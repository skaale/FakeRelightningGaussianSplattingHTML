using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class VHSRendererFeature : ScriptableRendererFeature
{
    class VHSRenderPass : ScriptableRenderPass
    {
        private VHS m_VHSEffect;
        private RTHandle m_TempRT;
        private ScriptableRenderer m_Renderer;

        public void Setup(ScriptableRenderer renderer)
        {
            m_Renderer = renderer;
        }

        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            RenderTextureDescriptor desc = renderingData.cameraData.cameraTargetDescriptor;
            desc.depthBufferBits = 0;
            desc.msaaSamples = 1;

            RenderingUtils.ReAllocateIfNeeded(ref m_TempRT, desc, FilterMode.Bilinear, TextureWrapMode.Clamp, name: "_VHSTempRT");
            
            ConfigureTarget(m_Renderer.cameraColorTargetHandle);
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            var stack = VolumeManager.instance.stack;
            m_VHSEffect = stack.GetComponent<VHS>();
            
            if (m_VHSEffect == null || !m_VHSEffect.IsActive())
                return;

            if (!m_VHSEffect.Setup())
            {
                Debug.LogError("VHS: Setup failed - shaders not found!");
                return;
            }

            CommandBuffer cmd = CommandBufferPool.Get("VHS Effect");

            RTHandle cameraTarget = renderingData.cameraData.renderer.cameraColorTargetHandle;
            Camera camera = renderingData.cameraData.camera;
            
            // Pass camera for VR detection (temporal effects disabled in VR)
            m_VHSEffect.Render(cmd, cameraTarget, m_TempRT, camera);
            
            cmd.Blit(m_TempRT.nameID, cameraTarget.nameID);

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }

        public void Dispose()
        {
            m_TempRT?.Release();
        }
    }

    VHSRenderPass m_ScriptablePass;

    public override void Create()
    {
        m_ScriptablePass = new VHSRenderPass();
        m_ScriptablePass.renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
    }

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        var stack = VolumeManager.instance.stack;
        var vhs = stack.GetComponent<VHS>();
        
        if (vhs == null || !vhs.IsActive())
            return;

        m_ScriptablePass.Setup(renderer);
        renderer.EnqueuePass(m_ScriptablePass);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            m_ScriptablePass?.Dispose();
            
            // Check if VolumeManager and stack are still available before accessing
            if (VolumeManager.instance != null && VolumeManager.instance.stack != null)
            {
                var vhs = VolumeManager.instance.stack.GetComponent<VHS>();
                if (vhs != null)
                {
                    vhs.Cleanup();
                }
            }
        }
    }
}

