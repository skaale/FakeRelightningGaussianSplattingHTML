#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEditor.Rendering;

[VolumeComponentEditor(typeof(VHS))]
public class VHSVolumeComponentEditor : VolumeComponentEditor
{
    private static int selectedTab = 0;
    private static readonly string[] tabNames = new string[]
    {
        "Presets",
        "General",
        "Chroma",
        "Scanlines",
        "Interference",
        "CRT",
        "Tape",
        "Color"
    };

    // Poster thumbnails
    private Texture2D posterBladeRunner;
    private Texture2D posterTerminator;
    private Texture2D posterMiamiVice;
    private Texture2D posterFriday13;
    private Texture2D posterGoonies;
    private bool postersLoaded = false;

    // General
    SerializedDataParameter retroIntensity;
    SerializedDataParameter filmResWidth, filmResHeight;
    SerializedDataParameter motionBlurH, motionBlurV;
    
    // Chroma
    SerializedDataParameter chromaBleed, chromaIntensity, chromaWobble, chromaOffset;
    SerializedDataParameter edgeEnhancement, sharpnessRadius;
    SerializedDataParameter filmGrain;
    
    // Tape
    SerializedDataParameter tapeTracking, trackingAmplitude;
    SerializedDataParameter phosphorBurn, tapeArtifacts, horizontalWobble;
    
    // Scanlines
    SerializedDataParameter scanlineIntensity, scanlineCount, scanlineSpeed;
    SerializedDataParameter tapeLines, tapeLinesCount, tapeLinesSpeed;
    SerializedDataParameter tapeLinesDarkness, tapeLinesDistortion;
    
    // Interference
    SerializedDataParameter headSwitchingNoise, staticNoiseBars, signalDropout, rainbowBanding;
    
    // CRT
    SerializedDataParameter ghosting, vignette, phosphorGlow, barrelDistortion;
    
    // Tape Playback
    SerializedDataParameter bottomRoll, tapeSpeedWobble, pauseJitter;
    
    // Color
    SerializedDataParameter filmResponse, colorSaturation, colorTemperature;
    SerializedDataParameter contrastRange, exposureRange;

    private GUIStyle headerStyle;
    private GUIStyle tabStyle;
    private GUIStyle selectedTabStyle;
    private GUIStyle descriptionStyle;
    private GUIStyle selectButtonStyle;
    private GUIStyle sectionTitleStyle;

    private string FindPostersFolder()
    {
        // Find this script's location and navigate to Posters folder
        var script = MonoScript.FromScriptableObject(ScriptableObject.CreateInstance<VHS>());
        if (script != null)
        {
            string scriptPath = AssetDatabase.GetAssetPath(script);
            string dir = System.IO.Path.GetDirectoryName(scriptPath);
            // Go up from Scripts folder to package root, then to Assets/Posters
            string packageRoot = System.IO.Path.GetDirectoryName(dir);
            string postersPath = System.IO.Path.Combine(packageRoot, "Assets", "Posters").Replace("\\", "/");
            if (AssetDatabase.IsValidFolder(postersPath))
                return postersPath;
        }
        
        // Fallback: search entire project for Posters folder containing VHS textures
        string[] folderGuids = AssetDatabase.FindAssets("Posters t:Folder");
        foreach (string guid in folderGuids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (path.EndsWith("Posters") || path.EndsWith("Posters/"))
            {
                string[] texGuids = AssetDatabase.FindAssets("t:Texture2D", new[] { path });
                if (texGuids.Length > 0)
                    return path;
            }
        }
        
        return null;
    }

    private void LoadPosterTextures()
    {
        if (postersLoaded) return;
        
        string postersFolder = FindPostersFolder();
        if (string.IsNullOrEmpty(postersFolder))
        {
            postersLoaded = true;
            return;
        }
        
        string[] guids = AssetDatabase.FindAssets("t:Texture2D", new[] { postersFolder });
        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            string filename = System.IO.Path.GetFileNameWithoutExtension(path).ToLower();
            Texture2D tex = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            
            if (filename.Contains("bladerun")) posterBladeRunner = tex;
            else if (filename.Contains("terminator")) posterTerminator = tex;
            else if (filename.Contains("miami")) posterMiamiVice = tex;
            else if (filename.Contains("friday")) posterFriday13 = tex;
            else if (filename.Contains("goonies")) posterGoonies = tex;
        }
        postersLoaded = true;
    }

    public override void OnEnable()
    {
        var o = new PropertyFetcher<VHS>(serializedObject);
        LoadPosterTextures();
        
        // General
        retroIntensity = Unpack(o.Find(x => x.VHS1980_RetroIntensity));
        filmResWidth = Unpack(o.Find(x => x.VHS1980_FilmResolutionWidth));
        filmResHeight = Unpack(o.Find(x => x.VHS1980_FilmResolutionHeight));
        motionBlurH = Unpack(o.Find(x => x.VHS1980_MotionBlurHorizontal));
        motionBlurV = Unpack(o.Find(x => x.VHS1980_MotionBlurVertical));
        
        // Chroma
        chromaBleed = Unpack(o.Find(x => x.VHS1980_ChromaBleed));
        chromaIntensity = Unpack(o.Find(x => x.VHS1980_ChromaIntensity));
        chromaWobble = Unpack(o.Find(x => x.VHS1980_ChromaWobble));
        chromaOffset = Unpack(o.Find(x => x.VHS1980_ChromaOffset));
        edgeEnhancement = Unpack(o.Find(x => x.VHS1980_EdgeEnhancement));
        sharpnessRadius = Unpack(o.Find(x => x.VHS1980_SharpnessRadius));
        filmGrain = Unpack(o.Find(x => x.VHS1980_FilmGrain));
        
        // Tape Tracking
        tapeTracking = Unpack(o.Find(x => x.VHS1980_TapeTracking));
        trackingAmplitude = Unpack(o.Find(x => x.VHS1980_TrackingAmplitude));
        phosphorBurn = Unpack(o.Find(x => x.VHS1980_PhosphorBurn));
        tapeArtifacts = Unpack(o.Find(x => x.VHS1980_TapeArtifacts));
        horizontalWobble = Unpack(o.Find(x => x.VHS1980_HorizontalWobble));
        
        // Scanlines
        scanlineIntensity = Unpack(o.Find(x => x.VHS1980_ScanlineIntensity));
        scanlineCount = Unpack(o.Find(x => x.VHS1980_ScanlineCount));
        scanlineSpeed = Unpack(o.Find(x => x.VHS1980_ScanlineSpeed));
        tapeLines = Unpack(o.Find(x => x.VHS1980_TapeLines));
        tapeLinesCount = Unpack(o.Find(x => x.VHS1980_TapeLinesCount));
        tapeLinesSpeed = Unpack(o.Find(x => x.VHS1980_TapeLinesSpeed));
        tapeLinesDarkness = Unpack(o.Find(x => x.VHS1980_TapeLinesDarkness));
        tapeLinesDistortion = Unpack(o.Find(x => x.VHS1980_TapeLinesDistortion));
        
        // Interference
        headSwitchingNoise = Unpack(o.Find(x => x.VHS1980_HeadSwitchingNoise));
        staticNoiseBars = Unpack(o.Find(x => x.VHS1980_StaticNoiseBars));
        signalDropout = Unpack(o.Find(x => x.VHS1980_SignalDropout));
        rainbowBanding = Unpack(o.Find(x => x.VHS1980_RainbowBanding));
        
        // CRT
        ghosting = Unpack(o.Find(x => x.VHS1980_Ghosting));
        vignette = Unpack(o.Find(x => x.VHS1980_Vignette));
        phosphorGlow = Unpack(o.Find(x => x.VHS1980_PhosphorGlow));
        barrelDistortion = Unpack(o.Find(x => x.VHS1980_BarrelDistortion));
        
        // Tape Playback
        bottomRoll = Unpack(o.Find(x => x.VHS1980_BottomRoll));
        tapeSpeedWobble = Unpack(o.Find(x => x.VHS1980_TapeSpeedWobble));
        pauseJitter = Unpack(o.Find(x => x.VHS1980_PauseJitter));
        
        // Color
        filmResponse = Unpack(o.Find(x => x.VHS1980_FilmResponse));
        colorSaturation = Unpack(o.Find(x => x.VHS1980_ColorSaturation));
        colorTemperature = Unpack(o.Find(x => x.VHS1980_ColorTemperature));
        contrastRange = Unpack(o.Find(x => x.VHS1980_ContrastRange));
        exposureRange = Unpack(o.Find(x => x.VHS1980_ExposureRange));
    }

    private void InitStyles()
    {
        if (headerStyle == null)
        {
            headerStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 14,
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = new Color(0.9f, 0.75f, 0.4f) }
            };
        }

        if (tabStyle == null)
        {
            tabStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = 10,
                padding = new RectOffset(6, 6, 6, 6),
                margin = new RectOffset(1, 1, 0, 0),
                fixedHeight = 28
            };
        }

        if (selectedTabStyle == null)
        {
            selectedTabStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = 10,
                padding = new RectOffset(6, 6, 6, 6),
                margin = new RectOffset(1, 1, 0, 0),
                fixedHeight = 28,
                fontStyle = FontStyle.Bold
            };
            selectedTabStyle.normal.textColor = Color.white;
        }

        if (descriptionStyle == null)
        {
            descriptionStyle = new GUIStyle(EditorStyles.miniLabel)
            {
                fontSize = 10,
                wordWrap = true,
                normal = { textColor = new Color(0.6f, 0.6f, 0.6f) }
            };
        }

        if (selectButtonStyle == null)
        {
            selectButtonStyle = new GUIStyle(EditorStyles.miniButton)
            {
                fontSize = 9,
                fixedHeight = 18
            };
        }

        if (sectionTitleStyle == null)
        {
            sectionTitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                fontStyle = FontStyle.Bold,
                normal = { textColor = new Color(0.85f, 0.85f, 0.85f) },
                padding = new RectOffset(0, 0, 5, 2)
            };
        }
    }

    private void DrawSelectAllNoneButtons(params SerializedDataParameter[] parameters)
    {
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        
        GUI.backgroundColor = new Color(0.3f, 0.5f, 0.3f);
        if (GUILayout.Button("Select All", selectButtonStyle, GUILayout.Width(70)))
        {
            foreach (var param in parameters)
            {
                if (param != null)
                    param.overrideState.boolValue = true;
            }
        }
        
        GUI.backgroundColor = new Color(0.5f, 0.3f, 0.3f);
        if (GUILayout.Button("Select None", selectButtonStyle, GUILayout.Width(70)))
        {
            foreach (var param in parameters)
            {
                if (param != null)
                    param.overrideState.boolValue = false;
            }
        }
        GUI.backgroundColor = Color.white;
        
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.Space(5);
    }

    public override void OnInspectorGUI()
    {
        InitStyles();

        // Header
        EditorGUILayout.Space(5);
        EditorGUILayout.LabelField("━━━ VHS 1980 VR Effects ━━━", headerStyle);
        EditorGUILayout.Space(5);

        // Reset button
        EditorGUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        GUI.backgroundColor = new Color(0.7f, 0.3f, 0.3f);
        if (GUILayout.Button("Reset All", GUILayout.Width(80), GUILayout.Height(20)))
        {
            VHS vhs = (VHS)target;
            Undo.RecordObject(vhs, "Reset VHS to Defaults");
            vhs.ResetToDefaults();
            serializedObject.Update();
            EditorUtility.SetDirty(vhs);
        }
        GUI.backgroundColor = Color.white;
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(5);

        // Tab bar
        EditorGUILayout.BeginHorizontal();
        for (int i = 0; i < tabNames.Length; i++)
        {
            GUI.backgroundColor = (selectedTab == i) ? new Color(0.4f, 0.6f, 0.9f) : new Color(0.3f, 0.3f, 0.3f);
            GUIStyle style = (selectedTab == i) ? selectedTabStyle : tabStyle;
            if (GUILayout.Button(tabNames[i], style))
            {
                selectedTab = i;
            }
        }
        GUI.backgroundColor = Color.white;
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.Space(10);

        // Draw selected tab content
        switch (selectedTab)
        {
            case 0: DrawPresetsTab(); break;
            case 1: DrawGeneralTab(); break;
            case 2: DrawChromaTab(); break;
            case 3: DrawScanlinesTab(); break;
            case 4: DrawInterferenceTab(); break;
            case 5: DrawCRTTab(); break;
            case 6: DrawTapeTab(); break;
            case 7: DrawColorTab(); break;
        }
    }

    private void DrawPresetRow(string title, string description, Color buttonColor, 
        Texture2D poster, VHSPresets.MoviePreset preset, VHS vhs)
    {
        // Card background
        Rect bgRect = EditorGUILayout.BeginHorizontal(EditorStyles.helpBox, GUILayout.Height(80));
        
        // Thumbnail on left
        if (poster != null)
        {
            Rect rect = GUILayoutUtility.GetRect(100, 100, GUILayout.Width(40), GUILayout.Height(60));
            rect.y += 8;
            GUI.DrawTexture(rect, poster, ScaleMode.ScaleAndCrop);
            GUILayout.Space(12);
        }
        
        // Right side: text and button
        EditorGUILayout.BeginVertical();
        GUILayout.Space(6);
        EditorGUILayout.LabelField(title, sectionTitleStyle);
        EditorGUILayout.LabelField(description, descriptionStyle);
        GUILayout.Space(4);
        GUI.backgroundColor = buttonColor;
        if (GUILayout.Button("Apply", GUILayout.Height(24), GUILayout.Width(100)))
        {
            Undo.RecordObject(vhs, "Apply " + title + " Preset");
            VHSPresets.ApplyPresetTo(vhs, preset);
            EditorUtility.SetDirty(vhs);
        }
        GUI.backgroundColor = Color.white;
        GUILayout.Space(4);
        EditorGUILayout.EndVertical();
        
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.Space(4);
    }

    private void DrawPresetsTab()
    {
        EditorGUILayout.LabelField("Select a 1980s movie style preset", descriptionStyle);
        EditorGUILayout.Space(6);
        
        VHS vhs = (VHS)target;
        
        DrawPresetRow("Blade Runner (1982)", 
            "Neo-noir: Neon highlights, deep shadows, cool tones",
            new Color(0.2f, 0.5f, 0.7f), posterBladeRunner, 
            VHSPresets.MoviePreset.BladeRunner1982, vhs);
        
        DrawPresetRow("The Terminator (1984)", 
            "Sci-fi: Blue tint, high contrast, cold atmosphere",
            new Color(0.3f, 0.4f, 0.6f), posterTerminator, 
            VHSPresets.MoviePreset.Terminator1984, vhs);
        
        DrawPresetRow("Miami Vice (1984)", 
            "Stylish: Pastel neon, warm saturated, clean look",
            new Color(0.9f, 0.4f, 0.6f), posterMiamiVice, 
            VHSPresets.MoviePreset.MiamiVice1984, vhs);
        
        DrawPresetRow("Friday the 13th (1980)", 
            "Horror: Desaturated, green tint, heavy grain",
            new Color(0.3f, 0.5f, 0.3f), posterFriday13, 
            VHSPresets.MoviePreset.FridayThe13th1980, vhs);
        
        DrawPresetRow("The Goonies (1985)", 
            "Adventure: Warm vibrant colors, light grain",
            new Color(0.8f, 0.6f, 0.3f), posterGoonies, 
            VHSPresets.MoviePreset.TheGoonies1985, vhs);
    }

    private void DrawGeneralTab()
    {
        DrawSelectAllNoneButtons(retroIntensity, filmResWidth, filmResHeight, motionBlurH, motionBlurV);
        
        EditorGUILayout.LabelField("Main effect controls and resolution settings", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Master Control", sectionTitleStyle);
        PropertyField(retroIntensity, new GUIContent("VHS Intensity"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Resolution", sectionTitleStyle);
        EditorGUILayout.LabelField("Lower values create more authentic VHS look", descriptionStyle);
        PropertyField(filmResWidth, new GUIContent("Width"));
        PropertyField(filmResHeight, new GUIContent("Height"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Motion Blur", sectionTitleStyle);
        EditorGUILayout.LabelField("Simulates VHS tape motion blur", descriptionStyle);
        PropertyField(motionBlurH, new GUIContent("Horizontal"));
        PropertyField(motionBlurV, new GUIContent("Vertical"));
    }

    private void DrawChromaTab()
    {
        DrawSelectAllNoneButtons(chromaBleed, chromaIntensity, chromaWobble, chromaOffset, 
            edgeEnhancement, sharpnessRadius, filmGrain);
        
        EditorGUILayout.LabelField("Color channel processing and edge effects", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Chroma Processing", sectionTitleStyle);
        PropertyField(chromaBleed, new GUIContent("Chroma Bleed"));
        PropertyField(chromaIntensity, new GUIContent("Chroma Intensity"));
        PropertyField(chromaWobble, new GUIContent("Chroma Wobble"));
        PropertyField(chromaOffset, new GUIContent("Chroma Offset"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Edge Enhancement", sectionTitleStyle);
        PropertyField(edgeEnhancement, new GUIContent("Edge Enhancement"));
        PropertyField(sharpnessRadius, new GUIContent("Sharpness Radius"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Film Grain", sectionTitleStyle);
        PropertyField(filmGrain, new GUIContent("Film Grain"));
    }

    private void DrawScanlinesTab()
    {
        DrawSelectAllNoneButtons(scanlineIntensity, scanlineCount, scanlineSpeed, 
            tapeLines, tapeLinesCount, tapeLinesSpeed, tapeLinesDarkness, tapeLinesDistortion);
        
        EditorGUILayout.LabelField("CRT scanline and tape line simulation", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Scanline Settings", sectionTitleStyle);
        PropertyField(scanlineIntensity, new GUIContent("Intensity"));
        PropertyField(scanlineCount, new GUIContent("Count"));
        PropertyField(scanlineSpeed, new GUIContent("Speed"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Tape Lines (VR Compatible)", sectionTitleStyle);
        EditorGUILayout.LabelField("Horizontal interference lines - works in VR", descriptionStyle);
        PropertyField(tapeLines, new GUIContent("Tape Lines"));
        PropertyField(tapeLinesCount, new GUIContent("Line Count"));
        PropertyField(tapeLinesSpeed, new GUIContent("Line Speed"));
        PropertyField(tapeLinesDarkness, new GUIContent("Line Darkness"));
        PropertyField(tapeLinesDistortion, new GUIContent("Line Distortion"));
    }

    private void DrawInterferenceTab()
    {
        DrawSelectAllNoneButtons(headSwitchingNoise, staticNoiseBars, signalDropout, rainbowBanding);
        
        EditorGUILayout.LabelField("Signal interference and noise effects", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Signal Noise", sectionTitleStyle);
        PropertyField(headSwitchingNoise, new GUIContent("Head Switching Noise"));
        PropertyField(staticNoiseBars, new GUIContent("Static Noise Bars"));
        PropertyField(signalDropout, new GUIContent("Signal Dropout"));
        PropertyField(rainbowBanding, new GUIContent("Rainbow Banding"));
    }

    private void DrawCRTTab()
    {
        DrawSelectAllNoneButtons(ghosting, vignette, phosphorGlow, barrelDistortion);
        
        EditorGUILayout.LabelField("CRT display simulation effects", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Display Effects", sectionTitleStyle);
        PropertyField(ghosting, new GUIContent("Ghosting"));
        PropertyField(vignette, new GUIContent("Vignette"));
        PropertyField(phosphorGlow, new GUIContent("Phosphor Glow"));
        PropertyField(barrelDistortion, new GUIContent("Barrel Distortion"));
    }

    private void DrawTapeTab()
    {
        DrawSelectAllNoneButtons(tapeTracking, trackingAmplitude, phosphorBurn, tapeArtifacts, 
            horizontalWobble, bottomRoll, tapeSpeedWobble, pauseJitter);
        
        EditorGUILayout.LabelField("VHS tape playback artifacts", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Tape Tracking", sectionTitleStyle);
        PropertyField(tapeTracking, new GUIContent("Tape Tracking"));
        PropertyField(trackingAmplitude, new GUIContent("Tracking Amplitude"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Tape Artifacts", sectionTitleStyle);
        PropertyField(phosphorBurn, new GUIContent("Phosphor Burn"));
        PropertyField(tapeArtifacts, new GUIContent("Tape Artifacts"));
        PropertyField(horizontalWobble, new GUIContent("Horizontal Wobble"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Playback Effects", sectionTitleStyle);
        PropertyField(bottomRoll, new GUIContent("Bottom Roll"));
        PropertyField(tapeSpeedWobble, new GUIContent("Speed Wobble"));
        PropertyField(pauseJitter, new GUIContent("Pause Jitter"));
    }

    private void DrawColorTab()
    {
        DrawSelectAllNoneButtons(filmResponse, colorSaturation, colorTemperature, contrastRange, exposureRange);
        
        EditorGUILayout.LabelField("Color grading and film response", descriptionStyle);
        EditorGUILayout.Space(5);
        
        EditorGUILayout.LabelField("▸ Color Grading", sectionTitleStyle);
        PropertyField(filmResponse, new GUIContent("Film Response"));
        PropertyField(colorSaturation, new GUIContent("Saturation"));
        PropertyField(colorTemperature, new GUIContent("Temperature"));
        
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("▸ Dynamic Range", sectionTitleStyle);
        PropertyField(contrastRange, new GUIContent("Contrast"));
        PropertyField(exposureRange, new GUIContent("Exposure"));
    }
}
#endif
