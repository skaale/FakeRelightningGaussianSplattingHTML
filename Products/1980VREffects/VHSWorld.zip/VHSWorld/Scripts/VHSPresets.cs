using UnityEngine;
using UnityEngine.Rendering;

/// <summary>
/// VHS 1980s Movie Presets - Authentic film looks from iconic 80s movies
/// </summary>
public class VHSPresets : MonoBehaviour
{
    public enum MoviePreset
    {
        None,
        BladeRunner1982,      // Neo-noir sci-fi, neon highlights, high contrast
        Terminator1984,       // Gritty blue tint, cold atmosphere
        MiamiVice1984,        // Pastel neon, warm saturated
        FridayThe13th1980,    // Horror, desaturated, green tint
        TheGoonies1985        // Adventure, warm vibrant colors
    }

    [Header("Preset Selection")]
    public MoviePreset currentPreset = MoviePreset.None;
    
    [Header("Volume Reference")]
    public Volume vhsVolume;
    
    private VHS vhsComponent;
    private MoviePreset lastPreset = MoviePreset.None;

    void Start()
    {
        FindVHSComponent();
    }

    void Update()
    {
        if (currentPreset != lastPreset)
        {
            ApplyPreset(currentPreset);
            lastPreset = currentPreset;
        }
    }

    void FindVHSComponent()
    {
        if (vhsVolume != null && vhsVolume.profile != null)
        {
            vhsVolume.profile.TryGet(out vhsComponent);
        }
        else
        {
            var volume = FindObjectOfType<Volume>();
            if (volume != null && volume.profile != null)
            {
                volume.profile.TryGet(out vhsComponent);
                vhsVolume = volume;
            }
        }
    }

    public void ApplyPreset(MoviePreset preset)
    {
        if (vhsComponent == null)
        {
            FindVHSComponent();
            if (vhsComponent == null) return;
        }

        switch (preset)
        {
            case MoviePreset.BladeRunner1982:
                EnableAllOverrides();
                ApplyBladeRunner();
                break;
            case MoviePreset.Terminator1984:
                EnableAllOverrides();
                ApplyTerminator();
                break;
            case MoviePreset.MiamiVice1984:
                EnableAllOverrides();
                ApplyMiamiVice();
                break;
            case MoviePreset.FridayThe13th1980:
                EnableAllOverrides();
                ApplyFridayThe13th();
                break;
            case MoviePreset.TheGoonies1985:
                EnableAllOverrides();
                ApplyTheGoonies();
                break;
            case MoviePreset.None:
                vhsComponent.ResetToDefaults();
                break;
        }
    }

    void EnableAllOverrides()
    {
        vhsComponent.VHS1980_RetroIntensity.overrideState = true;
        vhsComponent.VHS1980_FilmResolutionWidth.overrideState = true;
        vhsComponent.VHS1980_FilmResolutionHeight.overrideState = true;
        vhsComponent.VHS1980_MotionBlurHorizontal.overrideState = true;
        vhsComponent.VHS1980_MotionBlurVertical.overrideState = true;
        vhsComponent.VHS1980_ChromaBleed.overrideState = true;
        vhsComponent.VHS1980_ChromaIntensity.overrideState = true;
        vhsComponent.VHS1980_ChromaWobble.overrideState = true;
        vhsComponent.VHS1980_ChromaOffset.overrideState = true;
        vhsComponent.VHS1980_EdgeEnhancement.overrideState = true;
        vhsComponent.VHS1980_SharpnessRadius.overrideState = true;
        vhsComponent.VHS1980_FilmGrain.overrideState = true;
        vhsComponent.VHS1980_TapeTracking.overrideState = true;
        vhsComponent.VHS1980_TrackingAmplitude.overrideState = true;
        vhsComponent.VHS1980_PhosphorBurn.overrideState = true;
        vhsComponent.VHS1980_TapeArtifacts.overrideState = true;
        vhsComponent.VHS1980_HorizontalWobble.overrideState = true;
        vhsComponent.VHS1980_ScanlineIntensity.overrideState = true;
        vhsComponent.VHS1980_ScanlineCount.overrideState = true;
        vhsComponent.VHS1980_ScanlineSpeed.overrideState = true;
        vhsComponent.VHS1980_TapeLines.overrideState = true;
        vhsComponent.VHS1980_TapeLinesCount.overrideState = true;
        vhsComponent.VHS1980_TapeLinesSpeed.overrideState = true;
        vhsComponent.VHS1980_TapeLinesDarkness.overrideState = true;
        vhsComponent.VHS1980_TapeLinesDistortion.overrideState = true;
        vhsComponent.VHS1980_HeadSwitchingNoise.overrideState = true;
        vhsComponent.VHS1980_StaticNoiseBars.overrideState = true;
        vhsComponent.VHS1980_SignalDropout.overrideState = true;
        vhsComponent.VHS1980_RainbowBanding.overrideState = true;
        vhsComponent.VHS1980_Ghosting.overrideState = true;
        vhsComponent.VHS1980_Vignette.overrideState = true;
        vhsComponent.VHS1980_PhosphorGlow.overrideState = true;
        vhsComponent.VHS1980_BarrelDistortion.overrideState = true;
        vhsComponent.VHS1980_BottomRoll.overrideState = true;
        vhsComponent.VHS1980_TapeSpeedWobble.overrideState = true;
        vhsComponent.VHS1980_PauseJitter.overrideState = true;
        vhsComponent.VHS1980_FilmResponse.overrideState = true;
        vhsComponent.VHS1980_ColorSaturation.overrideState = true;
        vhsComponent.VHS1980_ColorTemperature.overrideState = true;
        vhsComponent.VHS1980_ContrastRange.overrideState = true;
        vhsComponent.VHS1980_ExposureRange.overrideState = true;
    }

    /// <summary>
    /// Blade Runner (1982) - Ridley Scott
    /// Neo-noir sci-fi: Deep shadows, neon cyan/pink highlights, smoky atmosphere
    /// High contrast, cool tones, phosphor glow for neon effects
    /// </summary>
    void ApplyBladeRunner()
    {
        vhsComponent.VHS1980_RetroIntensity.value = 0.85f;
        
        // Resolution - slightly degraded for film look
        vhsComponent.VHS1980_FilmResolutionWidth.value = 480;
        vhsComponent.VHS1980_FilmResolutionHeight.value = 720;
        
        // Motion blur - subtle cinematic
        vhsComponent.VHS1980_MotionBlurHorizontal.value = 0.8f;
        vhsComponent.VHS1980_MotionBlurVertical.value = 0.5f;
        
        // Chroma - cyan/magenta color bleeding
        vhsComponent.VHS1980_ChromaBleed.value = 2.2f;
        vhsComponent.VHS1980_ChromaIntensity.value = 1.4f;
        vhsComponent.VHS1980_ChromaWobble.value = 0.3f;
        vhsComponent.VHS1980_ChromaOffset.value = 0.025f;
        
        // Edge enhancement - sharp neon edges
        vhsComponent.VHS1980_EdgeEnhancement.value = 1.8f;
        vhsComponent.VHS1980_SharpnessRadius.value = 1.5f;
        
        // Film grain - moderate
        vhsComponent.VHS1980_FilmGrain.value = 0.025f;
        
        // Tape tracking - minimal
        vhsComponent.VHS1980_TapeTracking.value = 0.1f;
        vhsComponent.VHS1980_TrackingAmplitude.value = 0.01f;
        
        // Artifacts - smoky atmosphere
        vhsComponent.VHS1980_PhosphorBurn.value = 0.15f;
        vhsComponent.VHS1980_TapeArtifacts.value = 0.05f;
        vhsComponent.VHS1980_HorizontalWobble.value = 0.3f;
        
        // Scanlines - subtle CRT
        vhsComponent.VHS1980_ScanlineIntensity.value = 0.35f;
        vhsComponent.VHS1980_ScanlineCount.value = 360f;
        vhsComponent.VHS1980_ScanlineSpeed.value = 30f;
        vhsComponent.VHS1980_TapeLines.value = 0.1f;
        vhsComponent.VHS1980_TapeLinesCount.value = 4f;
        
        // CRT Display - neon glow and vignette
        vhsComponent.VHS1980_Ghosting.value = 0.08f;
        vhsComponent.VHS1980_Vignette.value = 0.4f;
        vhsComponent.VHS1980_PhosphorGlow.value = 0.35f;
        vhsComponent.VHS1980_BarrelDistortion.value = 0.05f;
        
        // VR-safe: no bottom roll
        vhsComponent.VHS1980_BottomRoll.value = 0f;
        vhsComponent.VHS1980_TapeSpeedWobble.value = 0f;
        vhsComponent.VHS1980_PauseJitter.value = 0f;
        
        // Color grading - cool cyan noir with crushed blacks
        vhsComponent.VHS1980_FilmResponse.value = 0.3f;
        vhsComponent.VHS1980_ColorSaturation.value = 0.7f;
        vhsComponent.VHS1980_ColorTemperature.value = -0.4f;
        vhsComponent.VHS1980_ContrastRange.value = new Vector2(0.08f, 0.92f);
        vhsComponent.VHS1980_ExposureRange.value = new Vector2(0.05f, 0.95f);
    }

    /// <summary>
    /// The Terminator (1984) - James Cameron
    /// Gritty sci-fi: Strong blue tint, high contrast, cold atmosphere
    /// Film grain, dark shadows, tech-noir aesthetic
    /// </summary>
    void ApplyTerminator()
    {
        vhsComponent.VHS1980_RetroIntensity.value = 0.9f;
        
        // Resolution - gritty film stock
        vhsComponent.VHS1980_FilmResolutionWidth.value = 400;
        vhsComponent.VHS1980_FilmResolutionHeight.value = 640;
        
        // Motion blur - action scenes
        vhsComponent.VHS1980_MotionBlurHorizontal.value = 1.2f;
        vhsComponent.VHS1980_MotionBlurVertical.value = 0.8f;
        
        // Chroma - blue steel color palette
        vhsComponent.VHS1980_ChromaBleed.value = 1.5f;
        vhsComponent.VHS1980_ChromaIntensity.value = 0.9f;
        vhsComponent.VHS1980_ChromaWobble.value = 0.4f;
        vhsComponent.VHS1980_ChromaOffset.value = 0.015f;
        
        // Edge enhancement - harsh metallic
        vhsComponent.VHS1980_EdgeEnhancement.value = 2.0f;
        vhsComponent.VHS1980_SharpnessRadius.value = 1.8f;
        
        // Film grain - gritty look
        vhsComponent.VHS1980_FilmGrain.value = 0.025f;
        
        // Tape tracking
        vhsComponent.VHS1980_TapeTracking.value = 0.15f;
        vhsComponent.VHS1980_TrackingAmplitude.value = 0.015f;
        
        // Artifacts - tech-noir grit
        vhsComponent.VHS1980_PhosphorBurn.value = 0.08f;
        vhsComponent.VHS1980_TapeArtifacts.value = 0.12f;
        vhsComponent.VHS1980_HorizontalWobble.value = 0.5f;
        
        // Scanlines - tech display look
        vhsComponent.VHS1980_ScanlineIntensity.value = 0.45f;
        vhsComponent.VHS1980_ScanlineCount.value = 320f;
        vhsComponent.VHS1980_ScanlineSpeed.value = 45f;
        vhsComponent.VHS1980_TapeLines.value = 0.15f;
        vhsComponent.VHS1980_TapeLinesCount.value = 6f;
        
        // Signal interference - tech static
        vhsComponent.VHS1980_HeadSwitchingNoise.value = 0.1f;
        vhsComponent.VHS1980_StaticNoiseBars.value = 0.08f;
        
        // CRT Display
        vhsComponent.VHS1980_Ghosting.value = 0.12f;
        vhsComponent.VHS1980_Vignette.value = 0.35f;
        vhsComponent.VHS1980_PhosphorGlow.value = 0.2f;
        vhsComponent.VHS1980_BarrelDistortion.value = 0.08f;
        
        // VR-safe: no bottom roll
        vhsComponent.VHS1980_BottomRoll.value = 0f;
        vhsComponent.VHS1980_TapeSpeedWobble.value = 0f;
        vhsComponent.VHS1980_PauseJitter.value = 0f;
        
        // Color grading - very cold blue steel
        vhsComponent.VHS1980_FilmResponse.value = 0.4f;
        vhsComponent.VHS1980_ColorSaturation.value = 0.5f;
        vhsComponent.VHS1980_ColorTemperature.value = -0.65f;
        vhsComponent.VHS1980_ContrastRange.value = new Vector2(0.12f, 0.88f);
        vhsComponent.VHS1980_ExposureRange.value = new Vector2(0.08f, 0.92f);
    }

    /// <summary>
    /// Miami Vice (1984-1989) - Michael Mann
    /// Neon nightlife: Strong pink/cyan color bleed, stylish TV look
    /// Heavy chroma effects, phosphor glow, NTSC artifacts
    /// </summary>
    void ApplyMiamiVice()
    {
        vhsComponent.VHS1980_RetroIntensity.value = 0.8f;
        
        // Resolution - TV broadcast quality
        vhsComponent.VHS1980_FilmResolutionWidth.value = 480;
        vhsComponent.VHS1980_FilmResolutionHeight.value = 720;
        
        // Motion blur - smooth stylish
        vhsComponent.VHS1980_MotionBlurHorizontal.value = 0.5f;
        vhsComponent.VHS1980_MotionBlurVertical.value = 0.3f;
        
        // Chroma - VERY strong neon pink/cyan bleed (signature look)
        vhsComponent.VHS1980_ChromaBleed.value = 3.5f;
        vhsComponent.VHS1980_ChromaIntensity.value = 2.0f;
        vhsComponent.VHS1980_ChromaWobble.value = 0.15f;
        vhsComponent.VHS1980_ChromaOffset.value = 0.045f;
        
        // Edge enhancement - sharp neon edges
        vhsComponent.VHS1980_EdgeEnhancement.value = 1.8f;
        vhsComponent.VHS1980_SharpnessRadius.value = 1.5f;
        
        // Film grain - minimal for clean TV
        vhsComponent.VHS1980_FilmGrain.value = 0.02f;
        
        // Tape tracking - minimal
        vhsComponent.VHS1980_TapeTracking.value = 0.05f;
        vhsComponent.VHS1980_TrackingAmplitude.value = 0.005f;
        
        // Artifacts - very clean
        vhsComponent.VHS1980_PhosphorBurn.value = 0.02f;
        vhsComponent.VHS1980_TapeArtifacts.value = 0.01f;
        vhsComponent.VHS1980_HorizontalWobble.value = 0.1f;
        
        // Scanlines - TV broadcast look
        vhsComponent.VHS1980_ScanlineIntensity.value = 0.35f;
        vhsComponent.VHS1980_ScanlineCount.value = 480f;
        vhsComponent.VHS1980_ScanlineSpeed.value = 60f;
        vhsComponent.VHS1980_TapeLines.value = 0.08f;
        vhsComponent.VHS1980_TapeLinesCount.value = 4f;
        
        // Rainbow banding - strong NTSC color interference
        vhsComponent.VHS1980_RainbowBanding.value = 0.25f;
        
        // CRT Display - strong neon glow
        vhsComponent.VHS1980_Ghosting.value = 0.08f;
        vhsComponent.VHS1980_Vignette.value = 0.35f;
        vhsComponent.VHS1980_PhosphorGlow.value = 0.55f;
        vhsComponent.VHS1980_BarrelDistortion.value = 0.04f;
        
        // VR-safe: no bottom roll
        vhsComponent.VHS1980_BottomRoll.value = 0f;
        vhsComponent.VHS1980_TapeSpeedWobble.value = 0f;
        vhsComponent.VHS1980_PauseJitter.value = 0f;
        
        // Color grading - cool pink/magenta with slight cool shift for neon contrast
        vhsComponent.VHS1980_FilmResponse.value = -0.25f;
        vhsComponent.VHS1980_ColorSaturation.value = 1.0f;
        vhsComponent.VHS1980_ColorTemperature.value = -0.15f;
        vhsComponent.VHS1980_ContrastRange.value = new Vector2(0.05f, 0.95f);
        vhsComponent.VHS1980_ExposureRange.value = new Vector2(0.0f, 1.0f);
    }

    /// <summary>
    /// Friday the 13th (1980) - Sean S. Cunningham
    /// Classic horror: Desaturated, yellowish/sepia worn tape look
    /// Eerie atmosphere, dark shadows, heavily degraded VHS
    /// </summary>
    void ApplyFridayThe13th()
    {
        vhsComponent.VHS1980_RetroIntensity.value = 0.95f;
        
        // Resolution - very low budget horror film
        vhsComponent.VHS1980_FilmResolutionWidth.value = 280;
        vhsComponent.VHS1980_FilmResolutionHeight.value = 420;
        
        // Motion blur - heavy suspenseful
        vhsComponent.VHS1980_MotionBlurHorizontal.value = 1.8f;
        vhsComponent.VHS1980_MotionBlurVertical.value = 1.2f;
        
        // Chroma - very muted, almost no color bleed
        vhsComponent.VHS1980_ChromaBleed.value = 0.8f;
        vhsComponent.VHS1980_ChromaIntensity.value = 0.5f;
        vhsComponent.VHS1980_ChromaWobble.value = 0.8f;
        vhsComponent.VHS1980_ChromaOffset.value = 0.015f;
        
        // Edge enhancement - soft degraded
        vhsComponent.VHS1980_EdgeEnhancement.value = 0.8f;
        vhsComponent.VHS1980_SharpnessRadius.value = 0.6f;
        
        // Film grain - worn tape grain
        vhsComponent.VHS1980_FilmGrain.value = 0.025f;
        
        // Tape tracking - badly worn tape
        vhsComponent.VHS1980_TapeTracking.value = 0.5f;
        vhsComponent.VHS1980_TrackingAmplitude.value = 0.035f;
        
        // Artifacts - heavily worn old tape
        vhsComponent.VHS1980_PhosphorBurn.value = 0.3f;
        vhsComponent.VHS1980_TapeArtifacts.value = 0.35f;
        vhsComponent.VHS1980_HorizontalWobble.value = 1.2f;
        
        // Scanlines - old worn CRT
        vhsComponent.VHS1980_ScanlineIntensity.value = 0.65f;
        vhsComponent.VHS1980_ScanlineCount.value = 240f;
        vhsComponent.VHS1980_ScanlineSpeed.value = 40f;
        vhsComponent.VHS1980_TapeLines.value = 0.35f;
        vhsComponent.VHS1980_TapeLinesCount.value = 12f;
        vhsComponent.VHS1980_TapeLinesDarkness.value = 0.5f;
        vhsComponent.VHS1980_TapeLinesDistortion.value = 0.7f;
        
        // Signal interference - very bad degraded signal
        vhsComponent.VHS1980_HeadSwitchingNoise.value = 0.3f;
        vhsComponent.VHS1980_StaticNoiseBars.value = 0.25f;
        vhsComponent.VHS1980_SignalDropout.value = 0.15f;
        
        // CRT Display - old worn CRT
        vhsComponent.VHS1980_Ghosting.value = 0.2f;
        vhsComponent.VHS1980_Vignette.value = 0.6f;
        vhsComponent.VHS1980_PhosphorGlow.value = 0.05f;
        vhsComponent.VHS1980_BarrelDistortion.value = 0.12f;
        
        // VR-safe: no bottom roll
        vhsComponent.VHS1980_BottomRoll.value = 0f;
        vhsComponent.VHS1980_TapeSpeedWobble.value = 0f;
        vhsComponent.VHS1980_PauseJitter.value = 0f;
        
        // Color grading - WARM yellowish/sepia desaturated horror (opposite of Terminator's cold blue)
        vhsComponent.VHS1980_FilmResponse.value = 0.7f;
        vhsComponent.VHS1980_ColorSaturation.value = 0.2f;
        vhsComponent.VHS1980_ColorTemperature.value = 0.35f;
        vhsComponent.VHS1980_ContrastRange.value = new Vector2(0.2f, 0.8f);
        vhsComponent.VHS1980_ExposureRange.value = new Vector2(0.15f, 0.85f);
    }

    /// <summary>
    /// The Goonies (1985) - Richard Donner
    /// Adventure comedy: Natural sunny film look, golden warmth
    /// Minimal VHS artifacts, clean Spielberg-style cinema
    /// </summary>
    void ApplyTheGoonies()
    {
        vhsComponent.VHS1980_RetroIntensity.value = 0.5f;
        
        // Resolution - high quality cinema film
        vhsComponent.VHS1980_FilmResolutionWidth.value = 640;
        vhsComponent.VHS1980_FilmResolutionHeight.value = 960;
        
        // Motion blur - natural cinema
        vhsComponent.VHS1980_MotionBlurHorizontal.value = 0.4f;
        vhsComponent.VHS1980_MotionBlurVertical.value = 0.3f;
        
        // Chroma - minimal, natural colors (not VHS-like)
        vhsComponent.VHS1980_ChromaBleed.value = 0.8f;
        vhsComponent.VHS1980_ChromaIntensity.value = 0.9f;
        vhsComponent.VHS1980_ChromaWobble.value = 0.05f;
        vhsComponent.VHS1980_ChromaOffset.value = 0.005f;
        
        // Edge enhancement - soft natural
        vhsComponent.VHS1980_EdgeEnhancement.value = 0.9f;
        vhsComponent.VHS1980_SharpnessRadius.value = 0.8f;
        
        // Film grain - natural 35mm film grain
        vhsComponent.VHS1980_FilmGrain.value = 0.02f;
        
        // Tape tracking - pristine
        vhsComponent.VHS1980_TapeTracking.value = 0.02f;
        vhsComponent.VHS1980_TrackingAmplitude.value = 0.002f;
        
        // Artifacts - almost none (quality film)
        vhsComponent.VHS1980_PhosphorBurn.value = 0.01f;
        vhsComponent.VHS1980_TapeArtifacts.value = 0.01f;
        vhsComponent.VHS1980_HorizontalWobble.value = 0.05f;
        
        // Scanlines - very subtle cinema (24fps look)
        vhsComponent.VHS1980_ScanlineIntensity.value = 0.1f;
        vhsComponent.VHS1980_ScanlineCount.value = 480f;
        vhsComponent.VHS1980_ScanlineSpeed.value = 24f;
        vhsComponent.VHS1980_TapeLines.value = 0f;
        vhsComponent.VHS1980_TapeLinesCount.value = 0f;
        
        // No rainbow banding (cinema, not TV)
        vhsComponent.VHS1980_RainbowBanding.value = 0f;
        
        // CRT Display - minimal, bright open look
        vhsComponent.VHS1980_Ghosting.value = 0.01f;
        vhsComponent.VHS1980_Vignette.value = 0.08f;
        vhsComponent.VHS1980_PhosphorGlow.value = 0.1f;
        vhsComponent.VHS1980_BarrelDistortion.value = 0f;
        
        // VR-safe: no bottom roll
        vhsComponent.VHS1980_BottomRoll.value = 0f;
        vhsComponent.VHS1980_TapeSpeedWobble.value = 0f;
        vhsComponent.VHS1980_PauseJitter.value = 0f;
        
        // Color grading - very warm golden sunlight, Spielberg magic hour
        vhsComponent.VHS1980_FilmResponse.value = -0.3f;
        vhsComponent.VHS1980_ColorSaturation.value = 0.75f;
        vhsComponent.VHS1980_ColorTemperature.value = 0.7f;
        vhsComponent.VHS1980_ContrastRange.value = new Vector2(0.0f, 1.0f);
        vhsComponent.VHS1980_ExposureRange.value = new Vector2(0.0f, 0.95f);
    }

    /// <summary>
    /// Static method to apply preset directly to a VHS component
    /// </summary>
    public static void ApplyPresetTo(VHS vhs, MoviePreset preset)
    {
        if (vhs == null) return;
        
        var presetHelper = new GameObject("TempPresetHelper").AddComponent<VHSPresets>();
        presetHelper.vhsComponent = vhs;
        presetHelper.ApplyPreset(preset);
        DestroyImmediate(presetHelper.gameObject);
    }
}

