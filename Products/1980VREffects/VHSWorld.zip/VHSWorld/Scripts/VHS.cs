using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System;

[Serializable, VolumeComponentMenu("Post-processing/VHS")]
public sealed class VHS : VolumeComponent, IPostProcessComponent
{
    [Header("General Settings")]
    [Tooltip("Controls the overall intensity of the VHS effect.")]
    public ClampedFloatParameter VHS1980_RetroIntensity = new ClampedFloatParameter(0f, 0f, 1f);

    [Header("Resolution Settings")]
    [Tooltip("Film resolution width - lower values create more authentic VHS look")]
    public ClampedIntParameter VHS1980_FilmResolutionWidth = new ClampedIntParameter(640, 20, 2048);
    
    [Tooltip("Film resolution height")]
    public ClampedIntParameter VHS1980_FilmResolutionHeight = new ClampedIntParameter(640, 640, 2048);

    [Header("Motion Blur Effects")]
    [Tooltip("Horizontal motion blur intensity - simulates VHS tape motion")]
    public ClampedFloatParameter VHS1980_MotionBlurHorizontal = new ClampedFloatParameter(0.5f, 0f, 3f);
    
    [Tooltip("Vertical motion blur intensity")]
    public ClampedFloatParameter VHS1980_MotionBlurVertical = new ClampedFloatParameter(0.5f, 0f, 3f);

    [Header("Chroma Processing")]
    [Tooltip("Chroma bleed intensity - color bleeding effect")]
    public ClampedFloatParameter VHS1980_ChromaBleed = new ClampedFloatParameter(1.7f, 0f, 5f);
    
    [Tooltip("Chroma intensity multiplier")]
    public ClampedFloatParameter VHS1980_ChromaIntensity = new ClampedFloatParameter(1f, 0f, 3.0f);
    
    [Tooltip("Chroma wobble - color channel instability")]
    public ClampedFloatParameter VHS1980_ChromaWobble = new ClampedFloatParameter(1.0f, 0f, 1f);
    
    [Tooltip("Chroma offset - color channel misalignment")]
    public ClampedFloatParameter VHS1980_ChromaOffset = new ClampedFloatParameter(0.02f, 0f, 0.1f);

    [Header("Edge Enhancement")]
    [Tooltip("Edge enhancement - sharpens image edges")]
    public ClampedFloatParameter VHS1980_EdgeEnhancement = new ClampedFloatParameter(1.2f, 0f, 5f);
    
    [Tooltip("Sharpness radius - size of edge enhancement")]
    public ClampedFloatParameter VHS1980_SharpnessRadius = new ClampedFloatParameter(1.2f, 0f, 5f);

    [Header("Film Grain")]
    [Tooltip("Film grain intensity - adds texture noise")]
    public ClampedFloatParameter VHS1980_FilmGrain = new ClampedFloatParameter(0.05f, 0f, 0.5f);

    [Header("Tape Tracking")]
    [Tooltip("Tape tracking - vertical tape movement")]
    public ClampedFloatParameter VHS1980_TapeTracking = new ClampedFloatParameter(0.2f, 0f, 5f);
    
    [Tooltip("Tracking amplitude - intensity of tape movement")]
    public ClampedFloatParameter VHS1980_TrackingAmplitude = new ClampedFloatParameter(0.02f, 0f, 0.1f);

    [Header("VHS Artifacts")]
    [Tooltip("Phosphor burn - screen burn-in effect")]
    public ClampedFloatParameter VHS1980_PhosphorBurn = new ClampedFloatParameter(0.1f, 0f, 1f);
    
    [Tooltip("Tape artifacts - dust and scratches on tape")]
    public ClampedFloatParameter VHS1980_TapeArtifacts = new ClampedFloatParameter(0.1f, 0f, 1f);
    
    [Tooltip("Horizontal wobble - screen shake effect")]
    public ClampedFloatParameter VHS1980_HorizontalWobble = new ClampedFloatParameter(1f, 0f, 2f);

    [Header("Scanline Effects")]
    [Tooltip("Scanline intensity - visibility of horizontal scan lines")]
    public ClampedFloatParameter VHS1980_ScanlineIntensity = new ClampedFloatParameter(0.5f, 0f, 1f);
    
    [Tooltip("Scanline count - number of scanlines on screen")]
    public ClampedFloatParameter VHS1980_ScanlineCount = new ClampedFloatParameter(288f, 100f, 600f);
    
    [Tooltip("Scanline speed - interlace animation speed")]
    public ClampedFloatParameter VHS1980_ScanlineSpeed = new ClampedFloatParameter(60f, 0f, 120f);
    
    [Tooltip("Tape lines - horizontal interference lines across screen (VR compatible)")]
    public ClampedFloatParameter VHS1980_TapeLines = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Tape lines count - number of horizontal lines")]
    public ClampedFloatParameter VHS1980_TapeLinesCount = new ClampedFloatParameter(8f, 1f, 50f);
    
    [Tooltip("Tape lines speed - animation speed of moving lines")]
    public ClampedFloatParameter VHS1980_TapeLinesSpeed = new ClampedFloatParameter(2f, 0f, 10f);
    
    [Tooltip("Tape lines darkness - how dark the interference lines appear")]
    public ClampedFloatParameter VHS1980_TapeLinesDarkness = new ClampedFloatParameter(0.3f, 0f, 1f);
    
    [Tooltip("Tape lines distortion - horizontal distortion amount on line areas")]
    public ClampedFloatParameter VHS1980_TapeLinesDistortion = new ClampedFloatParameter(0.5f, 0f, 1f);

    [Header("Signal Interference")]
    [Tooltip("Head switching noise - horizontal noise band at bottom of screen")]
    public ClampedFloatParameter VHS1980_HeadSwitchingNoise = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Static noise bars - random horizontal noise lines")]
    public ClampedFloatParameter VHS1980_StaticNoiseBars = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Signal dropout - momentary horizontal line loss")]
    public ClampedFloatParameter VHS1980_SignalDropout = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Rainbow banding - diagonal NTSC color interference")]
    public ClampedFloatParameter VHS1980_RainbowBanding = new ClampedFloatParameter(0f, 0f, 1f);

    [Header("CRT Display")]
    [Tooltip("VHS Ghosting - signal echo/duplicate image offset")]
    public ClampedFloatParameter VHS1980_Ghosting = new ClampedFloatParameter(0f, 0f, 0.5f);
    
    [Tooltip("CRT Vignette - darkened screen corners")]
    public ClampedFloatParameter VHS1980_Vignette = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Phosphor glow/bloom - bright areas bleeding light")]
    public ClampedFloatParameter VHS1980_PhosphorGlow = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("CRT barrel distortion - screen curvature")]
    public ClampedFloatParameter VHS1980_BarrelDistortion = new ClampedFloatParameter(0f, 0f, 0.5f);

    [Header("Tape Playback")]
    [Tooltip("Bottom roll - image rolling from bad vertical sync")]
    public ClampedFloatParameter VHS1980_BottomRoll = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Tape speed wobble - pitch/speed variation")]
    public ClampedFloatParameter VHS1980_TapeSpeedWobble = new ClampedFloatParameter(0f, 0f, 1f);
    
    [Tooltip("Pause jitter - effect when VHS is paused")]
    public ClampedFloatParameter VHS1980_PauseJitter = new ClampedFloatParameter(0f, 0f, 1f);

    [Header("Color Grading")]
    [Tooltip("Film response curve - gamma correction")]
    public ClampedFloatParameter VHS1980_FilmResponse = new ClampedFloatParameter(0f, -2f, 2f);
    
    [Tooltip("Color saturation - intensity of colors")]
    public ClampedFloatParameter VHS1980_ColorSaturation = new ClampedFloatParameter(1f, -1f, 1f);
    
    [Tooltip("Color temperature - warm/cool color shift")]
    public ClampedFloatParameter VHS1980_ColorTemperature = new ClampedFloatParameter(0f, -1f, 1f);
    
    [Tooltip("Contrast range - black and white levels")]
    public FloatRangeParameter VHS1980_ContrastRange = new FloatRangeParameter(new Vector2(0f, 1f), 0f, 1f);
    
    [Tooltip("Exposure range - dynamic range adjustment")]
    public FloatRangeParameter VHS1980_ExposureRange = new FloatRangeParameter(new Vector2(0f, 1f), 0f, 1f);




    public Material[] materials;
    public Texture2D noiseTex;
    public Texture2D emptyTexture;
    public RenderTexture rt1;
    public RenderTexture rt2;
    public RenderTexture rt3;

    Material m_Material;
    Material m_Material2;
    Material m_Material3;
    Material m_Material4;
    int oldRes;

    public bool IsActive()
    {
        // Must have VHS Intensity enabled and > 0
        if (!VHS1980_RetroIntensity.overrideState || VHS1980_RetroIntensity.value <= 0f)
            return false;
        
        // Must have at least one effect parameter enabled
        return HasAnyEffectEnabled();
    }

    private bool HasAnyEffectEnabled()
    {
        return VHS1980_ChromaBleed.overrideState ||
               VHS1980_ChromaIntensity.overrideState ||
               VHS1980_ChromaWobble.overrideState ||
               VHS1980_ChromaOffset.overrideState ||
               VHS1980_EdgeEnhancement.overrideState ||
               VHS1980_SharpnessRadius.overrideState ||
               VHS1980_FilmGrain.overrideState ||
               VHS1980_TapeTracking.overrideState ||
               VHS1980_TrackingAmplitude.overrideState ||
               VHS1980_PhosphorBurn.overrideState ||
               VHS1980_TapeArtifacts.overrideState ||
               VHS1980_HorizontalWobble.overrideState ||
               VHS1980_ScanlineIntensity.overrideState ||
               VHS1980_TapeLines.overrideState ||
               VHS1980_HeadSwitchingNoise.overrideState ||
               VHS1980_StaticNoiseBars.overrideState ||
               VHS1980_SignalDropout.overrideState ||
               VHS1980_RainbowBanding.overrideState ||
               VHS1980_Ghosting.overrideState ||
               VHS1980_Vignette.overrideState ||
               VHS1980_PhosphorGlow.overrideState ||
               VHS1980_BarrelDistortion.overrideState ||
               VHS1980_BottomRoll.overrideState ||
               VHS1980_TapeSpeedWobble.overrideState ||
               VHS1980_PauseJitter.overrideState ||
               VHS1980_FilmResponse.overrideState ||
               VHS1980_ColorSaturation.overrideState ||
               VHS1980_ColorTemperature.overrideState ||
               VHS1980_MotionBlurHorizontal.overrideState ||
               VHS1980_MotionBlurVertical.overrideState;
    }

    /// <summary>
    /// Resets all VHS effect parameters to their default values and disables all overrides
    /// </summary>
    public void ResetToDefaults()
    {
        // General - disable overrides and reset values
        VHS1980_RetroIntensity.overrideState = false;
        VHS1980_RetroIntensity.value = 0f;
        
        // Resolution
        VHS1980_FilmResolutionWidth.overrideState = false;
        VHS1980_FilmResolutionWidth.value = 640;
        VHS1980_FilmResolutionHeight.overrideState = false;
        VHS1980_FilmResolutionHeight.value = 640;
        
        // Motion Blur
        VHS1980_MotionBlurHorizontal.overrideState = false;
        VHS1980_MotionBlurHorizontal.value = 0f;
        VHS1980_MotionBlurVertical.overrideState = false;
        VHS1980_MotionBlurVertical.value = 0f;
        
        // Chroma
        VHS1980_ChromaBleed.overrideState = false;
        VHS1980_ChromaBleed.value = 0f;
        VHS1980_ChromaIntensity.overrideState = false;
        VHS1980_ChromaIntensity.value = 0f;
        VHS1980_ChromaWobble.overrideState = false;
        VHS1980_ChromaWobble.value = 0f;
        VHS1980_ChromaOffset.overrideState = false;
        VHS1980_ChromaOffset.value = 0f;
        
        // Sharpness
        VHS1980_EdgeEnhancement.overrideState = false;
        VHS1980_EdgeEnhancement.value = 0f;
        VHS1980_SharpnessRadius.overrideState = false;
        VHS1980_SharpnessRadius.value = 0f;
        
        // Film Grain
        VHS1980_FilmGrain.overrideState = false;
        VHS1980_FilmGrain.value = 0f;
        
        // Tape Tracking
        VHS1980_TapeTracking.overrideState = false;
        VHS1980_TapeTracking.value = 0f;
        VHS1980_TrackingAmplitude.overrideState = false;
        VHS1980_TrackingAmplitude.value = 0f;
        
        // Artifacts
        VHS1980_PhosphorBurn.overrideState = false;
        VHS1980_PhosphorBurn.value = 0f;
        VHS1980_TapeArtifacts.overrideState = false;
        VHS1980_TapeArtifacts.value = 0f;
        VHS1980_HorizontalWobble.overrideState = false;
        VHS1980_HorizontalWobble.value = 0f;
        
        // Scanlines
        VHS1980_ScanlineIntensity.overrideState = false;
        VHS1980_ScanlineIntensity.value = 0f;
        VHS1980_ScanlineCount.overrideState = false;
        VHS1980_ScanlineCount.value = 288f;
        VHS1980_ScanlineSpeed.overrideState = false;
        VHS1980_ScanlineSpeed.value = 0f;
        VHS1980_TapeLines.overrideState = false;
        VHS1980_TapeLines.value = 0f;
        VHS1980_TapeLinesCount.overrideState = false;
        VHS1980_TapeLinesCount.value = 8f;
        VHS1980_TapeLinesSpeed.overrideState = false;
        VHS1980_TapeLinesSpeed.value = 0f;
        VHS1980_TapeLinesDarkness.overrideState = false;
        VHS1980_TapeLinesDarkness.value = 0f;
        VHS1980_TapeLinesDistortion.overrideState = false;
        VHS1980_TapeLinesDistortion.value = 0f;
        
        // Signal Interference
        VHS1980_HeadSwitchingNoise.overrideState = false;
        VHS1980_HeadSwitchingNoise.value = 0f;
        VHS1980_StaticNoiseBars.overrideState = false;
        VHS1980_StaticNoiseBars.value = 0f;
        VHS1980_SignalDropout.overrideState = false;
        VHS1980_SignalDropout.value = 0f;
        VHS1980_RainbowBanding.overrideState = false;
        VHS1980_RainbowBanding.value = 0f;
        
        // CRT Display
        VHS1980_Ghosting.overrideState = false;
        VHS1980_Ghosting.value = 0f;
        VHS1980_Vignette.overrideState = false;
        VHS1980_Vignette.value = 0f;
        VHS1980_PhosphorGlow.overrideState = false;
        VHS1980_PhosphorGlow.value = 0f;
        VHS1980_BarrelDistortion.overrideState = false;
        VHS1980_BarrelDistortion.value = 0f;
        
        // Tape Playback
        VHS1980_BottomRoll.overrideState = false;
        VHS1980_BottomRoll.value = 0f;
        VHS1980_TapeSpeedWobble.overrideState = false;
        VHS1980_TapeSpeedWobble.value = 0f;
        VHS1980_PauseJitter.overrideState = false;
        VHS1980_PauseJitter.value = 0f;
        
        // Color Grading
        VHS1980_FilmResponse.overrideState = false;
        VHS1980_FilmResponse.value = 0f;
        VHS1980_ColorSaturation.overrideState = false;
        VHS1980_ColorSaturation.value = 0f;
        VHS1980_ColorTemperature.overrideState = false;
        VHS1980_ColorTemperature.value = 0f;
        VHS1980_ContrastRange.overrideState = false;
        VHS1980_ContrastRange.value = new Vector2(0f, 1f);
        VHS1980_ExposureRange.overrideState = false;
        VHS1980_ExposureRange.value = new Vector2(0f, 1f);
    }

    public bool Setup()
    {
        bool allShadersFound = true;
        
        if (m_Material == null)
        {
            Shader shader = Shader.Find("Hidden/VHS19080_VR_Effects/Blur");
            if (shader != null)
                m_Material = new Material(shader);
            else
            {
                Debug.LogError("VHS: Could not find shader 'Hidden/VHS19080_VR_Effects/Blur'");
                allShadersFound = false;
            }
        }
        if (m_Material2 == null)
        {
            Shader shader = Shader.Find("Hidden/VHS19080_VR_Effects/ChromaProcessing");
            if (shader != null)
                m_Material2 = new Material(shader);
            else
            {
                Debug.LogError("VHS: Could not find shader 'Hidden/VHS19080_VR_Effects/ChromaProcessing'");
                allShadersFound = false;
            }
        }
        if (m_Material3 == null)
        {
            Shader shader = Shader.Find("Hidden/VHS19080_VR_Effects/Scanlines");
            if (shader != null)
                m_Material3 = new Material(shader);
            else
            {
                Debug.LogError("VHS: Could not find shader 'Hidden/VHS19080_VR_Effects/Scanlines'");
                allShadersFound = false;
            }
        }
        if (m_Material4 == null)
        {
            Shader shader = Shader.Find("Hidden/VHS19080_VR_Effects/ColorGrading");
            if (shader != null)
                m_Material4 = new Material(shader);
            else
            {
                Debug.LogError("VHS: Could not find shader 'Hidden/VHS19080_VR_Effects/ColorGrading'");
                allShadersFound = false;
            }
        }
        if (noiseTex == null)
            noiseTex = Resources.Load<Texture2D>("Noise");
        
        // Create empty black texture for Trail placeholder
        if (emptyTexture == null)
        {
            emptyTexture = new Texture2D(1, 1);
            emptyTexture.SetPixel(0, 0, Color.black);
            emptyTexture.Apply();
        }

        if (!allShadersFound)
            return false;

        if (rt1 == null)
        {
            rt1 = new RenderTexture(VHS1980_FilmResolutionWidth.value, 480, 32, RenderTextureFormat.DefaultHDR);
            rt1.useMipMap = true;
            rt1.autoGenerateMips = true;
            rt1.anisoLevel = 32;
            rt1.filterMode = FilterMode.Trilinear;
            rt1.Create();
        }

        if (rt2 == null)
        {
            rt2 = new RenderTexture(VHS1980_FilmResolutionWidth.value, 480, 32, RenderTextureFormat.DefaultHDR);
            rt2.useMipMap = true;
            rt2.autoGenerateMips = true;
            rt2.anisoLevel = 32;
            rt2.filterMode = FilterMode.Trilinear;
            rt2.Create();
        }

        oldRes = rt1.width + rt1.height;
        
        return true;
    }

    public void Update()
    {


        if ((rt1.width + rt1.height) != oldRes)
        {
            rt1.Release();
            rt2.Release();

            rt1 = new RenderTexture(VHS1980_FilmResolutionWidth.value, 480, 32, RenderTextureFormat.DefaultHDR);
            rt1.useMipMap = true;
            rt1.autoGenerateMips = true;
            rt1.anisoLevel = 32;
            rt1.filterMode = FilterMode.Trilinear;



            rt2 = new RenderTexture(VHS1980_FilmResolutionWidth.value, 480, 32, RenderTextureFormat.DefaultHDR);
            rt2.useMipMap = true;
            rt2.autoGenerateMips = true;
            rt2.anisoLevel = 32;
            rt2.filterMode = FilterMode.Trilinear;

            oldRes = rt1.width + rt1.height;
        }
    }


    public void Render(CommandBuffer cmd, RTHandle source, RTHandle destination, Camera camera = null)
    {
        if (m_Material == null || m_Material2 == null || m_Material3 == null || 
            m_Material4 == null || rt1 == null)
        {
            Debug.LogError("VHS: Missing materials or render textures!");
            cmd.Blit(source.nameID, destination.nameID);
            return;
        }

        int newRes = VHS1980_FilmResolutionWidth.value + rt1.height;

        if ((newRes) != oldRes)
        {
            rt1.Release();
            rt2.Release();

            rt1 = new RenderTexture(VHS1980_FilmResolutionWidth.value, 480, 32, RenderTextureFormat.DefaultHDR);
            rt1.useMipMap = true;
            rt1.autoGenerateMips = true;
            rt1.anisoLevel = 32;
            rt1.filterMode = FilterMode.Trilinear;
            rt1.Create();

            rt2 = new RenderTexture(VHS1980_FilmResolutionWidth.value, 480, 32, RenderTextureFormat.DefaultHDR);
            rt2.useMipMap = true;
            rt2.autoGenerateMips = true;
            rt2.anisoLevel = 32;
            rt2.filterMode = FilterMode.Trilinear;
            rt2.Create();

            oldRes = rt1.width + rt1.height;
        }

        float intensity = VHS1980_RetroIntensity.value;
        
        m_Material.SetFloat("_1980VHS_RetroIntensity", intensity);
        m_Material2.SetFloat("_1980VHS_ChromaBleed", VHS1980_ChromaBleed.value * intensity);
        m_Material2.SetFloat("_1980VHS_EdgeEnhancement", VHS1980_EdgeEnhancement.value * intensity);
        m_Material2.SetFloat("_1980VHS_SharpnessRadius", VHS1980_SharpnessRadius.value * intensity);
        m_Material2.SetFloat("_1980VHS_FilmGrain", VHS1980_FilmGrain.value * intensity);
        m_Material2.SetFloat("_1980VHS_TapeTracking", VHS1980_TapeTracking.value * intensity);
        m_Material2.SetFloat("_1980VHS_TrackingAmplitude", VHS1980_TrackingAmplitude.value * intensity);
        m_Material2.SetFloat("_1980VHS_ChromaOffset", VHS1980_ChromaOffset.value * intensity);
        m_Material2.SetFloat("_1980VHS_ChromaIntensity", VHS1980_ChromaIntensity.value);
        m_Material2.SetFloat("_1980VHS_ChromaWobble", VHS1980_ChromaWobble.value * intensity);
        m_Material2.SetFloat("_1980VHS_PhosphorBurn", VHS1980_PhosphorBurn.value * intensity);
        m_Material2.SetFloat("_1980VHS_TapeArtifacts", 1f - VHS1980_TapeArtifacts.value * intensity);
        m_Material2.SetTexture("_TrailTex", emptyTexture);
        m_Material2.SetTexture("_NoiseTex", noiseTex);
        m_Material4.SetFloat("_1980VHS_FilmResponse", VHS1980_FilmResponse.value * intensity);
        m_Material4.SetFloat("_1980VHS_ColorSaturation", VHS1980_ColorSaturation.value * intensity);
        m_Material4.SetFloat("_1980VHS_HorizontalWobble", VHS1980_HorizontalWobble.value * intensity);
        m_Material4.SetFloat("_1980VHS_Black", VHS1980_ContrastRange.value.x * intensity);
        m_Material4.SetFloat("_1980VHS_White", 1 - ((1 - VHS1980_ContrastRange.value.y) * intensity));
        m_Material4.SetFloat("_1980VHS_DynamicRangeMin", VHS1980_ExposureRange.value.x * intensity);
        m_Material4.SetFloat("_1980VHS_DynamicRangeMax", 1 - ((1 - VHS1980_ExposureRange.value.y) * intensity));
        m_Material4.SetFloat("_1980VHS_ColorTemperature", VHS1980_ColorTemperature.value * intensity);
        m_Material.SetFloat("_1980VHS_MotionBlurHorizontal", VHS1980_MotionBlurHorizontal.value);
        m_Material.SetFloat("_1980VHS_MotionBlurVertical", VHS1980_MotionBlurVertical.value);
        
        // Scanline effects
        m_Material3.SetFloat("_1980VHS_ScanlineIntensity", VHS1980_ScanlineIntensity.value * intensity);
        m_Material3.SetFloat("_1980VHS_ScanlineCount", VHS1980_ScanlineCount.value);
        m_Material3.SetFloat("_1980VHS_ScanlineSpeed", VHS1980_ScanlineSpeed.value);
        m_Material3.SetFloat("_1980VHS_TapeLines", VHS1980_TapeLines.value * intensity);
        m_Material3.SetFloat("_1980VHS_TapeLinesCount", VHS1980_TapeLinesCount.value);
        m_Material3.SetFloat("_1980VHS_TapeLinesSpeed", VHS1980_TapeLinesSpeed.value);
        m_Material3.SetFloat("_1980VHS_TapeLinesDarkness", VHS1980_TapeLinesDarkness.value);
        m_Material3.SetFloat("_1980VHS_TapeLinesDistortion", VHS1980_TapeLinesDistortion.value);
        
        // Signal interference
        m_Material2.SetFloat("_1980VHS_HeadSwitchingNoise", VHS1980_HeadSwitchingNoise.value * intensity);
        m_Material2.SetFloat("_1980VHS_StaticNoiseBars", VHS1980_StaticNoiseBars.value * intensity);
        m_Material2.SetFloat("_1980VHS_SignalDropout", VHS1980_SignalDropout.value * intensity);
        m_Material2.SetFloat("_1980VHS_RainbowBanding", VHS1980_RainbowBanding.value * intensity);
        
        // CRT display effects
        m_Material3.SetFloat("_1980VHS_Ghosting", VHS1980_Ghosting.value * intensity);
        m_Material3.SetFloat("_1980VHS_Vignette", VHS1980_Vignette.value * intensity);
        m_Material3.SetFloat("_1980VHS_PhosphorGlow", VHS1980_PhosphorGlow.value * intensity);
        m_Material3.SetFloat("_1980VHS_BarrelDistortion", VHS1980_BarrelDistortion.value * intensity);
        
        // Tape playback effects
        m_Material4.SetFloat("_1980VHS_BottomRoll", VHS1980_BottomRoll.value * intensity);
        m_Material2.SetFloat("_1980VHS_TapeSpeedWobble", VHS1980_TapeSpeedWobble.value * intensity);
        m_Material2.SetFloat("_1980VHS_PauseJitter", VHS1980_PauseJitter.value * intensity);

        // Full effect chain - use RenderTargetIdentifier for RTHandle compatibility
        RenderTargetIdentifier sourceId = source.nameID;
        RenderTargetIdentifier destId = destination.nameID;
        
        cmd.Blit(sourceId, rt1, m_Material, 0);           // Gray blur
        cmd.Blit(rt1, rt2, m_Material2, 0);               // T shader (chroma/processing)
        cmd.Blit(rt2, rt1, m_Material4, 0);               // PostTV shader (color grading)
        cmd.Blit(rt1, destId, m_Material3, 0);            // TV shader (final scanlines)
    }

    public void Cleanup()
    {
        CoreUtils.Destroy(m_Material);
        CoreUtils.Destroy(m_Material2);
        CoreUtils.Destroy(m_Material3);
        CoreUtils.Destroy(m_Material4);
        
        if (rt1 != null) rt1.Release();
        if (rt2 != null) rt2.Release();
    }




}
