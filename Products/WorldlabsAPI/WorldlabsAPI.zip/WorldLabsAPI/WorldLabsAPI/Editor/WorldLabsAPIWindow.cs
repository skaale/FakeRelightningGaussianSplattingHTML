// SPDX-License-Identifier: MIT
// World Labs API Integration for Unity
// Generic plugin - no external dependencies required

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using Debug = UnityEngine.Debug;

namespace WorldLabsAPI.Editor
{
    public class WorldLabsAPIWindow : EditorWindow
    {
        private const string API_BASE_URL = "https://api.worldlabs.ai/marble/v1";
        private const string PREF_API_KEY = "WorldLabsAPI.ApiKey";
        
        // API Key (user must provide their own)
        private string m_ApiKey = "";
        private bool m_ShowApiKey = false;
        
        // Tab state
        private int m_CurrentTab = 0;
        private readonly string[] m_TabNames = { "Text → World", "Image → World", "Video → World", "Operations" };
        
        // Model selection
        public enum ModelType
        {
            [InspectorName("Marble 0.1-plus (Best Quality, ~5min)")] Plus = 0,
            [InspectorName("Marble 0.1-mini (Draft, ~30-45s)")] Mini = 1
        }
        private ModelType m_ModelType = ModelType.Plus;
        
        // Text to World
        private string m_TextPrompt = "";
        private string m_DisplayName = "My World";
        private int m_Seed = -1;
        
        // Image to World
        private Texture2D m_InputImage;
        private string m_ImageTextPrompt = "";
        private bool m_IsPanorama = false;
        
        // Viewport capture
        private bool m_UseViewportCapture = false;
        private int m_CaptureWidth = 1920;
        private int m_CaptureHeight = 1080;
        
        // Video to World
        private string m_VideoUrl = "";
        private string m_VideoFilePath = "";
        private string m_VideoTextPrompt = "";
        private bool m_UseVideoUrl = false; // false = local file (default), true = public URL
        
        // Upload context tracking (image vs video)
        private bool m_IsVideoUpload = false;
        
        // Background upload state (GCS uploads use System.Net instead of UnityWebRequest)
        private volatile bool m_BgUploadComplete = false;
        private volatile bool m_BgUploadFailed = false;
        private volatile string m_BgUploadError = "";
        private volatile string m_BgUploadErrorDetails = "";
        
        // Operation tracking
        private string m_CurrentOperationId = "";
        private string m_CurrentWorldId = "";
        private float m_OperationProgress = 0f;
        private string m_OperationStatus = "";
        private bool m_IsPolling = false;
        private double m_LastPollTime = 0;
        private const float POLL_INTERVAL = 5f;
        private int m_PollErrorCount = 0;
        private const int MAX_POLL_ERRORS_BEFORE_WARNING = 5;
        
        // Retry state for FetchWorldDetails (if it fails, we retry on next update)
        private bool m_NeedsFetchWorldDetails = false;
        private int m_FetchWorldRetries = 0;
        private const int MAX_FETCH_WORLD_RETRIES = 10;
        
        // Generation history
        private List<WorldOperation> m_Operations = new List<WorldOperation>();
        
        // Request state
        private UnityWebRequest m_CurrentRequest;
        private bool m_IsProcessing = false;
        private string m_StatusMessage = "";
        private MessageType m_StatusType = MessageType.None;
        
        // Scroll position
        private Vector2 m_ScrollPosition;
        private Vector2 m_DebugScrollPosition;
        
        // Debug log
        private bool m_ShowDebugLog = false;
        private List<DebugLogEntry> m_DebugLog = new List<DebugLogEntry>();
        private const int MAX_DEBUG_ENTRIES = 50;
        
        [Serializable]
        private class DebugLogEntry
        {
            public DateTime timestamp;
            public string type; // REQUEST, RESPONSE, ERROR, INFO
            public string message;
            public string details;
        }
        
        // Rate limits info
        private const int RATE_LIMIT_PER_MINUTE = 10;
        private const string GENERATION_TIME_ESTIMATE = "~5 minutes";
        
        // Colors
        private static readonly Color COL_ACCENT = new Color(0.18f, 0.52f, 0.89f);
        private static readonly Color COL_SUCCESS = new Color(0.35f, 0.75f, 0.45f);
        private static readonly Color COL_WARNING = new Color(0.95f, 0.65f, 0.25f);
        private static readonly Color COL_DANGER = new Color(0.85f, 0.35f, 0.35f);
        
        // Output quality selection (World Labs API provides SPZ format only, not PLY)
        public enum OutputQuality 
        { 
            [InspectorName("Full Resolution (~70-100MB)")] FullRes = 0, 
            [InspectorName("500k Splats (~20-50MB)")] Quality500k = 1, 
            [InspectorName("100k Splats (~5-10MB)")] Quality100k = 2 
        }
        private OutputQuality m_OutputQuality = OutputQuality.FullRes;
        
        // Auto-import settings
        private bool m_AutoImportToScene = true;
        private string m_OutputFolder = "Assets/WorldLabsAssets";
        
        [Serializable]
        private class WorldOperation
        {
            public string operationId;
            public string worldId;
            public string displayName;
            public string status;
            public DateTime startTime;
            public bool done;
            public string spzUrlFullRes;
            public string spzUrl500k;
            public string spzUrl100k;
            public string colliderMeshUrl;
            public string panoUrl;
            public string thumbnailUrl;
            public string caption;
        }
        
        [MenuItem("Window/World Labs API", false, 110)]
        public static void ShowWindow()
        {
            var window = GetWindow<WorldLabsAPIWindow>();
            window.titleContent = new GUIContent("World Labs", EditorGUIUtility.IconContent("d_SceneViewOrtho").image);
            window.minSize = new Vector2(400, 500);
            window.Show();
        }
        
        private void OnEnable()
        {
            string savedKey = EditorPrefs.GetString(PREF_API_KEY, "");
            if (!string.IsNullOrEmpty(savedKey))
                m_ApiKey = savedKey;
            EditorApplication.update += OnEditorUpdate;
        }
        
        private void OnDisable()
        {
            EditorApplication.update -= OnEditorUpdate;
            CleanupRequest();
        }
        
        private void CleanupRequest()
        {
            if (m_CurrentRequest != null)
            {
                m_CurrentRequest.Dispose();
                m_CurrentRequest = null;
            }
        }
        
        private void ResetAllState()
        {
            // Stop everything
            CleanupRequest();
            m_IsPolling = false;
            m_IsProcessing = false;
            m_IsVideoUpload = false;
            
            // Clear operation tracking
            m_CurrentOperationId = "";
            m_CurrentWorldId = "";
            m_OperationProgress = 0f;
            m_OperationStatus = "";
            m_PollErrorCount = 0;
            m_NeedsFetchWorldDetails = false;
            m_FetchWorldRetries = 0;
            
            // Clear background upload state
            m_BgUploadComplete = false;
            m_BgUploadFailed = false;
            m_BgUploadError = "";
            m_BgUploadErrorDetails = "";
            
            // Clear history
            m_Operations.Clear();
            
            // Clear status and debug log
            m_StatusMessage = "";
            m_StatusType = MessageType.None;
            m_DebugLog.Clear();
            
            // Switch to Video tab so user can start fresh
            m_CurrentTab = 2;
            
            AddDebugLog("INFO", "All state reset. Ready for new generation.");
            Repaint();
        }
        
        private void OnEditorUpdate()
        {
            if (m_CurrentRequest != null && m_CurrentRequest.isDone)
            {
                HandleRequestComplete();
            }
            
            // Check for background GCS upload completion
            if (m_BgUploadComplete)
            {
                m_BgUploadComplete = false;
                AddDebugLog("RESPONSE", "GCS upload complete (200 OK via System.Net)");
                HandleMediaUploadComplete();
                Repaint();
            }
            else if (m_BgUploadFailed)
            {
                m_BgUploadFailed = false;
                m_IsProcessing = false;
                m_IsVideoUpload = false;
                AddDebugLog("ERROR", $"GCS upload failed: {m_BgUploadError}", m_BgUploadErrorDetails);
                SetStatus($"Upload failed: {m_BgUploadError}", MessageType.Error);
                m_ShowDebugLog = true;
                Repaint();
            }
            
            // Poll for operation status
            if (m_IsPolling && !string.IsNullOrEmpty(m_CurrentOperationId))
            {
                if (EditorApplication.timeSinceStartup - m_LastPollTime > POLL_INTERVAL)
                {
                    m_LastPollTime = EditorApplication.timeSinceStartup;
                    PollOperationStatus();
                }
            }
            
            // Retry FetchWorldDetails if it previously failed
            if (m_NeedsFetchWorldDetails && m_CurrentRequest == null && !string.IsNullOrEmpty(m_CurrentWorldId))
            {
                if (EditorApplication.timeSinceStartup - m_LastPollTime > POLL_INTERVAL)
                {
                    m_LastPollTime = EditorApplication.timeSinceStartup;
                    m_FetchWorldRetries++;
                    if (m_FetchWorldRetries <= MAX_FETCH_WORLD_RETRIES)
                    {
                        AddDebugLog("INFO", $"Retrying FetchWorldDetails (attempt {m_FetchWorldRetries}/{MAX_FETCH_WORLD_RETRIES})...");
                        FetchWorldDetails(m_CurrentWorldId);
                    }
                    else
                    {
                        m_NeedsFetchWorldDetails = false;
                        AddDebugLog("ERROR", "Exhausted retries for FetchWorldDetails. Use Refresh Status to retry manually.");
                        SetStatus("Failed to fetch world details after multiple retries. Click 'Refresh Status' to try again.", MessageType.Warning);
                    }
                }
            }
        }
        
        private void OnGUI()
        {
            m_ScrollPosition = EditorGUILayout.BeginScrollView(m_ScrollPosition);
            
            DrawHeader();
            EditorGUILayout.Space(8);
            DrawApiKeySection();
            EditorGUILayout.Space(8);
            DrawRateLimitsInfo();
            EditorGUILayout.Space(8);
            DrawTabs();
            EditorGUILayout.Space(8);
            DrawTabContent();
            EditorGUILayout.Space(8);
            DrawStatusSection();
            EditorGUILayout.Space(8);
            DrawDebugSection();
            
            EditorGUILayout.EndScrollView();
        }
        
        private void DrawHeader()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            GUILayout.Label("WORLD LABS API", EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            
            if (m_IsProcessing)
            {
                GUI.color = COL_WARNING;
                GUILayout.Label("⏳ Processing...");
                GUI.color = Color.white;
            }
            
            EditorGUILayout.EndHorizontal();
        }
        
        private void DrawApiKeySection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("API Configuration", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            if (m_ShowApiKey)
                m_ApiKey = EditorGUILayout.TextField("API Key", m_ApiKey);
            else
                m_ApiKey = EditorGUILayout.PasswordField("API Key", m_ApiKey);
            
            if (GUILayout.Button(m_ShowApiKey ? "Hide" : "Show", GUILayout.Width(50)))
                m_ShowApiKey = !m_ShowApiKey;
            EditorGUILayout.EndHorizontal();
            
            if (GUILayout.Button("Save API Key"))
            {
                EditorPrefs.SetString(PREF_API_KEY, m_ApiKey);
                SetStatus("API Key saved", MessageType.Info);
            }
            
            if (string.IsNullOrEmpty(m_ApiKey))
            {
                EditorGUILayout.HelpBox("Enter your World Labs API key to use the service.", MessageType.Warning);
            }
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawRateLimitsInfo()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Rate Limits & Time Estimates", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            GUI.color = COL_ACCENT;
            EditorGUILayout.LabelField("⏱️ Generation Time:", GUILayout.Width(130));
            GUI.color = Color.white;
            EditorGUILayout.LabelField(GENERATION_TIME_ESTIMATE);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            GUI.color = COL_WARNING;
            EditorGUILayout.LabelField("📊 Rate Limit:", GUILayout.Width(130));
            GUI.color = Color.white;
            EditorGUILayout.LabelField($"{RATE_LIMIT_PER_MINUTE} requests/minute");
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            GUI.color = COL_SUCCESS;
            EditorGUILayout.LabelField("💾 Output Format:", GUILayout.Width(130));
            GUI.color = Color.white;
            EditorGUILayout.LabelField("SPZ (Scaniverse format)");
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            GUI.color = new Color(0.7f, 0.5f, 0.9f);
            EditorGUILayout.LabelField("📐 Quality Options:", GUILayout.Width(130));
            GUI.color = Color.white;
            EditorGUILayout.LabelField("Full (~130MB), 500k, 100k");
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            GUI.color = COL_ACCENT;
            EditorGUILayout.LabelField("🔷 Extras:", GUILayout.Width(130));
            GUI.color = Color.white;
            EditorGUILayout.LabelField("Collider mesh (GLB), Panorama");
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawTabs()
        {
            m_CurrentTab = GUILayout.Toolbar(m_CurrentTab, m_TabNames);
        }
        
        private void DrawTabContent()
        {
            switch (m_CurrentTab)
            {
                case 0:
                    DrawTextToWorldTab();
                    break;
                case 1:
                    DrawImageToWorldTab();
                    break;
                case 2:
                    DrawVideoToWorldTab();
                    break;
                case 3:
                    DrawOperationsTab();
                    break;
            }
        }
        
        private void DrawTextToWorldTab()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("🔤 Text to World", EditorStyles.boldLabel);
            EditorGUILayout.Space(4);
            
            m_DisplayName = EditorGUILayout.TextField("Display Name", m_DisplayName);
            
            EditorGUILayout.LabelField("Text Prompt:");
            m_TextPrompt = EditorGUILayout.TextArea(m_TextPrompt, GUILayout.Height(80));
            
            // Model selection
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Model:", GUILayout.Width(60));
            m_ModelType = (ModelType)EditorGUILayout.EnumPopup(m_ModelType);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Seed (-1 = random):", GUILayout.Width(120));
            m_Seed = EditorGUILayout.IntField(m_Seed);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(8);
            
            GUI.enabled = !m_IsProcessing && !string.IsNullOrEmpty(m_ApiKey) && !string.IsNullOrEmpty(m_TextPrompt);
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("🚀 Generate World from Text", GUILayout.Height(35)))
            {
                GenerateWorldFromText();
            }
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawImageToWorldTab()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("🖼️ Image to World", EditorStyles.boldLabel);
            EditorGUILayout.Space(4);
            
            m_DisplayName = EditorGUILayout.TextField("Display Name", m_DisplayName);
            
            // Viewport capture toggle
            m_UseViewportCapture = EditorGUILayout.Toggle("Use Viewport Capture", m_UseViewportCapture);
            
            if (m_UseViewportCapture)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.LabelField("📷 Viewport Capture (16:9)", EditorStyles.boldLabel);
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("1920x1080"))
                {
                    m_CaptureWidth = 1920;
                    m_CaptureHeight = 1080;
                }
                if (GUILayout.Button("1280x720"))
                {
                    m_CaptureWidth = 1280;
                    m_CaptureHeight = 720;
                }
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.LabelField($"Resolution: {m_CaptureWidth}x{m_CaptureHeight}");
                
                GUI.backgroundColor = COL_ACCENT;
                if (GUILayout.Button("📸 Capture Viewport", GUILayout.Height(30)))
                {
                    CaptureViewport();
                }
                GUI.backgroundColor = Color.white;
                
                EditorGUILayout.EndVertical();
            }
            else
            {
                // Asset picker
                m_InputImage = (Texture2D)EditorGUILayout.ObjectField("Input Image", m_InputImage, typeof(Texture2D), false);
                
                // File browser button
                EditorGUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("📂 Browse File...", GUILayout.Width(120)))
                {
                    LoadImageFromFile();
                }
                if (m_InputImage != null && GUILayout.Button("✕", GUILayout.Width(25)))
                {
                    m_InputImage = null;
                }
                EditorGUILayout.EndHorizontal();
            }
            
            // Preview captured/selected image
            if (m_InputImage != null)
            {
                EditorGUILayout.Space(4);
                var rect = GUILayoutUtility.GetRect(200, 112.5f);
                GUI.DrawTexture(rect, m_InputImage, ScaleMode.ScaleToFit);
            }
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Text Prompt (optional):");
            m_ImageTextPrompt = EditorGUILayout.TextArea(m_ImageTextPrompt, GUILayout.Height(60));
            
            m_IsPanorama = EditorGUILayout.Toggle("Is Panorama", m_IsPanorama);
            
            // Model selection
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Model:", GUILayout.Width(60));
            m_ModelType = (ModelType)EditorGUILayout.EnumPopup(m_ModelType);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(8);
            
            GUI.enabled = !m_IsProcessing && !string.IsNullOrEmpty(m_ApiKey) && m_InputImage != null;
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("🚀 Generate World from Image", GUILayout.Height(35)))
            {
                GenerateWorldFromImage();
            }
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawVideoToWorldTab()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("🎬 Video to World", EditorStyles.boldLabel);
            EditorGUILayout.Space(4);
            
            m_DisplayName = EditorGUILayout.TextField("Display Name", m_DisplayName);
            
            // Source toggle: local file or URL
            EditorGUILayout.Space(4);
            m_UseVideoUrl = EditorGUILayout.Toggle("Use Public URL", m_UseVideoUrl);
            
            if (m_UseVideoUrl)
            {
                EditorGUILayout.LabelField("Video URL (public URL to mp4/mov/mkv):");
                m_VideoUrl = EditorGUILayout.TextField(m_VideoUrl);
            }
            else
            {
                // Local file browser
                EditorGUILayout.BeginHorizontal();
                string displayPath = string.IsNullOrEmpty(m_VideoFilePath) ? "(no file selected)" : Path.GetFileName(m_VideoFilePath);
                EditorGUILayout.LabelField("Video File:", GUILayout.Width(70));
                EditorGUILayout.LabelField(displayPath, EditorStyles.wordWrappedLabel);
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("📂 Browse Video...", GUILayout.Width(140)))
                {
                    string path = EditorUtility.OpenFilePanel("Select Video", "", "mp4,mov,mkv");
                    if (!string.IsNullOrEmpty(path))
                    {
                        m_VideoFilePath = path;
                    }
                }
                if (!string.IsNullOrEmpty(m_VideoFilePath) && GUILayout.Button("✕", GUILayout.Width(25)))
                {
                    m_VideoFilePath = "";
                }
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Text Prompt (optional):");
            m_VideoTextPrompt = EditorGUILayout.TextArea(m_VideoTextPrompt, GUILayout.Height(60));
            
            // Model selection
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Model:", GUILayout.Width(60));
            m_ModelType = (ModelType)EditorGUILayout.EnumPopup(m_ModelType);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Seed (-1 = random):", GUILayout.Width(120));
            m_Seed = EditorGUILayout.IntField(m_Seed);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(8);
            
            if (m_UseVideoUrl)
                EditorGUILayout.HelpBox("Provide a public URL to your video file. Supported formats: mp4, mov, mkv", MessageType.Info);
            else
                EditorGUILayout.HelpBox("Select a local video file. It will be uploaded to World Labs before generation. Supported formats: mp4, mov, mkv", MessageType.Info);
            
            bool hasVideoSource = m_UseVideoUrl ? !string.IsNullOrEmpty(m_VideoUrl) : !string.IsNullOrEmpty(m_VideoFilePath);
            GUI.enabled = !m_IsProcessing && !string.IsNullOrEmpty(m_ApiKey) && hasVideoSource;
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("🚀 Generate World from Video", GUILayout.Height(35)))
            {
                GenerateWorldFromVideo();
            }
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawOperationsTab()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("📋 Active Operations", EditorStyles.boldLabel);
            
            // Current operation status
            if (!string.IsNullOrEmpty(m_CurrentOperationId))
            {
                EditorGUILayout.Space(4);
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                
                EditorGUILayout.LabelField($"Operation: {m_CurrentOperationId.Substring(0, Mathf.Min(8, m_CurrentOperationId.Length))}...");
                EditorGUILayout.LabelField($"Status: {m_OperationStatus}");
                
                if (m_IsPolling)
                {
                    EditorGUI.ProgressBar(EditorGUILayout.GetControlRect(GUILayout.Height(20)), m_OperationProgress, $"{m_OperationProgress * 100:F0}%");
                }
                
                if (!string.IsNullOrEmpty(m_CurrentWorldId))
                {
                    EditorGUILayout.LabelField($"World ID: {m_CurrentWorldId}");
                }
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("🔄 Refresh Status"))
                {
                    PollOperationStatus();
                }
                if (GUILayout.Button("❌ Stop Polling"))
                {
                    m_IsPolling = false;
                }
                EditorGUILayout.EndHorizontal();
                
                // Reset button
                GUI.backgroundColor = COL_DANGER;
                if (GUILayout.Button("🗑️ Reset All & Start Fresh", GUILayout.Height(25)))
                {
                    ResetAllState();
                }
                GUI.backgroundColor = Color.white;
                
                EditorGUILayout.EndVertical();
            }
            else
            {
                EditorGUILayout.HelpBox("No active operations. Generate a world to see progress here.", MessageType.Info);
            }
            
            // Operation history
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("History", EditorStyles.boldLabel);
            
            // Quality selection
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Download Quality:", GUILayout.Width(110));
            m_OutputQuality = (OutputQuality)EditorGUILayout.EnumPopup(m_OutputQuality);
            EditorGUILayout.EndHorizontal();
            
            // Auto-import settings
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            m_AutoImportToScene = EditorGUILayout.Toggle("Auto-Import to Scene", m_AutoImportToScene);
            
            if (m_AutoImportToScene)
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Output Folder:", GUILayout.Width(90));
                m_OutputFolder = EditorGUILayout.TextField(m_OutputFolder);
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.HelpBox("Downloads SPZ to folder. Use your preferred Gaussian Splatting plugin to import.", MessageType.Info);
            }
            EditorGUILayout.EndVertical();
            
            EditorGUILayout.Space(4);
            
            if (m_Operations.Count == 0)
            {
                EditorGUILayout.LabelField("No previous operations");
            }
            else
            {
                foreach (var op in m_Operations)
                {
                    EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                    
                    EditorGUILayout.BeginHorizontal();
                    GUI.color = op.done ? COL_SUCCESS : COL_WARNING;
                    EditorGUILayout.LabelField(op.done ? "✓" : "⏳", GUILayout.Width(20));
                    GUI.color = Color.white;
                    
                    EditorGUILayout.LabelField(op.displayName, EditorStyles.boldLabel);
                    EditorGUILayout.LabelField(op.status, GUILayout.Width(100));
                    EditorGUILayout.EndHorizontal();
                    
                    if (op.done)
                    {
                        EditorGUILayout.BeginHorizontal();
                        
                        // SPZ download/import button
                        string selectedUrl = GetSelectedSpzUrl(op);
                        GUI.enabled = !string.IsNullOrEmpty(selectedUrl);
                        
                        string buttonLabel = m_AutoImportToScene ? $"🚀 Import ({m_OutputQuality})" : $"📦 SPZ ({m_OutputQuality})";
                        if (GUILayout.Button(buttonLabel, GUILayout.Height(25)))
                        {
                            if (m_AutoImportToScene)
                                DownloadAndImportToScene(op, selectedUrl);
                            else
                                DownloadAsset(op, selectedUrl, "spz", $"{op.displayName}.spz");
                        }
                        GUI.enabled = true;
                        
                        // Collider mesh download
                        GUI.enabled = !string.IsNullOrEmpty(op.colliderMeshUrl);
                        if (GUILayout.Button("🔷 Collider GLB", GUILayout.Height(25)))
                        {
                            DownloadAsset(op, op.colliderMeshUrl, "glb", $"{op.displayName}_collider.glb");
                        }
                        GUI.enabled = true;
                        
                        EditorGUILayout.EndHorizontal();
                        
                        // Show available qualities
                        EditorGUILayout.BeginHorizontal();
                        GUI.color = new Color(0.7f, 0.7f, 0.7f);
                        string available = "Available: ";
                        if (!string.IsNullOrEmpty(op.spzUrlFullRes)) available += "Full ";
                        if (!string.IsNullOrEmpty(op.spzUrl500k)) available += "500k ";
                        if (!string.IsNullOrEmpty(op.spzUrl100k)) available += "100k ";
                        EditorGUILayout.LabelField(available, EditorStyles.miniLabel);
                        GUI.color = Color.white;
                        EditorGUILayout.EndHorizontal();
                    }
                    
                    EditorGUILayout.EndVertical();
                }
            }
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawStatusSection()
        {
            if (!string.IsNullOrEmpty(m_StatusMessage))
            {
                EditorGUILayout.HelpBox(m_StatusMessage, m_StatusType);
            }
        }
        
        private void DrawDebugSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            EditorGUILayout.BeginHorizontal();
            m_ShowDebugLog = EditorGUILayout.Foldout(m_ShowDebugLog, $"🔍 Debug Log ({m_DebugLog.Count} entries)", true);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Clear", GUILayout.Width(50)))
            {
                m_DebugLog.Clear();
                m_StatusMessage = "";
                m_StatusType = MessageType.None;
            }
            EditorGUILayout.EndHorizontal();
            
            if (m_ShowDebugLog && m_DebugLog.Count > 0)
            {
                m_DebugScrollPosition = EditorGUILayout.BeginScrollView(m_DebugScrollPosition, GUILayout.Height(200));
                
                for (int i = m_DebugLog.Count - 1; i >= 0; i--)
                {
                    var entry = m_DebugLog[i];
                    
                    // Color based on type
                    switch (entry.type)
                    {
                        case "ERROR": GUI.color = COL_DANGER; break;
                        case "REQUEST": GUI.color = COL_ACCENT; break;
                        case "RESPONSE": GUI.color = COL_SUCCESS; break;
                        default: GUI.color = Color.white; break;
                    }
                    
                    EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                    EditorGUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField($"[{entry.timestamp:HH:mm:ss}] {entry.type}", EditorStyles.boldLabel, GUILayout.Width(150));
                    EditorGUILayout.LabelField(entry.message, EditorStyles.wordWrappedLabel);
                    EditorGUILayout.EndHorizontal();
                    
                    if (!string.IsNullOrEmpty(entry.details))
                    {
                        GUI.color = new Color(0.7f, 0.7f, 0.7f);
                        string truncatedDetails = entry.details.Length > 500 ? entry.details.Substring(0, 500) + "..." : entry.details;
                        EditorGUILayout.LabelField(truncatedDetails, EditorStyles.wordWrappedMiniLabel);
                    }
                    
                    EditorGUILayout.EndVertical();
                    GUI.color = Color.white;
                }
                
                EditorGUILayout.EndScrollView();
            }
            
            EditorGUILayout.EndVertical();
        }
        
        private void AddDebugLog(string type, string message, string details = "")
        {
            m_DebugLog.Add(new DebugLogEntry
            {
                timestamp = DateTime.Now,
                type = type,
                message = message,
                details = details
            });
            
            // Keep log size manageable
            while (m_DebugLog.Count > MAX_DEBUG_ENTRIES)
            {
                m_DebugLog.RemoveAt(0);
            }
            
            Repaint();
        }
        
        private void SetStatus(string message, MessageType type)
        {
            m_StatusMessage = message;
            m_StatusType = type;
            Repaint();
        }
        
        private void LoadImageFromFile()
        {
            string path = EditorUtility.OpenFilePanel("Select Image", "", "png,jpg,jpeg,webp");
            if (string.IsNullOrEmpty(path)) return;
            
            try
            {
                byte[] fileData = File.ReadAllBytes(path);
                Texture2D tex = new Texture2D(2, 2);
                if (tex.LoadImage(fileData))
                {
                    m_InputImage = tex;
                    SetStatus($"Loaded image: {Path.GetFileName(path)} ({tex.width}x{tex.height})", MessageType.Info);
                }
                else
                {
                    SetStatus("Failed to load image file", MessageType.Error);
                }
            }
            catch (System.Exception ex)
            {
                SetStatus($"Error loading image: {ex.Message}", MessageType.Error);
            }
        }
        
        private void CaptureViewport()
        {
            SceneView sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null)
            {
                SetStatus("No active Scene View found", MessageType.Error);
                return;
            }
            
            // Calculate 16:9 aspect capture
            int width = m_CaptureWidth;
            int height = m_CaptureHeight;
            
            // Create render texture
            RenderTexture rt = new RenderTexture(width, height, 24);
            RenderTexture prev = sceneView.camera.targetTexture;
            
            sceneView.camera.targetTexture = rt;
            sceneView.camera.Render();
            
            // Read pixels
            RenderTexture.active = rt;
            m_InputImage = new Texture2D(width, height, TextureFormat.RGB24, false);
            m_InputImage.ReadPixels(new Rect(0, 0, width, height), 0, 0);
            m_InputImage.Apply();
            
            // Cleanup
            sceneView.camera.targetTexture = prev;
            RenderTexture.active = null;
            DestroyImmediate(rt);
            
            SetStatus($"Captured viewport at {width}x{height}", MessageType.Info);
            Repaint();
        }
        
        private void GenerateWorldFromText()
        {
            if (string.IsNullOrEmpty(m_ApiKey))
            {
                SetStatus("API Key is required", MessageType.Error);
                return;
            }
            
            m_IsProcessing = true;
            SetStatus("Starting world generation...", MessageType.Info);
            
            string jsonBody = BuildTextPromptJson();
            StartGenerateRequest(jsonBody);
        }
        
        private void GenerateWorldFromImage()
        {
            if (string.IsNullOrEmpty(m_ApiKey))
            {
                SetStatus("API Key is required", MessageType.Error);
                return;
            }
            
            if (m_InputImage == null)
            {
                SetStatus("Input image is required", MessageType.Error);
                return;
            }
            
            m_IsProcessing = true;
            m_IsVideoUpload = false;
            SetStatus("Uploading image and starting world generation...", MessageType.Info);
            
            // First upload the image as media asset
            PrepareMediaAssetUpload("viewport_capture.jpg", "image", "jpg");
        }
        
        private string GetModelString()
        {
            return m_ModelType == ModelType.Mini ? "Marble 0.1-mini" : "Marble 0.1-plus";
        }
        
        private string BuildTextPromptJson()
        {
            var sb = new StringBuilder();
            sb.Append("{");
            sb.Append($"\"display_name\":\"{EscapeJson(m_DisplayName)}\",");
            sb.Append($"\"model\":\"{GetModelString()}\",");
            sb.Append("\"world_prompt\":{");
            sb.Append("\"type\":\"text\",");
            sb.Append($"\"text_prompt\":\"{EscapeJson(m_TextPrompt)}\"");
            sb.Append("}");
            
            if (m_Seed >= 0)
            {
                sb.Append($",\"seed\":{m_Seed}");
            }
            
            sb.Append("}");
            return sb.ToString();
        }
        
        private string EscapeJson(string str)
        {
            if (string.IsNullOrEmpty(str)) return "";
            return str.Replace("\\", "\\\\")
                      .Replace("\"", "\\\"")
                      .Replace("\n", "\\n")
                      .Replace("\r", "\\r")
                      .Replace("\t", "\\t");
        }
        
        private void StartGenerateRequest(string jsonBody)
        {
            string url = $"{API_BASE_URL}/worlds:generate";
            
            AddDebugLog("REQUEST", $"POST {url}", jsonBody);
            
            m_CurrentRequest = new UnityWebRequest(url, "POST");
            byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonBody);
            m_CurrentRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
            m_CurrentRequest.downloadHandler = new DownloadHandlerBuffer();
            m_CurrentRequest.SetRequestHeader("Content-Type", "application/json");
            m_CurrentRequest.SetRequestHeader("WLT-Api-Key", m_ApiKey);
            
            m_CurrentRequest.SendWebRequest();
        }
        
        private void PrepareMediaAssetUpload(string fileName, string kind, string extension)
        {
            string url = $"{API_BASE_URL}/media-assets:prepare_upload";
            
            string jsonBody = $"{{\"file_name\":\"{EscapeJson(fileName)}\",\"kind\":\"{kind}\",\"extension\":\"{extension}\"}}";
            
            AddDebugLog("REQUEST", $"POST {url}", jsonBody);
            
            m_CurrentRequest = new UnityWebRequest(url, "POST");
            byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonBody);
            m_CurrentRequest.uploadHandler = new UploadHandlerRaw(bodyRaw);
            m_CurrentRequest.downloadHandler = new DownloadHandlerBuffer();
            m_CurrentRequest.SetRequestHeader("Content-Type", "application/json");
            m_CurrentRequest.SetRequestHeader("WLT-Api-Key", m_ApiKey);
            
            m_CurrentRequest.SendWebRequest();
        }
        
        private void HandleRequestComplete()
        {
            if (m_CurrentRequest == null) return;
            
            string responseText = m_CurrentRequest.downloadHandler.text;
            bool isError = m_CurrentRequest.result != UnityWebRequest.Result.Success;
            string requestUrl = m_CurrentRequest.url;
            long responseCode = m_CurrentRequest.responseCode;
            string errorMsg = m_CurrentRequest.error;
            
            CleanupRequest();
            
            if (isError)
            {
                string endpoint = GetEndpointName(requestUrl);
                
                // Polling errors during active generation should be silent - just log and retry
                bool isPollingError = m_IsPolling && (requestUrl.Contains("operations/") || requestUrl.Contains("worlds/"));
                bool isFetchWorldError = m_NeedsFetchWorldDetails && requestUrl.Contains("worlds/");
                
                if (isPollingError || isFetchWorldError)
                {
                    m_PollErrorCount++;
                    AddDebugLog("ERROR", $"HTTP {responseCode}: {errorMsg} (poll error #{m_PollErrorCount})", $"Endpoint: {endpoint}\nURL: {requestUrl}");
                    
                    // If world details fetch failed, flag for retry
                    if (requestUrl.Contains("worlds/") && !requestUrl.Contains("generate"))
                    {
                        m_NeedsFetchWorldDetails = true;
                    }
                    
                    // Only show warning to user after several consecutive failures
                    if (m_PollErrorCount >= MAX_POLL_ERRORS_BEFORE_WARNING)
                    {
                        SetStatus($"Network issues ({m_PollErrorCount} poll errors). Still retrying...\nLast error: {errorMsg}", MessageType.Warning);
                    }
                    // Don't return here for polling errors - Repaint will still be called at end
                    Repaint();
                    return;
                }
                
                // Non-polling errors are treated as actual failures
                m_IsProcessing = false;
                m_IsVideoUpload = false;
                AddDebugLog("ERROR", $"HTTP {responseCode}: {errorMsg}", $"Endpoint: {endpoint}\nURL: {requestUrl}\nResponse: {responseText}");
                SetStatus($"Request failed: {errorMsg}\nHTTP {responseCode}\nEndpoint: {endpoint}", MessageType.Error);
                m_ShowDebugLog = true; // Auto-expand debug log on error
                return;
            }
            
            // Reset poll error counter on success
            m_PollErrorCount = 0;
            
            AddDebugLog("RESPONSE", $"HTTP {responseCode} from {GetEndpointName(requestUrl)}", responseText);
            
            // Parse response based on endpoint
            if (requestUrl.Contains("media-assets:prepare_upload"))
            {
                HandlePrepareUploadResponse(responseText);
            }
            else if (requestUrl.Contains("worlds:generate"))
            {
                HandleGenerateResponse(responseText);
            }
            else if (requestUrl.Contains("operations/"))
            {
                HandleOperationResponse(responseText);
            }
            else if (requestUrl.Contains("worlds/"))
            {
                HandleWorldResponse(responseText);
            }
            else if (requestUrl.Contains("storage"))
            {
                HandleMediaUploadComplete();
            }
            
            Repaint();
        }
        
        private string GetEndpointName(string url)
        {
            if (url.Contains("worlds:generate")) return "worlds:generate";
            if (url.Contains("media-assets:prepare_upload")) return "media-assets:prepare_upload";
            if (url.Contains("operations/")) return "operations";
            if (url.Contains("worlds/")) return "worlds";
            if (url.Contains("storage")) return "storage upload";
            return url;
        }
        
        private void HandlePrepareUploadResponse(string json)
        {
            // Parse media_asset ID and upload_info.upload_url
            // API docs show: {"media_asset":{"id":"..."},"upload_info":{"upload_url":"..."}}
            string mediaAssetId = ExtractNestedJsonValue(json, "media_asset", "id");
            if (string.IsNullOrEmpty(mediaAssetId))
                mediaAssetId = ExtractNestedJsonValue(json, "media_asset", "media_asset_id");
            string uploadUrl = ExtractNestedJsonValue(json, "upload_info", "upload_url");
            
            if (string.IsNullOrEmpty(uploadUrl))
            {
                m_IsProcessing = false;
                AddDebugLog("ERROR", "Failed to get upload URL from prepare_upload response", json);
                SetStatus("Failed to get upload URL", MessageType.Error);
                return;
            }
            
            if (string.IsNullOrEmpty(mediaAssetId))
            {
                m_IsProcessing = false;
                AddDebugLog("ERROR", "Failed to get media asset ID from prepare_upload response", json);
                SetStatus("Failed to get media asset ID", MessageType.Error);
                return;
            }
            
            AddDebugLog("INFO", $"Got media asset ID: {mediaAssetId}");
            
            // Store media asset ID for later
            EditorPrefs.SetString("WorldLabs.LastMediaAssetId", mediaAssetId);
            
            // Extract required headers
            var requiredHeaders = ExtractRequiredHeaders(json);
            
            // Upload the media file (image or video)
            UploadMediaToSignedUrl(uploadUrl, requiredHeaders);
        }
        
        private Dictionary<string, string> ExtractRequiredHeaders(string json)
        {
            var headers = new Dictionary<string, string>();
            
            // Find required_headers object
            int idx = json.IndexOf("\"required_headers\"");
            if (idx < 0) return headers;
            
            int braceStart = json.IndexOf('{', idx);
            if (braceStart < 0) return headers;
            
            int depth = 1;
            int braceEnd = braceStart + 1;
            while (braceEnd < json.Length && depth > 0)
            {
                if (json[braceEnd] == '{') depth++;
                else if (json[braceEnd] == '}') depth--;
                braceEnd++;
            }
            
            string headersJson = json.Substring(braceStart, braceEnd - braceStart);
            
            // Parse simple key-value pairs
            var matches = System.Text.RegularExpressions.Regex.Matches(headersJson, "\"([^\"]+)\"\\s*:\\s*\"([^\"]+)\"");
            foreach (System.Text.RegularExpressions.Match m in matches)
            {
                headers[m.Groups[1].Value] = m.Groups[2].Value;
            }
            
            return headers;
        }
        
        /// <summary>
        /// Uploads media to GCS signed URL using curl via Process on a background thread.
        /// Both UnityWebRequest and System.Net.HttpWebRequest have issues with GCS signed URLs
        /// in Unity's Mono runtime (connection resets, cert failures). Using curl directly
        /// matches the official World Labs API docs: https://docs.worldlabs.ai/api
        /// </summary>
        private void UploadMediaToSignedUrl(string uploadUrl, Dictionary<string, string> requiredHeaders)
        {
            string filePath;
            string tempFilePath = null;
            
            if (m_IsVideoUpload)
            {
                SetStatus("Uploading video via curl...", MessageType.Info);
                if (!File.Exists(m_VideoFilePath))
                {
                    m_IsProcessing = false;
                    AddDebugLog("ERROR", $"Video file not found: {m_VideoFilePath}");
                    SetStatus($"Video file not found: {m_VideoFilePath}", MessageType.Error);
                    return;
                }
                filePath = m_VideoFilePath;
                var fi = new FileInfo(filePath);
                AddDebugLog("REQUEST", $"PUT video upload ({fi.Length / 1024}KB) via curl - {Path.GetFileName(filePath)}");
            }
            else
            {
                SetStatus("Uploading image via curl...", MessageType.Info);
                byte[] imageData = GetReadableTextureBytes(m_InputImage);
                AddDebugLog("REQUEST", $"PUT image upload ({imageData.Length / 1024}KB) via curl");
                
                // Write image bytes to a temp file for curl
                tempFilePath = Path.Combine(Path.GetTempPath(), $"worldlabs_upload_{Guid.NewGuid()}.jpg");
                File.WriteAllBytes(tempFilePath, imageData);
                filePath = tempFilePath;
            }
            
            // Log details
            var headerLog = new StringBuilder();
            headerLog.Append($"File: {filePath}");
            foreach (var kvp in requiredHeaders)
            {
                headerLog.Append($"\n  {kvp.Key}: {kvp.Value}");
            }
            AddDebugLog("INFO", "Upload details (via curl)", headerLog.ToString());
            
            // Reset upload state
            m_BgUploadComplete = false;
            m_BgUploadFailed = false;
            m_BgUploadError = "";
            m_BgUploadErrorDetails = "";
            
            // Build curl arguments matching the official docs:
            // curl -X PUT '<signed_upload_url>' -H 'x-goog-content-length-range: 0,1048576000' --data-binary '@/path/to/file'
            var curlArgs = new StringBuilder();
            curlArgs.Append("-X PUT ");
            curlArgs.Append($"\"{uploadUrl}\" ");
            
            foreach (var kvp in requiredHeaders)
            {
                curlArgs.Append($"-H \"{kvp.Key}: {kvp.Value}\" ");
            }
            
            curlArgs.Append($"--data-binary \"@{filePath.Replace("\\", "/")}\" ");
            curlArgs.Append("-s -w \"\\n%{http_code}\" "); // Silent mode + output HTTP status code
            curlArgs.Append("--connect-timeout 30 ");
            curlArgs.Append("--max-time 600"); // 10 minute timeout
            
            string curlArgsStr = curlArgs.ToString();
            string tempFileToClean = tempFilePath; // Capture for thread
            
            AddDebugLog("INFO", "curl command", $"curl {curlArgsStr.Substring(0, Math.Min(200, curlArgsStr.Length))}...");
            
            // Run curl on background thread
            ThreadPool.QueueUserWorkItem(_ =>
            {
                try
                {
                    // Use curl.exe explicitly - on Windows, "curl" in PowerShell is aliased to Invoke-WebRequest
                    string curlExe = Application.platform == RuntimePlatform.WindowsEditor ? "curl.exe" : "curl";
                    
                    var psi = new ProcessStartInfo
                    {
                        FileName = curlExe,
                        Arguments = curlArgsStr,
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        CreateNoWindow = true
                    };
                    
                    using (var process = Process.Start(psi))
                    {
                        string stdout = process.StandardOutput.ReadToEnd();
                        string stderr = process.StandardError.ReadToEnd();
                        process.WaitForExit(660000); // 11 minutes max
                        
                        // Parse HTTP status code from last line of stdout
                        string[] lines = stdout.TrimEnd().Split('\n');
                        string httpCode = lines.Length > 0 ? lines[lines.Length - 1].Trim() : "";
                        string responseBody = lines.Length > 1 ? string.Join("\n", lines, 0, lines.Length - 1) : "";
                        
                        if (process.ExitCode == 0 && (httpCode == "200" || httpCode == "201"))
                        {
                            m_BgUploadComplete = true;
                        }
                        else
                        {
                            m_BgUploadError = $"curl exit={process.ExitCode}, HTTP {httpCode}";
                            m_BgUploadErrorDetails = $"stdout: {stdout}\nstderr: {stderr}";
                            m_BgUploadFailed = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    m_BgUploadError = $"Failed to run curl: {ex.Message}";
                    m_BgUploadErrorDetails = ex.ToString();
                    m_BgUploadFailed = true;
                }
                finally
                {
                    // Clean up temp file if we created one
                    if (!string.IsNullOrEmpty(tempFileToClean))
                    {
                        try { File.Delete(tempFileToClean); }
                        catch { /* ignore */ }
                    }
                }
            });
        }
        
        private byte[] GetReadableTextureBytes(Texture2D source)
        {
            // Handle compressed or non-readable textures by rendering to a temp RT
            RenderTexture rt = RenderTexture.GetTemporary(source.width, source.height, 0, RenderTextureFormat.ARGB32);
            Graphics.Blit(source, rt);
            
            RenderTexture prev = RenderTexture.active;
            RenderTexture.active = rt;
            
            Texture2D readable = new Texture2D(source.width, source.height, TextureFormat.RGB24, false);
            readable.ReadPixels(new Rect(0, 0, source.width, source.height), 0, 0);
            readable.Apply();
            
            RenderTexture.active = prev;
            RenderTexture.ReleaseTemporary(rt);
            
            byte[] data = readable.EncodeToJPG(90);
            DestroyImmediate(readable);
            
            return data;
        }
        
        private void HandleMediaUploadComplete()
        {
            string mediaType = m_IsVideoUpload ? "Video" : "Image";
            SetStatus($"{mediaType} uploaded, starting world generation...", MessageType.Info);
            AddDebugLog("INFO", $"{mediaType} upload complete, preparing generation request");
            
            string mediaAssetId = EditorPrefs.GetString("WorldLabs.LastMediaAssetId", "");
            
            if (string.IsNullOrEmpty(mediaAssetId))
            {
                AddDebugLog("ERROR", "Media asset ID is empty!");
                SetStatus("Failed: Media asset ID is empty", MessageType.Error);
                m_IsProcessing = false;
                return;
            }
            
            var sb = new StringBuilder();
            sb.Append("{");
            sb.Append($"\"display_name\":\"{EscapeJson(m_DisplayName)}\",");
            sb.Append($"\"model\":\"{GetModelString()}\",");
            sb.Append("\"world_prompt\":{");
            
            if (m_IsVideoUpload)
            {
                // Build video prompt JSON with media_asset source
                sb.Append("\"type\":\"video\",");
                sb.Append("\"video_prompt\":{");
                sb.Append("\"source\":\"media_asset\",");
                sb.Append($"\"media_asset_id\":\"{mediaAssetId}\"");
                sb.Append("}");
                if (!string.IsNullOrEmpty(m_VideoTextPrompt))
                {
                    sb.Append($",\"text_prompt\":\"{EscapeJson(m_VideoTextPrompt)}\"");
                }
            }
            else
            {
                // Build image prompt JSON with media_asset source
                sb.Append("\"type\":\"image\",");
                sb.Append("\"image_prompt\":{");
                sb.Append("\"source\":\"media_asset\",");
                sb.Append($"\"media_asset_id\":\"{mediaAssetId}\"");
                if (m_IsPanorama)
                    sb.Append(",\"is_pano\":true");
                sb.Append("}");
                if (!string.IsNullOrEmpty(m_ImageTextPrompt))
                {
                    sb.Append($",\"text_prompt\":\"{EscapeJson(m_ImageTextPrompt)}\"");
                }
            }
            
            sb.Append("}");
            
            if (m_Seed >= 0)
            {
                sb.Append($",\"seed\":{m_Seed}");
            }
            
            sb.Append("}");
            
            m_IsVideoUpload = false; // Reset flag
            StartGenerateRequest(sb.ToString());
        }
        
        private void GenerateWorldFromVideo()
        {
            if (string.IsNullOrEmpty(m_ApiKey))
            {
                SetStatus("API Key is required", MessageType.Error);
                return;
            }
            
            m_IsProcessing = true;
            
            if (m_UseVideoUrl)
            {
                // Public URL mode - send directly
                if (string.IsNullOrEmpty(m_VideoUrl))
                {
                    SetStatus("Video URL is required", MessageType.Error);
                    m_IsProcessing = false;
                    return;
                }
                
                SetStatus("Starting world generation from video URL...", MessageType.Info);
                
                var sb = new StringBuilder();
                sb.Append("{");
                sb.Append($"\"display_name\":\"{EscapeJson(m_DisplayName)}\",");
                sb.Append($"\"model\":\"{GetModelString()}\",");
                sb.Append("\"world_prompt\":{");
                sb.Append("\"type\":\"video\",");
                sb.Append("\"video_prompt\":{");
                sb.Append("\"source\":\"uri\",");
                sb.Append($"\"uri\":\"{EscapeJson(m_VideoUrl)}\"");
                sb.Append("}");
                if (!string.IsNullOrEmpty(m_VideoTextPrompt))
                {
                    sb.Append($",\"text_prompt\":\"{EscapeJson(m_VideoTextPrompt)}\"");
                }
                sb.Append("}");
                
                if (m_Seed >= 0)
                {
                    sb.Append($",\"seed\":{m_Seed}");
                }
                
                sb.Append("}");
                
                StartGenerateRequest(sb.ToString());
            }
            else
            {
                // Local file mode - upload via media-assets first
                if (string.IsNullOrEmpty(m_VideoFilePath) || !File.Exists(m_VideoFilePath))
                {
                    SetStatus("Valid video file path is required", MessageType.Error);
                    m_IsProcessing = false;
                    return;
                }
                
                SetStatus("Uploading video and starting world generation...", MessageType.Info);
                m_IsVideoUpload = true;
                
                string extension = Path.GetExtension(m_VideoFilePath).TrimStart('.').ToLower();
                string fileName = Path.GetFileName(m_VideoFilePath);
                PrepareMediaAssetUpload(fileName, "video", extension);
            }
        }
        
        private void HandleGenerateResponse(string json)
        {
            m_CurrentOperationId = ExtractJsonValue(json, "operation_id");
            
            if (string.IsNullOrEmpty(m_CurrentOperationId))
            {
                m_IsProcessing = false;
                SetStatus("Failed to start generation: " + json, MessageType.Error);
                return;
            }
            
            // Add to operations list
            var op = new WorldOperation
            {
                operationId = m_CurrentOperationId,
                displayName = m_DisplayName,
                status = "IN_PROGRESS",
                startTime = DateTime.Now,
                done = false
            };
            m_Operations.Insert(0, op);
            
            m_IsProcessing = false;
            m_IsPolling = true;
            m_PollErrorCount = 0;
            m_NeedsFetchWorldDetails = false;
            m_OperationStatus = "IN_PROGRESS";
            m_OperationProgress = 0.1f;
            
            string timeEstimate = m_ModelType == ModelType.Mini ? "~30-45 seconds" : GENERATION_TIME_ESTIMATE;
            SetStatus($"World generation started! Operation ID: {m_CurrentOperationId}\nModel: {GetModelString()}\nEstimated time: {timeEstimate}", MessageType.Info);
            
            // Switch to operations tab
            m_CurrentTab = 3;
        }
        
        private void PollOperationStatus()
        {
            if (m_CurrentRequest != null) return;
            if (string.IsNullOrEmpty(m_CurrentOperationId)) return;
            
            string url = $"{API_BASE_URL}/operations/{m_CurrentOperationId}";
            
            m_CurrentRequest = UnityWebRequest.Get(url);
            m_CurrentRequest.SetRequestHeader("WLT-Api-Key", m_ApiKey);
            m_CurrentRequest.timeout = 30; // 30s timeout so polls don't hang
            m_CurrentRequest.SendWebRequest();
        }
        
        private void HandleOperationResponse(string json)
        {
            bool done = json.Contains("\"done\":true") || json.Contains("\"done\": true");
            string status = ExtractNestedJsonValue(json, "progress", "status");
            m_CurrentWorldId = ExtractNestedJsonValue(json, "metadata", "world_id");
            
            if (string.IsNullOrEmpty(status))
                status = done ? "COMPLETED" : "IN_PROGRESS";
            
            m_OperationStatus = status;
            
            // Update operation in list
            foreach (var op in m_Operations)
            {
                if (op.operationId == m_CurrentOperationId)
                {
                    op.status = status;
                    op.worldId = m_CurrentWorldId;
                    op.done = done;
                    break;
                }
            }
            
            if (done)
            {
                m_IsPolling = false;
                m_OperationProgress = 1f;
                
                // Extract all SPZ URLs from response (nested under assets.splats.spz_urls)
                string spzFull = ExtractDeepNestedJsonValue(json, "spz_urls", "full_res");
                string spz500k = ExtractDeepNestedJsonValue(json, "spz_urls", "500k");
                string spz100k = ExtractDeepNestedJsonValue(json, "spz_urls", "100k");
                string colliderMesh = ExtractDeepNestedJsonValue(json, "mesh", "collider_mesh_url");
                string panoUrl = ExtractDeepNestedJsonValue(json, "imagery", "pano_url");
                string thumbnailUrl = ExtractJsonValue(json, "thumbnail_url");
                string caption = ExtractJsonValue(json, "caption");
                
                foreach (var op in m_Operations)
                {
                    if (op.operationId == m_CurrentOperationId)
                    {
                        op.spzUrlFullRes = spzFull;
                        op.spzUrl500k = spz500k;
                        op.spzUrl100k = spz100k;
                        op.colliderMeshUrl = colliderMesh;
                        op.panoUrl = panoUrl;
                        op.thumbnailUrl = thumbnailUrl;
                        op.caption = caption;
                        break;
                    }
                }
                
                if (status == "SUCCEEDED")
                {
                    SetStatus($"World generation completed! World ID: {m_CurrentWorldId}\nFull Res: {(!string.IsNullOrEmpty(spzFull) ? "✓" : "✗")} | 500k: {(!string.IsNullOrEmpty(spz500k) ? "✓" : "✗")} | 100k: {(!string.IsNullOrEmpty(spz100k) ? "✓" : "✗")}", MessageType.Info);
                    AddDebugLog("INFO", "Generation SUCCEEDED! Fetching world details...");
                    
                    // Fetch world details to get full asset URLs then auto-download
                    // Set retry flag in case the fetch fails (transient network errors)
                    if (!string.IsNullOrEmpty(m_CurrentWorldId))
                    {
                        m_NeedsFetchWorldDetails = true;
                        m_FetchWorldRetries = 0;
                        FetchWorldDetails(m_CurrentWorldId);
                    }
                    else if (m_AutoImportToScene)
                    {
                        // If we already have SPZ URLs from operation response, auto-download
                        var completedOp = m_Operations.Find(o => o.operationId == m_CurrentOperationId);
                        if (completedOp != null)
                        {
                            string selectedUrl = GetSelectedSpzUrl(completedOp);
                            if (!string.IsNullOrEmpty(selectedUrl))
                            {
                                AddDebugLog("INFO", $"Auto-downloading SPZ ({m_OutputQuality})...");
                                DownloadAndImportToScene(completedOp, selectedUrl);
                            }
                        }
                    }
                }
                else
                {
                    string errorMsg = ExtractJsonValue(json, "message");
                    SetStatus($"Generation failed: {errorMsg}", MessageType.Error);
                }
            }
            else
            {
                // Update progress estimate based on time elapsed
                var op = m_Operations.Find(o => o.operationId == m_CurrentOperationId);
                if (op != null)
                {
                    float elapsed = (float)(DateTime.Now - op.startTime).TotalSeconds;
                    float estimated = m_ModelType == ModelType.Mini ? 45f : 300f;
                    m_OperationProgress = Mathf.Clamp(elapsed / estimated, 0f, 0.9f); // Hard cap at 90% until done
                }
                
                string timeHint = m_OperationProgress >= 0.9f ? " (still processing, please wait...)" : "";
                SetStatus($"Generation in progress... Status: {status}{timeHint}", MessageType.Info);
            }
        }
        
        private void FetchWorldDetails(string worldId)
        {
            if (m_CurrentRequest != null) return; // Wait for current request to finish
            
            string url = $"{API_BASE_URL}/worlds/{worldId}";
            
            m_CurrentRequest = UnityWebRequest.Get(url);
            m_CurrentRequest.SetRequestHeader("WLT-Api-Key", m_ApiKey);
            m_CurrentRequest.timeout = 30; // 30s timeout
            m_CurrentRequest.SendWebRequest();
        }
        
        private void HandleWorldResponse(string json)
        {
            // World details fetched successfully - clear retry state
            m_NeedsFetchWorldDetails = false;
            m_FetchWorldRetries = 0;
            
            // Extract asset URLs (nested under assets.splats.spz_urls)
            string spzFull = ExtractDeepNestedJsonValue(json, "spz_urls", "full_res");
            string spz500k = ExtractDeepNestedJsonValue(json, "spz_urls", "500k");
            string spz100k = ExtractDeepNestedJsonValue(json, "spz_urls", "100k");
            string colliderMesh = ExtractDeepNestedJsonValue(json, "mesh", "collider_mesh_url");
            string panoUrl = ExtractDeepNestedJsonValue(json, "imagery", "pano_url");
            string thumbnailUrl = ExtractJsonValue(json, "thumbnail_url");
            string caption = ExtractJsonValue(json, "caption");
            
            // Update operation with all URLs
            WorldOperation completedOp = null;
            foreach (var op in m_Operations)
            {
                if (op.worldId == m_CurrentWorldId)
                {
                    op.spzUrlFullRes = spzFull;
                    op.spzUrl500k = spz500k;
                    op.spzUrl100k = spz100k;
                    op.colliderMeshUrl = colliderMesh;
                    op.panoUrl = panoUrl;
                    op.thumbnailUrl = thumbnailUrl;
                    op.caption = caption;
                    completedOp = op;
                    break;
                }
            }
            
            SetStatus($"World ready!\nFull Res: {(!string.IsNullOrEmpty(spzFull) ? "✓" : "✗")} | 500k: {(!string.IsNullOrEmpty(spz500k) ? "✓" : "✗")} | 100k: {(!string.IsNullOrEmpty(spz100k) ? "✓" : "✗")}\nCollider: {(!string.IsNullOrEmpty(colliderMesh) ? "✓" : "✗")}", MessageType.Info);
            
            // Auto-download if enabled
            if (m_AutoImportToScene && completedOp != null)
            {
                string selectedUrl = GetSelectedSpzUrl(completedOp);
                if (!string.IsNullOrEmpty(selectedUrl))
                {
                    AddDebugLog("INFO", $"Auto-downloading SPZ ({m_OutputQuality})...");
                    DownloadAndImportToScene(completedOp, selectedUrl);
                }
                else
                {
                    AddDebugLog("WARNING", "Auto-import enabled but no SPZ URL available");
                }
            }
        }
        
        private string GetSelectedSpzUrl(WorldOperation op)
        {
            switch (m_OutputQuality)
            {
                case OutputQuality.FullRes:
                    return !string.IsNullOrEmpty(op.spzUrlFullRes) ? op.spzUrlFullRes : 
                           !string.IsNullOrEmpty(op.spzUrl500k) ? op.spzUrl500k : op.spzUrl100k;
                case OutputQuality.Quality500k:
                    return !string.IsNullOrEmpty(op.spzUrl500k) ? op.spzUrl500k : 
                           !string.IsNullOrEmpty(op.spzUrlFullRes) ? op.spzUrlFullRes : op.spzUrl100k;
                case OutputQuality.Quality100k:
                    return !string.IsNullOrEmpty(op.spzUrl100k) ? op.spzUrl100k : 
                           !string.IsNullOrEmpty(op.spzUrl500k) ? op.spzUrl500k : op.spzUrlFullRes;
                default:
                    return op.spzUrlFullRes;
            }
        }
        
        private void DownloadAsset(WorldOperation op, string url, string extension, string defaultName)
        {
            if (string.IsNullOrEmpty(url))
            {
                SetStatus($"No {extension.ToUpper()} URL available", MessageType.Error);
                return;
            }
            
            string savePath = EditorUtility.SaveFilePanel($"Save {extension.ToUpper()} File", "", defaultName, extension);
            if (string.IsNullOrEmpty(savePath)) return;
            
            SetStatus($"Downloading {extension.ToUpper()} file...", MessageType.Info);
            
            var request = UnityWebRequest.Get(url);
            request.SendWebRequest();
            
            EditorApplication.CallbackFunction downloadCallback = null;
            downloadCallback = () =>
            {
                if (!request.isDone) return;
                
                EditorApplication.update -= downloadCallback;
                
                if (request.result == UnityWebRequest.Result.Success)
                {
                    File.WriteAllBytes(savePath, request.downloadHandler.data);
                    SetStatus($"{extension.ToUpper()} saved to: {savePath}", MessageType.Info);
                    AssetDatabase.Refresh();
                }
                else
                {
                    SetStatus($"Download failed: {request.error}", MessageType.Error);
                }
                
                request.Dispose();
            };
            
            EditorApplication.update += downloadCallback;
        }
        
        private void DownloadAndImportToScene(WorldOperation op, string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                SetStatus("No SPZ URL available", MessageType.Error);
                return;
            }
            
            // Ensure output folder exists
            if (!Directory.Exists(m_OutputFolder))
            {
                Directory.CreateDirectory(m_OutputFolder);
            }
            
            string safeName = SanitizeFileName(op.displayName);
            string savePath = $"{m_OutputFolder}/{safeName}.spz";
            
            SetStatus("Downloading SPZ for import...", MessageType.Info);
            
            var request = UnityWebRequest.Get(url);
            request.SendWebRequest();
            
            EditorApplication.CallbackFunction downloadCallback = null;
            downloadCallback = () =>
            {
                if (!request.isDone) return;
                
                EditorApplication.update -= downloadCallback;
                
                if (request.result == UnityWebRequest.Result.Success)
                {
                    File.WriteAllBytes(savePath, request.downloadHandler.data);
                    AssetDatabase.Refresh();
                    
                    SetStatus($"SPZ downloaded to: {savePath}\nUse your Gaussian Splatting plugin to import.", MessageType.Info);
                    
                    // Select the downloaded file in Project window
                    EditorApplication.delayCall += () =>
                    {
                        SelectDownloadedFile(savePath);
                    };
                }
                else
                {
                    SetStatus($"Download failed: {request.error}", MessageType.Error);
                }
                
                request.Dispose();
            };
            
            EditorApplication.update += downloadCallback;
        }
        
        /// <summary>
        /// Selects the downloaded file in the Project window
        /// </summary>
        private void SelectDownloadedFile(string filePath)
        {
            try
            {
                // Convert to relative path if within Assets
                string relativePath = filePath;
                if (filePath.StartsWith(Application.dataPath))
                {
                    relativePath = "Assets" + filePath.Substring(Application.dataPath.Length);
                }
                
                var asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(relativePath);
                if (asset != null)
                {
                    Selection.activeObject = asset;
                    EditorGUIUtility.PingObject(asset);
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"Could not select downloaded file: {ex.Message}");
            }
        }
        
        private string SanitizeFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "world";
            
            char[] invalid = Path.GetInvalidFileNameChars();
            foreach (char c in invalid)
            {
                name = name.Replace(c, '_');
            }
            return name.Replace(' ', '_');
        }
        
        // Simple JSON value extraction (no external dependencies)
        private string ExtractJsonValue(string json, string key)
        {
            string pattern = $"\"{key}\"\\s*:\\s*\"([^\"]+)\"";
            var match = System.Text.RegularExpressions.Regex.Match(json, pattern);
            return match.Success ? match.Groups[1].Value : "";
        }
        
        private string ExtractNestedJsonValue(string json, string parentKey, string childKey)
        {
            // Find parent object
            int parentIdx = json.IndexOf($"\"{parentKey}\"");
            if (parentIdx < 0) return "";
            
            int braceStart = json.IndexOf('{', parentIdx);
            if (braceStart < 0) return "";
            
            // Find matching closing brace
            int depth = 1;
            int braceEnd = braceStart + 1;
            while (braceEnd < json.Length && depth > 0)
            {
                if (json[braceEnd] == '{') depth++;
                else if (json[braceEnd] == '}') depth--;
                braceEnd++;
            }
            
            string subJson = json.Substring(braceStart, braceEnd - braceStart);
            return ExtractJsonValue(subJson, childKey);
        }
        
        /// <summary>
        /// Extracts value from deeply nested JSON (e.g., assets.splats.spz_urls.full_res)
        /// Searches for parentKey anywhere in the JSON and then extracts childKey from within it
        /// </summary>
        private string ExtractDeepNestedJsonValue(string json, string parentKey, string childKey)
        {
            // First try direct nested extraction
            string result = ExtractNestedJsonValue(json, parentKey, childKey);
            if (!string.IsNullOrEmpty(result)) return result;
            
            // Try finding within "assets" object first (new API structure)
            int assetsIdx = json.IndexOf("\"assets\"");
            if (assetsIdx >= 0)
            {
                int braceStart = json.IndexOf('{', assetsIdx);
                if (braceStart >= 0)
                {
                    int depth = 1;
                    int braceEnd = braceStart + 1;
                    while (braceEnd < json.Length && depth > 0)
                    {
                        if (json[braceEnd] == '{') depth++;
                        else if (json[braceEnd] == '}') depth--;
                        braceEnd++;
                    }
                    
                    string assetsJson = json.Substring(braceStart, braceEnd - braceStart);
                    result = ExtractNestedJsonValue(assetsJson, parentKey, childKey);
                    if (!string.IsNullOrEmpty(result)) return result;
                }
            }
            
            // Try finding within "response" object (operation response structure)
            int responseIdx = json.IndexOf("\"response\"");
            if (responseIdx >= 0)
            {
                int braceStart = json.IndexOf('{', responseIdx);
                if (braceStart >= 0)
                {
                    int depth = 1;
                    int braceEnd = braceStart + 1;
                    while (braceEnd < json.Length && depth > 0)
                    {
                        if (json[braceEnd] == '{') depth++;
                        else if (json[braceEnd] == '}') depth--;
                        braceEnd++;
                    }
                    
                    string responseJson = json.Substring(braceStart, braceEnd - braceStart);
                    
                    // Look for assets within response
                    result = ExtractNestedJsonValue(responseJson, parentKey, childKey);
                    if (!string.IsNullOrEmpty(result)) return result;
                    
                    // Try assets.splats.spz_urls path
                    int assetsInResponseIdx = responseJson.IndexOf("\"assets\"");
                    if (assetsInResponseIdx >= 0)
                    {
                        braceStart = responseJson.IndexOf('{', assetsInResponseIdx);
                        if (braceStart >= 0)
                        {
                            depth = 1;
                            braceEnd = braceStart + 1;
                            while (braceEnd < responseJson.Length && depth > 0)
                            {
                                if (responseJson[braceEnd] == '{') depth++;
                                else if (responseJson[braceEnd] == '}') depth--;
                                braceEnd++;
                            }
                            
                            string assetsInResponse = responseJson.Substring(braceStart, braceEnd - braceStart);
                            result = ExtractNestedJsonValue(assetsInResponse, parentKey, childKey);
                        }
                    }
                }
            }
            
            return result;
        }
    }
}
