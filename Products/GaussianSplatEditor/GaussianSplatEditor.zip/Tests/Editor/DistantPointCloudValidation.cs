using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    // Offscreen production-shader draws; no camera, scene, renderer or selection is created/modified.
    public static class DistantPointCloudValidation
    {
        const int Width = 128, Height = 96;
        const float Distance = 8f, Opacity = 0.625f;
        static string ReportPath => Path.Combine(Path.GetTempPath(), "SplatBox-quality-analysis",
            "distant-point-validation.json");
        static string Root => PackageRoot();
        static string PackageRoot() => UnityEditor.PackageManager.PackageInfo
            .FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";

        [StructLayout(LayoutKind.Sequential)]
        struct ViewData
        {
            public Vector4 pos;
            public uint axis1, axis2, color1, color2;
            public Vector3 worldPos;
            public uint splatIdx;
        }
        [StructLayout(LayoutKind.Sequential)] struct Data32 { public Vector4 a, b; }
        [StructLayout(LayoutKind.Sequential)] struct Data64 { public Vector4 a, b, c, d; }
        [StructLayout(LayoutKind.Sequential)] struct Data80 { public Vector4 a, b, c, d, e; }
        [StructLayout(LayoutKind.Sequential)] struct Data96 { public Matrix4x4 a; public Vector4 b, c; }
        [StructLayout(LayoutKind.Sequential)]
        struct PointLight { public Vector4 position, color; public float intensity, range, mode, pad; }
        [StructLayout(LayoutKind.Sequential)]
        struct SpotLight
        {
            public Vector4 position, direction, color;
            public float intensity, range, innerCone, outerCone, mode, pad0, pad1, pad2;
        }
        [StructLayout(LayoutKind.Sequential)]
        struct DirectionalLight
        {
            public Vector4 direction, color;
            public float intensity, range, softness, shadowStrength, useDistance, distanceFactor, useAngle, angleBias;
        }
        [StructLayout(LayoutKind.Sequential)]
        struct PlanarLight
        {
            public Vector4 position, normal, color;
            public float intensity, range, sizeX, sizeY, twoSided, mode, pad0, pad1;
        }

        [Serializable] sealed class ShaderResult
        {
            public string shader;
            public int gaussianPixels, point3Pixels, point4Pixels, point6Pixels, draws;
            public bool passed, relightResponds;
        }
        [Serializable] sealed class Report
        {
            public string state = "running", graphicsApi, completedUtc, error;
            public List<ShaderResult> shaders = new List<ShaderResult>();
        }
        [Serializable] sealed class StabilityCase
        {
            public string name, error;
            public bool passed;
            public int coveredPixels, nonFiniteChannels;
            public float minimumRgb, maximumRgb;
        }
        [Serializable] sealed class StabilityShader
        {
            public string shader;
            public bool passed;
            public int draws;
            public List<StabilityCase> cases = new List<StabilityCase>();
        }
        [Serializable] sealed class StabilityReport
        {
            public string state = "running", graphicsApi, completedUtc, error;
            public List<StabilityShader> shaders = new List<StabilityShader>();
        }
        [Serializable] sealed class GradingCase
        {
            public string name, error;
            public bool passed;
            public int coveredPixels, faintCoveredPixels;
            public float maximumAbsoluteError, maximumRelativeError;
            public float coveredAbsoluteEnergyBudget, faintAbsoluteEnergyBudget;
            public float[] referenceEnergy = new float[3], actualEnergy = new float[3];
            public float[] referenceFaintEnergy = new float[3], actualFaintEnergy = new float[3];
        }
        [Serializable] sealed class GradingShader
        {
            public string shader;
            public bool passed;
            public int draws;
            public List<GradingCase> cases = new List<GradingCase>();
        }
        [Serializable] sealed class GradingReport
        {
            public string state = "running", graphicsApi, completedUtc, error;
            public List<GradingShader> shaders = new List<GradingShader>();
        }

        // Compare the optimized production draw with its original fragment path. A decal whose
        // volume is far from the splat disables the optimization without changing the image.
        public static void RunRelightGradingParity()
        {
            var report = new GradingReport { graphicsApi = SystemInfo.graphicsDeviceType.ToString() };
            var parity = new Dictionary<string, Color[]>();
            WriteGrading(report);
            try
            {
                Require(SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat), "ARGBFloat rendering is required.");
                using var fixture = new Fixture();
                foreach (string path in new[] { "Resources/RenderSplatsRelight.shader", "Shaders/Relight/RenderGaussianSplats.shader" })
                {
                    var result = new GradingShader { shader = path };
                    report.shaders.Add(result);
                    Shader shader = AssetDatabase.LoadAssetAtPath<Shader>(Root + path);
                    Require(shader != null && shader.isSupported, "Missing or unsupported production shader: " + path);
                    var material = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
                    var draws = new ShaderResult { shader = path };
                    try
                    {
                        CompileVariants(material);
                        var position = new Vector3(0, 0, Distance + 1);
                        var sceneFilter = new Color(0.8537736f, 0.92750853f, 1, 1);
                        void SceneGrade(Material m)
                        {
                            m.SetFloat("_ColorExposure", -2);
                            m.SetFloat("_ColorHueShift", 1);
                            m.SetColor("_ColorFilter", sceneFilter);
                        }
                        Color[] Draw(Color color, float opacity, bool point, Action<Material> setup = null,
                            bool forceFragment = false, bool selected = false, bool forceViaPanorama = false)
                        {
                            fixture.Configure(material);
                            return fixture.Draw(material, draws, position, point, opacity: opacity,
                                selected: selected, sourceColor: color, configureBeforeDraw: m =>
                                {
                                    SceneGrade(m);
                                    setup?.Invoke(m);
                                    if (forceFragment)
                                    {
                                        if (forceViaPanorama)
                                        {
                                            // Keep an active decal intact when testing its fallback.
                                            m.SetInt("_EquirectEnabled", 1);
                                            m.SetFloat("_EquirectOpacity", 0);
                                        }
                                        else ForceFragmentGrading(m);
                                    }
                                });
                        }
                        void Case(string name, Func<Color[]> optimized, Func<Color[]> fragment,
                            Action<Color[]> check = null, bool exact = false)
                        {
                            var item = new GradingCase { name = name };
                            result.cases.Add(item);
                            try
                            {
                                Color[] actual = optimized(), reference = fragment();
                                CompareGrading(reference, actual, item);
                                if (exact) CompareExact(reference, actual, name + " retained fragment path");
                                check?.Invoke(actual);
                                foreach (var pair in new[] { (key: name + "/optimized", pixels: actual), (key: name + "/fragment", pixels: reference) })
                                {
                                    if (parity.TryGetValue(pair.key, out var previous))
                                        CompareExact(previous, pair.pixels, "Relight grading source/player " + pair.key);
                                    else parity.Add(pair.key, pair.pixels);
                                }
                                item.passed = true;
                            }
                            catch (Exception exception) { item.error = exception.ToString(); }
                            result.draws = draws.draws;
                            WriteGrading(report);
                        }
                        void Pair(string name, Color color, float opacity, Action<Material> setup = null)
                        {
                            foreach (bool point in new[] { false, true })
                                Case(name + (point ? "-point" : "-gaussian"),
                                    () => Draw(color, opacity, point, setup),
                                    () => Draw(color, opacity, point, setup, forceFragment: true),
                                    color == Color.black ? pixels => Require(pixels.All(p => p.r == 0 && p.g == 0 && p.b == 0),
                                        "Black source emitted RGB during grading.") : (Action<Color[]>)null);
                        }

                        Pair("scene-colour", new Color(0.25f, 0.5f, 0.75f, 1), Opacity);
                        Pair("scene-dark", new Color(0.001f, 0.002f, 0.003f, 1), Opacity);
                        Pair("scene-grey-faint", Color.gray, 1f / 128f);
                        Pair("black-faint", Color.black, 1f / 128f);
                        Pair("near-black-faint", new Color(0.0001f, 0.0002f, 0.0003f, 1), 1f / 128f);
                        Pair("hdr-tinted", new Color(6, 2, 0.5f, 1), 0.125f,
                            m => m.SetFloat("_ColorSaturation", 0.8f));
                        Pair("hdr-pre-alpha-exceeds-half", new Color(8192, 4096, 2048, 1), 1f / 128f,
                            m => m.SetFloat("_ColorExposure", 5));
                        Pair("dark-floor-boundary-opacity-saturation", new Color(0.039f, 0.04f, 0.041f, 1), 1.5f);
                        Pair("bright-hue-saturation", new Color(0.8f, 0.025f, 0.1f, 1), Opacity, m =>
                        {
                            m.SetFloat("_ColorExposure", 2);
                            m.SetFloat("_ColorHueShift", 45);
                            m.SetFloat("_ColorSaturation", 1.4f);
                            m.SetColor("_ColorFilter", new Color(0.6f, 1, 0.7f, 1));
                        });
                        Pair("dim-negative-hue", new Color(0.2f, 0.5f, 0.75f, 1), Opacity, m =>
                        {
                            m.SetFloat("_ColorExposure", -6);
                            m.SetFloat("_ColorHueShift", -135);
                            m.SetFloat("_ColorSaturation", 0.35f);
                        });
                        Pair("lit-low-colour", new Color(0.001f, 0.02f, 0.039f, 1), Opacity,
                            m => fixture.SetPoint(m, new PointLight { position = new Vector4(position.x, position.y, position.z, 0),
                                color = new Vector4(1, 0.5f, 0.25f, 1), intensity = 3, range = 4 }));

                        var source = new Color(0.25f, 0.5f, 0.75f, 1);
                        Color[] ordinary = Draw(source, Opacity, false);
                        void Fallback(string name, Action<Material> setup, bool selected = false, bool activeDecal = false)
                        {
                            Case("fallback-" + name,
                                () => Draw(source, Opacity, false, setup, selected: selected),
                                () => Draw(source, Opacity, false, setup, forceFragment: true,
                                    selected: selected, forceViaPanorama: activeDecal),
                                pixels => Require(pixels.Where((p, i) => Enumerable.Range(0, 4)
                                    .Any(c => Mathf.Abs(p[c] - ordinary[i][c]) > 0.0001f)).Any(),
                                    name + " did not exercise a visible fallback effect."), exact: true);
                        }
                        Fallback("contrast-below-one", m => m.SetFloat("_ColorContrast", 0.8f));
                        Fallback("contrast-above-one", m => m.SetFloat("_ColorContrast", 1.2f));
                        Fallback("selection", null, selected: true);
                        Fallback("mesh-albedo", m => m.SetInt("_MeshTexEnabled", 1));
                        Fallback("sharpen-debug-tint", m => m.SetFloat("_SharpenStrength", 0.8f));
                        Fallback("panorama", m =>
                        {
                            m.SetInt("_EquirectEnabled", 1); m.SetFloat("_EquirectOpacity", 0.35f);
                            m.SetInt("_EquirectBlendMode", 0); m.SetInt("_EquirectUseDistanceFiltering", 0);
                            m.SetVector("_EquirectProjectorPosition", Vector4.zero);
                            m.SetVector("_EquirectProjectorScale", Vector4.one);
                            m.SetVector("_EquirectProjectorRotation", new Vector4(0, 0, 0, 1));
                            m.SetFloat("_EquirectTileX", 1); m.SetFloat("_EquirectTileY", 1);
                            m.SetColor("_EquirectTintColor", new Color(0.4f, 0.7f, 0.1f, 1));
                        });
                        Fallback("decal", m =>
                        {
                            m.SetInt("_DecalEnabled", 1); m.SetInt("_DecalProjectionMode", 0);
                            m.SetMatrix("_DecalWorldToProjector", Matrix4x4.identity);
                            m.SetVector("_DecalBoxSize", Vector3.one * 100);
                            m.SetInt("_DecalBlendMode", 0); m.SetFloat("_DecalOpacity", 0.35f);
                            m.SetColor("_DecalTintColor", new Color(0.1f, 0.8f, 0.2f, 1));
                            m.SetInt("_DecalUseCircleMask", 0); m.SetInt("_DecalUseDepthFade", 0);
                        }, activeDecal: true);
                        result.passed = result.cases.All(c => c.passed);
                        var errors = ShaderUtil.GetShaderMessages(shader).Where(m => m.severity == ShaderCompilerMessageSeverity.Error).ToArray();
                        Require(errors.Length == 0, path + ": " + string.Join("; ", errors.Select(m => m.message)));
                    }
                    finally { UnityEngine.Object.DestroyImmediate(material); }
                }
                int failures = report.shaders.Sum(s => s.cases.Count(c => !c.passed));
                Require(failures == 0, "Relight grading parity GPU cases failed: " + failures + ". See relight-grading-parity-validation.json.");
                report.state = "passed";
                Debug.Log("SplatBox relight grading GPU PASS: optimized/fragment parity, exact opacity, faint-tail energy, HDR/near-black grading, retained effect fallbacks and source/player parity.");
            }
            catch (Exception exception) { report.state = "failed"; report.error = exception.ToString(); throw; }
            finally { report.completedUtc = DateTime.UtcNow.ToString("O"); WriteGrading(report); }
        }

        static void ForceFragmentGrading(Material material)
        {
            material.SetInt("_DecalEnabled", 1); material.SetInt("_DecalProjectionMode", 0);
            material.SetMatrix("_DecalWorldToProjector", Matrix4x4.Translate(Vector3.one * 2000));
            material.SetVector("_DecalBoxSize", Vector3.one);
        }

        static void CompareGrading(Color[] reference, Color[] actual, GradingCase result)
        {
            // The fragment path rounds premultiplied RGB to half before grading. Hoisting
            // grading can retain light that this intermediate rounded to zero. Allow one
            // smallest FP16 subnormal step (2^-24) per covered pixel, plus the unchanged
            // 0.3% relative allowance. Count covered/faint pixels separately, so empty
            // image area cannot hide energy loss and visible faint colours retain a tight
            // relative check. This is also much tighter than the former 1e-5 pixel floor.
            const float halfSubnormalStep = 1f / 16_777_216f;
            Require(reference.Length == actual.Length, "Grading image sizes differ.");
            result.coveredPixels = Coverage(reference);
            Require(result.coveredPixels > 0, "Grading fixture did not render a splat.");
            for (int i = 0; i < reference.Length; i++)
            {
                Require(actual[i].a == reference[i].a, "Grading changed opacity at pixel " + i);
                bool faint = reference[i].a > 0 && reference[i].a <= 1f / 64f;
                if (faint) result.faintCoveredPixels++;
                for (int c = 0; c < 4; c++)
                {
                    float a = actual[i][c], r = reference[i][c];
                    Require(!float.IsNaN(a) && !float.IsInfinity(a) && !float.IsNaN(r) && !float.IsInfinity(r),
                        "Grading emitted a non-finite channel at pixel " + i);
                    if (c == 3) continue;
                    if (reference[i].a == 0)
                        Require(a == 0 && r == 0, "Grading leaked RGB outside the splat at pixel " + i);
                    float difference = Mathf.Abs(a - r);
                    result.maximumAbsoluteError = Mathf.Max(result.maximumAbsoluteError, difference);
                    if (Mathf.Abs(r) > 1e-8f)
                        result.maximumRelativeError = Mathf.Max(result.maximumRelativeError, difference / Mathf.Abs(r));
                    Require(difference <= halfSubnormalStep + Mathf.Abs(r) * 0.003f,
                        $"Grading RGB differs at pixel {i}, channel {c}: fragment={r}, optimized={a}");
                    result.referenceEnergy[c] += Mathf.Abs(r); result.actualEnergy[c] += Mathf.Abs(a);
                    if (faint)
                    {
                        result.referenceFaintEnergy[c] += Mathf.Abs(r);
                        result.actualFaintEnergy[c] += Mathf.Abs(a);
                    }
                }
            }
            result.coveredAbsoluteEnergyBudget = result.coveredPixels * halfSubnormalStep;
            result.faintAbsoluteEnergyBudget = result.faintCoveredPixels * halfSubnormalStep;
            for (int c = 0; c < 3; c++)
            {
                Require(Mathf.Abs(result.actualEnergy[c] - result.referenceEnergy[c]) <= result.coveredAbsoluteEnergyBudget + result.referenceEnergy[c] * 0.003f,
                    "Grading changed integrated RGB energy in channel " + c);
                Require(Mathf.Abs(result.actualFaintEnergy[c] - result.referenceFaintEnergy[c]) <= result.faintAbsoluteEnergyBudget + result.referenceFaintEnergy[c] * 0.003f,
                    "Grading changed integrated faint-tail energy in channel " + c);
            }
        }

        // Separate entry point so all numerical regressions are reported even if one case fails.
        public static void RunRelightStability()
        {
            var report = new StabilityReport { graphicsApi = SystemInfo.graphicsDeviceType.ToString() };
            var parity = new Dictionary<string, Color[]>();
            WriteStability(report);
            try
            {
                Require(SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat), "ARGBFloat rendering is required.");
                using var fixture = new Fixture();
                foreach (string path in new[] { "Resources/RenderSplatsRelight.shader", "Shaders/Relight/RenderGaussianSplats.shader" })
                {
                    var result = new StabilityShader { shader = path };
                    report.shaders.Add(result);
                    Shader shader = AssetDatabase.LoadAssetAtPath<Shader>(Root + path);
                    Require(shader != null && shader.isSupported, "Missing or unsupported production shader: " + path);
                    var material = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
                    var drawResult = new ShaderResult { shader = path };
                    try
                    {
                        CompileVariants(material);
                        var baseColor = new Color(0.25f, 0.5f, 0.75f, 1);
                        Color[] Draw(Vector3 position, Color? color = null, float opacity = Opacity,
                            Action<Material> setup = null, Vector3? eye = null)
                        {
                            fixture.Configure(material);
                            return fixture.Draw(material, drawResult, position, false, opacity: opacity,
                                eyePosition: eye, sourceColor: color ?? baseColor, configureBeforeDraw: setup);
                        }
                        var origin = Draw(Vector3.zero);
                        var above = Draw(Vector3.up);
                        var outside = Draw(new Vector3(3, 1, 0));
                        var below = Draw(Vector3.down);
                        void Case(string name, Func<Color[]> draw, Action<Color[]> check = null)
                        {
                            var item = new StabilityCase { name = name };
                            result.cases.Add(item);
                            try
                            {
                                Color[] pixels = draw();
                                item.coveredPixels = Coverage(pixels);
                                item.minimumRgb = float.MaxValue;
                                item.maximumRgb = float.MinValue;
                                foreach (Color pixel in pixels)
                                {
                                    for (int c = 0; c < 4; c++)
                                    {
                                        float value = pixel[c];
                                        if (float.IsNaN(value) || float.IsInfinity(value)) item.nonFiniteChannels++;
                                        else if (c < 3)
                                        {
                                            item.minimumRgb = Mathf.Min(item.minimumRgb, value);
                                            item.maximumRgb = Mathf.Max(item.maximumRgb, value);
                                        }
                                    }
                                }
                                Require(item.nonFiniteChannels == 0, name + " emitted non-finite output channels: " + item.nonFiniteChannels);
                                Require(item.coveredPixels > 0, name + " did not render the test splat.");
                                foreach (Color pixel in pixels)
                                {
                                    Require(pixel.a >= 0 && pixel.a <= 1, name + " emitted invalid opacity.");
                                    for (int c = 0; c < 3; c++)
                                        Require(pixel[c] >= -0.00001f && pixel[c] <= pixel.a * 4 + 0.0001f,
                                            name + " emitted negative or non-premultiplied/overbright RGB.");
                                }
                                check?.Invoke(pixels);
                                if (parity.TryGetValue(name, out var reference)) CompareExact(reference, pixels, "Relight stability source/player " + name);
                                else parity.Add(name, pixels);
                                item.passed = true;
                            }
                            catch (Exception exception) { item.error = exception.ToString(); }
                            result.draws = drawResult.draws;
                            WriteStability(report);
                        }

                        const float lowOpacity = 1f / 128f;
                        void LowExposureHue(Material m)
                        {
                            m.SetFloat("_ColorExposure", -2);
                            m.SetFloat("_ColorHueShift", 1);
                        }
                        Case("black-low-opacity-hue-exposure", () => Draw(Vector3.zero, Color.black, lowOpacity, LowExposureHue),
                            pixels => Require(pixels.All(p => p.r == 0 && p.g == 0 && p.b == 0), "Black became visible RGB after hue/exposure."));
                        Case("grey-low-opacity-hue-exposure", () => Draw(Vector3.zero, Color.gray, lowOpacity, LowExposureHue),
                            pixels => Require(pixels.All(p => Mathf.Abs(p.r - p.a * 0.125f) < 0.00001f &&
                                Mathf.Abs(p.g - p.r) < 0.00001f && Mathf.Abs(p.b - p.r) < 0.00001f), "Neutral grey became a bright or coloured speck."));
                        Case("dark-low-opacity-hue-exposure", () => Draw(Vector3.zero, new Color(0.001f, 0.002f, 0.003f, 1), lowOpacity, LowExposureHue),
                            pixels => Require(pixels.All(p => Mathf.Max(p.r, Mathf.Max(p.g, p.b)) <= p.a * 0.0031f + 0.000001f), "Dark source produced a bright speck."));
                        Case("black-moved-eye", () => Draw(Vector3.zero, Color.black, lowOpacity, LowExposureHue, new Vector3(0.032f, 0, 0)),
                            pixels => Require(pixels.All(p => p.r == 0 && p.g == 0 && p.b == 0), "Black source changed with eye position."));

                        Case("inactive-point-at-origin", () => Draw(Vector3.zero, setup: m => fixture.SetPoint(m, default)),
                            pixels => CompareExact(origin, pixels, "Inactive point must not alter ambient"));
                        Case("zero-range-point-at-origin", () => Draw(Vector3.zero, setup: m => fixture.SetPoint(m,
                            new PointLight { color = Vector4.one, intensity = 1, range = 0, mode = 2 })),
                            pixels => CompareExact(origin, pixels, "Zero-range point must not alter ambient"));
                        void InvalidRedChannel(Color[] pixels)
                        {
                            for (int i = 0; i < pixels.Length; i++)
                                Require(pixels[i].r <= origin[i].r * 0.02f + 0.000001f &&
                                    Mathf.Abs(pixels[i].g - origin[i].g) < 0.000001f &&
                                    Mathf.Abs(pixels[i].b - origin[i].b) < 0.000001f,
                                    "Invalid red lighting channel flashed bright or contaminated valid channels.");
                        }
                        Case("nan-point-colour-channel", () => Draw(Vector3.zero, setup: m => fixture.SetPoint(m,
                            new PointLight { color = new Vector4(float.NaN, 0, 0, 1), intensity = 1, range = 4 })), InvalidRedChannel);
                        Case("infinite-point-colour-channel", () => Draw(Vector3.zero, setup: m => fixture.SetPoint(m,
                            new PointLight { color = new Vector4(float.PositiveInfinity, 0, 0, 1), intensity = 1, range = 4 })), InvalidRedChannel);
                        Case("inactive-spot-at-origin", () => Draw(Vector3.zero, setup: m => fixture.SetSpot(m, default)),
                            pixels => CompareExact(origin, pixels, "Inactive spot must not alter ambient"));
                        Case("zero-direction-spot", () => Draw(Vector3.up, setup: m => fixture.SetSpot(m,
                            new SpotLight { color = Vector4.one, intensity = 1, range = 4, innerCone = 0.9f, outerCone = 0.7f })),
                            pixels => CompareExact(above, pixels, "Invalid spot direction must not alter ambient"));
                        Case("zero-range-spot-at-origin", () => Draw(Vector3.zero, setup: m => fixture.SetSpot(m,
                            new SpotLight { color = Vector4.one, direction = new Vector4(0, 0, 1, 0), intensity = 1, innerCone = 0.9f, outerCone = 0.7f })),
                            pixels => CompareExact(origin, pixels, "Zero-range spot must not alter ambient"));

                        var upwardPlane = new PlanarLight { normal = new Vector4(0, 1, 0, 0), color = new Vector4(1, 0, 0, 1),
                            intensity = 1, range = 4, sizeX = 4, sizeY = 4 };
                        Case("upward-planar-inside-bounds", () => Draw(Vector3.up, setup: m => fixture.SetPlane(m, upwardPlane)),
                            pixels => Require(pixels.Sum(p => p.r) > above.Sum(p => p.r) * 1.2f &&
                                Mathf.Abs(pixels.Sum(p => p.g) - above.Sum(p => p.g)) < 0.001f,
                                "Upward-facing planar light did not illuminate its bounded front side."));
                        Case("upward-planar-outside-bounds", () => Draw(new Vector3(3, 1, 0), setup: m => fixture.SetPlane(m, upwardPlane)),
                            pixels => CompareExact(outside, pixels, "Planar light leaked outside bounds"));
                        Case("upward-planar-back-side", () => Draw(Vector3.down, setup: m => fixture.SetPlane(m, upwardPlane)),
                            pixels => CompareExact(below, pixels, "One-sided planar light leaked behind its plane"));
                        Case("zero-direction-directional", () => Draw(Vector3.up, setup: m => fixture.SetDirectional(m,
                            new DirectionalLight { color = Vector4.one, intensity = 1, range = 5, softness = 1, shadowStrength = 1 })),
                            pixels => CompareExact(above, pixels, "Invalid directional direction must not alter ambient"));
                        Case("zero-range-directional-at-origin", () => Draw(Vector3.zero, setup: m => fixture.SetDirectional(m,
                            new DirectionalLight { color = Vector4.one, direction = new Vector4(0, 1, 0, 0), intensity = 1 })),
                            pixels => CompareExact(origin, pixels, "Zero-range directional light must not alter ambient"));
                        Case("high-finite-intensity-directional-outside-range", () => Draw(Vector3.up, setup: m => fixture.SetDirectional(m,
                            new DirectionalLight { color = Vector4.one, direction = new Vector4(0, 1, 0, 0),
                                intensity = 10000000000f, range = 0.5f, softness = 0.1f })),
                            pixels => CompareExact(above, pixels, "A finite bright light outside its range must not overflow before attenuation"));
                        Case("high-finite-intensity-directional-inside-range", () => Draw(Vector3.up, setup: m => fixture.SetDirectional(m,
                            new DirectionalLight { color = new Vector4(1, 0, 0, 1), direction = new Vector4(0, 1, 0, 0),
                                intensity = 100000f, range = 5, softness = 1 })),
                            pixels =>
                            {
                                for (int i = 0; i < pixels.Length; i++)
                                    Require(Mathf.Abs(pixels[i].r - above[i].r * 4) < 0.00001f &&
                                        Mathf.Abs(pixels[i].g - above[i].g) < 0.000001f &&
                                        Mathf.Abs(pixels[i].b - above[i].b) < 0.000001f,
                                        "Bright finite red light did not retain its bounded red response.");
                            });
                        result.passed = result.cases.All(c => c.passed);
                        var errors = ShaderUtil.GetShaderMessages(shader).Where(m => m.severity == ShaderCompilerMessageSeverity.Error).ToArray();
                        Require(errors.Length == 0, path + ": " + string.Join("; ", errors.Select(m => m.message)));
                    }
                    finally { UnityEngine.Object.DestroyImmediate(material); }
                }
                int failures = report.shaders.Sum(s => s.cases.Count(c => !c.passed));
                Require(failures == 0, "Relight stability GPU regression cases failed: " + failures + ". See relight-stability-validation.json.");
                report.state = "passed";
                Debug.Log("SplatBox relight stability GPU PASS: dark/grey/black low-alpha grading, inactive/degenerate light data, upward planar bounds, finite premultiplied output and source/player parity.");
            }
            catch (Exception exception) { report.state = "failed"; report.error = exception.ToString(); throw; }
            finally { report.completedUtc = DateTime.UtcNow.ToString("O"); WriteStability(report); }
        }

        public static void Run()
        {
            var report = new Report { graphicsApi = SystemInfo.graphicsDeviceType.ToString() };
            Write(report);
            try
            {
                Require(SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat), "ARGBFloat rendering is required.");
                using var fixture = new Fixture();
                Color[] standardReference = null, relightReference = null;
                foreach (string path in new[] { "Resources/RenderSplats.shader", "Shaders/RenderGaussianSplats.shader",
                    "Resources/RenderSplatsRelight.shader", "Shaders/Relight/RenderGaussianSplats.shader" })
                {
                    var result = new ShaderResult { shader = path };
                    report.shaders.Add(result);
                    bool relight = path.Contains("Relight");
                    Shader shader = AssetDatabase.LoadAssetAtPath<Shader>(Root + path);
                    Require(shader != null && shader.isSupported, "Missing or unsupported production shader: " + path);
                    var material = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
                    try
                    {
                        CompileVariants(material);
                        fixture.Configure(material);
                        var far = new Vector3(0, 0, Distance + 0.01f);
                        Color[] gaussian = fixture.Draw(material, result, far, false);
                        ValidateGaussian(gaussian, path);
                        result.gaussianPixels = Coverage(gaussian);
                        CompareExact(gaussian, fixture.Draw(material, result, far, false, head: new Vector3(100, 0, 0)), path + " flag off");
                        CompareExact(gaussian, fixture.Draw(material, result, Vector3.zero, true), path + " near");
                        CompareExact(gaussian, fixture.Draw(material, result, new Vector3(0, 0, Distance), true), path + " exact boundary");
                        CompareExact(gaussian, fixture.Draw(material, result, far, true, head: new Vector3(0, 0, 0.02f)), path + " moved head near");

                        Color[] point4 = fixture.Draw(material, result, far, true);
                        result.point4Pixels = ValidateDisk(point4, 4, Opacity, path);
                        result.point3Pixels = ValidateDisk(fixture.Draw(material, result, far, true, size: 3), 3, Opacity, path);
                        result.point6Pixels = ValidateDisk(fixture.Draw(material, result, far, true, size: 6), 6, Opacity, path);
                        Require(result.point3Pixels < result.point4Pixels && result.point4Pixels < result.point6Pixels &&
                            result.gaussianPixels > result.point6Pixels * 8, "Point size or Gaussian footprint regression: " + path);
                        ValidateDisk(fixture.Draw(material, result, far, true, opacity: 0.125f), 4, 0.125f, path + " opacity");
                        CompareExact(point4, fixture.Draw(material, result, far, true, eyePosition: new Vector3(-0.032f, 0, 0)), path + " left-eye position");
                        CompareExact(point4, fixture.Draw(material, result, far, true, eyePosition: new Vector3(0.032f, 0, 0)), path + " right-eye position");
                        Require(Coverage(fixture.Draw(material, result, far, true, depthOccluded: true)) == 0, "Opaque depth did not hide distant point: " + path);
                        Require(Coverage(fixture.Draw(material, result, far, true, hidden: true)) == 0, "A compute-hidden distant splat reappeared: " + path);
                        Color[] selected = fixture.Draw(material, result, far, true, selected: true);
                        Require(Coverage(selected) == result.point4Pixels && selected.Max(c => c.a) > 0.99f,
                            "Selected point coverage/selection opacity changed: " + path);

                        if (relight)
                        {
                            Color[] lit = fixture.Draw(material, result, far, true, customLight: true);
                            float before = point4.Sum(c => c.r), after = lit.Sum(c => c.r);
                            Require(after > before * 1.7f && Coverage(lit) == Coverage(point4),
                                "Custom point lighting was bypassed for distant points: " + path);
                            result.relightResponds = true;
                            if (relightReference != null) CompareExact(relightReference, point4, "Relight source/player parity");
                            relightReference = point4;
                        }
                        else
                        {
                            if (standardReference != null) CompareExact(standardReference, point4, "Standard source/player parity");
                            standardReference = point4;
                        }
                        var errors = ShaderUtil.GetShaderMessages(shader).Where(m => m.severity == ShaderCompilerMessageSeverity.Error).ToArray();
                        Require(errors.Length == 0, path + ": " + string.Join("; ", errors.Select(m => m.message)));
                        result.passed = true;
                        Write(report);
                    }
                    finally { UnityEngine.Object.DestroyImmediate(material); }
                }
                report.state = "passed";
                Debug.Log("SplatBox distant point cloud GPU PASS: all four production shaders, Gaussian off/near/boundary parity, circular pixel diameters, source opacity, shared head position, depth/hidden/selection behavior and custom relight response.");
            }
            catch (Exception exception) { report.state = "failed"; report.error = exception.ToString(); throw; }
            finally { report.completedUtc = DateTime.UtcNow.ToString("O"); Write(report); }
        }

        static void CompileVariants(Material material)
        {
            foreach (string keyword in new[] { "", "STEREO_INSTANCING_ON", "STEREO_MULTIVIEW_ON" })
            {
                material.DisableKeyword("STEREO_INSTANCING_ON");
                material.DisableKeyword("STEREO_MULTIVIEW_ON");
                if (keyword.Length > 0) material.EnableKeyword(keyword);
                ShaderUtil.CompilePass(material, 0, true);
            }
            material.DisableKeyword("STEREO_INSTANCING_ON");
            material.DisableKeyword("STEREO_MULTIVIEW_ON");
        }

        sealed class Fixture : IDisposable
        {
            readonly GraphicsBuffer views = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, Marshal.SizeOf<ViewData>());
            readonly GraphicsBuffer uvs = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 32);
            readonly GraphicsBuffer selectedBits = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4);
            readonly GraphicsBuffer targetBits = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4);
            readonly GraphicsBuffer indices = new GraphicsBuffer(GraphicsBuffer.Target.Index, 6, 2);
            readonly GraphicsBuffer points = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 48);
            readonly GraphicsBuffer spots = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 80);
            readonly GraphicsBuffer directions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 64);
            readonly GraphicsBuffer planes = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 80);
            readonly GraphicsBuffer excludes = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 96);
            readonly RenderTexture target = new RenderTexture(Width, Height, 0, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear);
            readonly Texture2D readback = new Texture2D(Width, Height, TextureFormat.RGBAFloat, false, true);
            readonly Texture2D depth = new Texture2D(Width, Height, TextureFormat.RFloat, false, true);
            readonly RenderTexture previousTarget = RenderTexture.active;
            readonly Matrix4x4 previousView = Shader.GetGlobalMatrix("unity_MatrixV"), previousProjection = Shader.GetGlobalMatrix("unity_MatrixP");
            readonly Dictionary<string, Vector4> previousVectors = new Dictionary<string, Vector4>();
            static readonly string[] Keywords = { "STEREO_INSTANCING_ON", "STEREO_MULTIVIEW_ON", "_MAIN_LIGHT_SHADOWS",
                "_MAIN_LIGHT_SHADOWS_CASCADE", "_MAIN_LIGHT_SHADOWS_SCREEN", "_SHADOWS_SOFT", "_SHADOWS_SOFT_LOW",
                "_SHADOWS_SOFT_MEDIUM", "_SHADOWS_SOFT_HIGH", "_DEPTH_AS_INPUT_ATTACHMENT", "_DEPTH_AS_INPUT_ATTACHMENT_MSAA" };

            public Fixture()
            {
                foreach (string name in new[] { "_ScreenParams", "_ScaledScreenParams", "_ScreenSize", "_RTHandleScale",
                    "_ScaleBiasRt", "_ProjectionParams", "unity_OrthoParams", "_ZBufferParams", "_WorldSpaceCameraPos" })
                    previousVectors.Add(name, Shader.GetGlobalVector(name));
                indices.SetData(new ushort[] { 0, 1, 2, 1, 3, 2 });
                uvs.SetData(new Data32[1]); targetBits.SetData(new uint[1]);
                spots.SetData(new Data80[1]); directions.SetData(new Data64[1]); planes.SetData(new Data80[1]); excludes.SetData(new Data96[1]);
                var pixels = Enumerable.Repeat(new Color(0.5f, 0, 0, 1), Width * Height).ToArray();
                depth.SetPixels(pixels); depth.Apply(false);
                target.Create();
            }

            public void Configure(Material material)
            {
                material.SetBuffer("_SplatViewData", views); material.SetBuffer("_SplatMeshUvs", uvs);
                material.SetBuffer("_SplatSelectedBits", selectedBits); material.SetBuffer("_SplatTargetSelectedBits", targetBits);
                material.SetBuffer("_CustomPointLights", points); material.SetBuffer("_CustomSpotLights", spots);
                material.SetBuffer("_CustomDirectionalLights", directions); material.SetBuffer("_CustomPlanarLights", planes);
                material.SetBuffer("_SplatShadowExcludeVolumes", excludes);
                material.SetInt("_SplatCount", 1); material.SetInt("_SplatTightQuads", 0);
                material.SetInt("_MeshTexEnabled", 0); material.SetTexture("_MeshTex", Texture2D.whiteTexture);
                material.SetInt("_EquirectEnabled", 0); material.SetTexture("_EquirectTexture", Texture2D.whiteTexture);
                material.SetInt("_DecalEnabled", 0); material.SetTexture("_DecalTexture", Texture2D.whiteTexture);
                material.SetTexture("_GaussianSSAO", Texture2D.whiteTexture); material.SetFloat("_SSAOStrength", 0);
                material.SetTexture("_CameraDepthTexture", depth);
                material.SetVector("_CameraDepthTexture_TexelSize", new Vector4(1f / Width, 1f / Height, Width, Height));
                material.SetVector("_SplatRenderTargetSize", new Vector4(Width, Height, 1f / Width, 1f / Height));
                material.SetFloat("_LodDetailDistance", Distance);
                material.SetInt("_CustomPointLightCount", 0); material.SetInt("_CustomSpotLightCount", 0);
                material.SetInt("_CustomDirectionalLightCount", 0); material.SetInt("_CustomPlanarLightCount", 0);
                material.SetInt("_SplatShadowExcludeCount", 0);
                material.SetFloat("_AmbientIntensity", 1); material.SetFloat("_DirectionalIntensity", 0);
                material.SetFloat("_ShadowStrength", 0); material.SetFloat("_AmbientShadowStrength", 0);
                material.SetFloat("_AmbientShadowDistanceScale", 0); material.SetFloat("_SharpenStrength", 0);
                material.SetFloat("_ColorExposure", 0); material.SetFloat("_ColorContrast", 1);
                material.SetFloat("_ColorHueShift", 0); material.SetFloat("_ColorSaturation", 1);
                material.SetColor("_ColorFilter", Color.white);
                material.SetColor("_SelectionColor", Color.red); material.SetColor("_TargetSelectionColor", Color.green);
            }

            public Color[] Draw(Material material, ShaderResult result, Vector3 worldPos, bool enabled, float size = 4,
                Vector3? head = null, float opacity = Opacity, Vector3? eyePosition = null,
                bool depthOccluded = false, bool hidden = false, bool selected = false, bool customLight = false,
                Color? sourceColor = null, Action<Material> configureBeforeDraw = null)
            {
                Color source = sourceColor ?? new Color(0.25f, 0.5f, 0.75f, 1);
                views.SetData(new[] { new ViewData
                {
                    pos = new Vector4(0, 0, 0.5f, hidden ? 0 : 1), axis1 = Pack(10, 0), axis2 = Pack(0, 7),
                    color1 = Pack(source.r, source.g), color2 = Pack(source.b, opacity), worldPos = worldPos
                } });
                selectedBits.SetData(new uint[] { selected ? 1u : 0u });
                points.SetData(new[] { new PointLight { position = new Vector4(worldPos.x, worldPos.y, worldPos.z, 0),
                    color = new Vector4(1, 0, 0, 1), intensity = 1, range = 5 } });
                material.SetInt("_LodDistantPointCloud", enabled ? 1 : 0);
                material.SetVector("_LodCameraWorldPos", head ?? Vector3.zero);
                material.SetFloat("_SplatSize", size); material.SetInt("_SplatBitsValid", selected ? 1 : 0);
                material.SetInt("_SceneDepthOcclusion", depthOccluded ? 1 : 0);
                material.SetInt("_SceneDepthTextureValid", depthOccluded ? 1 : 0); material.SetFloat("_SceneDepthFade", 0.05f);
                material.SetInt("_CustomPointLightCount", customLight ? 1 : 0);
                configureBeforeDraw?.Invoke(material);
                using var cmd = new CommandBuffer { name = "Distant point cloud GPU validation" };
                var keywords = Keywords.ToDictionary(k => k, Shader.IsKeywordEnabled);
                foreach (string keyword in Keywords) cmd.DisableShaderKeyword(keyword);
                cmd.SetRenderTarget(target); cmd.SetViewport(new Rect(0, 0, Width, Height));
                cmd.ClearRenderTarget(false, true, Color.clear); cmd.SetViewProjectionMatrices(Matrix4x4.identity, Matrix4x4.identity);
                cmd.SetGlobalVector("_ScreenParams", new Vector4(Width, Height, 1 + 1f / Width, 1 + 1f / Height));
                cmd.SetGlobalVector("_ScaledScreenParams", new Vector4(Width, Height, 1 + 1f / Width, 1 + 1f / Height));
                cmd.SetGlobalVector("_ScreenSize", new Vector4(Width, Height, 1f / Width, 1f / Height));
                cmd.SetGlobalVector("_RTHandleScale", Vector4.one); cmd.SetGlobalVector("_ScaleBiasRt", new Vector4(1, 0, 1, 0));
                cmd.SetGlobalVector("_ProjectionParams", new Vector4(1, 0.1f, 100, 0.01f));
                cmd.SetGlobalVector("unity_OrthoParams", Vector4.zero);
                cmd.SetGlobalVector("_ZBufferParams", new Vector4(0, 0, 0, 2));
                Vector3 eye = eyePosition ?? Vector3.zero;
                cmd.SetGlobalVector("_WorldSpaceCameraPos", new Vector4(eye.x, eye.y, eye.z, 1));
                cmd.DrawProcedural(indices, Matrix4x4.identity, material, 0, MeshTopology.Triangles, 6, 1);
                foreach (var entry in keywords) if (entry.Value) cmd.EnableShaderKeyword(entry.Key);
                Graphics.ExecuteCommandBuffer(cmd);
                var active = RenderTexture.active;
                try
                {
                    RenderTexture.active = target;
                    readback.ReadPixels(new Rect(0, 0, Width, Height), 0, 0, false); readback.Apply(false);
                    result.draws++;
                    return readback.GetPixels();
                }
                finally { RenderTexture.active = active; }
            }

            public void SetPoint(Material material, PointLight light)
            {
                points.SetData(new[] { light });
                material.SetInt("_CustomPointLightCount", 1);
            }
            public void SetSpot(Material material, SpotLight light)
            {
                spots.SetData(new[] { light });
                material.SetInt("_CustomSpotLightCount", 1);
            }
            public void SetDirectional(Material material, DirectionalLight light)
            {
                directions.SetData(new[] { light });
                material.SetInt("_CustomDirectionalLightCount", 1);
            }
            public void SetPlane(Material material, PlanarLight light)
            {
                planes.SetData(new[] { light });
                material.SetInt("_CustomPlanarLightCount", 1);
            }

            public void Dispose()
            {
                using (var restore = new CommandBuffer { name = "Restore distant point validation globals" })
                {
                    restore.SetViewProjectionMatrices(previousView, previousProjection);
                    foreach (var entry in previousVectors) restore.SetGlobalVector(entry.Key, entry.Value);
                    Graphics.ExecuteCommandBuffer(restore);
                }
                RenderTexture.active = previousTarget;
                views.Dispose(); uvs.Dispose(); selectedBits.Dispose(); targetBits.Dispose(); indices.Dispose();
                points.Dispose(); spots.Dispose(); directions.Dispose(); planes.Dispose(); excludes.Dispose();
                target.Release(); UnityEngine.Object.DestroyImmediate(target);
                UnityEngine.Object.DestroyImmediate(readback); UnityEngine.Object.DestroyImmediate(depth);
            }
        }

        static void ValidateGaussian(Color[] pixels, string label)
        {
            int covered = 0;
            for (int y = 0; y < Height; y++) for (int x = 0; x < Width; x++)
            {
                float px = (x + 0.5f - Width * 0.5f) / 10f, py = (y + 0.5f - Height * 0.5f) / 7f;
                float expected = Mathf.Abs(px) <= 2 && Mathf.Abs(py) <= 2 ? Opacity * Mathf.Exp(-px * px - py * py) : 0;
                if (expected < 1f / 255f) expected = 0;
                float actual = pixels[y * Width + x].a;
                Require(!float.IsNaN(actual) && Mathf.Abs(actual - expected) <= 0.0015f, "Gaussian alpha changed: " + label);
                if (actual > 0) covered++;
            }
            Require(covered > 400, "Gaussian fixture failed to draw: " + label);
        }

        static int ValidateDisk(Color[] pixels, float diameter, float opacity, string label)
        {
            int covered = 0;
            float radius = diameter * 0.5f;
            for (int y = 0; y < Height; y++) for (int x = 0; x < Width; x++)
            {
                float dx = x + 0.5f - Width * 0.5f, dy = y + 0.5f - Height * 0.5f;
                float expected = dx * dx + dy * dy <= radius * radius ? opacity : 0;
                Color actual = pixels[y * Width + x];
                Require(!float.IsNaN(actual.a) && Mathf.Abs(actual.a - expected) < 0.001f,
                    $"Circular point footprint/opacity mismatch: {label}, diameter={diameter}, pixel={x},{y}, alpha={actual.a}, expected={expected}");
                if (actual.a > 0) covered++;
            }
            Require(covered > 0, "Point fixture failed to draw: " + label);
            return covered;
        }

        static void CompareExact(Color[] expected, Color[] actual, string label)
        {
            for (int i = 0; i < expected.Length; i++) for (int c = 0; c < 4; c++)
                Require(!float.IsNaN(actual[i][c]) && actual[i][c] == expected[i][c],
                    $"Pixel parity failed: {label}, pixel={i}, channel={c}, expected={expected[i][c]}, actual={actual[i][c]}");
        }
        static int Coverage(Color[] pixels) => pixels.Count(p => p.a > 0.0001f);
        static uint Pack(float high, float low) => ((uint)Mathf.FloatToHalf(high) << 16) | Mathf.FloatToHalf(low);
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        static void Write(Report report)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ReportPath));
            File.WriteAllText(ReportPath, JsonUtility.ToJson(report, true));
        }
        static void WriteStability(StabilityReport report)
        {
            string path = Path.Combine(Path.GetTempPath(), "SplatBox-quality-analysis", "relight-stability-validation.json");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, JsonUtility.ToJson(report, true));
        }
        static void WriteGrading(GradingReport report)
        {
            string path = Path.Combine(Path.GetTempPath(), "SplatBox-quality-analysis", "relight-grading-parity-validation.json");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, JsonUtility.ToJson(report, true));
        }
    }
}
