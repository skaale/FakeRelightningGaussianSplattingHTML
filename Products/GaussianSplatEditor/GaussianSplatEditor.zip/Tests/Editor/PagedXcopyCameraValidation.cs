// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using Unity.Collections.LowLevel.Unsafe;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    // Run in an isolated batch-mode project: this creates assets and replaces the open scene.
    public static class PagedXcopyCameraValidation
    {
        const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        struct View { public Vector4 clip; public uint a, b, c, d; public Vector3 world; public uint index; }
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Set(object instance, string name, object value) => instance.GetType().GetField(name, Flags).SetValue(instance, value);
        static object Call(object instance, string name, params object[] args) => instance.GetType().GetMethod(name, Flags).Invoke(instance, args);

        public static void Run()
        {
            Require(Application.isBatchMode, "Use an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null;
            GaussianSplatEditorWindow window = null;
            SceneView sceneView = null;
            GameObject cameraObject = null;
            RenderTexture target = null;
            string manifestPath = null;
            string scenePath = "Assets/__PagedXcopyCameras_" + Guid.NewGuid().ToString("N") + ".unity";
            var drawOrder = new List<SplatBoxRenderer>();
            Action<SplatBoxRenderer, CommandBuffer, MaterialPropertyBlock> capture = (renderer, command, properties) => drawOrder.Add(renderer);
            try
            {
                var fixtureType = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture", true);
                fixture = Activator.CreateInstance(fixtureType, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = (SplatBoxRenderer)fixtureType.GetField("renderer", Flags).GetValue(fixture);
                Require(source.ForceRebuildPagedLodInEditor(), "Source failed to initialize.");
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
                var holder = new GameObject("Xcopy camera validation brush"); holder.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatBoxBrush>(); brush.TargetRenderer = source;
                brush.BoxPosition = new Vector3(-0.1f, 0, 5); brush.BoxSize = Vector3.one * 0.1f;
                Set(window, "m_BoxBrush", brush); Set(window, "m_TargetRenderer", source);
                Call(window, "CopyPagedXcopy");
                brush.BoxPosition = new Vector3(-0.1f, 0, 4);
                Call(window, "PastePagedXcopy");
                var root = GameObject.Find("Editor cold-start recovery fixture Xcopy");
                Require(root != null, "Paged paste failed: " + window.GetType().GetField("m_PagedCopyMessage", Flags).GetValue(window));
                var copy = root.GetComponentInChildren<SplatBoxRenderer>();
                manifestPath = AssetDatabase.GetAssetPath(copy.pagedScene);
                copy.m_Cutouts[0].name = "Renamed copy boundary";
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save camera test scene.");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                var sourceObject = GameObject.Find("Editor cold-start recovery fixture");
                root = GameObject.Find("Editor cold-start recovery fixture Xcopy");
                Require(sourceObject != null && root != null, "Source or copy disappeared after reopening.");
                source = sourceObject.GetComponent<SplatBoxRenderer>();
                copy = root.GetComponentInChildren<SplatBoxRenderer>();
                Require(source.ForceRebuildPagedLodInEditor() && copy.ForceRebuildPagedLodInEditor(), "Reopened renderers failed to initialize.");
                source.m_ColorFilter = Color.red;
                copy.m_ColorFilter = Color.green;
                cameraObject = new GameObject("Xcopy test main camera"); cameraObject.tag = "MainCamera";
                var main = cameraObject.AddComponent<Camera>(); main.transform.position = new Vector3(-0.1f, 0, 0); main.farClipPlane = 200;
                target = new RenderTexture(640, 480, 0, RenderTextureFormat.ARGB32) { hideFlags = HideFlags.HideAndDontSave }; target.Create(); main.targetTexture = target;
                sceneView = ScriptableObject.CreateInstance<SceneView>(); sceneView.ShowUtility();
                sceneView.LookAtDirect(new Vector3(-0.1f, 0, 4), Quaternion.Euler(0, 180, 0), 4f);
                var scene = sceneView.camera; Require(scene != null, "Scene camera missing.");
                scene.targetTexture = target;
                scene.transform.SetPositionAndRotation(new Vector3(-0.1f, 0, 8), Quaternion.Euler(0, 180, 0));
                scene.ResetWorldToCameraMatrix();
                GaussianSplatRenderSystem.OnBeforeDrawSplatsForRenderer += capture;

                // Main looks away during selection. Scene must still see the one copied leaf:
                // the page root and its other leaf lie outside the copied box.
                main.transform.rotation = Quaternion.Euler(0, 180, 0);
                for (int i = 0; i < 5; ++i) copy.PreloadPagedLodPages(main);
                Require(copy.activeSplatCount == 1, "Copy did not refine its off-box coarse root when Main looked away.");
                Draw(scene, target, drawOrder);
                AssertVisible(copy, "Scene view with Main facing away");

                // Both cameras see the copy from opposite sides. Check view-buffer coverage and
                // the order in which the separate copy and original are submitted.
                main.transform.rotation = Quaternion.identity;
                copy.PreloadPagedLodPages(main);
                Draw(main, target, drawOrder);
                AssertVisible(copy, "Main camera");
                Require(drawOrder.IndexOf(copy) >= 0 && drawOrder.IndexOf(source) >= 0 &&
                    drawOrder.IndexOf(copy) < drawOrder.IndexOf(source), "Nearer copy was submitted behind the original.");
                var mainPixel = ReadCenter(target);
                Require(mainPixel.g > mainPixel.r, $"Nearer green copy did not appear in the Main camera pixel: {mainPixel}");

                // The editor normally keeps the original selected after pasting. A screen brush
                // over the paste must edit its separate renderer as well as the source.
                var eraseHolder = new GameObject("Xcopy erase validation brush"); eraseHolder.SetActive(false);
                var erase = eraseHolder.AddComponent<GaussianSplatBrush>();
                erase.TargetRenderer = source;
                erase.BackfaceCulling = true;
                Set(window, "m_EraseBrush", erase);
                Set(window, "m_TargetRenderer", source);
                Set(window, "m_EraseIncludePagedCopies", true);
                Vector2 brushCenter = new Vector2(target.width / 2f, target.height / 2f);
                Call(window, "ApplyEditorErase", brushCenter, brushCenter, 40f, 40f, main, false, false);
                Require(source.pagedLodEraseStrokeCount == 1 && copy.pagedLodEraseStrokeCount == 1,
                    "Screen erase did not reach both source and copied renderer.");
                Draw(main, target, drawOrder);
                AssertHidden(copy, "Erased copy");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                Require(source.pagedLodEraseStrokeCount == 0 && copy.pagedLodEraseStrokeCount == 0,
                    "Undo did not restore both renderers in one operation.");
                Draw(main, target, drawOrder); AssertVisible(copy, "Undo erased copy");
                Undo.PerformRedo();
                Require(source.pagedLodEraseStrokeCount == 1 && copy.pagedLodEraseStrokeCount == 1,
                    "Redo did not erase both renderers.");
                Draw(main, target, drawOrder); AssertHidden(copy, "Redo erased copy");
                Object.DestroyImmediate(eraseHolder);
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save erased copy.");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                source = GameObject.Find("Editor cold-start recovery fixture").GetComponent<SplatBoxRenderer>();
                copy = GameObject.Find("Editor cold-start recovery fixture Xcopy").GetComponentInChildren<SplatBoxRenderer>();
                main = GameObject.Find("Xcopy test main camera").GetComponent<Camera>();
                main.targetTexture = target;
                Require(source.pagedLodEraseStrokeCount == 1 && copy.pagedLodEraseStrokeCount == 1,
                    "Erase history did not persist for source and copy after reopen.");
                Require(source.ForceRebuildPagedLodInEditor() && copy.ForceRebuildPagedLodInEditor(), "Erased renderers failed to reopen.");
                for (int i = 0; i < 5; ++i) { source.PreloadPagedLodPages(main); copy.PreloadPagedLodPages(main); }
                source.m_ColorFilter = Color.red; copy.m_ColorFilter = Color.green;
                Draw(main, target, drawOrder); AssertHidden(copy, "Erased copy after reopen");
                eraseHolder = new GameObject("Xcopy erase validation brush"); eraseHolder.SetActive(false);
                erase = eraseHolder.AddComponent<GaussianSplatBrush>(); erase.TargetRenderer = source;
                erase.BackfaceCulling = true;
                Set(window, "m_EraseBrush", erase); Set(window, "m_TargetRenderer", source);
                Call(window, "ApplyEditorErase", brushCenter, brushCenter, 40f, 40f, main, true, false);
                Require(source.pagedLodEraseStrokeCount == 2 && copy.pagedLodEraseStrokeCount == 2,
                    "Screen restore did not reach both source and copy.");
                Draw(main, target, drawOrder);
                AssertVisible(copy, "Restored copy");
                Set(window, "m_EraseIncludePagedCopies", false);
                erase.BackfaceCulling = false;
                Call(window, "ApplyEditorErase", brushCenter, brushCenter, 40f, 40f, main, false, false);
                Require(source.pagedLodEraseStrokeCount == 3 && copy.pagedLodEraseStrokeCount == 2,
                    "Selected-renderer-only erase changed the copied renderer.");
                Draw(main, target, drawOrder);
                AssertVisible(copy, "Copy excluded from erase");
                source.ResetDeletedSplats(); copy.ResetDeletedSplats();
                Set(window, "m_TargetRenderer", copy);
                Set(window, "m_EraseIncludePagedCopies", true);
                Call(window, "ApplyEditorErase", brushCenter, brushCenter, 40f, 40f, main, false, false);
                Require(copy.pagedLodEraseStrokeCount == 1 && source.pagedLodEraseStrokeCount == 0,
                    "Erasing a selected copy changed its source or missed the copy.");
                Draw(main, target, drawOrder); AssertHidden(copy, "Directly selected copy");
                copy.ResetDeletedSplats(); Set(window, "m_TargetRenderer", source);
                using (var serial = new SerializedObject(copy))
                {
                    serial.FindProperty("m_PagedXcopySource").objectReferenceValue = null;
                    serial.FindProperty("m_PagedXcopyRoot").objectReferenceValue = null;
                    serial.ApplyModifiedPropertiesWithoutUndo();
                }
                Call(window, "ApplyEditorErase", brushCenter, brushCenter, 40f, 40f, main, false, false);
                Require(copy.pagedLodEraseStrokeCount == 1 && source.pagedLodEraseStrokeCount == 1,
                    "Erase missed a copy created before source tracking.");
                Draw(main, target, drawOrder); AssertHidden(copy, "Legacy copy");
                source.ResetDeletedSplats(); copy.ResetDeletedSplats();
                Draw(scene, target, drawOrder);
                AssertVisible(copy, "Scene view from opposite side");
                Require(drawOrder.IndexOf(copy) >= 0 && drawOrder.IndexOf(source) >= 0 &&
                    drawOrder.IndexOf(copy) < drawOrder.IndexOf(source), "Equal-layer copy was submitted behind the original.");
                var scenePixel = ReadCenter(target);
                Require(scenePixel.g > scenePixel.r, $"Equal-layer copy disappeared from the reverse angle: {scenePixel}");
                source.m_RenderOrder = copy.m_RenderOrder + 1;
                Draw(scene, target, drawOrder);
                Require(drawOrder.IndexOf(source) < drawOrder.IndexOf(copy), "Explicit higher source layer did not take priority.");
                scenePixel = ReadCenter(target);
                Require(scenePixel.r > scenePixel.g, $"Higher-layer source did not occlude the copy: {scenePixel}");
                source.m_RenderOrder = copy.m_RenderOrder;
                source.gameObject.SetActive(false);
                Vector3 center = copy.m_Cutouts[0].transform.position;
                foreach (Vector3 direction in new[] { Vector3.forward, Vector3.back, Vector3.left, Vector3.right })
                {
                    scene.transform.SetPositionAndRotation(center - direction * 4f, Quaternion.LookRotation(direction));
                    scene.ResetWorldToCameraMatrix();
                    Draw(scene, target, drawOrder);
                    AssertVisible(copy, "Scene view orbit " + direction);
                }
                // Copies made by the previous release have no dedicated boundary reference.
                // Keep those existing scenes working without requiring another paste.
                copy.m_Cutouts[0].name = "Xcopy boundary";
                using (var serialized = new SerializedObject(copy))
                {
                    serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = null;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                main.transform.rotation = Quaternion.Euler(0, 180, 0);
                copy.PreloadPagedLodPages(main);
                Require(copy.activeSplatCount == 1, "Existing copy without the new reference lost its boundary-aware selection.");
                Debug.Log("SplatBox paged Xcopy multi-camera coverage and scene reopen PASS");
            }
            finally
            {
                GaussianSplatRenderSystem.OnBeforeDrawSplatsForRenderer -= capture;
                if (sceneView != null) sceneView.Close();
                if (window != null) Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
                if (!string.IsNullOrEmpty(manifestPath)) AssetDatabase.DeleteAsset(manifestPath);
            }
        }

        static void Draw(Camera camera, RenderTexture target, List<SplatBoxRenderer> order)
        {
            order.Clear();
            using var cmd = new CommandBuffer { name = "Validate Xcopy camera" };
            cmd.SetRenderTarget(target); cmd.SetViewport(new Rect(0, 0, 640, 480));
            cmd.ClearRenderTarget(false, true, Color.clear);
            cmd.SetViewProjectionMatrices(camera.worldToCameraMatrix, GL.GetGPUProjectionMatrix(camera.projectionMatrix, true));
            cmd.SetGlobalVector("_ScreenParams", new Vector4(640, 480, 1 + 1f / 640, 1 + 1f / 480));
            cmd.SetGlobalVector("_SplatRenderTargetSize", new Vector4(640, 480, 1f / 640, 1f / 480));
            Require(GaussianSplatRenderSystem.instance.GatherSplatsForCamera(camera), "No renderers gathered.");
            Require(GaussianSplatRenderSystem.instance.SortAndRenderSplats(camera, cmd) != null, "No splat draw.");
            Graphics.ExecuteCommandBuffer(cmd);
        }

        public static void RunPagedClone()
        {
            Require(Application.isBatchMode, "Use an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GaussianSplatEditorWindow window = null; RenderTexture target = null;
            string cloneFolder = null;
            string scenePath = "Assets/__PagedClone_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var fixtureType = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture", true);
                fixture = Activator.CreateInstance(fixtureType, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = (SplatBoxRenderer)fixtureType.GetField("renderer", Flags).GetValue(fixture);
                Set(source, "m_UseRelightShader", true);
                Set(source, "m_LodFastEditorPreview", true);
                Require(source.ForceRebuildPagedLodInEditor(), "Source failed to initialize.");
                var cameraObject = new GameObject("Paged clone test camera") { tag = "MainCamera" }; var camera = cameraObject.AddComponent<Camera>(); camera.farClipPlane = 100;
                target = new RenderTexture(640, 480, 0, RenderTextureFormat.ARGB32) { hideFlags = HideFlags.HideAndDontSave }; target.Create(); camera.targetTexture = target;
                for (int i = 0; i < 10; i++)
                {
                    if (source.lodStreamer != null) Set(source.lodStreamer, "m_LastPageUploadFrame", -1);
                    source.PreloadPagedLodPages(camera);
                }
                Require(source.activeSplatCount > 0, "Source did not load its current LoD selection.");
                var cutObject = new GameObject("Clone test cutout"); cutObject.transform.position = new Vector3(-0.1f, 0, 5); cutObject.transform.localScale = Vector3.one * 0.04f;
                var cutout = cutObject.AddComponent<GaussianCutout>(); cutout.m_Type = GaussianCutout.Type.Box; source.m_Cutouts = new[] { cutout };
                source.EditDeleteSphere(new Vector3(0.1f, 0, 5), 0.04f);

                var worldPolygon = new[] { new Vector3(-1.2f,-0.3f,5), new Vector3(-1.2f,0.3f,5), new Vector3(1.2f,0.3f,5), new Vector3(1.2f,-0.3f,5) };
                var polygon = new Vector2[worldPolygon.Length];
                for (int i = 0; i < polygon.Length; i++) { var p = camera.WorldToViewportPoint(worldPolygon[i]); polygon[i] = new Vector2(p.x, p.y); }
                var originalCompute = (ComputeShader)typeof(SplatBoxRenderer).GetField("m_CSBoxUtil", Flags).GetValue(source);
                string packageRoot = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                var eligiblePositions = new List<Vector3>();
                foreach (string computePath in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    Set(source, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(packageRoot + "/" + computePath)); Call(source, "InitializeKernels");
                    using var gpu = new GraphicsBuffer(GraphicsBuffer.Target.Structured, source.activeSplatCount, UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>());
                    Require(source.ExportPagedClone(polygon, camera, 0.2f, gpu, out int selected) && selected > 0 && selected <= gpu.count,
                        computePath + " did not select visible paged splats.");
                    var entries = new GaussianSplatAssetCreator.InputSplatData[selected]; gpu.GetData(entries, 0, 0, selected);
                    foreach (var entry in entries)
                    {
                        Require(Vector3.Distance(entry.pos, new Vector3(-0.1f,0,5)) > 0.04f, computePath + " included a cutout splat.");
                        Require(Vector3.Distance(entry.pos, new Vector3(0.1f,0,5)) > 0.04f, computePath + " included an erased splat.");
                        eligiblePositions.Add(entry.pos);
                    }
                }
                Set(source, "m_CSBoxUtil", originalCompute); Call(source, "InitializeKernels");
                var holder = new GameObject("Paged clone test brush"); holder.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatCloneBrush>(); brush.TargetRenderer = source; brush.DepthOffset = 0.15f;
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window, "m_CloneBrush", brush); Set(window, "m_TargetRenderer", source);
                brush.AddVertex(new Vector3(-10,-0.2f,5)); brush.AddVertex(new Vector3(-10,0.2f,5)); brush.AddVertex(new Vector3(-9,0.2f,5));
                brush.FinishSourcePolygon(); brush.SetTargetPosition(brush.SourceCenter + Vector3.right);
                Call(window, "ExecuteCloneInEditor", camera);
                Require(GameObject.Find("Editor cold-start recovery fixture Clone") == null && brush.SourceVertices.Count == 3 &&
                    ((string)window.GetType().GetField("m_PagedCloneStatus", Flags).GetValue(window)).Contains("No visible"),
                    "An empty selection silently created a clone or cleared the polygon.");
                brush.ClearAll();
                brush.AddVertex(worldPolygon[0]); brush.AddVertex(worldPolygon[1]); brush.AddVertex(worldPolygon[2]);
                brush.FinishSourcePolygon(); brush.SetTargetPosition(brush.SourceCenter + Vector3.right);
                Call(window, "ExecuteCloneInEditor", camera);
                var root = GameObject.Find("Editor cold-start recovery fixture Clone");
                Require(root != null, "Clone did not create an object: " + window.GetType().GetField("m_PagedCloneStatus", Flags).GetValue(window));
                var copy = root.GetComponentInChildren<SplatBoxRenderer>();
                Require(copy != null && !copy.UsesPagedLod && copy.m_Asset != null && copy.activeSplatCount > 0, "Clone asset or renderer was not created.");
                string assetPath = AssetDatabase.GetAssetPath(copy.m_Asset); cloneFolder = System.IO.Path.GetDirectoryName(assetPath).Replace('\\', '/');
                var order = new List<SplatBoxRenderer>(); Draw(camera, target, order); AssertVisible(copy, "Paged Clone output");
                Require(source.usesRelightShader && copy.usesRelightShader, "Clone lost the configured Relight choice.");
                Require(!((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(source)).shader.name.Contains("Relight") &&
                    !((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(copy)).shader.name.Contains("Relight"),
                    "Clone did not match the source's standard fast preview shader.");
                var view = new View[copy.activeSplatCount]; ((GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(copy)).GetData(view);
                var sourceViews = new View[source.activeSplatCount];
                ((GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(source)).GetData(sourceViews);
                foreach (var entry in view) if (entry.clip.w > 0)
                {
                    Require(Mathf.Abs(entry.world.z - 5.15f) < 0.02f && entry.world.x < 1,
                        "Clone position, polygon or depth offset is wrong: " + entry.world);
                    bool matched = false;
                    foreach (var candidate in eligiblePositions)
                        if (Mathf.Abs(entry.world.x - (candidate.x + 1)) < 0.02f) { matched = true; break; }
                    Require(matched, "Cloned splat did not land at the requested target: " + entry.world);
                    bool matchedColor = false;
                    foreach (var original in sourceViews)
                        if (original.clip.w > 0 && Mathf.Abs(entry.world.x - (original.world.x + 1)) < 0.02f &&
                            Mathf.Abs(entry.world.z - (original.world.z + 0.15f)) < 0.02f)
                        {
                            for (int component = 0; component < 4; ++component)
                            {
                                uint originalPacked = component < 2 ? original.c : original.d;
                                uint copyPacked = component < 2 ? entry.c : entry.d;
                                int shift = (component % 2 == 0) ? 16 : 0;
                                int a = (int)((originalPacked >> shift) & 0xffff);
                                int b = (int)((copyPacked >> shift) & 0xffff);
                                Require(Math.Abs(a - b) <= 64, $"Clone changed source color component {component}: half {a} vs {b}.");
                            }
                            matchedColor = true;
                            break;
                        }
                    Require(matchedColor, "Could not compare a cloned splat with its source color.");
                }
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Require(GameObject.Find("Editor cold-start recovery fixture Clone") == null, "Undo did not remove clone.");
                Undo.PerformRedo(); root = GameObject.Find("Editor cold-start recovery fixture Clone"); Require(root != null, "Redo did not restore clone.");
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save clone scene.");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                root = GameObject.Find("Editor cold-start recovery fixture Clone"); Require(root != null, "Clone disappeared on reopen.");
                copy = root.GetComponentInChildren<SplatBoxRenderer>(); camera = GameObject.Find("Paged clone test camera").GetComponent<Camera>(); camera.targetTexture = target;
                Require(copy.m_Asset != null && copy.activeSplatCount > 0, "Clone asset did not survive reopening.");
                Draw(camera, target, order); AssertVisible(copy, "Reopened clone");
                source = GameObject.Find("Editor cold-start recovery fixture").GetComponent<SplatBoxRenderer>(); Set(window, "m_TargetRenderer", source);
                Call(copy, "EditorUpdate");
                Require(copy.usesRelightShader && !((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(copy)).shader.name.Contains("Relight"),
                    "Reopened clone did not preserve Relight and match fast preview.");
                Set(source, "m_LodFastEditorPreview", false); Call(source, "OnValidate"); Call(copy, "EditorUpdate");
                Require(((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(copy)).shader.name.Contains("Relight"),
                    "Clone did not switch to Relight when fast preview was disabled.");
                Set(source, "m_UseRelightShader", false); Call(source, "OnValidate"); Call(copy, "EditorUpdate");
                Require(!((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(copy)).shader.name.Contains("Relight"),
                    "Clone did not follow the source's standard shader choice.");
                Set(source, "m_UseRelightShader", true); Call(source, "OnValidate"); Call(copy, "EditorUpdate");
                Require(((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(copy)).shader.name.Contains("Relight"),
                    "Clone did not follow the source's Relight shader choice.");
                Set(source, "m_LodFastEditorPreview", true); Call(source, "OnValidate"); Call(copy, "EditorUpdate");
                Require(!((Material)typeof(SplatBoxRenderer).GetField("m_MatSplats", Flags).GetValue(copy)).shader.name.Contains("Relight"),
                    "Clone did not switch back to the standard fast preview.");
                Call(window, "ResetAllSplatEdits"); Require(root == null, "Reset all did not remove the Clone object.");
                Debug.Log("SplatBox paged Clone selection, target and reopen PASS");
            }
            finally
            {
                if (window != null) Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
                if (!string.IsNullOrEmpty(cloneFolder)) AssetDatabase.DeleteAsset(cloneFolder);
            }
        }

        public static void RunResetCloneAndMask()
        {
            Require(Application.isBatchMode, "Use an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GaussianSplatEditorWindow window = null; RenderTexture target = null;
            string cloneFolder = null;
            var manifests = new List<string>();
            string scenePath = "Assets/__ResetCloneMask_" + Guid.NewGuid().ToString("N") + ".unity";
            const string sourceName = "Editor cold-start recovery fixture";
            const string cloneName = sourceName + " Clone";
            const string copyName = sourceName + " Xcopy";
            try
            {
                var fixtureType = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture", true);
                fixture = Activator.CreateInstance(fixtureType, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = (SplatBoxRenderer)fixtureType.GetField("renderer", Flags).GetValue(fixture);
                Set(source, "m_UseRelightShader", true); Set(source, "m_LodFastEditorPreview", true);
                Require(source.ForceRebuildPagedLodInEditor(), "Reset source failed to initialize.");
                string sourceManifest = AssetDatabase.GetAssetPath(source.pagedScene);
                var camera = new GameObject("Reset validation camera") { tag = "MainCamera" }.AddComponent<Camera>();
                camera.farClipPlane = 100;
                target = new RenderTexture(640, 480, 0, RenderTextureFormat.ARGB32) { hideFlags = HideFlags.HideAndDontSave };
                target.Create(); camera.targetTexture = target;
                for (int i = 0; i < 10; ++i)
                {
                    if (source.lodStreamer != null) Set(source.lodStreamer, "m_LastPageUploadFrame", -1);
                    source.PreloadPagedLodPages(camera);
                }
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
                Set(window, "m_TargetRenderer", source);
                var brushHolder = new GameObject("Reset validation brushes"); brushHolder.SetActive(false);
                var cloneBrush = brushHolder.AddComponent<GaussianSplatCloneBrush>(); cloneBrush.TargetRenderer = source;
                Set(window, "m_CloneBrush", cloneBrush);
                cloneBrush.AddVertex(new Vector3(-1.2f,-0.3f,5)); cloneBrush.AddVertex(new Vector3(-1.2f,0.3f,5));
                cloneBrush.AddVertex(new Vector3(1.2f,0.3f,5)); cloneBrush.AddVertex(new Vector3(1.2f,-0.3f,5));
                cloneBrush.FinishSourcePolygon(); cloneBrush.SetTargetPosition(cloneBrush.SourceCenter + Vector3.right * 3);
                Call(window, "ExecuteCloneInEditor", camera);
                var cloneRoot = GameObject.Find(cloneName);
                Require(cloneRoot != null, "Reset fixture failed to create a real Clone output.");
                var clone = cloneRoot.GetComponentInChildren<SplatBoxRenderer>();
                string cloneAsset = AssetDatabase.GetAssetPath(clone.m_Asset);
                cloneFolder = System.IO.Path.GetDirectoryName(cloneAsset).Replace('\\', '/');
                var box = brushHolder.AddComponent<GaussianSplatBoxBrush>(); box.TargetRenderer = source;
                box.BoxPosition = new Vector3(0,0,5); box.BoxSize = new Vector3(3,1,1);
                Set(window, "m_BoxBrush", box); Call(window, "CopyPagedXcopy");
                box.BoxPosition = new Vector3(0,2,5); Call(window, "PastePagedXcopy");
                var copyRoot = GameObject.Find(copyName);
                Require(copyRoot != null, "Reset fixture failed to create a real Xcopy output.");
                var copy = copyRoot.GetComponentInChildren<SplatBoxRenderer>();
                manifests.Add(AssetDatabase.GetAssetPath(copy.pagedScene));
                var boundary = copy.m_Cutouts[0];

                var ownMask = new GameObject("Reset owned polygon").AddComponent<GaussianPolyMask>();
                ownMask.m_ShapeType = GaussianPolyMask.ShapeType.Box;
                ownMask.GenerateShape(new Vector3(-0.5f,0,5), Vector3.forward, 1);
                Set(window, "m_PolyMask", ownMask); Call(window, "ApplyMaskCutout");
                var sharedMask = new GameObject("Reset shared polygon").AddComponent<GaussianPolyMask>();
                sharedMask.m_ShapeType = GaussianPolyMask.ShapeType.Box;
                sharedMask.GenerateShape(new Vector3(10,0,5), Vector3.forward, 1);
                Set(window, "m_PolyMask", sharedMask); Call(window, "ApplyMaskCutout");
                var unrelatedObject = new GameObject("Reset unrelated renderer"); unrelatedObject.SetActive(false);
                var unrelated = unrelatedObject.AddComponent<SplatBoxRenderer>(); unrelated.enabled = false;
                unrelated.m_Cutouts = new GaussianCutout[] { sharedMask }; unrelatedObject.SetActive(true);
                Set(window, "m_PolyMask", ownMask);
                source.EditDeleteSphere(new Vector3(0.1f,0,5), 0.04f);
                Require(source.pagedLodEraseStrokeCount == 1, "Reset fixture did not record erasure.");
                Require(Array.IndexOf(clone.m_Cutouts, ownMask) >= 0 && Array.IndexOf(copy.m_Cutouts, ownMask) >= 0,
                    "Mask did not reach both generated copies.");
                cloneBrush.AddVertex(new Vector3(-1,-1,5)); cloneBrush.AddVertex(new Vector3(-1,1,5));
                cloneBrush.AddVertex(new Vector3(1,1,5)); cloneBrush.FinishSourcePolygon(); cloneBrush.SetTargetPosition(Vector3.one);
                // Isolate Reset's Undo group from the setup and previously created copies.
                Undo.FlushUndoRecordObjects(); Undo.ClearAll();
                Call(window, "ResetAllSplatEdits"); Undo.FlushUndoRecordObjects();
                Require(GameObject.Find(cloneName) == null && GameObject.Find(copyName) == null,
                    "Reset retained a masked Clone or Xcopy output.");
                Require((source.m_Cutouts == null || source.m_Cutouts.Length == 0) && source.pagedLodEraseStrokeCount == 0 && !ownMask.IsClosed,
                    "Reset did not clear its polygon references, polygon geometry and erased splats.");
                Require(sharedMask.IsClosed && unrelated.m_Cutouts.Length == 1 && unrelated.m_Cutouts[0] == sharedMask && !unrelated.enabled,
                    "Reset changed a polygon shared by an unrelated renderer.");
                Require(cloneBrush.SourceVertices.Count == 0 && !cloneBrush.HasTarget && cloneBrush.IsDrawingSource,
                    "Reset left a pending Clone source/target selection.");
                Require(source.enabled && source.usesRelightShader && AssetDatabase.GetAssetPath(source.pagedScene) == sourceManifest,
                    "Reset changed the renderer's enabled state, source asset or shader preference.");
                Require(AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(cloneAsset) != null &&
                    AssetDatabase.LoadAssetAtPath<GaussianSplatPagedScene>(manifests[0]) != null,
                    "Reset deleted generated assets needed by Undo or another saved scene.");

                Undo.PerformUndo();
                cloneRoot = GameObject.Find(cloneName); copyRoot = GameObject.Find(copyName);
                Require(cloneRoot != null && copyRoot != null && ownMask.IsClosed &&
                    source.pagedLodEraseStrokeCount == 1 && Array.IndexOf(source.m_Cutouts, ownMask) >= 0,
                    "One Undo did not restore copies, polygon and erasure together.");
                clone = cloneRoot.GetComponentInChildren<SplatBoxRenderer>(); copy = copyRoot.GetComponentInChildren<SplatBoxRenderer>();
                Require(Array.IndexOf(clone.m_Cutouts, ownMask) >= 0 && Array.IndexOf(copy.m_Cutouts, ownMask) >= 0 &&
                    Array.Exists(copy.m_Cutouts, value => value != null && value.m_Invert && value.name == "Xcopy boundary"),
                    "Undo did not restore the masked copy references and Xcopy boundary.");
                Undo.PerformRedo();
                Require(GameObject.Find(cloneName) == null && GameObject.Find(copyName) == null && !ownMask.IsClosed &&
                    (source.m_Cutouts == null || source.m_Cutouts.Length == 0) && source.pagedLodEraseStrokeCount == 0,
                    "Redo did not reset Clone, Xcopy, Mask and Erase together.");
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save reset scene.");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                source = GameObject.Find(sourceName).GetComponent<SplatBoxRenderer>();
                ownMask = GameObject.Find("Reset owned polygon").GetComponent<GaussianPolyMask>();
                sharedMask = GameObject.Find("Reset shared polygon").GetComponent<GaussianPolyMask>();
                unrelated = GameObject.Find("Reset unrelated renderer").GetComponent<SplatBoxRenderer>();
                Require(GameObject.Find(cloneName) == null && GameObject.Find(copyName) == null && !ownMask.IsClosed &&
                    (source.m_Cutouts == null || source.m_Cutouts.Length == 0) && source.pagedLodEraseStrokeCount == 0 && source.usesRelightShader,
                    "Clone, Mask or Erase edits returned after reopening a reset scene.");
                Require(sharedMask.IsClosed && unrelated.m_Cutouts[0] == sharedMask && !unrelated.enabled,
                    "Unrelated shared mask changed after reopening the reset scene.");
                camera = GameObject.Find("Reset validation camera").GetComponent<Camera>(); camera.targetTexture = target;
                Require(source.ForceRebuildPagedLodInEditor(), "Reopened reset renderer failed to initialize.");
                for (int i = 0; i < 10; ++i)
                {
                    if (source.lodStreamer != null) Set(source.lodStreamer, "m_LastPageUploadFrame", -1);
                    source.PreloadPagedLodPages(camera);
                }
                Draw(camera, target, new List<SplatBoxRenderer>()); AssertVisible(source, "Reset scene reopened");
                var resetViews = new View[source.activeSplatCount];
                ((GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(source)).GetData(resetViews);
                bool erasedRestored = false, maskedRestored = false;
                foreach (var view in resetViews)
                    if (view.clip.w > 0)
                    {
                        erasedRestored |= Vector3.Distance(view.world, new Vector3(0.1f,0,5)) < 0.01f;
                        maskedRestored |= Vector3.Distance(view.world, new Vector3(-0.1f,0,5)) < 0.01f;
                    }
                Require(erasedRestored && maskedRestored, "Previously erased/masked geometry stayed hidden after saving and reopening the reset scene.");

                // Resetting a selected Xcopy edits that copy, retaining the boundary that defines it.
                brushHolder = new GameObject("Selected copy reset brushes"); brushHolder.SetActive(false);
                box = brushHolder.AddComponent<GaussianSplatBoxBrush>(); box.TargetRenderer = source;
                box.BoxPosition = new Vector3(0,0,5); box.BoxSize = new Vector3(3,1,1);
                Set(window, "m_BoxBrush", box); Set(window, "m_TargetRenderer", source);
                Set(window, "m_CloneBrush", null); Set(window, "m_PolyMask", null);
                Call(window, "CopyPagedXcopy"); box.BoxPosition = new Vector3(0,2,5); Call(window, "PastePagedXcopy");
                copyRoot = GameObject.Find(copyName); Require(copyRoot != null, "Could not create selected-copy reset fixture.");
                copy = copyRoot.GetComponentInChildren<SplatBoxRenderer>(); boundary = copy.m_Cutouts[0];
                manifests.Add(AssetDatabase.GetAssetPath(copy.pagedScene));
                ownMask.GenerateShape(new Vector3(0,2,5), Vector3.forward, 1);
                Set(window, "m_TargetRenderer", copy); Set(window, "m_PolyMask", ownMask); Call(window, "ApplyMaskCutout");
                source.EditDeleteSphere(new Vector3(0.1f,0,5), 0.04f);
                copy.EditDeleteSphere(new Vector3(0.1f,2,5), 0.04f);
                Require(copy.pagedLodEraseStrokeCount == 1 && source.pagedLodEraseStrokeCount == 1, "Selected-copy erase fixture failed.");
                Call(window, "ResetAllSplatEdits");
                Require(copyRoot != null && copy.m_Cutouts.Length == 1 && copy.m_Cutouts[0] == boundary &&
                    boundary.m_Invert && copy.pagedLodEraseStrokeCount == 0 && !ownMask.IsClosed,
                    "Resetting an Xcopy removed its copy boundary or retained polygon/erase edits.");
                Require(source.pagedLodEraseStrokeCount == 1, "Resetting a selected copy changed its source's erase history.");
                source.enabled = false; Set(window, "m_TargetRenderer", source);
                Call(window, "ResetAllSplatEdits");
                Require(!source.enabled && source.pagedLodEraseStrokeCount == 0 && source.usesRelightShader,
                    "Reset enabled a disabled renderer or changed its shader preference.");
                Debug.Log("SplatBox Reset Clone and Mask PASS: masked Clone/Xcopy removal, polygon/erase reset, shared-mask isolation, source settings, single Undo/Redo, saved reset scene and selected-copy boundary.");
            }
            finally
            {
                if (window != null) Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
                foreach (var path in manifests) AssetDatabase.DeleteAsset(path);
                if (!string.IsNullOrEmpty(cloneFolder)) AssetDatabase.DeleteAsset(cloneFolder);
            }
        }

        public static void RunPagedCloneDepth()
        {
            Require(Application.isBatchMode, "Use an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null;
            try
            {
                var fixtureType = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture", true);
                fixture = Activator.CreateInstance(fixtureType, Flags, null, new object[] { true }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = (SplatBoxRenderer)fixtureType.GetField("renderer", Flags).GetValue(fixture);
                var cameraObject = new GameObject("Clone depth camera") { tag = "MainCamera" }; var camera = cameraObject.AddComponent<Camera>(); camera.farClipPlane = 100;
                Require(source.ForceRebuildPagedLodInEditor(), "Depth test source did not initialize.");
                for (int i = 0; i < 10; i++) { if (source.lodStreamer != null) Set(source.lodStreamer, "m_LastPageUploadFrame", -1); source.PreloadPagedLodPages(camera); }
                Require(source.activeSplatCount >= 3, "Depth test source did not select overlapping pages.");
                var polygon = new[] { new Vector2(0.35f,0.35f), new Vector2(0.35f,0.65f), new Vector2(0.65f,0.65f), new Vector2(0.65f,0.35f) };
                string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    Set(source, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(root + "/" + path)); Call(source, "InitializeKernels");
                    using var buffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, source.activeSplatCount, UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>());
                    Require(source.ExportPagedClone(polygon, camera, 0.2f, buffer, out int frontCount) && frontCount > 0, "No front layer selected: " + path);
                    var front = new GaussianSplatAssetCreator.InputSplatData[frontCount]; buffer.GetData(front, 0, 0, frontCount);
                    foreach (var splat in front) Require(Mathf.Abs(splat.pos.z - 4) < 0.01f, "Thin depth selected a hidden layer: " + splat.pos);
                    Require(source.ExportPagedClone(polygon, camera, 2.01f, buffer, out int deepCount) && deepCount > frontCount, "Larger depth did not include deeper splats: " + path);
                    using var tinyBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>());
                    Require(source.ExportPagedClone(polygon, camera, 2.01f, tinyBuffer, out int overflowCount) && overflowCount == deepCount,
                        "Clone capacity overflow was not reported accurately: " + path);
                }
                Debug.Log("SplatBox paged Clone surface depth PASS");
            }
            finally
            {
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
            }
        }

        public static void RunPolygonMaskScene()
        {
            Require(Application.isBatchMode, "Use an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GaussianSplatEditorWindow window = null; RenderTexture target = null;
            string scenePath = "Assets/__PolygonMaskScene_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var fixtureType = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture", true);
                fixture = Activator.CreateInstance(fixtureType, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = (SplatBoxRenderer)fixtureType.GetField("renderer", Flags).GetValue(fixture);
                Require(source.ForceRebuildPagedLodInEditor(), "Mask test source failed to initialize.");
                var cameraObject = new GameObject("Polygon mask test camera") { tag = "MainCamera" };
                var camera = cameraObject.AddComponent<Camera>(); camera.farClipPlane = 100;
                target = new RenderTexture(640, 480, 0, RenderTextureFormat.ARGB32) { hideFlags = HideFlags.HideAndDontSave };
                target.Create(); camera.targetTexture = target;
                for (int i = 0; i < 10; ++i)
                {
                    if (source.lodStreamer != null) Set(source.lodStreamer, "m_LastPageUploadFrame", -1);
                    source.PreloadPagedLodPages(camera);
                }
                var mask = new GameObject("Saved polygon mask").AddComponent<GaussianPolyMask>();
                Set(mask, "m_ExpansionX", 1f); Set(mask, "m_ExpansionY", 1f); Set(mask, "m_CutDepth", 0.4f);
                mask.StartDrawing(new Vector3(-1.2f,-0.3f,5), Vector3.forward);
                mask.AddVertex3D(new Vector3(-1.2f,0.3f,5)); mask.AddVertex3D(new Vector3(0,0.3f,5));
                mask.AddVertex3D(new Vector3(0,-0.3f,5)); mask.ClosePath();
                source.EditDeleteSphere(new Vector3(0.1f,0,5), 0.04f);
                var previousAtlas = typeof(SplatBoxRenderer).GetField("m_GpuLodUnifiedPos", Flags).GetValue(source);
                var unrelated = new GameObject("Unrelated mask renderer"); unrelated.SetActive(false);
                var unrelatedRenderer = unrelated.AddComponent<SplatBoxRenderer>();
                unrelatedRenderer.enabled = false; unrelated.SetActive(true);
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
                Set(window, "m_TargetRenderer", source); Set(window, "m_PolyMask", mask);
                Call(window, "ApplyMaskCutout");
                Require(source.m_Cutouts != null && Array.IndexOf(source.m_Cutouts, mask) >= 0, "Mask UI did not attach to its selected renderer.");
                Require(unrelatedRenderer.m_Cutouts == null || unrelatedRenderer.m_Cutouts.Length == 0,
                    "Mask UI changed an unrelated scene renderer.");
                Require(!unrelatedRenderer.enabled, "Mask UI enabled an unrelated disabled renderer.");
                Require(ReferenceEquals(previousAtlas, typeof(SplatBoxRenderer).GetField("m_GpuLodUnifiedPos", Flags).GetValue(source)),
                    "Applying the mask unnecessarily recreated the paged atlas.");
                Require(source.pagedLodEraseStrokeCount == 1, "Applying the mask reset the erase journal.");
                var order = new List<SplatBoxRenderer>();
                Draw(camera, target, order);
                AssertMaskSceneVisibleRange(source, true, "Applied mask");
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save mask scene.");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                source = GameObject.Find("Editor cold-start recovery fixture").GetComponent<SplatBoxRenderer>();
                camera = GameObject.Find("Polygon mask test camera").GetComponent<Camera>(); camera.targetTexture = target;
                mask = GameObject.Find("Saved polygon mask").GetComponent<GaussianPolyMask>();
                Require(mask.IsClosed && source.pagedLodEraseStrokeCount == 1 && Array.IndexOf(source.m_Cutouts, mask) >= 0,
                    "Mask or erase journal disappeared after scene reopen.");
                Require(source.ForceRebuildPagedLodInEditor(), "Reopened mask renderer failed to initialize.");
                for (int i = 0; i < 10; ++i)
                {
                    if (source.lodStreamer != null) Set(source.lodStreamer, "m_LastPageUploadFrame", -1);
                    source.PreloadPagedLodPages(camera);
                }
                Draw(camera, target, order); AssertMaskSceneVisibleRange(source, true, "Reopened mask");
                mask.Clear();
                Draw(camera, target, order); AssertMaskSceneVisibleRange(source, false, "Cleared reopened mask");
                Require(source.pagedLodEraseStrokeCount == 1, "Clearing a mask reset independent erase edits.");
                source.EditRestoreSphere(new Vector3(0.1f,0,5), 0.04f);
                Draw(camera, target, order); AssertVisible(source, "Restored mask scene");
                var views = new View[source.activeSplatCount];
                ((GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(source)).GetData(views);
                bool restored = false;
                foreach (var view in views) if (view.clip.w > 0 && Vector3.Distance(view.world, new Vector3(0.1f,0,5)) < 0.01f) restored = true;
                Require(restored, "Restore after reopening did not reveal the independently erased splat.");
                Debug.Log("SplatBox Polygon Mask scene/UI PASS: selected renderer only, no atlas restart, preserved erase/restore and save/reopen visibility.");
            }
            finally
            {
                if (window != null) Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
            }
        }

        static void AssertMaskSceneVisibleRange(SplatBoxRenderer source, bool masked, string label)
        {
            var views = new View[source.activeSplatCount];
            ((GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(source)).GetData(views);
            int visible = 0; bool leftVisible = false;
            foreach (var view in views)
            {
                if (view.clip.w <= 0) continue;
                ++visible;
                Require(Vector3.Distance(view.world, new Vector3(0.1f,0,5)) > 0.04f, label + " ignored the erase journal.");
                if (view.world.x < 0) leftVisible = true;
                if (masked) Require(view.world.x > 0.2f, label + " left a masked splat visible.");
            }
            Require(visible > 0 && (masked || leftVisible), label + " failed to preserve visible geometry.");
        }

        public static void RunComputeKernelAvailability()
        {
            string packageRoot = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
            string[] kernels = { "CSCalcViewData", "CSApplyPagedErase", "CSCloneFindDepth", "CSCloneExport",
                "CSPaintSplatBatch", "CSPaintSplatsGPU", "CSPaintSplatsFromTexture", "CSSmudgeSplats",
                "CSPinchSplats", "CSFlattenSplats", "CSRelaxSplats", "CSRestorePositionsInSphere",
                "CSApplyPagedSmudge", "CSClearPagedSmudge" };
            foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
            {
                var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(packageRoot + "/" + path);
                Require(shader != null, "Missing compute shader " + path);
                foreach (string kernel in kernels) Require(shader.HasKernel(kernel), path + " is missing kernel " + kernel);
            }
            Debug.Log("SplatBox compute kernel declarations PASS");
        }

        public static void RunCloneLayout()
        {
            Require(Application.isBatchMode, "Use an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            {
                if (message.Contains("Invalid GUILayout state") || message.Contains("Getting control") || message.Contains("ImmediateModeException"))
                    errors.Add(message);
            };
            Application.logMessageReceived += observe;
            GaussianSplatEditorWindow window = null;
            try
            {
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); window.ShowUtility();
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.CloneBrush); Set(window, "m_ShowToolSettings", true);
                window.SendEvent(new Event { type = EventType.Layout }); window.SendEvent(new Event { type = EventType.Repaint });
                Require(window.GetType().GetField("m_CloneBrush", Flags).GetValue(window) != null, "Clone settings did not initialize.");
                // Simulate a Scene-view tool switch after layout but before the window repaint.
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.PolyMask);
                window.SendEvent(new Event { type = EventType.Repaint });
                window.SendEvent(new Event { type = EventType.Layout }); window.SendEvent(new Event { type = EventType.Repaint });
                Require(window.GetType().GetField("m_PolyMask", Flags).GetValue(window) != null, "Mask settings did not initialize.");
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.CloneBrush);
                window.SendEvent(new Event { type = EventType.Repaint });
                window.SendEvent(new Event { type = EventType.Layout }); window.SendEvent(new Event { type = EventType.Repaint });
                Require(errors.Count == 0, "Tool switch caused a GUILayout error: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Clone and Mask layout PASS");
            }
            finally
            {
                if (window != null) window.Close();
                Application.logMessageReceived -= observe;
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            }
        }

        static void AssertVisible(SplatBoxRenderer renderer, string label)
        {
            var buffer = (GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(renderer);
            var views = new View[renderer.activeSplatCount];
            if (views.Length > 0) buffer.GetData(views, 0, 0, views.Length);
            int visible = 0;
            foreach (var view in views) if (view.clip.w > 0) visible++;
            Require(visible > 0, label + " lost the copied splat.");
        }

        static void AssertHidden(SplatBoxRenderer renderer, string label)
        {
            var buffer = (GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView", Flags).GetValue(renderer);
            var views = new View[renderer.activeSplatCount];
            if (views.Length > 0) buffer.GetData(views, 0, 0, views.Length);
            foreach (var view in views) Require(view.clip.w <= 0, label + " remained visible.");
        }

        static Color ReadCenter(RenderTexture target)
        {
            var previous = RenderTexture.active;
            var pixel = new Texture2D(1, 1, TextureFormat.RGBA32, false, true);
            try
            {
                RenderTexture.active = target;
                pixel.ReadPixels(new Rect(target.width / 2, target.height / 2, 1, 1), 0, 0, false);
                pixel.Apply(false);
                return pixel.GetPixel(0, 0);
            }
            finally { RenderTexture.active = previous; Object.DestroyImmediate(pixel); }
        }
    }
}
