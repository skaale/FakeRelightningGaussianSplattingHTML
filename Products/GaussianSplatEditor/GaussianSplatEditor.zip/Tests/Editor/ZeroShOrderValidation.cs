using System;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    /// <summary>SH-free captures must retain identical colour when their unused SH work is skipped.</summary>
    public static class ZeroShOrderValidation
    {
        [MenuItem("Tools/Gaussian Splatting/Validate Zero SH Order")]
        public static void Run()
        {
            Require(SystemInfo.supportsComputeShaders, "Zero-SH validation needs a graphics device.");
            string root = UnityEditor.PackageManager.PackageInfo
                .FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";
            Validate(root + "Tests/Editor/CompareResourceSH.compute");
            Validate(root + "Tests/Editor/CompareSourceSH.compute");
            Debug.Log("SplatBox zero-SH validation PASS: exact colour/opacity parity for SH orders 0 and 3, " +
                      "Norm11 and Norm6, both compute shader copies and eight view directions.");
        }

        static void Validate(string path)
        {
            var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
            Require(shader != null, "Missing comparison compute shader: " + path);
            int kernel = shader.FindKernel("CompareSH");
            using var pos = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 3, 4);
            using var other = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 8, 4);
            using var sh = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 48, 4);
            using var chunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 64);
            using var remap = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 4);
            using var pagedColors = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 16);
            using var result = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 24, 16);
            var color = new Texture2D(1, 1, TextureFormat.RGBAFloat, false, true);
            try
            {
                pos.SetData(new float[] { 0.1f, 0.2f, 0.3f });
                other.SetData(new uint[8]);
                sh.SetData(new uint[48]);
                remap.SetData(new uint[] { 0 });
                pagedColors.SetData(new[] { Vector4.zero });
                uint zeroShRange = (uint)Mathf.FloatToHalf(0.00001f) << 16;
                chunks.SetData(new[] { new GaussianSplatAsset.ChunkInfo
                {
                    colR = 0x3c000000, colG = 0x3c000000, colB = 0x3c000000, colA = 0x3c000000,
                    sclX = 0x3c000000, sclY = 0x3c000000, sclZ = 0x3c000000,
                    shR = zeroShRange, shG = zeroShRange, shB = zeroShRange
                } });
                color.SetPixel(0, 0, new Color(0.6f, 0.5f, 0.4f, 0.7f));
                color.Apply();
                shader.SetBuffer(kernel, "_SplatPos", pos);
                shader.SetBuffer(kernel, "_SplatOther", other);
                shader.SetBuffer(kernel, "_SplatSH", sh);
                shader.SetBuffer(kernel, "_SplatChunks", chunks);
                shader.SetBuffer(kernel, "_SplatIndexRemap", remap);
                shader.SetBuffer(kernel, "_PagedColorOverrides", pagedColors);
                shader.SetInt("_PagedColorOverridesValid", 0);
                shader.SetTexture(kernel, "_SplatColor", color);
                shader.SetBuffer(kernel, "_TestResults", result);
                shader.SetInt("_UseSplatIndexRemap", 1);
                shader.SetInt("_SplatSHDataValid", 1);
                shader.SetInt("_SplatChunkCount", 1);

                var fullOrder = new Vector4[24];
                var zeroOrder = new Vector4[24];
                foreach (var format in new[] { GaussianSplatAsset.SHFormat.Norm11, GaussianSplatAsset.SHFormat.Norm6 })
                {
                    shader.SetInt("_SplatFormat", (int)format << 16);
                    shader.SetInt("_TestOrder", 3);
                    shader.Dispatch(kernel, 8, 1, 1);
                    result.GetData(fullOrder);
                    shader.SetInt("_TestOrder", 0);
                    shader.Dispatch(kernel, 8, 1, 1);
                    result.GetData(zeroOrder);
                    for (int i = 0; i < fullOrder.Length; i += 3)
                    {
                        Require(fullOrder[i].x > 0.5f && fullOrder[i].w > 0.6f,
                            $"Invalid colour/opacity fixture in {path}, format {format}.");
                        Require(ExactlyEqual(fullOrder[i], fullOrder[i + 1]) &&
                                ExactlyEqual(zeroOrder[i], zeroOrder[i + 1]) &&
                                ExactlyEqual(fullOrder[i], zeroOrder[i + 1]),
                            $"Zero-SH colour/opacity changed in {path}, format {format}, direction {i / 3}: " +
                            $"order3={fullOrder[i]:R}, order0={zeroOrder[i + 1]:R}.");
                        Require(fullOrder[i + 2].sqrMagnitude == 0 && zeroOrder[i + 2].sqrMagnitude == 0,
                            $"Zero-SH load paths differ in {path}, format {format}.");
                    }
                }
            }
            finally { UnityEngine.Object.DestroyImmediate(color); }
        }

        static bool ExactlyEqual(Vector4 left, Vector4 right) =>
            left.x == right.x && left.y == right.y && left.z == right.z && left.w == right.w;

        static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
