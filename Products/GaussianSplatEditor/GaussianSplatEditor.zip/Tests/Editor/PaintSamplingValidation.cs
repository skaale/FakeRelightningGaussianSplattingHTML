// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    public static class PaintSamplingValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object value, string field) => (T)value.GetType().GetField(field, Flags).GetValue(value);
        static void Set(object value, string field, object data) => value.GetType().GetField(field, Flags).SetValue(value, data);
        static object Call(object value, string method, params object[] args) => value.GetType().GetMethod(method, Flags).Invoke(value, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static uint Norm11(Vector3 v) => (uint)Mathf.RoundToInt(v.x*2047) | ((uint)Mathf.RoundToInt(v.y*1023)<<11) | ((uint)Mathf.RoundToInt(v.z*2047)<<21);

        static void Sampling(string shaderPath, bool paged, bool compressed)
        {
            var type = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
            object fixture = Activator.CreateInstance(type, Flags, null, new object[] { shaderPath, paged }, null);
            GameObject cutoutObject = null;
            string context = shaderPath + ", paged=" + paged + ", compressed=" + compressed;
            try
            {
                var renderer = Get<SplatBoxRenderer>(fixture,"renderer");
                var owner = Get<GameObject>(fixture,"owner"); owner.transform.SetPositionAndRotation(Vector3.zero,Quaternion.identity);
                var camera = Get<Camera>(fixture,"camera");
                camera.transform.SetPositionAndRotation(Vector3.zero,Quaternion.identity);
                var expectedColor = new Color(.6f,.4f,.2f,.8f);
                float expectedDepth = 3;
                if (compressed)
                {
                    var asset = Get<GaussianSplatAsset>(fixture,"asset");
                    asset.Initialize(128,GaussianSplatAsset.VectorFormat.Norm11,GaussianSplatAsset.VectorFormat.Norm11,
                        GaussianSplatAsset.ColorFormat.Norm8x4,GaussianSplatAsset.SHFormat.Norm6,Vector3.one*-10,Vector3.one*10,null);
                    var payload = Get<TextAsset>(fixture,"data"); asset.SetAssetFiles(payload,payload,payload,payload,payload);
                    var positions = new uint[128]; var others = new uint[256];
                    for(int i=0;i<128;++i) { positions[i]=Norm11(new Vector3(.9f,.9f,.9f)); others[i*2]=0xE0080200u; others[i*2+1]=Norm11(Vector3.one*.5f); }
                    positions[32]=Norm11(new Vector3(.5f,.5f,.3f)); positions[33]=Norm11(new Vector3(.5f,.5f,.5f));
                    Get<GraphicsBuffer>(fixture,"pos").SetData(positions); Get<GraphicsBuffer>(fixture,"other").SetData(others);
                    var chunk = new GaussianSplatAsset.ChunkInfo { posX=new float2(-10,10),posY=new float2(-10,10),posZ=new float2(0,10),
                        colR=HalfRange(.1f,.9f),colG=HalfRange(.2f,.6f),colB=HalfRange(.3f,.7f),colA=HalfRange(.2f,.8f),
                        sclX=HalfRange(.5f,1),sclY=HalfRange(.5f,1),sclZ=HalfRange(.5f,1) };
                    Get<GraphicsBuffer>(fixture,"chunks").SetData(new[]{chunk}); Set(renderer,"m_GpuChunksValid",true);
                    if(paged)
                    {
                        // Real compressed paged atlases publish both their chunk buffer and
                        // its count. The synthetic base fixture normally has no compression.
                        Set(renderer,"m_GpuLodUnifiedChunks",Get<GraphicsBuffer>(fixture,"chunks"));
                        Set(renderer,"m_LodUnifiedChunkCount",1);
                    }
                    expectedColor = new Color(.58f,.36f,.38f,GaussianUtils.InvSquareCentered01(.68f));
                    expectedDepth = Mathf.Round(.3f*2047)/2047*10;
                    Require(!renderer.SupportsInPlacePaint,"Compressed source was accepted by raw Paint writes.");
                }
                else
                {
                    Call(fixture,"SetWorldPosition",32,new Vector3(0,0,3));
                    Call(fixture,"SetWorldPosition",33,new Vector3(0,0,5));
                    Call(fixture,"SetWorldPosition",34,new Vector3(3,0,3));
                }
                if(paged)
                {
                    Call(fixture,"UsePagedPlaceholder");
                    Call(fixture,"Select",new uint[]{34,33,32},new uint[]{2,0,1});
                    Require(!renderer.SupportsInPlacePaint,"Paged source was accepted by raw Paint writes.");
                }
                var palette = new Color[4]; var pixel = new Vector2(320,240);
                foreach(bool orthographic in new[]{false,true})
                {
                    camera.orthographic=orthographic; camera.orthographicSize=5;
                    Require(renderer.TryGetPaintSurfaceDepth(camera,pixel,8,out float depth) && Mathf.Abs(depth-expectedDepth)<.005f,
                        "Paint did not decode source surface depth: "+shaderPath+", paged="+paged+", compressed="+compressed+", depth="+depth);
                    Require(renderer.SamplePaintColors(camera,pixel,8,depth,.1f,palette,out int count) && count==1,"Paint sampled behind the picked surface.");
                    Color c=palette[0];
                    Require(Mathf.Abs(c.r-expectedColor.r)<.004f && Mathf.Abs(c.g-expectedColor.g)<.004f &&
                        Mathf.Abs(c.b-expectedColor.b)<.004f && Mathf.Abs(c.a-expectedColor.a)<.004f,"Paint decoded the wrong color/alpha: "+c);
                }
                cutoutObject=new GameObject("Paint sampling cutout"); var cutout=cutoutObject.AddComponent<GaussianCutout>();
                cutout.transform.position=new Vector3(0,0,expectedDepth); cutout.transform.localScale=Vector3.one*.05f;
                renderer.m_Cutouts=new[]{cutout};
                Require(renderer.TryGetPaintSurfaceDepth(camera,pixel,8,out float backDepth) && Mathf.Abs(backDepth-5)<.01f,"Paint ignored the front cutout: " + context + ", depth=" + backDepth);
                renderer.m_Cutouts=Array.Empty<GaussianCutout>();
                renderer.EditDeleteSphere(new Vector3(0,0,expectedDepth),.05f);
                Require(renderer.TryGetPaintSurfaceDepth(camera,pixel,8,out backDepth) && Mathf.Abs(backDepth-5)<.01f,"Paint ignored erased geometry: " + context + ", depth=" + backDepth);
                Require(renderer.SamplePaintColors(camera,pixel,8,expectedDepth,.1f,palette,out int erasedCount) && erasedCount==0,"Paint palette included erased geometry: " + context);
                var one=new Color[1];
                Require(renderer.SamplePaintColors(camera,pixel,1000,5,100,one,out int boundedCount) && boundedCount==1,"Paint palette capacity was not bounded.");
                Require(!renderer.TryGetPaintSurfaceDepth(camera,new Vector2(float.NaN,0),8,out _) &&
                    !renderer.SamplePaintColors(camera,pixel,8,3,-1,palette,out _),"Paint accepted invalid query parameters.");
                if(!renderer.SupportsInPlacePaint)
                {
                    int before=renderer.splatCount;
                    renderer.PaintSplatsGPU(32,Vector3.zero,1,.1f,Color.red,0,Vector3.right,Vector3.up,3,1);
                    renderer.PaintSplatsBatch(32,new[]{Vector3.zero},new[]{.1f},new[]{Color.red},1,1);
                    renderer.EnsureOriginalPositionsCaptured();
                    // Geometry sculpting is supported through displacement journals on
                    // both source types. Its source immutability is covered by the sculpt
                    // suites; only direct Paint writes must be rejected here.
                    Require(renderer.splatCount==before && renderer.TryGetPaintSurfaceDepth(camera,pixel,8,out backDepth) && Mathf.Abs(backDepth-5)<.01f,
                        "Unsupported raw Paint call modified a source asset.");
                }
            }
            finally
            {
                if(cutoutObject!=null) Object.DestroyImmediate(cutoutObject);
                // The base fixture owns this buffer and disposes it separately.
                if(paged && compressed) Set(Get<SplatBoxRenderer>(fixture,"renderer"),"m_GpuLodUnifiedChunks",null);
                ((IDisposable)fixture).Dispose();
            }
        }

        static void WritesAndExport(string shaderPath)
        {
            string folder="Assets/__PaintWrite_"+Guid.NewGuid().ToString("N"); GameObject owner=null; Texture2D texture=null;
            try
            {
                AssetDatabase.CreateFolder("Assets",folder.Substring(7));
                using var seed=new NativeArray<Splat>(new[] { new Splat { pos=new Vector3(0,0,5),dc0=new float3(.1f,.2f,.3f),opacity=2,
                    scale=new float3(Mathf.Log(.1f)),rot=new Quaternion(1,0,0,0),sh1=new float3(.11f,.22f,.33f) } },Allocator.TempJob);
                string assetPath=GaussianSplatAssetCreator.CreateAssetFromSplats(seed,folder,"Seed",GaussianSplatAssetCreator.DataQuality.VeryHigh);
                owner=new GameObject("Paint write validation"); owner.SetActive(false); var renderer=owner.AddComponent<SplatBoxRenderer>();
                Set(renderer,"m_Asset",AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(assetPath)); owner.SetActive(true);
                string packageRoot=UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                var shader=AssetDatabase.LoadAssetAtPath<ComputeShader>(packageRoot+"/"+shaderPath);
                Set(renderer,"m_CSBoxUtil",shader); Call(renderer,"InitializeKernels");
                Require(renderer.SupportsInPlacePaint && renderer.HasValidRenderSetup,"Writable paint fixture did not initialize.");
                renderer.EditSetSplatCount(128);
                using var export=new GraphicsBuffer(GraphicsBuffer.Target.Structured,128,UnsafeUtility.SizeOf<Splat>());
                var data=new Splat[128];
                Require(renderer.ExportPaintSplats(export,0,128),"Paint range export rejected a writable asset."); export.GetData(data);
                Require(math.distance(data[0].sh1,seed[0].sh1)<.001f,"Resizing changed existing SH.");
                for(int i=1;i<128;++i) Require(GaussianUtils.Sigmoid(data[i].opacity)<.00002f,"Unwritten paint capacity was visible.");
                shader.SetInt("_SplatChunkCount",7);
                renderer.PaintSplatsGPU(1,new Vector3(0,0,3),.1f,.05f,new Color(.2f,.4f,.8f,.6f),0,Vector3.right,Vector3.up,2,.5f);
                shader.SetInt("_SplatChunkCount",7);
                renderer.PaintSplatsBatch(3,new[]{new Vector3(.2f,0,3)},new[]{.07f},new[]{new Color(.7f,.3f,.2f,.8f)},1,.5f);
                texture=new Texture2D(2,2,TextureFormat.RGBAFloat,false,true); texture.SetPixels(new[]{Color.green,Color.green,Color.green,Color.green}); texture.Apply();
                shader.SetInt("_SplatChunkCount",7);
                renderer.PaintSplatsFromTextureGPU(4,new Vector3(.4f,0,3),.1f,.06f,texture,1,0,0,Vector3.right,Vector3.up,1,.5f);
                shader.SetInt("_SplatChunkCount",7);
                renderer.PaintSplatsAt(5,new Vector3(.6f,0,3),Quaternion.identity,.08f,.5f,1,Color.blue);
                Require(renderer.ExportPaintSplats(export,0,128),"Paint export failed after GPU writes."); export.GetData(data);
                Require(math.distance(data[0].sh1,seed[0].sh1)<.001f,"Paint cleared unrelated source SH.");
                for(int i=1;i<=5;++i)
                {
                    Require(math.all(math.isfinite(data[i].pos)) && Mathf.Abs(data[i].pos.z-3)<.03f,"Paint ignored stale chunk state or produced invalid positions.");
                    Require(math.length(data[i].sh1)+math.length(data[i].shF)<.00001f,"Paint did not initialize SH.");
                }
                Require(math.distance(GaussianUtils.SH0ToColor(data[1].dc0),new float3(.2f,.4f,.8f))<.003f &&
                    Mathf.Abs(GaussianUtils.Sigmoid(data[1].opacity)-.3f)<.003f && Mathf.Abs(Mathf.Exp(data[1].scale.x)-.05f)<.001f,"GPU paint/export changed color, alpha or scale.");
                Require(math.distance(GaussianUtils.SH0ToColor(data[3].dc0),new float3(.7f,.3f,.2f))<.003f &&
                    Mathf.Abs(GaussianUtils.Sigmoid(data[3].opacity)-.4f)<.003f,"Batch paint/export changed color or alpha.");
                Require(math.distance(GaussianUtils.SH0ToColor(data[4].dc0),new float3(0,1,0))<.003f,"Texture paint/export changed color.");
                Require(!renderer.ExportPaintSplats(export,127,2) && !renderer.ExportPaintSplats(export,-1,1),"Paint export accepted an invalid range.");
            }
            finally { if(owner!=null) Object.DestroyImmediate(owner); if(texture!=null) Object.DestroyImmediate(texture); AssetDatabase.DeleteAsset(folder); }
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders,"Use an isolated batch project with a graphics device.");
            var errors=new List<string>();
            Application.LogCallback observe=(message,stack,type)=> { if(type==LogType.Error || type==LogType.Exception || type==LogType.Assert) errors.Add(message); };
            Application.logMessageReceived+=observe;
            try
            {
                foreach(string shader in new[]{"Resources/BoxUtil.compute","Shaders/BoxUtil.compute"})
                {
                    Sampling(shader,false,false); Sampling(shader,true,false);
                    Sampling(shader,false,true); Sampling(shader,true,true);
                    WritesAndExport(shader);
                }
                Require(errors.Count==0,"Paint validation logged errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox Paint sampling/write PASS: packed/chunked and paged picking, source alpha, surface depth, masks/erase, bounded palette, safe capacity, all paint kernels and interleaved export on both shaders.");
            }
            finally { Application.logMessageReceived-=observe; }
        }
    }
}
