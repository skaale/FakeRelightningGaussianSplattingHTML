using System;
using System.Runtime.InteropServices;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    /// <summary>Compares real Gaussian draws with the shader before vertex colour grading.</summary>
    public static class SplatColorAdjustmentValidation
    {
        static string Root => UnityEditor.PackageManager.PackageInfo
            .FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";
        const int Width = 128;
        const int Height = 96;

        [StructLayout(LayoutKind.Sequential)]
        struct ViewData
        {
            public Vector4 pos;
            public uint axis1, axis2, color1, color2;
            public Vector3 worldPos;
            public uint splatIdx;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct MeshUv
        {
            public Vector2 uv, sigmaX, sigmaY, pad;
        }

        public static void Run()
        {
            if (!SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.ARGBFloat))
                throw new InvalidOperationException("Colour parity validation requires an ARGBFloat render target.");

            var baselineShader = Load("Tests/Editor/SplatColorAdjustmentBaseline.shader");
            var views = new ViewData[6];
            var uvs = new MeshUv[views.Length];
            var colors = new[]
            {
                new Color(0.12f, 0.72f, 0.43f, 0.85f), new Color(1.8f, 0.16f, 0.32f, 0.4f),
                new Color(0.55f, 0.32f, 0.91f, 0.7f), new Color(0.08f, 0.92f, 1.4f, 0.12f),
                new Color(0.66f, 0.41f, 0.15f, 1.3f), new Color(0.4f, 0.4f, 0.4f, 0.55f)
            };
            for (int i = 0; i < views.Length; ++i)
            {
                var center = new Vector3(-0.45f + i * 0.18f, (i % 2 == 0 ? -1 : 1) * 0.15f, 0.5f);
                views[i] = new ViewData
                {
                    pos = new Vector4(center.x, center.y, center.z, 1),
                    axis1 = Pack(17 + i, 3 - i), axis2 = Pack(-2, 12 + i),
                    color1 = Pack(colors[i].r, colors[i].g), color2 = Pack(colors[i].b, colors[i].a),
                    worldPos = center, splatIdx = (uint)i
                };
                uvs[i] = new MeshUv
                {
                    uv = new Vector2(0.18f + i * 0.11f, 0.48f),
                    sigmaX = new Vector2(0.12f, 0.025f), sigmaY = new Vector2(0.02f, 0.15f)
                };
            }

            using var viewBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, views.Length, Marshal.SizeOf<ViewData>());
            using var uvBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, uvs.Length, Marshal.SizeOf<MeshUv>());
            using var selected = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4);
            using var targetSelected = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4);
            using var indices = new GraphicsBuffer(GraphicsBuffer.Target.Index, 6, 2);
            viewBuffer.SetData(views);
            uvBuffer.SetData(uvs);
            // Exercise unselected, source, target and both-selected splats together.
            selected.SetData(new uint[] { 0b101010 });
            targetSelected.SetData(new uint[] { 0b110100 });
            indices.SetData(new ushort[] { 0, 1, 2, 1, 3, 2 });

            var texture = new Texture2D(8, 8, TextureFormat.RGBAFloat, false, true)
                { filterMode = FilterMode.Bilinear, wrapMode = TextureWrapMode.Clamp };
            var rt = new RenderTexture(Width, Height, 0, RenderTextureFormat.ARGBFloat, RenderTextureReadWrite.Linear);
            var readback = new Texture2D(Width, Height, TextureFormat.RGBAFloat, false, true);
            var baseline = new Material(baselineShader);
            try
            {
                for (int y = 0; y < 8; ++y)
                    for (int x = 0; x < 8; ++x)
                        texture.SetPixel(x, y, new Color(0.1f + x * 0.1f, 0.15f + y * 0.09f, 0.85f - x * 0.07f, 0.25f + y * 0.09f));
                texture.Apply();
                rt.Create();

                foreach (string path in new[] { "Resources/RenderSplats.shader", "Shaders/RenderGaussianSplats.shader" })
                {
                    var optimized = new Material(Load(path));
                    try
                    {
                        // Mesh texture and selection need grading after their fragment-dependent colour.
                        // Equirect projection must still apply after grading in every combination.
                        for (int grade = 0; grade < 3; ++grade)
                            for (int mode = 0; mode < 8; ++mode)
                            {
                                Configure(baseline, grade, mode, views.Length, viewBuffer, uvBuffer,
                                    selected, targetSelected, texture);
                                Configure(optimized, grade, mode, views.Length, viewBuffer, uvBuffer,
                                    selected, targetSelected, texture);
                                Color[] expected = Draw(baseline, indices, views.Length, rt, readback);
                                Color[] actual = Draw(optimized, indices, views.Length, rt, readback);
                                Compare(expected, actual, path + " grade=" + grade + " mode=" + mode);
                            }
                    }
                    finally { UnityEngine.Object.DestroyImmediate(optimized); }
                }
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(baseline);
                UnityEngine.Object.DestroyImmediate(texture);
                UnityEngine.Object.DestroyImmediate(readback);
                rt.Release();
                UnityEngine.Object.DestroyImmediate(rt);
            }
            Debug.Log("SplatBox colour adjustment parity PASS: both draw shaders, HDR, overlapping splats, selection, mesh texture and equirect projection.");
        }

        static Shader Load(string path)
        {
            var shader = AssetDatabase.LoadAssetAtPath<Shader>(Root + path);
            if (shader == null || !shader.isSupported)
                throw new InvalidOperationException("Missing or unsupported shader: " + path);
            return shader;
        }

        static uint Pack(float high, float low) => ((uint)Mathf.FloatToHalf(high) << 16) | Mathf.FloatToHalf(low);

        static void Configure(Material material, int grade, int mode, int count, GraphicsBuffer views,
            GraphicsBuffer uvs, GraphicsBuffer selected, GraphicsBuffer targetSelected, Texture texture)
        {
            material.SetBuffer("_SplatViewData", views);
            material.SetBuffer("_SplatSelectedBits", selected);
            material.SetBuffer("_SplatTargetSelectedBits", targetSelected);
            material.SetBuffer("_SplatMeshUvs", uvs);
            material.SetInt("_SplatCount", count);
            material.SetInt("_SplatBitsValid", (mode & 1) != 0 ? 1 : 0);
            material.SetInt("_SplatTightQuads", 1);
            material.SetInt("_MeshTexEnabled", (mode & 2) != 0 ? 1 : 0);
            material.SetTexture("_MeshTex", texture);
            material.SetInt("_SceneDepthOcclusion", 0);
            material.SetInt("_SceneDepthTextureValid", 0);
            material.SetTexture("_CameraDepthTexture", Texture2D.whiteTexture);
            material.SetVector("_SplatRenderTargetSize", new Vector4(Width, Height, 1f / Width, 1f / Height));
            material.SetFloat("_ColorExposure", grade == 0 ? 0 : grade == 1 ? -1 : 1.3f);
            material.SetFloat("_ColorContrast", grade == 2 ? 1.15f : 1);
            material.SetFloat("_ColorHueShift", grade == 0 ? 0 : grade == 1 ? 1 : 173);
            material.SetFloat("_ColorSaturation", grade == 2 ? 1.6f : 1);
            material.SetColor("_ColorFilter", grade == 0 ? Color.white : new Color(0.8537736f, 0.92750853f, 1));
            material.SetColor("_SelectionColor", new Color(0.9f, 0.12f, 0.4f));
            material.SetColor("_TargetSelectionColor", new Color(0.2f, 0.9f, 0.3f));
            material.SetInt("_EquirectEnabled", (mode & 4) != 0 ? 1 : 0);
            material.SetFloat("_EquirectOpacity", 0.7f);
            material.SetTexture("_EquirectTexture", texture);
            material.SetVector("_EquirectProjectorPosition", new Vector3(0, 0, -2));
            material.SetVector("_EquirectProjectorScale", Vector3.one);
            material.SetVector("_EquirectProjectorRotation", new Vector4(0, 0, 0, 1));
            material.SetInt("_EquirectBlendMode", 4);
            material.SetColor("_EquirectTintColor", new Color(0.8f, 0.9f, 1, 0.75f));
            material.SetFloat("_EquirectTileX", 1);
            material.SetFloat("_EquirectTileY", 1);
        }

        static Color[] Draw(Material material, GraphicsBuffer indices, int count, RenderTexture target, Texture2D readback)
        {
            bool instancing = Shader.IsKeywordEnabled("STEREO_INSTANCING_ON");
            bool multiview = Shader.IsKeywordEnabled("STEREO_MULTIVIEW_ON");
            using var cmd = new CommandBuffer { name = "Splat colour parity" };
            cmd.DisableShaderKeyword("STEREO_INSTANCING_ON");
            cmd.DisableShaderKeyword("STEREO_MULTIVIEW_ON");
            cmd.SetRenderTarget(target);
            cmd.SetViewport(new Rect(0, 0, Width, Height));
            cmd.ClearRenderTarget(false, true, Color.clear);
            cmd.SetViewProjectionMatrices(Matrix4x4.identity, Matrix4x4.identity);
            cmd.SetGlobalVector("_ScreenParams", new Vector4(Width, Height, 1 + 1f / Width, 1 + 1f / Height));
            cmd.DrawProcedural(indices, Matrix4x4.identity, material, 0, MeshTopology.Triangles, 6, count);
            if (instancing) cmd.EnableShaderKeyword("STEREO_INSTANCING_ON");
            if (multiview) cmd.EnableShaderKeyword("STEREO_MULTIVIEW_ON");
            Graphics.ExecuteCommandBuffer(cmd);
            var previous = RenderTexture.active;
            try
            {
                RenderTexture.active = target;
                readback.ReadPixels(new Rect(0, 0, Width, Height), 0, 0, false);
                readback.Apply(false);
                return readback.GetPixels();
            }
            finally { RenderTexture.active = previous; }
        }

        static void Compare(Color[] expected, Color[] actual, string label)
        {
            int covered = 0;
            for (int i = 0; i < expected.Length; ++i)
            {
                if (expected[i].a > 0.01f) ++covered;
                for (int channel = 0; channel < 4; ++channel)
                {
                    float reference = expected[i][channel];
                    float result = actual[i][channel];
                    // Half-precision arithmetic/interpolation can round at different stages.
                    float tolerance = 0.003f * Mathf.Max(1, Mathf.Abs(reference));
                    if (float.IsNaN(result) || Mathf.Abs(reference - result) > tolerance)
                        throw new InvalidOperationException("Colour parity failed for " + label + " at pixel=" + i +
                            " channel=" + channel + ": baseline=" + reference + " actual=" + result);
                }
            }
            if (covered < 100)
                throw new InvalidOperationException("Colour parity fixture did not render: " + label);
        }
    }
}
