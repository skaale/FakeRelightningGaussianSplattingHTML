// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    /// <summary>GPU regressions for edits that must follow geometry through paged LoD changes.</summary>
    public static class PagedLodEditingValidation
    {
        const BindingFlags Private = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public;
        const int Capacity = 128;
        const int PageOffset = 32;
        static string Root => UnityEditor.PackageManager.PackageInfo
            .FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        struct View
        {
            public Vector4 clip;
            public uint axis1, axis2, color1, color2;
            public Vector3 world;
            public uint index;
        }

        [MenuItem("Tools/Gaussian Splatting/Validate Paged LoD Editing")]
        public static void Run()
        {
            Require(SystemInfo.supportsComputeShaders, "Paged editing validation needs a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            {
                if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
                    errors.Add(message);
            };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    using (var fixture = new Fixture(path, true))
                    {
                        ValidatePagedEditing(fixture);
                        fixture.ValidateDrawBindings(path.StartsWith("Resources/")
                            ? "Resources/RenderSplats.shader" : "Shaders/RenderGaussianSplats.shader");
                        fixture.ValidateDrawBindings(path.StartsWith("Resources/")
                            ? "Resources/RenderSplatsRelight.shader" : "Shaders/Relight/RenderGaussianSplats.shader");
                    }
                    using (var fixture = new Fixture(path, true)) ValidatePagedGeometry(fixture);
                    using (var fixture = new Fixture(path, false)) ValidateMonolithicEditing(fixture);
                    using (var fixture = new Fixture(path, true)) ValidateScreenRestore(fixture, true);
                    using (var fixture = new Fixture(path, false)) ValidateScreenRestore(fixture, false);
                }
                Require(errors.Count == 0, "GPU editing or draw validation logged errors: " + string.Join("\n", errors));
            }
            finally { Application.logMessageReceived -= observe; }
            Debug.Log("SplatBox paged editing validation PASS: screen erase survives active remapping, " +
                "draw ordering and camera movement; unrelated geometry remains visible; recycled slots, " +
                "new detail, ordered restore, serialized journals, resource recreation, deterministic " +
                "falloff, depth filtering, bounded Geometry tools, draw buffer fallbacks and monolithic erasure pass with both compute shaders.");
        }

        public static void RunScreenRestore()
        {
            Require(SystemInfo.supportsComputeShaders, "Screen restore validation needs a graphics device.");
            foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                foreach (bool paged in new[] { true, false })
                    using (var fixture = new Fixture(path, paged)) ValidateScreenRestore(fixture, paged);
            Debug.Log("SplatBox screen restore validation PASS: both compute copies, paged/monolithic masks, " +
                "near/far/off-axis coverage beyond the pivot, filtered erase, fully erased view, unchanged outside/behind-camera splats, remapping, journal reload and late detail.");
        }

        public static void RunPolygonMask()
        {
            Require(Application.isBatchMode, "Run polygon-mask validation in an isolated batch-mode project.");
            Require(SystemInfo.supportsComputeShaders, "Polygon-mask validation needs a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            {
                if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message);
            };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                    foreach (bool paged in new[] { true, false })
                        using (var fixture = new Fixture(path, paged)) ValidatePolygonMask(fixture, paged);
                Require(errors.Count == 0, "Polygon-mask validation logged errors: " + string.Join("\n", errors));
            }
            finally { Application.logMessageReceived -= observe; }
            Debug.Log("SplatBox polygon mask GPU PASS: exact concave geometry, invert, multiple cutouts, clear/disable, stationary-camera edits, erase/restore, remapping, page replay and serialized mask geometry; both compute variants and paged/monolithic assets.");
        }

        public static void RunPolygonMaskSuite()
        {
            Require(Application.isBatchMode, "Run polygon-mask validation in an isolated batch-mode project.");
            RunPolygonMask();
            PolygonMaskGeometryValidation.Run();
            Run();
            PagedXcopyCameraValidation.RunPolygonMaskScene();
            DistantPointComputeValidation.Run();
            PagedXcopyCameraValidation.RunCloneLayout();
            Debug.Log("SplatBox Polygon Mask complete validation suite PASS");
        }

        static void ValidatePolygonMask(Fixture f, bool paged)
        {
            var maskObject = new GameObject("Polygon regression mask");
            var secondaryObject = new GameObject("Polygon regression second cutout");
            var reloadedObject = new GameObject("Polygon regression reloaded mask");
            GameObject copyRoot = null;
            try
            {
                var mask = maskObject.AddComponent<GaussianPolyMask>();
                Set(mask, "m_ExpansionX", 1f); Set(mask, "m_ExpansionY", 1f); Set(mask, "m_CutDepth", 0.4f);
                // The upper-right quarter is outside this concave L, although inside its AABB.
                Vector3[] polygon = { new Vector3(-1,-1,5), new Vector3(1,-1,5), new Vector3(1,0,5),
                    new Vector3(0,0,5), new Vector3(0,1,5), new Vector3(-1,1,5) };
                mask.StartDrawing(polygon[0], Vector3.forward);
                for (int i = 1; i < polygon.Length; ++i) mask.AddVertex3D(polygon[i]);
                mask.ClosePath();
                Vector3[] positions = { new Vector3(-0.5f,0.5f,5), new Vector3(0.5f,0.5f,5),
                    new Vector3(0.5f,-0.5f,5), new Vector3(1.5f,0,5), new Vector3(-0.5f,0.5f,7) };
                for (int i = 0; i < positions.Length; ++i) f.SetWorldPosition(32 + i, positions[i]);
                f.page.splatCount = positions.Length; f.UpdatePageBounds();
                if (paged) { f.UsePagedPlaceholder(); f.Select(new uint[] { 32,33,34,35,36 }, new uint[] { 0,1,2,3,4 }); }
                f.renderer.m_Cutouts = new GaussianCutout[] { mask };
                Action<bool[]> expect = hidden =>
                {
                    var views = f.Views();
                    for (int i = 0; i < positions.Length; ++i)
                        Require((views[paged ? i : 32 + i].clip.w == 0) == hidden[i],
                            $"Polygon mask changed wrong point {i}, paged={paged}, invert={mask.m_Invert}.");
                };
                expect(new[] { true,false,true,false,false });
                if (paged)
                {
                    Require(!(bool)Call(f.renderer, "ShouldCalculateEditorLodView", f.camera), "Unchanged mask needlessly invalidated view cache.");
                    mask.m_Invert = true;
                    Require((bool)Call(f.renderer, "ShouldCalculateEditorLodView", f.camera), "Invert left the stationary-camera mask cache stale.");
                }
                else mask.m_Invert = true;
                expect(new[] { false,true,false,true,true });
                var secondary = secondaryObject.AddComponent<GaussianCutout>();
                secondary.m_Type = GaussianCutout.Type.Box;
                secondary.transform.position = positions[0]; secondary.transform.localScale = Vector3.one * 0.1f;
                f.renderer.m_Cutouts = new GaussianCutout[] { mask, secondary };
                expect(new[] { true,true,false,true,true }); // An inverted keep region cannot bypass another cutout.
                if (paged)
                {
                    copyRoot = new GameObject("Polygon regression Xcopy root");
                    f.owner.transform.SetParent(copyRoot.transform, true);
                    secondary.transform.SetParent(copyRoot.transform, true);
                    secondary.name = "Xcopy boundary"; secondary.m_Invert = true;
                    secondary.transform.position = new Vector3(0,0,5);
                    secondary.transform.localScale = new Vector3(2,2,3);
                    Set(f.renderer, "m_PagedXcopyBoundary", secondary);
                    f.renderer.m_Cutouts = new GaussianCutout[] { secondary, mask };
                    Require(ReferenceEquals(f.renderer.GetType().GetProperty("PagedXcopyBoundary", Private).GetValue(f.renderer), secondary),
                        "Adding a polygon mask disabled Xcopy's page refinement boundary.");
                    mask.m_Invert = false;
                    expect(new[] { true,false,true,false,false });
                    Set(f.renderer, "m_PagedXcopyBoundary", null);
                }
                f.renderer.m_Cutouts = new GaussianCutout[] { mask };
                mask.m_Invert = false;
                mask.enabled = false; expect(new[] { false,false,false,false,false });
                mask.enabled = true; expect(new[] { true,false,true,false,false });
                Set(mask, "m_OffsetX", 2f);
                if (paged) Require((bool)Call(f.renderer, "ShouldCalculateEditorLodView", f.camera), "Offset left mask cache stale.");
                expect(new[] { false,false,false,true,false });
                Set(mask, "m_OffsetX", 0f);
                Set(mask, "m_ExpansionX", 0.2f);
                expect(new[] { false,false,false,false,false });
                Set(mask, "m_ExpansionX", 1f);
                // Moving all vertices leaves the transform unchanged; vertex buffers also invalidate the view.
                for (int i = 0; i < mask.m_Vertices.Count; ++i) mask.m_Vertices[i] += Vector3.right * 2;
                if (paged) Require((bool)Call(f.renderer, "ShouldCalculateEditorLodView", f.camera), "Vertex edit left mask cache stale.");
                expect(new[] { false,false,false,true,false });
                for (int i = 0; i < mask.m_Vertices.Count; ++i) mask.m_Vertices[i] -= Vector3.right * 2;
                expect(new[] { true,false,true,false,false });

                // Erase and live cutouts remain independent: restoring an erased point cannot unmask it.
                f.renderer.EditDeleteSphere(positions[1], 0.1f);
                expect(new[] { true,true,true,false,false });
                f.renderer.EditRestoreSphere(positions[1], 0.1f);
                expect(new[] { true,false,true,false,false });
                f.renderer.EditDeleteSphere(positions[0], 0.1f);
                mask.Clear();
                expect(new[] { true,false,false,false,false });
                f.renderer.EditRestoreSphere(positions[0], 0.1f);
                expect(new[] { false,false,false,false,false });

                // Horizontal polygons previously lost their detected extrusion axis on script/scene reload.
                mask.StartDrawing(new Vector3(-1,0,4), Vector3.up);
                mask.AddVertex3D(new Vector3(1,0,4)); mask.AddVertex3D(new Vector3(1,0,6));
                mask.AddVertex3D(new Vector3(-1,0,6)); mask.ClosePath();
                var loaded = reloadedObject.AddComponent<GaussianPolyMask>();
                reloadedObject.transform.SetPositionAndRotation(mask.transform.position, mask.transform.rotation);
                reloadedObject.transform.localScale = mask.transform.localScale;
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(mask), loaded);
                f.renderer.m_Cutouts = new GaussianCutout[] { loaded };
                f.SetWorldPosition(32, new Vector3(0,0,5));
                f.SetWorldPosition(33, new Vector3(0,1,5));
                f.SetWorldPosition(34, new Vector3(0,0,7));
                f.page.splatCount = 3; f.UpdatePageBounds();
                if (paged)
                {
                    f.renderer.EditDeleteSphere(new Vector3(0,1,5), 0.1f);
                    f.Select(new uint[] { 34,32,33 }, new uint[] { 2,0,1 });
                    f.ExpectVisibility(new[] { 33,34,32 }, true,false,true);
                    f.Replay(PageOffset, 3);
                    f.ExpectVisibility(new[] { 33,34,32 }, true,false,true);
                    f.renderer.EditRestoreSphere(new Vector3(0,1,5), 0.1f);
                    f.ExpectVisibility(new[] { 33,34,32 }, false,false,true);
                    f.ReloadJournal();
                    // This fixture round-trips only the renderer's journal through JSON; its
                    // unsaved scene references are not persisted by EditorJsonUtility. Restore
                    // the live mask explicitly. RunPolygonMaskScene validates actual scene refs
                    // and mask geometry through SaveScene/OpenScene with persistent assets.
                    f.renderer.m_Cutouts = new GaussianCutout[] { loaded };
                    Require(loaded.IsClosed && loaded.IsPointInside(new Vector3(0,0,5)),
                        "Reloaded mask no longer contains the center point.");
                    f.Select(new uint[] { 32,34,33 }, new uint[] { 1,2,0 });
                    f.ExpectVisibility(new[] { 34,33,32 }, false,false,true);
                }
                else
                {
                    var views = f.Views();
                    Require(views[32].clip.w == 0 && views[33].clip.w > 0 && views[34].clip.w > 0,
                        "Reloaded horizontal mask did not retain its plane/depth.");
                }
            }
            finally
            {
                f.renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                f.owner.transform.SetParent(null, true);
                UnityEngine.Object.DestroyImmediate(maskObject); UnityEngine.Object.DestroyImmediate(secondaryObject);
                UnityEngine.Object.DestroyImmediate(reloadedObject);
                if (copyRoot != null) UnityEngine.Object.DestroyImmediate(copyRoot);
            }
        }

        static void ValidateScreenRestore(Fixture f, bool paged)
        {
            if (paged) f.UsePagedPlaceholder();
            f.SetWorldPosition(32, new Vector3(0.05f, 0, 2));
            f.SetWorldPosition(33, new Vector3(0.4f, 0, 16));
            f.SetWorldPosition(34, new Vector3(0.7f, 0.2f, 16));
            f.SetWorldPosition(35, new Vector3(1.8f, 0, 16));
            f.SetWorldPosition(36, new Vector3(0, 0, -2));
            f.SetWorldPosition(37, new Vector3(0.6f, 0.1f, 14)); // A detail node loaded later.
            f.page.splatCount = 5;
            f.UpdatePageBounds();
            if (paged) f.Select(new uint[] { 34, 32, 35, 33, 36 }, new uint[] { 3, 1, 4, 0, 2 });
            Vector2 center = new Vector2(f.camera.pixelWidth * 0.5f, f.camera.pixelHeight * 0.5f);
            const float radius = 24;
            foreach (bool colorFilter in new[] { false, true })
            {
                f.renderer.ResetDeletedSplats();
                f.renderer.EditDeleteSplatsInScreenCircle(center, radius, f.camera, false,
                    useColorFilter: colorFilter, colorFilter: new Color(0.6f, 0.4f, 0.2f), colorThreshold: 0.01f);
                f.ExpectEditingBits(paged ? new[] { 32, 33, 34 } : new[] { 32, 33, 34, 37 });
                // This was the former RMB route. Its pivot half-cylinder cannot restore the
                // far geometry removed by the same perspective screen circle.
                f.renderer.EditRestoreCylinder(new Vector3(0, 0, 2), 0.12f, Vector3.forward);
                f.ExpectEditingBits(paged ? new[] { 33, 34 } : new[] { 33, 34, 37 });
                f.renderer.EditRestoreSplatsInScreenCircle(center, radius, f.camera);
                f.ExpectEditingBits();
            }
            f.renderer.ResetDeletedSplats();
            f.renderer.EditDeleteSphere(new Vector3(0, 0, 8), 30);
            f.ExpectEditingBits(paged ? new[] { 32, 33, 34, 35, 36 } : new[] { 32, 33, 34, 35, 36, 37 });
            // No visible front surface remains. Restoration must not depend on finding one,
            // nor restore projected points outside the circle or behind the camera.
            f.renderer.EditRestoreSplatsInScreenCircle(center, radius, f.camera);
            f.ExpectEditingBits(35, 36);
            if (!paged) return;
            f.page.splatCount = 6; f.UpdatePageBounds(); f.Replay(PageOffset, 6);
            f.ExpectEditingBits(35, 36);
            f.Select(new uint[] { 37, 36, 35, 34, 33, 32 }, new uint[] { 4, 0, 5, 3, 2, 1 });
            f.ExpectVisibility(new[] { 33, 37, 32, 34, 35, 36 }, false, false, false, false, true, true);
            f.ReloadJournal(); f.ExpectEditingBits(35, 36);
            f.Replay(PageOffset, 6); f.ExpectEditingBits(35, 36);
        }

        public static void RunPolygonDelete()
        {
            Require(Application.isBatchMode, "Run polygon deletion validation in an isolated batch-mode project.");
            Require(SystemInfo.supportsComputeShaders, "Polygon deletion validation needs a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            {
                if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message);
            };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    using (var fixture = new Fixture(path, true)) ValidatePolygonDelete(fixture);
                    using (var fixture = new Fixture(path, true)) ValidatePagedFillDepth(fixture);
                    using (var fixture = new Fixture(path, true)) ValidatePagedFillExport(fixture);
                }
                Require(errors.Count == 0, "Polygon deletion logged errors: " + string.Join("\n", errors));
            }
            finally { Application.logMessageReceived -= observe; }
            Debug.Log("SplatBox paged polygon deletion PASS: concave/depth selection, immutable multi-polygon replay, late detail, remapping, transformed renderer, serialized journals, erase/restore compatibility, perspective/orthographic surface picking and interleaved nonzero SH edge export with both compute shaders.");
        }

        static void ValidatePagedFillExport(Fixture f)
        {
            f.UsePagedPlaceholder();
            Vector3[] polygon = { new Vector3(-1,-1,5), new Vector3(1,-1,5), new Vector3(1,1,5), new Vector3(-1,1,5) };
            Vector3[] positions = { new Vector3(-1,0,5), new Vector3(0,0,5), new Vector3(-1,0.5f,5.3f), new Vector3(1,0,5) };
            for (int i = 0; i < positions.Length; ++i) f.SetWorldPosition(32 + i, positions[i]);
            f.page.splatCount = positions.Length; f.UpdatePageBounds();
            f.Select(new uint[] { 34,35,33,32 }, new uint[] { 2,0,3,1 });
            var sh = new float[Capacity * 48];
            for (int index = 32; index < 36; ++index)
                for (int component = 0; component < 45; ++component)
                    sh[index * 48 + component] = (component + 1) * 0.01f + index * 0.001f;
            Get<GraphicsBuffer>(f.renderer, "m_GpuLodUnifiedSh").SetData(sh);
            using var output = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 4, Marshal.SizeOf<GaussianSplatAssetCreator.InputSplatData>());
            Require(f.renderer.ExportPagedPolygonSamples(polygon, Vector3.forward, 0.2f, 0.1f, output, out int count) && count == 2,
                "Fill edge export did not exclude polygon interior/out-of-depth samples.");
            var samples = new GaussianSplatAssetCreator.InputSplatData[4]; output.GetData(samples);
            string[] fields = { "sh1", "sh2", "sh3", "sh4", "sh5", "sh6", "sh7", "sh8", "sh9", "shA", "shB", "shC", "shD", "shE", "shF" };
            for (int sampleIndex = 0; sampleIndex < count; ++sampleIndex)
            {
                var sample = samples[sampleIndex];
                int atlasIndex = (sample.pos - f.Position(32)).sqrMagnitude < 0.00001f ? 32 : 35;
                Require((sample.pos - f.Position(atlasIndex)).sqrMagnitude < 0.00001f, "Fill export lost the active atlas remap.");
                for (int coefficient = 0; coefficient < fields.Length; ++coefficient)
                {
                    var actual = (Vector3)typeof(GaussianSplatAssetCreator.InputSplatData).GetField(fields[coefficient]).GetValue(sample);
                    int offset = atlasIndex * 48 + coefficient * 3;
                    var expected = new Vector3(sh[offset], sh[offset + 1], sh[offset + 2]);
                    Require((actual - expected).sqrMagnitude < 0.000001f, "Fill export changed RGB SH coefficient " + fields[coefficient]);
                }
                Vector3 color = sample.dc0 * 0.2820948f + Vector3.one * 0.5f;
                Require((color - new Vector3(0.6f,0.4f,0.2f)).sqrMagnitude < 0.00001f &&
                    Mathf.Abs(1f / (1f + Mathf.Exp(-sample.opacity)) - 0.8f) < 0.001f &&
                    Mathf.Abs(Mathf.Exp(sample.scale.x) - 0.1f) < 0.0001f,
                    "Fill export changed source color/opacity/scale through importer encoding.");
            }
            using (var limited = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, output.stride))
                Require(f.renderer.ExportPagedPolygonSamples(polygon, Vector3.forward, 0.2f, 0.1f, limited, out count) && count == 2,
                    "Fill export failed to report capacity overflow for caller retry.");
            f.renderer.EditDeleteSphere(positions[0], 0.1f);
            Require(f.renderer.ExportPagedPolygonSamples(polygon, Vector3.forward, 0.2f, 0.1f, output, out count) && count == 1,
                "Fill export sampled deleted edge geometry.");
            var cutoutObject = new GameObject("Fill edge sample cutout");
            try
            {
                var cutout = cutoutObject.AddComponent<GaussianCutout>(); cutout.m_Type = GaussianCutout.Type.Box;
                cutout.transform.position = positions[3]; cutout.transform.localScale = Vector3.one * 0.1f;
                f.renderer.m_Cutouts = new[] { cutout };
                Require(f.renderer.ExportPagedPolygonSamples(polygon, Vector3.forward, 0.2f, 0.1f, output, out count) && count == 0,
                    "Fill export sampled masked edge geometry.");
                f.renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                f.renderer.ResetDeletedSplats();
                var colors = Get<Texture2D>(f.renderer, "m_GpuLodUnifiedColor");
                var pixels = colors.GetPixels();
                for (int i = 0; i < pixels.Length; ++i) pixels[i].a = 0.001f;
                colors.SetPixels(pixels); colors.Apply();
                Require(f.renderer.ExportPagedPolygonSamples(polygon, Vector3.forward, 0.2f, 0.1f, output, out count) && count == 0,
                    "Fill export sampled transparent splats.");
            }
            finally
            {
                f.renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                UnityEngine.Object.DestroyImmediate(cutoutObject);
            }
        }

        static void ValidatePagedFillDepth(Fixture f)
        {
            f.UsePagedPlaceholder();
            f.owner.transform.SetPositionAndRotation(new Vector3(2,1,0), Quaternion.Euler(17,33,-21));
            f.owner.transform.localScale = new Vector3(1.7f,0.6f,2.3f);
            f.camera.transform.SetPositionAndRotation(new Vector3(-2,1,3), Quaternion.Euler(10,20,4));
            f.camera.nearClipPlane = 0.3f; f.camera.farClipPlane = 100;
            var cutoutObject = new GameObject("Fill depth picking cutout");
            try
            {
                var cutout = cutoutObject.AddComponent<GaussianCutout>();
                cutout.m_Type = GaussianCutout.Type.Box;
                cutout.transform.localScale = Vector3.one * 0.1f;
                foreach (bool ortho in new[] { false, true })
                {
                    f.camera.orthographic = ortho; f.camera.orthographicSize = 5;
                    Vector3[] viewport = { new Vector3(0.3f,0.75f,3), new Vector3(0.3f,0.75f,5),
                        new Vector3(0.3f,0.25f,2), new Vector3(0.8f,0.75f,2),
                        new Vector3(0.3f,0.75f,-1), new Vector3(0.3f,0.75f,150), new Vector3(0.3f,0.75f,0.1f) };
                    for (int i = 0; i < viewport.Length; ++i)
                        f.SetWorldPosition(32 + i, f.camera.ViewportToWorldPoint(viewport[i]));
                    f.page.splatCount = viewport.Length; f.UpdatePageBounds();
                    f.Select(new uint[] { 34,38,33,36,32,37,35 }, new uint[] { 4,2,6,1,3,0,5 });
                    Vector3 screen = f.camera.WorldToScreenPoint(f.WorldPoint(32));
                    Vector2 pixel = new Vector2(screen.x, screen.y);
                    Require(f.renderer.TryGetPagedFillSurfaceDepth(f.camera, pixel, 8, out float depth) && Mathf.Abs(depth - 3) < 0.001f,
                        "Fill picked the wrong pixel/depth or legacy placeholder, orthographic=" + ortho + ", depth=" + depth);
                    f.renderer.EditDeleteSphere(f.WorldPoint(32), 0.05f);
                    Require(f.renderer.TryGetPagedFillSurfaceDepth(f.camera, pixel, 8, out depth) && Mathf.Abs(depth - 5) < 0.001f,
                        "Fill picking ignored erased front geometry, orthographic=" + ortho);
                    cutout.transform.position = f.WorldPoint(33);
                    f.renderer.m_Cutouts = new[] { cutout };
                    Require(!f.renderer.TryGetPagedFillSurfaceDepth(f.camera, pixel, 8, out _),
                        "Fill picking ignored cutout/near/far/behind-camera rejection, orthographic=" + ortho);
                    f.renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                    f.renderer.ResetDeletedSplats();
                }
                Require(!f.renderer.TryGetPagedFillSurfaceDepth(f.camera, new Vector2(float.NaN, 0), 8, out _) &&
                    !f.renderer.TryGetPagedFillSurfaceDepth(f.camera, Vector2.zero, -1, out _), "Fill picking accepted invalid input.");
            }
            finally
            {
                f.renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                UnityEngine.Object.DestroyImmediate(cutoutObject);
            }
        }

        static void ValidatePolygonDelete(Fixture f)
        {
            f.UsePagedPlaceholder();
            f.owner.transform.SetPositionAndRotation(new Vector3(2,1,0), Quaternion.Euler(17,33,-21));
            f.owner.transform.localScale = new Vector3(1.7f,0.6f,2.3f);
            Vector3[] polygon = { new Vector3(-1,-1,5), new Vector3(1,-1,5), new Vector3(1,0,5),
                new Vector3(0,0,5), new Vector3(0,1,5), new Vector3(-1,1,5) };
            Vector3[] second = { new Vector3(1.5f,-0.5f,5), new Vector3(2.5f,-0.5f,5),
                new Vector3(2.5f,0.5f,5), new Vector3(1.5f,0.5f,5) };
            Vector3[] positions = { new Vector3(-0.5f,0.5f,5), new Vector3(0.5f,0.5f,5),
                new Vector3(0.5f,-0.5f,5), new Vector3(-0.5f,0.5f,5.3f), new Vector3(2,0,5),
                new Vector3(-0.25f,0.25f,5), new Vector3(2.1f,0.1f,5), new Vector3(2.1f,0.1f,5.5f) };
            for (int i = 0; i < positions.Length; ++i) f.SetWorldPosition(32 + i, positions[i]);
            f.page.splatCount = 5; f.UpdatePageBounds();
            f.Select(new uint[] { 35,32,36,33,34 }, new uint[] { 1,4,0,3,2 });
            Require(f.renderer.DeletePagedSplatsInPolygon(polygon, Vector3.forward, 0.4f), "Concave polygon was rejected.");
            f.ExpectBits(32,34); // The notch and a point beyond half of Selection Depth survive.
            Require(f.renderer.DeletePagedSplatsInPolygon(second, Vector3.forward, 0.4f), "Second polygon was rejected.");
            f.ExpectBits(32,34,36);
            f.ExpectVisibility(new[] { 32,34,35,33,36 }, true,true,false,false,true);

            // Replay queues both polygon dispatches before executing. Distinct footprints must
            // remain distinct, rather than both reading the last uploaded polygon buffer.
            f.Replay(PageOffset, 5); f.ExpectBits(32,34,36);
            f.renderer.EditRestoreSphere(positions[0], 0.1f); f.ExpectBits(34,36);
            f.renderer.EditDeleteSphere(positions[1], 0.1f); f.ExpectBits(33,34,36);
            f.renderer.EditRestoreSphere(positions[1], 0.1f); f.ExpectBits(34,36);
            f.Replay(PageOffset, 5); f.ExpectBits(34,36);
            f.ExpectVisibility(new[] { 32,34,35,33,36 }, false,true,false,false,true);

            int journalCount = f.renderer.pagedLodEraseStrokeCount;
            Require(!f.renderer.DeletePagedSplatsInPolygon(new[] { Vector3.zero, Vector3.right, Vector3.right * 2 }, Vector3.forward, 0.4f),
                "A collinear polygon created an erase stroke.");
            Require(!f.renderer.DeletePagedSplatsInPolygon(polygon, Vector3.forward, float.NaN) &&
                f.renderer.pagedLodEraseStrokeCount == journalCount, "Invalid depth changed the journal.");

            // Nodes absent at edit time receive the captured polygon when their page detail arrives.
            f.page.splatCount = positions.Length; f.UpdatePageBounds(); f.Replay(PageOffset, positions.Length);
            f.ExpectBits(34,36,37,38);
            f.Select(new uint[] { 39,37,33,36,32,38,35,34 }, new uint[] { 7,0,4,2,5,1,6,3 });
            f.ExpectVisibility(new[] { 34,39,32,33,38,37,35,36 }, true,false,false,false,true,true,false,true);
            f.ReloadJournal(); f.ExpectBits(34,36,37,38);
            f.owner.transform.position += new Vector3(3,2,1);
            f.Replay(PageOffset, positions.Length); f.ExpectBits(34,36,37,38);
            f.renderer.EditRestoreSphere(f.WorldPoint(37), 0.1f); f.ExpectBits(34,36,38);
            f.ReloadJournal(); f.Replay(PageOffset, positions.Length); f.ExpectBits(34,36,38);
            f.renderer.ResetDeletedSplats(); f.ExpectBits();
            Require(f.renderer.pagedLodEraseStrokeCount == 0, "Reset retained polygon deletion history.");
        }

        static void ValidatePagedGeometry(Fixture f)
        {
            // Real paged renderers keep an eight-byte legacy position placeholder. Geometry
            // tools must never decode it as the full scene or write logical deletion bits.
            f.UsePagedPlaceholder();
            f.owner.transform.rotation = Quaternion.Euler(17, 33, -21);
            f.owner.transform.localScale = new Vector3(1.7f, 0.6f, 2.3f);
            Vector3 center = new Vector3(1, 0.25f, 7);
            Quaternion rotation = Quaternion.Euler(18, 37, 12);
            Vector3 size = new Vector3(2, 1, 3);
            Vector3[] boxLocal = { Vector3.zero, new Vector3(0.9f, 0.4f, 1.4f),
                new Vector3(1.1f, 0, 0), new Vector3(0, 0.6f, 0), new Vector3(0, 0, 1.6f),
                new Vector3(-0.9f, -0.4f, -1.4f) };
            for (int i = 0; i < boxLocal.Length; ++i) f.SetWorldPosition(32 + i, center + rotation * boxLocal[i]);
            f.page.splatCount = boxLocal.Length;
            f.UpdatePageBounds();
            f.renderer.DeleteSplatsInBox(center, size, rotation);
            f.ExpectBits(32, 33, 37);
            f.Select(new uint[] { 35, 32, 37, 34, 33, 36 }, new uint[] { 4, 0, 2, 5, 1, 3 });
            f.ExpectVisibility(new[] { 33, 35, 37, 36, 32, 34 }, true, false, true, false, true, false);
            f.renderer.EditRestoreSphere(center, 0.1f);
            f.ExpectBits(33, 37);
            f.Replay(PageOffset, boxLocal.Length);
            f.ExpectBits(33, 37);
            f.renderer.RestoreSplatsInBox(center, size, rotation);
            f.ExpectBits();
            f.renderer.DeleteSplatsInBox(center, size, rotation);
            f.ReloadJournal();
            f.ExpectBits(32, 33, 37);
            f.SetWorldPosition(38, center + rotation * new Vector3(0.2f, 0.2f, 0.2f));
            f.page.splatCount = 7;
            f.UpdatePageBounds();
            f.Replay(PageOffset, 7);
            f.ExpectBits(32, 33, 37, 38);
            f.SetWorldPosition(32, center + rotation * new Vector3(2, 0, 0));
            f.Replay(PageOffset, 7);
            f.ExpectBits(33, 37, 38);
            f.owner.transform.position += new Vector3(3, 2, 1);
            f.Replay(PageOffset, 7);
            f.ExpectBits(33, 37, 38);

            f.renderer.ResetDeletedSplats();
            Vector3 axis = rotation * Vector3.up;
            Vector3 radial = rotation * Vector3.right;
            Vector3[] cylinder = { center, center + axis * 0.9f + radial * 0.8f,
                center + axis * 1.2f, center - axis * 1.2f, center + radial * 1.2f,
                center - axis * 0.9f + radial * 0.8f };
            for (int i = 0; i < cylinder.Length; ++i) f.SetWorldPosition(32 + i, cylinder[i]);
            f.page.splatCount = cylinder.Length;
            f.UpdatePageBounds();
            f.renderer.DeleteSplatsInCylinderBounded(center, 1, 2, axis);
            f.ExpectBits(32, 33, 37); // Both axial caps and the radial boundary are enforced.
            f.ReloadJournal();
            f.ExpectBits(32, 33, 37);
            f.renderer.RestoreSplatsInCylinderBounded(center, 1, 2, axis);
            f.ExpectBits();
            f.renderer.EditDeleteCylinder(center + axis * 3, 1, axis);
            f.ExpectBits(32, 33, 34, 35, 37); // The existing unbounded brush reaches past both caps.
            f.renderer.ResetDeletedSplats();
            f.renderer.EditDeleteSphere(center, 0.1f);
            f.ExpectBits(32);
            f.renderer.EditRestoreSphere(center, 0.1f);
            f.ExpectBits();

            // Exact inclusive boundaries use identity transforms to avoid numerical ambiguity.
            f.renderer.ResetDeletedSplats();
            f.owner.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
            f.owner.transform.localScale = Vector3.one;
            f.SetPosition(32, new Vector3(1, 0, 7));
            f.SetPosition(33, new Vector3(0, 1, 7));
            f.SetPosition(34, new Vector3(0, -1, 7));
            f.SetPosition(35, new Vector3(1.01f, 0, 7));
            f.SetPosition(36, new Vector3(0, 1.01f, 7));
            f.page.splatCount = 5;
            f.UpdatePageBounds();
            f.renderer.DeleteSplatsInCylinderBounded(new Vector3(0, 0, 7), 1, 2, Vector3.up);
            f.ExpectBits(32, 33, 34);
            f.renderer.RestoreSplatsInCylinderBounded(new Vector3(0, 0, 7), 1, 2, Vector3.up);
            f.ExpectBits();
            f.renderer.DeleteSplatsInBox(new Vector3(0, 0, 7), Vector3.one * 2, Quaternion.identity);
            f.ExpectBits(32, 33, 34);
            f.renderer.RestoreSplatsInBox(new Vector3(0, 0, 7), Vector3.one * 2, Quaternion.identity);
            f.ExpectBits();
            Debug.Log("SplatBox paged Geometry validation PASS: eight-byte placeholder, oriented box, " +
                "bounded cylinder caps, transformed renderer, restore, remapping and persisted replay.");
        }

        static void ValidatePagedEditing(Fixture f)
        {
            // A stale logical deletion mask must not delete a different node in a paged selection.
            f.legacyDeleted.SetData(new uint[] { 1, 0, 0, 0 });
            f.Select(new uint[] { 33, 32, 35 }, new uint[] { 2, 0, 1 });
            f.ExpectVisibility(new[] { 35, 33, 32 }, false, false, false);
            f.renderer.EditDeleteSplatsInScreenCircle(f.ScreenPoint(32), 24, f.camera, false);
            Require(f.renderer.pagedLodEraseStrokeCount == 1, "Screen erase did not append one spatial stroke.");
            f.ExpectBits(32, 34);
            f.ExpectVisibility(new[] { 35, 33, 32 }, false, false, true);

            // No further brush input: LoD now exposes another node and changes both permutations.
            f.Select(new uint[] { 34, 35, 32, 33 }, new uint[] { 3, 2, 0, 1 });
            f.camera.transform.position = new Vector3(0.02f, 0, 0);
            f.ExpectVisibility(new[] { 33, 32, 34, 35 }, false, true, true, false);
            Require(f.renderer.pagedLodEraseStrokeCount == 1, "View updates kept appending erase strokes after input stopped.");
            f.camera.transform.position = Vector3.zero;

            // A different page takes the same aligned slot. The old bit is cleared before replay.
            f.SetPosition(32, new Vector3(0.7f, 0, 5));
            f.Replay(PageOffset, 4);
            f.ExpectBits(34);
            f.SetPosition(32, new Vector3(-1, 0, 5));
            f.Replay(PageOffset, 4);
            f.ExpectBits(32, 34);

            // A child that was not resident at stroke time is erased as soon as it uploads.
            f.SetPosition(36, new Vector3(-0.99f, 0.01f, 5));
            f.page.splatCount = 5;
            f.Replay(PageOffset, 5);
            f.ExpectBits(32, 34, 36);
            f.renderer.EditRestoreSphere(f.WorldPoint(32), 0.2f);
            f.ExpectBits(34);
            f.renderer.EditDeleteSphere(f.WorldPoint(32), 0.2f);
            f.ExpectBits(32, 34, 36);
            f.Replay(PageOffset, 5);
            f.ExpectBits(32, 34, 36);

            // GPU atlas lifetime and the serialized edit lifetime are independent.
            string serialized = EditorJsonUtility.ToJson(f.renderer);
            int strokes = f.renderer.pagedLodEraseStrokeCount;
            f.RecreateAtlas();
            f.EnsureJournal();
            Require(f.renderer.pagedLodEraseStrokeCount == strokes, "Atlas recreation discarded the edit journal.");
            f.ExpectBits(32, 34, 36);
            f.renderer.ResetDeletedSplats();
            Require(f.renderer.pagedLodEraseStrokeCount == 0 && f.Mask == null,
                "Reset did not clear the paged journal and GPU mask.");
            f.ExpectVisibility(new[] { 33, 32, 34, 35 }, false, false, false, false);
            EditorJsonUtility.FromJsonOverwrite(serialized, f.renderer);
            // EditorJsonUtility cannot resolve an unsaved scene component reference. Normal
            // resource initialization reconnects this component with GetComponent as well.
            Set(f.renderer, "m_LodStreamer", f.owner.GetComponent<SplatBoxLodStreamer>());
            f.EnsureJournal();
            Require(f.renderer.pagedLodEraseStrokeCount == strokes, "Serialized edits did not survive reload: visible count=" +
                f.renderer.pagedLodEraseStrokeCount + ", stored count=" +
                Get<System.Collections.IList>(f.renderer, "m_PagedEraseStrokes").Count + ", paged=" + f.renderer.UsesPagedLod +
                ", same scene=" + (Get<GaussianSplatPagedScene>(f.renderer, "m_PagedEraseScene") == f.renderer.pagedScene) +
                ", serialized contains journal=" + serialized.Contains("m_PagedEraseStrokes"));
            f.ExpectBits(32, 34, 36);

            // Undo must restore a previous journal, rather than leave its GPU bitset stale.
            f.renderer.ResetDeletedSplats();
            Undo.FlushUndoRecordObjects();
            Undo.IncrementCurrentGroup();
            f.renderer.EditDeleteSphere(f.WorldPoint(32), 0.2f);
            Undo.FlushUndoRecordObjects();
            f.ExpectBits(32, 36);
            Undo.PerformUndo();
            f.EnsureJournal();
            Require(f.renderer.pagedLodEraseStrokeCount == 0 && f.Mask == null,
                "Undo left the spatial journal or erased GPU bits active.");

            // A depth-limited screen stroke removes the original front layer only.
            f.Select(new uint[] { 32, 34, 33 }, new uint[] { 1, 2, 0 });
            f.renderer.EditDeleteSplatsInScreenCircle(f.ScreenPoint(32), 24, f.camera, true);
            f.ExpectBits(32, 36);
            f.Replay(PageOffset, 5);
            f.ExpectBits(32, 36);
            f.renderer.EditDeleteSplatsInScreenCircle(f.ScreenPoint(32), 24, f.camera, true);
            f.ExpectBits(32, 34, 36); // Min-depth search must skip the already erased front layer.

            f.renderer.ResetDeletedSplats();
            f.renderer.EditDeleteCylinder(f.WorldPoint(34), 0.8f, Vector3.forward);
            f.ExpectBits(32, 34, 36);
            f.renderer.EditRestoreCylinder(f.WorldPoint(34), 0.8f, Vector3.forward);
            f.ExpectBits();

            // The same soft edge must replay identically at another atlas address.
            // Pick a nonempty edge sample without assuming identical floating-point noise
            // thresholds across graphics vendors. Each attempt starts a single-stroke journal.
            uint original = 0;
            for (int seed = 0; seed < 16 && original == 0; ++seed)
            {
                f.renderer.ResetDeletedSplats();
                f.renderer.DeleteSplatsInSphereWithFalloff(f.WorldPoint(32) + Vector3.right * 0.6f,
                    1.1f, 1f, 0.4f, 1.3f, 0.271f + seed * 0.531f);
                original = f.ReadMask()[1] & 31u;
            }
            Require(original != 0 && original != 31u, "The deterministic falloff fixture needs erased and preserved geometry.");
            f.Replay(PageOffset, 5);
            Require((f.ReadMask()[1] & 31u) == original, "Soft erase changed on replay in the same slot.");
            for (int i = 0; i < 5; ++i) f.SetPosition(64 + i, f.Position(32 + i));
            f.page.atlasOffset = f.page.uploadedAtlasOffset = 64;
            f.Replay(64, 5);
            Require((f.ReadMask()[2] & 31u) == original,
                "Soft erase depended on atlas indices instead of geometry and its captured seed.");
            f.owner.transform.position += new Vector3(3, 2, 1);
            f.Replay(64, 5);
            Require((f.ReadMask()[2] & 31u) == original,
                "Moving the renderer changed the replayed erase region relative to its splats.");
            f.renderer.ResetDeletedSplats();
            f.EnsureJournal();
            Require(f.Mask == null && f.renderer.pagedLodEraseStrokeCount == 0,
                "Cleared edits returned during a later replay tick.");
        }

        static void ValidateAggressiveScreenErase(string shader, bool paged, bool packed, bool ortho)
        {
            using var f=new Fixture(shader,paged);
            try
            {
                f.owner.transform.SetPositionAndRotation(new Vector3(-1,.5f,1),Quaternion.Euler(13,-23,9));
                f.owner.transform.localScale=new Vector3(1.2f,.8f,1.1f);
                f.camera.transform.SetPositionAndRotation(new Vector3(2,-1,-2),Quaternion.Euler(12,34,0));
                f.camera.orthographic=ortho; f.camera.orthographicSize=3;
                Vector3 origin=f.camera.transform.position, forward=f.camera.transform.forward, right=f.camera.transform.right;
                var raw=Get<float[]>(f,"positions"); for(int i=0;i<raw.Length;i++) raw[i]=8;
                f.SetWorldPosition(32,origin+forward*3);
                f.SetWorldPosition(33,origin+forward*3.025f); // part of the thin visible surface
                f.SetWorldPosition(34,origin+forward*3.10f); // the old 15 cm reach incorrectly removed this rear layer
                f.SetWorldPosition(35,origin+forward*5);
                f.SetWorldPosition(36,origin+forward*3+right*2); // outside brush
                f.SetWorldPosition(37,origin-forward*2); // behind camera, including orthographic
                if(paged) f.SetWorldPosition(38,origin+forward*3.03f); // front-surface detail arriving after the dab
                f.page.splatCount=6; f.UpdatePageBounds();
                if(packed)
                {
                    var asset=Get<GaussianSplatAsset>(f,"asset"); var data=Get<TextAsset>(f,"data");
                    asset.Initialize(Capacity,GaussianSplatAsset.VectorFormat.Norm11,GaussianSplatAsset.VectorFormat.Float32,
                        GaussianSplatAsset.ColorFormat.Float32x4,GaussianSplatAsset.SHFormat.Float32,Vector3.one*-10,Vector3.one*10,null);
                    asset.SetAssetFiles(data,data,data,data,data);
                    var positions=new uint[Capacity];
                    for(int i=0;i<Capacity;i++)
                    {
                        Vector3 p=(f.Position(i)+Vector3.one*10)/20;
                        positions[i]=(uint)Mathf.RoundToInt(p.x*2047) | (uint)Mathf.RoundToInt(p.y*1023)<<11 | (uint)Mathf.RoundToInt(p.z*2047)<<21;
                    }
                    Get<GraphicsBuffer>(f,"pos").SetData(positions);
                    Get<GraphicsBuffer>(f,"chunks").SetData(new[]{new GaussianSplatAsset.ChunkInfo {
                        posX=new float2(-10,10),posY=new float2(-10,10),posZ=new float2(-10,10),
                        colR=0x3c000000,colG=0x3c000000,colB=0x3c000000,colA=0x3c000000 }});
                    Set(f.renderer,"m_GpuChunksValid",true);
                    if(paged)
                    {
                        Set(f.renderer,"m_GpuLodUnifiedChunks",Get<GraphicsBuffer>(f,"chunks"));
                        Set(f.renderer,"m_LodUnifiedChunkCount",1);
                    }
                }
                if(paged)
                {
                    f.UsePagedPlaceholder();
                    f.Select(new uint[]{35,32,37,33,36,34},new uint[]{4,1,5,0,2,3});
                    // Stale monolithic bits must not hide a different paged atlas index.
                    f.legacyDeleted.SetData(new uint[]{uint.MaxValue,uint.MaxValue,uint.MaxValue,uint.MaxValue});
                }
                Vector2 pixel=f.ScreenPoint(32);
                f.renderer.EditDeleteSplatsInScreenCircle(pixel,24,f.camera,true);
                f.ExpectEditingBits(32,33);
                if(paged)
                {
                    f.page.splatCount=7;
                    f.Replay(38,1); f.ExpectBits(32,33,38);
                    Vector3 savedPosition=f.camera.transform.position; Quaternion savedRotation=f.camera.transform.rotation;
                    f.camera.transform.SetPositionAndRotation(Vector3.one*20,Quaternion.Euler(0,180,0));
                    f.Replay(PageOffset,7); f.ExpectBits(32,33,38);
                    f.camera.transform.SetPositionAndRotation(savedPosition,savedRotation);
                }
                f.renderer.EditDeleteSplatsInScreenCircle(pixel,24,f.camera,true);
                f.ExpectEditingBits(paged ? new[]{32,33,34,38} : new[]{32,33,34});
                f.renderer.EditDeleteSplatsInScreenCircle(pixel,24,f.camera,true);
                f.ExpectEditingBits(paged ? new[]{32,33,34,35,38} : new[]{32,33,34,35});
                if(paged) { f.Replay(PageOffset,7); f.ExpectBits(32,33,34,35,38); }
                f.renderer.ResetDeletedSplats();
                f.renderer.EditDeleteSplatsInScreenCircle(pixel,24,f.camera,false);
                f.ExpectEditingBits(paged ? new[]{32,33,34,35,38} : new[]{32,33,34,35});
            }
            finally { if(paged && packed) Set(f.renderer,"m_GpuLodUnifiedChunks",null); }
        }

        public static void RunAggressiveScreenErase()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders,"Use an isolated batch project with graphics");
            var errors=new List<string>(); Application.LogCallback observe=(message,stack,type)=>
            { if(type==LogType.Error || type==LogType.Exception || type==LogType.Assert) errors.Add(message); };
            Application.logMessageReceived+=observe;
            try
            {
                foreach(string shader in new[]{"Resources/BoxUtil.compute","Shaders/BoxUtil.compute"})
                foreach(bool paged in new[]{false,true})
                foreach(bool packed in new[]{false,true})
                foreach(bool ortho in new[]{false,true}) ValidateAggressiveScreenErase(shader,paged,packed,ortho);
                Require(errors.Count==0,"Aggressive erase errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox Front Surface Eraser PASS: thin front layer, nearby rear-layer protection, repeated dabs advance past erased splats, outside/behind-camera protection, perspective/orthographic, packed/raw monolithic and paged remapping, captured-depth replay and late detail; both compute shaders.");
            }
            finally { Application.logMessageReceived-=observe; }
        }

        static void ValidateMonolithicEditing(Fixture f)
        {
            f.legacyDeleted.SetData(new uint[Capacity / 32]);
            f.renderer.EditDeleteSphere(f.WorldPoint(32), 0.2f);
            var bits = new uint[Capacity / 32];
            f.legacyDeleted.GetData(bits);
            Require(bits[1] == 1 && bits[0] == 0 && bits[2] == 0 && bits[3] == 0,
                "Monolithic sphere erase stopped using its original deletion mask.");
            var view = f.Views();
            Require(view[32].clip.w == 0 && view[33].clip.w != 0 && view[34].clip.w != 0 &&
                f.renderer.pagedLodEraseStrokeCount == 0, "Paged editing changed monolithic visibility.");
            f.renderer.EditRestoreSphere(f.WorldPoint(32), 0.2f);
            f.legacyDeleted.GetData(bits);
            Require(bits[1] == 0 && f.Views()[32].clip.w != 0, "Monolithic restore no longer restores visibility.");
        }

        sealed class Fixture : IDisposable
        {
            public readonly GameObject owner, cameraOwner;
            public readonly SplatBoxRenderer renderer;
            public readonly SplatBoxLodStreamer streamer;
            public readonly Camera camera;
            public readonly SplatBoxPageGpuState page;
            public readonly GraphicsBuffer legacyDeleted;
            readonly GaussianSplatAsset asset;
            readonly GaussianSplatPagedScene scene;
            readonly string sceneAssetPath;
            readonly TextAsset data;
            readonly RenderTexture target;
            readonly GraphicsBuffer chunks, order, distances, selected, views, drawArgs, indices;
            readonly ComputeShader shader;
            readonly float oldRenderScale;
            readonly float[] positions = new float[Capacity * 3];
            GraphicsBuffer pos, other, sh, remap;
            GraphicsBuffer legacyPlaceholder;
            Texture2D color;
            uint[] active = new uint[] { 32, 33, 34 };

            public Fixture(string shaderPath, bool paged)
            {
                oldRenderScale = GaussianSplatRenderSystem.SplatRenderScale;
                owner = new GameObject("Paged erase regression fixture");
                owner.SetActive(false);
                renderer = owner.AddComponent<SplatBoxRenderer>();
                streamer = owner.AddComponent<SplatBoxLodStreamer>();
                cameraOwner = new GameObject("Paged erase regression camera");
                cameraOwner.SetActive(false);
                camera = cameraOwner.AddComponent<Camera>();
                camera.fieldOfView = 60;
                target = new RenderTexture(640, 480, 0);
                camera.targetTexture = target;
                owner.transform.position = new Vector3(2, 1, 0);
                shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + shaderPath);
                Require(shader != null && shader.IsSupported(shader.FindKernel("CSApplyPagedErase")) &&
                    shader.IsSupported(shader.FindKernel("CSClearPagedErase")), "Paged erase kernels failed to compile: " + shaderPath);
                Set(renderer, "m_CSBoxUtil", shader);
                Set(renderer, "m_ShaderSplats", AssetDatabase.LoadAssetAtPath<Shader>(Root + "Resources/RenderSplats.shader"));
                Set(renderer, "m_SplatCount", Capacity);
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_EnableDistanceCulling", false);
                Set(renderer, "m_SplatScale", 1f);
                Set(renderer, "m_OpacityScale", 1f);
                asset = ScriptableObject.CreateInstance<GaussianSplatAsset>();
                asset.Initialize(Capacity, GaussianSplatAsset.VectorFormat.Float32, GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.ColorFormat.Float32x4, GaussianSplatAsset.SHFormat.Float32, Vector3.zero, Vector3.one, null);
                data = new TextAsset("Synthetic GPU fixture data");
                asset.SetAssetFiles(null, data, data, data, data);
                Set(renderer, "m_Asset", asset);
                Set(renderer, "m_LodFormatAsset", asset);
                if (paged)
                {
                    scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
                    scene.Initialize(Vector3.zero, Vector3.one * 20, 20,
                        new[] { new GaussianSplatPageEntry { pageId = 1, splatCount = 5 } });
                    // The journal references the source manifest. Persist it like a real imported
                    // paged scene so editor JSON/Undo can resolve its asset GUID after reload.
                    sceneAssetPath = "Assets/__PagedEditingValidation_" + Guid.NewGuid().ToString("N") + ".asset";
                    AssetDatabase.CreateAsset(scene, sceneAssetPath);
                    Set(renderer, "m_PagedScene", scene);
                }
                chunks = Buffer(GraphicsBuffer.Target.Structured, 1, 64, "m_GpuChunks");
                chunks.SetData(new GaussianSplatAsset.ChunkInfo[1]);
                order = Buffer(GraphicsBuffer.Target.Structured, Capacity, 4, "m_GpuSortKeys");
                distances = Buffer(GraphicsBuffer.Target.Structured, Capacity, 4, "m_GpuSortDistances");
                selected = Buffer(GraphicsBuffer.Target.Raw, Capacity / 32, 4, "m_GpuEditSelected");
                legacyDeleted = Buffer(GraphicsBuffer.Target.Raw, Capacity / 32, 4, "m_GpuEditDeleted");
                selected.SetData(new uint[Capacity / 32]);
                legacyDeleted.SetData(new uint[Capacity / 32]);
                views = Buffer(GraphicsBuffer.Target.Structured, Capacity, Marshal.SizeOf<View>(), "m_GpuView");
                drawArgs = Buffer(GraphicsBuffer.Target.Structured, 5, 4, "m_GpuDrawArgs");
                drawArgs.SetData(new uint[] { 6, Capacity, 0, 0, 0 });
                indices = Buffer(GraphicsBuffer.Target.Index, 6, 2, "m_GpuIndexBuffer");
                indices.SetData(new ushort[] { 0, 1, 2, 1, 3, 2 });
                for (int i = 0; i < Capacity; ++i) SetPositionData(i, new Vector3(40, 40, 40));
                SetPositionData(32, new Vector3(-1, 0, 5));
                SetPositionData(33, new Vector3(1, 0, 5));
                SetPositionData(34, new Vector3(-0.6f, 0.4f, 7));
                SetPositionData(35, new Vector3(-1, -1, 5));
                page = new SplatBoxPageGpuState
                {
                    atlasOffset = PageOffset, uploadedAtlasOffset = PageOffset, pageId = 1, pageSlot = 0,
                    splatCount = 4, isCoarseStub = false, bounds = new Bounds(new Vector3(0, 0, 6), Vector3.one * 20),
                    lodTree = LodTreeRuntime.Build(new[] { new LodTreeNode { featureSize = 1 } }, true)
                };
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(page);
                CreateAtlas();
                Select(new uint[] { 32, 33, 34 }, new uint[] { 0, 1, 2 });
                if (!paged)
                {
                    var identity = new uint[Capacity];
                    for (uint i = 0; i < identity.Length; ++i) identity[i] = i;
                    order.SetData(identity);
                }
                Require(renderer.HasValidAsset && renderer.HasValidRenderSetup, "Incomplete renderer editing fixture.");
            }

            GraphicsBuffer Buffer(GraphicsBuffer.Target kind, int count, int stride, string field)
            {
                var result = new GraphicsBuffer(kind, count, stride);
                Set(renderer, field, result);
                return result;
            }

            void CreateAtlas()
            {
                pos = Buffer(GraphicsBuffer.Target.Raw, Capacity * 3, 4, "m_GpuLodUnifiedPos");
                other = Buffer(GraphicsBuffer.Target.Raw, Capacity * 4, 4, "m_GpuLodUnifiedOther");
                sh = Buffer(GraphicsBuffer.Target.Raw, Capacity * 48, 4, "m_GpuLodUnifiedSh");
                remap = Buffer(GraphicsBuffer.Target.Structured, Capacity, 4, "m_GpuLodAtlasIndices");
                pos.SetData(positions);
                var otherData = new uint[Capacity * 4];
                for (int i = 0; i < Capacity; ++i)
                {
                    otherData[i * 4] = 0xE0080200u;
                    otherData[i * 4 + 1] = math.asuint(0.1f);
                    otherData[i * 4 + 2] = math.asuint(0.1f);
                    otherData[i * 4 + 3] = math.asuint(0.1f);
                }
                other.SetData(otherData);
                sh.SetData(new float[Capacity * 48]);
                remap.SetData(active);
                color = new Texture2D(16, 16, TextureFormat.RGBAFloat, false, true);
                var pixels = new Color[256];
                for (int i = 0; i < pixels.Length; ++i) pixels[i] = new Color(0.6f, 0.4f, 0.2f, 0.8f);
                color.SetPixels(pixels);
                color.Apply();
                Set(renderer, "m_GpuLodUnifiedColor", color);
                Set(renderer, "m_LodAtlasCapacity", Capacity);
                Set(renderer, "m_UnifiedAtlasSplatCount", Capacity);
                Set(renderer, "m_GpuPosData", legacyPlaceholder ?? pos);
                Set(renderer, "m_GpuOtherData", other);
                Set(renderer, "m_GpuSHData", sh);
                Set(renderer, "m_GpuColorData", color);
                page.gpuPosData = pos;
            }

            public void RecreateAtlas()
            {
                ClearBaseAliases();
                Call(renderer, "DisposeLodAtlasBuffers");
                pos = other = sh = remap = null;
                color = null;
                CreateAtlas();
            }

            public void UsePagedPlaceholder()
            {
                legacyPlaceholder ??= new GraphicsBuffer(GraphicsBuffer.Target.Raw, 2, 4);
                legacyPlaceholder.SetData(new uint[] { 0x12345678, 0xABCDEF01 });
                Set(renderer, "m_GpuPosData", legacyPlaceholder);
            }
            public void SetWorldPosition(int index, Vector3 value) => SetPosition(index, owner.transform.InverseTransformPoint(value));
            public void UpdatePageBounds()
            {
                var bounds = new Bounds(Position(page.atlasOffset), Vector3.zero);
                for (int i = 1; i < page.splatCount; ++i) bounds.Encapsulate(Position(page.atlasOffset + i));
                page.bounds = bounds;
            }
            public void ReloadJournal()
            {
                string serialized = EditorJsonUtility.ToJson(renderer);
                int count = renderer.pagedLodEraseStrokeCount;
                RecreateAtlas();
                EnsureJournal();
                renderer.ResetDeletedSplats();
                EditorJsonUtility.FromJsonOverwrite(serialized, renderer);
                Set(renderer, "m_LodStreamer", streamer);
                EnsureJournal();
                Require(renderer.pagedLodEraseStrokeCount == count, "Geometry journal was lost on reload.");
            }

            public GraphicsBuffer Mask => Get<GraphicsBuffer>(renderer, "m_GpuPagedLodDeletedBits");
            public uint[] ReadMask()
            {
                var result = new uint[Capacity / 32];
                Mask?.GetData(result);
                return result;
            }
            public void ExpectBits(params int[] erased)
            {
                var expected = new uint[Capacity / 32];
                foreach (int index in erased) expected[index / 32] |= 1u << (index & 31);
                uint[] actual = ReadMask();
                for (int i = 0; i < actual.Length; ++i)
                    Require(actual[i] == expected[i], "Unexpected paged erase bits in word " + i + ": " + actual[i] + ", expected " + expected[i]);
            }
            public void ExpectEditingBits(params int[] erased)
            {
                if (renderer.UsesPagedLod) { ExpectBits(erased); return; }
                var expected = new uint[Capacity / 32];
                foreach (int index in erased) expected[index / 32] |= 1u << (index & 31);
                var actual = new uint[Capacity / 32]; legacyDeleted.GetData(actual);
                for (int i = 0; i < actual.Length; ++i)
                    Require(actual[i] == expected[i], "Unexpected monolithic erase bits in word " + i + ": " + actual[i] + ", expected " + expected[i]);
            }
            public Vector3 Position(int index) => new Vector3(positions[index * 3], positions[index * 3 + 1], positions[index * 3 + 2]);
            public Vector3 WorldPoint(int index) => owner.transform.TransformPoint(Position(index));
            public Vector2 ScreenPoint(int index)
            {
                Vector4 clip = GL.GetGPUProjectionMatrix(camera.projectionMatrix, false) * camera.worldToCameraMatrix *
                    new Vector4(WorldPoint(index).x, WorldPoint(index).y, WorldPoint(index).z, 1);
                return new Vector2((clip.x / clip.w * 0.5f + 0.5f) * camera.pixelWidth,
                    (0.5f - clip.y / clip.w * 0.5f) * camera.pixelHeight);
            }
            void SetPositionData(int index, Vector3 value)
            {
                positions[index * 3] = value.x;
                positions[index * 3 + 1] = value.y;
                positions[index * 3 + 2] = value.z;
            }
            public void SetPosition(int index, Vector3 value) { SetPositionData(index, value); pos.SetData(positions); }
            public void Select(uint[] indices, uint[] sorted)
            {
                active = indices;
                remap.SetData(indices);
                order.SetData(sorted);
                Set(renderer, "m_ActiveSplatCount", indices.Length);
            }
            public void Replay(int offset, int count) => Call(renderer, "ReplayPagedLodEraseRange", null, offset, count);
            public void EnsureJournal() => Call(renderer, "EnsurePagedLodEraseState", new object[] { null });
            public View[] Views()
            {
                using var cmd = new CommandBuffer { name = "Validate paged erased geometry visibility" };
                Call(renderer, "CalcViewData", cmd, camera, owner.transform.localToWorldMatrix);
                Graphics.ExecuteCommandBuffer(cmd);
                var result = new View[Capacity];
                views.GetData(result);
                return result;
            }
            public void ExpectVisibility(int[] atlasIndices, params bool[] hidden)
            {
                var actual = Views();
                for (int i = 0; i < atlasIndices.Length; ++i)
                {
                    Require((actual[i].clip.w == 0) == hidden[i], "Erasure changed the wrong draw slot " + i);
                    if (!hidden[i]) Require(Vector3.Distance(actual[i].world, WorldPoint(atlasIndices[i])) < 0.001f,
                        "Visible draw slot resolved the wrong atlas geometry.");
                }
            }
            public void ValidateDrawBindings(string shaderPath)
            {
                // Optional editor resources can disappear during tool changes/rebuilds. Test
                // the final production binder, including actual draws rather than only handles.
                var drawShader = AssetDatabase.LoadAssetAtPath<Shader>(Root + shaderPath);
                Require(drawShader != null && drawShader.isSupported, "Unsupported draw shader: " + shaderPath);
                var material = new Material(drawShader);
                var readback = new Texture2D(target.width, target.height, TextureFormat.RGBA32, false, true);
                var block = new MaterialPropertyBlock();
                bool instancing = Shader.IsKeywordEnabled("STEREO_INSTANCING_ON");
                bool multiview = Shader.IsKeywordEnabled("STEREO_MULTIVIEW_ON");
                var oldScreen = Shader.GetGlobalVector("_ScreenParams");
                try
                {
                    typeof(GaussianSplatRenderSystem).GetMethod("BindDefaultDrawMaterial",
                        BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { material });
                    material.SetVector("_SplatRenderTargetSize", new Vector4(target.width, target.height,
                        1f / target.width, 1f / target.height));
                    material.SetTexture("_CameraDepthTexture", Texture2D.whiteTexture);
                    material.SetTexture("_MeshTex", Texture2D.whiteTexture);
                    material.SetTexture("_EquirectTexture", Texture2D.whiteTexture);
                    material.SetFloat("_AmbientIntensity", 1); material.SetFloat("_DirectionalIntensity", 0);
                    material.SetFloat("_ShadowStrength", 0); material.SetFloat("_AmbientShadowStrength", 0);
                    material.SetFloat("_AmbientShadowDistanceScale", 0); material.SetFloat("_SSAOStrength", 0);
                    Set(renderer, "m_ActiveSplatCount", Capacity);
                    var data = new View[Capacity];
                    data[0] = new View { clip = new Vector4(0, 0, 0.5f, 1),
                        axis1 = Pack(10, 0), axis2 = Pack(0, 10), color1 = Pack(0.3f, 0.5f),
                        color2 = Pack(0.7f, 0.8f), index = Capacity - 1 };
                    views.SetData(data);
                    Set(renderer, "m_GpuEditSelected", null);
                    Set(renderer, "m_GpuEditDeleted", null);
                    for (int mode = 0; mode < 3; ++mode)
                    {
                        using var cmd = new CommandBuffer { name = "Validate renderer draw descriptors" };
                        typeof(GaussianSplatRenderSystem).GetMethod("InvokeBeforeDrawSplats",
                            BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer, cmd, block });
                        if (mode == 2)
                        {
                            Set(renderer, "m_GpuEditSelected", selected);
                            Set(renderer, "m_GpuEditDeleted", legacyDeleted);
                        }
                        if (mode > 0)
                        {
                            Call(renderer, "SetAssetDataOnMaterial", block);
                            Require((bool)Call(renderer, "BindRequiredDrawBuffers", block), "Valid draw resources were rejected.");
                            var fallback = Get<GraphicsBuffer>(renderer, "m_GpuDrawEmptyEditBits");
                            Require(fallback != null && fallback.count >= Capacity / 32, "Optional mask fallback is undersized.");
                            var bits = new uint[fallback.count]; fallback.GetData(bits);
                            foreach (uint word in bits) Require(word == 0, "Optional mask fallback contains stale selection bits.");
                        }
                        cmd.DisableShaderKeyword("STEREO_INSTANCING_ON");
                        cmd.DisableShaderKeyword("STEREO_MULTIVIEW_ON");
                        cmd.SetRenderTarget(target); cmd.SetViewport(new Rect(0, 0, target.width, target.height));
                        cmd.ClearRenderTarget(false, true, Color.clear);
                        cmd.SetGlobalVector("_ScreenParams", new Vector4(target.width, target.height, 1, 1));
                        cmd.DrawProcedural(indices, Matrix4x4.identity, material, 0, MeshTopology.Triangles,
                            6, 1, mode == 0 ? null : block);
                        Graphics.ExecuteCommandBuffer(cmd);
                        var previous = RenderTexture.active;
                        try
                        {
                            RenderTexture.active = target;
                            readback.ReadPixels(new Rect(0, 0, target.width, target.height), 0, 0, false);
                            readback.Apply(false);
                            float alpha = readback.GetPixel(target.width / 2, target.height / 2).a;
                            Require(mode == 0 ? alpha == 0 : alpha > 0.5f,
                                "Default or populated renderer descriptors produced incorrect draw output, shader=" + shaderPath + ", mode=" + mode);
                        }
                        finally { RenderTexture.active = previous; }
                    }
                    Set(renderer, "m_GpuView", null);
                    Require(!(bool)Call(renderer, "BindRequiredDrawBuffers", block), "A draw without view data was accepted.");
                    Debug.Log("SplatBox material draw binding validation PASS: " + shaderPath);
                }
                finally
                {
                    Set(renderer, "m_GpuView", views);
                    Set(renderer, "m_GpuEditSelected", selected);
                    Set(renderer, "m_GpuEditDeleted", legacyDeleted);
                    if (instancing) Shader.EnableKeyword("STEREO_INSTANCING_ON");
                    if (multiview) Shader.EnableKeyword("STEREO_MULTIVIEW_ON");
                    Shader.SetGlobalVector("_ScreenParams", oldScreen);
                    UnityEngine.Object.DestroyImmediate(material);
                    UnityEngine.Object.DestroyImmediate(readback);
                }
            }
            static uint Pack(float high, float low) => ((uint)Mathf.FloatToHalf(high) << 16) | Mathf.FloatToHalf(low);
            void ClearBaseAliases()
            {
                Set(renderer, "m_GpuPosData", null);
                Set(renderer, "m_GpuOtherData", null);
                Set(renderer, "m_GpuSHData", null);
                Set(renderer, "m_GpuColorData", null);
                page.gpuPosData = null;
            }
            public void Dispose()
            {
                Undo.ClearUndo(renderer);
                ClearBaseAliases();
                foreach (string field in new[] { "m_GpuChunks", "m_GpuSortKeys", "m_GpuSortDistances", "m_GpuEditSelected",
                    "m_GpuEditDeleted", "m_GpuView", "m_GpuDrawArgs", "m_GpuIndexBuffer" }) Set(renderer, field, null);
                Call(renderer, "DisposeResourcesForAsset");
                chunks.Dispose(); order.Dispose(); distances.Dispose(); selected.Dispose(); legacyDeleted.Dispose(); views.Dispose(); drawArgs.Dispose();
                indices.Dispose();
                legacyPlaceholder?.Dispose();
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
                UnityEngine.Object.DestroyImmediate(target);
                UnityEngine.Object.DestroyImmediate(asset);
                UnityEngine.Object.DestroyImmediate(data);
                if (!string.IsNullOrEmpty(sceneAssetPath)) AssetDatabase.DeleteAsset(sceneAssetPath);
                else if (scene != null) UnityEngine.Object.DestroyImmediate(scene);
                GaussianSplatRenderSystem.SplatRenderScale = oldRenderScale;
            }
        }

        static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Private).GetValue(target);
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Private).SetValue(target, value);
        static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Private).Invoke(target, args);
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    }
}
