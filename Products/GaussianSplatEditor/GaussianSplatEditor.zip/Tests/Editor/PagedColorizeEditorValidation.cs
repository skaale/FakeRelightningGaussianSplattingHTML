// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    public static class PagedColorizeEditorValidation
    {
        const BindingFlags Flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
        [StructLayout(LayoutKind.Sequential,Pack=4)]
        struct View { public Vector4 clip; public uint a,b,c,d; public Vector3 world; public uint index; }
        static void Require(bool value,string message) { if(!value) throw new InvalidOperationException(message); }
        static void Set(object owner,string field,object value)=>owner.GetType().GetField(field,Flags).SetValue(owner,value);
        static object Call(object owner,string method,params object[] args)=>owner.GetType().GetMethod(method,Flags).Invoke(owner,args);
        static Color BaseColor=>new Color(.6f,.4f,.2f,.8f);
        static void Preload(SplatBoxRenderer source,Camera camera)
        {
            Require(source.ForceRebuildPagedLodInEditor(),"Colorize source did not initialize.");
            for(int i=0;i<10;++i) { if(source.lodStreamer!=null) Set(source.lodStreamer,"m_LastPageUploadFrame",-1); source.PreloadPagedLodPages(camera); }
        }
        static void ColorIs(Color actual,Color expected,string label)
        {
            Require(Mathf.Abs(actual.r-expected.r)<.012f && Mathf.Abs(actual.g-expected.g)<.012f &&
                Mathf.Abs(actual.b-expected.b)<.012f && Mathf.Abs(actual.a-expected.a)<.006f,
                label+": expected "+expected+", got "+actual);
        }
        static void CenterIs(SplatBoxRenderer source,Camera camera,Color expected,string label,int expectedCount=2,float depth=5)
        {
            var colors=new Color[8];
            Require(source.SamplePaintColors(camera,new Vector2(320,240),16,depth,.04f,colors,out int count)&&count==expectedCount,
                label+": wrong source sample count "+count);
            for(int i=0;i<count;++i) ColorIs(colors[i],expected,label);
        }
        static void DrawIs(SplatBoxRenderer source,Camera camera,RenderTexture target,Color center,Color left)
        {
            typeof(PagedXcopyCameraValidation).GetMethod("Draw",BindingFlags.Static|BindingFlags.NonPublic)
                .Invoke(null,new object[]{camera,target,new List<SplatBoxRenderer>()});
            var data=new View[source.activeSplatCount];
            ((GraphicsBuffer)source.GetType().GetField("m_GpuView",Flags).GetValue(source)).GetData(data);
            int visible=0;
            foreach(var item in data) if(item.clip.w>0)
            {
                ++visible;
                Color actual=new Color(Mathf.HalfToFloat((ushort)(item.c>>16)),Mathf.HalfToFloat((ushort)item.c),
                    Mathf.HalfToFloat((ushort)(item.d>>16)),Mathf.HalfToFloat((ushort)item.d));
                float x=source.transform.InverseTransformPoint(item.world).x;
                ColorIs(actual,Mathf.Abs(x)<.25f?center:x<-.5f?left:BaseColor,"Rendered Colorize");
            }
            Require(visible==6,"Colorize hid splats or changed selection coverage: "+visible);
        }
        static GaussianSplatColorizeBrush Brush(SplatBoxRenderer source)
        {
            var holder=new GameObject("Colorize validation brush"); holder.SetActive(false);
            var brush=holder.AddComponent<GaussianSplatColorizeBrush>(); brush.TargetRenderer=source;
            brush.Falloff=0; brush.BlendStrength=1; brush.UseNoise=false; return brush;
        }
        static void Stroke(GaussianSplatColorizeBrush brush,Color color,Vector3 point,float radius=.3f)
        {
            brush.TargetColor=color; brush.PushUndoState(); brush.ColorizeAtPosition(point,radius); brush.EndStroke();
        }

        public static void RunAll()
        {
            Require(Application.isBatchMode,"Run in an isolated batch project with a graphics device.");
            ColorizeLayoutValidation.Run();
            PagedColorizeGpuValidation.Run();
            Run();
            Debug.Log("SplatBox paged Colorize suite PASS.");
        }
        public static void RunCompatibility()
        {
            Require(Application.isBatchMode,"Run in an isolated batch project with a graphics device.");
            PaintSamplingValidation.Run();
            PagedFillValidation.Run();
            PagedLodEditingValidation.Run();
            ZeroShOrderValidation.Run();
            DistantPointComputeValidation.Run();
            MobileRenderingValidation.Run();
            Debug.Log("SplatBox Colorize compatibility PASS: Paint, Fill, paged editing, SH and shared rendering kernels.");
        }
        public static void Run()
        {
            Require(Application.isBatchMode,"Run in an isolated batch project with a graphics device.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            object fixture=null; GaussianSplatEditorWindow window=null; RenderTexture target=null; SceneView sceneView=null;
            string scenePath="Assets/__ColorizeValidation_"+Guid.NewGuid().ToString("N")+".unity"; string copyPath=null;
            var errors=new List<string>();
            Application.LogCallback observe=(message,stack,type)=>{if(type==LogType.Error||type==LogType.Exception||type==LogType.Assert)errors.Add(message);};
            Application.logMessageReceived+=observe;
            try
            {
                var type=typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture",BindingFlags.NonPublic);
                fixture=Activator.CreateInstance(type,Flags,null,new object[]{false},null);
                Call(fixture,"AssignScene"); Call(fixture,"PublishPages");
                var source=(SplatBoxRenderer)type.GetField("renderer",Flags).GetValue(fixture); source.name="Colorize validation source";
                var sourceColors=new List<string>();
                foreach(var page in source.pagedScene.pages) sourceColors.Add(Convert.ToBase64String(page.pageAsset.splatData.colorData.bytes));
                var camera=new GameObject("Colorize validation camera").AddComponent<Camera>(); camera.tag="MainCamera";
                target=new RenderTexture(640,480,0,RenderTextureFormat.ARGB32); target.Create(); camera.targetTexture=target;
                Preload(source,camera);
                var brush=Brush(source);
                window=ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window,"m_TargetRenderer",source); Set(window,"m_ColorizeBrush",brush);
                Set(window,"m_CurrentTool",GaussianSplatEditorWindow.BrushTool.PaintBrush); Set(window,"m_PaintBrushMode",1);
                var red=new Color(1,0,0,.8f); var green=new Color(0,1,0,.8f);
                CenterIs(source,camera,BaseColor,"Initial source");
                DrawIs(source,camera,target,BaseColor,BaseColor);
                brush.PushUndoState(); brush.EndStroke(); Require(brush.UndoCount==0,"Empty Colorize stroke added Undo history.");
                Undo.ClearAll();
                brush.PushUndoState(); brush.TargetColor=new Color(1,0,0,0); brush.ColorizeAtPosition(new Vector3(0,0,5),.3f);
                brush.TargetColor=Color.green; brush.ColorizeAtPosition(new Vector3(-.8f,0,5),.3f); brush.EndStroke();
                Require(source.pagedColorizeStrokeCount==1 && brush.UndoCount==1,"One drag did not group Colorize dabs.");
                CenterIs(source,camera,red,"First stroke"); DrawIs(source,camera,target,red,green);
                Require(brush.TrySampleColorAtPosition(new Vector3(0,0,5),.2f,camera,out var eyedropper),"Colorize eyedropper failed.");
                ColorIs(eyedropper,red,"Colorize eyedropper");
                Require(brush.TryGetSurfacePoint(new Ray(Vector3.zero,Vector3.forward),camera,2,true,out var hit) && Mathf.Abs(hit.z-5)<.001f,
                    "Colorize placement used pivot/legacy placeholder instead of LoD surface.");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Preload(source,camera);
                CenterIs(source,camera,BaseColor,"Unity Undo");
                Undo.PerformRedo(); Preload(source,camera); CenterIs(source,camera,red,"Unity Redo");
                // Xcopy snapshots keep the source colors, independently of later source edits.
                var boxHolder=new GameObject("Colorize copy brush"); boxHolder.SetActive(false);
                var box=boxHolder.AddComponent<GaussianSplatBoxBrush>(); box.TargetRenderer=source; box.BoxPosition=new Vector3(0,0,5); box.BoxSize=Vector3.one*.4f;
                Set(window,"m_BoxBrush",box); Call(window,"CopyPagedXcopy"); box.BoxPosition=new Vector3(0,0,4); Call(window,"PastePagedXcopy");
                var copy=GameObject.Find("Colorize validation source Xcopy")?.GetComponentInChildren<SplatBoxRenderer>();
                Require(copy!=null,"Could not create Colorize snapshot Xcopy."); copyPath=AssetDatabase.GetAssetPath(copy.pagedScene);
                Preload(copy,camera); CenterIs(copy,camera,red,"Xcopy color snapshot",2,4);

                brush.BlendMode=ColorizeBlendMode.Multiply; brush.BlendModeIntensity=.5f; brush.BlendStrength=.5f;
                Stroke(brush,new Color(.2f,.5f,1,0),new Vector3(0,0,5));
                var mixed=new Color(.6f,.125f,.25f,.8f);
                CenterIs(source,camera,mixed,"Multiply/intensity/strength"); DrawIs(source,camera,target,mixed,green);
                CenterIs(copy,camera,red,"Independent Xcopy",2,4);
                Require(brush.Undo() && source.pagedColorizeStrokeCount==1,"Colorize button Undo failed."); CenterIs(source,camera,red,"Custom Undo");
                Require(brush.Redo() && source.pagedColorizeStrokeCount==2,"Colorize button Redo failed."); CenterIs(source,camera,mixed,"Custom Redo");
                var polygon=new[]{new Vector3(-.2f,-.2f,5),new Vector3(.2f,-.2f,5),new Vector3(.2f,.2f,5),new Vector3(-.2f,.2f,5)};
                using(var output=new GraphicsBuffer(GraphicsBuffer.Target.Structured,4,UnsafeUtility.SizeOf<Splat>()))
                {
                    Require(source.ExportPagedPolygonSamples(polygon,Vector3.forward,.2f,.2f,output,out int count)&&count==2,"Colorized Fill samples missing.");
                    var values=new Splat[2]; output.GetData(values,0,0,2);
                    foreach(var value in values) { var rgb=GaussianUtils.SH0ToColor(value.dc0); ColorIs(new Color(rgb.x,rgb.y,rgb.z,GaussianUtils.Sigmoid(value.opacity)),mixed,"Exported color"); }
                }
                source.EditDeleteSphere(new Vector3(.1f,0,5),.04f); CenterIs(source,camera,mixed,"Erase keeps Colorize",1);
                source.ResetDeletedSplats(); CenterIs(source,camera,mixed,"Erase reset keeps Colorize");
                Preload(source,camera); CenterIs(source,camera,mixed,"Force LoD rebuild");
                source.enabled=false; source.enabled=true; Preload(source,camera); CenterIs(source,camera,mixed,"Disable/enable");
                // The source data is unchanged; replay uses captured geometry coordinates.
                for(int i=0;i<sourceColors.Count;++i) Require(sourceColors[i]==Convert.ToBase64String(source.pagedScene.pages[i].pageAsset.splatData.colorData.bytes),"Colorize rewrote source page colors.");
                source.transform.position=Vector3.right*1.2f; camera.transform.position=source.transform.position;
                Preload(source,camera); CenterIs(source,camera,mixed,"Moved source replay");
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),scenePath),"Could not save Colorize scene.");
                EditorSceneManager.OpenScene(scenePath,OpenSceneMode.Single);
                source=GameObject.Find("Colorize validation source").GetComponent<SplatBoxRenderer>();
                camera=GameObject.Find("Colorize validation camera").GetComponent<Camera>(); camera.targetTexture=target; Preload(source,camera);
                brush=Brush(source); Set(window,"m_TargetRenderer",source); Set(window,"m_ColorizeBrush",brush);
                CenterIs(source,camera,mixed,"Scene reopen"); Require(brush.UndoCount==2,"Scene reopen lost renderer-owned stroke history.");
                DrawIs(source,camera,target,mixed,green);
                sceneView=ScriptableObject.CreateInstance<SceneView>(); sceneView.ShowUtility(); var sceneCamera=sceneView.camera;
                sceneCamera.targetTexture=target; sceneCamera.transform.SetPositionAndRotation(new Vector3(1.2f,0,8),Quaternion.Euler(0,180,0));
                DrawIs(source,sceneCamera,target,mixed,green);
                Require(brush.Undo(),"Reopened Colorize stroke could not Undo."); CenterIs(source,camera,red,"Reopened Undo");
                Require(brush.Redo(),"Reopened Colorize stroke could not Redo."); CenterIs(source,camera,mixed,"Reopened Redo");
                brush.ClearUndoHistory(); Require(!brush.CanUndo && !brush.CanRedo,"Clear History retained Undo boundaries."); CenterIs(source,camera,mixed,"Clear History retained color");
                Set(window,"m_IsColorizeStrokeActive",true); GaussianSplatColorizeBrush.IsColorizing=true;
                Call(window,"ResetAllSplatEdits"); Preload(source,camera); CenterIs(source,camera,BaseColor,"Reset All");
                Require(!(bool)window.GetType().GetField("m_IsColorizeStrokeActive",Flags).GetValue(window) && !GaussianSplatColorizeBrush.IsColorizing,
                    "Reset All left a Colorize gesture active.");
                Require(source.pagedColorizeStrokeCount==0 && GameObject.Find("Colorize validation source Xcopy")==null,"Reset All retained colors/copies.");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Preload(source,camera); CenterIs(source,camera,mixed,"Undo Reset All");
                Require(GameObject.Find("Colorize validation source Xcopy")!=null,"Undo Reset All lost the copy.");
                Require(errors.Count==0,"Colorize integration logged errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox paged Colorize editor PASS: grouped brush strokes, surface/eyedropper, stationary Game/Scene views, Multiply controls, Unity/custom Undo/Redo, immutable source, Xcopy snapshot, rebuild/move/reopen, history clearing and Reset All.");
            }
            finally
            {
                Application.logMessageReceived-=observe;
                if(window!=null) Object.DestroyImmediate(window); if(sceneView!=null) sceneView.Close();
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
                if(fixture is IDisposable disposable) disposable.Dispose();
                if(target!=null) {target.Release();Object.DestroyImmediate(target);}
                AssetDatabase.DeleteAsset(scenePath); if(copyPath!=null) AssetDatabase.DeleteAsset(copyPath);
            }
        }
    }
}
