// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Collections;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    /// <summary>Runs the real URP render graph, including a second camera with only opaque geometry.</summary>
    public static class CameraSplatDofRenderGraphValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const BindingFlags StaticFlags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
        const int Width = 384, Height = 192, SplatLayer = 30, OpaqueLayer = 29;
        const string UrpAssembly = ", Unity.RenderPipelines.Universal.Runtime";
        static Type Urp(string name) => Type.GetType("UnityEngine.Rendering.Universal." + name + UrpAssembly, true);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Set(object target, string field, object value) => target.GetType().GetField(field, Flags).SetValue(target, value);
        static object Call(object target, string method, params object[] args) => target.GetType().GetMethod(method, Flags).Invoke(target, args);
        static void PreparePipeline(RenderPipelineAsset pipeline)
        {
            var prepare = typeof(RenderPipelineManager).GetMethod("TryPrepareRenderPipeline", StaticFlags);
            Require(prepare != null && (bool)prepare.Invoke(null, new object[] { pipeline }), "URP could not initialize for the render request");
        }
        static void CleanupPipeline() => typeof(RenderPipelineManager).GetMethod("CleanupRenderPipeline", StaticFlags).Invoke(null, null);

        static Color[] Read(RenderTexture target)
        {
            var previous = RenderTexture.active;
            var image = new Texture2D(Width, Height, TextureFormat.RGBAFloat, false, true);
            try
            {
                RenderTexture.active = target;
                image.ReadPixels(new Rect(0, 0, Width, Height), 0, 0, false); image.Apply(false);
                return image.GetPixels();
            }
            finally { RenderTexture.active = previous; Object.DestroyImmediate(image); }
        }

        static float Contrast(Color[] pixels, int panel)
        {
            double sum = 0; int count = 0;
            for (int y = 30; y < Height - 30; y++)
                for (int x = panel * Width / 3 + 20; x < (panel + 1) * Width / 3 - 21; x++)
                { sum += Math.Abs(pixels[y * Width + x].r - pixels[y * Width + x + 1].r); count++; }
            return (float)(sum / count);
        }

        static void Save(string name, Color[] pixels)
        {
            string folder = Path.Combine(Path.GetTempPath(), "SplatBox-quality-analysis"); Directory.CreateDirectory(folder);
            var image = new Texture2D(Width, Height, TextureFormat.RGBA32, false, true);
            try { image.SetPixels(pixels); image.Apply(false); File.WriteAllBytes(Path.Combine(folder, name + ".png"), image.EncodeToPNG()); }
            finally { Object.DestroyImmediate(image); }
        }

        sealed class Fixture : IDisposable
        {
            readonly RenderPipelineAsset oldGraphics = GraphicsSettings.defaultRenderPipeline;
            readonly RenderPipelineAsset oldQuality = QualitySettings.renderPipeline;
            readonly string folder;
            readonly List<GameObject> owners = new List<GameObject>();
            readonly RenderTexture target;
            readonly RenderPipelineAsset pipeline;
            readonly Texture2D checker;
            readonly Material opaqueMaterial;
            readonly Type requestType = Urp("UniversalRenderPipeline").GetNestedType("SingleCameraRequest", BindingFlags.Public);
            readonly MethodInfo submit;
            public readonly Camera camera, secondCamera;
            public readonly GaussianSplatTiltShiftEffect effect, secondEffect;
            public readonly SplatBoxRenderer source;

            public Fixture()
            {
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                folder = "Assets/__CameraSplatDofGraph_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder("Assets", folder.Substring(7));
                var rendererData = ScriptableObject.CreateInstance(Urp("UniversalRendererData"));
                rendererData.name = "DoF Validation Renderer";
                AssetDatabase.CreateAsset(rendererData, folder + "/Renderer.asset");
                AddFeature(rendererData, Type.GetType("GaussianSplatting.Runtime.GaussianSplatURPFeature, GaussianSplatting.SplatBox.Runtime", true));
                var blur = AddFeature(rendererData, Type.GetType("GaussianSplatting.Runtime.GaussianTiltShiftRendererFeature, GaussianSplatting.SplatBox.Runtime", true));
                object settings = blur.GetType().GetField("settings", Flags).GetValue(blur);
                Set(settings, "enabled", false); Set(settings, "allowCameraOverride", true);
                EditorUtility.SetDirty(blur); AssetDatabase.SaveAssetIfDirty(rendererData);
                pipeline = (RenderPipelineAsset)Urp("UniversalRenderPipelineAsset").GetMethod("Create", StaticFlags)
                    .Invoke(null, new object[] { rendererData });
                pipeline.name = "DoF Validation Pipeline";
                var pipelineSO = new SerializedObject(pipeline);
                pipelineSO.FindProperty("m_MSAA").intValue = 1;
                pipelineSO.FindProperty("m_RenderScale").floatValue = 1;
                pipelineSO.FindProperty("m_RequireDepthTexture").boolValue = true;
                pipelineSO.ApplyModifiedPropertiesWithoutUndo();
                AssetDatabase.CreateAsset(pipeline, folder + "/Pipeline.asset");
                GraphicsSettings.defaultRenderPipeline = pipeline; QualitySettings.renderPipeline = null;
                PreparePipeline(pipeline);

                target = new RenderTexture(Width, Height, 24, RenderTextureFormat.ARGBHalf, RenderTextureReadWrite.Linear)
                { name = "DoF URP request output", filterMode = FilterMode.Bilinear, antiAliasing = 1 };
                target.Create();
                camera = MakeCamera("Splat DoF Camera", 1 << SplatLayer);
                secondCamera = MakeCamera("Opaque DoF Camera", 1 << OpaqueLayer);
                effect = ConfigureEffect(camera); secondEffect = ConfigureEffect(secondCamera);
                source = MakeSplats();
                checker = new Texture2D(Width, Height, TextureFormat.RGBA32, false, true)
                { filterMode = FilterMode.Point, wrapMode = TextureWrapMode.Clamp };
                var pixels = new Color[Width * Height];
                for (int y = 0; y < Height; y++) for (int x = 0; x < Width; x++)
                { float v = (((x / 4) + (y / 4)) & 1) == 0 ? .1f : .95f; pixels[y * Width + x] = new Color(v, v, v, 1); }
                checker.SetPixels(pixels); checker.Apply(false);
                var shader = Shader.Find("Universal Render Pipeline/Unlit");
                Require(shader != null && shader.isSupported, "Missing URP opaque checkerboard shader");
                opaqueMaterial = new Material(shader); opaqueMaterial.SetTexture("_BaseMap", checker);
                opaqueMaterial.SetColor("_BaseColor", Color.white); opaqueMaterial.SetFloat("_Cull", 0);
                var quad = GameObject.CreatePrimitive(PrimitiveType.Quad); owners.Add(quad); quad.layer = OpaqueLayer;
                float halfHeight = 8 * Mathf.Tan(camera.fieldOfView * Mathf.Deg2Rad * .5f);
                quad.transform.position = Vector3.forward * 8;
                quad.transform.localScale = new Vector3(halfHeight * camera.aspect * 2, halfHeight * 2, 1);
                quad.GetComponent<MeshRenderer>().sharedMaterial = opaqueMaterial;
                submit = typeof(RenderPipeline).GetMethod("SubmitRenderRequest", StaticFlags).MakeGenericMethod(requestType);
            }

            ScriptableObject AddFeature(ScriptableObject rendererData, Type type)
            {
                var feature = ScriptableObject.CreateInstance(type);
                feature.name = type.Name; AssetDatabase.AddObjectToAsset(feature, rendererData);
                var serialized = new SerializedObject(rendererData);
                var list = serialized.FindProperty("m_RendererFeatures");
                int index = list.arraySize; list.arraySize++;
                list.GetArrayElementAtIndex(index).objectReferenceValue = feature;
                var map = serialized.FindProperty("m_RendererFeatureMap"); map.arraySize = list.arraySize;
                AssetDatabase.TryGetGUIDAndLocalFileIdentifier(feature, out string guid, out long id);
                map.GetArrayElementAtIndex(index).longValue = id;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                Call(rendererData, "SetDirty"); EditorUtility.SetDirty(rendererData);
                AssetDatabase.SaveAssetIfDirty(rendererData); return feature;
            }

            Camera MakeCamera(string name, int mask)
            {
                var owner = new GameObject(name); owners.Add(owner);
                var value = owner.AddComponent<Camera>(); value.enabled = false;
                value.clearFlags = CameraClearFlags.SolidColor; value.backgroundColor = new Color(.1f, .1f, .1f, 1);
                value.fieldOfView = 60; value.aspect = (float)Width / Height; value.nearClipPlane = .1f; value.farClipPlane = 100;
                value.allowHDR = true; value.allowMSAA = false; value.cullingMask = mask; value.targetTexture = target;
                value.stereoTargetEye = StereoTargetEyeMask.None;
                var data = owner.AddComponent(Urp("UniversalAdditionalCameraData"));
                var serialized = new SerializedObject(data);
                serialized.FindProperty("m_RendererIndex").intValue = 0;
                serialized.FindProperty("m_RenderPostProcessing").boolValue = false;
                serialized.ApplyModifiedPropertiesWithoutUndo(); return value;
            }

            static GaussianSplatTiltShiftEffect ConfigureEffect(Camera camera)
            {
                var effect = camera.gameObject.AddComponent<GaussianSplatTiltShiftEffect>();
                effect.effectEnabled = false; effect.blurMode = GaussianSplatTiltShiftEffect.BlurMode.DepthOfField;
                effect.focusDistance = 8; effect.focusRange = 2; effect.nearBlurStrength = effect.farBlurStrength = 1;
                effect.blurStrength = 25; effect.highQualityBlur = true; effect.blurSamples = 12;
                effect.saturationBoost = effect.contrastBoost = 1; effect.vignetteStrength = effect.bokehShape = 0;
                effect.focusPosition = .5f; effect.focusWidth = .8f; effect.topBlurOffset = effect.bottomBlurOffset = .5f;
                return effect;
            }

            SplatBoxRenderer MakeSplats()
            {
                var points = new List<Splat>(); float[] depths = { 3, 8, 15 };
                float tangent = Mathf.Tan(camera.fieldOfView * Mathf.Deg2Rad * .5f);
                for (int p = 0; p < depths.Length; p++)
                    for (int y = 12; y < Height - 12; y += 2)
                        for (int x = p * Width / 3 + 8; x < (p + 1) * Width / 3 - 8; x += 2)
                        {
                            float z = depths[p];
                            float v = (((x / 4) + (y / 4)) & 1) == 0 ? .1f : .95f;
                            float sigma = 1.1f * z * tangent * 2 / Height;
                            points.Add(new Splat
                            {
                                pos = new Vector3(((x + .5f) * 2 / Width - 1) * z * tangent * camera.aspect,
                                    ((y + .5f) * 2 / Height - 1) * z * tangent, z),
                                dc0 = (Vector3.one * v - Vector3.one * .5f) / .2820948f,
                                opacity = Mathf.Log(19), scale = Vector3.one * Mathf.Log(sigma), rot = new Quaternion(1, 0, 0, 0)
                            });
                        }
                using var data = new NativeArray<Splat>(points.ToArray(), Allocator.TempJob);
                string path = GaussianSplatAssetCreator.CreateAssetFromSplats(data, folder, "DepthPanels", GaussianSplatAssetCreator.DataQuality.VeryHigh);
                var owner = new GameObject("DoF Checkerboard Splats"); owners.Add(owner); owner.SetActive(false); owner.layer = SplatLayer;
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                Set(renderer, "m_UseRelightShader", false); renderer.m_Asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
                renderer.m_SplatScale = renderer.m_OpacityScale = 1;
                owner.SetActive(true); Require(renderer.HasValidRenderSetup, "Checkerboard splat asset did not initialize");
                return renderer;
            }

            public Color[] Render(Camera selected)
            {
                // The splat renderer currently gathers independently of Camera.cullingMask.
                // Explicitly remove it for the second-camera empty-splat graph path.
                source.enabled = selected == camera;
                if (source.enabled)
                {
                    Require(source.HasValidRenderSetup, "Returning splat renderer did not restore its resources");
                    Call(source, "ForceResort");
                }
                object request = Activator.CreateInstance(requestType); Set(request, "destination", target);
                submit.Invoke(null, new[] { (object)selected, request });
                Require(!Shader.IsKeywordEnabled("SPLAT_DOF_DEPTH"), "Splat depth draw left its MRT keyword enabled");
                return Read(target);
            }

            public void Dispose()
            {
                for (int i = owners.Count - 1; i >= 0; i--) if (owners[i] != null) Object.DestroyImmediate(owners[i]);
                CleanupPipeline();
                GraphicsSettings.defaultRenderPipeline = oldGraphics; QualitySettings.renderPipeline = oldQuality;
                if (oldQuality != null || oldGraphics != null) PreparePipeline(oldQuality != null ? oldQuality : oldGraphics);
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                if (opaqueMaterial != null) Object.DestroyImmediate(opaqueMaterial);
                if (checker != null) Object.DestroyImmediate(checker);
                AssetDatabase.DeleteAsset(folder); AssetDatabase.SaveAssets();
            }
        }

        public static void Run()
        {
            Require(Application.isBatchMode, "Render-graph validation replaces scenes; use an isolated batch project");
            var errors = new List<string>();
            Application.LogCallback observe = (m, s, t) => { if (t == LogType.Error || t == LogType.Exception || t == LogType.Assert) errors.Add(m); };
            Application.logMessageReceived += observe;
            try
            {
                using var fixture = new Fixture();
                var original = fixture.Render(fixture.camera);
                var opaque = fixture.Render(fixture.secondCamera);
                for (int p = 0; p < 3; p++) Require(Contrast(original, p) > .015f && Contrast(opaque, p) > .02f, "URP fixture rendered no checkerboard contrast");
                fixture.effect.effectEnabled = true;
                var focus8 = fixture.Render(fixture.camera);
                Require(Contrast(focus8, 0) < Contrast(original, 0) * .93f && Contrast(focus8, 2) < Contrast(original, 2) * .95f,
                    "Real URP render graph did not blur near and far splats by their visible depth");
                Require(Contrast(focus8, 1) > Contrast(original, 1) * .92f, "Real URP render graph blurred the focused splat panel");
                fixture.secondEffect.effectEnabled = true;
                var second = fixture.Render(fixture.secondCamera);
                for (int p = 0; p < 3; p++) Require(Contrast(second, p) > Contrast(opaque, p) * .94f,
                    "Second camera reused splat depth from the first camera instead of its focused opaque depth");
                fixture.effect.focusDistance = 3;
                var focus3 = fixture.Render(fixture.camera);
                Require(Contrast(focus3, 0) > Contrast(focus8, 0) * 1.04f && Contrast(focus3, 1) < Contrast(focus8, 1) * .95f,
                    "Changing camera focus did not move the sharp splat panel");
                fixture.effect.effectEnabled = false;
                var off = fixture.Render(fixture.camera);
                for (int p = 0; p < 3; p++) Require(Contrast(off, p) > Contrast(original, p) * .96f, "Disabling DoF left stale blur active");
                fixture.effect.effectEnabled = true; fixture.effect.blurMode = GaussianSplatTiltShiftEffect.BlurMode.TiltShift;
                var tiltOnly = fixture.Render(fixture.camera);
                for (int p = 0; p < 3; p++) Require(Contrast(tiltOnly, p) > Contrast(original, p) * .94f,
                    "Tilt-shift mode consumed stale depth blur instead of its wide sharp band");
                Save("dof-urp-original", original); Save("dof-urp-focus8", focus8); Save("dof-urp-focus3", focus3);
                Require(errors.Count == 0, "URP DoF render graph logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Camera Splat DoF RenderGraph PASS: actual URP SingleCameraRequest, depth-driven near/far focus, second-camera opaque fallback, off/mode changes, keyword cleanup.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
