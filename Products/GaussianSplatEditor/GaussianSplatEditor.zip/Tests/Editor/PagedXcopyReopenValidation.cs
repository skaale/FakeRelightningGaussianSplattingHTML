// SPDX-License-Identifier: MIT

using System;
using System.Reflection;
using GaussianSplatting.Runtime;
using GaussianSplatting.Editor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Rendering;
using System.Runtime.InteropServices;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
public static class PagedXcopyReopenValidation
{
    [StructLayout(LayoutKind.Sequential, Pack=4)] struct View { public Vector4 clip; public uint axis1,axis2,color1,color2; public Vector3 world; public uint index; }
    const BindingFlags F = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    static void Require(bool x, string m) { if (!x) throw new Exception(m); }
    static void Set(object x,string n,object v) => x.GetType().GetField(n,F).SetValue(x,v);
    static object Call(object x,string n,params object[] a) => x.GetType().GetMethod(n,F).Invoke(x,a);
    public static void Run()
    {
        if (!Application.isBatchMode) throw new InvalidOperationException("Run this scene-reopening validation in an isolated batch-mode project.");
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        string testScene = "Assets/__PagedXcopyValidation_" + Guid.NewGuid().ToString("N") + ".unity";
        string manifestPath = null;
        object fixture = null;
        GaussianSplatEditorWindow window = null;
        try
        {
            var t = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture",true);
            fixture = Activator.CreateInstance(t,F,null,new object[]{false},null);
            Call(fixture,"AssignScene"); Call(fixture,"PublishPages");
            var owner = (GameObject)t.GetField("owner",F).GetValue(fixture);
            var source = (SplatBoxRenderer)t.GetField("renderer",F).GetValue(fixture); string copyName = owner.name + " Xcopy";
            Require(source.ForceRebuildPagedLodInEditor(), "Source paged resources failed to initialize"); source.EditDeleteSphere(new Vector3(-0.1f,0,5),0.03f); Require(source.pagedLodEraseStrokeCount == 1, "Source erase journal not created");
            window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            var brushObject = new GameObject("Validation brush"); brushObject.SetActive(false);
            var brush = brushObject.AddComponent<GaussianSplatBoxBrush>(); brush.TargetRenderer = source;
            brush.BoxPosition = new Vector3(-0.05f,0,5); brush.BoxSize = Vector3.one * 0.4f;
            Set(window,"m_BoxBrush",brush); Set(window,"m_TargetRenderer",source);
            Call(window,"CopyPagedXcopy");
            var selected = (GaussianSplatPageEntry[])window.GetType().GetField("m_PagedCopyPages",F).GetValue(window);
            Require(selected != null && selected.Length == 1 && selected[0].pageId == 1,"Wrong page selection");
            brush.BoxPosition = new Vector3(2,0,5);
            Call(window,"PastePagedXcopy");
            var root = GameObject.Find(copyName); Require(root != null,"Paste did not create root: "+window.GetType().GetField("m_PagedCopyMessage",F).GetValue(window));
            var pasted = root.GetComponentInChildren<SplatBoxRenderer>();
            Require(pasted != null && pasted.UsesPagedLod && pasted.pagedScene.pageCount == 1,"Copy manifest missing page");
            Require(pasted.pagedScene.pages[0].pageAsset == selected[0].pageAsset,"Page reference lost");
            Require(pasted.lodStreamer != source.lodStreamer,"Streamer was shared");
            Require(pasted.m_Cutouts.Length == 1 && pasted.m_Cutouts[0].m_Invert,"Boundary missing"); Require(pasted.pagedLodEraseStrokeCount == 1,"Source erase journal missing on copy");
            manifestPath = AssetDatabase.GetAssetPath(pasted.pagedScene);
            Require(!string.IsNullOrEmpty(manifestPath),"Manifest not persisted");
            Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Require(GameObject.Find(copyName) == null,"Undo did not remove pasted object");
            Undo.PerformRedo(); root = GameObject.Find(copyName); Require(root != null && root.activeSelf,"Redo did not restore active pasted object");
            pasted = root.GetComponentInChildren<SplatBoxRenderer>(); Require(pasted != null && pasted.pagedLodEraseStrokeCount == 1,"Redo lost pasted renderer or edits");
            Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),testScene),"Scene save failed");
            EditorSceneManager.OpenScene(testScene,OpenSceneMode.Single);
            root = GameObject.Find(copyName); Require(root != null,"Copy missing after reopening");
            pasted = root.GetComponentInChildren<SplatBoxRenderer>();
            Require(pasted != null && pasted.UsesPagedLod && pasted.pagedScene.pageCount == 1 && pasted.pagedScene.pages[0].pageAsset != null,"Reopened pages missing");
            Require(pasted.m_Cutouts.Length == 1 && pasted.m_Cutouts[0] != null && pasted.m_Cutouts[0].transform.IsChildOf(root.transform),"Reopened clip missing"); Require(pasted.pagedLodEraseStrokeCount == 1,"Erase journal did not survive reopening");
            var cameraObject = new GameObject("Xcopy camera"); var camera = cameraObject.AddComponent<Camera>(); camera.transform.position = new Vector3(2,0,0); camera.farClipPlane = 100;
            for (int i=0; i<10 && pasted.activeSplatCount == 0; i++) pasted.PreloadPagedLodPages(camera);
            Require(pasted.activeSplatCount > 0, "Reopened copy did not stream any splats");
            var deleted = (GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuPagedLodDeletedBits",F).GetValue(pasted); Require(deleted != null,"Reopened erase mask absent"); var words = new uint[deleted.count]; deleted.GetData(words); bool found=false; foreach (var word in words) found |= word != 0; Require(found,"Erased splat was not hidden after reopen and streaming");
            Require(Vector3.Distance(root.transform.position,new Vector3(2,0,5)) < 0.001f,"Reopened transform wrong");
            var sourceAfter = GameObject.Find("Editor cold-start recovery fixture"); if (sourceAfter != null) sourceAfter.SetActive(false);
            var rt = new RenderTexture(640,480,0); using (var cmd = new CommandBuffer()) { rt.Create(); camera.targetTexture=rt; cmd.SetRenderTarget(rt); cmd.SetViewport(new Rect(0,0,640,480)); cmd.ClearRenderTarget(false,true,Color.clear); cmd.SetViewProjectionMatrices(camera.worldToCameraMatrix,GL.GetGPUProjectionMatrix(camera.projectionMatrix,true)); cmd.SetGlobalVector("_ScreenParams",new Vector4(640,480,1+1f/640,1+1f/480)); cmd.SetGlobalVector("_SplatRenderTargetSize",new Vector4(640,480,1f/640,1f/480)); Require(GaussianSplatRenderSystem.instance.GatherSplatsForCamera(camera),"Copied renderer was not drawable"); Require(GaussianSplatRenderSystem.instance.SortAndRenderSplats(camera,cmd) != null,"No render material"); Graphics.ExecuteCommandBuffer(cmd); }
            var viewBuffer = (GraphicsBuffer)typeof(SplatBoxRenderer).GetField("m_GpuView",F).GetValue(pasted); var views=new View[pasted.activeSplatCount]; viewBuffer.GetData(views,0,0,views.Length); int visible=0; foreach(var v in views) { if(v.clip.w > 0) visible++; Debug.Log("XCOPY VIEW "+v.index+" "+v.world+" w="+v.clip.w); } Require(visible > 0,"No pasted splats rendered after reopen");
            pasted.m_Cutouts[0].transform.localScale = Vector3.one * 0.1f;
            using (var second = new CommandBuffer()) { second.SetRenderTarget(rt); second.SetViewport(new Rect(0,0,640,480)); second.SetViewProjectionMatrices(camera.worldToCameraMatrix,GL.GetGPUProjectionMatrix(camera.projectionMatrix,true)); second.SetGlobalVector("_ScreenParams",new Vector4(640,480,1+1f/640,1+1f/480)); second.SetGlobalVector("_SplatRenderTargetSize",new Vector4(640,480,1f/640,1f/480)); Require(GaussianSplatRenderSystem.instance.GatherSplatsForCamera(camera),"Renderer not gathered after clip change"); GaussianSplatRenderSystem.instance.SortAndRenderSplats(camera,second); Graphics.ExecuteCommandBuffer(second); }
            views = new View[pasted.activeSplatCount]; if (views.Length > 0) viewBuffer.GetData(views,0,0,views.Length); foreach(var v in views) Require(v.clip.w == 0,"Outside splat escaped copied box or erased splat returned");
            pasted.m_Cutouts[0].transform.localScale = Vector3.one * 0.2f;
            Require(pasted.ForceRebuildPagedLodInEditor(),"Copy failed to rebuild streamed pages"); for (int i=0; i<10 && pasted.activeSplatCount == 0; i++) pasted.PreloadPagedLodPages(camera);
            Require(pasted.activeSplatCount > 0 && pasted.pagedLodEraseStrokeCount == 1,"Rebuild lost pages or erase history");
            camera.targetTexture = null; rt.Release(); Object.DestroyImmediate(rt);

            // A renamed new copy and an inactive legacy copy must both reset after a scene
            // reopen. A copy owned by another renderer must survive, and Undo restores both.
            sourceAfter.SetActive(true);
            source = sourceAfter.GetComponent<SplatBoxRenderer>();
            root.name = "Renamed paged copy";
            var legacy = Object.Instantiate(root);
            legacy.name = copyName;
            legacy.SetActive(false);
            var legacyRenderer = legacy.GetComponentInChildren<SplatBoxRenderer>(true);
            legacyRenderer.m_Cutouts[0].name = "Xcopy boundary";
            using (var serial = new SerializedObject(legacyRenderer))
            {
                serial.FindProperty("m_PagedXcopySource").objectReferenceValue = null;
                serial.FindProperty("m_PagedXcopyRoot").objectReferenceValue = null;
                serial.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = null;
                serial.ApplyModifiedPropertiesWithoutUndo();
            }
            var otherSourceObject = Object.Instantiate(sourceAfter); otherSourceObject.name = "Other source";
            var otherSource = otherSourceObject.GetComponent<SplatBoxRenderer>();
            var otherCopy = Object.Instantiate(root); otherCopy.name = "Unrelated paged copy";
            var otherCopyRenderer = otherCopy.GetComponentInChildren<SplatBoxRenderer>(true);
            using (var serial = new SerializedObject(otherCopyRenderer))
            {
                serial.FindProperty("m_PagedXcopySource").objectReferenceValue = otherSource;
                serial.FindProperty("m_PagedXcopyRoot").objectReferenceValue = otherCopy;
                serial.ApplyModifiedPropertiesWithoutUndo();
            }
            var protectedCopy = Object.Instantiate(root); protectedCopy.name = "Copy with extra child";
            var protectedRenderer = protectedCopy.GetComponentInChildren<SplatBoxRenderer>(true);
            using (var serial = new SerializedObject(protectedRenderer))
            {
                serial.FindProperty("m_PagedXcopySource").objectReferenceValue = source;
                serial.FindProperty("m_PagedXcopyRoot").objectReferenceValue = protectedCopy;
                serial.ApplyModifiedPropertiesWithoutUndo();
            }
            new GameObject("User-added child").transform.SetParent(protectedCopy.transform, false);
            Set(window,"m_TargetRenderer",source);
            Set(window,"m_PagedCopySource",source);
            Call(window,"ResetAllSplatEdits");
            Require(root == null && legacy == null,"Reset did not remove new and legacy copies");
            Require(otherCopy != null && otherSource != null && protectedCopy != null,"Reset removed another source's objects or a copy with added content");
            Require(source.pagedLodEraseStrokeCount == 0,"Reset did not clear the source erase journal");
            Require(window.GetType().GetField("m_PagedCopySource",F).GetValue(window) == null,"Reset retained copied area");
            Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
            root = GameObject.Find("Renamed paged copy");
            Require(root != null && source.pagedLodEraseStrokeCount == 1,"Undo did not restore copy and erase journal");
            Require(FindInactiveRoot(copyName) != null,"Undo did not restore inactive legacy copy");
            Undo.PerformRedo();
            Require(GameObject.Find("Renamed paged copy") == null && FindInactiveRoot(copyName) == null && otherCopy != null && protectedCopy != null,
                "Redo did not reset only this source's copies");
            Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),testScene),"Could not save reset scene");
            EditorSceneManager.OpenScene(testScene,OpenSceneMode.Single);
            Require(GameObject.Find("Renamed paged copy") == null && FindInactiveRoot(copyName) == null &&
                GameObject.Find("Unrelated paged copy") != null && GameObject.Find("Copy with extra child") != null,
                "Reset or protected copies did not persist after reopen");
            Debug.Log("PAGED XCOPY SAVE REOPEN AND RESET PASS");
        }
        finally
        {
            if (window != null) Object.DestroyImmediate(window);
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            if (fixture is IDisposable d) d.Dispose();
            AssetDatabase.DeleteAsset(testScene);
            if (!string.IsNullOrEmpty(manifestPath)) AssetDatabase.DeleteAsset(manifestPath);
        }
    }

    static GameObject FindInactiveRoot(string name)
    {
        foreach (var root in SceneManager.GetActiveScene().GetRootGameObjects()) if (root.name == name) return root;
        return null;
    }
}

}
