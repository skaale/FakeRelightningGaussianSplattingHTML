// SPDX-License-Identifier: MIT
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using GaussianSplatting.Runtime;
using Unity.Burst;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace GaussianSplatting.Tests
{
    /// <summary>
    /// Opt-in performance experiment for paged attractors; run only in an isolated batch editor.
    /// A deterministic 16x8 grid contains 128 resident octree pages of 25,000 nodes each
    /// (3.2 million total nodes, 2.8 million leaves). Local influence admits three pages;
    /// global influence admits all pages. The cold first step includes source admission
    /// and initial allocations. Six warm frames precede twelve stage samples and eight whole steps.
    ///
    /// Timings are main-thread wall time, including completion of CPU jobs and GPU upload
    /// submission. They exclude rendering, depth sorting and GPU frame completion. Selection
    /// is deliberately forced in every staged sample at a two-million-splat budget to show
    /// its independent cost; normal rendering can retain a complete frontier and refine it
    /// asynchronously. Consequently the staged sum is not an application frame-rate claim.
    /// Four-substep catch-up models the fixed-step cap reached during a slow editor frame.
    /// No timing threshold is asserted. Use identical hardware/editor settings and this
    /// same fixture on both revisions when comparing changes.
    /// </summary>
    public static class PagedAttractorPerformanceValidation
    {
        const BindingFlags F = BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance;
        static T Get<T>(object o,string n)=>(T)o.GetType().GetField(n,F).GetValue(o);
        static void Set(object o,string n,object v)=>o.GetType().GetField(n,F).SetValue(o,v);
        static object Call(object o,string n,params object[] a)=>o.GetType().GetMethod(n,F).Invoke(o,a);
        static long Counter(object o,string name) => o.GetType().GetField(name,F) is FieldInfo field ? Convert.ToInt64(field.GetValue(o)) : -1;
        static double Ms(Action work){var sw=Stopwatch.StartNew();work();return sw.Elapsed.TotalMilliseconds;}
        static string Stats(List<double> x){x.Sort();return $"median={x[x.Count/2]:F3}ms min={x[0]:F3}ms max={x[x.Count-1]:F3}ms";}
        static LodTreeRuntime Tree(Vector3 center,int count)
        {
            var nodes=new LodTreeNode[count];var half=new float[count];half[0]=.9f;
            nodes[0].center=center;
            for(int n=0;n<count;n++)
            {
                if(n>0){int p=(n-1)/8,k=(n-1)%8;half[n]=half[p]*.5f;nodes[n].center=nodes[p].center+new float3((k&1)==0?-half[n]:half[n],(k&2)==0?-half[n]:half[n],(k&4)==0?-half[n]:half[n]);}
                int start=n*8+1,children=Math.Max(0,Math.Min(8,count-start));
                nodes[n].childStart=(uint)(children>0?start:0);nodes[n].childCount=(ushort)children;nodes[n].featureSize=children>0?half[n]*3.4642f:.006f;
            }
            return LodTreeRuntime.Build(nodes,true);
        }
        static void Case(int pageCount,int nodesPerPage,float range,string label)
        {
            var ft=typeof(PagedSmudgeValidation).GetNestedType("Fixture",BindingFlags.NonPublic);
            object f=Activator.CreateInstance(ft,F,null,new object[]{"Resources/BoxUtil.compute"},null);
            var r=Get<SplatBoxRenderer>(f,"renderer");var streamer=Get<SplatBoxLodStreamer>(f,"streamer");var old=Get<SplatBoxPageGpuState>(f,"page");
            var pages=Get<List<SplatBoxPageGpuState>>(streamer,"m_LoadedList");
            int total=pageCount*nodesPerPage;
            try
            {
                pages.Clear();Set(r,"m_LodAtlasCapacity",total);Set(r,"m_EnableWind",true);r.windDamping=.1f;r.windMinVelocity=.01f;
                int leaves=0;
                for(int p=0;p<pageCount;p++)
                {
                    Vector3 c=new Vector3((p%16)*2,((p/16)%8)*2,10);
                    var tree=Tree(c,nodesPerPage);leaves+=tree.leafCount;
                    pages.Add(new SplatBoxPageGpuState{pageId=p,pageSlot=p,splatCount=nodesPerPage,lodNodeCount=nodesPerPage,atlasOffset=p*nodesPerPage,uploadedAtlasOffset=p*nodesPerPage,gpuPosData=old.gpuPosData,lodTree=tree,bounds=new Bounds(c,Vector3.one*1.8f)});
                }
                r.SetAttractorData(new[]{new AttractorData{position=new Vector3(0,0,10),strength=.02f,range=range,falloff=1,mode=0,enabled=1,rotation=Quaternion.identity,scale=Vector3.one,vortexHeight=.1f}});
                var context=new SplatBoxLodTraverser.PageContext[pageCount];var output=new LodActiveSplatRef[Math.Min(2000000,total)];var workspace=new SplatBoxLodTraverser.Workspace();
                var view=new SplatBoxLodTraverser.ViewContext{cameraWorld=new float3(15,7,-20),cameraForward=new float3(0,0,1),pixelScaleFactor=1800,pixelsPerUnitAtUnitDistance=900,cosHalfFovY=.5f,screenHeight=1080,frustumCull=false,splatScale=1};
                int selected=0;Action traverse=()=>{for(int p=0;p<pageCount;p++)context[p]=new SplatBoxLodTraverser.PageContext{pageSlot=p,nodes=pages[p].lodTree.nodes,childTable=pages[p].lodTree.childTable,childTableStart=pages[p].lodTree.childTableStart,localToWorld=float4x4.identity,lodScale=1,outsideFoveate=1,behindFoveate=1};selected=SplatBoxLodTraverser.Traverse(context,pageCount,view,output.Length,.01f,output,workspace);};
                double first=Ms(()=>Call(r,"StepPagedAttractors",1f/60,.7f));
                for(int i=0;i<6;i++){Call(r,"StepPagedAttractors",1f/60,.7f+i/60f);traverse();}
                GC.Collect();GC.WaitForPendingFinalizers();GC.Collect();
                var sim=new List<double>();var hierarchy=new List<double>();var upload=new List<double>();var publish=new List<double>();var selection=new List<double>();var frame=new List<double>();
                long uploadCalls=Counter(r,"m_PagedAttractorGpuUploadCalls"), uploadBytes=Counter(r,"m_PagedAttractorGpuUploadedBytes"), clearCalls=Counter(r,"m_PagedAttractorGpuClearDispatches");
                for(int i=0;i<12;i++)
                {
                    var sw=Stopwatch.StartNew();
                    object[] args={1f/60,.9f+i/60f,false};sim.Add(Ms(()=>Call(r,"SimulatePagedAttractors",args)));
                    hierarchy.Add(Ms(()=>Call(r,"EnsurePagedAttractorHierarchy")));
                    upload.Add(Ms(()=>Call(r,"RefreshPagedAttractorGpuOffsets")));
                    publish.Add(Ms(()=>Call(r,"PublishPagedAttractorStep",false)));
                    selection.Add(Ms(traverse));frame.Add(sw.Elapsed.TotalMilliseconds);
                }
                Debug.Log($"ATTRACTOR_PERF {label} gpu counters available={uploadCalls>=0} callsPerFrame={(Counter(r,"m_PagedAttractorGpuUploadCalls")-uploadCalls)/12.0:F1} bytesPerFrame={(Counter(r,"m_PagedAttractorGpuUploadedBytes")-uploadBytes)/12.0:F0} clearDispatches={Counter(r,"m_PagedAttractorGpuClearDispatches")-clearCalls}");
                int states=((ICollection)Get<object>(r,"m_PagedAttractorStates")).Count;
                Debug.Log($"ATTRACTOR_PERF {label} pages={pageCount} nodes={total} leaves={leaves} affectedPages={states} affectedNodes={states*nodesPerPage} selected={selected} BurstTraversal={workspace.usedBurst} firstStep={first:F2}ms");
                Debug.Log($"ATTRACTOR_PERF {label} simulation {Stats(sim)} | hierarchy {Stats(hierarchy)} | upload {Stats(upload)} | publish-rest {Stats(publish)} | selection {Stats(selection)} | sum-frame {Stats(frame)}");
                var totalStep=new List<double>();for(int i=0;i<8;i++)totalStep.Add(Ms(()=>Call(r,"StepPagedAttractors",1f/60,1.2f+i/60f)));
                Debug.Log($"ATTRACTOR_PERF {label} actual-step-without-selection {Stats(totalStep)}");
                var catchup=new List<double>();
                for(int i=0;i<8;i++)
                {
                    Set(r,"m_PagedAttractorLastTick",EditorApplication.timeSinceStartup-.1);
                    Set(r,"m_PagedAttractorAccumulator",.00001d);
                    catchup.Add(Ms(()=>Call(r,"TickPagedAttractors")));
                }
                Debug.Log($"ATTRACTOR_PERF {label} four-substep-catchup-without-selection {Stats(catchup)}");
            }
            finally{Call(r,"DisposePagedAttractors");pages.Clear();pages.Add(old);((IDisposable)f).Dispose();}
        }
        public static void Run()
        {
            if (!Application.isBatchMode || !SystemInfo.supportsComputeShaders)
                throw new InvalidOperationException("Run this benchmark in an isolated batch editor with a graphics device.");
            bool previousSynchronous = BurstCompiler.Options.EnableBurstCompileSynchronously;
            BurstCompiler.Options.EnableBurstCompileSynchronously = true;
            try
            {
                Debug.Log($"ATTRACTOR_PERF ENV cpu={SystemInfo.processorType} cores={SystemInfo.processorCount} gpu={SystemInfo.graphicsDeviceName} unity={Application.unityVersion} Burst={BurstCompiler.IsEnabled} package={UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).resolvedPath}");
                Case(128, 25000, 1.2f, "local-3.2m");
                Case(128, 25000, 100f, "global-3.2m");
                Debug.Log("ATTRACTOR_PERF DONE");
            }
            finally { BurstCompiler.Options.EnableBurstCompileSynchronously = previousSynchronous; }
        }
    }
}
