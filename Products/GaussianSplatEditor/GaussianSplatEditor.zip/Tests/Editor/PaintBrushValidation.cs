// SPDX-License-Identifier: MIT
using System;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEngine;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    public static class PaintBrushValidation
    {
        const BindingFlags Private = BindingFlags.NonPublic | BindingFlags.Instance;
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Set(GaussianSplatPaintBrush brush, string field, object value) =>
            typeof(GaussianSplatPaintBrush).GetField(field, Private).SetValue(brush, value);

        public static void Run()
        {
            GameObject holder = null, sourceObject = null, outputObject = null, otherObject = null, cameraObject = null;
            RenderTexture target = null;
            try
            {
                holder = new GameObject("Paint brush contract") { hideFlags = HideFlags.HideAndDontSave };
                sourceObject = new GameObject("Paint source contract") { hideFlags = HideFlags.HideAndDontSave };
                outputObject = new GameObject("Paint output contract") { hideFlags = HideFlags.HideAndDontSave };
                otherObject = new GameObject("Paint alternate source") { hideFlags = HideFlags.HideAndDontSave };
                holder.SetActive(false); sourceObject.SetActive(false); outputObject.SetActive(false); otherObject.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatPaintBrush>();
                var source = sourceObject.AddComponent<SplatBoxRenderer>();
                var output = outputObject.AddComponent<SplatBoxRenderer>();
                var other = otherObject.AddComponent<SplatBoxRenderer>();
                brush.TargetRenderer = source;
                brush.BeginPaintStroke(); brush.BeginPaintStroke();
                Set(brush, "m_NextWriteIndex", 42); Set(brush, "m_AllocatedCapacity", 2000);
                brush.PaintOutputRenderer = output;
                Require(brush.TargetRenderer == source && brush.PaintOutputRenderer == output &&
                    brush.PaintedSplatEndIndex == 0 && brush.CurrentStrokeLayer == 2,
                    "Starting a paint output changed the sampled source or discarded layering.");
                Set(brush, "m_NextWriteIndex", 9);
                brush.TargetRenderer = source;
                Require(brush.PaintedSplatEndIndex == 9 && brush.PaintOutputRenderer == output,
                    "Rebinding the same source during a drag reset its pending stroke.");
                brush.PaintOutputRenderer = null;
                Require(brush.PaintedSplatEndIndex == 0 && brush.CurrentStrokeLayer == 2,
                    "Finishing an output stroke retained buffer indices or discarded layering.");
                brush.PaintOutputRenderer = output; brush.TargetRenderer = other;
                Require(brush.PaintOutputRenderer == null && brush.CurrentStrokeLayer == 0,
                    "Changing the source retained the prior output or depth/layer state.");
                brush.EnsureCapacity();
                Require(brush.PaintedSplatEndIndex == 0, "An invalid source advanced the paint write index.");

                cameraObject = new GameObject("Paint ray projection contract") { hideFlags = HideFlags.HideAndDontSave };
                var camera = cameraObject.AddComponent<Camera>(); camera.enabled = false;
                target = new RenderTexture(800,600,0); target.Create(); camera.targetTexture = target;
                camera.pixelRect = new Rect(40,60,640,480);
                camera.transform.SetPositionAndRotation(new Vector3(2,-1,4), Quaternion.Euler(18,41,-5));
                var convert = typeof(GaussianSplatPaintBrush).GetMethod("TryGetRayScreenPoint", BindingFlags.NonPublic | BindingFlags.Static);
                foreach (bool orthographic in new[] { false, true })
                {
                    camera.orthographic = orthographic;
                    foreach (var viewport in new[] { new Vector2(.23f,.77f), new Vector2(.8f,.15f) })
                    {
                        Ray ray = camera.ViewportPointToRay(viewport);
                        object[] args = { ray, camera, 5f, Vector2.zero };
                        Require((bool)convert.Invoke(null,args), "Paint could not convert a valid camera ray.");
                        Vector2 pixels = (Vector2)args[3];
                        Require(Vector2.Distance(pixels,new Vector2(viewport.x*camera.pixelWidth,viewport.y*camera.pixelHeight)) < .01f,
                            "Paint picking used screen offsets or a flipped Y coordinate; orthographic=" + orthographic);
                    }
                }
                // A world-space circular brush must stay circular on a rotated renderer
                // with nonuniform scaling, rather than inheriting its scale ratio.
                Matrix4x4 localToWorld = Matrix4x4.TRS(new Vector3(3,2,-1),Quaternion.Euler(21,38,-13),new Vector3(4,.5f,1.7f));
                Vector3 viewDir = new Vector3(.2f,.4f,1).normalized;
                var basis = typeof(GaussianSplatPaintBrush).GetMethod("BuildPaintScatterBasis",BindingFlags.Static|BindingFlags.NonPublic);
                object[] basisArgs = { localToWorld.inverse,viewDir,Vector3.zero,Vector3.zero };
                basis.Invoke(null,basisArgs);
                Vector3 right = (Vector3)basisArgs[2], up = (Vector3)basisArgs[3];
                for (int i=0;i<16;++i)
                {
                    float angle=i*Mathf.PI/8;
                    Vector3 worldOffset=localToWorld.MultiplyVector(right*Mathf.Cos(angle)+up*Mathf.Sin(angle));
                    Require(Mathf.Abs(worldOffset.magnitude-1)<.0001f && Mathf.Abs(Vector3.Dot(worldOffset,viewDir))<.0001f,
                        "Nonuniform scale changed the brush radius or camera-facing paint plane.");
                }
                Debug.Log("SplatBox Paint brush PASS: separate source/output, stroke index and layer lifetime, invalid source safety, perspective/orthographic viewport coordinates and transformed brush radius.");
            }
            finally
            {
                if (cameraObject != null) Object.DestroyImmediate(cameraObject);
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                if (holder != null) Object.DestroyImmediate(holder);
                if (sourceObject != null) Object.DestroyImmediate(sourceObject);
                if (outputObject != null) Object.DestroyImmediate(outputObject);
                if (otherObject != null) Object.DestroyImmediate(otherObject);
            }
        }
    }
}
