// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    /// <summary>Exercise the renderer dispatches with fresh compute state, including disabled LoD bindings.</summary>
    public static class PhysicsWindBindingValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const int Count = 128;
        static T Get<T>(object obj, string field) => (T)obj.GetType().GetField(field, Flags).GetValue(obj);
        static void Set(object obj, string field, object value) => obj.GetType().GetField(field, Flags).SetValue(obj, value);
        static void Call(object obj, string method) => obj.GetType().GetMethod(method, Flags).Invoke(obj, null);
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        static void Near(Vector3 actual, Vector3 expected, string message) =>
            Require(Vector3.Distance(actual, expected) < .0001f, message + ": got " + actual + ", expected " + expected);

        static Vector3[] Read(SplatBoxRenderer renderer, string field)
        {
            var result = new Vector3[Count];
            Get<GraphicsBuffer>(renderer, field).GetData(result);
            return result;
        }

        static void Validate(string shaderPath)
        {
            var fixtureType = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
            using var fixture = (IDisposable)Activator.CreateInstance(fixtureType, Flags, null,
                new object[] { shaderPath, false }, null);
            var renderer = Get<SplatBoxRenderer>(fixture, "renderer");
            var sourceShader = Get<ComputeShader>(fixture, "shader");
            ComputeShader isolatedShader = null;
            void FreshShader()
            {
                if (isolatedShader != null) Object.DestroyImmediate(isolatedShader);
                isolatedShader = Object.Instantiate(sourceShader);
                Set(renderer, "m_CSBoxUtil", isolatedShader);
                // A prior paged renderer may have enabled these globals on the shared shader.
                // Each monolithic dispatch must explicitly reset them and bind valid fallbacks.
                isolatedShader.SetInt("_UseSplatIndexRemap", 1);
                isolatedShader.SetInt("_PagedSmudgeValid", 1);
                isolatedShader.SetInt("_PagedAttractorValid", 1);
            }
            try
            {
                var positions = new Vector3[Count];
                for (int i = 0; i < Count; i++) positions[i] = new Vector3(.2f + i * .001f, .1f, .3f);
                Get<GraphicsBuffer>(renderer, "m_GpuPosData").SetData(positions);
                renderer.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                renderer.windGravity = renderer.windDamping = renderer.windMinVelocity = 0;
                Set(renderer, "m_Gravity", 0f); Set(renderer, "m_Damping", 0f); Set(renderer, "m_MinVelocity", 0f);

                // Reproduce activating the editor wind tool, before any physics kernel has run.
                FreshShader();
                renderer.enableWind = true;
                var previous = Read(renderer, "m_GpuSplatPrevPositions");
                var original = Read(renderer, "m_GpuSplatOriginalPositions");
                var velocities = Read(renderer, "m_GpuSplatVelocities");
                for (int i = 0; i < Count; i++)
                {
                    Near(previous[i], positions[i], "Physics initialization lost position " + i);
                    Near(original[i], positions[i], "Wind initialization lost original position " + i);
                    Near(velocities[i], Vector3.zero, "Initial velocity was not zero");
                }

                // No colliders: the wind integration path must move every splat correctly.
                FreshShader();
                for (int i = 0; i < Count; i++) velocities[i] = Vector3.right;
                Get<GraphicsBuffer>(renderer, "m_GpuSplatVelocities").SetData(velocities);
                Call(renderer, "UpdatePhysicsInternal");
                var moved = Read(renderer, "m_GpuPosData");
                for (int i = 0; i < Count; i++) Near(moved[i], positions[i] + Vector3.right * .016f, "Wind integration " + i);

                // Collision path: penetration correction must run, followed by integration.
                FreshShader();
                Get<GraphicsBuffer>(renderer, "m_GpuPosData").SetData(positions);
                Get<GraphicsBuffer>(renderer, "m_GpuSplatVelocities").SetData(new Vector3[Count]);
                renderer.UpdateSphereColliders(new[] { new SphereColliderData { radius = 1, mass = 1 } });
                renderer.SetSphereColliderCount(1);
                Call(renderer, "UpdatePhysicsInternal");
                moved = Read(renderer, "m_GpuPosData");
                Require(moved[0].magnitude > positions[0].magnitude + .1f, "Collision dispatch did not resolve penetration");

                // Actual wind forces: a fresh shader must work without a preceding render dispatch.
                FreshShader();
                renderer.SetSphereColliderCount(0);
                Get<GraphicsBuffer>(renderer, "m_GpuPosData").SetData(positions);
                Get<GraphicsBuffer>(renderer, "m_GpuSplatVelocities").SetData(new Vector3[Count]);
                renderer.UpdateWindBoxes(new[] { new WindBoxData {
                    worldToBox = Matrix4x4.identity, windDirection = Vector3.right,
                    windStrength = 1, noiseScale = 1, flags = 1 } });
                renderer.SetWindBoxCount(1);
                Call(renderer, "UpdateWindEffects");
                velocities = Read(renderer, "m_GpuSplatVelocities");
                Require(velocities[0].sqrMagnitude > .000001f && !float.IsNaN(velocities[0].sqrMagnitude),
                    "Wind force dispatch did not produce finite motion");
            }
            finally
            {
                Set(renderer, "m_CSBoxUtil", sourceShader);
                if (isolatedShader != null) Object.DestroyImmediate(isolatedShader);
            }
        }

        static void ValidateStartup(string shaderPath, bool compressed = false)
        {
            // Open a renderer saved with physics already enabled. Its remap fallback must
            // exist before CreateResourcesForAsset initializes physics/original positions.
            string folder = "Assets/__PhysicsStartup_" + Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets", Path.GetFileName(folder));
            var owner = new GameObject("Physics startup fixture");
            owner.SetActive(false);
            var renderer = owner.AddComponent<SplatBoxRenderer>();
            var asset = ScriptableObject.CreateInstance<GaussianSplatAsset>();
            ComputeShader shader = null;
            TextAsset Data(string name, byte[] bytes)
            {
                string path = folder + "/" + name + ".bytes";
                File.WriteAllBytes(path, bytes);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
            }
            try
            {
                asset.Initialize(Count, compressed ? GaussianSplatAsset.VectorFormat.Norm11 : GaussianSplatAsset.VectorFormat.Float32, GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.ColorFormat.Float32x4, GaussianSplatAsset.SHFormat.Float32,
                    Vector3.zero, Vector3.one, null);
                var coordinates = new float[Count * 3];
                for (int i = 0; i < Count; i++)
                { coordinates[i * 3] = .2f + i * .001f; coordinates[i * 3 + 1] = .1f; coordinates[i * 3 + 2] = .3f; }
                coordinates[(Count - 1) * 3] = 5;
                byte[] bytes;
                TextAsset chunks = null;
                if (compressed)
                {
                    var packed = new uint[Count];
                    for (int i = 0; i < Count; i++)
                    {
                        uint x = (uint)Mathf.RoundToInt((coordinates[i * 3] + 10) / 20 * 2047);
                        uint y = (uint)Mathf.RoundToInt((coordinates[i * 3 + 1] + 10) / 20 * 1023);
                        uint z = (uint)Mathf.RoundToInt((coordinates[i * 3 + 2] + 10) / 20 * 2047);
                        packed[i] = x | (y << 11) | (z << 21);
                        coordinates[i * 3] = x / 2047f * 20 - 10;
                        coordinates[i * 3 + 1] = y / 1023f * 20 - 10;
                        coordinates[i * 3 + 2] = z / 2047f * 20 - 10;
                    }
                    bytes = new byte[Count * 4]; Buffer.BlockCopy(packed, 0, bytes, 0, bytes.Length);
                    var chunkWords = new float[16] { 0, 0, 0, 0, -10, 10, -10, 10, -10, 10, 0, 0, 0, 0, 0, 0 };
                    var chunkBytes = new byte[64]; Buffer.BlockCopy(chunkWords, 0, chunkBytes, 0, 64);
                    chunks = Data("chunks", chunkBytes);
                }
                else
                {
                    bytes = new byte[coordinates.Length * sizeof(float)];
                    Buffer.BlockCopy(coordinates, 0, bytes, 0, bytes.Length);
                }
                var (width, height) = GaussianSplatAsset.CalcTextureSize(Count);
                asset.SetAssetFiles(chunks, Data("positions", bytes), Data("other", new byte[Count * 16]),
                    Data("color", new byte[width * height * 16]), Data("sh", new byte[Count * 48 * 4]));
                string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                shader = Object.Instantiate(AssetDatabase.LoadAssetAtPath<ComputeShader>(root + "/" + shaderPath));
                Set(renderer, "m_CSBoxUtil", shader); Set(renderer, "m_Asset", asset); Set(renderer, "m_EnablePhysics", true);
                Call(renderer, "CreateResourcesForAsset");
                var previous = Read(renderer, "m_GpuSplatPrevPositions");
                for (int i = 0; i < Count; i++)
                    Near(previous[i], new Vector3(coordinates[i * 3], coordinates[i * 3 + 1], coordinates[i * 3 + 2]),
                        "Physics-enabled startup failed to initialize position " + i);

                // Exercise the real editor callback with no SplatBox window or scene clicks.
                Call(renderer, "DisposeResourcesForAsset");
                Set(renderer, "m_EnablePhysics", false);
                owner.SetActive(true);
                Set(renderer, "m_CSBoxUtil", shader);
                Set(renderer, "m_PrevAsset", asset); Set(renderer, "m_PrevHash", asset.dataHash);
                ValidateAttractorModes(renderer, previous, compressed);
            }
            finally
            {
                Call(renderer, "DisposeResourcesForAsset");
                Object.DestroyImmediate(owner); Object.DestroyImmediate(asset);
                if (shader != null) Object.DestroyImmediate(shader);
                AssetDatabase.DeleteAsset(folder);
            }
        }

        static void ValidateAttractorModes(SplatBoxRenderer renderer, Vector3[] baseline, bool compressed)
        {
            var owner = new GameObject("Attractor transport fixture");
            var attractor = owner.AddComponent<GaussianSplatAttractor>();
            var cameraOwner = new GameObject("Attractor view fixture");
            var camera = cameraOwner.AddComponent<Camera>(); camera.enabled = false;
            camera.transform.position = new Vector3(0, 0, -3);
            renderer.enableWind = true;
            Vector3[] Positions()
            {
                var data = Read(renderer, compressed ? "m_GpuPhysicsOffsets" : "m_GpuPosData");
                if (compressed) for (int i = 0; i < data.Length; i++) data[i] += baseline[i];
                return data;
            }
            void Tick()
            {
                typeof(SplatBoxRenderer).GetMethod("RecordSortContext", Flags).Invoke(renderer,
                    new object[] { camera, Time.frameCount });
                Set(renderer, "m_LastEditorPhysicsTick", -1d);
                Call(renderer, "EditorUpdate");
                Require((bool)typeof(SplatBoxRenderer).GetMethod("ShouldSortThisFrame", Flags)
                    .Invoke(renderer, new object[] { camera }), "Motion retained the stationary camera's old depth order");
            }
            var source = new uint[Get<GraphicsBuffer>(renderer, "m_GpuPosData").count];
            Get<GraphicsBuffer>(renderer, "m_GpuPosData").GetData(source);
            try
            {
                for (int mode = 0; mode < 4; mode++)
                foreach (float strength in new[] { .001f, .02f, .377f })
                {
                    attractor.AttractorEnabled = false;
                    Get<GraphicsBuffer>(renderer, compressed ? "m_GpuPhysicsOffsets" : "m_GpuPosData")
                        .SetData(compressed ? new Vector3[Count] : baseline);
                    Set(attractor, "m_Mode", (GaussianSplatAttractor.AttractorMode)mode);
                    attractor.Strength = strength;
                    attractor.AttractorEnabled = true;
                    for (int i = 0; i < 12; i++) Tick();
                    Vector3 moved = Positions()[0];
                    Require(Vector3.Distance(moved, baseline[0]) > .000001f,
                        $"Attractor mode {mode}, strength {strength}, compressed={compressed} produced no editor motion");
                    Near(Positions()[Count - 1], baseline[Count - 1], "Attractor moved geometry outside range");
                    if (mode == 1) Require(moved.magnitude < baseline[0].magnitude, "Attract did not pull inward");
                    if (mode == 2) Require(moved.magnitude > baseline[0].magnitude, "Repel did not push outward");
                    if (mode == 0) Require(Mathf.Abs(moved.x - baseline[0].x) > .0000001f, "Vortex did not swirl");
                    using (var cmd = new CommandBuffer { name = "Validate attractor render positions" })
                    {
                        typeof(SplatBoxRenderer).GetMethod("CalcViewData", Flags).Invoke(renderer,
                            new object[] { cmd, camera, renderer.transform.localToWorldMatrix });
                        Graphics.ExecuteCommandBuffer(cmd);
                        var view = new Vector4[Count * 3];
                        Get<GraphicsBuffer>(renderer, "m_GpuView").GetData(view);
                        Near((Vector3)view[2], moved, "Rendered position ignored monolithic motion");
                    }
                    attractor.AttractorPaused = true;
                    Tick(); Tick(); Near(Positions()[0], moved, "Pause did not hold current shape");
                    attractor.AttractorPaused = false;
                    for (int i = 0; i < 12; i++) Tick();
                    Require(Vector3.Distance(Positions()[0], moved) > .000001f, "Resume did not move geometry");
                    attractor.AttractorEnabled = false;
                    moved = Positions()[0]; Tick(); Tick(); Near(Positions()[0], moved, "Stop did not hold current shape");
                }
                if (compressed)
                {
                    var after = new uint[source.Length]; Get<GraphicsBuffer>(renderer, "m_GpuPosData").GetData(after);
                    for (int i = 0; i < after.Length; i++) Require(after[i] == source[i], "Motion changed packed source bytes");
                }
            }
            finally { Object.DestroyImmediate(owner); Object.DestroyImmediate(cameraOwner); }
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders,
                "Run in an isolated batch project with a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                { ValidateStartup(shader); ValidateStartup(shader, true); Validate(shader); }
                Require(errors.Count == 0, "Physics/wind dispatch errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Physics/Wind bindings PASS: startup, all four attractor modes at low/default/high strength, rendered positions, editor ticks without a window, Pause/Resume/Stop, immutable packed positions, collisions and wind forces on both compute copies.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
