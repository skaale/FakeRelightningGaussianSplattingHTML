using System;
using System.Linq;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GaussianSplatting.Tests
{
    public static class RelightSelectionValidation
    {
        const string Pref = "SplatBox.Relight.UseRelight";
        const BindingFlags Instance = BindingFlags.Instance | BindingFlags.NonPublic;

        public static void Run()
        {
            bool hadPref = EditorPrefs.HasKey(Pref);
            bool previousPref = EditorPrefs.GetBool(Pref);
            float previousRenderScale = GaussianSplatRenderSystem.SplatRenderScale;
            var previousSelection = Selection.objects;
            var previousActiveSelection = Selection.activeObject;
            var previousScene = SceneManager.GetActiveScene();
            bool singleScene = string.IsNullOrEmpty(previousScene.path);
            Require(!singleScene || Application.isBatchMode, "Save the open scene or run validation in an isolated batchmode project.");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, singleScene ? NewSceneMode.Single : NewSceneMode.Additive);
            SceneManager.SetActiveScene(scene);
            string folder = "Assets/SplatBoxRelightValidation_" + Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets", folder.Substring("Assets/".Length));
            GaussianSplatPagedScene paged = null;
            try
            {
                var defaultShader = Resources.Load<Shader>("RenderSplats");
                var relightShader = Resources.Load<Shader>("RenderSplatsRelight");
                Require(defaultShader != null && relightShader != null, "Missing shader resources");
                var editorType = Type.GetType("GaussianSplatting.Editor.GaussianSplatEditorWindow, GaussianSplatting.SplatBox.Editor", true);
                var managerType = Type.GetType("GaussianSplatting.Relight.CustomLightManager, GaussianSplatting.SplatBox.Relight", true);
                var manager = new GameObject("Relight manager");
                manager.SetActive(false);
                manager.AddComponent(managerType);
                var standard = CreateRenderer("Default renderer");
                var relit = CreateRenderer("Relight renderer");

                // Exercise the actual editor buttons, with a conflicting global preference.
                EditorPrefs.SetBool(Pref, true);
                Click(editorType, "ApplyDefaultShaderToRenderer", standard);
                Require(!standard.enabled && !standard.usesRelightShader, "Default button changed enabled state/choice");
                Require(!EditorPrefs.GetBool(Pref), "Default button did not update the new-renderer preference");
                Set(relit, "m_LodFastEditorPreview", false);
                Click(editorType, "ApplyRelightShaderToRenderer", relit);
                Require(!relit.enabled && relit.usesRelightShader, "Relight button changed enabled state/choice");
                Require(!FastPreviewOf(relit), "A non-paged relight button changed a disabled preview preference");
                Set(relit, "m_LodFastEditorPreview", true);
                Click(editorType, "ApplyRelightShaderToRenderer", relit);
                Require(FastPreviewOf(relit), "A non-paged relight button changed an enabled preview preference");
                Invoke(standard, "OnValidate");
                Require(ShaderOf(standard) == defaultShader && !standard.usesRelightShader, "Editor preference overrode default renderer");
                EditorPrefs.SetBool(Pref, false);
                Invoke(relit, "OnValidate");
                Require(ShaderOf(relit) == relightShader && relit.usesRelightShader, "Editor preference overrode relight renderer");

                // Player recovery must obey the saved flag for null, stale and matching references,
                // regardless of whether a relight manager is active or inactive in the scene.
                foreach (bool managerActive in new[] { false, true })
                foreach (bool relight in new[] { false, true })
                foreach (var serializedShader in new[] { null, defaultShader, relightShader })
                {
                    manager.SetActive(managerActive);
                    Set(standard, "m_UseRelightShader", relight);
                    Set(standard, "m_ShaderSplats", serializedShader);
                    for (int retry = 0; retry < 3; ++retry)
                    {
                        Invoke(standard, "ResolvePlayerShaderReferences");
                        Require(ShaderOf(standard) == (relight ? relightShader : defaultShader),
                            $"Player choice changed: relight={relight}, managerActive={managerActive}, retry={retry}");
                    }
                }
                var custom = Shader.Find("Hidden/InternalErrorShader");
                Require(custom != null, "Missing custom-shader test fixture");
                Set(standard, "m_UseRelightShader", false);
                Set(standard, "m_ShaderSplats", custom);
                Invoke(standard, "ResolvePlayerShaderReferences");
                Require(ShaderOf(standard) == custom, "Custom default shader was replaced");

                // A cheap editor preview may use the default shader without changing the saved
                // relight choice; the player must still restore relight in that case.
                paged = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
                paged.Initialize(Vector3.zero, Vector3.one, 1, new[] { new GaussianSplatPageEntry() });
                Set(relit, "m_PagedScene", paged);
                Set(relit, "m_LodFastEditorPreview", true);
                Invoke(relit, "EditorAutoFindShaders");
                Require(relit.usesRelightShader && ShaderOf(relit) == defaultShader, "Fast preview lost the saved relight choice");
                Invoke(relit, "ResolvePlayerShaderReferences");
                Require(ShaderOf(relit) == relightShader, "Player did not restore relight after fast editor preview");

                // An explicit relight request must show relighting immediately. Keeping fast
                // preview enabled caused OnValidate to silently replace the requested shader.
                Click(editorType, "ApplyRelightShaderToRenderer", relit);
                Require(!relit.enabled && relit.usesRelightShader && !FastPreviewOf(relit) &&
                    ShaderOf(relit) == relightShader,
                    "The paged relight button did not disable fast preview while preserving the disabled renderer");
                Invoke(relit, "OnValidate");
                Require(!relit.enabled && !FastPreviewOf(relit) && ShaderOf(relit) == relightShader,
                    "OnValidate replaced the explicitly requested paged relight shader");

                // A later deliberate preview toggle remains available, and may never change
                // the saved player mode or stop player recovery from restoring relighting.
                Set(relit, "m_LodFastEditorPreview", true);
                Invoke(relit, "OnValidate");
                Require(!relit.enabled && relit.usesRelightShader && ShaderOf(relit) == defaultShader,
                    "Manually re-enabling fast preview failed to retain the saved relight choice");
                Invoke(relit, "ResolvePlayerShaderReferences");
                Require(!relit.enabled && FastPreviewOf(relit) && ShaderOf(relit) == relightShader,
                    "Player recovery failed after manually re-enabling fast preview");
                Set(relit, "m_PagedScene", null);

                Click(editorType, "ApplyDefaultShaderToRenderer", standard);
                Click(editorType, "ApplyRelightShaderToRenderer", relit);
                string prefabPath = folder + "/Default.prefab";
                PrefabUtility.SaveAsPrefabAsset(standard.gameObject, prefabPath);
                string scenePath = folder + "/Mixed.unity";
                Require(EditorSceneManager.SaveScene(scene, scenePath), "Scene save failed");
                if (!singleScene) EditorSceneManager.CloseScene(scene, true);
                // Loading with the opposite global preference must not change either saved mode.
                EditorPrefs.SetBool(Pref, true);
                scene = EditorSceneManager.OpenScene(scenePath, singleScene ? OpenSceneMode.Single : OpenSceneMode.Additive);
                SceneManager.SetActiveScene(scene);
                standard = scene.GetRootGameObjects().Single(g => g.name == "Default renderer").GetComponent<SplatBoxRenderer>();
                relit = scene.GetRootGameObjects().Single(g => g.name == "Relight renderer").GetComponent<SplatBoxRenderer>();
                Require(!standard.usesRelightShader && relit.usesRelightShader, "Scene round trip lost mixed renderer choices");
                Invoke(standard, "ResolvePlayerShaderReferences");
                Invoke(relit, "ResolvePlayerShaderReferences");
                Require(ShaderOf(standard) == defaultShader && ShaderOf(relit) == relightShader, "Reloaded scene selected wrong player shaders");
                var prefab = PrefabUtility.LoadPrefabContents(prefabPath);
                try
                {
                    var renderer = prefab.GetComponent<SplatBoxRenderer>();
                    Invoke(renderer, "OnValidate");
                    Require(!renderer.usesRelightShader && ShaderOf(renderer) == defaultShader, "Prefab default choice was overridden");
                }
                finally { PrefabUtility.UnloadPrefabContents(prefab); }
                Debug.Log("SplatBox relight selection PASS: editor buttons, conflicting preferences, disabled renderers, scene/prefab persistence, mixed modes, explicit paged relight preview and player recovery after manual fast preview.");
            }
            finally
            {
                try
                {
                    if (singleScene) EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                    else if (scene.IsValid() && scene.isLoaded) EditorSceneManager.CloseScene(scene, true);
                    if (previousScene.IsValid() && previousScene.isLoaded) SceneManager.SetActiveScene(previousScene);
                    if (paged != null) UnityEngine.Object.DestroyImmediate(paged);
                    AssetDatabase.DeleteAsset(folder);
                }
                finally
                {
                    if (hadPref) EditorPrefs.SetBool(Pref, previousPref);
                    else EditorPrefs.DeleteKey(Pref);
                    GaussianSplatRenderSystem.SplatRenderScale = previousRenderScale;
                    Selection.objects = previousSelection.Where(item => item != null).ToArray();
                    Selection.activeObject = previousActiveSelection;
                }
            }
        }

        static SplatBoxRenderer CreateRenderer(string name)
        {
            var go = new GameObject(name);
            go.SetActive(false);
            var renderer = go.AddComponent<SplatBoxRenderer>();
            renderer.enabled = false;
            return renderer;
        }

        static void Click(Type editor, string method, SplatBoxRenderer renderer) =>
            editor.GetMethod(method, BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer });
        static void Invoke(SplatBoxRenderer renderer, string method) =>
            typeof(SplatBoxRenderer).GetMethod(method, Instance).Invoke(renderer, null);
        static void Set(SplatBoxRenderer renderer, string field, object value) =>
            typeof(SplatBoxRenderer).GetField(field, Instance).SetValue(renderer, value);
        static Shader ShaderOf(SplatBoxRenderer renderer) =>
            (Shader)typeof(SplatBoxRenderer).GetField("m_ShaderSplats", Instance).GetValue(renderer);
        static bool FastPreviewOf(SplatBoxRenderer renderer) =>
            (bool)typeof(SplatBoxRenderer).GetField("m_LodFastEditorPreview", Instance).GetValue(renderer);
        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
