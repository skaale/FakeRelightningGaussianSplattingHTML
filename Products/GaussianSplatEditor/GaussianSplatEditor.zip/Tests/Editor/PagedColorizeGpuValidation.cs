// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    /// <summary>Exercises production colorize dispatch, display sampling and persistent page replay.</summary>
    public static class PagedColorizeGpuValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static readonly Color Source = new Color(.6f, .4f, .2f, .8f);
        static readonly Color Target = new Color(.2f, .7f, .9f, .15f);
        static T Get<T>(object value, string field) => (T)value.GetType().GetField(field, Flags).GetValue(value);
        static void Set(object value, string field, object data) => value.GetType().GetField(field, Flags).SetValue(value, data);
        static object Call(object value, string method, params object[] args) => value.GetType().GetMethod(method, Flags).Invoke(value, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(Color actual, Color expected, string context)
        {
            Require(Mathf.Abs(actual.r - expected.r) < .004f && Mathf.Abs(actual.g - expected.g) < .004f &&
                Mathf.Abs(actual.b - expected.b) < .004f && Mathf.Abs(actual.a - expected.a) < .004f,
                context + ": got " + actual + ", expected " + expected);
        }

        sealed class Fixture : IDisposable
        {
            public readonly object inner;
            public readonly SplatBoxRenderer renderer;
            public readonly GameObject owner;
            public readonly Camera camera;
            public readonly SplatBoxPageGpuState page;
            public Fixture(string path, bool paged = true)
            {
                var type = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                inner = Activator.CreateInstance(type, Flags, null, new object[] { path, paged }, null);
                renderer = Get<SplatBoxRenderer>(inner, "renderer"); owner = Get<GameObject>(inner, "owner");
                camera = Get<Camera>(inner, "camera"); page = Get<SplatBoxPageGpuState>(inner, "page");
                if (paged) Call(inner, "UsePagedPlaceholder");
                var shader = Get<ComputeShader>(inner, "shader");
                Require(shader.IsSupported(shader.FindKernel("CSApplyPagedColor")) &&
                    shader.IsSupported(shader.FindKernel("CSClearPagedColor")), "Paged color kernels unsupported: " + path);
            }
            public Vector3 World(int index) => (Vector3)Call(inner, "WorldPoint", index);
            public Color Sample(int index) => SampleWorld(World(index));
            public Color SampleWorld(Vector3 point)
            {
                Vector3 pixel = camera.WorldToScreenPoint(point);
                float depth = Vector3.Dot(point - camera.transform.position, camera.transform.forward);
                var palette = new Color[4];
                Require(renderer.SamplePaintColors(camera, new Vector2(pixel.x, pixel.y), 2, depth, .025f, palette, out int count) && count == 1,
                    "Expected one sample at " + point + ", got " + count);
                return palette[0];
            }
            public void Dab(int index = 32, float strength = .65f, int mode = 0, float intensity = .4f,
                float noise = 0, float radius = .5f) =>
                renderer.ColorizeInSphere(World(index), radius, Target, strength, .5f, mode, intensity, noise, 1.3f);
            public void Stroke(int index = 32, float strength = .65f, int mode = 0, float intensity = .4f)
            {
                renderer.BeginPagedColorizeStroke(); Dab(index, strength, mode, intensity); renderer.EndPagedColorizeStroke();
            }
            public void ReplayPage() => Call(renderer, "ReplayPagedColorizePage", null, page, page.atlasOffset);
            public void Ensure() => Call(renderer, "EnsurePagedColorizeState", new object[] { null });
            public Vector4[] Overrides()
            {
                Ensure(); var buffer = Get<GraphicsBuffer>(renderer, "m_GpuPagedColorOverrides");
                var data = new Vector4[buffer.count]; buffer.GetData(data); return data;
            }
            public void Dispose() => ((IDisposable)inner).Dispose();
        }

        static float Blend(float a, float b, int mode)
        {
            switch (mode)
            {
                case 1: return a * b;
                case 2: return 1 - (1 - a) * (1 - b);
                case 3: return a < .5f ? 2 * a * b : 1 - 2 * (1 - a) * (1 - b);
                case 4: return Mathf.Min(a, b);
                case 5: return Mathf.Max(a, b);
                case 6: return b < .5f ? 2 * a * b + a * a * (1 - 2 * b) : Mathf.Sqrt(a) * (2 * b - 1) + 2 * a * (1 - b);
                case 7: return b < .5f ? 2 * a * b : 1 - 2 * (1 - a) * (1 - b);
                case 8: return Mathf.Clamp01(a / Mathf.Max(.001f, 1 - b));
                case 9: return Mathf.Clamp01(1 - (1 - a) / Mathf.Max(.001f, b));
                default: return b;
            }
        }
        static Color Expected(Color source, int mode = 0, float strength = .65f, float intensity = .4f)
        {
            var result = source;
            for (int c = 0; c < 3; ++c) result[c] = Mathf.LerpUnclamped(source[c],
                Mathf.LerpUnclamped(Target[c], Blend(source[c], Target[c], mode), intensity), strength);
            return result;
        }

        static void ModesAndHistory(string path)
        {
            using var f = new Fixture(path);
            Near(f.Sample(32), Source, "Initial source");
            var originalSh = new float[128 * 48];
            for (int i = 0; i < originalSh.Length; ++i) originalSh[i] = (i % 31 - 15) * .002f;
            Get<GraphicsBuffer>(f.inner, "sh").SetData(originalSh);
            f.renderer.m_SHOrder = 0; // Compare base-color output while retaining nonzero source SH.
            for (int mode = 0; mode < 10; ++mode)
            {
                f.renderer.ResetPagedColorize(); f.Stroke(mode: mode);
                Near(f.Sample(32), Expected(Source, mode), "Blend " + mode + " / " + path);
                Near(f.Sample(33), Source, "Unpainted splat changed");
                // Actual view generation and sorted/remapped sampling must use the same atlas color.
                Call(f.inner, "Select", new uint[] { 34, 32, 33 }, new uint[] { 2, 0, 1 });
                Near(f.Sample(32), Expected(Source, mode), "Active draw remap changed color");
                Array views = (Array)Call(f.inner, "Views");
                object view = views.GetValue(2);
                uint rg = Get<uint>(view, "color1"), ba = Get<uint>(view, "color2");
                Near(new Color(Mathf.HalfToFloat((ushort)(rg >> 16)), Mathf.HalfToFloat((ushort)rg),
                    Mathf.HalfToFloat((ushort)(ba >> 16)), Mathf.HalfToFloat((ushort)ba)), Expected(Source, mode), "Rendered view color");
            }
            var afterSh = new float[originalSh.Length]; Get<GraphicsBuffer>(f.inner, "sh").GetData(afterSh);
            for (int i = 0; i < afterSh.Length; ++i) Require(afterSh[i] == originalSh[i], "Colorize rewrote source SH.");
            foreach (Color pixel in Get<Texture2D>(f.inner, "color").GetPixels()) Near(pixel, Source, "Source atlas texture mutated");

            f.renderer.ResetPagedColorize();
            f.renderer.BeginPagedColorizeStroke(); f.Dab(); f.Dab(); f.renderer.EndPagedColorizeStroke();
            Color twice = Expected(Expected(Source));
            Near(f.Sample(32), twice, "Repeated dabs did not accumulate");
            Require(f.renderer.pagedColorizeUndoCount == 1, "A mouse gesture should produce one undo item.");
            f.renderer.UndoPagedColorize(); Near(f.Sample(32), Source, "Undo did not restore original color");
            f.renderer.RedoPagedColorize(); Near(f.Sample(32), twice, "Redo changed stroke result");
            f.renderer.BeginPagedColorizeStroke(); f.renderer.EndPagedColorizeStroke();
            Require(f.renderer.pagedColorizeUndoCount == 1, "Empty stroke changed history.");
            f.renderer.ClearPagedColorizeUndoHistory();
            Require(f.renderer.pagedColorizeUndoCount == 0 && f.renderer.pagedColorizeRedoCount == 0, "Clear history kept undo boundaries.");
            Near(f.Sample(32), twice, "Clear history removed visible edits");
            f.renderer.ResetPagedColorize(); Near(f.Sample(32), Source, "Reset did not clear color edits");

            for (int stroke = 0; stroke < 3; ++stroke)
            {
                f.renderer.BeginPagedColorizeStroke(2); f.Dab(strength: .1f); f.renderer.EndPagedColorizeStroke();
            }
            Require(f.renderer.pagedColorizeUndoCount == 2 && f.renderer.UndoPagedColorize() &&
                f.renderer.UndoPagedColorize() && !f.renderer.UndoPagedColorize(), "History limit did not bound Undo.");
            Near(f.Sample(32), Expected(Source, strength: .1f), "History limit erased the retained baseline");
            f.renderer.RedoPagedColorize(); f.renderer.UndoPagedColorize();
            f.Stroke(strength: .25f);
            Require(f.renderer.pagedColorizeRedoCount == 0, "Painting after Undo retained the abandoned redo branch.");
            Near(f.Sample(32), Expected(Expected(Source, strength: .1f), strength: .25f), "New branch changed retained colors");
            f.renderer.ResetPagedColorize(); Near(f.Sample(32), Source, "Reset did not clear bounded history");
        }

        static void ReplayAndPersistence(string path)
        {
            using var f = new Fixture(path);
            f.page.splatCount = 3;
            Vector3 local = (Vector3)Call(f.inner, "Position", 32);
            Call(f.inner, "SetPosition", 35, local + Vector3.right * .1f);
            f.renderer.BeginPagedColorizeStroke(); f.Dab(noise: .65f); f.renderer.EndPagedColorizeStroke();
            Color painted = f.Sample(32);
            Require(painted != Source, "Noise stroke produced no color change.");
            Require(f.Overrides()[35].w == 0, "Stroke wrote detail that was not resident.");
            f.page.splatCount = 4; f.ReplayPage();
            Require(f.Overrides()[35].w > .5f, "New detail did not inherit the color journal.");
            Vector4 late = f.Overrides()[35];
            f.ReplayPage(); Near(f.Sample(32), painted, "Replaying a page applied the same stroke twice");
            Require(Vector4.Distance(f.Overrides()[35], late) < .0001f, "Replay changed deterministic noise for new detail.");

            string saved = EditorJsonUtility.ToJson(f.renderer);
            int groups = f.renderer.pagedColorizeStrokeCount;
            f.renderer.ResetPagedColorize();
            EditorJsonUtility.FromJsonOverwrite(saved, f.renderer);
            Set(f.renderer, "m_LodStreamer", Get<SplatBoxLodStreamer>(f.inner, "streamer"));
            Call(f.inner, "RecreateAtlas"); f.Ensure();
            Require(f.renderer.pagedColorizeStrokeCount == groups, "Serialized color history was lost.");
            Near(f.Sample(32), painted, "Reload/atlas rebuild lost the color edit");
            Require(Vector4.Distance(f.Overrides()[35], late) < .0001f, "Reload did not restore new-detail color.");
            // Replay must use each stroke's original transform, so moving the object keeps its paint.
            f.owner.transform.position += new Vector3(.5f, .5f, 0);
            Call(f.inner, "RecreateAtlas"); f.Ensure();
            Near(f.Sample(32), painted, "Moving the object detached its color edits");
            f.renderer.UndoPagedColorize(); Near(f.Sample(32), Source, "Undo failed after serialization");
            f.renderer.RedoPagedColorize(); Near(f.Sample(32), painted, "Redo failed after serialization");
        }

        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static uint Norm11(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);

        static void Float32MonolithicBox(string path)
        {
            using var f = new Fixture(path, false);
            var source = Get<Texture2D>(f.inner, "color");
            var writable = new RenderTexture(source.width, source.height, 0, source.graphicsFormat)
                { enableRandomWrite = true, filterMode = FilterMode.Point };
            try
            {
                Require(writable.Create(), "Could not create the editable color texture.");
                Graphics.Blit(source, writable);
                Set(f.renderer, "m_GpuColorData", writable);
                var adjustments = ColorAdjustments.Default;
                adjustments.exposure = -1f;
                var brush = f.owner.AddComponent<GaussianSplatColorBrush>();
                brush.TargetRenderer = f.renderer;
                brush.BoxPosition = f.World(32);
                brush.BoxSize = Vector3.one;
                brush.ColorAdjust = adjustments;
                brush.ApplyColorAdjustments();
                Near(f.Sample(32), new Color(Source.r * .5f, Source.g * .5f, Source.b * .5f, Source.a),
                    "Float32 box adjustment");
                Near(f.Sample(33), Source, "Float32 adjustment must stay inside the box");
                Require(Get<GraphicsBuffer>(f.renderer, "m_GpuMonolithicColorOverrides") == null,
                    "Float32 box should update the editable texture for copy and paste.");
            }
            finally
            {
                Set(f.renderer, "m_GpuColorData", source);
                UnityEngine.Object.DestroyImmediate(writable);
            }
        }

        static void PackedColors(string path, bool paged)
        {
            using var f = new Fixture(path, paged);
            f.owner.transform.position = Vector3.zero;
            var asset = Get<GaussianSplatAsset>(f.inner, "asset");
            asset.Initialize(128, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
            var data = Get<TextAsset>(f.inner, "data"); asset.SetAssetFiles(data, data, data, data, data);
            var positions = new uint[128]; var others = new uint[256];
            for (int i = 0; i < 128; ++i)
            {
                positions[i] = Norm11(Vector3.one * .9f); others[i * 2] = 0xE0080200u;
                others[i * 2 + 1] = Norm11(Vector3.one * .5f);
            }
            positions[32] = Norm11(new Vector3(.5f, .5f, .3f));
            positions[33] = Norm11(new Vector3(.5f, .5f, .5f));
            Get<GraphicsBuffer>(f.inner, "pos").SetData(positions); Get<GraphicsBuffer>(f.inner, "other").SetData(others);
            var chunk = new GaussianSplatAsset.ChunkInfo
            {
                posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                colR = HalfRange(.1f, .9f), colG = HalfRange(.2f, .6f), colB = HalfRange(.3f, .7f), colA = HalfRange(.2f, .8f),
                sclX = HalfRange(.5f, 1), sclY = HalfRange(.5f, 1), sclZ = HalfRange(.5f, 1)
            };
            Get<GraphicsBuffer>(f.inner, "chunks").SetData(new[] { chunk }); Set(f.renderer, "m_GpuChunksValid", true);
            if (paged)
            {
                Set(f.renderer, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(f.inner, "chunks"));
                Set(f.renderer, "m_LodUnifiedChunkCount", 1);
            }
            try
            {
                if (paged) Call(f.inner, "Select", new uint[] { 34, 33, 32 }, new uint[] { 2, 0, 1 });
                Vector3 point = new Vector3(Mathf.Round(.5f * 2047) / 2047 * 20 - 10,
                    Mathf.Round(.5f * 1023) / 1023 * 20 - 10, Mathf.Round(.3f * 2047) / 2047 * 10);
                var decoded = new Color(.58f, .36f, .38f, GaussianUtils.InvSquareCentered01(.68f));
                Near(f.SampleWorld(point), decoded, "Packed source decoding");
                var adjustments = ColorAdjustments.Default;
                adjustments.exposure = 1;
                adjustments.colorTint = new Color(.5f, 1f, .25f);
                var expected = new Color(decoded.r, decoded.g * 2, decoded.b * .5f, decoded.a);
                Vector3 size = new Vector3(.25f, .5f, 1f);
                Vector3 outside = new Vector3(point.x, point.y, Mathf.Round(.5f * 2047) / 2047 * 10);
                f.renderer.AdjustColorsInBox(point, size, adjustments);
                Near(f.SampleWorld(point), expected, "Packed box adjustment");
                Near(f.SampleWorld(outside), decoded, "Box changed splats outside its depth");
                if (!paged) return;

                Require(f.renderer.pagedColorizeStrokeCount == 1, "Box adjustment should produce one undo item.");
                f.ReplayPage();
                Near(f.SampleWorld(point), expected, "Packed box replay");
                f.renderer.UndoPagedColorize();
                Near(f.SampleWorld(point), decoded, "Packed box undo");
                f.renderer.RedoPagedColorize();
                Near(f.SampleWorld(point), expected, "Packed box redo");

                string saved = EditorJsonUtility.ToJson(f.renderer);
                f.renderer.ResetPagedColorize();
                EditorJsonUtility.FromJsonOverwrite(saved, f.renderer);
                Set(f.renderer, "m_LodStreamer", Get<SplatBoxLodStreamer>(f.inner, "streamer"));
                f.Ensure();
                Near(f.SampleWorld(point), expected, "Packed box journal reload");

                f.renderer.BeginPagedColorizeStroke();
                f.renderer.ColorizeInSphere(point, .5f, Target, .65f, .5f, 1, .4f);
                f.renderer.EndPagedColorizeStroke();
                Near(f.SampleWorld(point), Expected(expected, 1), "Sphere blending over a box adjustment");
                f.ReplayPage(); Near(f.SampleWorld(point), Expected(expected, 1), "Mixed shape replay");
                f.renderer.ResetPagedColorize(); Near(f.SampleWorld(point), decoded, "Packed reset");
            }
            finally { Set(f.renderer, "m_GpuLodUnifiedChunks", null); } // The shared fixture separately owns this buffer.
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use an isolated batch project with a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    ModesAndHistory(path); ReplayAndPersistence(path);
                    Float32MonolithicBox(path);
                    PackedColors(path, true); PackedColors(path, false);
                }
                Require(errors.Count == 0, "Colorize validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Color GPU PASS: box adjustments for Float32 and packed monoliths and paged LoD, sphere blend modes, alpha/SH/source preservation, undo/redo/reset, streamed detail and serialized replay on both shaders.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
