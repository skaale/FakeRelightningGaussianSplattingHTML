// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    /// <summary>Stable page-local motion for the four attractor modes.</summary>
    public static class PagedAttractorValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object obj, string name) => (T)obj.GetType().GetField(name, Flags).GetValue(obj);
        static void Set(object obj, string name, object value) => obj.GetType().GetField(name, Flags).SetValue(obj, value);
        static object Call(object obj, string method, params object[] args) => obj.GetType().GetMethod(method, Flags).Invoke(obj, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(Vector3 actual, Vector3 expected, string message, float tolerance = .0001f) =>
            Require(Vector3.Distance(actual, expected) <= tolerance, message + ": got " + actual.ToString("G9") + ", expected " + expected.ToString("G9"));
        static AttractorData Effect(Vector3 center, int mode = 1) => new AttractorData {
            position = center, strength = .3f, range = 2, falloff = 1, mode = mode, enabled = 1,
            rotation = Quaternion.identity, scale = Vector3.one, waveFrequency = 2, waveAmplitude = .8f,
            waveSpeed = 1.4f, waveAxis = 1 };
        static Vector3 Force(Vector3 world, AttractorData data, float time)
        {
            if (data.enabled < .5f) return Vector3.zero;
            Vector3 safe = Vector3.Max(data.scale, Vector3.one * .0001f);
            Vector3 local = Quaternion.Inverse(data.rotation) * (world - data.position);
            Vector3 p = new Vector3(local.x / safe.x, local.y / safe.y, local.z / safe.z);
            float distance = p.magnitude;
            if (distance < .001f || distance > data.range) return Vector3.zero;
            Vector3 direction = -p / distance, force;
            float t = distance / data.range;
            if (data.mode == 0)
            {
                force = new Vector3(-direction.z, 0, direction.x) * .8f + direction * .2f;
                force.y = data.vortexHeight * (1 - t);
            }
            else if (data.mode == 1) force = direction;
            else if (data.mode == 2) force = -direction;
            else
            {
                float a, b; Vector3 wave, curl;
                if (data.waveAxis == 0) { a = p.z; b = p.y; wave = Vector3.right; curl = Vector3.up; }
                else if (data.waveAxis == 1)
                {
                    a = new Vector2(p.x, p.z).magnitude; b = Mathf.Atan2(p.z, p.x); wave = Vector3.up;
                    curl = new Vector3(-p.z, 0, p.x) / Mathf.Max(a, .001f);
                }
                else { a = p.x; b = p.y; wave = Vector3.forward; curl = Vector3.up; }
                float amount = Mathf.Sin(a * data.waveFrequency + time * data.waveSpeed) * data.waveAmplitude;
                if (data.secondaryFrequency > .01f)
                    amount += Mathf.Sin(b * data.secondaryFrequency + time * data.waveSpeed * .7f) * data.waveAmplitude * .5f;
                force = wave * amount;
                if (data.curlStrength > .01f)
                    force += curl * Mathf.Cos(a * data.waveFrequency * .5f + time * data.waveSpeed * 1.3f) * data.curlStrength * data.waveAmplitude;
            }
            float scale = Mathf.Sqrt(data.range) * Mathf.Pow(Mathf.Max((safe.x + safe.y + safe.z) / 3, .0001f), .25f) * Mathf.Max(data.falloff, .1f);
            return data.rotation * force * (data.strength * Mathf.Pow(Mathf.Max(0, 1 - t), data.falloff) * scale);
        }
        sealed class Fixture : IDisposable
        {
            public readonly object wrapper, inner;
            public readonly SplatBoxRenderer renderer;
            public readonly SplatBoxPageGpuState page;
            public readonly SplatBoxLodStreamer streamer;
            public readonly GameObject owner;
            public readonly Camera camera;
            public Fixture(string shader)
            {
                var type = typeof(PagedSmudgeValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                wrapper = Activator.CreateInstance(type, Flags, null, new object[] { shader }, null);
                inner = Get<object>(wrapper, "inner"); renderer = Get<SplatBoxRenderer>(wrapper, "renderer");
                page = Get<SplatBoxPageGpuState>(wrapper, "page"); streamer = Get<SplatBoxLodStreamer>(wrapper, "streamer");
                owner = Get<GameObject>(wrapper, "owner"); camera = Get<Camera>(wrapper, "camera");
                Set(renderer, "m_EnableWind", true); renderer.windGravity = 0; renderer.windDamping = 0; renderer.windMinVelocity = 0;
            }
            public void Positions(params Vector3[] positions) => Call(wrapper, "Positions", new object[] { positions });
            public void Select(uint[] active) { var order = new uint[active.Length]; for (int i = 0; i < order.Length; i++) order[i] = (uint)i; Call(wrapper, "Select", active, order); }
            public void SetEffects(params AttractorData[] data) => renderer.SetAttractorData(data);
            public void Step(float dt = .016f, float time = .7f) => Call(renderer, "StepPagedAttractors", dt, time);
            public void Reset() => Call(renderer, "ResetPagedAttractors");
            public void Refresh()
            {
                Call(renderer, "EnsurePagedAttractorHierarchy"); Call(renderer, "RefreshPagedAttractorGpuOffsets");
            }
            public Vector3[] Offsets()
            {
                Refresh(); var buffer = Get<GraphicsBuffer>(renderer, "m_GpuPagedAttractorOffsets"); var data = new Vector3[128];
                bool valid = (bool)renderer.GetType().GetProperty("HasPagedAttractorState", Flags).GetValue(renderer);
                if (valid && buffer != null) buffer.GetData(data); return data;
            }
            public void Dispose() { Call(renderer, "DisposePagedAttractors"); ((IDisposable)wrapper).Dispose(); }
        }
        static void ForceModes(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 center = new Vector3(0, 0, 4), point = center + new Vector3(.5f, .2f, .3f);
            f.Positions(center, point, center + Vector3.right * 4, center);
            f.Select(new uint[] { 33, 34, 35 });
            var sourceWords = new uint[384]; Get<GraphicsBuffer>(f.inner, "pos").GetData(sourceWords);
            const float dt = .016f;
            float proportionality = 2 * dt * dt * Mathf.Pow(.995f, dt / .016f);
            void Check(AttractorData[] effects, string message)
            {
                f.Reset(); f.SetEffects(effects); f.Step(); Vector3 moved = f.Offsets()[33];
                Vector3 expectedForce = Vector3.zero;
                foreach (var effect in effects) expectedForce += Force(f.owner.transform.TransformPoint(point), effect, .7f);
                expectedForce = f.owner.transform.InverseTransformVector(expectedForce);
                Require(expectedForce.sqrMagnitude > 1e-8f && moved.sqrMagnitude > 1e-14f, message + " produced no motion");
                Near(moved, expectedForce * proportionality, message + " force direction/scale", Mathf.Max(1e-8f, moved.magnitude * .002f));
                Near(f.page.lodTree.nodes[1].center, point + moved, message + " CPU/GPU pose");
                Near(f.Offsets()[34], Vector3.zero, message + " moved point outside influence");
            }
            for (int mode = 0; mode < 4; mode++)
            {
                var effect = Effect(center, mode); effect.vortexHeight = .35f;
                Check(new[] { effect }, "Mode " + mode);
                foreach (float strength in new[] { .04f, .5f }) { effect.strength = strength; Check(new[] { effect }, "Strength " + strength); }
                effect = Effect(center, mode);
                foreach (float falloff in new[] { .2f, 2.5f }) { effect.falloff = falloff; Check(new[] { effect }, "Falloff " + falloff); }
                effect = Effect(center, mode); effect.range = 3; Check(new[] { effect }, "Range");
            }
            for (int axis = 0; axis < 3; axis++)
            {
                var effect = Effect(center, 3); effect.waveAxis = axis; effect.waveFrequency = 3.3f;
                effect.waveSpeed = .8f; effect.waveAmplitude = 1.7f; effect.curlStrength = .6f; effect.secondaryFrequency = 1.5f;
                Check(new[] { effect }, "Wave axis/curl/secondary " + axis);
            }
            var rotated = Effect(center, 0); rotated.rotation = Quaternion.Euler(20, 40, 30); rotated.scale = new Vector3(1.3f, .7f, 1.1f); rotated.vortexHeight = .3f;
            Check(new[] { rotated }, "Attractor rotation/ellipsoid");
            var secondary = Effect(center + Vector3.up * .4f, 2); secondary.strength = .11f;
            Check(new[] { rotated, secondary }, "Multiple effects");
            f.owner.transform.SetPositionAndRotation(new Vector3(1, 2, .5f), Quaternion.Euler(10, 25, 5)); f.owner.transform.localScale = new Vector3(1.5f, .8f, 1.2f);
            rotated = Effect(f.owner.transform.TransformPoint(center), 1); rotated.range = 3;
            Check(new[] { rotated }, "Renderer transform");
            var after = new uint[sourceWords.Length]; Get<GraphicsBuffer>(f.inner, "pos").GetData(after);
            for (int i = 0; i < sourceWords.Length; i++) Require(after[i] == sourceWords[i], "Attractor rewrote source position bytes");
            f.Reset(); f.SetEffects(Effect(f.owner.transform.TransformPoint(point), 1)); f.Step();
            Near(f.Offsets()[33], Vector3.zero, "Attractor center generated nonfinite motion");
        }

        static void SortingHierarchyAndAtlas(string shader)
        {
            using var f = new Fixture(shader);
            var source = new[] { new Vector3(0, 0, 4), new Vector3(.04f, 0, 3), new Vector3(-.04f, 0, 5), new Vector3(.1f, 0, 3) };
            f.Positions(source); f.Select(new uint[] { 33, 34 });
            var effect = Effect(new Vector3(0, 0, 4), 3); effect.range = 10; effect.strength = .5f;
            effect.waveAxis = 2; effect.waveFrequency = 20; effect.waveAmplitude = 1; effect.waveSpeed = 0;
            f.SetEffects(effect);
            Vector3[] offsets = null;
            for (int step = 0; step < 160; step++)
            {
                f.Step(); offsets = f.Offsets();
                if (source[1].z + offsets[33].z > source[2].z + offsets[34].z + .6f) break;
            }
            Vector3 first = source[1] + offsets[33], second = source[2] + offsets[34];
            Require(first.z > second.z + .6f && second.z > .3f, "Wave fixture did not reverse front/back order with enough separation for conservative frustum culling");
            var sorted = (uint[])Call(f.wrapper, "Sort");
            Require(sorted[0] == 1 && sorted[1] == 0, "Depth sorting ignored attractor displacement");
            Call(f.wrapper, "ExpectView", first, 1);
            Require(f.renderer.TryGetPaintSurfaceDepth(f.camera, new Vector2(320, 240), 12, out float depth), "Attractor pose was not pickable");
            Require(Mathf.Abs(depth - second.z) < .001f, "Picking ignored the front displaced splat");
            Near(f.page.lodTree.nodes[1].center, first, "Moved hierarchy leaf");
            LodTreeNode parent = f.page.lodTree.nodes[0];
            for (int i = 1; i < source.Length; i++)
            {
                var node = f.page.lodTree.nodes[i]; Require(f.page.bounds.Contains(node.center), "Page bounds lost moving child");
                Require(parent.featureSize * .5f + .001f >= math.distance(parent.center, node.center) + node.featureSize * .5f,
                    "Attractor hierarchy parent no longer encloses a child");
            }
            var entry = new GaussianSplatPageEntry { pageId = f.page.pageId, boundsMin = new Vector3(-.1f, -.1f, 3), boundsMax = new Vector3(.2f, .1f, 5) };
            Bounds bound = (Bounds)Call(f.streamer, "GetEditedPageBounds", entry);
            Require(bound.Contains(first) && bound.Contains(second), "Streaming bounds exclude displaced page geometry");
            var contexts = new[] { new SplatBoxLodTraverser.PageContext { pageSlot = 0, nodes = f.page.lodTree.nodes,
                localToWorld = float4x4.identity, lodScale = 1, outsideFoveate = 1, behindFoveate = 1 } };
            var view = new SplatBoxLodTraverser.ViewContext { cameraWorld = float3.zero, cameraForward = new float3(0, 0, 1),
                pixelScaleFactor = 1000, pixelsPerUnitAtUnitDistance = 500, cosHalfFovY = .7f, screenHeight = 480,
                frustumCull = true, splatScale = 1, cullPlanes = new[] { new float4(0, 0, 1, -(first.z + second.z) * .5f) } };
            var selected = new LodActiveSplatRef[8];
            int selectedCount = SplatBoxLodTraverser.Traverse(contexts, 1, view, selected.Length, .01f, selected, new SplatBoxLodTraverser.Workspace());
            bool foundFirst = false, foundSecond = false;
            for (int i = 0; i < selectedCount; i++) { foundFirst |= selected[i].splatIndex == 1; foundSecond |= selected[i].splatIndex == 2; }
            Require(foundFirst && !foundSecond, "LoD selection culled/refined using pre-motion positions");

            Call(f.renderer, "ClearPagedAttractorVelocities"); f.SetEffects();
            for (int i = 0; i < 4; i++) f.Step(); Near(f.Offsets()[33], offsets[33], "Pause/Stop changed frozen pose");
            // Remapping active splats must not exchange their velocities or displacements.
            f.Select(new uint[] { 34, 33 }); Call(f.wrapper, "ExpectView", second, 0);
            Near(f.Offsets()[33], offsets[33], "Active-index reorder changed source motion");
            var oldNodes = (LodTreeNode[])f.page.lodTree.nodes.Clone();
            f.page.splatCount = 1; f.page.isCoarseStub = true;
            f.page.lodTree = LodTreeRuntime.BuildPrefix(new[] { new LodTreeNode { center = source[0], featureSize = 4, childStart = 1, childCount = 3 } });
            f.Refresh();
            f.page.splatCount = 4; f.page.isCoarseStub = false;
            var baseline = new LodTreeNode[4];
            for (int i = 0; i < baseline.Length; i++) baseline[i] = new LodTreeNode { center = source[i], featureSize = i == 0 ? 4 : .2f, childStart = i == 0 ? 1u : 0u, childCount = i == 0 ? (ushort)3 : (ushort)0 };
            f.page.lodTree = LodTreeRuntime.Build(baseline, true); f.Refresh();
            Near(f.Offsets()[35], offsets[35], "Full-detail return lost hidden child motion");
            Near(f.page.lodTree.nodes[3].center, source[3] + offsets[35], "Full-detail hierarchy reapplied motion twice");
            var pages = Get<List<SplatBoxPageGpuState>>(f.streamer, "m_LoadedList");
            var other = new SplatBoxPageGpuState { pageId = 99, pageSlot = 0, atlasOffset = 32, uploadedAtlasOffset = 32, splatCount = 4,
                lodTree = LodTreeRuntime.Build((LodTreeNode[])baseline.Clone(), true), bounds = f.page.bounds };
            pages[0] = other; Call(f.renderer, "ReplayPagedAttractorPage", null, other, 32);
            Near(f.Offsets()[33], Vector3.zero, "Recycled atlas slot retained another page's motion");
            pages[0] = f.page; f.page.atlasOffset = f.page.uploadedAtlasOffset = 64;
            for (int i = 0; i < source.Length; i++) Call(f.inner, "SetPosition", 64 + i, source[i]);
            Call(f.renderer, "ReplayPagedAttractorPage", null, f.page, 64); f.Refresh();
            Near(f.Offsets()[65], offsets[33], "Returning page lost motion at a new atlas address");
            f.Reset(); Near(f.Offsets()[65], Vector3.zero, "Reset retained attractor motion");
            Near(f.page.lodTree.nodes[1].center, source[1], "Reset retained dynamic hierarchy");
            f.Select(new uint[] { 65, 66 }); Call(f.wrapper, "ExpectView", source[1], 0);
            f.Step(); // No active forces: reset must remain at the source pose on stationary frames.
            Call(f.wrapper, "ExpectView", source[1], 0);
            var stationary = Effect(source[1], 1); stationary.range = .0005f;
            f.SetEffects(stationary); f.Step();
            Near(f.Offsets()[65], Vector3.zero, "Admitting a stationary page reactivated stale GPU offsets");
            Call(f.wrapper, "ExpectView", source[1], 0);
        }

        static void WorkerSnapshotOwnership(string shader)
        {
            using var f = new Fixture(shader);
            f.Positions(new Vector3(0, 0, 4), new Vector3(.4f, 0, 4), new Vector3(-.4f, 0, 4), new Vector3(0, .3f, 4));
            f.SetEffects(Effect(new Vector3(0, 0, 4), 0)); f.Step();
            long uploads = Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls");
            f.Refresh(); f.Refresh();
            Require(Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls") == uploads,
                "Unchanged motion uploaded the same GPU range again");
            var loaded = Get<List<SplatBoxPageGpuState>>(f.streamer, "m_LoadedList");
            var untouched = new SplatBoxPageGpuState { pageId = 99, pageSlot = 1, atlasOffset = 64, uploadedAtlasOffset = 64,
                splatCount = 1, lodNodeCount = 1, gpuPosData = f.page.gpuPosData,
                bounds = new Bounds(Vector3.one * 30, Vector3.one),
                lodTree = LodTreeRuntime.Build(new[] { new LodTreeNode { center = new float3(30), featureSize = .2f } }, true) };
            loaded.Add(untouched);
            try
            {
                f.Step();
                Require(Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls") == uploads + 1,
                    "Local motion uploaded unchanged pages or uploaded its own page more than once");
            }
            finally { loaded.Remove(untouched); }
            var held = f.page.lodTree.nodes;
            var expected = (LodTreeNode[])held.Clone();
            using var worker = new SplatBoxLodSelectionWorker();
            Set(f.renderer, "m_LodSelectionWorker", worker);
            Set(f.renderer, "m_HasLastLodView", true);
            Set(f.renderer, "m_PagedAttractorSelectionComplete", true);
            Set(f.renderer, "m_LodSelectionInvalid", false);
            Set(f.renderer, "m_LodSelectionDirty", false);
            var contexts = new[] { new SplatBoxLodTraverser.PageContext { pageSlot = 0, nodes = held,
                localToWorld = float4x4.identity, lodScale = 1, outsideFoveate = 1, behindFoveate = 1 } };
            var view = new SplatBoxLodTraverser.ViewContext { cameraWorld = float3.zero, cameraForward = new float3(0, 0, 1),
                pixelScaleFactor = 1000, pixelsPerUnitAtUnitDistance = 500, cosHalfFovY = .7f, screenHeight = 480, splatScale = 1 };
            try
            {
                Require(worker.TryBegin(contexts, 1, view, 8, .01f), "Could not borrow animated hierarchy for selection");
                // Even a completed worker owns its immutable snapshot until the main thread
                // consumes the result. Several publications must use the other pool entries.
                var seen = new HashSet<LodTreeNode[]> { held };
                for (int frame = 0; frame < 12; frame++)
                {
                    f.Step(); seen.Add(f.page.lodTree.nodes);
                    Require(!ReferenceEquals(f.page.lodTree.nodes, held), "Publication reused a worker-owned node array");
                    for (int n = 0; n < held.Length; n++)
                    {
                        Near(held[n].center, expected[n].center, "In-flight selection snapshot changed", 0);
                        Require(held[n].featureSize == expected[n].featureSize && held[n].childStart == expected[n].childStart &&
                            held[n].childCount == expected[n].childCount, "In-flight hierarchy metadata changed");
                    }
                    Require(!Get<bool>(f.renderer, "m_LodSelectionInvalid"), "Ordinary motion forced a synchronous selection");
                }
                Require(seen.Count <= 3, "Repeated motion allocated unbounded hierarchy snapshots");
                var task = (System.Threading.Tasks.Task)Get<object>(worker, "m_Task");
                Require(task.Wait(5000) && worker.TryComplete(out var result) && result.selected > 0,
                    "Repeated animation cancelled or lost the selection worker result");
                Require(worker.cancelledSelectionCount == 0, "Ordinary animation cancelled valid background selection");
                bool reused = false;
                for (int frame = 0; frame < 5; frame++) { f.Step(); reused |= ReferenceEquals(f.page.lodTree.nodes, held); }
                Require(reused, "Retired selection snapshot was never returned to the publication pool");
                Set(f.renderer, "m_PagedAttractorSelectionComplete", false);
                Set(f.renderer, "m_LodSelectionInvalid", false);
                f.Step();
                Require(Get<bool>(f.renderer, "m_LodSelectionInvalid"), "Incomplete selection was retained after motion could reveal omitted splats");
            }
            finally { Set(f.renderer, "m_LodSelectionWorker", null); }
        }

        static void BatchedSubsteps(string shader)
        {
            using var f = new Fixture(shader);
            f.Positions(new Vector3(0, 0, 4), new Vector3(.4f, .2f, 4), new Vector3(-.4f, 0, 4), new Vector3(0, .3f, 4));
            var wave = Effect(new Vector3(0, 0, 4), 3); wave.waveAxis = 2; wave.curlStrength = .4f;
            wave.secondaryFrequency = 2.7f; wave.waveSpeed = 4;
            var vortex = Effect(new Vector3(.1f, 0, 4), 0); vortex.vortexHeight = .3f;
            f.renderer.windDamping = .3f;
            f.SetEffects(wave, vortex);
            const float delta = 1f / 60;
            float time = .7f;
            for (int step = 0; step < 4; step++) { f.Step(delta, time); time += delta; }
            var expectedFour = f.Offsets();
            f.Step(delta, time); var expectedFive = f.Offsets();
            f.Reset(); f.SetEffects(wave, vortex);
            object[] args = { delta, .7f, 4, false };
            Require((bool)Call(f.renderer, "SimulatePagedAttractorSubsteps", args), "Batched catch-up did not simulate");
            var actualFour = f.Offsets();
            for (int n = 32; n < 36; n++) Near(actualFour[n], expectedFour[n], "Batched catch-up changed evolving force integration", 1e-7f);
            f.Step(delta, time); var actualFive = f.Offsets();
            for (int n = 32; n < 36; n++) Near(actualFive[n], expectedFive[n], "Batched catch-up changed retained velocity", 1e-7f);
        }

        static void CoalescedUploads(string shader)
        {
            using var f = new Fixture(shader);
            var loaded = Get<List<SplatBoxPageGpuState>>(f.streamer, "m_LoadedList");
            var dynamicPages = new List<SplatBoxPageGpuState>();
            var originals = new Dictionary<SplatBoxPageGpuState, LodTreeNode[]>();
            SplatBoxPageGpuState Page(int id, int atlas, Vector3 center)
            {
                var nodes = new[] { new LodTreeNode { center = center, featureSize = 1, childStart = 1, childCount = 3 },
                    new LodTreeNode { center = center + Vector3.right * .2f, featureSize = .1f },
                    new LodTreeNode { center = center + Vector3.up * .2f, featureSize = .1f },
                    new LodTreeNode { center = center + Vector3.forward * .2f, featureSize = .1f } };
                var page = new SplatBoxPageGpuState { pageId = id, pageSlot = loaded.Count, atlasOffset = atlas, uploadedAtlasOffset = atlas,
                    splatCount = 4, lodNodeCount = 4, gpuPosData = f.page.gpuPosData, bounds = new Bounds(center, Vector3.one),
                    lodTree = LodTreeRuntime.Build(nodes, true) };
                originals.Add(page, (LodTreeNode[])nodes.Clone()); loaded.Add(page); return page;
            }
            loaded.Clear();
            try
            {
                for (int p = 0; p < 8; p++) dynamicPages.Add(Page(p + 10, 32 + p * 8, new Vector3(p * 3, 0, 4)));
                var parked = Page(100, 36, new Vector3(100, 0, 4));
                var main = Effect(new Vector3(10, 0, 4), 0); main.range = 30;
                var remote = Effect(new Vector3(101, 0, 4), 1);
                f.SetEffects(remote); f.Step();
                Vector3 parkedOffset = f.Offsets()[37];
                Require(parkedOffset.sqrMagnitude > 0, "Bridge owner fixture did not acquire a saved dynamic pose");
                Call(f.renderer, "ClearPagedAttractorVelocities"); loaded.Remove(parked); f.SetEffects(main);
                long before = Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls"); f.Step();
                Require(Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls") == before + 1,
                    "Eight adjacent dirty ranges did not coalesce into one upload");
                loaded.Add(parked); Call(f.renderer, "ReplayPagedAttractorPage", null, parked, 36);
                Near(f.Offsets()[37], parkedOffset, "Coalesced upload erased an unchanged owner in its bridge gap", 1e-7f);

                Call(f.renderer, "ClearPagedAttractorVelocities");
                var local = Effect(new Vector3(.3f, 0, 4), 1); local.range = .7f;
                f.SetEffects(local); before = Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls"); f.Step();
                Require(Get<long>(f.renderer, "m_PagedAttractorGpuUploadCalls") == before + 1, "Local update did not keep its single-page upload path");
                Near(f.Offsets()[37], parkedOffset, "Local staging mirror changed a different owner");
                loaded.Remove(parked);
                var replacement = Page(999, 36, new Vector3(120, 0, 4));
                // A two-node synthetic payload in a four-slot resident range exercises the
                // copied<count zero-tail path. Unowned atlas padding has no zero requirement.
                replacement.lodTree = LodTreeRuntime.BuildPrefix(new[] { originals[replacement][0], originals[replacement][1] });
                replacement.isCoarseStub = true;
                Call(f.renderer, "ClearPagedAttractorVelocities");
                f.SetEffects(Effect(new Vector3(121, 0, 4), 1)); f.Step();
                var cleared = f.Offsets();
                Require(cleared[36].sqrMagnitude > 0 && cleared[37].sqrMagnitude > 0, "Short payload did not retain its own offsets");
                for (int n = 38; n < 40; n++) Near(cleared[n], Vector3.zero, "Short payload retained previous owner's tail motion", 1e-7f);
                Call(f.renderer, "ClearPagedAttractorVelocities"); f.SetEffects(main); f.Step();
                var values = f.Offsets();
                foreach (var page in dynamicPages)
                    for (int n = 0; n < page.splatCount; n++)
                        Near(values[page.atlasOffset + n], (Vector3)(page.lodTree.nodes[n].center - originals[page][n].center),
                            "Coalesced publication lost a page's canonical motion", 1e-6f);
                for (int n = 36; n < 38; n++) Near(values[n], cleared[n], "Later batch lost a direct local staging update", 1e-7f);
                for (int n = 38; n < 40; n++) Near(values[n], Vector3.zero, "Later batch resurrected cleared staging bytes", 1e-7f);
            }
            finally { loaded.Clear(); loaded.Add(f.page); }
        }

        static uint Pack(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static void PackedAndSculpted(string shader)
        {
            using var f = new Fixture(shader);
            string folder = "Assets/__AttractorPacked_" + Guid.NewGuid().ToString("N"); AssetDatabase.CreateFolder("Assets", Path.GetFileName(folder));
            GaussianSplatPageAsset sourcePage = null;
            var asset = Get<GaussianSplatAsset>(f.inner, "asset");
            TextAsset Bytes(string name, byte[] bytes)
            {
                string path = folder + "/" + name + ".bytes"; File.WriteAllBytes(path, bytes);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport); return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
            }
            try
            {
                asset.Initialize(4, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
                var positions = new uint[128]; var others = new uint[256];
                for (int i = 0; i < 128; i++) { positions[i] = Pack(Vector3.one * .9f); others[i * 2] = 0xE0080200u; others[i * 2 + 1] = Pack(Vector3.one * .5f); }
                positions[33] = Pack(new Vector3(.5f, .5f, .3f));
                Get<GraphicsBuffer>(f.inner, "pos").SetData(positions); Get<GraphicsBuffer>(f.inner, "other").SetData(others);
                var chunk = new GaussianSplatAsset.ChunkInfo { posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                    colR = HalfRange(0, 1), colG = HalfRange(0, 1), colB = HalfRange(0, 1), colA = HalfRange(.5f, .9f),
                    sclX = HalfRange(.1f, .2f), sclY = HalfRange(.1f, .2f), sclZ = HalfRange(.1f, .2f) };
                Get<GraphicsBuffer>(f.inner, "chunks").SetData(new[] { chunk }); Set(f.renderer, "m_GpuChunksValid", true);
                Set(f.renderer, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(f.inner, "chunks")); Set(f.renderer, "m_LodUnifiedChunkCount", 1);
                byte[] posBytes = new byte[16]; Buffer.BlockCopy(positions, 32 * 4, posBytes, 0, 16);
                var chunkBytes = new byte[64]; var pointer = System.Runtime.InteropServices.Marshal.AllocHGlobal(64);
                try { System.Runtime.InteropServices.Marshal.StructureToPtr(chunk, pointer, false); System.Runtime.InteropServices.Marshal.Copy(pointer, chunkBytes, 0, 64); }
                finally { System.Runtime.InteropServices.Marshal.FreeHGlobal(pointer); }
                var payload = Get<TextAsset>(f.inner, "data"); asset.SetAssetFiles(Bytes("chunks", chunkBytes), Bytes("pos", posBytes), payload, payload, payload);
                Vector3 decoded = new Vector3(Mathf.Round(.5f * 2047) / 2047 * 20 - 10,
                    Mathf.Round(.5f * 1023) / 1023 * 20 - 10, Mathf.Round(.3f * 2047) / 2047 * 10);
                var nodes = new[] { new LodTreeNode { center = decoded, featureSize = 30, childStart = 1, childCount = 3 },
                    new LodTreeNode { center = decoded, featureSize = .2f }, new LodTreeNode { center = new float3(8, 8, 9), featureSize = .2f }, new LodTreeNode { center = new float3(8, 8, 9), featureSize = .2f } };
                sourcePage = ScriptableObject.CreateInstance<GaussianSplatPageAsset>();
                sourcePage.Initialize(f.page.pageId, Vector3Int.zero, Vector3.one * -10, Vector3.one * 10, asset, Bytes("tree", LodTreeNode.ToBytes(nodes)), 4, 3);
                f.page.source = sourcePage; f.page.chunkInfos = new[] { chunk }; f.page.gpuChunksValid = true; f.page.lodTree = LodTreeRuntime.Build(nodes, true);
                f.renderer.SmudgeSplatsGPU(decoded, Vector3.up * .4f, .1f, 0, 1); Vector3 sculpted = decoded + Vector3.up * .4f;
                var effect = Effect(sculpted + Vector3.right, 1); f.SetEffects(effect); f.Step(); f.Select(new uint[] { 33 });
                Vector3 offset = f.Offsets()[33]; Require(offset.x > 0 && Mathf.Abs(offset.y) < 1e-7f, "Packed attractor did not start at decoded/sculpted base");
                Call(f.wrapper, "ExpectView", sculpted + offset, 0); Near(f.page.lodTree.nodes[1].center, sculpted + offset, "Packed CPU hierarchy pose");
                f.Reset(); Call(f.wrapper, "ExpectView", sculpted, 0);
                var after = new uint[128]; Get<GraphicsBuffer>(f.inner, "pos").GetData(after, 0, 0, 128);
                for (int i = 0; i < after.Length; i++) Require(after[i] == positions[i], "Attractor rewrote packed source bytes");
            }
            finally
            {
                Set(f.renderer, "m_GpuLodUnifiedChunks", null); f.page.source = null;
                if (sourcePage != null) Object.DestroyImmediate(sourcePage); AssetDatabase.DeleteAsset(folder);
            }
        }

        static object RealFixture()
        {
            var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
            object fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
            Call(fixture, "AssignScene"); Call(fixture, "PublishPages"); return fixture;
        }
        static void Preload(SplatBoxRenderer renderer, Camera camera) => typeof(PagedSmudgeValidation)
            .GetMethod("Preload", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer, camera });
        static Vector3 PageOffset(SplatBoxRenderer renderer, int pageId, int node)
        {
            Call(renderer, "EnsurePagedAttractorHierarchy"); Call(renderer, "RefreshPagedAttractorGpuOffsets");
            if (!(bool)renderer.GetType().GetProperty("HasPagedAttractorState", Flags).GetValue(renderer)) return Vector3.zero;
            var gpu = Get<GraphicsBuffer>(renderer, "m_GpuPagedAttractorOffsets");
            foreach (var page in renderer.lodStreamer.loadedPages)
                if (page.pageId == pageId)
                {
                    var value = new Vector3[1]; gpu.GetData(value, 0, page.atlasOffset + node, 1); return value[0];
                }
            throw new InvalidOperationException("Expected resident page " + pageId);
        }
        static void RealStreamingAndTransport(string shader)
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null, secondaryFixture = null; RenderTexture target = null;
            GameObject firstOwner = null, secondOwner = null;
            try
            {
                fixture = RealFixture(); var renderer = Get<SplatBoxRenderer>(fixture, "renderer"); renderer.name = "Attractor source";
                var camera = new GameObject("Attractor camera").AddComponent<Camera>(); camera.tag = "MainCamera";
                target = new RenderTexture(640, 480, 0); target.Create(); camera.targetTexture = target;
                Preload(renderer, camera);
                string packageRoot = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                Set(renderer, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(packageRoot + "/" + shader)); Call(renderer, "InitializeKernels");
                renderer.enableWind = true; renderer.windDamping = 0; renderer.windMinVelocity = 0;
                var original = new List<string>();
                foreach (var entry in renderer.pagedScene.pages) original.Add(Convert.ToBase64String(entry.pageAsset.splatData.posData.bytes));
                // Keep only roots addressable before the first simulation step. Full source
                // payloads must still receive motion so fine leaves do not pop back on upgrade.
                foreach (var page in renderer.lodStreamer.loadedPages) { page.splatCount = 1; page.isCoarseStub = true; }
                var effect = Effect(new Vector3(0, 0, 5), 2); effect.range = 3;
                renderer.SetAttractorData(new[] { effect });
                for (int i = 0; i < 15; i++) Call(renderer, "StepPagedAttractors", .016f, .7f);
                foreach (var page in renderer.lodStreamer.loadedPages) { page.splatCount = 3; page.isCoarseStub = false; }
                Vector3 first = PageOffset(renderer, 0, 1);
                Require(first.x < -.001f, "Fine source leaves were not simulated while only coarse roots were addressable");
                renderer.ClearAllVelocities(); renderer.SetAttractorData(Array.Empty<AttractorData>());
                var retired = new List<GraphicsBuffer>(); foreach (var page in renderer.lodStreamer.loadedPages) retired.Add(page.gpuPosData);
                renderer.lodStreamer.UnloadAll(); foreach (var gpu in retired) Require(!gpu.IsValid(), "Unloading animated page retained GPU resources");
                Preload(renderer, camera); Near(PageOffset(renderer, 0, 1), first, "Reload/rebuild lost paused page motion");
                renderer.SetAttractorData(new[] { effect }); renderer.lodStreamer.UnloadAll();
                for (int i = 0; i < 10; i++) Call(renderer, "StepPagedAttractors", .016f, .7f);
                Preload(renderer, camera); Vector3 later = PageOffset(renderer, 0, 1);
                Require(later.x < first.x - .0001f, "Unloaded source page stopped simulating");
                for (int i = 0; i < original.Count; i++) Require(original[i] == Convert.ToBase64String(renderer.pagedScene.pages[i].pageAsset.splatData.posData.bytes), "Motion rewrote real source assets");
                renderer.ResetPagedAttractors(); Near(PageOffset(renderer, 0, 1), Vector3.zero, "Reset did not clear real overlay");
                SelectionPublication(renderer, camera, effect);

                // Runtime components broadcast independently of the editor window, and pausing
                // one effect clears momentum on every affected renderer before remaining forces resume.
                secondaryFixture = RealFixture(); var second = Get<SplatBoxRenderer>(secondaryFixture, "renderer");
                Preload(second, camera); second.enableWind = true; second.windDamping = 0; second.windMinVelocity = 0;
                firstOwner = new GameObject("Attractor transport A"); var a = firstOwner.AddComponent<GaussianSplatAttractor>();
                a.transform.position = new Vector3(0, 0, 5); a.Range = 3; a.Strength = .3f;
                Set(a, "m_Mode", GaussianSplatAttractor.AttractorMode.Attract); a.AttractorEnabled = true;
                secondOwner = new GameObject("Attractor transport B"); var b = secondOwner.AddComponent<GaussianSplatAttractor>();
                b.transform.position = new Vector3(0, .5f, 5); b.Range = 3; b.Strength = .2f;
                Set(b, "m_Mode", GaussianSplatAttractor.AttractorMode.Repel); b.AttractorEnabled = true;
                Require(Get<int>(renderer, "m_ActiveAttractorCount") == 2 && Get<int>(second, "m_ActiveAttractorCount") == 2,
                    "Runtime effects did not broadcast to both renderers");
                foreach (var r in new[] { renderer, second }) { Call(r, "StepPagedAttractors", .016f, .7f); Call(r, "StepPagedAttractors", .016f, .7f); }
                a.AttractorPaused = true;
                Require(Get<int>(renderer, "m_ActiveAttractorCount") == 1 && Get<int>(second, "m_ActiveAttractorCount") == 1, "Pause removed the wrong active effects");
                var bData = Effect(b.transform.position, 2); bData.range = b.Range; bData.strength = b.Strength;
                foreach (var r in new[] { renderer, second })
                {
                    Vector3 before = PageOffset(r, 0, 1);
                    Vector3 expectedDelta = Force(new Vector3(-.9f, 0, 5) + before, bData, .7f) * (2 * .016f * .016f * .995f);
                    Call(r, "StepPagedAttractors", .016f, .7f);
                    Near(PageOffset(r, 0, 1) - before, expectedDelta, "Pause left momentum on one renderer", 1e-7f);
                }
                b.AttractorPaused = true; Vector3 frozen = PageOffset(renderer, 0, 1), secondFrozen = PageOffset(second, 0, 1);
                foreach (var r in new[] { renderer, second }) Call(r, "StepPagedAttractors", .016f, 10f);
                Near(PageOffset(renderer, 0, 1), frozen, "All-paused motion changed pose"); Near(PageOffset(second, 0, 1), secondFrozen, "All-paused secondary changed pose");
                a.AttractorPaused = false; Call(renderer, "StepPagedAttractors", .016f, .7f);
                Require(Vector3.Distance(PageOffset(renderer, 0, 1), frozen) > 1e-7f, "Resume failed to move the frozen pose");
                a.AttractorEnabled = false; frozen = PageOffset(renderer, 0, 1); Call(renderer, "StepPagedAttractors", .016f, 11f);
                Require(Get<int>(renderer, "m_ActiveAttractorCount") == 0, "Stop kept active data"); Near(PageOffset(renderer, 0, 1), frozen, "Stop restored or moved geometry");
                // Component Scale multiplies range and Wave amplitude; gizmo transforms remain independent.
                a.Scale = 2; a.Range = 1.25f; Set(a, "m_WaveAmplitude", .6f); a.transform.localScale = new Vector3(1, 2, 3);
                var parameters = a.GetAttractorData(); Require(Mathf.Abs(parameters.range - 2.5f) < 1e-6f && Mathf.Abs(parameters.waveAmplitude - 1.2f) < 1e-6f && parameters.scale == new Vector3(1, 2, 3), "Effect Scale/transform contract changed");
                a.AttractorEnabled = true; a.Strength = .4f;
                typeof(GaussianSplatAttractor).GetField("s_LastEditorUpdate", BindingFlags.Static | BindingFlags.NonPublic).SetValue(null, -1000d);
                typeof(GaussianSplatAttractor).GetMethod("EditorUpdateAttractors", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, null);
                var forces = Get<Unity.Collections.NativeArray<AttractorData>>(renderer, "m_PagedAttractorForces");
                Require(forces.Length == 1 && Mathf.Abs(forces[0].strength - .4f) < 1e-6f, "Editor-global update did not refresh changed settings without a window");
                renderer.enabled = false;
                a.ManualUpdate();
                Require(!Get<Unity.Collections.NativeArray<AttractorData>>(renderer, "m_PagedAttractorForces").IsCreated,
                    "Global broadcast allocated force state on a disabled renderer");
                a.AttractorEnabled = false; renderer.enabled = true; Preload(renderer, camera);
                Near(PageOffset(renderer, 0, 1), Vector3.zero, "Disable retained transient attractor state");
            }
            finally
            {
                if (firstOwner != null) Object.DestroyImmediate(firstOwner); if (secondOwner != null) Object.DestroyImmediate(secondOwner);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                (fixture as IDisposable)?.Dispose(); (secondaryFixture as IDisposable)?.Dispose();
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
            }
        }

        static void SelectionPublication(SplatBoxRenderer renderer, Camera camera, AttractorData effect)
        {
            renderer.SetAttractorData(new[] { effect });
            Call(renderer, "StepPagedAttractors", .016f, .7f);
            Call(renderer, "SelectAndGatherLodSplats", camera, null, false);
            Require(Get<bool>(renderer, "m_PagedAttractorSelectionComplete") && !Get<bool>(renderer, "m_LodSelectionInvalid") && renderer.activeSplatCount > 0,
                "Synchronous selection did not record actual complete hierarchy coverage");
            Require(renderer.lodStreamer.loadedPages.Count > 1, "Coverage fixture needs multiple roots");
            Call(renderer, "SelectLoadedSplatsWithLodCore", camera, renderer.lodStreamer.loadedPages, 1,
                new LodActiveSplatRef[1], false, false);
            Require(!Get<bool>(renderer, "m_PendingAttractorCompleteCoverage"), "A budget smaller than the page-root count was marked complete");
            Call(renderer, "SelectAndGatherLodSplats", camera, null, false);
            Call(renderer, "StepPagedAttractors", .016f, .72f);
            Require(!Get<bool>(renderer, "m_LodSelectionInvalid"), "Published complete selection was invalidated by ordinary motion");
            Set(renderer, "m_LodAsyncTraversal", true);
            Call(renderer, "SelectAndGatherLodSplats", camera, null, true);
            var worker = Get<SplatBoxLodSelectionWorker>(renderer, "m_LodSelectionWorker");
            Require(worker != null && worker.isRunning, "Actual selection pipeline did not start background refinement during motion");
            Call(renderer, "StepPagedAttractors", .016f, .74f);
            var task = (System.Threading.Tasks.Task)Get<object>(worker, "m_Task");
            Require(task != null && task.Wait(5000) && (bool)Call(renderer, "TryApplyAsyncLodSelection", new object[] { null }),
                "A complete older-pose worker result was rejected by actual renderer publication");
            Require(Get<bool>(renderer, "m_PagedAttractorSelectionComplete") && Get<bool>(renderer, "m_LodSelectionDirty") &&
                !Get<bool>(renderer, "m_LodSelectionInvalid"), "Accepted older pose did not retain coverage while requesting fresh detail");

            uint pose = Get<uint>(renderer, "m_PagedAttractorPoseRevision");
            Set(renderer, "m_AsyncAttractorPoseRevision", pose - 1);
            Set(renderer, "m_AsyncAttractorCompleteCoverage", true);
            Require((bool)Call(renderer, "IsPagedAttractorWorkerPoseValid", 0), "Complete older-pose coverage rejected");
            Require(!(bool)Call(renderer, "IsPagedAttractorWorkerPoseValid", 1), "Older-pose coverage with dropped merged nodes accepted");
            Set(renderer, "m_AsyncAttractorCompleteCoverage", false);
            Require(!(bool)Call(renderer, "IsPagedAttractorWorkerPoseValid", 0), "Incomplete older-pose coverage accepted");
            Call(renderer, "SelectAndGatherLodSplats", camera, null, false);
            renderer.SmudgeSplatsGPU(new Vector3(-.9f, 0, 5), Vector3.right * .02f, .25f, 0, 1);
            Call(renderer, "StepPagedAttractors", .016f, .76f);
            Require(Get<bool>(renderer, "m_LodSelectionInvalid"), "Changed sculpt baseline retained an obsolete selection");
            renderer.ResetPagedSculpt(); renderer.ResetPagedAttractors();
            renderer.SetAttractorData(Array.Empty<AttractorData>());
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use an isolated batch project with a graphics device");
            var errors = new List<string>(); Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                { ForceModes(shader); SortingHierarchyAndAtlas(shader); WorkerSnapshotOwnership(shader); BatchedSubsteps(shader); CoalescedUploads(shader); PackedAndSculpted(shader); RealStreamingAndTransport(shader); }
                Require(errors.Count == 0, "Paged attractor validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Paged Attractor PASS: all4 force modes/settings, Wave and transforms, batched integration parity, worker snapshot ownership/reuse, complete-frontier async publication and invalidation, dirty/coalesced GPU uploads with parked owners and cleared tails, packed/sculpted baseline, sorting/picking/hierarchy/bounds, page reload and atlas reuse, transport and immutable sources on both shaders.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
