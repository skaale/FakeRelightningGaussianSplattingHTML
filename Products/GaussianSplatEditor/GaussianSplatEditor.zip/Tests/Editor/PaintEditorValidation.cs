// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    // Replaces scenes and writes temporary assets: isolated batch project only.
    public static class PaintEditorValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        struct View { public Vector4 clip; public uint a,b,c,d; public Vector3 world; public uint index; }
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Set(object value, string field, object data) => value.GetType().GetField(field,Flags).SetValue(value,data);
        static object Call(object value, string method, params object[] args) => value.GetType().GetMethod(method,Flags).Invoke(value,args);
        static void Preload(SplatBoxRenderer source, Camera camera)
        {
            if (!source.UsesPagedLod) return;
            Require(source.ForceRebuildPagedLodInEditor(),"Paint source failed to initialize.");
            for(int i=0;i<10;++i) { if(source.lodStreamer!=null) Set(source.lodStreamer,"m_LastPageUploadFrame",-1); source.PreloadPagedLodPages(camera); }
        }
        static int Draw(SplatBoxRenderer output,Camera camera,RenderTexture target)
        {
            typeof(PagedXcopyCameraValidation).GetMethod("Draw",BindingFlags.Static|BindingFlags.NonPublic)
                .Invoke(null,new object[]{camera,target,new List<SplatBoxRenderer>()});
            var views=new View[output.activeSplatCount];
            ((GraphicsBuffer)output.GetType().GetField("m_GpuView",Flags).GetValue(output)).GetData(views);
            int visible=0;
            foreach(var view in views) if(view.clip.w>0 && Mathf.HalfToFloat((ushort)view.d)>0.005f) ++visible;
            return visible;
        }
        static Splat[] Read(SplatBoxRenderer output)
        {
            using var buffer=new GraphicsBuffer(GraphicsBuffer.Target.Structured,output.splatCount,UnsafeUtility.SizeOf<Splat>());
            Require(output.ExportPaintSplats(buffer,0,output.splatCount),"Paint output export failed.");
            var values=new Splat[output.splatCount]; buffer.GetData(values); return values;
        }
        static SplatBoxRenderer MonoSource(string folder,GaussianSplatAssetCreator.DataQuality quality)
        {
            var values=new Splat[256];
            for(int i=0;i<values.Length;++i)
                values[i]=new Splat { pos=new Vector3((i%16-7.5f)*.025f,(i/16-7.5f)*.025f,5+(i%3)*.0001f),
                    dc0=(new Vector3(.6f,.4f,.2f)-Vector3.one*.5f)/.2820948f,
                    opacity=Mathf.Log(4),scale=Vector3.one*Mathf.Log(.03f),rot=new Quaternion(1,0,0,0) };
            using var data=new NativeArray<Splat>(values,Allocator.TempJob);
            string path=GaussianSplatAssetCreator.CreateAssetFromSplats(data,folder,"Source",quality);
            var owner=new GameObject("Paint validation source"); owner.SetActive(false);
            var renderer=owner.AddComponent<SplatBoxRenderer>(); renderer.m_Asset=AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
            owner.SetActive(true); Require(renderer.HasValidRenderSetup,"Monolithic Paint fixture failed: "+quality); return renderer;
        }

        public static void RunAll()
        {
            Require(Application.isBatchMode,"Run Paint validation in an isolated batch project.");
            PaintBrushValidation.Run();
            PaintLayoutValidation.Run();
            PaintSamplingValidation.Run();
            Run();
            Debug.Log("SplatBox Paint suite PASS.");
        }

        public static void Run()
        {
            Require(Application.isBatchMode,"Run Paint validation in an isolated batch project.");
            foreach(string kind in new[]{"Paged","VeryLow","Low","Medium","High"}) ValidateSource(kind);
            Debug.Log("SplatBox Paint editor PASS: paged/VeryLow/Low/Medium/High sources, live GPU/CPU/texture strokes, sampling, shader inheritance, immutable source, Undo/Redo, reset and save/reopen.");
        }

        public static void RunCompatibility()
        {
            Require(Application.isBatchMode,"Run Paint validation in an isolated batch project.");
            ValidateSource("VeryLow");
            FillLayoutValidation.Run();
            PagedFillValidation.Run();
            Debug.Log("SplatBox Paint compatibility PASS: VeryLow/BC7 and existing paged Fill.");
        }

        static void ValidateSource(string kind)
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            string folder="Assets/__PaintValidation_"+Guid.NewGuid().ToString("N"); AssetDatabase.CreateFolder("Assets",folder.Substring(7));
            string scenePath=folder+"/scene.unity";
            object fixture=null; GaussianSplatEditorWindow window=null; RenderTexture target=null; Texture2D texture=null;
            var folders=new HashSet<string>(); var errors=new List<string>();
            Application.LogCallback observe=(message,stack,type)=> { if(type==LogType.Error||type==LogType.Exception||type==LogType.Assert) errors.Add(message); };
            Application.logMessageReceived+=observe;
            try
            {
                SplatBoxRenderer source;
                if(kind=="Paged")
                {
                    var type=typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture",BindingFlags.NonPublic);
                    fixture=Activator.CreateInstance(type,Flags,null,new object[]{false},null);
                    Call(fixture,"AssignScene"); Call(fixture,"PublishPages"); source=(SplatBoxRenderer)type.GetField("renderer",Flags).GetValue(fixture);
                }
                else source=MonoSource(folder,(GaussianSplatAssetCreator.DataQuality)Enum.Parse(typeof(GaussianSplatAssetCreator.DataQuality),kind));
                source.name="Paint validation source";
                Set(source,"m_UseRelightShader",true); Set(source,"m_LodFastEditorPreview",true);
                var camera=new GameObject("Paint validation camera").AddComponent<Camera>(); camera.tag="MainCamera";
                target=new RenderTexture(640,480,0,RenderTextureFormat.ARGB32); target.Create(); camera.targetTexture=target;
                Preload(source,camera);
                int originalCount=source.splatCount; var originalAsset=source.m_Asset; var originalScene=source.pagedScene;
                Require(!source.SupportsInPlacePaint,"Fixture should require separate Paint output: "+kind);
                var holder=new GameObject("Paint validation brush"); holder.SetActive(false);
                var brush=holder.AddComponent<GaussianSplatPaintBrush>(); brush.TargetRenderer=source;
                brush.SplatsPerStroke=7; brush.PaintDensity=.75f; brush.EnableLayering=false; brush.SplatSizeMultiplier=.2f;
                window=ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window,"m_TargetRenderer",source); Set(window,"m_PaintBrush",brush);
                Set(window,"m_CurrentTool",GaussianSplatEditorWindow.BrushTool.PaintBrush); Set(window,"m_PaintBrushMode",0);
                var ray=new Ray(camera.transform.position,Vector3.forward);
                brush.SampleColorsAtRay(ray,camera,5,40);
                Require(brush.HasSampledColors,"Paint could not sample "+kind);
                Color sampled=brush.GetAverageColor();
                Require(Mathf.Abs(sampled.r-.6f)<.07f && Mathf.Abs(sampled.g-.4f)<.07f && Mathf.Abs(sampled.b-.2f)<.07f,"Wrong packed/paged sampled colors: "+sampled);
                brush.BeginPaintStroke(); GaussianSplatPaintBrush.IsPainting=true;
                Require(brush.FindSplatSurfaceFromRay(ray,camera,5,40).HasValue,"Initial surface query failed.");
                camera.transform.position=Vector3.forward;
                var movedHit=brush.FindSplatSurfaceFromRay(new Ray(Vector3.forward,Vector3.forward),camera,4,40);
                Require(movedHit.HasValue && Mathf.Abs(movedHit.Value.z-5)<.002f,"Camera motion reused stale Paint depth.");
                camera.transform.position=Vector3.zero; brush.ResetBufferState(); GaussianSplatPaintBrush.IsPainting=false;
                Require((bool)Call(window,"BeginPaintOutputStroke"),"Could not begin empty stroke.");
                string emptyFolder=System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(brush.PaintOutputRenderer.m_Asset)).Replace('\\','/');
                Call(window,"FinishPaintOutputStroke");
                Require(brush.PaintOutputRenderer==null && !AssetDatabase.IsValidFolder(emptyFolder),"An empty stroke retained preview objects/assets.");
                texture=new Texture2D(2,2,TextureFormat.RGBA32,false);
                texture.SetPixels(new[]{new Color(.1f,.8f,.3f,.8f),new Color(.1f,.8f,.3f,.8f),new Color(.1f,.8f,.3f,.8f),new Color(.1f,.8f,.3f,.8f)}); texture.Apply();
                brush.LoadTextureToSlot(texture,0);
                if (kind == "Paged" || kind == "High")
                {
                    Set(window,"m_CurrentTool",GaussianSplatEditorWindow.BrushTool.TextureStamp);
                    Set(window,"m_StampResolution",8);
                    Set(window,"m_StampDensity",.5f);
                    Set(window,"m_StampBlendMode",GaussianSplatEditorWindow.StampBlendMode.Multiply);
                    Set(window,"m_StampLayeringEnabled",true);
                    Set(window,"m_StampLayerSpacing",.05f);
                    Set(window,"m_StampCurrentLayer",1);
                    Call(window,"ExecuteTextureStamp",new Vector3(-.2f,-.2f,5),new Vector3(.2f,.2f,5),camera,texture);
                    var stamp=GameObject.Find(source.name+" Stamp");
                    Require(stamp!=null,"Stamp did not create an output on "+kind+": "+window.GetType().GetField("m_StampStatus",Flags).GetValue(window));
                    var stamped=stamp.GetComponentInChildren<SplatBoxRenderer>();
                    Require(stamped!=null && stamped.splatCount==64,"Stamp did not save its complete grid on "+kind+".");
                    folders.Add(System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(stamped.m_Asset)).Replace('\\','/'));
                    var stampData=Read(stamped);
                    int blended=0;
                    foreach(var value in stampData)
                    {
                        var rgb=GaussianUtils.SH0ToColor(value.dc0);
                        if (Mathf.Abs(rgb.x-.06f)<.04f && Mathf.Abs(rgb.y-.32f)<.04f && Mathf.Abs(rgb.z-.06f)<.04f) blended++;
                        Require(Mathf.Abs(GaussianUtils.Sigmoid(value.opacity)-.4f)<.015f,"Stamp opacity was not preserved.");
                        Require(Mathf.Abs(value.pos.z-4.95f)<.003f,"Stamp layering offset was not preserved.");
                    }
                    Require(blended>0,"Stamp did not blend against source colors on "+kind+".");
                    Require(source.splatCount==originalCount && source.pagedScene==originalScene && source.m_Asset==originalAsset,"Stamp modified its source.");
                    Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Require(GameObject.Find(source.name+" Stamp")==null,"Undo did not remove the Stamp.");
                    Undo.PerformRedo(); Require(GameObject.Find(source.name+" Stamp")!=null,"Redo did not restore the Stamp.");
                    Set(window,"m_CurrentTool",GaussianSplatEditorWindow.BrushTool.PaintBrush);
                    Preload(source,camera);
                }
                var roots=new List<string>();
                for(int mode=0;mode<3;++mode)
                {
                    brush.UseGPUPaint=mode!=1; brush.UseCustomColor=mode==0; brush.CustomColor=new Color(.85f,.15f,.25f,.8f); brush.ColorVariation=0;
                    brush.UseTexturePaint=mode==2; brush.ActiveTextureSlot=0;
                    Require((bool)Call(window,"BeginPaintOutputStroke"),"Could not start Paint stroke on "+kind);
                    var output=brush.PaintOutputRenderer;
                    Require(output!=null && output!=source && output.SupportsInPlacePaint,"Paint did not create a compatible separate output.");
                    string outputFolder=System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(output.m_Asset)).Replace('\\','/'); folders.Add(outputFolder);
                    brush.BeginPaintStroke();
                    GaussianSplatPaintBrush.IsPainting=true;
                    for(int dab=0;dab<2;++dab)
                        if(mode==2) brush.PaintWithTextureAtRay(ray,camera,.1f,Vector3.forward,5); else brush.PaintAtRay(ray,camera,.1f,Vector3.forward,5);
                    Require(brush.PaintedSplatEndIndex==15,"Paint capacity tracker did not count 14 splats after dummy seed.");
                    Require(Draw(output,camera,target)==14,"Live Paint preview missing splats or rendering uninitialized headroom on "+kind+" mode "+mode);
                    if(mode==2 && kind=="Paged")
                        Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),scenePath),"Saving active Paint stroke failed.");
                    else Call(window,"FinishPaintOutputStroke");
                    Require(brush.PaintOutputRenderer==null && output.m_Asset.splatCount==14 && output.splatCount==14,"Completed Paint stroke did not save exact count.");
                    Require(output.usesRelightShader==source.usesRelightShader,"Paint lost source shader preference.");
                    Require(source.splatCount==originalCount && source.m_Asset==originalAsset && source.pagedScene==originalScene && source.pagedLodEraseStrokeCount==0,"Painting modified its source.");
                    Color expected=mode==0?brush.CustomColor:mode==1?sampled:new Color(.1f,.8f,.3f,.8f);
                    foreach(var value in Read(output))
                    {
                        var rgb=GaussianUtils.SH0ToColor(value.dc0);
                        Require(Vector3.Distance(rgb,new Vector3(expected.r,expected.g,expected.b))<.025f,"Paint color changed during serialization.");
                        Require(Mathf.Abs(GaussianUtils.Sigmoid(value.opacity)-expected.a*.75f)<.015f,"Paint density/alpha did not persist.");
                        Require(Mathf.Abs(value.pos.z-5)<.002f && new Vector2(value.pos.x,value.pos.y).magnitude<=.101f,"Paint missed the sampled surface or brush radius.");
                        Require(value.sh1.sqrMagnitude==0 && value.shF.sqrMagnitude==0,"New Paint splats contain uninitialized SH.");
                    }
                    string rootName=output.transform.parent.name; roots.Add(rootName);
                    Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Require(GameObject.Find(rootName)==null,"One Undo did not remove the Paint stroke.");
                    Undo.PerformRedo(); Require(GameObject.Find(rootName)!=null,"Redo did not restore Paint stroke.");
                    Preload(source,camera);
                }
                // A renderer selection change can reset the brush before the window's next
                // update. Its checkpoint must retain the entire pending stroke.
                Require((bool)Call(window,"BeginPaintOutputStroke"),"Could not begin target-switch stroke.");
                var pending=brush.PaintOutputRenderer;
                folders.Add(System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(pending.m_Asset)).Replace('\\','/'));
                brush.BeginPaintStroke(); brush.UseTexturePaint=false; brush.UseCustomColor=true;
                brush.PaintAtRay(ray,camera,.1f,Vector3.forward,5); brush.PaintAtRay(ray,camera,.1f,Vector3.forward,5);
                Call(window,"RecordPaintOutputProgress");
                brush.TargetRenderer=null; Set(window,"m_TargetRenderer",null); Call(window,"UpdatePaintPersistence");
                Require(pending!=null && pending.m_Asset.splatCount==14,"Target change discarded or truncated a pending Paint stroke.");
                roots.Add(pending.transform.parent.name);
                Set(window,"m_TargetRenderer",source); brush.TargetRenderer=source;
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),scenePath),"Could not save painted scene.");
                EditorSceneManager.OpenScene(scenePath,OpenSceneMode.Single);
                source=GameObject.Find("Paint validation source").GetComponent<SplatBoxRenderer>();
                camera=GameObject.Find("Paint validation camera").GetComponent<Camera>(); camera.targetTexture=target; Preload(source,camera);
                foreach(string rootName in roots)
                {
                    var output=GameObject.Find(rootName)?.GetComponentInChildren<SplatBoxRenderer>();
                    Require(output!=null && output.m_Asset.splatCount==14 && Draw(output,camera,target)==14,"Reopened Paint stroke is missing or invisible on "+kind);
                }
                Set(window,"m_TargetRenderer",source); Call(window,"ResetAllSplatEdits");
                foreach(string rootName in roots) Require(GameObject.Find(rootName)==null,"Reset All retained Paint stroke.");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                foreach(string rootName in roots) Require(GameObject.Find(rootName)!=null,"Undo Reset All lost Paint stroke.");
                Require(errors.Count==0,"Paint validation logged errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox Paint source PASS: "+kind);
            }
            finally
            {
                Application.logMessageReceived-=observe;
                if(window!=null) Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
                if(fixture is IDisposable disposable) disposable.Dispose();
                if(target!=null) { target.Release(); Object.DestroyImmediate(target); }
                if(texture!=null) Object.DestroyImmediate(texture);
                foreach(string ownFolder in folders) AssetDatabase.DeleteAsset(ownFolder);
                AssetDatabase.DeleteAsset(folder);
            }
        }
    }
}
