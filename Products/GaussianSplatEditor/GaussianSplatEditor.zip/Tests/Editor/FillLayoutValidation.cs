// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    public static class FillLayoutValidation
    {
        const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Set(object obj, string name, object value) => obj.GetType().GetField(name, Flags).SetValue(obj, value);
        static void Layout(GaussianSplatEditorWindow window)
        {
            window.SendEvent(new Event { type = EventType.Layout });
            window.SendEvent(new Event { type = EventType.Repaint });
        }

        static void ValidatePreview(Vector3[] polygon, float expectedArea, Vector3? excludedPoint = null)
        {
            var method = typeof(GaussianSplatEditorWindow).GetMethod("TryTriangulateFillPreview",
                BindingFlags.Static | BindingFlags.NonPublic);
            object[] args = { polygon, Vector3.forward, null };
            Require((bool)method.Invoke(null, args), "Fill preview could not triangulate a valid polygon.");
            var indices = (int[])args[2];
            Require(indices.Length >= 3 && indices.Length % 3 == 0, "Fill preview returned invalid triangle indices.");
            float area = 0f;
            for (int i = 0; i < indices.Length; i += 3)
            {
                Vector3 a = polygon[indices[i]], b = polygon[indices[i + 1]], c = polygon[indices[i + 2]];
                area += Vector3.Cross(b - a, c - a).magnitude * 0.5f;
                if (!excludedPoint.HasValue) continue;
                Vector3 p = excludedPoint.Value;
                float ab = Vector3.Cross(b - a, p - a).z;
                float bc = Vector3.Cross(c - b, p - b).z;
                float ca = Vector3.Cross(a - c, p - c).z;
                bool covered = ab >= -1e-5f && bc >= -1e-5f && ca >= -1e-5f ||
                    ab <= 1e-5f && bc <= 1e-5f && ca <= 1e-5f;
                Require(!covered, "Fill preview shaded the empty notch of a concave polygon.");
            }
            Require(Mathf.Abs(area - expectedArea) < 0.0001f, "Fill preview triangle area does not match the polygon.");
        }

        public static void Run()
        {
            Require(Application.isBatchMode, "Run Fill validation in an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            {
                if (message.Contains("Invalid GUILayout state") || message.Contains("Getting control") ||
                    message.Contains("ImmediateModeException")) errors.Add(message);
            };
            Application.logMessageReceived += observe;
            GaussianSplatEditorWindow window = null;
            SceneView sceneView = null;
            try
            {
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); window.ShowUtility();
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.FillBrush);
                Set(window, "m_ShowToolSettings", true);
                Layout(window);
                var brush = (GaussianSplatFillBrush)window.GetType().GetField("m_FillBrush", Flags).GetValue(window);
                Require(brush != null, "Fill tool failed to initialize during Layout.");
                brush.StartDrawing(new Vector3(-1,0,5), Vector3.forward);
                brush.AddVertex(new Vector3(0,0,5)); brush.AddVertex(new Vector3(1,0,5));
                Require(Vector3.Dot(brush.PolygonNormal, Vector3.forward) > 0.999f,
                    "Collinear leading vertices changed the Fill drawing plane.");
                // A closed polygon adds the transform controls. Scene keyboard input can close
                // or clear it after Layout but before the editor window gets its Repaint.
                brush.StartDrawing(new Vector3(-1,-1,5), Vector3.forward);
                sceneView = ScriptableObject.CreateInstance<SceneView>();
                sceneView.ShowUtility();
                sceneView.camera.transform.rotation = Quaternion.Euler(0, 30, 0);
                var hitMethod = window.GetType().GetMethod("GetFillHitPoint", Flags);
                Vector3 planeHit = (Vector3)hitMethod.Invoke(window, new object[]
                {
                    new Ray(new Vector3(2, 3, 0), Vector3.forward), sceneView, false
                });
                Require(Vector3.Distance(planeHit, new Vector3(2, 3, 5)) < 0.0001f,
                    "Moving the Scene camera changed the Fill drawing plane.");
                brush.AddVertex(new Vector3(1,-1,5)); brush.AddVertex(new Vector3(1,1,5));
                brush.AddVertex(new Vector3(-1,1,5));
                window.SendEvent(new Event { type = EventType.Layout });
                brush.ClosePolygon();
                window.SendEvent(new Event { type = EventType.Repaint });
                Layout(window);
                window.SendEvent(new Event { type = EventType.Layout });
                brush.Clear();
                window.SendEvent(new Event { type = EventType.Repaint });
                Layout(window);
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.CloneBrush);
                window.SendEvent(new Event { type = EventType.Repaint }); Layout(window);
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.FillBrush);
                window.SendEvent(new Event { type = EventType.Repaint }); Layout(window);
                Require(errors.Count == 0, "Fill layout regression: " + string.Join(" | ", errors));

                // Closing, Undo and editing a transformed polygon must retain its displayed
                // geometry; the serialized tool state also survives a scene/domain reload.
                brush.StartDrawing(new Vector3(-1,-1,5), Vector3.forward);
                brush.AddVertex(new Vector3(1,-1,5)); brush.AddVertex(new Vector3(1,1,5));
                brush.AddVertex(new Vector3(-1,1,5)); brush.ClosePolygon();
                brush.TransformOffset = new Vector3(2,3,1);
                brush.TransformRotation = Quaternion.Euler(20,35,12);
                brush.TransformScale = new Vector3(2,0.7f,1.3f);
                var before = brush.GetTransformedVertices();
                var requested = before[1] + Vector3.up * 0.2f;
                brush.MoveTransformedVertex(1, requested);
                var after = brush.GetTransformedVertices();
                for (int i = 0; i < after.Count; ++i)
                    Require(Vector3.Distance(after[i], i == 1 ? requested : before[i]) < 0.0001f,
                        "Dragging a transformed Fill vertex moved another vertex.");
                var loaded = new GameObject("Reloaded Fill brush").AddComponent<GaussianSplatFillBrush>();
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(brush), loaded);
                Require(loaded.IsClosed && loaded.VertexCount == 4, "Fill polygon state was not serialized.");
                for (int i = 0; i < after.Count; ++i)
                    Require(Vector3.Distance(loaded.GetTransformedVertex(i), after[i]) < 0.0001f,
                        "Fill transform changed after serialized reload.");
                loaded.UndoLastVertex(); loaded.UndoLastVertex();
                Require(!loaded.IsClosed && loaded.IsDrawing && !loaded.HasValidPolygon,
                    "Undo Vertex left an invalid two-vertex polygon closed.");
                var concave = new[]
                {
                    new Vector3(0,0,5), new Vector3(3,0,5), new Vector3(3,1,5),
                    new Vector3(1,1,5), new Vector3(1,3,5), new Vector3(0,3,5)
                };
                ValidatePreview(concave, 5f, new Vector3(2,2,5));
                Array.Reverse(concave);
                ValidatePreview(concave, 5f, new Vector3(2,2,5));
                ValidatePreview(new[] { new Vector3(0,0,5), new Vector3(2,0,5),
                    new Vector3(2,2,5), new Vector3(0,2,5) }, 4f);
                Require(errors.Count == 0, "Fill layout regression: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Fill layout and tool geometry PASS: cold initialization, Scene close/clear between events, tool switches, fixed drawing plane, transformed vertex edits, serialized polygon state and concave previews.");
            }
            finally
            {
                if (window != null) window.Close();
                if (sceneView != null) sceneView.Close();
                Application.logMessageReceived -= observe;
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            }
        }
    }
}
