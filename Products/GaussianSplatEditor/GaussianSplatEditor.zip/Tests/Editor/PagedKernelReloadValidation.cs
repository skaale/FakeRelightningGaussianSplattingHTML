// SPDX-License-Identifier: MIT
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    /// <summary>Kernel ordinals may change on reimport without replacing the ComputeShader object.</summary>
    public static class PagedKernelReloadValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object value, string field) => (T)value.GetType().GetField(field, Flags).GetValue(value);
        static void Set(object value, string field, object data) => value.GetType().GetField(field, Flags).SetValue(value, data);
        static object Call(object value, string method, params object[] args) => value.GetType().GetMethod(method, Flags).Invoke(value, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static string Root => UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";

        static void Poison(SplatBoxRenderer renderer, ComputeShader shader)
        {
            // Both names identify valid current kernels. Old cached ordinals 30/31 selected
            // these unrelated kernels after pragmas were inserted earlier in BoxUtil.
            int wind = shader.FindKernel("CSUpdateWindPhysics");
            int original = shader.FindKernel("CSInitOriginalPositions");
            Set(renderer, "m_PagedEraseShader", shader);
            Set(renderer, "m_PagedEraseApplyKernel", wind);
            Set(renderer, "m_PagedEraseClearKernel", original);
            Set(renderer, "m_PagedColorShader", shader);
            Set(renderer, "m_PagedColorApplyKernel", original);
            Set(renderer, "m_PagedColorClearKernel", wind);
            var cache = Get<IDictionary>(renderer, "m_KernelIndices");
            Require(cache != null && cache.Count > 0, "Kernel cache was not primed.");
            var keys = new ArrayList(cache.Keys);
            foreach (object key in keys) cache[key] = shader.FindKernel("CSSetIndices");
        }

        static void RequireFreshResolution(SplatBoxRenderer renderer, ComputeShader shader, string path)
        {
            Require((bool)Call(renderer, "FindPagedLodEraseKernels") &&
                Get<int>(renderer, "m_PagedEraseApplyKernel") == shader.FindKernel("CSApplyPagedErase") &&
                Get<int>(renderer, "m_PagedEraseClearKernel") == shader.FindKernel("CSClearPagedErase"),
                "Same-object shader reload kept stale erase kernel ordinals (wind/init-position instead of erase/clear): " + path);
            Require((bool)Call(renderer, "FindPagedColorizeKernels") &&
                Get<int>(renderer, "m_PagedColorApplyKernel") == shader.FindKernel("CSApplyPagedColor") &&
                Get<int>(renderer, "m_PagedColorClearKernel") == shader.FindKernel("CSClearPagedColor"),
                "Same-object shader reload kept stale Colorize kernel ordinals: " + path);
            foreach (var pair in new[]
            {
                (SplatBoxRenderer.KernelIndices.CalcViewData, "CSCalcViewData"),
                (SplatBoxRenderer.KernelIndices.PaintSampleColors, "CSPaintSampleColors"),
                (SplatBoxRenderer.KernelIndices.CalcDistances, "CSCalcDistances")
            })
                Require((int)Call(renderer, "GetKernelIndex", pair.Item1) == shader.FindKernel(pair.Item2),
                    "Same-object shader reload kept stale " + pair.Item2 + " ordinal: " + path);
        }

        static Color Sample(SplatBoxRenderer renderer, Camera camera, Vector3 point, int expectedCount, float radius)
        {
            Vector3 pixel = camera.WorldToScreenPoint(point);
            float depth = Vector3.Dot(point - camera.transform.position, camera.transform.forward);
            var output = new Color[8];
            Require(renderer.SamplePaintColors(camera, new Vector2(pixel.x, pixel.y), radius, depth, .03f, output, out int count) &&
                count == expectedCount, "Kernel reload sample count: expected " + expectedCount + ", got " + count);
            for (int i = 1; i < count; ++i) Near(output[i], output[0], "Split page color after reload");
            return count > 0 ? output[0] : Color.clear;
        }
        static void Near(Color actual, Color expected, string context)
        {
            Require(Mathf.Abs(actual.r - expected.r) < .005f && Mathf.Abs(actual.g - expected.g) < .005f &&
                Mathf.Abs(actual.b - expected.b) < .005f && Mathf.Abs(actual.a - expected.a) < .005f,
                context + ": expected " + expected + ", got " + actual);
        }

        static void DirectReplay(string path)
        {
            var type = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
            object fixture = Activator.CreateInstance(type, Flags, null, new object[] { path, true }, null);
            try
            {
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer");
                var shader = Get<ComputeShader>(fixture, "shader");
                var camera = Get<Camera>(fixture, "camera");
                Vector3 painted = (Vector3)Call(fixture, "WorldPoint", 32);
                Vector3 erased = (Vector3)Call(fixture, "WorldPoint", 33);
                renderer.ColorizeInSphere(painted, .25f, Color.green, 1, 0);
                renderer.EditDeleteSphere(erased, .1f);
                Call(fixture, "ExpectBits", new object[] { new[] { 33 } });
                Near(Sample(renderer, camera, painted, 1, 2), new Color(0, 1, 0, .8f), "Initial color");
                Poison(renderer, shader);
                // Fail cleanly on the original bug before an invalid dispatch can corrupt buffers.
                RequireFreshResolution(renderer, shader, path);
                Poison(renderer, shader);
                Call(fixture, "RecreateAtlas");
                Call(fixture, "EnsureJournal");
                Call(renderer, "EnsurePagedColorizeState", new object[] { null });
                Call(fixture, "ExpectBits", new object[] { new[] { 33 } });
                Near(Sample(renderer, camera, painted, 1, 2), new Color(0, 1, 0, .8f), "Replayed color after stale cache");
                Sample(renderer, camera, erased, 0, 2);
                Call(fixture, "ExpectVisibility", new object[] { new[] { 32, 33, 34 }, new[] { false, true, false } });
                Require(ReferenceEquals(shader, Get<ComputeShader>(renderer, "m_CSBoxUtil")), "Test replaced the shader instead of recovering its cache.");
            }
            finally { ((IDisposable)fixture).Dispose(); }
        }

        static void Preload(SplatBoxRenderer renderer, Camera camera)
        {
            for (int i = 0; i < 10; ++i)
            {
                if (renderer.lodStreamer != null) Set(renderer.lodStreamer, "m_LastPageUploadFrame", -1);
                renderer.PreloadPagedLodPages(camera);
            }
        }

        static void EditorRecovery(string path)
        {
            var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
            object fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
            try
            {
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer");
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages"); Call(fixture, "CreateCamera");
                var camera = Get<Camera>(fixture, "camera");
                var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + path);
                Set(renderer, "m_CSBoxUtil", shader); Set(renderer, "m_LodAsyncTraversal", false);
                Require(renderer.ForceRebuildPagedLodInEditor(), "Could not initialize real page fixture.");
                Preload(renderer, camera);
                renderer.EditDeleteSphere(new Vector3(-.9f, 0, 5), .04f);
                renderer.ColorizeInSphere(new Vector3(.8f, 0, 5), .25f, Color.green, 1, 0);
                Near(Sample(renderer, camera, new Vector3(.8f, 0, 5), 2, 16), new Color(0, 1, 0, .8f), "Initial real page color");
                Near(Sample(renderer, camera, new Vector3(-.8f, 0, 5), 1, 16), new Color(.6f, .4f, .2f, .8f), "Initial real page erase");

                Poison(renderer, shader);
                foreach (var page in renderer.lodStreamer.loadedPages) page.uploadedAtlasOffset = -1;
                Require(Get<bool>(renderer, "m_HasLastLodView") && !renderer.lodStreamer.hasPendingCoarseLoads,
                    "Fixture did not reach the normal editor streaming path.");
                Set(renderer, "m_LodAtlasDirty", true);
                Set(renderer, "m_PagedEraseAppliedRevision", -1); Set(renderer, "m_PagedColorAppliedRevision", -1);
                camera.transform.position = new Vector3(.03f, 0, 0);
                Call(renderer, "EditorTickPagedLodStreaming"); Preload(renderer, camera);
                Near(Sample(renderer, camera, new Vector3(.8f, 0, 5), 2, 16), new Color(0, 1, 0, .8f), "Editor tick replayed wrong color kernel");
                Near(Sample(renderer, camera, new Vector3(-.8f, 0, 5), 1, 16), new Color(.6f, .4f, .2f, .8f), "Editor tick replayed wrong erase kernel");
                Call(fixture, "AssertVisible");

                Poison(renderer, shader);
                Require(renderer.ForceRebuildPagedLodInEditor(), "Force rebuild did not recover stale kernels.");
                Preload(renderer, camera); Call(renderer, "EditorTickPagedLodStreaming");
                Near(Sample(renderer, camera, new Vector3(.8f, 0, 5), 2, 16), new Color(0, 1, 0, .8f), "Force rebuild lost color journal");
                Near(Sample(renderer, camera, new Vector3(-.8f, 0, 5), 1, 16), new Color(.6f, .4f, .2f, .8f), "Force rebuild lost erase journal");
                Require(renderer.pagedLodEraseStrokeCount == 1 && renderer.pagedColorizeStrokeCount == 1,
                    "Kernel recovery changed serialized edit journals.");
                Require(ReferenceEquals(shader, Get<ComputeShader>(renderer, "m_CSBoxUtil")), "Recovery replaced the tested shader object.");
                Call(fixture, "AssertVisible");
            }
            finally { ((IDisposable)fixture).Dispose(); }
        }

        public static void Run()
        {
            Require(Application.isBatchMode && !Application.isPlaying && SystemInfo.supportsComputeShaders,
                "Use an isolated editor batch project with a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                { DirectReplay(path); EditorRecovery(path); }
                Require(errors.Count == 0, "Kernel reload logged GPU errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox paged kernel reload PASS: same-object stale erase/color/main ordinals recover before dispatch; page replay, camera/editor tick and force rebuild preserve edits on both shaders.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
