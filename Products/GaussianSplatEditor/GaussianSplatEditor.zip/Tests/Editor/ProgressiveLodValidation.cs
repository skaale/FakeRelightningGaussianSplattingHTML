// SPDX-License-Identifier: MIT

using System;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    // CPU-only: -executeMethod GaussianSplatting.Tests.ProgressiveLodValidation.RunAll -quit
    public static class ProgressiveLodValidation
    {
        public static void RunAll()
        {
            ValidateUnstartedState();
            ValidateTimedUpgrade();
            ValidateRestartAndBounds();
            Debug.Log("SplatBox progressive LoD PASS: actual coarse prefix, timed intermediate tiers, " +
                "completion, unchanged resident payload and independent upgrade restarts.");
        }

        static void ValidateUnstartedState()
        {
            using var state = State();
            Require(state.RefinementNodeLimit(-1000f) == state.lodNodeCount &&
                    state.RefinementNodeLimit(1000f) == state.lodNodeCount &&
                    !state.HasPendingRefinement(1000f),
                "Pages without a coarse-to-full upgrade must expose their complete tree");

            using var empty = new SplatBoxPageGpuState();
            empty.BeginRefinement(1, 10f);
            Require(empty.RefinementNodeLimit(10f) == 0 && !empty.HasPendingRefinement(10f),
                "An empty page started a visual refinement transition");
        }

        static void ValidateTimedUpgrade()
        {
            using var state = State();
            const int actualCoarseCount = 13;
            var prefix = new LodTreeNode[actualCoarseCount];
            Array.Copy(state.lodTreeNodes, prefix, prefix.Length);
            using var coarse = new SplatBoxPageGpuState
            {
                splatCount = actualCoarseCount,
                lodNodeCount = actualCoarseCount,
                lodTree = LodTreeRuntime.BuildPrefix(prefix),
                isCoarseStub = true
            };

            var tree = state.lodTree;
            var nodes = state.lodTreeNodes;
            var originalNodes = (LodTreeNode[])nodes.Clone();
            int fullCount = state.splatCount;
            int atlasOffset = state.atlasOffset;
            int uploadedAtlasOffset = state.uploadedAtlasOffset;
            float residencyStart = state.detailAcquiredTime;
            const float startTime = 20f;
            state.BeginRefinement(coarse.splatCount, startTime);

            Require(state.RefinementNodeLimit(startTime) == actualCoarseCount &&
                    state.RefinementNodeLimit(startTime - 1f) == actualCoarseCount,
                "Upgrade did not begin at the actual preceding coarse prefix");
            Require(state.HasPendingRefinement(startTime), "Upgrade was already complete at its first frame");
            int firstUpdate = state.RefinementNodeLimit(startTime + 0.08f);
            Require(firstUpdate >= actualCoarseCount && firstUpdate < fullCount,
                "One selection interval exposed the whole full-detail tree");

            int previous = actualCoarseCount;
            int distinctIntermediateTiers = 0;
            for (int step = 1; step < 12; ++step)
            {
                float now = startTime + SplatBoxPageGpuState.RefinementDurationSeconds * step / 12f;
                int limit = state.RefinementNodeLimit(now);
                Require(limit >= previous && limit < fullCount && state.HasPendingRefinement(now),
                    "Visual refinement regressed or completed before its deadline");
                Require(state.RefinementNodeLimit(now) == limit,
                    "Repeated queries at the same explicit time advanced visual refinement");
                if (limit > previous && limit > actualCoarseCount)
                    ++distinctIntermediateTiers;
                previous = limit;
            }
            Require(distinctIntermediateTiers >= 3, "Upgrade did not provide intermediate refinement tiers");
            float deadline = startTime + SplatBoxPageGpuState.RefinementDurationSeconds;
            Require(state.RefinementNodeLimit(deadline) == fullCount &&
                    state.RefinementNodeLimit(deadline + 100f) == fullCount &&
                    !state.HasPendingRefinement(deadline),
                "Visual refinement did not finish at its explicit deadline");

            Require(ReferenceEquals(state.lodTree, tree) && ReferenceEquals(state.lodTreeNodes, nodes) &&
                    state.splatCount == fullCount && state.lodNodeCount == fullCount && !state.isCoarseStub &&
                    state.atlasOffset == atlasOffset && state.uploadedAtlasOffset == uploadedAtlasOffset &&
                    state.detailSlot == 3 && state.detailAcquiredTime == residencyStart,
                "Visual refinement changed resident payload size, atlas residency or detail-slot hold time");
            for (int i = 0; i < nodes.Length; ++i)
            {
                Require(math.all(nodes[i].center == originalNodes[i].center) &&
                        nodes[i].featureSize == originalNodes[i].featureSize &&
                        nodes[i].childStart == originalNodes[i].childStart &&
                        nodes[i].childCount == originalNodes[i].childCount &&
                        nodes[i].flags == originalNodes[i].flags,
                    "Visual refinement mutated a node retained by an existing worker snapshot");
            }
        }

        static void ValidateRestartAndBounds()
        {
            using var state = State();
            state.BeginRefinement(5, 1f);
            Require(state.RefinementNodeLimit(2f) == state.lodNodeCount,
                "First upgrade did not complete before the re-upgrade fixture");
            state.BeginRefinement(21, 10f);
            Require(state.RefinementNodeLimit(10f) == 21 && state.HasPendingRefinement(10f) &&
                    state.RefinementNodeLimit(10.375f) > 21 &&
                    state.RefinementNodeLimit(10.75f) == state.lodNodeCount,
                "A re-upgrade reused its previous visual prefix or timestamp");

            state.BeginRefinement(0, 30f);
            Require(state.RefinementNodeLimit(30f) == 1 && state.HasPendingRefinement(30f),
                "A legacy or invalid starting prefix failed to retain the root");
            state.BeginRefinement(state.lodNodeCount + 100, 40f);
            Require(state.RefinementNodeLimit(40f) == state.lodNodeCount &&
                    !state.HasPendingRefinement(40f),
                "A page already covered by its starting prefix began an unnecessary transition");
        }

        static SplatBoxPageGpuState State()
        {
            // Four-ary, level-order tree: root + 4 + 16 merged nodes + 64 genuine leaves.
            var nodes = new LodTreeNode[85];
            for (int i = 0; i < nodes.Length; ++i)
            {
                nodes[i] = new LodTreeNode
                {
                    center = new float3(i * 0.01f, 0, 5),
                    featureSize = 1f,
                    childCount = i < 21 ? (ushort)4 : (ushort)0,
                    childStart = i < 21 ? (uint)(i * 4 + 1) : 0
                };
            }
            return new SplatBoxPageGpuState
            {
                splatCount = nodes.Length,
                lodNodeCount = nodes.Length,
                lodTree = LodTreeRuntime.Build(nodes, true),
                atlasOffset = 12000,
                uploadedAtlasOffset = 12000,
                detailSlot = 3,
                detailAcquiredTime = 7f
            };
        }

        static void Require(bool condition, string message)
        {
            if (!condition)
                throw new InvalidOperationException(message);
        }
    }
}
