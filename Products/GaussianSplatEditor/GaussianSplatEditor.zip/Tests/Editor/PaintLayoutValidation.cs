// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    public static class PaintLayoutValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Flags).SetValue(target, value);
        static void Layout(GaussianSplatEditorWindow window)
        {
            window.SendEvent(new Event { type = EventType.Layout });
            window.SendEvent(new Event { type = EventType.Repaint });
        }
        public static void Run()
        {
            if (!Application.isBatchMode) throw new InvalidOperationException("Run Paint layout validation in an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GaussianSplatEditorWindow window = null;
            Texture2D texture = null;
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) => {
                if (message.Contains("Invalid GUILayout state") || message.Contains("Getting control") ||
                    message.Contains("ImmediateModeException")) errors.Add(message);
            };
            Application.logMessageReceived += observe;
            try
            {
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); window.ShowUtility();
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.PaintBrush);
                Set(window, "m_ShowToolSettings", true);
                Layout(window);
                var brush = (GaussianSplatPaintBrush)window.GetType().GetField("m_PaintBrush", Flags).GetValue(window);
                if (brush == null) throw new InvalidOperationException("Paint did not initialize during Layout.");
                texture = new Texture2D(2,2) { hideFlags = HideFlags.HideAndDontSave };
                var slots = (Texture2D[])brush.GetType().GetField("m_TextureSlots", Flags).GetValue(brush);
                var changes = new Action[] {
                    () => brush.UseCustomColor = true,
                    () => brush.AddSampledColor(Color.green),
                    () => brush.UseCustomColor = false,
                    () => brush.UseTexturePaint = true,
                    () => slots[0] = texture,
                    () => brush.ActiveTextureSlot = 1,
                    () => brush.EnableLayering = false,
                    () => brush.UseGPUPaint = false,
                    () => brush.FastPaintMode = false,
                    () => Set(window, "m_IsCapturingRect", true),
                    () => Set(window, "m_PaintOutputStatus", "Saved a paint stroke. Save the scene to retain it."),
                    () => Set(window, "m_PaintBrushMode", 1),
                    () => Set(window, "m_PaintBrushMode", 0),
                };
                foreach (var change in changes)
                {
                    window.SendEvent(new Event { type = EventType.Layout });
                    change();
                    window.SendEvent(new Event { type = EventType.Repaint });
                    Layout(window);
                }
                if (errors.Count != 0) throw new InvalidOperationException("Paint layout regression: " + string.Join(" | ",errors));
                Debug.Log("SplatBox Paint layout PASS: cold initialization, sampled/custom/texture states, performance/layer controls, mode changes and save status between events.");
            }
            finally
            {
                if (window != null) window.Close();
                if (texture != null) Object.DestroyImmediate(texture);
                Application.logMessageReceived -= observe;
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            }
        }
    }
}
