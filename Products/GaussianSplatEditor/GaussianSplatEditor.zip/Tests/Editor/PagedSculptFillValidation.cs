// SPDX-License-Identifier: MIT
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    /// <summary>Sculpt-aware Fill picking, edge samples, replacement membership and saved output.</summary>
    public static class PagedSculptFillValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Flags).GetValue(target);
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Flags).SetValue(target, value);
        static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Flags).Invoke(target, args);
        static object Static(Type type, string method, params object[] args) => type.GetMethod(method, BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(Vector3 value, Vector3 expected, string message, float tolerance = .003f) =>
            Require(Vector3.Distance(value, expected) < tolerance, message + ": got " + value + ", expected " + expected);
        static void Near(float value, float expected, string message, float tolerance = .003f) =>
            Require(Mathf.Abs(value - expected) < tolerance, message + ": got " + value + ", expected " + expected);
        static Vector3[] Square(Vector3 center, float half = .2f) => new[] {
            center + new Vector3(-half, -half, 0), center + new Vector3(half, -half, 0),
            center + new Vector3(half, half, 0), center + new Vector3(-half, half, 0) };
        static void Polygon(GaussianSplatFillBrush brush, Vector3 center)
        {
            var points = Square(center); brush.Clear(); brush.StartDrawing(points[0], Vector3.forward);
            for (int i = 1; i < points.Length; i++) brush.AddVertex(points[i]); brush.ClosePolygon();
        }
        static void Preload(SplatBoxRenderer source, Camera camera) => Static(typeof(PagedSmudgeValidation), "Preload", source, camera);
        static Splat[] Samples(SplatBoxRenderer source, Vector3 center) =>
            (Splat[])Static(typeof(PagedFillValidation), "Samples", source, Square(center), .2f);
        static Splat[] Read(SplatBoxRenderer source) => (Splat[])Static(typeof(PaintEditorValidation), "Read", source);
        static string Fingerprint(GaussianSplatAsset asset) => (string)Static(typeof(PagedSculptStampValidation), "Fingerprint", asset);
        static void Independent(SplatBoxRenderer output)
        {
            Require(!output.UsesPagedLod && output.pagedScene == null, "Fill retained source paged scene");
            foreach (string field in new[] { "m_PagedEraseStrokes", "m_PagedColorizeStrokes", "m_PagedSmudgeDabs", "m_PagedEditSculptHistory" })
                Require(Get<IList>(output, field).Count == 0, "Fill inherited " + field);
            foreach (string field in new[] { "m_PagedEraseScene", "m_PagedColorizeScene", "m_PagedSmudgeScene" })
                Require(Get<Object>(output, field) == null, "Fill inherited " + field);
        }
        static void SetShader(SplatBoxRenderer source, string path)
        {
            string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
            Set(source, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(root + "/" + path)); Call(source, "InitializeKernels");
        }
        static void FreshPick(string shader)
        {
            object fixture = null; GaussianSplatEditorWindow window = null; SceneView view = null; GameObject holder = null, collider = null;
            Action<SceneView> callback = null;
            try
            {
                var type = typeof(PagedSmudgeValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { shader }, null);
                var source = Get<SplatBoxRenderer>(fixture, "renderer");
                Call(fixture, "Positions", new object[] { new[] { new Vector3(3, 3, 9), new Vector3(0, 0, 3), new Vector3(1, 0, 7) } });
                Call(fixture, "Select", new uint[] { 33, 34 }, new uint[] { 0, 1 });
                holder = new GameObject("Fill sculpt picking brush"); holder.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatFillBrush>(); brush.TargetRenderer = source;
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window, "m_TargetRenderer", source); Set(window, "m_FillBrush", brush);
                view = ScriptableObject.CreateInstance<SceneView>(); view.position = new Rect(100, 100, 640, 480); view.ShowUtility();
                view.LookAtDirect(new Vector3(0, 0, 5), Quaternion.identity, 3);
                Vector2 cursor = Vector2.zero; bool prepared = false; int clicks = 0; Exception failure = null;
                callback = current =>
                {
                    if (current != view || failure != null) return;
                    try
                    {
                        if (!prepared && Event.current.type == EventType.Repaint)
                        {
                            prepared = true; cursor = HandleUtility.WorldToGUIPoint(new Vector3(0, 0, 3));
                            Ray ray = view.camera.ScreenPointToRay(view.camera.WorldToScreenPoint(new Vector3(0, 0, 3)));
                            Near((Vector3)Call(window, "GetFillHitPoint", ray, view, true), new Vector3(0, 0, 3), "Initial Fill surface");
                            source.SmudgeSplatsGPU(new Vector3(0, 0, 3), Vector3.forward * 2, .1f, 0, 1);
                            Set(window, "m_NextFillDepthSampleTime", EditorApplication.timeSinceStartup + 100);
                            Near((Vector3)Call(window, "GetFillHitPoint", ray, view, false), new Vector3(0, 0, 5), "Fill preview reused pre-sculpt depth");
                            Ray other = view.camera.ScreenPointToRay(view.camera.WorldToScreenPoint(new Vector3(1, 0, 7)));
                            Near((Vector3)Call(window, "GetFillHitPoint", other, view, true), new Vector3(1, 0, 7), "Fill click reused another cursor depth");
                            collider = new GameObject("Stale source collision"); collider.transform.position = new Vector3(0, 0, 3);
                            collider.AddComponent<BoxCollider>().size = new Vector3(.5f, .5f, .02f); Physics.SyncTransforms();
                            Require(Physics.Raycast(ray, out _, 100), "Stale collision fixture did not intersect source ray");
                            Set(window, "m_NextFillDepthSampleTime", EditorApplication.timeSinceStartup + 100);
                        }
                        else if (prepared && Event.current.type == EventType.MouseDown)
                        {
                            Call(window, "HandleFillBrushScene", view, Event.current); clicks++;
                            Require(brush.Vertices.Count == clicks, "Fill click did not add exactly one vertex");
                            Near(brush.Vertices[clicks - 1].z, 5, "Fill vertex followed stale collision or later source sculpt");
                            if (clicks == 1) source.SmudgeSplatsGPU(new Vector3(0, 0, 5), Vector3.forward * 2, .1f, 0, 1);
                        }
                    }
                    catch (Exception exception) { failure = exception; }
                };
                SceneView.duringSceneGui += callback;
                view.SendEvent(new Event { type = EventType.Layout }); view.SendEvent(new Event { type = EventType.Repaint });
                view.SendEvent(new Event { type = EventType.MouseEnterWindow, mousePosition = cursor });
                view.SendEvent(new Event { type = EventType.MouseDown, button = 0, mousePosition = cursor });
                view.SendEvent(new Event { type = EventType.MouseUp, button = 0, mousePosition = cursor });
                view.SendEvent(new Event { type = EventType.MouseDown, button = 0, mousePosition = cursor + Vector2.right * 32 });
                view.SendEvent(new Event { type = EventType.MouseUp, button = 0, mousePosition = cursor + Vector2.right * 32 });
                if (failure != null) throw failure;
                Require(prepared && clicks == 2, "Fill did not route the actual Scene GUI vertex clicks");
                Object.DestroyImmediate(collider); collider = null; brush.Clear();
                PackedPickAndSamples(fixture, window, view);
            }
            finally
            {
                if (callback != null) SceneView.duringSceneGui -= callback;
                if (view != null) view.Close(); if (window != null) Object.DestroyImmediate(window);
                if (holder != null) Object.DestroyImmediate(holder); if (collider != null) Object.DestroyImmediate(collider);
                (fixture as IDisposable)?.Dispose();
            }
        }
        static uint Pack(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static void PackedPickAndSamples(object fixture, GaussianSplatEditorWindow window, SceneView view)
        {
            var source = Get<SplatBoxRenderer>(fixture, "renderer"); var inner = Get<object>(fixture, "inner");
            source.ResetPagedSculpt(); source.ResetDeletedSplats();
            var asset = Get<GaussianSplatAsset>(inner, "asset");
            asset.Initialize(128, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
            var payload = Get<TextAsset>(inner, "data"); asset.SetAssetFiles(payload, payload, payload, payload, payload);
            var positions = new uint[128]; var others = new uint[256];
            for (int i = 0; i < 128; i++)
            { positions[i] = Pack(Vector3.one * .9f); others[i * 2] = 0xE0080200u; others[i * 2 + 1] = Pack(Vector3.one * .5f); }
            positions[33] = Pack(new Vector3(.5f, .5f, .3f));
            Get<GraphicsBuffer>(inner, "pos").SetData(positions); Get<GraphicsBuffer>(inner, "other").SetData(others);
            var chunk = new GaussianSplatAsset.ChunkInfo { posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                colR = HalfRange(0, 1), colG = HalfRange(0, 1), colB = HalfRange(0, 1), colA = HalfRange(.5f, .9f),
                sclX = HalfRange(.1f, .2f), sclY = HalfRange(.1f, .2f), sclZ = HalfRange(.1f, .2f) };
            Get<GraphicsBuffer>(inner, "chunks").SetData(new[] { chunk }); Set(source, "m_GpuChunksValid", true);
            Set(source, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(inner, "chunks")); Set(source, "m_LodUnifiedChunkCount", 1);
            try
            {
                Vector3 point = new Vector3(Mathf.Round(.5f * 2047) / 2047 * 20 - 10,
                    Mathf.Round(.5f * 1023) / 1023 * 20 - 10, Mathf.Round(.3f * 2047) / 2047 * 10);
                source.SmudgeSplatsGPU(point, new Vector3(0, 1, 1), .1f, 0, 1); point += new Vector3(0, 1, 1);
                Call(fixture, "Select", new uint[] { 33 }, new uint[] { 0 });
                var ray = view.camera.ScreenPointToRay(view.camera.WorldToScreenPoint(point));
                Near((Vector3)Call(window, "GetFillHitPoint", ray, view, true), point, "Packed sculpted Fill pick");
                source.BeginPagedColorizeStroke(); source.ColorizeInSphere(point, .1f, Color.cyan, 1, 0); source.EndPagedColorizeStroke();
                var data = Samples(source, point + Vector3.right * .1f); Require(data.Length == 1, "Packed Fill did not export sculpted sample");
                Near(data[0].pos, point, "Packed Fill exported old position"); Near(GaussianUtils.SH0ToColor(data[0].dc0), Vector3.up + Vector3.forward, "Packed Fill lost Colorize");
            }
            finally { Set(source, "m_GpuLodUnifiedChunks", null); }
        }

        static void ExpectDeletedMiddle(SplatBoxRenderer source, bool deleted)
        {
            Call(source, "EnsurePagedLodEraseState", new object[] { null });
            var buffer = Get<GraphicsBuffer>(source, "m_GpuPagedLodDeletedBits");
            var words = buffer == null ? new uint[0] : new uint[buffer.count]; if (buffer != null) buffer.GetData(words);
            foreach (var page in source.lodStreamer.loadedPages)
                for (int i = 0; i < page.splatCount; i++)
                {
                    int index = page.atlasOffset + i;
                    bool erased = words.Length > 0 && (words[index / 32] & (1u << (index & 31))) != 0;
                    Require(erased == (deleted && page.pageId == 1), "Fill replacement changed the wrong source identity");
                }
        }
        static void SavedFill(string shader)
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GaussianSplatEditorWindow window = null; RenderTexture target = null; string folder = null;
            string scenePath = "Assets/__SculptFill_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = Get<SplatBoxRenderer>(fixture, "renderer"); source.name = "Sculpt Fill source";
                var camera = new GameObject("Sculpt Fill camera").AddComponent<Camera>(); camera.tag = "MainCamera";
                target = new RenderTexture(640, 480, 0); target.Create(); camera.targetTexture = target;
                Preload(source, camera); SetShader(source, shader);
                var sourceBytes = new List<string>(); foreach (var entry in source.pagedScene.pages) sourceBytes.Add(Fingerprint(entry.pageAsset.splatData));
                Vector3 center = new Vector3(0, .8f, 4);
                source.SmudgeSplatsGPU(new Vector3(0, 0, 5), new Vector3(0, .8f, -1), .3f, 0, 1);
                source.BeginPagedColorizeStroke(); source.ColorizeInSphere(center + Vector3.left * .1f, .04f, Color.red, 1, 0);
                source.ColorizeInSphere(center + Vector3.right * .1f, .04f, Color.blue, 1, 0); source.EndPagedColorizeStroke();
                Require(Samples(source, new Vector3(0, 0, 5)).Length == 0, "Fill sampled pre-sculpt geometry");
                var samples = Samples(source, center); Require(samples.Length == 2, "Fill lost sculpted edge leaves");
                foreach (var sample in samples)
                {
                    Near(sample.pos.y, center.y, "Fill edge old height"); Near(sample.pos.z, center.z, "Fill edge old depth");
                    Near(GaussianUtils.SH0ToColor(sample.dc0), sample.pos.x < 0 ? Vector3.right : Vector3.forward, "Fill edge Colorize");
                    Near(GaussianUtils.Sigmoid(sample.opacity), .8f, "Fill edge alpha");
                }
                var cutoutOwner = new GameObject("Sculpt Fill sampling cutout"); var cutout = cutoutOwner.AddComponent<GaussianCutout>();
                cutout.transform.position = center + Vector3.left * .1f; cutout.transform.localScale = Vector3.one * .03f; source.m_Cutouts = new[] { cutout };
                Require(Samples(source, center).Length == 1, "Fill ignored sculpted cutout location");
                source.m_Cutouts = Array.Empty<GaussianCutout>(); Object.DestroyImmediate(cutoutOwner);
                var holder = new GameObject("Sculpt Fill brush"); holder.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatFillBrush>(); brush.TargetRenderer = source;
                brush.SelectionDepth = .2f; brush.EdgeSampleWidth = .2f; brush.PositionJitter = 0; brush.FillDensity = 1; brush.DeleteBeforeFill = true;
                Polygon(brush, center); window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
                Set(window, "m_TargetRenderer", source); Set(window, "m_FillBrush", brush);
                Undo.FlushUndoRecordObjects(); Undo.ClearAll(); Call(window, "ExecuteFillInEditor", camera, false);
                var fill = GameObject.Find(source.name + " Fill")?.GetComponentInChildren<SplatBoxRenderer>();
                Require(fill != null, "Fill output missing: " + Get<string>(window, "m_PagedFillStatus"));
                string name = fill.transform.parent.name; folder = Path.GetDirectoryName(AssetDatabase.GetAssetPath(fill.m_Asset)).Replace('\\', '/');
                Independent(fill); ExpectDeletedMiddle(source, true);
                var initial = Read(fill); Require(initial.Length > 0, "Saved Fill empty"); int red = 0, blue = 0;
                foreach (var sample in initial)
                {
                    Require(Mathf.Abs(sample.pos.x) < .201f && Mathf.Abs(sample.pos.y - center.y) < .201f && Mathf.Abs(sample.pos.z - center.z) < .101f, "Fill escaped sculpted polygon");
                    Vector3 rgb = GaussianUtils.SH0ToColor(sample.dc0);
                    if (Vector3.Distance(rgb, Vector3.right) < .008f) red++; else if (Vector3.Distance(rgb, Vector3.forward) < .008f) blue++;
                    else throw new InvalidOperationException("Fill generated a color absent from sculpted edges: " + rgb);
                    Near(GaussianUtils.Sigmoid(sample.opacity), .8f, "Fill output alpha");
                }
                Require(red > 0 && blue > 0, "Fill lost local edge color distribution");
                string savedBytes = Fingerprint(fill.m_Asset);
                Action check = () =>
                {
                    fill = GameObject.Find(name)?.GetComponentInChildren<SplatBoxRenderer>(); Require(fill != null, "Saved Fill object lost"); Independent(fill);
                    Require(Fingerprint(fill.m_Asset) == savedBytes, "Saved Fill asset changed"); var actual = Read(fill);
                    Require(actual.Length == initial.Length, "Saved Fill splat count changed");
                    for (int i = 0; i < actual.Length; i++)
                    { Near(actual[i].pos, initial[i].pos, "Saved Fill GPU positions"); Near(actual[i].dc0, initial[i].dc0, "Saved Fill GPU colors"); Near(actual[i].opacity, initial[i].opacity, "Saved Fill GPU alpha"); }
                };
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Require(GameObject.Find(name) == null, "Fill Undo retained output");
                Preload(source, camera); ExpectDeletedMiddle(source, false);
                Undo.PerformRedo(); Preload(source, camera); ExpectDeletedMiddle(source, true); check();
                // Move an unrelated page into the original fill volume. Historical deletion
                // must stay with its original source identities when the atlas is reconstructed.
                source.SmudgeSplatsGPU(new Vector3(-.8f, 0, 5), new Vector3(.8f, .8f, -1), .3f, 0, 1);
                Preload(source, camera); ExpectDeletedMiddle(source, true); check();
                Require(Samples(source, center).Length == 2, "Fill deletion incorrectly captured geometry sculpted into its old volume");
                source.ResetPagedSculpt(); Preload(source, camera); ExpectDeletedMiddle(source, true); check();
                var oldBuffers = new List<GraphicsBuffer>(); foreach (var page in source.lodStreamer.loadedPages) oldBuffers.Add(page.gpuPosData);
                source.lodStreamer.UnloadAll(); foreach (var buffer in oldBuffers) Require(!buffer.IsValid(), "Fill unload retained source GPU buffer");
                Preload(source, camera); ExpectDeletedMiddle(source, true); check();
                AssetDatabase.SaveAssets(); Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save Fill scene");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                source = GameObject.Find("Sculpt Fill source").GetComponent<SplatBoxRenderer>(); camera = GameObject.Find("Sculpt Fill camera").GetComponent<Camera>();
                camera.targetTexture = target; Preload(source, camera); ExpectDeletedMiddle(source, true); check();
                for (int i = 0; i < sourceBytes.Count; i++) Require(Fingerprint(source.pagedScene.pages[i].pageAsset.splatData) == sourceBytes[i], "Fill changed source bytes");
                Set(window, "m_TargetRenderer", source); Undo.ClearAll(); Call(window, "ResetAllSplatEdits");
                Require(GameObject.Find(name) == null, "Reset All retained saved Fill"); Preload(source, camera); ExpectDeletedMiddle(source, false);
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Preload(source, camera); ExpectDeletedMiddle(source, true); check();
                Undo.PerformRedo(); Require(GameObject.Find(name) == null, "Redo Reset All retained Fill");
            }
            finally
            {
                if (window != null) Object.DestroyImmediate(window); EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                (fixture as IDisposable)?.Dispose(); if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                if (folder != null) AssetDatabase.DeleteAsset(folder); AssetDatabase.DeleteAsset(scenePath);
            }
        }
        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use an isolated batch project with graphics device");
            var errors = new List<string>(); Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" }) { FreshPick(shader); SavedFill(shader); }
                Require(errors.Count == 0, "Sculpt Fill logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Paged Sculpt Fill PASS: fresh sculpted picks over stale colliders, planar clicks, packed edges/current colors, persistent replacement identities after later sculpt, independent saved GPU data, unload/reload, scene reopen, Undo/Redo and Reset All on both shaders.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
