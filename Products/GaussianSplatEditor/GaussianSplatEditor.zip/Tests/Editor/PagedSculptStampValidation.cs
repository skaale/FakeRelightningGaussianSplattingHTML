// SPDX-License-Identifier: MIT
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    /// <summary>Stamp targets the current sculpted surface and saves independent output geometry.</summary>
    public static class PagedSculptStampValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Flags).GetValue(target);
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Flags).SetValue(target, value);
        static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Flags).Invoke(target, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(float value, float expected, string message, float tolerance = .003f) =>
            Require(Mathf.Abs(value - expected) < tolerance, message + ": got " + value + ", expected " + expected);
        static void Near(Vector3 value, Vector3 expected, string message, float tolerance = .003f) =>
            Require(Vector3.Distance(value, expected) < tolerance, message + ": got " + value + ", expected " + expected);
        static Splat[] Read(SplatBoxRenderer renderer) => (Splat[])typeof(PaintEditorValidation)
            .GetMethod("Read", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer });
        static void Preload(SplatBoxRenderer renderer, Camera camera) => typeof(PagedSmudgeValidation)
            .GetMethod("Preload", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer, camera });
        static string Fingerprint(GaussianSplatAsset asset) => Convert.ToBase64String(asset.posData.bytes) +
            Convert.ToBase64String(asset.otherData.bytes) + Convert.ToBase64String(asset.colorData.bytes) + Convert.ToBase64String(asset.shData.bytes);
        static void SetShader(SplatBoxRenderer renderer, string shader)
        {
            string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
            Set(renderer, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(root + "/" + shader));
            Call(renderer, "InitializeKernels");
        }
        static Vector3 Pick(GaussianSplatEditorWindow window, Camera camera, Vector3 point)
        {
            var ray = camera.ScreenPointToRay(camera.WorldToScreenPoint(point));
            var hit = (Vector3?)Call(window, "GetStampSurfacePosition", ray, camera, 5f);
            Require(hit.HasValue, "Stamp could not pick the resident sculpted surface"); return hit.Value;
        }
        static void FreshPickAndLockedPlane(string shader)
        {
            object fixture = null; GaussianSplatEditorWindow window = null; SceneView sceneView = null;
            GameObject brushOwner = null; Action<SceneView> callback = null;
            try
            {
                var type = typeof(PagedSmudgeValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { shader }, null);
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer"); var camera = Get<Camera>(fixture, "camera");
                Call(fixture, "Positions", new object[] { new[] { new Vector3(3, 3, 9), new Vector3(0, 0, 3), new Vector3(1, 0, 7) } });
                Call(fixture, "Select", new uint[] { 33, 34 }, new uint[] { 0, 1 });
                brushOwner = new GameObject("Stamp picking validation brush"); brushOwner.SetActive(false);
                var brush = brushOwner.AddComponent<GaussianSplatPaintBrush>(); brush.TargetRenderer = renderer;
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
                Set(window, "m_TargetRenderer", renderer); Set(window, "m_PaintBrush", brush);
                Near(Pick(window, camera, new Vector3(0, 0, 3)).z, 3, "Initial Stamp depth");
                Set(brush, "m_LastSurfaceUpdateTime", Time.realtimeSinceStartup + 100);
                renderer.SmudgeSplatsGPU(new Vector3(0, 0, 3), Vector3.forward * 2, .1f, 0, 1);
                Near(Pick(window, camera, new Vector3(0, 0, 5)).z, 5, "Stamp reused cached depth immediately after sculpt");
                Set(brush, "m_LastSurfaceUpdateTime", Time.realtimeSinceStartup + 100);
                Near(Pick(window, camera, new Vector3(1, 0, 7)).z, 7, "Stamp reused another pixel's cached depth");
                renderer.EditDeleteSphere(new Vector3(1, 0, 7), .1f);
                // The narrow hit must win over a nearer surface elsewhere in the broad search.
                renderer.EditRestoreSphere(new Vector3(1, 0, 7), .1f);
                Near(Pick(window, camera, new Vector3(1, 0, 7)).z, 7, "Stamp broad fallback replaced a precise hit");

                var texture = new Texture2D(2, 2); texture.SetPixels(new[] { Color.red, Color.green, Color.blue, Color.white }); texture.Apply();
                brush.LoadTextureToSlot(texture, 0); Object.DestroyImmediate(texture);
                sceneView = ScriptableObject.CreateInstance<SceneView>(); sceneView.position = new Rect(100, 100, 640, 480);
                sceneView.ShowUtility(); sceneView.LookAtDirect(new Vector3(0, 0, 5), Quaternion.identity, 3);
                Vector2 cursor = Vector2.zero; bool prepared = false, down = false, dragged = false, cancelled = false;
                Exception failure = null;
                callback = view =>
                {
                    if (view != sceneView || failure != null) return;
                    try
                    {
                        if (!prepared && Event.current.type == EventType.Repaint)
                        {
                            prepared = true; cursor = HandleUtility.WorldToGUIPoint(new Vector3(0, 0, 5));
                            Pick(window, view.camera, new Vector3(0, 0, 5));
                            renderer.SmudgeSplatsGPU(new Vector3(0, 0, 5), Vector3.forward, .1f, 0, 1);
                            Set(brush, "m_LastSurfaceUpdateTime", Time.realtimeSinceStartup + 100);
                        }
                        else if (prepared && Event.current.type == EventType.MouseDown)
                        {
                            Call(window, "HandleTextureStampScene", view, Event.current); down = true;
                            Require(Get<bool>(window, "m_IsDraggingStamp"), "MouseDown did not begin Stamp");
                            Near(Get<Vector3>(window, "m_StampStartWorld").z, 6, "MouseDown did not force a fresh sculpted depth");
                            renderer.SmudgeSplatsGPU(new Vector3(0, 0, 6), Vector3.forward, .1f, 0, 1);
                        }
                        else if (down && Event.current.type == EventType.MouseDrag)
                        {
                            Call(window, "HandleTextureStampScene", view, Event.current); dragged = true;
                            Near(Get<Vector3>(window, "m_StampEndWorld").z, 6, "Stamp drag changed its locked plane after source sculpt");
                        }
                        else if (dragged && Event.current.type == EventType.KeyDown)
                        {
                            Call(window, "HandleTextureStampScene", view, Event.current); cancelled = true;
                            Require(!Get<bool>(window, "m_IsDraggingStamp"), "Escape did not cancel Stamp");
                        }
                    }
                    catch (Exception exception) { failure = exception; }
                };
                SceneView.duringSceneGui += callback;
                sceneView.SendEvent(new Event { type = EventType.Layout }); sceneView.SendEvent(new Event { type = EventType.Repaint });
                sceneView.SendEvent(new Event { type = EventType.MouseEnterWindow, mousePosition = cursor });
                sceneView.SendEvent(new Event { type = EventType.MouseDown, button = 0, mousePosition = cursor });
                sceneView.SendEvent(new Event { type = EventType.MouseDrag, button = 0, mousePosition = cursor + new Vector2(24, -24) });
                sceneView.SendEvent(new Event { type = EventType.KeyDown, keyCode = KeyCode.Escape });
                if (failure != null) throw failure;
                Require(prepared && down && dragged && cancelled, "Stamp input fixture did not route all real Scene GUI events");
                Action arm = () =>
                {
                    Set(window, "m_IsDraggingStamp", true); Set(window, "m_StampDragSource", renderer);
                    Set(window, "m_StampDragCamera", sceneView.camera);
                    Set(window, "m_StampDragView", sceneView.camera.worldToCameraMatrix);
                    Set(window, "m_StampDragProjection", sceneView.camera.projectionMatrix);
                    Set(window, "m_StampDragSourceMatrix", renderer.transform.localToWorldMatrix);
                };
                Action<Event> expectCancel = input =>
                {
                    Call(window, "HandleTextureStampScene", sceneView, input);
                    Require(!Get<bool>(window, "m_IsDraggingStamp") && Get<Object>(window, "m_StampDragSource") == null &&
                        Get<Object>(window, "m_StampDragCamera") == null, "Stamp retained stale drag after " + input.type);
                };
                foreach (EventType kind in new[] { EventType.MouseLeaveWindow, EventType.Ignore, EventType.MouseMove })
                { arm(); expectCancel(new Event { type = kind }); }
                arm(); expectCancel(new Event { type = EventType.MouseDrag, button = 0, modifiers = EventModifiers.Alt });
                arm(); Set(window, "m_TargetRenderer", null); expectCancel(new Event { type = EventType.Repaint }); Set(window, "m_TargetRenderer", renderer);
                arm(); Vector3 cameraPosition = sceneView.camera.transform.position;
                sceneView.camera.transform.position += Vector3.right; expectCancel(new Event { type = EventType.Repaint });
                sceneView.camera.transform.position = cameraPosition;
                arm(); float fieldOfView = sceneView.camera.fieldOfView; sceneView.camera.fieldOfView += 1;
                expectCancel(new Event { type = EventType.Repaint }); sceneView.camera.fieldOfView = fieldOfView;
                arm(); renderer.transform.position += Vector3.right; expectCancel(new Event { type = EventType.Repaint }); renderer.transform.position -= Vector3.right;
                PackedPick(fixture, window, camera);
            }
            finally
            {
                if (callback != null) SceneView.duringSceneGui -= callback;
                if (sceneView != null) sceneView.Close(); if (window != null) Object.DestroyImmediate(window);
                if (brushOwner != null) Object.DestroyImmediate(brushOwner); (fixture as IDisposable)?.Dispose();
            }
        }

        static uint Pack(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static void PackedPick(object fixture, GaussianSplatEditorWindow window, Camera camera)
        {
            var renderer = Get<SplatBoxRenderer>(fixture, "renderer"); var inner = Get<object>(fixture, "inner");
            renderer.ResetPagedSculpt(); renderer.ResetDeletedSplats();
            var asset = Get<GaussianSplatAsset>(inner, "asset");
            asset.Initialize(128, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
            var payload = Get<TextAsset>(inner, "data"); asset.SetAssetFiles(payload, payload, payload, payload, payload);
            var positions = new uint[128]; var others = new uint[256];
            for (int i = 0; i < 128; i++)
            { positions[i] = Pack(Vector3.one * .9f); others[i * 2] = 0xE0080200u; others[i * 2 + 1] = Pack(Vector3.one * .5f); }
            positions[33] = Pack(new Vector3(.5f, .5f, .3f));
            Get<GraphicsBuffer>(inner, "pos").SetData(positions); Get<GraphicsBuffer>(inner, "other").SetData(others);
            var chunk = new GaussianSplatAsset.ChunkInfo { posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                colR = HalfRange(0, 1), colG = HalfRange(0, 1), colB = HalfRange(0, 1), colA = HalfRange(.5f, .9f),
                sclX = HalfRange(.1f, .2f), sclY = HalfRange(.1f, .2f), sclZ = HalfRange(.1f, .2f) };
            Get<GraphicsBuffer>(inner, "chunks").SetData(new[] { chunk }); Set(renderer, "m_GpuChunksValid", true);
            Set(renderer, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(inner, "chunks")); Set(renderer, "m_LodUnifiedChunkCount", 1);
            try
            {
                Vector3 point = new Vector3(Mathf.Round(.5f * 2047) / 2047 * 20 - 10,
                    Mathf.Round(.5f * 1023) / 1023 * 20 - 10, Mathf.Round(.3f * 2047) / 2047 * 10);
                Call(fixture, "Select", new uint[] { 33 }, new uint[] { 0 });
                Near(Pick(window, camera, point), point, "Packed Stamp source pick");
                renderer.SmudgeSplatsGPU(point, new Vector3(0, 1, 1), .1f, 0, 1);
                Near(Pick(window, camera, point + new Vector3(0, 1, 1)), point + new Vector3(0, 1, 1), "Packed sculpted Stamp pick");
            }
            finally { Set(renderer, "m_GpuLodUnifiedChunks", null); }
        }

        static void AssertIndependent(SplatBoxRenderer renderer)
        {
            Require(!renderer.UsesPagedLod && renderer.pagedScene == null, "Stamp remained attached to the source page hierarchy");
            foreach (string field in new[] { "m_PagedEraseStrokes", "m_PagedColorizeStrokes", "m_PagedSmudgeDabs", "m_PagedEditSculptHistory" })
                Require(Get<IList>(renderer, field).Count == 0, "Stamp inherited source history " + field);
            foreach (string field in new[] { "m_PagedEraseScene", "m_PagedColorizeScene", "m_PagedSmudgeScene" })
                Require(Get<Object>(renderer, field) == null, "Stamp inherited source scene " + field);
        }
        static bool SampleGrid(object grid, Vector2 uv, out Color color)
        {
            object[] args = { uv.x, uv.y, Color.clear }; bool result = (bool)Call(grid, "TrySample", args); color = (Color)args[2]; return result;
        }
        static void SavedStamp(string shader)
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GaussianSplatEditorWindow window = null; RenderTexture target = null; Texture2D texture = null;
            string scenePath = "Assets/__SculptStamp_" + Guid.NewGuid().ToString("N") + ".unity";
            var folders = new HashSet<string>();
            try
            {
                var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = Get<SplatBoxRenderer>(fixture, "renderer"); source.name = "Sculpt Stamp source";
                var camera = new GameObject("Sculpt Stamp camera").AddComponent<Camera>(); camera.tag = "MainCamera";
                target = new RenderTexture(640, 480, 0); target.Create(); camera.targetTexture = target;
                Preload(source, camera); SetShader(source, shader);
                var sourceBytes = new List<string>();
                foreach (var entry in source.pagedScene.pages) sourceBytes.Add(Fingerprint(entry.pageAsset.splatData));
                source.SmudgeSplatsGPU(new Vector3(0, 0, 5), new Vector3(0, .5f, -1), .3f, 0, 1);
                Color tint = new Color(.2f, .8f, .4f, 1);
                source.BeginPagedColorizeStroke(); source.ColorizeInSphere(new Vector3(0, .5f, 4), .3f, tint, 1, 0); source.EndPagedColorizeStroke();
                source.EditDeleteSphere(new Vector3(-.1f, .5f, 4), .04f);
                var brushOwner = new GameObject("Sculpt Stamp brush"); brushOwner.SetActive(false);
                var brush = brushOwner.AddComponent<GaussianSplatPaintBrush>(); brush.TargetRenderer = source;
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window, "m_TargetRenderer", source); Set(window, "m_PaintBrush", brush);
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.TextureStamp);
                Set(window, "m_StampResolution", 8); Set(window, "m_StampDensity", .5f); Set(window, "m_StampAutoSize", false);
                Set(window, "m_StampManualSize", .025f); Set(window, "m_StampLayeringEnabled", true);
                Set(window, "m_StampLayerSpacing", .1f); Set(window, "m_StampCurrentLayer", 2);
                var colors = new[] { new Color(.1f, .2f, .3f, .2f), new Color(.4f, .5f, .6f, .4f),
                    new Color(.7f, .8f, .2f, .6f), new Color(.9f, .3f, .8f, .8f) };
                texture = new Texture2D(2, 2, TextureFormat.RGBAFloat, false, true); texture.SetPixels(colors); texture.Apply();
                brush.LoadTextureToSlot(texture, 0);
                Call(window, "ExecuteTextureStamp", new Vector3(.2f, .7f, 4), new Vector3(-.2f, .3f, 4), camera, texture);
                var stamp = GameObject.Find(source.name + " Stamp")?.GetComponentInChildren<SplatBoxRenderer>();
                Require(stamp != null, "Stamp output missing: " + Get<string>(window, "m_StampStatus"));
                string firstName = stamp.transform.parent.name;
                folders.Add(Path.GetDirectoryName(AssetDatabase.GetAssetPath(stamp.m_Asset)).Replace('\\', '/'));
                Require(stamp.splatCount == 64, "Stamp grid lost splats"); AssertIndependent(stamp);
                foreach (var splat in Read(stamp))
                {
                    int quadrant = (splat.pos.x > 0 ? 1 : 0) + (splat.pos.y > .5f ? 2 : 0); Color expected = colors[quadrant];
                    Near(GaussianUtils.SH0ToColor(splat.dc0), new Vector3(expected.r, expected.g, expected.b), "Stamp UV colors flipped", .008f);
                    Near(GaussianUtils.Sigmoid(splat.opacity), expected.a * .5f, "Stamp texture alpha/density");
                    Near(splat.pos.z, 3.8f, "Stamp layering"); Near(Mathf.Exp(splat.scale.x), .025f, "Stamp manual size");
                }
                Require(Get<int>(window, "m_StampCurrentLayer") == 3, "Stamp layer counter did not advance");
                string firstBytes = Fingerprint(stamp.m_Asset);
                Splat[] firstData = Read(stamp);
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Require(GameObject.Find(firstName) == null, "Stamp Undo did not remove output");
                Undo.PerformRedo(); stamp = GameObject.Find(firstName)?.GetComponentInChildren<SplatBoxRenderer>();
                Require(stamp != null && Fingerprint(stamp.m_Asset) == firstBytes, "Stamp Redo changed output");
                stamp.transform.parent.name = firstName = "UV sculpt Stamp";

                // Projection is essential when the sampling point lies behind the stamp plane.
                var origin = new Vector3(-.2f, .3f, 3); var end = new Vector3(.2f, .7f, 3);
                object grid = Call(window, "SampleStampColors", origin, Vector3.right, Vector3.up, .4f, .4f, camera);
                Vector3 projected = camera.WorldToViewportPoint(new Vector3(.1f, .5f, 4));
                Vector3 lower = camera.WorldToViewportPoint(origin), upper = camera.WorldToViewportPoint(end);
                var uv = new Vector2((projected.x - lower.x) / (upper.x - lower.x), (projected.y - lower.y) / (upper.y - lower.y));
                Require(SampleGrid(grid, uv, out Color sampled), "Sculpted surface color did not map to its projected Stamp UV");
                Near(new Vector3(sampled.r, sampled.g, sampled.b), new Vector3(tint.r, tint.g, tint.b), "Stamp ignored Colorize on sculpted geometry");
                Require(!SampleGrid(grid, new Vector2(.25f, .5f), out _), "Stamp sampled deleted or unprojected geometry");
                camera.orthographic = true; camera.orthographicSize = 2;
                grid = Call(window, "SampleStampColors", new Vector3(-.2f, .3f, 4), Vector3.right, Vector3.up, .4f, .4f, camera);
                Require(SampleGrid(grid, new Vector2(.75f, .5f), out sampled), "Orthographic Stamp UV changed");
                camera.orthographic = false;
                Color stampColor = new Color(.5f, .25f, .75f, .4f);
                texture.SetPixels(new[] { stampColor, stampColor, stampColor, stampColor }); texture.Apply();
                Set(window, "m_StampBlendMode", GaussianSplatEditorWindow.StampBlendMode.Multiply); Set(window, "m_StampLayeringEnabled", false);
                Call(window, "ExecuteTextureStamp", new Vector3(-.2f, .3f, 4), new Vector3(.2f, .7f, 4), camera, texture);
                var blend = GameObject.Find(source.name + " Stamp")?.GetComponentInChildren<SplatBoxRenderer>();
                Require(blend != null, "Blended Stamp output missing: " + Get<string>(window, "m_StampStatus"));
                string secondName = blend.transform.parent.name; AssertIndependent(blend);
                folders.Add(Path.GetDirectoryName(AssetDatabase.GetAssetPath(blend.m_Asset)).Replace('\\', '/'));
                int blended = 0;
                foreach (var splat in Read(blend))
                {
                    if (Vector3.Distance(GaussianUtils.SH0ToColor(splat.dc0), new Vector3(.1f, .2f, .3f)) < .008f) blended++;
                    Near(splat.pos.z, 4, "Blend Stamp plane"); Near(GaussianUtils.Sigmoid(splat.opacity), .2f, "Blend alpha");
                }
                Require(blended > 0, "Stamp Multiply did not use the Colorized sculpted visible source");
                string secondBytes = Fingerprint(blend.m_Asset);
                Splat[] secondData = Read(blend);
                Action check = () =>
                {
                    foreach (var item in new[] { (firstName, firstBytes, firstData), (secondName, secondBytes, secondData) })
                    {
                        var output = GameObject.Find(item.Item1)?.GetComponentInChildren<SplatBoxRenderer>();
                        Require(output != null && output.splatCount == 64 && Fingerprint(output.m_Asset) == item.Item2, "Saved Stamp changed under source lifecycle");
                        AssertIndependent(output); var values = Read(output); Require(values.Length == 64, "Saved Stamp GPU data missing");
                        for (int i = 0; i < values.Length; i++)
                        {
                            Near(values[i].pos, item.Item3[i].pos, "Saved Stamp GPU positions changed");
                            Near(values[i].dc0, item.Item3[i].dc0, "Saved Stamp GPU colors changed");
                            Near(values[i].opacity, item.Item3[i].opacity, "Saved Stamp GPU opacity changed");
                            Near(values[i].scale, item.Item3[i].scale, "Saved Stamp GPU scale changed");
                        }
                    }
                };
                source.ResetPagedSculpt(); source.ResetPagedColorize(); source.ResetDeletedSplats(); Preload(source, camera); check();
                // Exercise the streamer's public unload lifecycle. DestroyImmediate on this
                // non-ExecuteAlways component can skip OnDestroy in an Edit-mode-only fixture.
                var oldPageBuffers = new List<GraphicsBuffer>();
                foreach (var page in source.lodStreamer.loadedPages) oldPageBuffers.Add(page.gpuPosData);
                source.lodStreamer.UnloadAll();
                foreach (var buffer in oldPageBuffers) Require(!buffer.IsValid(), "Unloading source pages retained their GPU buffers");
                Preload(source, camera); check();
                AssetDatabase.SaveAssets(); Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save Stamp scene");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                source = GameObject.Find("Sculpt Stamp source").GetComponent<SplatBoxRenderer>();
                camera = GameObject.Find("Sculpt Stamp camera").GetComponent<Camera>(); camera.targetTexture = target;
                Preload(source, camera); check();
                for (int i = 0; i < sourceBytes.Count; i++) Require(sourceBytes[i] == Fingerprint(source.pagedScene.pages[i].pageAsset.splatData), "Stamp changed source bytes");
                Set(window, "m_TargetRenderer", source); Undo.ClearAll(); Call(window, "ResetAllSplatEdits");
                Require(GameObject.Find(firstName) == null && GameObject.Find(secondName) == null, "Reset All retained Stamp output");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); check(); Undo.PerformRedo();
                Require(GameObject.Find(firstName) == null && GameObject.Find(secondName) == null, "Redo Reset All retained Stamp output");
            }
            finally
            {
                if (window != null) Object.DestroyImmediate(window); EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                (fixture as IDisposable)?.Dispose(); if (texture != null) Object.DestroyImmediate(texture);
                if (target != null) { target.Release(); Object.DestroyImmediate(target); }
                foreach (string folder in folders) AssetDatabase.DeleteAsset(folder); AssetDatabase.DeleteAsset(scenePath);
            }
        }
        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use an isolated batch project with graphics device");
            var errors = new List<string>(); Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                { FreshPickAndLockedPlane(shader); SavedStamp(shader); }
                Require(errors.Count == 0, "Stamp validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Paged Sculpt Stamp PASS: fresh sculpted picks, precise cursor depth, locked drag plane, projected perspective/orthographic UV, Colorize blending, alpha/layers/size, independent assets, page rebuild/reload, scene reopen, Undo/Redo and Reset All on both shaders.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
