// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GaussianSplatting.Tests
{
    /// <summary>Erase and Colorize retain their stroke-time geometry through later sculpt/reloads.</summary>
    public static class PagedSculptPaintValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static readonly Color Source = new Color(.6f, .4f, .2f, .8f);
        static T Get<T>(object target, string field) => (T)target.GetType().GetField(field, Flags).GetValue(target);
        static void Set(object target, string field, object value) => target.GetType().GetField(field, Flags).SetValue(target, value);
        static object Call(object target, string method, params object[] args) => target.GetType().GetMethod(method, Flags).Invoke(target, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(Vector3 value, Vector3 expected, string message) =>
            Require(Vector3.Distance(value, expected) < .001f, message + ": got " + value + ", expected " + expected);
        static void Near(Color value, Color expected, string message) =>
            Require(Mathf.Abs(value.r - expected.r) < .004f && Mathf.Abs(value.g - expected.g) < .004f &&
                Mathf.Abs(value.b - expected.b) < .004f && Mathf.Abs(value.a - expected.a) < .004f,
                message + ": got " + value + ", expected " + expected);
        static Color Opaque(Color color) => new Color(color.r, color.g, color.b, Source.a);
        static int ArchiveCount(SplatBoxRenderer renderer) => Get<System.Collections.IList>(renderer, "m_PagedEditSculptHistory").Count;
        static int LastColorSnapshot(SplatBoxRenderer renderer)
        {
            var strokes = Get<System.Collections.IList>(renderer, "m_PagedColorizeStrokes");
            var dabs = Get<System.Collections.IList>(strokes[strokes.Count - 1], "dabs");
            return Get<int>(dabs[dabs.Count - 1], "sculptSnapshot");
        }

        sealed class Fixture : IDisposable
        {
            public readonly object wrapper, inner;
            public readonly SplatBoxRenderer renderer;
            public readonly SplatBoxPageGpuState page;
            public readonly SplatBoxLodStreamer streamer;
            public readonly Camera camera;
            public Fixture(string shader)
            {
                var type = typeof(PagedSmudgeValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                wrapper = Activator.CreateInstance(type, Flags, null, new object[] { shader }, null);
                inner = Get<object>(wrapper, "inner"); renderer = Get<SplatBoxRenderer>(wrapper, "renderer");
                page = Get<SplatBoxPageGpuState>(wrapper, "page"); streamer = Get<SplatBoxLodStreamer>(wrapper, "streamer");
                camera = Get<Camera>(wrapper, "camera");
            }
            public Vector3 Original(int index) => (Vector3)Call(wrapper, "Position", index);
            public Vector3 Position(int index) => Original(index) + ((Vector3[])Call(wrapper, "Offsets"))[index];
            public void Positions(params Vector3[] positions) => Call(wrapper, "Positions", new object[] { positions });
            public void Move(Vector3 center, Vector3 delta, float radius = 10)
            {
                renderer.BeginPagedSculptStroke(); renderer.SmudgeSplatsGPU(center, delta, radius, 0, 1); renderer.EndPagedSculptStroke();
            }
            public void Paint(Vector3 center, Color color, float radius = .1f, float strength = 1, float falloff = 0, float noise = 0)
            {
                renderer.BeginPagedColorizeStroke();
                renderer.ColorizeInSphere(center, radius, color, strength, falloff, 0, 0, noise, 1.3f);
                renderer.EndPagedColorizeStroke();
            }
            public void Ensure()
            {
                Call(renderer, "EnsurePagedSmudgeState", new object[] { null });
                Call(renderer, "EnsurePagedLodEraseState", new object[] { null });
                Call(renderer, "EnsurePagedColorizeState", new object[] { null });
            }
            public void Replay()
            {
                Call(renderer, "ReplayPagedSmudgePage", null, page, page.atlasOffset);
                Call(renderer, "ReplayPagedLodErasePage", null, page, page.atlasOffset);
                Call(renderer, "ReplayPagedColorizePage", null, page, page.atlasOffset);
                Ensure();
            }
            public bool Deleted(int index)
            {
                Ensure(); var buffer = Get<GraphicsBuffer>(renderer, "m_GpuPagedLodDeletedBits");
                if (buffer == null) return false;
                var words = new uint[buffer.count]; buffer.GetData(words);
                return (words[index / 32] & (1u << (index & 31))) != 0;
            }
            public Color Color(int index)
            {
                Ensure(); var buffer = Get<GraphicsBuffer>(renderer, "m_GpuPagedColorOverrides");
                if (buffer == null) return Source;
                var data = new Vector4[buffer.count]; buffer.GetData(data);
                return data[index].w > .5f ? new Color(data[index].x, data[index].y, data[index].z, Source.a) : Source;
            }
            public Color Sample(Vector3 position)
            {
                Call(inner, "Select", new uint[] { 33, 34, 35 }, new uint[] { 0, 1, 2 });
                Vector3 pixel = camera.WorldToScreenPoint(position);
                float depth = Vector3.Dot(position - camera.transform.position, camera.transform.forward);
                var colors = new Color[4];
                Require(renderer.SamplePaintColors(camera, new Vector2(pixel.x, pixel.y), 2, depth, .015f, colors, out int count) && count == 1,
                    "Expected one visible sculpted source sample, got " + count);
                return colors[0];
            }
            public void Reload()
            {
                string json = EditorJsonUtility.ToJson(renderer);
                renderer.ResetDeletedSplats(); renderer.ResetPagedColorize(); renderer.ResetPagedSculpt();
                EditorJsonUtility.FromJsonOverwrite(json, renderer);
                Set(renderer, "m_LodStreamer", streamer); Call(inner, "RecreateAtlas"); Ensure();
            }
            public void Dispose() => ((IDisposable)wrapper).Dispose();
        }

        static void MixedSnapshots(string shader)
        {
            using var f = new Fixture(shader);
            var sourceWords = new uint[384]; Get<GraphicsBuffer>(f.inner, "pos").GetData(sourceWords);
            f.Paint(f.Original(34), Color.green);
            f.renderer.EditDeleteSphere(f.Original(35), .1f); // Legacy/source-space edits predate sculpt.
            f.Move(new Vector3(0, 0, 4), Vector3.right * 1.5f);
            Vector3 first = f.Position(33);
            f.Paint(first + Vector3.up * .03f, Color.red, .2f, .65f, .4f, .35f);
            int firstSnapshot = LastColorSnapshot(f.renderer), firstArchiveSize = ArchiveCount(f.renderer);
            Require(firstSnapshot > 0 && firstArchiveSize == 1, "First edited pose did not capture one sculpt node");
            Color painted = f.Color(33);
            Require(painted != Source, "Colorize missed the sculpted splat");
            Near(f.Sample(first), painted, "Picking/Colorize uses sculpted geometry");
            f.renderer.EditDeleteSphere(first, .1f);
            Require(f.Deleted(33) && f.Deleted(35) && !f.Deleted(34), "Erase did not hit the sculpted position");
            f.renderer.EditRestoreSphere(first, .1f);
            Require(!f.Deleted(33) && f.Deleted(35), "Restore did not use the sculpted position");
            f.renderer.EditDeleteSphere(f.Position(34), .1f);
            Require(ArchiveCount(f.renderer) == firstArchiveSize, "Repeated erase/restore copied an unchanged sculpt chain");
            f.Move(new Vector3(1.5f, 0, 4), Vector3.left * 3);
            f.Replay();
            Near(f.Color(33), painted, "Later sculpt changed noise/falloff on replay");
            Near(f.Color(34), Opaque(Color.green), "Pre-sculpt color did not follow its splat");
            Require(!f.Deleted(33) && f.Deleted(34) && f.Deleted(35), "Later sculpt changed erased identities");
            Near(f.Position(33), f.Original(33) + Vector3.left * 1.5f, "Replay scratch leaked into live positions");
            f.renderer.EditRestoreSphere(f.Position(34), .1f);
            f.Move(new Vector3(-1.5f, 0, 4), Vector3.right);
            f.Replay();
            Require(!f.Deleted(34) && f.Deleted(35), "A later restore was reevaluated at the wrong sculpt state");
            f.renderer.ResetPagedSculpt(); f.Replay();
            Near(f.Color(33), painted, "Reset Sculpt erased a paint snapshot");
            Near(f.Color(34), Opaque(Color.green), "Reset Sculpt changed legacy color");
            Require(!f.Deleted(33) && !f.Deleted(34) && f.Deleted(35), "Reset Sculpt changed erase identities");
            f.Reload();
            Near(f.Color(33), painted, "Serialized snapshots lost color after Reset Sculpt");
            Require(f.Deleted(35) && !f.Deleted(33) && !f.Deleted(34), "Serialized snapshots lost erase/restore order");
            Require(f.renderer.UndoPagedColorize(), "Colorize Undo unavailable");
            Near(f.Color(33), Source, "Colorize Undo did not remove newest snapshot stroke");
            Require(f.renderer.RedoPagedColorize(), "Colorize Redo unavailable");
            Near(f.Color(33), painted, "Colorize Redo lost stroke-time noise");
            Undo.FlushUndoRecordObjects(); Undo.IncrementCurrentGroup();
            f.renderer.EditDeleteSphere(f.Position(33), .1f); Undo.FlushUndoRecordObjects();
            Require(f.Deleted(33), "Erase Undo fixture did not erase");
            Undo.PerformUndo(); f.Ensure(); Require(!f.Deleted(33), "Erase Undo left a snapshot mask active");
            Undo.PerformRedo(); f.Ensure(); Require(f.Deleted(33), "Erase Redo failed to replay its snapshot");
            // Reset discarded the live journal; a longer, different branch must not alias the saved head.
            int previousArchiveSize = ArchiveCount(f.renderer);
            for (int i = 0; i < 3; i++) f.Move(new Vector3(0, 0, 4), Vector3.up * .2f);
            f.Paint(f.Position(34), Color.blue);
            int branchedSnapshot = LastColorSnapshot(f.renderer);
            Require(branchedSnapshot != firstSnapshot && ArchiveCount(f.renderer) == previousArchiveSize + 3,
                "A new sculpt branch reused or redundantly copied the old snapshot");
            f.Paint(f.Position(34), Color.blue);
            Require(LastColorSnapshot(f.renderer) == branchedSnapshot && ArchiveCount(f.renderer) == previousArchiveSize + 3,
                "Repeated Colorize failed to share the same sculpt snapshot");
            f.renderer.ResetPagedSculpt(); f.Replay();
            Near(f.Color(34), Opaque(Color.blue), "Reset/new branch replay selected the wrong identity");
            Near(f.Color(33), painted, "A new branch overwrote the original captured pose");
            var after = new uint[sourceWords.Length]; Get<GraphicsBuffer>(f.inner, "pos").GetData(after);
            for (int i = 0; i < after.Length; i++) Require(after[i] == sourceWords[i], "Snapshot editing mutated source positions");
            foreach (Color pixel in Get<Texture2D>(f.inner, "color").GetPixels()) Near(pixel, Source, "Snapshot editing mutated source colors");
        }

        static void LateDetailAndRecycledSlots(string shader)
        {
            using var f = new Fixture(shader);
            f.Positions(new Vector3(0, .5f, 4), new Vector3(0, 0, 3), new Vector3(0, 0, 5), new Vector3(.03f, 0, 3));
            var original = (LodTreeNode[])f.page.lodTree.nodes.Clone();
            var positions = new[] { f.Original(32), f.Original(33), f.Original(34), f.Original(35) };
            f.page.isCoarseStub = true; f.page.splatCount = 3;
            f.page.lodTree = LodTreeRuntime.BuildPrefix(new[] { original[0], original[1], original[2] });
            f.Move(new Vector3(0, 0, 4), Vector3.right * 3);
            f.Paint(new Vector3(3, 0, 3), Color.red, .1f);
            f.renderer.EditDeleteSphere(new Vector3(3, 0, 3), .1f);
            Require(!f.Deleted(35), "Edit wrote nonresident detail");
            f.Move(new Vector3(3, 0, 4), Vector3.left * 6);
            f.Paint(new Vector3(-3, 0, 5), Color.blue, .1f);
            f.page.splatCount = 4; f.page.isCoarseStub = false;
            f.page.lodTree = LodTreeRuntime.Build((LodTreeNode[])original.Clone(), true);
            f.Replay();
            Require(f.Deleted(33) && f.Deleted(35) && !f.Deleted(34), "Late child did not inherit stroke-time erasure");
            Near(f.Color(35), Opaque(Color.red), "Late child did not inherit stroke-time color");
            Near(f.Color(34), Opaque(Color.blue), "Second sculpt snapshot lost its color");
            // Unrelated geometry replaces the same address; neither sculpt nor editing history applies.
            for (int i = 0; i < 4; i++) Call(f.inner, "SetPosition", 32 + i, new Vector3(30 + i, 0, 3));
            f.page.bounds = new Bounds(new Vector3(31.5f, 0, 3), new Vector3(3, 0, 0));
            f.Replay();
            for (int i = 32; i < 36; i++)
            { Require(!f.Deleted(i), "Recycled page inherited stale erase bits"); Near(f.Color(i), Source, "Recycled page inherited stale colors"); }
            // The original page subsequently loads at another atlas offset.
            for (int i = 0; i < 4; i++) Call(f.inner, "SetPosition", 64 + i, positions[i]);
            f.page.atlasOffset = f.page.uploadedAtlasOffset = 64;
            f.page.bounds = new Bounds(new Vector3(0, .25f, 4), new Vector3(.1f, .5f, 2));
            f.page.lodTree = LodTreeRuntime.Build((LodTreeNode[])original.Clone(), true);
            f.Replay();
            Require(f.Deleted(65) && f.Deleted(67) && !f.Deleted(66), "Relocated page lost captured erase identities");
            Near(f.Color(67), Opaque(Color.red), "Relocated child lost captured color");
            Near(f.Color(66), Opaque(Color.blue), "Relocated page confused two sculpt snapshots");
        }

        static void RelaxAndRestoreSnapshots(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 center = new Vector3(0, 0, 5);
            f.Positions(center, center - Vector3.right * .1f, center + Vector3.right * .1f, center + Vector3.right * 8);
            f.Move(center, Vector3.right * .4f, 1);
            f.renderer.BeginPagedSculptStroke();
            f.renderer.RestorePositionsInSphereGPU(center + Vector3.right * .4f, 1, 0, .5f);
            f.renderer.RelaxSplatsGPU(center + Vector3.right * .2f, 1, 0, .5f, 1);
            f.renderer.EndPagedSculptStroke();
            Vector3 paintedPoint = f.Position(33), erasedPoint = f.Position(34);
            f.Paint(paintedPoint, Color.magenta, .03f);
            f.renderer.EditDeleteSphere(erasedPoint, .03f);
            Near(f.Color(33), Opaque(Color.magenta), "Colorize missed Relax/Restore geometry");
            Require(f.Deleted(34) && !f.Deleted(33), "Erase missed Relax/Restore geometry");
            f.renderer.ResetPagedSculpt(); f.Move(center, Vector3.left * .5f, 2);
            f.Replay(); f.Reload();
            Near(f.Color(33), Opaque(Color.magenta), "Captured Relax field did not survive changed sculpt history");
            Require(f.Deleted(34) && !f.Deleted(33), "Captured Restore/Relax erase did not survive changed history");
            Near(f.Position(33), f.Original(33) + Vector3.left * .5f, "Snapshot replay changed live sculpt history");
        }

        static void ScreenAndSoftErase(string shader)
        {
            using var f = new Fixture(shader);
            Call(f.inner, "Select", new uint[] { 33, 34 }, new uint[] { 0, 1 });
            f.Move(new Vector3(0, 0, 3), Vector3.forward * 4, .1f);
            f.renderer.EditDeleteSplatsInScreenCircle(new Vector2(320, 240), 8, f.camera, true);
            Require(!f.Deleted(33) && f.Deleted(34), "Depth-limited screen erase ignored sculpted front/back order");
            f.Move(new Vector3(0, 0, 7), Vector3.back * 5, .1f); f.Replay();
            Require(!f.Deleted(33) && f.Deleted(34), "Screen erase reevaluated depth after later sculpt");
            f.renderer.ResetDeletedSplats(); f.renderer.ResetPagedSculpt();
            f.Positions(new Vector3(0, 0, 5), new Vector3(-.2f, 0, 5), new Vector3(.2f, 0, 5), new Vector3(8, 0, 5));
            f.Move(new Vector3(0, 0, 5), Vector3.right * 1.5f, 1);
            int pattern = 0;
            Func<int> read = () => (f.Deleted(32) ? 1 : 0) | (f.Deleted(33) ? 2 : 0) | (f.Deleted(34) ? 4 : 0);
            for (int seed = 0; seed < 16 && (pattern == 0 || pattern == 7); seed++)
            {
                f.renderer.ResetDeletedSplats();
                f.renderer.DeleteSplatsInSphereWithFalloff(new Vector3(1.9f, 0, 5), .8f, 1, .4f, 1.3f, .271f + seed * .531f);
                pattern = read();
            }
            Require(pattern != 0 && pattern != 7, "Soft erase fixture needs erased and preserved points");
            f.Move(new Vector3(1.5f, 0, 5), Vector3.left * 3, 1); f.Replay();
            Require(read() == pattern && !f.Deleted(35), "Later sculpt changed captured soft-erase falloff/noise");
            f.renderer.ResetPagedSculpt(); f.Replay();
            Require(read() == pattern, "Reset Sculpt changed captured soft-erase identities");
        }

        static uint Pack(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static void PackedSnapshots(string shader)
        {
            using var f = new Fixture(shader);
            var asset = Get<GaussianSplatAsset>(f.inner, "asset");
            asset.Initialize(128, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
            var payload = Get<TextAsset>(f.inner, "data"); asset.SetAssetFiles(payload, payload, payload, payload, payload);
            var positions = new uint[128]; var others = new uint[256];
            for (int i = 0; i < 128; i++)
            { positions[i] = Pack(Vector3.one * .9f); others[i * 2] = 0xE0080200u; others[i * 2 + 1] = Pack(Vector3.one * .5f); }
            positions[33] = Pack(new Vector3(.5f, .5f, .3f));
            positions[34] = Pack(new Vector3(.5f, .5f, .5f));
            Get<GraphicsBuffer>(f.inner, "pos").SetData(positions); Get<GraphicsBuffer>(f.inner, "other").SetData(others);
            var chunk = new GaussianSplatAsset.ChunkInfo { posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                colR = HalfRange(0, 1), colG = HalfRange(0, 1), colB = HalfRange(0, 1), colA = HalfRange(.5f, .9f),
                sclX = HalfRange(.1f, .2f), sclY = HalfRange(.1f, .2f), sclZ = HalfRange(.1f, .2f) };
            Get<GraphicsBuffer>(f.inner, "chunks").SetData(new[] { chunk }); Set(f.renderer, "m_GpuChunksValid", true);
            Set(f.renderer, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(f.inner, "chunks")); Set(f.renderer, "m_LodUnifiedChunkCount", 1);
            try
            {
                Vector3 point = new Vector3(Mathf.Round(.5f * 2047) / 2047 * 20 - 10,
                    Mathf.Round(.5f * 1023) / 1023 * 20 - 10, Mathf.Round(.3f * 2047) / 2047 * 10);
                f.Move(point, Vector3.up * 2, .1f);
                f.Paint(point + Vector3.up * 2, Color.cyan, .05f);
                f.renderer.EditDeleteSphere(point + Vector3.up * 2, .05f);
                Require(f.Deleted(33) && !f.Deleted(34), "Packed erase did not decode sculpted positions");
                Near(f.Color(33), Opaque(Color.cyan), "Packed Colorize did not decode sculpted positions");
                f.renderer.ResetPagedSculpt(); f.Replay();
                Require(f.Deleted(33) && !f.Deleted(34), "Packed erase snapshot lost after Reset Sculpt");
                Near(f.Color(33), Opaque(Color.cyan), "Packed color snapshot lost after Reset Sculpt");
                f.renderer.EditRestoreSphere(point, .05f); f.Replay();
                Require(!f.Deleted(33), "Packed restore could not target reset geometry");
                var actual = new uint[128]; Get<GraphicsBuffer>(f.inner, "pos").GetData(actual, 0, 0, actual.Length);
                for (int i = 0; i < actual.Length; i++) Require(actual[i] == positions[i], "Packed snapshots modified source bytes");
            }
            finally { Set(f.renderer, "m_GpuLodUnifiedChunks", null); }
        }

        static void Preload(SplatBoxRenderer renderer, Camera camera) => typeof(PagedSmudgeValidation)
            .GetMethod("Preload", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer, camera });
        static void ExpectRealEdits(SplatBoxRenderer renderer)
        {
            Call(renderer, "EnsurePagedLodEraseState", new object[] { null });
            Call(renderer, "EnsurePagedColorizeState", new object[] { null });
            var colors = Get<GraphicsBuffer>(renderer, "m_GpuPagedColorOverrides");
            var erased = Get<GraphicsBuffer>(renderer, "m_GpuPagedLodDeletedBits");
            Require(colors != null && erased != null, "Real-page color/erase snapshot buffers missing");
            var rgba = new Vector4[colors.count]; colors.GetData(rgba);
            var bits = new uint[erased.count]; erased.GetData(bits);
            foreach (var page in renderer.lodStreamer.loadedPages)
                for (int i = 0; i < page.splatCount; i++)
                {
                    int index = page.atlasOffset + i;
                    Require(((bits[index / 32] & (1u << (index & 31))) != 0) == (page.pageId == 1 && i == 1), "Real-page erased identity changed");
                    if (page.pageId == 1)
                        Near(new Color(rgba[index].x, rgba[index].y, rgba[index].z, Source.a), Opaque(Color.magenta), "Real-page captured color");
                    else Require(rgba[index].w == 0, "Snapshot colored unrelated page");
                }
        }

        static void SavedSceneAndCopy()
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; RenderTexture target = null;
            GaussianSplatEditorWindow window = null; string copyPath = null;
            string scenePath = "Assets/__SculptPaintValidation_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer"); renderer.name = "Sculpt paint validation source";
                var camera = new GameObject("Sculpt paint validation camera").AddComponent<Camera>(); camera.tag = "MainCamera";
                target = new RenderTexture(640, 480, 0); target.Create(); camera.targetTexture = target;
                var originals = new List<string>();
                foreach (var entry in renderer.pagedScene.pages)
                    originals.Add(Convert.ToBase64String(entry.pageAsset.splatData.posData.bytes) + Convert.ToBase64String(entry.pageAsset.splatData.colorData.bytes));
                Preload(renderer, camera);
                renderer.SmudgeSplatsGPU(new Vector3(0, 0, 5), Vector3.up, .3f, 0, 1);
                renderer.BeginPagedColorizeStroke(); renderer.ColorizeInSphere(new Vector3(0, 1, 5), .3f, Color.magenta, 1, 0); renderer.EndPagedColorizeStroke();
                renderer.EditDeleteSphere(new Vector3(-.1f, 1, 5), .04f);
                ExpectRealEdits(renderer);
                renderer.SmudgeSplatsGPU(new Vector3(0, 1, 5), Vector3.down * 2, .3f, 0, 1);
                Preload(renderer, camera); ExpectRealEdits(renderer);
                renderer.ResetPagedSculpt(); Preload(renderer, camera); ExpectRealEdits(renderer);
                AssetDatabase.SaveAssets();
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save sculpt/paint scene");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                renderer = GameObject.Find("Sculpt paint validation source").GetComponent<SplatBoxRenderer>();
                camera = GameObject.Find("Sculpt paint validation camera").GetComponent<Camera>(); camera.targetTexture = target;
                Preload(renderer, camera); ExpectRealEdits(renderer);
                for (int i = 0; i < originals.Count; i++)
                {
                    var asset = renderer.pagedScene.pages[i].pageAsset.splatData;
                    Require(originals[i] == Convert.ToBase64String(asset.posData.bytes) + Convert.ToBase64String(asset.colorData.bytes), "Saved snapshots rewrote source assets");
                }
                Undo.FlushUndoRecordObjects(); Undo.IncrementCurrentGroup();
                renderer.EditRestoreSphere(new Vector3(-.1f, 0, 5), .04f); Undo.FlushUndoRecordObjects();
                Undo.PerformUndo(); Preload(renderer, camera); ExpectRealEdits(renderer);
                Require(renderer.UndoPagedColorize() && renderer.RedoPagedColorize(), "Saved snapshot Colorize history could not Undo/Redo");
                Preload(renderer, camera); ExpectRealEdits(renderer);
                // Xcopy clones the complete archive, including historical poses after Reset Sculpt.
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window, "m_TargetRenderer", renderer);
                var boxOwner = new GameObject("Sculpt paint validation copy brush"); boxOwner.SetActive(false);
                var box = boxOwner.AddComponent<GaussianSplatBoxBrush>(); box.TargetRenderer = renderer;
                box.BoxPosition = new Vector3(0, 0, 5); box.BoxSize = Vector3.one * .4f;
                Set(window, "m_BoxBrush", box); Call(window, "CopyPagedXcopy");
                box.BoxPosition = new Vector3(0, 0, 4); Call(window, "PastePagedXcopy");
                var copy = GameObject.Find("Sculpt paint validation source Xcopy")?.GetComponentInChildren<SplatBoxRenderer>();
                Require(copy != null, "Could not create sculpt/paint Xcopy"); copyPath = AssetDatabase.GetAssetPath(copy.pagedScene);
                Preload(copy, camera);
                Action checkCopy = () =>
                {
                    var palette = new Color[8];
                    Require(copy.SamplePaintColors(camera, new Vector2(320, 240), 20, 4, .04f, palette, out int count) && count == 1,
                        "Xcopy lost historical erased identity: visible count=" + count);
                    Near(palette[0], Opaque(Color.magenta), "Xcopy lost historical color");
                };
                checkCopy();
                renderer.ResetDeletedSplats(); renderer.ResetPagedColorize(); Preload(renderer, camera);
                Preload(copy, camera); checkCopy();
            }
            finally
            {
                if (window != null) UnityEngine.Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); UnityEngine.Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
                if (!string.IsNullOrEmpty(copyPath)) AssetDatabase.DeleteAsset(copyPath);
            }
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use isolated batch project with graphics device");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    MixedSnapshots(shader); LateDetailAndRecycledSlots(shader);
                    RelaxAndRestoreSnapshots(shader); PackedSnapshots(shader); ScreenAndSoftErase(shader);
                }
                SavedSceneAndCopy();
                Require(errors.Count == 0, "Sculpt/paint validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Paged Sculpt Paint PASS: sculpted erase/restore/color, legacy strokes, immutable noise/falloff, " +
                    "later sculpt/reset, mixed snapshots, late children/recycled slots, Relax/Restore and compressed histories, Undo/Redo, saved-scene replay and source preservation.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
