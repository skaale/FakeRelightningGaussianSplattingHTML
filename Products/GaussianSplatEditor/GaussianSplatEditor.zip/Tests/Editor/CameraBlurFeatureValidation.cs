// SPDX-License-Identifier: MIT
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    /// <summary>Camera Blur installs only the required active URP features and preserves authored settings.</summary>
    public static class CameraBlurFeatureValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static readonly Type PipelineType = Type.GetType("UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset, Unity.RenderPipelines.Universal.Runtime", true);
        static readonly Type RendererType = Type.GetType("UnityEngine.Rendering.Universal.UniversalRendererData, Unity.RenderPipelines.Universal.Runtime", true);
        static readonly Type CameraDataType = Type.GetType("UnityEngine.Rendering.Universal.UniversalAdditionalCameraData, Unity.RenderPipelines.Universal.Runtime", true);
        static readonly Type FeatureType = Type.GetType("GaussianSplatting.Runtime.GaussianTiltShiftRendererFeature, GaussianSplatting.SplatBox.Runtime", true);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static T Get<T>(object target, string field) => (T)target.GetType().GetField(field, Flags).GetValue(target);
        static void Set(object target, string field, object value) => target.GetType().GetField(field, Flags).SetValue(target, value);
        static object Call(object target, string method, params object[] args) => target.GetType().GetMethod(method, Flags).Invoke(target, args);
        static object Settings(Object feature) => Get<object>(feature, "settings");
        static bool Active(Object feature) => (bool)feature.GetType().GetProperty("isActive", Flags).GetValue(feature);
        static void Near(float value, float expected, string message) => Require(Mathf.Abs(value - expected) < .00001f, message);

        static bool Ensure(Camera camera, out string error)
        {
            var method = typeof(GaussianTiltShiftBuildSync).GetMethod("EnsureActiveRendererFeature", BindingFlags.Static | BindingFlags.Public);
            Require(method != null, "Missing Camera Blur renderer setup bridge");
            object[] args = { camera, null };
            bool result = (bool)method.Invoke(null, args);
            error = args[1] as string;
            return result;
        }

        static void Ensure(Camera camera)
        {
            bool success = Ensure(camera, out string error);
            Require(success, "Camera Blur feature setup failed: " + error);
        }

        static Object OnlyFeature(ScriptableObject renderer)
        {
            var serialized = new SerializedObject(renderer);
            var features = serialized.FindProperty("m_RendererFeatures");
            Require(features.arraySize == 1, renderer.name + " must contain exactly one blur feature");
            var feature = features.GetArrayElementAtIndex(0).objectReferenceValue;
            Require(feature != null && feature.GetType() == FeatureType, "Renderer has a missing or unexpected feature");
            return feature;
        }

        static int FeatureCount(ScriptableObject renderer) =>
            new SerializedObject(renderer).FindProperty("m_RendererFeatures").arraySize;

        static long FeatureId(ScriptableObject renderer)
        {
            var feature = OnlyFeature(renderer);
            Require(AssetDatabase.TryGetGUIDAndLocalFileIdentifier(feature, out string guid, out long id) && id != 0,
                "Blur feature does not have a persistent subasset identifier");
            Require(AssetDatabase.GetAssetPath(feature) == AssetDatabase.GetAssetPath(renderer), "Blur feature is not stored with its renderer");
            var map = new SerializedObject(renderer).FindProperty("m_RendererFeatureMap");
            Require(map.arraySize == 1 && map.GetArrayElementAtIndex(0).longValue == id,
                "URP feature map does not match the feature's local file ID");
            return id;
        }

        static void VerifyRenderPassQueue(Object feature, Camera camera)
        {
            var contextType = Type.GetType("UnityEngine.Rendering.ContextContainer, Unity.RenderPipelines.Core.Runtime", true);
            var universalCameraType = Type.GetType("UnityEngine.Rendering.Universal.UniversalCameraData, Unity.RenderPipelines.Universal.Runtime", true);
            var renderingDataType = Type.GetType("UnityEngine.Rendering.Universal.RenderingData, Unity.RenderPipelines.Universal.Runtime", true);
            var rendererType = Type.GetType("UnityEngine.Rendering.Universal.UniversalRenderer, Unity.RenderPipelines.Universal.Runtime", true);
            var passType = Type.GetType("UnityEngine.Rendering.Universal.ScriptableRenderPass, Unity.RenderPipelines.Universal.Runtime", true);
            object context = Activator.CreateInstance(contextType);
            var create = contextType.GetMethod("Create").MakeGenericMethod(universalCameraType);
            var arguments = new object[create.GetParameters().Length];
            for (int i = 0; i < arguments.Length; i++) arguments[i] = Type.Missing;
            object cameraData = create.Invoke(context, arguments);
            Set(cameraData, "camera", camera); Set(cameraData, "cameraType", CameraType.SceneView);
            object renderingData = Activator.CreateInstance(renderingDataType, Flags, null, new[] { context }, null);
            // AddRenderPasses only calls EnqueuePass on the renderer. Initialize that real URP
            // queue without constructing unrelated shadows, lighting and renderer GPU resources.
#pragma warning disable SYSLIB0050
            object renderer = FormatterServices.GetUninitializedObject(rendererType);
#pragma warning restore SYSLIB0050
            var queue = (IList)Activator.CreateInstance(typeof(List<>).MakeGenericType(passType));
            rendererType.BaseType.GetField("m_ActiveRenderPassQueue", Flags).SetValue(renderer, queue);
            bool createdPass = Get<object>(feature, "m_RenderPass") == null;
            var effect = (GaussianSplatTiltShiftEffect)FeatureType.GetMethod("ResolveCameraEffect",
                BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { camera });
            bool effectEnabled = effect.effectEnabled;
            object settings = Settings(feature);
            bool baseEnabled = Get<bool>(settings, "enabled");
            bool allowOverride = Get<bool>(settings, "allowCameraOverride");
            bool authoredCamera = effect.authoredInSplatBoxEditor;
            object authoredEvent = Get<object>(settings, "renderPassEvent");
            Type eventType = authoredEvent.GetType();
            try
            {
                if (createdPass) Call(feature, "Create");
                Require(Get<object>(feature, "m_RenderPass") != null, "Installed blur feature could not create its render pass");
                // An obsolete render-pass override toggle cannot block SplatBox camera controls.
                Set(settings, "allowCameraOverride", false);
                effect.authoredInSplatBoxEditor = true;
                Set(settings, "enabled", false); effect.effectEnabled = true;
                object earlyEvent = Enum.Parse(eventType, "BeforeRenderingTransparents");
                Set(settings, "renderPassEvent", earlyEvent);
                Call(feature, "AddRenderPasses", renderer, renderingData);
                Require(queue.Count == 2 && queue[0].GetType().Name == "SplatDepthRequestPass",
                    "Depth of field did not enqueue its early splat-depth request and blur pass");
                Require(queue[0].GetType().GetProperty("renderPassEvent", Flags).GetValue(queue[0]).Equals(Enum.Parse(eventType, "BeforeRendering")),
                    "Splat-depth request runs after splat rendering");
                Require(queue[1].GetType().GetProperty("renderPassEvent", Flags).GetValue(queue[1]).Equals(Enum.Parse(eventType, "BeforeRenderingPostProcessing")),
                    "Depth blur was not moved after transparent splat rendering");
                Require(Get<object>(settings, "renderPassEvent").Equals(earlyEvent), "Runtime event clamp changed the authored feature setting");
                Require(Get<bool>(cameraData, "requiresDepthTexture"), "Depth-of-field override did not request depth");
                Near(Get<float>(Get<object>(feature, "m_RuntimeSettings"), "blurStrength"), effect.blurStrength,
                    "URP pass did not use the camera's blur settings");
                queue.Clear();
                Set(settings, "enabled", true); effect.effectEnabled = false;
                Call(feature, "AddRenderPasses", renderer, renderingData);
                Require(queue.Count == 0, "Disabled Scene View override allowed authored renderer blur to run");
            }
            finally
            {
                effect.effectEnabled = effectEnabled; Set(settings, "enabled", baseEnabled);
                effect.authoredInSplatBoxEditor = authoredCamera;
                Set(settings, "allowCameraOverride", allowOverride);
                Set(settings, "renderPassEvent", authoredEvent);
                if (createdPass) ((IDisposable)feature).Dispose();
                ((IDisposable)context).Dispose();
            }
        }

        static void VerifyRepeatedCreate(Object feature)
        {
            try
            {
                Call(feature, "Create");
                var firstPass = Get<object>(feature, "m_RenderPass");
                Require(firstPass != null, "Initial blur pass creation failed");
                Material first = Get<Material>(firstPass, "m_Material");
                Require(first != null, "Initial blur pass has no material");
                Call(feature, "Create");
                Require(first == null, "Recreating the blur feature leaked the previous pass material");
                var secondPass = Get<object>(feature, "m_RenderPass");
                Material second = Get<Material>(secondPass, "m_Material");
                Require(second != null, "Recreated blur pass has no material");
                ((IDisposable)feature).Dispose();
                Require(second == null && Get<object>(feature, "m_RenderPass") == null &&
                    Get<object>(feature, "m_DepthRequestPass") == null,
                    "Disposing the blur feature retained its pass or material");
            }
            finally { ((IDisposable)feature).Dispose(); }
        }

        sealed class Fixture : IDisposable
        {
            public readonly string folder;
            public readonly RenderPipelineAsset graphics = GraphicsSettings.defaultRenderPipeline;
            public readonly RenderPipelineAsset quality = QualitySettings.renderPipeline;
            public readonly Object selection = Selection.activeObject;
            public readonly Dictionary<FieldInfo, object> globals = new Dictionary<FieldInfo, object>();
            public readonly GameObject cameraOwner;
            public readonly Camera camera;
            public readonly Component cameraData;
            public GaussianSplatEditorWindow window;
            public SceneView view;
            public readonly GameObject[] previousMainCameras = GameObject.FindGameObjectsWithTag("MainCamera");

            public Fixture()
            {
                foreach (var field in typeof(GaussianTiltShiftGlobalSettings).GetFields(BindingFlags.Static | BindingFlags.Public))
                    if (!field.IsInitOnly) globals.Add(field, field.GetValue(null));
                string name = "__CameraBlurFeatureValidation_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder("Assets", name);
                folder = "Assets/" + name;
                cameraOwner = new GameObject("Camera Blur validation camera");
                camera = cameraOwner.AddComponent<Camera>();
                camera.enabled = false;
                cameraData = cameraOwner.AddComponent(CameraDataType);
            }

            public ScriptableObject Renderer(string name)
            {
                var value = ScriptableObject.CreateInstance(RendererType);
                value.name = name;
                AssetDatabase.CreateAsset(value, folder + "/" + name + ".asset");
                return value;
            }

            public RenderPipelineAsset Pipeline(string name, int defaultIndex, params ScriptableObject[] renderers)
            {
                var value = (RenderPipelineAsset)ScriptableObject.CreateInstance(PipelineType);
                value.name = name;
                var serialized = new SerializedObject(value);
                var list = serialized.FindProperty("m_RendererDataList");
                list.arraySize = renderers.Length;
                for (int i = 0; i < renderers.Length; i++) list.GetArrayElementAtIndex(i).objectReferenceValue = renderers[i];
                serialized.FindProperty("m_DefaultRendererIndex").intValue = defaultIndex;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                AssetDatabase.CreateAsset(value, folder + "/" + name + ".asset");
                return value;
            }

            public void CameraRenderer(int index)
            {
                var serialized = new SerializedObject(cameraData);
                serialized.FindProperty("m_RendererIndex").intValue = index;
                serialized.ApplyModifiedPropertiesWithoutUndo();
            }

            public void Dispose()
            {
                if (window != null) Object.DestroyImmediate(window);
                if (view != null) view.Close();
                if (cameraOwner != null) Object.DestroyImmediate(cameraOwner);
                foreach (var previous in previousMainCameras)
                    if (previous != null) previous.tag = "MainCamera";
                QualitySettings.renderPipeline = quality;
                GraphicsSettings.defaultRenderPipeline = graphics;
                Selection.activeObject = selection;
                foreach (var pair in globals) pair.Key.SetValue(null, pair.Value);
                AssetDatabase.DeleteAsset(folder);
                AssetDatabase.SaveAssets();
            }
        }

        static int BlurSubassetCount(ScriptableObject renderer)
        {
            int count = 0;
            foreach (var asset in AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(renderer)))
                if (asset != null && asset.GetType() == FeatureType) count++;
            return count;
        }

        static void UndoAndRedo(Fixture fixture)
        {
            var renderer = fixture.Renderer("UndoRenderer");
            GraphicsSettings.defaultRenderPipeline = fixture.Pipeline("UndoPipeline", 0, renderer);
            QualitySettings.renderPipeline = null;
            fixture.CameraRenderer(-1);
            Ensure(fixture.camera);
            long installedId = FeatureId(renderer);
            Require(BlurSubassetCount(renderer) == 1, "Initial install created duplicate feature subassets");
            Undo.FlushUndoRecordObjects();
            Undo.PerformUndo();
            Require(FeatureCount(renderer) == 0 && new SerializedObject(renderer).FindProperty("m_RendererFeatureMap").arraySize == 0,
                "Undo install left a renderer feature reference or map entry");
            Require(BlurSubassetCount(renderer) == 1, "Undo install removed the persistent feature needed for reliable Redo");
            foreach (var asset in AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(renderer)))
                if (asset != null && asset.GetType() == FeatureType)
                    Require((asset.hideFlags & HideFlags.HideInHierarchy) != 0,
                        "Unlinked blur feature was not retained as a hidden subasset");
            AssetDatabase.SaveAssetIfDirty(renderer);
            Undo.PerformRedo();
            Require(Active(OnlyFeature(renderer)) && FeatureId(renderer) == installedId && BlurSubassetCount(renderer) == 1,
                "Redo install did not restore the feature, map and persistent subasset identity");
            AssetDatabase.SaveAssetIfDirty(renderer);
            string path = AssetDatabase.GetAssetPath(renderer);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
            renderer = AssetDatabase.LoadAssetAtPath<ScriptableObject>(path);
            Require(FeatureId(renderer) == installedId && BlurSubassetCount(renderer) == 1,
                "Redone feature did not survive save/reimport");
            Ensure(fixture.camera);
            Require(FeatureId(renderer) == installedId && BlurSubassetCount(renderer) == 1,
                "Enabling after Redo duplicated or replaced the installed feature");

            Undo.PerformUndo();
            Require(FeatureCount(renderer) == 0 && BlurSubassetCount(renderer) == 1,
                "Undo did not leave a reusable unlinked feature");
            Ensure(fixture.camera);
            Require(FeatureId(renderer) == installedId && BlurSubassetCount(renderer) == 1,
                "Re-enabling an undone install did not reuse the persistent hidden feature");

            var feature = OnlyFeature(renderer);
            Call(feature, "SetActive", false);
            Set(Settings(feature), "allowCameraOverride", false);
            Set(Settings(feature), "blurStrength", 2.75f);
            EditorUtility.SetDirty(feature); AssetDatabase.SaveAssets();
            Ensure(fixture.camera);
            Require(Active(feature) && Get<bool>(Settings(feature), "allowCameraOverride"), "Existing feature did not reactivate");
            Undo.FlushUndoRecordObjects();
            Undo.PerformUndo();
            feature = OnlyFeature(renderer);
            Require(!Active(feature) && !Get<bool>(Settings(feature), "allowCameraOverride"),
                "Undo reactivation did not restore both feature activation and camera override");
            Near(Get<float>(Settings(feature), "blurStrength"), 2.75f, "Undo reactivation changed authored blur settings");
            Require(FeatureId(renderer) == installedId && BlurSubassetCount(renderer) == 1,
                "Undo reactivation removed or duplicated the existing feature");
            Undo.PerformRedo();
            feature = OnlyFeature(renderer);
            Require(Active(feature) && Get<bool>(Settings(feature), "allowCameraOverride"), "Redo reactivation did not enable the existing feature");
            Require(FeatureId(renderer) == installedId && BlurSubassetCount(renderer) == 1,
                "Redo reactivation changed the feature identity");
            Near(Get<float>(Settings(feature), "blurStrength"), 2.75f, "Redo reactivation changed authored blur settings");
        }

        static void ActivePipelineAndPersistence(Fixture fixture)
        {
            var unused = fixture.Renderer("UnusedRenderer");
            var defaultRenderer = fixture.Renderer("DefaultRenderer");
            var cameraRenderer = fixture.Renderer("CameraRenderer");
            var unrelated = fixture.Renderer("UnrelatedRenderer");
            fixture.Pipeline("UnrelatedPipeline", 0, unrelated);
            var pipeline = fixture.Pipeline("GraphicsPipeline", 1, unused, defaultRenderer, cameraRenderer);
            GraphicsSettings.defaultRenderPipeline = pipeline;
            QualitySettings.renderPipeline = null;
            fixture.CameraRenderer(2);
            Ensure(fixture.camera);
            var defaultFeature = OnlyFeature(defaultRenderer);
            var cameraFeature = OnlyFeature(cameraRenderer);
            Require(Active(defaultFeature) && Active(cameraFeature), "New blur features were not activated");
            Require(!Get<bool>(Settings(defaultFeature), "enabled") && !Get<bool>(Settings(cameraFeature), "enabled"),
                "Installing blur enabled its base effect on unrelated game cameras");
            Require(Get<bool>(Settings(defaultFeature), "allowCameraOverride"), "Camera override was not enabled");
            Require(FeatureCount(unused) == 0 && FeatureCount(unrelated) == 0, "Setup modified an unused renderer or unrelated pipeline");
            long defaultId = FeatureId(defaultRenderer), cameraId = FeatureId(cameraRenderer);

            // Re-enable an existing feature without resetting settings authored in its inspector.
            var settings = Settings(defaultFeature);
            Set(settings, "enabled", true); Set(settings, "allowCameraOverride", false);
            Set(settings, "blurStrength", 17.25f); Set(settings, "focusPosition", .123f);
            Set(settings, "highQualityBlur", false);
            Call(defaultFeature, "SetActive", false);
            EditorUtility.SetDirty(defaultFeature); AssetDatabase.SaveAssets();
            Ensure(fixture.camera);
            Require(OnlyFeature(defaultRenderer) == defaultFeature && Active(defaultFeature), "Disabled feature was duplicated instead of reactivated");
            Require(Get<bool>(settings, "enabled") && Get<bool>(settings, "allowCameraOverride"), "Authored enable state or camera override was lost");
            Near(Get<float>(settings, "blurStrength"), 17.25f, "Setup reset authored blur strength");
            Near(Get<float>(settings, "focusPosition"), .123f, "Setup reset authored focus position");
            Require(!Get<bool>(settings, "highQualityBlur"), "Setup reset authored blur quality");
            string authored = EditorJsonUtility.ToJson(defaultFeature);
            Ensure(fixture.camera);
            Require(EditorJsonUtility.ToJson(defaultFeature) == authored, "Repeated setup changed an already active feature");
            Require(FeatureId(defaultRenderer) == defaultId && FeatureId(cameraRenderer) == cameraId, "Repeated setup changed feature identifiers");

            AssetDatabase.SaveAssets();
            string defaultPath = AssetDatabase.GetAssetPath(defaultRenderer);
            string cameraPath = AssetDatabase.GetAssetPath(cameraRenderer);
            AssetDatabase.ImportAsset(defaultPath, ImportAssetOptions.ForceUpdate);
            AssetDatabase.ImportAsset(cameraPath, ImportAssetOptions.ForceUpdate);
            defaultRenderer = AssetDatabase.LoadAssetAtPath<ScriptableObject>(defaultPath);
            cameraRenderer = AssetDatabase.LoadAssetAtPath<ScriptableObject>(cameraPath);
            Require(FeatureId(defaultRenderer) == defaultId && FeatureId(cameraRenderer) == cameraId, "Feature references did not survive save/reimport");

            var qualityDefault = fixture.Renderer("QualityDefault");
            var qualityCamera = fixture.Renderer("QualityCamera");
            var qualityPipeline = fixture.Pipeline("QualityPipeline", 0, qualityDefault, qualityCamera);
            string graphicsBefore = EditorJsonUtility.ToJson(OnlyFeature(defaultRenderer));
            QualitySettings.renderPipeline = qualityPipeline;
            fixture.CameraRenderer(1);
            Ensure(fixture.camera);
            Require(Active(OnlyFeature(qualityDefault)) && Active(OnlyFeature(qualityCamera)), "Quality override pipeline was not configured");
            Require(EditorJsonUtility.ToJson(OnlyFeature(defaultRenderer)) == graphicsBefore && FeatureCount(unrelated) == 0,
                "Quality setup modified an inactive pipeline");

            // Built-in rendering needs only the camera component, and must leave stored URP assets alone.
            QualitySettings.renderPipeline = null; GraphicsSettings.defaultRenderPipeline = null;
            Require(Ensure(fixture.camera, out string builtInError), "Built-in pipeline incorrectly requires a URP feature: " + builtInError);
            Require(FeatureCount(unused) == 0 && FeatureCount(unrelated) == 0, "Built-in setup edited URP renderer assets");

            // Exercise the real window apply path, including Scene View camera override values.
            GraphicsSettings.defaultRenderPipeline = pipeline;
            fixture.CameraRenderer(-1);
            fixture.view = ScriptableObject.CreateInstance<SceneView>();
            fixture.view.ShowUtility();
            foreach (var previous in fixture.previousMainCameras)
                if (previous != null) previous.tag = "Untagged";
            fixture.cameraOwner.tag = "MainCamera";
            fixture.camera.enabled = true;
            Require(Camera.main == fixture.camera, "Validation camera was not detected as the Main Camera");
            fixture.window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            Set(fixture.window, "m_TiltShiftEnabled", true);
            Set(fixture.window, "m_BlurMode", 1);
            Set(fixture.window, "m_TiltShiftBlurStrength", 6.25f);
            Set(fixture.window, "m_DoFFocusDistance", 14f);
            authored = EditorJsonUtility.ToJson(OnlyFeature(defaultRenderer));
            Call(fixture.window, "ApplyTiltShiftToSceneView");
            var effect = fixture.view.camera.GetComponent<GaussianSplatTiltShiftEffect>();
            Require(effect != null && effect.effectEnabled, "Window enable did not configure Scene View camera blur");
            Require(effect.blurMode == GaussianSplatTiltShiftEffect.BlurMode.DepthOfField, "Camera override lost the chosen blur mode");
            Near(effect.blurStrength, 6.25f, "Camera override lost blur strength");
            Near(effect.focusDistance, 14f, "Camera override lost focus distance");
            Require(EditorJsonUtility.ToJson(OnlyFeature(defaultRenderer)) == authored, "Window preview overwrote authored renderer settings");
            var saved = fixture.camera.GetComponent<GaussianSplatTiltShiftEffect>();
            Require(saved != null && saved.authoredInSplatBoxEditor && saved.effectEnabled &&
                (saved.hideFlags & HideFlags.DontSaveInBuild) == 0,
                "Camera controls did not create a scene-saved effect for builds");
            Near(saved.focusDistance, 14f, "Window changes did not reach the Game camera");
            Near(saved.blurStrength, 6.25f, "Saved camera blur strength differs from preview");
            Set(fixture.window, "m_DoFFocusDistance", 2f);
            Call(fixture.window, "RefreshCameraBlurSettings", true);
            Near(Get<float>(fixture.window, "m_DoFFocusDistance"), 14f, "Reopening the panel did not load saved camera values");
            GaussianTiltShiftGlobalSettings.Reset();
            GaussianTiltShiftGlobalSettings.CopyFrom(saved);
            Near(GaussianTiltShiftGlobalSettings.FocusDistance, 14f, "VR controls did not load the saved depth of field");
            fixture.cameraOwner.SetActive(false);
            var applier = fixture.cameraOwner.AddComponent<GaussianTiltShiftRuntimeApplier>();
            applier.targetCamera = fixture.camera;
            Call(applier, "Apply");
            Near(saved.blurStrength, 6.25f, "Runtime applier overwrote the authored camera");
            Object.DestroyImmediate(applier);
            fixture.cameraOwner.SetActive(true);
            Require(saved != null, "Disabling the runtime applier destroyed the saved camera effect");
            var previewRenderer = fixture.Renderer("PreviewInstalledRenderer");
            GraphicsSettings.defaultRenderPipeline = fixture.Pipeline("PreviewPipeline", 0, previewRenderer);
            Call(fixture.window, "ApplyTiltShiftToSceneView");
            var previewFeature = OnlyFeature(previewRenderer);
            long previewId = FeatureId(previewRenderer);
            Require(Active(previewFeature) && !Get<bool>(Settings(previewFeature), "enabled"),
                "Window enable did not install an active, camera-controlled blur pass");
            VerifyRepeatedCreate(previewFeature);
            // Unity can remove image-effect components while setting up a Scene View camera.
            // The pass must still use the saved Main Camera look instead of its old defaults.
            Object.DestroyImmediate(fixture.view.camera.GetComponent<GaussianSplatTiltShiftEffect>());
            var resolved = FeatureType.GetMethod("ResolveCameraEffect", BindingFlags.Static | BindingFlags.NonPublic)
                .Invoke(null, new object[] { fixture.view.camera });
            Require(ReferenceEquals(resolved, saved), "Scene View lost the authored settings when its transient effect was removed");
            VerifyRenderPassQueue(previewFeature, fixture.view.camera);
            Set(Settings(previewFeature), "enabled", true);
            EditorUtility.SetDirty(previewFeature); AssetDatabase.SaveAssets();
            string previewAuthored = EditorJsonUtility.ToJson(previewFeature);
            Set(fixture.window, "m_TiltShiftEnabled", false);
            Call(fixture.window, "ApplyTiltShiftToSceneView");
            Require(Active(OnlyFeature(previewRenderer)) && FeatureId(previewRenderer) == previewId,
                "Turning off preview disabled or uninstalled the shared renderer feature");
            effect = (GaussianSplatTiltShiftEffect)FeatureType.GetMethod("ResolveCameraEffect",
                BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { fixture.view.camera });
            Require(effect != null && !effect.effectEnabled,
                "Turning off preview did not override an authored enabled renderer effect");
            Require(saved != null && !saved.effectEnabled && saved.authoredInSplatBoxEditor,
                "Turning off Camera Blur did not save an explicit Off on the Game camera");
            Near(saved.focusDistance, 14f, "Disabling blur discarded its authored focus distance");
            VerifyRenderPassQueue(previewFeature, fixture.camera);
            Require(EditorJsonUtility.ToJson(OnlyFeature(previewRenderer)) == previewAuthored &&
                EditorJsonUtility.ToJson(OnlyFeature(defaultRenderer)) == authored && FeatureCount(unrelated) == 0,
                "Turning off preview changed authored or unrelated renderer settings");
        }

        public static void Run()
        {
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                using (var fixture = new Fixture())
                {
                    UndoAndRedo(fixture);
                    ActivePipelineAndPersistence(fixture);
                }
                Require(errors.Count == 0, "Camera Blur validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Camera Blur Feature PASS: active Graphics/quality URP, default/alternate renderer, activation without duplicates, install/reactivation Undo/Redo and stable serialized feature IDs, preserved authored/unrelated settings, Scene View override and URP pass queue/depth, safe toggle-off, built-in pipeline.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
