// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    // CPU geometry coverage; run in an isolated batch project with -executeMethod.
    public static class PolygonMaskGeometryValidation
    {
        const BindingFlags Fields = BindingFlags.Instance | BindingFlags.NonPublic;
        static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
        static void Set(GaussianPolyMask mask, string field, object value) =>
            typeof(GaussianPolyMask).GetField(field, Fields).SetValue(mask, value);
        static readonly Vector3[] Concave = {
            new Vector3(-1, -1, 0), new Vector3(1, -1, 0), new Vector3(1, 0, 0),
            new Vector3(0, 0, 0), new Vector3(0, 1, 0), new Vector3(-1, 1, 0)
        };
        static void Draw(GaussianPolyMask mask, Vector3[] points, Vector3 normal)
        {
            mask.StartDrawing(points[0], normal);
            for (int i = 1; i < points.Length; ++i) mask.AddVertex3D(points[i]);
            mask.ClosePath();
            Require(mask.IsClosed, "Valid polygon did not close.");
        }
        static void SameVertices(GaussianPolyMask mask, Vector3[] expected, string label)
        {
            Require(mask.m_Vertices.Count == expected.Length, label + " changed the vertex count.");
            for (int i = 0; i < expected.Length; ++i)
                Require(Vector3.Distance(mask.transform.TransformPoint(mask.m_Vertices[i]), expected[i]) < 0.0001f,
                    label + " moved world vertex " + i);
        }
        static void SameMatrix(Matrix4x4 a, Matrix4x4 b, string label)
        {
            for (int i = 0; i < 16; ++i)
                Require(Mathf.Abs(a[i] - b[i]) < 0.0001f, label + " changed transform element " + i);
        }

        public static void Run()
        {
            Require(Application.isBatchMode, "Run polygon geometry validation in an isolated batch-mode project.");
            var objects = new List<GameObject>();
            GaussianPolyMask NewMask(string name, Transform parent = null)
            {
                var go = new GameObject(name); objects.Add(go);
                if (parent != null) go.transform.SetParent(parent, false);
                return go.AddComponent<GaussianPolyMask>();
            }
            try
            {
                var parent = new GameObject("Polygon geometry scaled parent"); objects.Add(parent);
                parent.transform.SetPositionAndRotation(new Vector3(2, -3, 4), Quaternion.Euler(23, -41, 17));
                parent.transform.localScale = new Vector3(2.3f, 0.7f, 1.4f);
                Vector3 center = new Vector3(1.3f, -0.4f, 6.1f);
                Quaternion planeRotation = Quaternion.Euler(31, 57, -18);
                var points = new Vector3[Concave.Length];
                for (int i = 0; i < points.Length; ++i) points[i] = center + planeRotation * Concave[i];
                var mask = NewMask("Concave polygon", parent.transform);
                mask.transform.localPosition = new Vector3(-2, 1, 0.3f);
                mask.transform.localRotation = Quaternion.Euler(-10, 34, 21);
                mask.transform.localScale = new Vector3(0.8f, 1.1f, 0.6f);
                Draw(mask, points, planeRotation * Vector3.forward);
                SameVertices(mask, points, "Parent-scaled arbitrary-plane normalization");
                Require(mask.IsPointInside(center + planeRotation * new Vector3(-0.5f, 0.5f, 0)), "Concave arm was excluded.");
                Require(!mask.IsPointInside(center + planeRotation * new Vector3(0.5f, 0.5f, 0)), "Concave notch was filled.");
                Require(!mask.IsPointInside(center + planeRotation * new Vector3(1.5f, 0, 0)), "Outside polygon point was included.");
                var reverse = (Vector3[])points.Clone(); Array.Reverse(reverse);
                var reversedMask = NewMask("Reversed polygon", parent.transform);
                Draw(reversedMask, reverse, planeRotation * Vector3.forward);
                SameVertices(reversedMask, reverse, "Reversed normalization");
                Require(reversedMask.IsPointInside(center + planeRotation * new Vector3(-0.5f, 0.5f, 0)) &&
                    !reversedMask.IsPointInside(center + planeRotation * new Vector3(0.5f, 0.5f, 0)), "Winding changed concave containment.");

                foreach (var axis in new[] { GaussianPolyMask.ExtrusionAxis.X, GaussianPolyMask.ExtrusionAxis.Y, GaussianPolyMask.ExtrusionAxis.Z })
                {
                    var manual = NewMask("Manual axis " + axis, parent.transform);
                    Set(manual, "m_ExtrusionAxis", axis);
                    Draw(manual, points, planeRotation * Vector3.forward);
                    SameVertices(manual, points, "Manual " + axis);
                    Require(manual.EffectiveExtrusionAxis == (uint)axis &&
                        manual.IsPointInside(center + planeRotation * new Vector3(-0.5f, 0.5f, 0)) &&
                        !manual.IsPointInside(center + planeRotation * new Vector3(0.5f, 0.5f, 0)),
                        "Manual axis changed polygon containment: " + axis);
                }

                // These serialized polygons model legacy scenes, where the auto-axis cache
                // was never saved. No ClosePath call can repair the data during this test.
                foreach (uint legacyAxis in new[] { 1u, 2u })
                {
                    var original = NewMask("Legacy axis " + legacyAxis);
                    foreach (var v in Concave)
                        original.m_Vertices.Add(legacyAxis == 1 ? new Vector3(0, v.x, v.y) : new Vector3(v.x, 0, v.y));
                    Set(original, "m_IsClosed", true);
                    string json = JsonUtility.ToJson(original);
                    var reopened = NewMask("Reloaded legacy " + legacyAxis);
                    JsonUtility.FromJsonOverwrite(json, reopened);
                    Require(reopened.EffectiveExtrusionAxis == legacyAxis, "Legacy extrusion axis was lost during serialization.");
                    Vector3 inside = legacyAxis == 1 ? new Vector3(0, -0.5f, 0.5f) : new Vector3(-0.5f, 0, 0.5f);
                    Vector3 outside = legacyAxis == 1 ? new Vector3(0, 0.5f, 0.5f) : new Vector3(0.5f, 0, 0.5f);
                    Require(reopened.IsPointInside(inside) && !reopened.IsPointInside(outside), "Legacy polygon containment changed after serialization.");
                    Require(GaussianCutout.GetShaderData(reopened, Matrix4x4.identity).extrusionAxis == legacyAxis,
                        "Legacy shader data did not preserve extrusion axis.");
                }

                Vector3 shapeCenter = new Vector3(-3, 2, 4);
                Vector3 shapeNormal = new Vector3(1, 2, 3).normalized;
                Vector3 right = Vector3.Cross(shapeNormal, Vector3.up).normalized;
                Vector3 up = Vector3.Cross(right, shapeNormal).normalized;
                foreach (var shape in new[] { GaussianPolyMask.ShapeType.Box, GaussianPolyMask.ShapeType.Circle,
                    GaussianPolyMask.ShapeType.Hexagon, GaussianPolyMask.ShapeType.Star })
                {
                    var generated = NewMask("Generated " + shape); generated.m_ShapeType = shape;
                    generated.GenerateShape(shapeCenter, shapeNormal, 3.2f);
                    Require(generated.IsClosed && Mathf.Abs(generated.ShapeSize - 3.2f) < 1e-6f, shape + " ignored its size.");
                    Require(generated.IsPointInside(shapeCenter) && !generated.IsPointInside(shapeCenter + right * 4),
                        shape + " failed center/outside containment.");
                    float expectedRadius = shape == GaussianPolyMask.ShapeType.Box ? 1.6f * Mathf.Sqrt(2) : 1.6f;
                    float maxRadius = 0;
                    foreach (var v in generated.m_Vertices)
                    {
                        Vector3 delta = generated.transform.TransformPoint(v) - shapeCenter;
                        Require(Mathf.Abs(Vector3.Dot(delta, shapeNormal)) < 0.0001f, shape + " moved off the drawing plane.");
                        maxRadius = Mathf.Max(maxRadius, delta.magnitude);
                    }
                    Require(Mathf.Abs(maxRadius - expectedRadius) < 0.0001f, shape + " size changed during normalization.");
                    Set(generated, "m_CutDepth", 0.4f);
                    Require(generated.IsPointInside(shapeCenter + shapeNormal * 0.3f) &&
                        !generated.IsPointInside(shapeCenter + shapeNormal * 0.5f), shape + " ignored depth.");
                    if (shape == GaussianPolyMask.ShapeType.Star)
                    {
                        float angle = Mathf.PI / 5;
                        Require(!generated.IsPointInside(shapeCenter + (right * Mathf.Cos(angle) + up * Mathf.Sin(angle)) * 1.3f),
                            "Star notch was filled as a convex shape.");
                    }
                }

                var adjusted = NewMask("Adjusted polygon"); adjusted.m_ShapeType = GaussianPolyMask.ShapeType.Box;
                adjusted.GenerateShape(Vector3.zero, Vector3.forward, 2);
                Set(adjusted, "m_ExpansionX", 0.5f); Set(adjusted, "m_ExpansionY", 1.5f);
                Set(adjusted, "m_OffsetX", 0.3f); Set(adjusted, "m_OffsetY", -0.2f); Set(adjusted, "m_CutDepth", 0.4f);
                Vector3 World(float x, float y, float z) => adjusted.transform.TransformPoint(new Vector3(x, y, z));
                Require(adjusted.IsPointInside(World(0.3f, -0.2f, 0.39f)), "Offset/depth center excluded.");
                Require(!adjusted.IsPointInside(World(0.81f, -0.2f, 0)) && !adjusted.IsPointInside(World(0.3f, 1.31f, 0)),
                    "Expansion extents ignored.");
                Require(!adjusted.IsPointInside(World(0.3f, -0.2f, 0.41f)), "Cut depth ignored.");
                adjusted.m_Invert = true;
                Require(adjusted.IsPointInside(World(0.3f, -0.2f, 0)), "Invert incorrectly changed raw containment.");
                var data = GaussianCutout.GetShaderData(adjusted, Matrix4x4.identity);
                Require(data.typeAndFlags == 0x102 && data.expansionX == 0.5f && data.expansionY == 1.5f &&
                    data.offsetX == 0.3f && data.offsetY == -0.2f && data.cutDepth == 0.4f,
                    "Shader data did not preserve polygon controls.");
                adjusted.Clear();
                Require(!adjusted.IsClosed && !adjusted.IsPointInside(Vector3.zero) && adjusted.GetDisplayVertices().Count == 0 &&
                    GaussianCutout.GetShaderData(adjusted, Matrix4x4.identity).typeAndFlags == uint.MaxValue,
                    "Clear left a polygon or stale display vertices active.");

                var undoMask = NewMask("Undo polygon");
                undoMask.transform.SetPositionAndRotation(new Vector3(1, 2, 3), Quaternion.Euler(12, 24, 36));
                undoMask.transform.localScale = new Vector3(2, 3, 4);
                undoMask.StartDrawing(points[0], planeRotation * Vector3.forward);
                for (int i = 1; i < points.Length; ++i) undoMask.AddVertex3D(points[i]);
                Matrix4x4 before = undoMask.transform.localToWorldMatrix;
                Undo.IncrementCurrentGroup(); int group = Undo.GetCurrentGroup();
                Undo.RecordObjects(new Object[] { undoMask, undoMask.transform }, "Validate polygon close undo");
                undoMask.ClosePath(); Undo.FlushUndoRecordObjects(); Undo.CollapseUndoOperations(group);
                SameVertices(undoMask, points, "Before undo");
                Undo.PerformUndo();
                Require(!undoMask.IsClosed && undoMask.m_IsDrawing, "Undo did not restore drawing state.");
                SameMatrix(undoMask.transform.localToWorldMatrix, before, "Undo close");
                Undo.PerformRedo();
                Require(undoMask.IsClosed, "Redo did not close polygon.");
                SameVertices(undoMask, points, "Redo close");
                Debug.Log("SplatBox polygon geometry, shapes, transform, controls, serialization and Undo PASS");
            }
            finally
            {
                for (int i = objects.Count - 1; i >= 0; --i)
                    if (objects[i] != null) Object.DestroyImmediate(objects[i]);
            }
        }
    }
}
