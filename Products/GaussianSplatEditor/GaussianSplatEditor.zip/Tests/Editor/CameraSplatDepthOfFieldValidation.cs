// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    public static class CameraSplatDepthOfFieldValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const int Width = 384, Height = 192;
        const float Far = 100, NearClip = .1f;
        static string Root => UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";
        static T Get<T>(object obj, string name) => (T)obj.GetType().GetField(name, Flags).GetValue(obj);
        static void Set(object obj, string name, object value) => obj.GetType().GetField(name, Flags).SetValue(obj, value);
        static object Call(object obj, string name, params object[] args) => obj.GetType().GetMethod(name, Flags).Invoke(obj, args);
        static void Require(bool ok, string message) { if (!ok) throw new InvalidOperationException(message); }
        static void Near(float actual, float expected, string message, float tolerance = .002f) => Require(Mathf.Abs(actual - expected) <= tolerance, $"{message}: {actual:G9} != {expected:G9}");
        static uint Pack(float a, float b) => ((uint)Mathf.FloatToHalf(a) << 16) | Mathf.FloatToHalf(b);
        static Vector4 ZParameters => SystemInfo.usesReversedZBuffer
            ? new Vector4(Far / NearClip - 1, 1, (Far / NearClip - 1) / Far, 1 / Far)
            : new Vector4(1 - Far / NearClip, Far / NearClip, (1 - Far / NearClip) / Far, 1 / NearClip);
        static float RawDepth(float eye) => (1 / eye - ZParameters.w) / ZParameters.z;
        [StructLayout(LayoutKind.Sequential)]
        struct ViewData { public Vector4 pos; public uint axis1, axis2, color1, color2; public Vector3 worldPos; public uint splatIdx; }
        static ViewData Point(float x, float y, float depth, Color color, float radius = 5, bool hidden = false) => new ViewData {
            pos = new Vector4((x * 2 / Width - 1) * depth, (y * 2 / Height - 1) * depth, .5f * depth, hidden ? 0 : depth),
            axis1 = Pack(radius, 0), axis2 = Pack(0, radius), color1 = Pack(color.r, color.g), color2 = Pack(color.b, color.a),
            worldPos = new Vector3((x * 2 / Width - 1) * depth, (y * 2 / Height - 1) * depth, depth) };
        static RenderTexture Target(string name, RenderTextureFormat format = RenderTextureFormat.ARGBHalf)
        {
            var rt = new RenderTexture(Width, Height, 0, format, RenderTextureReadWrite.Linear) { name = name, filterMode = FilterMode.Bilinear, wrapMode = TextureWrapMode.Clamp };
            rt.Create(); return rt;
        }
        static Color[] Read(RenderTexture target)
        {
            var prior = RenderTexture.active; var image = new Texture2D(target.width, target.height, TextureFormat.RGBAFloat, false, true);
            try { RenderTexture.active = target; image.ReadPixels(new Rect(0, 0, target.width, target.height), 0, 0, false); image.Apply(false); return image.GetPixels(); }
            finally { RenderTexture.active = prior; Object.DestroyImmediate(image); }
        }
        static void SaveImage(string name, Color[] pixels)
        {
            string folder = Path.Combine(Path.GetTempPath(), "SplatBox-quality-analysis"); Directory.CreateDirectory(folder);
            var image = new Texture2D(Width, Height, TextureFormat.RGBA32, false, true);
            try { image.SetPixels(pixels); image.Apply(); File.WriteAllBytes(Path.Combine(folder, name + ".png"), image.EncodeToPNG()); }
            finally { Object.DestroyImmediate(image); }
        }
        sealed class DrawFixture : IDisposable
        {
            readonly object fallback;
            readonly GraphicsBuffer indices;
            readonly Material material;
            GraphicsBuffer views;
            public readonly RenderTexture color = Target("DoF color"), depth = Target("DoF weighted eye depth");
            public readonly Texture2D sceneDepth = new Texture2D(Width, Height, TextureFormat.RFloat, false, true);
            readonly Texture previousDepth = Shader.GetGlobalTexture("_CameraDepthTexture");
            readonly Vector4 previousProjection = Shader.GetGlobalVector("_ProjectionParams"), previousZ = Shader.GetGlobalVector("_ZBufferParams"), previousOrtho = Shader.GetGlobalVector("unity_OrthoParams");
            public DrawFixture(string shader)
            {
                var type = typeof(DistantPointCloudValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fallback = Activator.CreateInstance(type, Flags, null, null, null);
                material = new Material(AssetDatabase.LoadAssetAtPath<Shader>(Root + shader));
                Require(material.shader != null && material.shader.isSupported, "Unsupported DoF splat shader: " + shader);
                Call(fallback, "Configure", material); indices = Get<GraphicsBuffer>(fallback, "indices");
                SetOpaqueDepth(Far);
            }
            public void SetOpaqueDepth(float eye)
            {
                var values = new Color[Width * Height]; for (int i = 0; i < values.Length; i++) values[i] = new Color(RawDepth(eye), 0, 0, 1);
                sceneDepth.SetPixels(values); sceneDepth.Apply(false);
            }
            public void Draw(ViewData[] points, bool mrt = true, bool occlusion = false)
            {
                views?.Dispose(); views = new GraphicsBuffer(GraphicsBuffer.Target.Structured, points.Length, Marshal.SizeOf<ViewData>());
                for (int i = 0; i < points.Length; i++) points[i].splatIdx = (uint)i;
                views.SetData(points); material.SetBuffer("_SplatViewData", views); material.SetInt("_SplatCount", points.Length);
                material.SetInt("_SplatBitsValid", 0); material.SetInt("_LodDistantPointCloud", 0);
                material.SetInt("_SceneDepthOcclusion", occlusion ? 1 : 0); material.SetInt("_SceneDepthTextureValid", 1);
                material.SetTexture("_CameraDepthTexture", sceneDepth); material.SetVector("_CameraDepthTexture_TexelSize", new Vector4(1f / Width, 1f / Height, Width, Height));
                material.SetVector("_SplatRenderTargetSize", new Vector4(Width, Height, 1f / Width, 1f / Height));
                bool keyword = Shader.IsKeywordEnabled("SPLAT_DOF_DEPTH");
                using var cmd = new CommandBuffer { name = "Validate splat DoF MRT" };
                if (mrt) cmd.SetRenderTarget(new[] { new RenderTargetIdentifier(color), new RenderTargetIdentifier(depth) }, BuiltinRenderTextureType.None);
                else cmd.SetRenderTarget(color);
                cmd.SetViewport(new Rect(0, 0, Width, Height)); cmd.ClearRenderTarget(false, true, Color.clear);
                cmd.SetViewProjectionMatrices(Matrix4x4.Scale(new Vector3(1, 1, -1)), Matrix4x4.identity);
                cmd.SetGlobalVector("_ScreenParams", new Vector4(Width, Height, 1 + 1f / Width, 1 + 1f / Height));
                cmd.SetGlobalVector("_ScaledScreenParams", new Vector4(Width, Height, 1 + 1f / Width, 1 + 1f / Height));
                cmd.SetGlobalVector("_ProjectionParams", new Vector4(1, NearClip, Far, 1 / Far));
                cmd.SetGlobalVector("_ZBufferParams", ZParameters); cmd.SetGlobalVector("unity_OrthoParams", Vector4.zero);
                cmd.SetGlobalTexture("_CameraDepthTexture", sceneDepth);
                if (mrt) cmd.EnableShaderKeyword("SPLAT_DOF_DEPTH"); else cmd.DisableShaderKeyword("SPLAT_DOF_DEPTH");
                cmd.DrawProcedural(indices, Matrix4x4.identity, material, 0, MeshTopology.Triangles, 6, points.Length);
                if (keyword) cmd.EnableShaderKeyword("SPLAT_DOF_DEPTH"); else cmd.DisableShaderKeyword("SPLAT_DOF_DEPTH");
                Graphics.ExecuteCommandBuffer(cmd);
            }
            public void Dispose()
            {
                if (RenderTexture.active == color || RenderTexture.active == depth) RenderTexture.active = null;
                views?.Dispose(); Object.DestroyImmediate(material); color.Release(); depth.Release(); Object.DestroyImmediate(color); Object.DestroyImmediate(depth);
                Object.DestroyImmediate(sceneDepth); ((IDisposable)fallback).Dispose();
                Shader.SetGlobalTexture("_CameraDepthTexture", previousDepth); Shader.SetGlobalVector("_ProjectionParams", previousProjection);
                Shader.SetGlobalVector("_ZBufferParams", previousZ); Shader.SetGlobalVector("unity_OrthoParams", previousOrtho);
            }
        }
        static void WeightedDepth(string shader)
        {
            using var f = new DrawFixture(shader);
            var overlap = new[] { Point(Width / 2, Height / 2, 3, new Color(1, 0, 0, .55f), 12), Point(Width / 2, Height / 2, 15, new Color(0, 0, 1, .6f), 12) };
            f.Draw(overlap); var color = Read(f.color); var depth = Read(f.depth); int covered = 0;
            for (int i = 0; i < color.Length; i++)
            {
                Near(depth[i].a, color[i].a, "MRT coverage differs from visible color", .002f);
                if (color[i].a < .04f) continue;
                covered++; Near(depth[i].r * Far, color[i].r * 3 + color[i].b * 15, "Weighted depth disagrees with alpha/color contributions", .025f);
            }
            Require(covered > 150, "MRT fixture produced too few covered pixels");
            int center = Height / 2 * Width + Width / 2;
            float eye = depth[center].r / depth[center].a * Far;
            Require(eye > 3.5f && eye < 10, "DoF depth did not preserve transparent front/back contributions");
            f.Draw(overlap, false); var without = Read(f.color);
            for (int i = 0; i < color.Length; i++)
            {
                Near(without[i].r, color[i].r, "Depth MRT changed splat red", .002f);
                Near(without[i].g, color[i].g, "Depth MRT changed splat green", .002f);
                Near(without[i].b, color[i].b, "Depth MRT changed splat blue", .002f);
                Near(without[i].a, color[i].a, "Depth MRT changed splat alpha", .002f);
            }
            f.Draw(new[] { Point(Width / 2, Height / 2, 3, Color.white, 12, true), Point(Width / 2, Height / 2, 15, new Color(1, 1, 1, 0), 12) });
            foreach (var sample in Read(f.depth)) Near(sample.a, 0, "Hidden/transparent splats wrote DoF depth", 0);
            f.SetOpaqueDepth(1); f.Draw(overlap, true, true);
            foreach (var sample in Read(f.depth)) Near(sample.a, 0, "Occluded splats wrote DoF depth", 0);
        }
        static float Contrast(Color[] pixels, int panel)
        {
            int x0 = panel * Width / 3 + 18, x1 = (panel + 1) * Width / 3 - 18;
            return ContrastRegion(pixels, new RectInt(x0, 30, x1 - x0, Height - 60));
        }
        static float ContrastRegion(Color[] pixels, RectInt region)
        {
            double sum = 0; int count = 0;
            for (int y = region.yMin; y < region.yMax; y++) for (int x = region.xMin; x < region.xMax - 1; x++)
            { sum += Math.Abs(pixels[y * Width + x].r - pixels[y * Width + x + 1].r); count++; }
            return (float)(sum / count);
        }
        static Color[] Blur(DrawFixture f, Material material, RenderTexture output, float focus, float near = 1, float far = 1, bool valid = true)
        {
            material.SetInt("_GaussianSplatDofDepthValid", valid ? 1 : 0); material.SetTexture("_GaussianSplatDofDepth", f.depth); material.SetFloat("_GaussianSplatDofDepthFlipY", 0);
            material.SetTexture("_CameraDepthTexture", f.sceneDepth); Shader.SetGlobalTexture("_CameraDepthTexture", f.sceneDepth);
            material.SetFloat("_BlurMode", 1); material.SetFloat("_FocusDistance", focus); material.SetFloat("_FocusRange", 2);
            material.SetFloat("_NearBlurStrength", near); material.SetFloat("_FarBlurStrength", far); material.SetFloat("_BlurStrength", 25);
            material.SetFloat("_SaturationBoost", 1); material.SetFloat("_ContrastBoost", 1); material.SetFloat("_VignetteStrength", 0);
            material.SetFloat("_BlurSamples", 12); material.SetFloat("_BokehShape", 0);
            var prior = RenderTexture.active;
            try { Graphics.Blit(f.color, output, material, 0); return Read(output); }
            finally { RenderTexture.active = prior; }
        }
        static void FocusContrast()
        {
            using var f = new DrawFixture("Resources/RenderSplats.shader");
            var points = new List<ViewData>(); float[] depths = { 3, 8, 15 };
            for (int p = 0; p < 3; p++) for (int y = 12; y < Height - 12; y += 2)
                for (int x = p * Width / 3 + 8; x < (p + 1) * Width / 3 - 8; x += 2)
                {
                    float value = (((x / 4) + (y / 4)) & 1) == 0 ? .1f : .95f;
                    points.Add(Point(x, y, depths[p], new Color(value, value, value, .95f), 1.1f));
                }
            f.SetOpaqueDepth(8); f.Draw(points.ToArray()); var baseline = Read(f.color);
            var material = new Material(AssetDatabase.LoadAssetAtPath<Shader>(Root + "Resources/GaussianTiltShiftBuiltin.shader")); var output = Target("DoF blurred panels");
            try
            {
                Require(material.FindPass("TiltShift_Builtin") == 0, "Direct built-in fixture selected the URP subshader");
                ShaderUtil.CompilePass(material, 0, true);
                Require(ShaderUtil.IsPassCompiled(material, 0), "Built-in DoF shader did not compile");
                var focused = Blur(f, material, output, 8);
                SaveImage("dof-splats-original", baseline); SaveImage("dof-splats-focus8", focused);
                Debug.Log($"SplatBox direct DoF contrast baseline={Contrast(baseline, 0):G6},{Contrast(baseline, 1):G6},{Contrast(baseline, 2):G6}; focus8={Contrast(focused, 0):G6},{Contrast(focused, 1):G6},{Contrast(focused, 2):G6}");
                Require(Contrast(focused, 0) < Contrast(baseline, 0) * .93f && Contrast(focused, 2) < Contrast(baseline, 2) * .95f, "Near/far splat panels did not blur by actual splat depth");
                Require(Contrast(focused, 1) > Contrast(baseline, 1) * .94f, "Focused splat panel lost sharpness");
                var zero = Blur(f, material, output, 8, 0, 0);
                for (int p = 0; p < 3; p++) Require(Contrast(zero, p) > Contrast(baseline, p) * .94f, "Zero near/far strength still blurred splats");
                var fallback = Blur(f, material, output, 8, 1, 1, false);
                for (int p = 0; p < 3; p++) Require(Contrast(fallback, p) > Contrast(baseline, p) * .94f, "Invalid splat texture did not fall back to opaque focus depth");
                var moved = Blur(f, material, output, 3);
                Require(Contrast(moved, 0) > Contrast(focused, 0) * 1.04f && Contrast(moved, 1) < Contrast(focused, 1) * .95f, "Moving focus failed to switch the sharp splat panel");
                SaveImage("dof-splats-original", baseline); SaveImage("dof-splats-focus8", focused); SaveImage("dof-splats-focus3", moved);
                points.Clear();
                for (int y = 10; y < Height - 10; y += 2) for (int x = 10; x < Width - 10; x += 2)
                {
                    float value = (((x / 4) + (y / 4)) & 1) == 0 ? .1f : .95f;
                    points.Add(Point(x, y, y > Height / 2 ? 3 : 15, new Color(value, value, value, .95f), 1.1f));
                }
                f.SetOpaqueDepth(3); f.Draw(points.ToArray()); baseline = Read(f.color); var asymmetric = Blur(f, material, output, 3);
                var top = new RectInt(30, Height / 2 + 20, Width - 60, Height / 2 - 40);
                var bottom = new RectInt(30, 20, Width - 60, Height / 2 - 40);
                // The synthetic clip-space draw may invert Y at the render target on different graphics APIs.
                // Resolve which half is near from the actual attachment, then verify the blur follows it.
                var depthImage = Read(f.depth);
                Color topDepth = depthImage[(Height * 3 / 4) * Width + Width / 2];
                Color bottomDepth = depthImage[(Height / 4) * Width + Width / 2];
                float topEye = topDepth.r / topDepth.a * Far, bottomEye = bottomDepth.r / bottomDepth.a * Far;
                bool topNear = topEye < bottomEye;
                Near(Mathf.Min(topEye, bottomEye), 3, "Asymmetric near depth", .03f);
                Near(Mathf.Max(topEye, bottomEye), 15, "Asymmetric far depth", .03f);
                RectInt nearRegion = topNear ? top : bottom, farRegion = topNear ? bottom : top;
                SaveImage("dof-splats-asymmetric", asymmetric);
                Require(ContrastRegion(asymmetric, nearRegion) > ContrastRegion(baseline, nearRegion) * .94f &&
                    ContrastRegion(asymmetric, farRegion) < ContrastRegion(baseline, farRegion) * .93f,
                    "Vertical asymmetric depth sampled the wrong side of the source image");
            }
            finally { Object.DestroyImmediate(material); if (RenderTexture.active == output) RenderTexture.active = null; output.Release(); Object.DestroyImmediate(output); }
        }

        static float StrongestDepth(Color[] depth, Camera camera, Vector3 world, out float alpha)
        {
            Vector3 screen = camera.WorldToScreenPoint(world); int x = Mathf.RoundToInt(screen.x), y = Mathf.RoundToInt(screen.y);
            Color strongest = Color.clear;
            for (int dy = -4; dy <= 4; dy++) for (int dx = -4; dx <= 4; dx++)
            {
                int px = Mathf.Clamp(x + dx, 0, Width - 1), py = Mathf.Clamp(y + dy, 0, Height - 1);
                Color value = depth[py * Width + px]; if (value.a > strongest.a) strongest = value;
            }
            alpha = strongest.a; return strongest.a > 0 ? strongest.r / strongest.a * camera.farClipPlane : 0;
        }
        static void BuiltinPagedAndSculpt()
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GameObject cameraOwner = null, secondOwner = null, opaque = null;
            Material opaqueMaterial = null; RenderTexture target = Target("Built-in paged DoF"), secondTarget = Target("Second camera DoF");
            try
            {
                var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer");
                cameraOwner = new GameObject("Built-in DoF validation camera"); var camera = cameraOwner.AddComponent<Camera>();
                camera.enabled = false; camera.tag = "MainCamera"; camera.targetTexture = target;
                camera.nearClipPlane = NearClip; camera.farClipPlane = Far; camera.fieldOfView = 60;
                camera.backgroundColor = Color.black; camera.clearFlags = CameraClearFlags.SolidColor;
                typeof(PagedSmudgeValidation).GetMethod("Preload", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer, camera });
                var effect = cameraOwner.AddComponent<GaussianSplatTiltShiftEffect>(); effect.effectEnabled = true;
                effect.blurMode = GaussianSplatTiltShiftEffect.BlurMode.TiltShift; effect.blurStrength = 25;
                Require(Call(effect, "PrepareSplatDofDepth", camera) == null, "Tilt Shift allocated a splat depth texture");
                effect.blurMode = GaussianSplatTiltShiftEffect.BlurMode.DepthOfField; effect.focusDistance = 5; effect.focusRange = .5f;
                effect.nearBlurStrength = effect.farBlurStrength = 1; effect.vignetteStrength = 0;
                effect.saturationBoost = effect.contrastBoost = 1;
                camera.Render(); var sharp = Read(target);
                var depthTarget = Get<RenderTexture>(effect, "m_SplatDofDepth");
                Require(depthTarget != null && depthTarget.IsCreated(), "Native built-in camera did not create DoF depth");
                // GetMaterial() refreshes bindings after the frame, so inspect the consumed material directly.
                Require(!Get<bool>(effect, "m_SplatDofDepthReady") && Get<Material>(effect, "m_Material").GetInt("_GaussianSplatDofDepthValid") == 1,
                    "Image effect did not consume the freshly rendered splat depth");
                Near(StrongestDepth(Read(depthTarget), camera, new Vector3(0, 0, 5), out float covered), 5, "Native paged eye depth", .04f);
                Require(covered > .1f && !Shader.IsKeywordEnabled("SPLAT_DOF_DEPTH"), "Native depth coverage/keyword cleanup failed");
                effect.focusDistance = 1; camera.Render(); var blurred = Read(target);
                SaveImage("dof-paged-native-focus5", sharp); SaveImage("dof-paged-native-focus1", blurred);
                Debug.Log($"DoF native contrast sharp={ContrastRegion(sharp, new RectInt(0, 0, Width, Height))}, blur={ContrastRegion(blurred, new RectInt(0, 0, Width, Height))}, color={sharp[Height / 2 * Width + Width / 2]}");
                Require(ReferenceEquals(depthTarget, Get<RenderTexture>(effect, "m_SplatDofDepth")), "Same-size camera frame replaced its depth target");
                Require(ContrastRegion(blurred, new RectInt(0, 0, Width, Height)) < ContrastRegion(sharp, new RectInt(0, 0, Width, Height)) * .95f,
                    "Native built-in splats did not blur when focus moved away");
                SaveImage("dof-paged-native-focus5", sharp); SaveImage("dof-paged-native-focus1", blurred);

                renderer.SmudgeSplatsGPU(new Vector3(-.8f, 0, 5), new Vector3(0, .5f, -2), .3f, 0, 1);
                renderer.SmudgeSplatsGPU(new Vector3(.8f, 0, 5), new Vector3(0, -.5f, 3), .3f, 0, 1);
                effect.focusDistance = 5; camera.Render(); var sculptDepth = Read(Get<RenderTexture>(effect, "m_SplatDofDepth"));
                Near(StrongestDepth(sculptDepth, camera, new Vector3(-.8f, .5f, 3), out covered), 3, "Sculpted near/top page used old or flipped depth", .05f);
                Require(covered > .1f, "Sculpted near page not covered");
                Near(StrongestDepth(sculptDepth, camera, new Vector3(.8f, -.5f, 8), out covered), 8, "Sculpted far/bottom page used old or flipped depth", .05f);
                Require(covered > .1f, "Sculpted far page not covered");

                opaque = GameObject.CreatePrimitive(PrimitiveType.Quad); opaque.transform.position = new Vector3(0, 0, 4);
                opaque.transform.localScale = new Vector3(.5f, .5f, 1);
                opaqueMaterial = new Material(Shader.Find("Standard")); opaqueMaterial.color = Color.white;
                opaque.GetComponent<Renderer>().sharedMaterial = opaqueMaterial; renderer.m_OccludeBySceneDepth = true;
                camera.Render(); var occluded = Read(Get<RenderTexture>(effect, "m_SplatDofDepth"));
                StrongestDepth(occluded, camera, new Vector3(0, 0, 5), out covered);
                Require(covered < .005f, "Opaque geometry in front of splats did not remove their DoF contribution");
                Object.DestroyImmediate(opaque); opaque = null;

                depthTarget = Get<RenderTexture>(effect, "m_SplatDofDepth"); depthTarget.Release();
                Require(ReferenceEquals(Call(effect, "PrepareSplatDofDepth", camera), depthTarget) && depthTarget.IsCreated(),
                    "Lost native depth target was not recreated at unchanged dimensions");
                var resizedTarget = new RenderTexture(Width / 2, Height / 2, 0); resizedTarget.Create();
                try
                {
                    camera.targetTexture = resizedTarget;
                    var resized = (RenderTexture)Call(effect, "PrepareSplatDofDepth", camera);
                    Require(depthTarget == null && resized.width == Width / 2 && resized.height == Height / 2,
                        "Camera resize retained the previous depth target");
                    camera.targetTexture = target;
                    var restored = (RenderTexture)Call(effect, "PrepareSplatDofDepth", camera);
                    Require(resized == null && restored.width == Width && restored.height == Height,
                        "Restoring camera size retained a mismatched depth target");
                }
                finally { camera.targetTexture = target; resizedTarget.Release(); Object.DestroyImmediate(resizedTarget); }
                effect.effectEnabled = false; camera.Render();
                Require(Get<RenderTexture>(effect, "m_SplatDofDepth") == null && !Shader.IsKeywordEnabled("SPLAT_DOF_DEPTH"), "Disabled DoF retained allocation or shader keyword");
                Material releasedMaterial = effect.GetMaterial(); effect.enabled = false;
                Require(releasedMaterial == null && Get<Material>(effect, "m_Material") == null, "Disabling the camera effect retained its material");

                secondOwner = new GameObject("Empty DoF validation camera"); var second = secondOwner.AddComponent<Camera>();
                second.enabled = false; second.targetTexture = secondTarget; second.backgroundColor = Color.black; second.clearFlags = CameraClearFlags.SolidColor;
                var secondEffect = secondOwner.AddComponent<GaussianSplatTiltShiftEffect>(); secondEffect.blurMode = GaussianSplatTiltShiftEffect.BlurMode.DepthOfField;
                secondEffect.vignetteStrength = 0;
                var compute = Get<ComputeShader>(renderer, "m_CSBoxUtil");
                try
                {
                    // Keep registration/camera hooks alive while making this renderer ineligible.
                    Set(renderer, "m_CSBoxUtil", null); second.Render();
                    Require(Get<RenderTexture>(secondEffect, "m_SplatDofDepth") == null && !Get<bool>(secondEffect, "m_SplatDofDepthReady"),
                        "Second camera inherited another camera's splat depth");
                    var secondMaterial = secondEffect.GetMaterial();
                    // The texture is a shader uniform, not a Properties texture, so GetTexture does not expose it.
                    // Verify the invalid flag and actual camera output instead of a hidden material binding.
                    Require(secondMaterial.GetInt("_GaussianSplatDofDepthValid") == 0,
                        "No-depth fallback retained a valid depth flag");
                    foreach (var value in Read(secondTarget)) Require(value.maxColorComponent <= 1.001f && value.r < .002f && value.g < .002f && value.b < .002f, "Empty camera replayed stale splat color");
                    Require(Get<CommandBuffer>(GaussianSplatRenderSystem.instance, "m_CommandBuffer").sizeInBytes == 0,
                        "No-splats camera retained prior draw commands");
                }
                finally { Set(renderer, "m_CSBoxUtil", compute); }
            }
            finally
            {
                if (opaque != null) Object.DestroyImmediate(opaque); if (opaqueMaterial != null) Object.DestroyImmediate(opaqueMaterial);
                if (secondOwner != null) Object.DestroyImmediate(secondOwner); if (cameraOwner != null) Object.DestroyImmediate(cameraOwner);
                (fixture as IDisposable)?.Dispose(); if (RenderTexture.active == target || RenderTexture.active == secondTarget) RenderTexture.active = null;
                target.Release(); secondTarget.Release(); Object.DestroyImmediate(target); Object.DestroyImmediate(secondTarget);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            }
        }
        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders && SystemInfo.supportedRenderTargetCount >= 2,
                "Use an isolated batch editor with a graphics device and MRT support");
            var errors = new List<string>(); Application.LogCallback observe = (m, s, t) => { if (t == LogType.Error || t == LogType.Exception || t == LogType.Assert) errors.Add(m); };
            Application.logMessageReceived += observe;
            var graphics = GraphicsSettings.defaultRenderPipeline; var quality = QualitySettings.renderPipeline;
            try
            {
                GraphicsSettings.defaultRenderPipeline = null; QualitySettings.renderPipeline = null;
                typeof(RenderPipelineManager).GetMethod("CleanupRenderPipeline", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).Invoke(null, null);
                var failed = new List<string>();
                void Check(string name, Action run) { try { run(); } catch (Exception e) { failed.Add(name + ": " + e); Debug.LogError(name + ": " + e); } }
                foreach (var shader in new[] { "Resources/RenderSplats.shader", "Resources/RenderSplatsRelight.shader", "Shaders/RenderGaussianSplats.shader", "Shaders/Relight/RenderGaussianSplats.shader" }) WeightedDepth(shader);
                Check("Direct focus contrast", FocusContrast); Check("Native built-in paged/sculpt", BuiltinPagedAndSculpt);
                Require(failed.Count == 0, string.Join(" | ", failed));
                Require(errors.Count == 0, "DoF validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Camera Splat DoF PASS: four shader MRT/color parity, weighted transparency/occlusion, focus contrast/control/UV orientation, native built-in paged/sculpted depth and opaque geometry, target-loss recovery, disabled and second-camera isolation.");
            }
            finally
            {
                GraphicsSettings.defaultRenderPipeline = graphics; QualitySettings.renderPipeline = quality;
                typeof(RenderPipelineManager).GetMethod("TryPrepareRenderPipeline", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
                    .Invoke(null, new object[] { GraphicsSettings.currentRenderPipeline });
                Application.logMessageReceived -= observe;
            }
        }
    }
}
