// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    // CPU-only regression checks. Run with Unity -batchmode -nographics -projectPath <project>
    // -executeMethod GaussianSplatting.Tests.PagedLodTraversalValidation.Run -quit.
    public static class PagedLodTraversalValidation
    {
        public static void Run()
        {
            ValidatePrefixCoverage();
            ValidateTraversalLimits();
            ValidateStereoUnion();
            ValidateVisibleChildBudget();
            ValidateEmptySelections();
            ValidateGlobalBudget();
            ValidateProjection();
            ValidateViewportFoveation();
            ValidateRawStereoOverride();
            ValidateBurstParity();
            ValidateDepthFirstFrontier();
            ValidateHeapRemovalParity();
            ValidateCancellation();
            ValidateCompleteFrontier();
            ValidatePagedCopyBoundary();
            ValidateEditorPreviewCoverage();
            Debug.Log("SplatBox paged traversal PASS: complete prefix coverage, progressive traversal limits, stereo union, visible-child budget, empty views, stand-in filters, projection sizing and viewport foveation.");
        }

        static void ValidateEditorPreviewCoverage()
        {
            var policy = typeof(SplatBoxRenderer).GetMethod("LodFrustumCullForEditorPreview",
                BindingFlags.Static | BindingFlags.NonPublic);
            Require(policy != null, "Editor preview culling policy is missing.");
            bool previewCull = (bool)policy.Invoke(null, new object[] { true, false });
            Require(!previewCull && (bool)policy.Invoke(null, new object[] { true, true }) &&
                    !(bool)policy.Invoke(null, new object[] { false, true }),
                "Editor preview must keep all directions without changing Play mode settings.");

            // Two separate roots model pages on opposite sides of the driving camera.
            var pages = new[] { Page(new LodTreeRuntime { nodes = new[] { Node(-10) } }, 0),
                                Page(new LodTreeRuntime { nodes = new[] { Node(10) } }, 1) };
            var view = View();
            view.frustumCull = previewCull;
            view.cullPlanes = new[] { new float4(1, 0, 0, 0) };
            var output = new LodActiveSplatRef[2];
            Require(Select(pages, view, 2, output) == 2,
                "Editor preview lost the page outside the driving camera's frustum.");
            view.frustumCull = true;
            Require(Select(pages, view, 2, output) == 1,
                "Play mode frustum culling did not exclude the outside page.");
        }

        static void ValidatePagedCopyBoundary()
        {
            // The coarse centre is outside the copied area even though one of its leaves is
            // inside. A normal distant LoD selection stops at that invisible parent.
            var nodes = new[] { Node(0f, 1f, 2, 1), Node(-0.4f), Node(0.4f) };
            var pages = new[] { Page(new LodTreeRuntime { nodes = nodes }) };
            var output = new LodActiveSplatRef[8];
            var workspace = new SplatBoxLodTraverser.Workspace();
            var view = View();
            view.cameraWorld = new float3(0, 0, -1000);
            int count = SplatBoxLodTraverser.Traverse(pages, 1, view, output.Length, 8f, output, workspace);
            Require(count == 1 && output[0].splatIndex == 0, "Fixture did not select the coarse root without a copy boundary.");
            view.hasCopyBoundary = true;
            view.copyLocalToBox = new float4x4(
                new float4(10, 0, 0, 0), new float4(0, 10, 0, 0),
                new float4(0, 0, 10, 0), new float4(4, 0, -50, 1));
            foreach (var forward in new[] { new float3(0, 0, 1), new float3(1, 0, 0), new float3(0, 0, -1) })
            {
                view.cameraForward = forward;
                count = SplatBoxLodTraverser.Traverse(pages, 1, view, output.Length, 8f, output, workspace);
                Require(count == 1 && output[0].splatIndex == 1,
                    "Copied boundary lost its inside leaf or retained an outside node when the camera turned.");
            }
            Require(!workspace.usedBurst, "Copy selection must use the boundary-aware traversal.");
        }

        // Optional desktop CPU benchmark, separate from the correctness checks. These numbers are
        // not Quest frame times: run the same selection on-device with the Unity profiler as well.
        public static void RunBenchmark()
        {
            const int leavesPerPage = 262144; // Complete 8-ary tree, six subdivision levels.
            const int nodesPerPage = (leavesPerPage * 8 - 1) / 7;
            const int internalNodes = nodesPerPage - leavesPerPage;
            var pages = new SplatBoxLodTraverser.PageContext[32];
            for (int p = 0; p < pages.Length; p++)
            {
                var nodes = new LodTreeNode[nodesPerPage];
                for (int i = 0; i < nodes.Length; i++)
                {
                    float feature = 8f;
                    float3 center = new float3((p % 4 - 1.5f) * 4f, (p / 4 % 4 - 1.5f) * 4f, 10f + p / 16 * 4f);
                    if (i != 0)
                    {
                        LodTreeNode parent = nodes[(i - 1) / 8];
                        int octant = (i - 1) % 8;
                        feature = parent.featureSize * 0.5f;
                        center = parent.center + new float3((octant & 1) == 0 ? -1 : 1,
                            (octant & 2) == 0 ? -1 : 1, (octant & 4) == 0 ? -1 : 1) * parent.featureSize * 0.125f;
                    }
                    nodes[i] = new LodTreeNode
                    {
                        center = center,
                        featureSize = feature,
                        childStart = i < internalNodes ? (uint)(i * 8 + 1) : 0,
                        childCount = i < internalNodes ? (ushort)8 : (ushort)0,
                        flags = i < internalNodes ? LodTreeNode.kFlagMerged : (ushort)0
                    };
                }
                pages[p] = Page(new LodTreeRuntime { nodes = nodes }, p);
            }

            var workspace = new SplatBoxLodTraverser.Workspace();
            var output = new LodActiveSplatRef[500000];
            var view = View();
            var timer = new System.Diagnostics.Stopwatch();
            foreach (int pageCount in new[] { 16, 32 })
            {
                foreach (int budget in new[] { 100000, 250000, 500000 })
                {
                    // Warm up heap capacity and JIT before timing a repeated selection.
                    int count = SplatBoxLodTraverser.Traverse(pages, pageCount, view, budget, 1f, output, workspace);
                    double elapsedMs = 0;
                    for (int repeat = 0; repeat < 3; repeat++)
                    {
                        timer.Restart();
                        count = SplatBoxLodTraverser.Traverse(pages, pageCount, view, budget, 1f, output, workspace);
                        elapsedMs += timer.Elapsed.TotalMilliseconds;
                    }
                    Require(count > 0 && count <= budget, "Large-model traversal exceeded its output budget");
                    Require(!Unity.Burst.BurstCompiler.IsEnabled || workspace.usedBurst,
                        "Burst was enabled but the large-model benchmark used the managed fallback");
                    Debug.Log($"SplatBox traversal desktop benchmark: sourceLeaves={pageCount * leavesPerPage}, " +
                        $"residentNodes={pageCount * nodesPerPage}, budget={budget}, selected={count}, " +
                        $"kernel={(workspace.usedBurst ? "Burst" : "managed")}, meanCpuMs={elapsedMs / 3:0.###}. " +
                        "Synthetic full-residency CPU traversal only; not Quest GPU/frame validation.");
                }
            }
        }

        static SplatBoxLodTraverser.ViewContext View() => new()
        {
            cameraWorld = float3.zero,
            cameraForward = new float3(0, 0, 1),
            pixelsPerUnitAtUnitDistance = 500f,
            pixelScaleFactor = 1000f,
            cosHalfFovY = 0.7f,
            splatScale = 1f
        };

        static SplatBoxLodTraverser.PageContext Page(LodTreeRuntime tree, int slot = 0) => new()
        {
            pageSlot = slot,
            nodes = tree.nodes,
            childTable = tree.childTable,
            childTableStart = tree.childTableStart,
            localToWorld = float4x4.identity,
            lodScale = 1f,
            outsideFoveate = 1f,
            behindFoveate = 1f
        };

        static LodTreeNode Node(float x, float feature = 0.01f, ushort children = 0, uint start = 0) => new()
        {
            center = new float3(x, 0, 5),
            featureSize = feature,
            childCount = children,
            childStart = start
        };

        static int Select(SplatBoxLodTraverser.PageContext[] pages, SplatBoxLodTraverser.ViewContext view,
            int budget, LodActiveSplatRef[] output, float floor = 0f)
        {
            var native = new SplatBoxLodTraverser.Workspace();
            int count = SplatBoxLodTraverser.Traverse(pages, pages.Length, view, budget, floor, output, native);
            Require(!Unity.Burst.BurstCompiler.IsEnabled || native.usedBurst,
                "Burst was enabled but traversal fell back to managed code");
            var managed = new SplatBoxLodTraverser.Workspace();
            var reference = new LodActiveSplatRef[output.Length];
            int expected = SplatBoxLodTraverser.TraverseManaged(pages, pages.Length, view, budget, floor, reference, managed);
            Require(count == expected && native.emittedLeaves == managed.emittedLeaves &&
                native.emittedMerged == managed.emittedMerged && native.droppedMerged == managed.droppedMerged &&
                native.budgetExhausted == managed.budgetExhausted,
                "Native traversal composition differs from the managed reference");
            for (int i = 0; i < count; i++)
                Require(output[i].pageSlot == reference[i].pageSlot && output[i].splatIndex == reference[i].splatIndex,
                    "Native traversal selection/order differs from the managed reference at index " + i);
            Require(native.usedDepthFirst == managed.usedDepthFirst,
                "Native and managed traversal chose different complete-frontier paths");
            CompareBestFirst(pages, view, budget, floor, reference, expected, managed);
            return count;
        }

        static readonly MethodInfo BestFirst = typeof(SplatBoxLodTraverser).GetMethod(
            "TraverseManagedBestFirst", BindingFlags.Static | BindingFlags.NonPublic);

        static void CompareBestFirst(SplatBoxLodTraverser.PageContext[] pages,
            SplatBoxLodTraverser.ViewContext view, int budget, float floor, LodActiveSplatRef[] actual,
            int count, SplatBoxLodTraverser.Workspace workspace, string label = "")
        {
            var expected = new LodActiveSplatRef[actual.Length];
            var baseline = new SplatBoxLodTraverser.Workspace();
            int expectedCount = (int)BestFirst.Invoke(null, new object[]
                { pages, pages.Length, view, budget, floor, expected, baseline });
            Require(count == expectedCount && workspace.emittedLeaves == baseline.emittedLeaves &&
                workspace.emittedMerged == baseline.emittedMerged && workspace.droppedMerged == baseline.droppedMerged &&
                workspace.budgetExhausted == baseline.budgetExhausted &&
                Mathf.Approximately(workspace.exhaustedPixelScale, baseline.exhaustedPixelScale),
                "Complete-frontier traversal changed best-first counts or diagnostics" + label +
                $" actual={count}/{workspace.emittedLeaves}/{workspace.emittedMerged}/{workspace.droppedMerged}/{workspace.budgetExhausted}/{workspace.exhaustedPixelScale:R}" +
                $" expected={expectedCount}/{baseline.emittedLeaves}/{baseline.emittedMerged}/{baseline.droppedMerged}/{baseline.budgetExhausted}/{baseline.exhaustedPixelScale:R}");
            var selected = new HashSet<ulong>();
            for (int i = 0; i < count; i++)
            {
                Require(selected.Add(((ulong)actual[i].pageSlot << 32) | actual[i].splatIndex),
                    "Complete-frontier traversal emitted a duplicate node");
                if (!workspace.usedDepthFirst)
                    Require(actual[i].pageSlot == expected[i].pageSlot && actual[i].splatIndex == expected[i].splatIndex,
                        "Budget fallback changed the original global priority/order");
            }
            for (int i = 0; i < expectedCount; i++)
                Require(selected.Contains(((ulong)expected[i].pageSlot << 32) | expected[i].splatIndex),
                    "Complete-frontier traversal changed the best-first selected set");
        }

        static void ValidateDepthFirstFrontier()
        {
            var pages = new SplatBoxLodTraverser.PageContext[2];
            for (int p = 0; p < pages.Length; p++)
            {
                var nodes = new LodTreeNode[85];
                for (int i = 0; i < nodes.Length; i++)
                    nodes[i] = Node(p == 0 ? -0.25f : 0.25f,
                        i == 0 ? 4f : i < 5 ? 2f : i < 21 ? 1f : 0.02f,
                        i < 21 ? (ushort)4 : (ushort)0, i < 21 ? (uint)(i * 4 + 1) : 0);
                pages[p] = Page(LodTreeRuntime.Build(nodes, true), p);
                pages[p].lodScale = p == 0 ? 1f : 0.4f;
            }
            var original = (LodTreeNode[])pages[0].nodes.Clone();
            var workspace = new SplatBoxLodTraverser.Workspace();
            var output = new LodActiveSplatRef[200];
            // Reuse scratch after success, after a partially emitted failed speculation,
            // after a root reservation failure, and after immutable resident-prefix caps.
            int[] budgets = { 200, 7, 1, 200, 200, 200 };
            int[] caps = { 0, 0, 0, 10, 5, 0 };
            for (int pass = 0; pass < budgets.Length; pass++)
            {
                bool previousExhausted = workspace.budgetExhausted;
                pages[0].nodeLimit = pages[1].nodeLimit = caps[pass];
                int count = SplatBoxLodTraverser.Traverse(pages, pages.Length, View(), budgets[pass], 0,
                    output, workspace);
                Require(workspace.usedDepthFirst == (budgets[pass] == 200 && !previousExhausted),
                    "Budget pressure did not skip repeated DFS, or spare-budget recovery failed to resume DFS");
                Require(!Unity.Burst.BurstCompiler.IsEnabled || workspace.usedBurst,
                    "Depth-first regression unexpectedly used the managed fallback");
                CompareBestFirst(pages, View(), budgets[pass], 0, output, count, workspace);
                var managed = new SplatBoxLodTraverser.Workspace { budgetExhausted = previousExhausted };
                var reference = new LodActiveSplatRef[output.Length];
                int managedCount = SplatBoxLodTraverser.TraverseManaged(pages, pages.Length, View(), budgets[pass],
                    0, reference, managed);
                Require(count == managedCount && workspace.usedDepthFirst == managed.usedDepthFirst,
                    "Reused native depth-first scratch disagrees with managed traversal");
                for (int i = 0; i < count; i++)
                    Require(output[i].pageSlot == reference[i].pageSlot && output[i].splatIndex == reference[i].splatIndex,
                        "Native/managed depth-first ordering differs after scratch reuse");
            }
            for (int i = 0; i < original.Length; i++)
                Require(pages[0].nodes[i].childStart == original[i].childStart &&
                    pages[0].nodes[i].childCount == original[i].childCount && pages[0].nodes[i].flags == original[i].flags,
                    "Complete-frontier traversal mutated the tree shared with selection workers");
            Debug.Log("SplatBox depth-first frontier PASS: exact best-first selected sets, priority-preserving budget fallback, prefixes and scratch reuse.");
        }

        static void ValidateCompleteFrontier()
        {
            var pages = new SplatBoxLodTraverser.PageContext[2];
            for (int p = 0; p < pages.Length; p++)
            {
                var nodes = new LodTreeNode[85];
                for (int i = 0; i < nodes.Length; i++)
                {
                    float feature = i == 0 ? 4f : nodes[(i - 1) / 4].featureSize * 0.5f;
                    float3 center = i == 0 ? new float3(p == 0 ? -1 : 1, 0, 5) :
                        nodes[(i - 1) / 4].center + new float3((i % 4 & 1) == 0 ? -0.1f : 0.1f,
                            (i % 4 & 2) == 0 ? -0.1f : 0.1f, 0);
                    nodes[i] = new LodTreeNode { center = center, featureSize = feature,
                        childCount = i < 21 ? (ushort)4 : (ushort)0,
                        childStart = i < 21 ? (uint)(i * 4 + 1) : 0 };
                }
                pages[p] = Page(LodTreeRuntime.Build(nodes, true), p);
            }
            var output = new LodActiveSplatRef[200];
            var reference = new LodActiveSplatRef[output.Length];
            var native = new SplatBoxLodTraverser.Workspace();
            var managed = new SplatBoxLodTraverser.Workspace();
            foreach (int cap in new[] { 0, 10 })
            foreach (int mode in new[] { 0, 1, 2, 3, 4, 5, 6, 7 })
            foreach (int budget in new[] { 200, 7, 1 })
            foreach (float floor in new[] { 0f, 50f, float.MaxValue })
            {
                pages[0].nodeLimit = pages[1].nodeLimit = cap;
                var view = View();
                view.orthographic = (mode & 1) != 0;
                view.skipMergedSplats = (mode & 2) != 0;
                view.frustumCull = (mode & 4) != 0;
                view.cullPlanes = XFrustum(-1);
                view.rightEyeCullPlanes = XFrustum(1);
                view.maxStandInPixels = mode >= 4 ? 512f : 0f;
                // Explicit complete-frontier attempts must ignore ordinary traversal's last
                // budget-pressure hint and always try DFS, including after a failed attempt.
                native.budgetExhausted = managed.budgetExhausted = true;
                bool fits = SplatBoxLodTraverser.TryTraverseCompleteFrontier(pages, pages.Length,
                    view, budget, floor, output, native, out int count);
                bool expectedFits = SplatBoxLodTraverser.TryTraverseCompleteFrontierManaged(pages, pages.Length,
                    view, budget, floor, reference, managed, out int referenceCount);
                Require(fits == expectedFits && count == referenceCount &&
                    native.budgetExhausted == managed.budgetExhausted &&
                    native.emittedLeaves == managed.emittedLeaves && native.emittedMerged == managed.emittedMerged &&
                    native.droppedMerged == managed.droppedMerged,
                    "Native complete-frontier result differs from managed coverage/composition");
                Require(!Unity.Burst.BurstCompiler.IsEnabled || native.usedBurst,
                    "Complete-frontier mode silently disabled native Burst traversal");
                if (fits)
                {
                    Require(native.usedDepthFirst && managed.usedDepthFirst && !native.budgetExhausted,
                        "A complete frontier did not use DFS");
                    for (int i = 0; i < count; i++)
                        Require(output[i].pageSlot == reference[i].pageSlot && output[i].splatIndex == reference[i].splatIndex,
                            "Native complete-frontier order differs from managed DFS");
                    // Compare a completed request with the full requested frontier, rather
                    // than a budgeted best-first pass whose intermediate queue can fill
                    // before stand-in filters release capacity. This fixture has <=128 leaves.
                    CompareBestFirst(pages, view, output.Length, floor, output, count, native,
                        $" cap={cap} mode={mode} budget={budget} floor={floor}");
                }
                else
                    Require(count == 0 && !native.usedDepthFirst && native.budgetExhausted &&
                        native.emittedLeaves == 0 && native.emittedMerged == 0 && native.droppedMerged == 0,
                        "An over-budget complete-frontier attempt published a partial or best-first selection");
            }

            pages[0].nodeLimit = pages[1].nodeLimit = 0;
            Require(!SplatBoxLodTraverser.TryTraverseCompleteFrontier(pages, 2, View(), 7, 0,
                output, native, out int overflowCount) && overflowCount == 0,
                "A small budget unexpectedly invoked best-first from complete-frontier mode");
            Require(SplatBoxLodTraverser.Traverse(pages, 2, View(), 7, 0, output, native) > 0,
                "Ordinary budgeted traversal lost its existing best-first fallback");
            Require(SplatBoxLodTraverser.TryTraverseCompleteFrontier(pages, 2, View(), 7, float.MaxValue,
                output, native, out int rootCount) && rootCount == 2,
                "A high floor did not recover complete root coverage after overflow");
            Require(!SplatBoxLodTraverser.TryTraverseCompleteFrontier(pages, 2, View(), 1, float.MaxValue,
                output, native, out overflowCount) && overflowCount == 0,
                "An undersized root budget published incomplete scene coverage");

            const BindingFlags instance = BindingFlags.NonPublic | BindingFlags.Instance;
            var request = typeof(SplatBoxLodTraverser.Workspace).GetMethod("RequestCancellation", instance);
            var reset = typeof(SplatBoxLodTraverser.Workspace).GetMethod("ResetCancellation", instance);
            for (int mode = 0; mode < 2; mode++)
            {
                var workspace = new SplatBoxLodTraverser.Workspace();
                request.Invoke(workspace, null);
                for (int repeat = 0; repeat < 2; repeat++)
                {
                    int count;
                    bool fits = mode == 0
                        ? SplatBoxLodTraverser.TryTraverseCompleteFrontier(pages, 2, View(), 200, 0,
                            output, workspace, out count)
                        : SplatBoxLodTraverser.TryTraverseCompleteFrontierManaged(pages, 2, View(), 200, 0,
                            output, workspace, out count);
                    Require(!fits && count == 0 && workspace.wasCancelled && !workspace.budgetExhausted &&
                        !workspace.usedDepthFirst && workspace.emittedLeaves == 0 && workspace.emittedMerged == 0,
                        "Canceled complete-frontier attempt published output or cleared its cancellation request");
                }
                reset.Invoke(workspace, null);
                bool recovered = mode == 0
                    ? SplatBoxLodTraverser.TryTraverseCompleteFrontier(pages, 2, View(), 200, 0,
                        output, workspace, out int _)
                    : SplatBoxLodTraverser.TryTraverseCompleteFrontierManaged(pages, 2, View(), 200, 0,
                        output, workspace, out _);
                Require(recovered && !workspace.wasCancelled,
                    "Complete-frontier scratch failed to recover after cancellation reset");
            }
            Debug.Log("SplatBox complete-frontier PASS: native/managed DFS parity, bounded failure without best-first, prefix/stereo coverage, root recovery and cancellation.");
        }

        struct HeapFixtureEntry
        {
            public float scale;
            public int page;
            public uint node;
        }

        static void ValidateHeapRemovalParity()
        {
            const BindingFlags instance = BindingFlags.NonPublic | BindingFlags.Instance;
            var heapField = typeof(SplatBoxLodTraverser.Workspace).GetField("heap", instance);
            var countField = typeof(SplatBoxLodTraverser.Workspace).GetField("heapCount", instance);
            var pop = typeof(SplatBoxLodTraverser).GetMethod("HeapPop", BindingFlags.NonPublic | BindingFlags.Static);
            var entryType = heapField.FieldType.GetElementType();
            var scaleField = entryType.GetField("pixelScale");
            var pageField = entryType.GetField("pageIndex");
            var nodeField = entryType.GetField("nodeIndex");
            var random = new System.Random(97021);
            for (int mode = 0; mode < 3; mode++)
            foreach (int size in new[] { 1, 2, 3, 7, 32, 127, 257 })
            {
                var reference = new HeapFixtureEntry[size];
                int referenceCount = 0;
                for (int i = 0; i < size; i++)
                {
                    var entry = new HeapFixtureEntry
                    {
                        scale = mode == 0 ? 1f : random.Next(mode == 1 ? 5 : 100000) * 0.1f,
                        page = i, node = (uint)(size - i)
                    };
                    int index = referenceCount++;
                    while (index > 0)
                    {
                        int parent = (index - 1) >> 1;
                        if (reference[parent].scale >= entry.scale) break;
                        reference[index] = reference[parent];
                        index = parent;
                    }
                    reference[index] = entry;
                }
                var workspace = new SplatBoxLodTraverser.Workspace();
                var heap = (Array)heapField.GetValue(workspace);
                for (int i = 0; i < size; i++)
                {
                    object entry = Activator.CreateInstance(entryType);
                    scaleField.SetValue(entry, reference[i].scale);
                    pageField.SetValue(entry, reference[i].page);
                    nodeField.SetValue(entry, reference[i].node);
                    heap.SetValue(entry, i);
                }
                countField.SetValue(workspace, size);
                while (referenceCount > 0)
                {
                    HeapFixtureEntry expected = ReferenceHeapPop(reference, ref referenceCount);
                    object actual = pop.Invoke(null, new object[] { workspace });
                    Require((int)pageField.GetValue(actual) == expected.page &&
                        (uint)nodeField.GetValue(actual) == expected.node,
                        "Floyd heap removal changed the original pop/tie order");
                    Require((int)countField.GetValue(workspace) == referenceCount, "Heap count changed");
                    for (int i = 0; i < referenceCount; i++)
                    {
                        object remaining = heap.GetValue(i);
                        Require((float)scaleField.GetValue(remaining) == reference[i].scale &&
                            (int)pageField.GetValue(remaining) == reference[i].page &&
                            (uint)nodeField.GetValue(remaining) == reference[i].node,
                            "Floyd heap removal changed the original remaining heap layout");
                    }
                }
            }
            Debug.Log("SplatBox heap removal PASS: exact original pop order and heap state, including dense/equal-priority ties.");
        }

        // The previous removal algorithm is retained only as an independent regression reference.
        static HeapFixtureEntry ReferenceHeapPop(HeapFixtureEntry[] heap, ref int count)
        {
            HeapFixtureEntry top = heap[0];
            --count;
            if (count > 0)
            {
                HeapFixtureEntry entry = heap[count];
                int index = 0;
                while (true)
                {
                    int left = index * 2 + 1;
                    if (left >= count) break;
                    int right = left + 1;
                    int largest = right < count && heap[right].scale > heap[left].scale ? right : left;
                    if (heap[largest].scale <= entry.scale) break;
                    heap[index] = heap[largest];
                    index = largest;
                }
                heap[index] = entry;
            }
            return top;
        }

        static void ValidateCancellation()
        {
            const BindingFlags instance = BindingFlags.NonPublic | BindingFlags.Instance;
            var request = typeof(SplatBoxLodTraverser.Workspace).GetMethod("RequestCancellation", instance);
            var reset = typeof(SplatBoxLodTraverser.Workspace).GetMethod("ResetCancellation", instance);
            var pages = new[] { Page(LodTreeRuntime.Build(new[] { Node(0, 4, 2, 1), Node(-1), Node(1) }, true)) };
            var output = new LodActiveSplatRef[8];
            for (int mode = 0; mode < 2; mode++)
            {
                var workspace = new SplatBoxLodTraverser.Workspace
                {
                    budgetExhausted = true, emittedLeaves = 7, emittedMerged = 5, droppedMerged = 3,
                    exhaustedPixelScale = 123f, usedDepthFirst = true
                };
                request.Invoke(workspace, null);
                int selected = mode == 0
                    ? SplatBoxLodTraverser.Traverse(pages, 1, View(), 8, 0, output, workspace)
                    : SplatBoxLodTraverser.TraverseManaged(pages, 1, View(), 8, 0, output, workspace);
                Require(selected == 0 && workspace.wasCancelled && !workspace.budgetExhausted &&
                    !workspace.usedDepthFirst && workspace.exhaustedPixelScale == 0 &&
                    workspace.emittedLeaves == 0 && workspace.emittedMerged == 0 && workspace.droppedMerged == 0,
                    "Canceled traversal exposed partial selection or stale diagnostics");
                Require((int)typeof(SplatBoxLodTraverser.Workspace).GetField("heapCount", instance).GetValue(workspace) == 0,
                    "Canceled traversal retained pending heap entries");
                reset.Invoke(workspace, null);
                selected = mode == 0
                    ? SplatBoxLodTraverser.Traverse(pages, 1, View(), 8, 0, output, workspace)
                    : SplatBoxLodTraverser.TraverseManaged(pages, 1, View(), 8, 0, output, workspace);
                Require(selected == 2 && !workspace.wasCancelled && workspace.usedDepthFirst,
                    "Reset canceled scratch did not recover a complete selection");
                if (mode == 0)
                    Require(!Unity.Burst.BurstCompiler.IsEnabled || workspace.usedBurst,
                        "Cancellation support silently disabled the native Burst traversal");
            }
            Debug.Log("SplatBox traversal cancellation PASS: native/managed cancellation, cleared state and reset/reuse.");
        }

        static void ValidateBurstParity()
        {
            var pages = new SplatBoxLodTraverser.PageContext[4];
            var random = new System.Random(7103);
            for (int p = 0; p < pages.Length; p++)
            {
                var nodes = new LodTreeNode[341]; // Four-ary tree: 85 internal nodes, 256 leaves.
                for (int i = 0; i < nodes.Length; i++)
                {
                    float feature = i == 0 ? 4f : nodes[(i - 1) / 4].featureSize * 0.5f;
                    float3 center = i == 0 ? new float3(p - 1.5f, 0, 5) :
                        nodes[(i - 1) / 4].center + new float3((float)random.NextDouble() - 0.5f,
                            (float)random.NextDouble() - 0.5f, (float)random.NextDouble() - 0.5f) * feature * 0.5f;
                    nodes[i] = new LodTreeNode { center = center, featureSize = feature,
                        childCount = i < 85 ? (ushort)4 : (ushort)0, childStart = i < 85 ? (uint)(i * 4 + 1) : 0 };
                }
                pages[p] = Page(LodTreeRuntime.Build(nodes, true), p);
                pages[p].localToWorld = float4x4.TRS(new float3(p * 0.1f, 0, 0), quaternion.identity,
                    new float3(1f + p * 0.1f, 1f, 1f));
                pages[p].outsideFoveate = 0.4f;
                pages[p].behindFoveate = 0.15f;
            }
            var output = new LodActiveSplatRef[1024];
            for (int mode = 0; mode < 8; mode++)
            {
                var view = View();
                view.cameraWorld = new float3(0, 0, mode * 0.75f);
                view.orthographic = (mode & 1) != 0;
                view.skipMergedSplats = (mode & 2) != 0;
                view.maxStandInPixels = (mode & 4) != 0 ? 512f : 0f;
                view.frustumCull = mode >= 4;
                view.cullPlanes = XFrustum(0);
                view.rightEyeCullPlanes = XFrustum(1);
                foreach (int budget in new[] { 1, 4, 7, 23, 64, 255, 512, 1024 })
                    Select(pages, view, budget, output, mode % 3 == 0 ? 0f : 50f);
            }
            // Legacy child tables and incomplete prefixes use the same native kernel.
            var legacy = LodTreeRuntime.Build(new[]
            { Node(0, 10, 2, 1), Node(-1, 2, 2, 2), Node(-1.2f), Node(-0.8f), Node(1) }, false);
            Select(new[] { Page(legacy) }, View(), 8, output);
            Debug.Log("SplatBox native/managed traversal parity PASS: varied budgets, transforms, filters, stereo, orthographic, prefixes and legacy child tables.");
        }

        static void ValidatePrefixCoverage()
        {
            var output = new LodActiveSplatRef[8];
            var partial = LodTreeRuntime.BuildPrefix(new[] { Node(0, 10, 3, 1), Node(-1), Node(0) });
            Require(partial.nodes[0].childCount == 0 && partial.nodes[0].IsMergedSplat,
                "An incomplete sibling group must retain its merged parent");
            int count = Select(new[] { Page(partial) }, View(), 8, output);
            Require(count == 1 && output[0].splatIndex == 0,
                "A prefix cut lost the missing sibling's coverage");

            var nested = LodTreeRuntime.BuildPrefix(new[]
            {
                Node(0, 10, 2, 1), Node(-1, 3, 2, 3), Node(1), Node(-1.2f)
            });
            count = Select(new[] { Page(nested) }, View(), 8, output);
            Require(count == 2 && Contains(output, count, 0, 1) && Contains(output, count, 0, 2),
                "A nested partial prefix must retain the incomplete branch and its complete sibling");

            var complete = LodTreeRuntime.BuildPrefix(new[]
            {
                Node(0, 10, 2, 1), Node(-1), Node(1)
            });
            count = Select(new[] { Page(complete) }, View(), 8, output);
            Require(count == 2 && Contains(output, count, 0, 1) && Contains(output, count, 0, 2),
                "Complete sibling groups must remain refinable");
        }

        static void ValidateTraversalLimits()
        {
            // A breadth-first four-ary tree has useful intermediate frontiers. A single very wide
            // root cannot exercise gradual refinement or prefixes that cut a nested sibling group.
            var nodes = new LodTreeNode[85];
            for (int i = 0; i < nodes.Length; i++)
            {
                float feature = i == 0 ? 4f : nodes[(i - 1) / 4].featureSize * 0.5f;
                nodes[i] = Node(0, feature, i < 21 ? (ushort)4 : (ushort)0,
                    i < 21 ? (uint)(i * 4 + 1) : 0);
            }
            var tree = LodTreeRuntime.Build(nodes, true);
            var original = (LodTreeNode[])tree.nodes.Clone();
            var pages = new[] { Page(tree) };
            var output = new LodActiveSplatRef[85];
            int[] limits = { 1, 5, 10, 21, 85, 0, 100 };
            int[] counts = { 1, 4, 7, 16, 64, 64, 64 };
            for (int mode = 0; mode < limits.Length; mode++)
            {
                pages[0].nodeLimit = limits[mode];
                int count = Select(pages, View(), 85, output);
                Require(count == counts[mode], "Unexpected frontier size for traversal limit " + limits[mode]);
                int available = limits[mode] > 0 ? Math.Min(limits[mode], nodes.Length) : nodes.Length;
                var selected = new bool[nodes.Length];
                for (int i = 0; i < count; i++)
                {
                    uint index = output[i].splatIndex;
                    Require(index < available && !selected[index],
                        "Traversal limit emitted an unavailable or duplicate node");
                    selected[index] = true;
                }
                // Each real leaf must be represented by exactly one selected ancestor. This catches
                // both holes from partial sibling groups and parent/descendant double coverage.
                for (int leaf = 21; leaf < nodes.Length; leaf++)
                {
                    int covered = 0;
                    for (int node = leaf;; node = (node - 1) / 4)
                    {
                        if (selected[node]) covered++;
                        if (node == 0) break;
                    }
                    Require(covered == 1, "Traversal limit lost or duplicated coverage for leaf " + leaf);
                }
                if (limits[mode] == 10)
                    Require(!selected[1] && selected[2] && selected[3] && selected[4] &&
                        selected[5] && selected[6] && selected[7] && selected[8] && !selected[9],
                        "A partial second sibling group replaced its parent");
            }
            Require(ReferenceEquals(pages[0].nodes, tree.nodes), "Traversal replaced the shared source tree");
            for (int i = 0; i < tree.nodes.Length; i++)
                Require(tree.nodes[i].Equals(original[i]), "Traversal limit mutated a shared source node");

            // The second root child is index 4, not the adjacent index 2. Capping a legacy
            // pre-order tree must validate its explicit child table before replacing the root.
            var legacy = LodTreeRuntime.Build(new[]
            { Node(0, 10, 2, 1), Node(-1, 2, 2, 2), Node(-1.2f), Node(-0.8f), Node(1) }, false);
            pages[0] = Page(legacy);
            pages[0].nodeLimit = 4;
            Require(Select(pages, View(), 85, output) == 1 && output[0].splatIndex == 0,
                "An incomplete legacy child-table group lost root coverage");
            pages[0].nodeLimit = 5;
            Require(Select(pages, View(), 85, output) == 3 && Contains(output, 3, 0, 2) &&
                Contains(output, 3, 0, 3) && Contains(output, 3, 0, 4),
                "A complete legacy child-table group stopped refining");
        }

        static void ValidateStereoUnion()
        {
            var pages = new[] { Page(LodTreeRuntime.Build(new[] { Node(2) }, true)) };
            var output = new LodActiveSplatRef[4];
            var view = View();
            view.frustumCull = true;
            view.cullPlanes = XFrustum(0);
            Require(Select(pages, view, 4, output) == 0, "Mono view unexpectedly contains the second-eye splat");
            view.rightEyeCullPlanes = XFrustum(2);
            Require(Select(pages, view, 4, output) == 1, "A splat visible only to the second eye disappeared");
            pages[0].nodes[0].center.x = 5;
            Require(Select(pages, view, 4, output) == 0, "Stereo culling retained a splat outside both eyes");
        }

        static void ValidateVisibleChildBudget()
        {
            var tree = LodTreeRuntime.Build(new[]
            {
                Node(0, 12, 4, 1), Node(0), Node(3), Node(4), Node(5)
            }, true);
            var view = View();
            view.frustumCull = true;
            view.cullPlanes = XFrustum(0);
            var output = new LodActiveSplatRef[2];
            int count = Select(new[] { Page(tree) }, view, 2, output);
            Require(count == 1 && output[0].splatIndex == 1,
                "Invisible siblings consumed the budget and prevented visible detail");
        }

        static void ValidateEmptySelections()
        {
            var tree = LodTreeRuntime.Build(new[] { Node(0, 10, 2, 1), Node(-0.1f), Node(0.1f) }, true);
            var output = new LodActiveSplatRef[4];
            var view = View();
            view.skipMergedSplats = true;
            Require(Select(new[] { Page(tree) }, view, 1, output) == 0,
                "Fallback selection bypassed the merged-splat filter");
            view.skipMergedSplats = false;
            view.maxStandInPixels = 1f;
            Require(Select(new[] { Page(tree) }, view, 1, output) == 0,
                "Fallback selection bypassed the stand-in size limit");
            view.maxStandInPixels = 0f;
            Require(Select(new[] { Page(tree) }, view, 1, output) == 1,
                "Explicitly allowing coarse stand-ins failed");
        }

        static void ValidateGlobalBudget()
        {
            var pages = new[]
            {
                Page(LodTreeRuntime.Build(new[] { Node(0, 10, 4, 1), Node(0), Node(0.1f), Node(0.2f), Node(0.3f) }, true)),
                Page(LodTreeRuntime.Build(new[] { Node(0, 2, 2, 1), Node(0), Node(0.1f) }, true), 1)
            };
            var output = new LodActiveSplatRef[3];
            int count = Select(pages, View(), 3, output);
            Require(count == 3 && Contains(output, count, 0, 0) &&
                Contains(output, count, 1, 1) && Contains(output, count, 1, 2),
                "The global frontier exceeded its budget or lost a page's coverage");
        }

        static void ValidateProjection()
        {
            var owner = new GameObject("Paged LoD projection validation");
            var target = new RenderTexture(640, 480, 0);
            try
            {
                var camera = owner.AddComponent<Camera>();
                camera.enabled = false;
                camera.targetTexture = target;
                camera.fieldOfView = 30f;
                camera.projectionMatrix = Matrix4x4.Perspective(90f, 4f / 3f, 0.1f, 100f);
                var position = new Vector3(2, 3, 4);
                var rotation = Quaternion.Euler(0, 90, 0);
                camera.worldToCameraMatrix = Matrix4x4.Scale(new Vector3(1, 1, -1)) *
                    Matrix4x4.TRS(position, rotation, Vector3.one).inverse;
                var view = SplatBoxLodTraverser.ViewContext.FromCamera(camera, false,
                    new SplatBoxLodTraverser.Workspace());
                float expected = GaussianSplatRenderSystem.GetSplatScreenParams(camera).y * 0.5f;
                Require(Mathf.Abs(view.pixelsPerUnitAtUnitDistance - expected) < 0.001f,
                    "LoD pixel size used Camera.fieldOfView instead of the render projection");
                Require(math.distance(view.cameraWorld, (float3)position) < 0.001f &&
                    math.distance(view.cameraForward, (float3)(rotation * Vector3.forward)) < 0.001f,
                    "LoD view position/direction ignored the camera view matrix");
                Require(Vector3.Distance(GaussianSplatRenderSystem.GetStreamingFocusPosition(camera), position) < 0.001f,
                    "Streaming focus changed camera position while converting view handedness");
                view = View();
                view.orthographic = true;
                float near = SplatBoxLodTraverser.ComputePixelScale(view, new float3(0, 0, 1), 0.1f, 1, 1, 1);
                float far = SplatBoxLodTraverser.ComputePixelScale(view, new float3(0, 0, 20), 0.1f, 1, 1, 1);
                Require(Mathf.Abs(near - far) < 0.001f, "Orthographic LoD changed with distance");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(target);
            }
        }

        static void ValidateViewportFoveation()
        {
            var owner = new GameObject("Paged LoD viewport foveation validation");
            try
            {
                var camera = owner.AddComponent<Camera>();
                camera.enabled = false;
                foreach (float aspect in new[] { 2f, 0.5f })
                {
                    camera.projectionMatrix = Matrix4x4.Perspective(60f, aspect, 0.1f, 100f);
                    var view = SplatBoxLodTraverser.ViewContext.FromCamera(camera, false,
                        new SplatBoxLodTraverser.Workspace());
                    ValidateViewportCorners(view, camera.projectionMatrix, camera.worldToCameraMatrix,
                        "aspect " + aspect);
                    float3 outside = new float3(10, 0, 0.1f);
                    float full = SplatBoxLodTraverser.ComputePixelScale(view, outside, 0.001f, 1, 1, 1);
                    float reduced = SplatBoxLodTraverser.ComputePixelScale(view, outside, 0.001f, 1, 0.1f, 1);
                    Require(Mathf.Abs(reduced - full * 0.1f) <= full * 0.0001f,
                        "Viewport cone disabled foveation for offscreen geometry");
                }

                camera.orthographic = true;
                camera.projectionMatrix = Matrix4x4.Ortho(-20, 20, -5, 5, 0.1f, 100f);
                var ortho = SplatBoxLodTraverser.ViewContext.FromCamera(camera, false,
                    new SplatBoxLodTraverser.Workspace());
                ValidateViewportCorners(ortho, camera.projectionMatrix, camera.worldToCameraMatrix,
                    "orthographic");

                camera.orthographic = false;
                Matrix4x4 flip = Matrix4x4.Scale(new Vector3(1, 1, -1));
                Matrix4x4 leftView = flip * Matrix4x4.TRS(new Vector3(-0.032f, 0, 0),
                    Quaternion.Euler(0, -10, 0), Vector3.one).inverse;
                Matrix4x4 rightView = flip * Matrix4x4.TRS(new Vector3(0.032f, 0, 0),
                    Quaternion.Euler(0, 10, 0), Vector3.one).inverse;
                Matrix4x4 leftProjection = Matrix4x4.Perspective(75f, 1.4f, 0.1f, 100f);
                Matrix4x4 rightProjection = leftProjection;
                leftProjection.m02 = 0.35f;
                leftProjection.m12 = 0.1f;
                rightProjection.m02 = -0.35f;
                rightProjection.m12 = -0.1f;
                GaussianSplatRenderSystem.SetOverrideMatrices(leftView, leftProjection);
                GaussianSplatRenderSystem.SetOverrideStereoMatrices(leftView, leftProjection,
                    rightView, rightProjection);
                var stereo = SplatBoxLodTraverser.ViewContext.FromCamera(camera, false,
                    new SplatBoxLodTraverser.Workspace());
                ValidateViewportCorners(stereo, leftProjection, leftView, "left asymmetric eye");
                ValidateViewportCorners(stereo, rightProjection, rightView, "right asymmetric eye");
            }
            finally
            {
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideMatrices();
                UnityEngine.Object.DestroyImmediate(owner);
            }
        }

        static void ValidateViewportCorners(SplatBoxLodTraverser.ViewContext view,
            Matrix4x4 projection, Matrix4x4 cameraView, string label)
        {
            Matrix4x4 inverse = (projection * cameraView).inverse;
            foreach (float z in new[] { -0.9f, 0.9f })
            foreach (float y in new[] { -0.98f, 0.98f })
            foreach (float x in new[] { -0.98f, 0.98f })
            {
                float3 center = inverse.MultiplyPoint(new Vector3(x, y, z));
                const float feature = 0.001f;
                float full = SplatBoxLodTraverser.ComputePixelScale(view, center, feature, 1, 1, 1);
                float foveated = SplatBoxLodTraverser.ComputePixelScale(view, center, feature, 1, 0.1f, 0.1f);
                Require(full > 0 && Mathf.Abs(foveated - full) <= full * 0.0001f,
                    "Visible viewport corner lost detail through offscreen foveation: " + label);

                // A cutoff between the old 0.1x penalty and the full size must still refine.
                // Select also compares the native Burst result with the managed reference.
                var nodes = new[]
                {
                    new LodTreeNode { center = center, featureSize = feature, childStart = 1, childCount = 2 },
                    new LodTreeNode { center = center, featureSize = feature * 0.1f },
                    new LodTreeNode { center = center, featureSize = feature * 0.1f }
                };
                var page = Page(LodTreeRuntime.Build(nodes, true));
                page.outsideFoveate = page.behindFoveate = 0.1f;
                Require(Select(new[] { page }, view, 2, new LodActiveSplatRef[2], full * 0.5f) == 2,
                    "Visible viewport subtree stopped refining: " + label);
            }
        }

        static void ValidateRawStereoOverride()
        {
            var owner = new GameObject("Paged LoD raw XR override validation");
            try
            {
                var camera = owner.AddComponent<Camera>();
                camera.enabled = false;
                Matrix4x4 projection = Matrix4x4.Perspective(90f, 1f, 0.1f, 100f);
                Matrix4x4 flip = Matrix4x4.Scale(new Vector3(1, 1, -1));
                Matrix4x4 leftView = flip * Matrix4x4.Translate(new Vector3(2, 0, 0));
                Matrix4x4 rightView = flip * Matrix4x4.Translate(new Vector3(-2, 0, 0));
                // URP can supply both eyes while Camera itself remains mono.
                GaussianSplatRenderSystem.SetOverrideMatrices(leftView, projection);
                GaussianSplatRenderSystem.SetOverrideStereoMatrices(leftView, projection, rightView, projection);
                var view = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    new SplatBoxLodTraverser.Workspace());
                Require(view.rightEyeCullPlanes != null && math.length(view.cameraWorld) < 0.001f &&
                    GaussianSplatRenderSystem.GetStreamingFocusPosition(camera).sqrMagnitude < 0.000001f,
                    "Raw URP eye overrides did not provide a shared head-center view and two-eye culling");
                var pages = new[] { Page(LodTreeRuntime.Build(new[] { Node(6) }, true)) };
                Require(Select(pages, view, 1, new LodActiveSplatRef[1]) == 1,
                    "Raw URP stereo override lost a node visible only to the right eye");
            }
            finally
            {
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideMatrices();
                UnityEngine.Object.DestroyImmediate(owner);
            }
        }

        static float4[] XFrustum(float center) => new[]
        {
            new float4(1, 0, 0, 0.5f - center), new float4(-1, 0, 0, center + 0.5f),
            new float4(0, 1, 0, 10), new float4(0, -1, 0, 10),
            new float4(0, 0, 1, 10), new float4(0, 0, -1, 10)
        };

        static bool Contains(LodActiveSplatRef[] output, int count, uint page, uint node)
        {
            for (int i = 0; i < count; i++)
                if (output[i].pageSlot == page && output[i].splatIndex == node)
                    return true;
            return false;
        }

        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
