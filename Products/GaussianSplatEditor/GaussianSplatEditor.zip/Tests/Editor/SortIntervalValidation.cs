// SPDX-License-Identifier: MIT

using System;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    public static class SortIntervalValidation
    {
        const BindingFlags PrivateInstance = BindingFlags.Instance | BindingFlags.NonPublic;

        public static void RunAll()
        {
            Require(Application.isPlaying, "Sort interval validation must run in actual Editor Play mode.");
            ValidateInspectorIntervalOne();
            ValidateRenderedFrameCadence();
            ValidateCameraOwnership();
            ValidateEyeReuseAndPublication();
            ValidateMobileCameraOwnership();
            Debug.Log("SplatBox sort interval PASS: inspector interval one, rendered-frame cadence, " +
                "camera ownership, multi-pass eyes, safe eye reuse and selection publication.");
        }

        public static void RunEditMode()
        {
            Require(!Application.isPlaying, "Editor view ownership validation must run outside Play mode.");
            ValidateEditorGameViewDriver();
            ValidateCalculatedViewOwnership();
            Debug.Log("SplatBox editor view ownership PASS: Main/Game camera sort driver, " +
                "Scene fallback, pure cache queries and actual calculation ownership.");
        }

        static void ValidateEditorGameViewDriver()
        {
            using var fixture = new Fixture();
            GameObject[] previousMainObjects = GameObject.FindGameObjectsWithTag("MainCamera");
            try
            {
                foreach (var main in previousMainObjects) main.tag = "Untagged";
                fixture.camera.gameObject.tag = "MainCamera";
                fixture.camera.gameObject.SetActive(true);
                Require(Camera.main == fixture.camera, "Editor driver fixture did not establish its Main camera.");
                Require(!ShouldSort(fixture.renderer, fixture.secondary),
                    "A secondary editor camera was allowed to sort the Main camera's shared LoD order.");
                Require(ShouldSort(fixture.renderer, fixture.camera),
                    "Game view could not sort its fresh selection while a Scene view exists.");
                Record(fixture.renderer, fixture.camera, Time.frameCount);
                Require(!ShouldSort(fixture.renderer, fixture.camera),
                    "An unchanged editor Game view ignored its successfully recorded sort.");
                Call(fixture.renderer, "MarkLodSelectionChanged");
                Require(ShouldSort(fixture.renderer, fixture.camera),
                    "A new Game-view selection retained identity order in edit mode.");

                fixture.camera.gameObject.tag = "Untagged";
                var sceneView = UnityEditor.SceneView.lastActiveSceneView;
                Camera fallback = sceneView != null ? sceneView.camera : fixture.secondary;
                Require(ShouldSort(fixture.renderer, fallback),
                    "Removing the Main camera did not restore Scene-view/fallback sorting.");
            }
            finally
            {
                fixture.camera.gameObject.tag = "Untagged";
                foreach (var main in previousMainObjects)
                    if (main != null) main.tag = "MainCamera";
            }
        }

        static void ValidateCalculatedViewOwnership()
        {
            using var fixture = new Fixture();
            var renderer = fixture.renderer;
            try
            {
                Require(NeedsView(renderer, fixture.camera) && NeedsView(renderer, fixture.camera),
                    "A cache query marked a view calculated before compute commands were recorded.");
                Call(renderer, "RecordCalculatedView", fixture.camera);
                Require(!NeedsView(renderer, fixture.camera), "A recorded calculation was not reusable.");

                // A changed-order branch short-circuits the cache predicate, but the actual compute
                // dispatch must still record the camera that has overwritten the shared view buffer.
                Set(renderer, "m_OrderBufferChanged", true);
                bool calculateSecondary = (bool)Call(renderer, "ConsumeOrderBufferChanged") ||
                    NeedsView(renderer, fixture.secondary);
                Require(calculateSecondary, "Changed order did not request view regeneration.");
                Call(renderer, "RecordCalculatedView", fixture.secondary);
                Require(NeedsView(renderer, fixture.camera) && !NeedsView(renderer, fixture.secondary),
                    "A forced secondary calculation left the Main camera falsely owning the view cache.");
                Call(renderer, "RecordCalculatedView", fixture.camera);
                Require(!NeedsView(renderer, fixture.camera), "Restoring Main's view did not update cache ownership.");

                GaussianSplatRenderSystem.SetOverrideRenderTargetSize(900, 600);
                Call(renderer, "RecordCalculatedView", fixture.camera);
                GaussianSplatRenderSystem.SetOverrideRenderTargetSize(900, 300);
                Require(NeedsView(renderer, fixture.camera),
                    "A new actual render-target size reused axes calculated for another target.");
                Matrix4x4 projection = Matrix4x4.Perspective(60, 1.5f, 0.1f, 100f);
                Matrix4x4 flip = Matrix4x4.Scale(new Vector3(1, 1, -1));
                GaussianSplatRenderSystem.SetOverrideMatrices(flip, projection);
                Call(renderer, "RecordCalculatedView", fixture.camera);
                Matrix4x4 trackedView = flip * Matrix4x4.Rotate(Quaternion.Euler(0, 30, 0)).inverse;
                GaussianSplatRenderSystem.SetOverrideMatrices(trackedView, projection);
                Require(NeedsView(renderer, fixture.camera),
                    "A tracked view change with an unchanged Camera.transform reused stale projected splats.");
            }
            finally
            {
                GaussianSplatRenderSystem.ClearOverrideRenderTargetSize();
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideMatrices();
            }
        }

        static void ValidateInspectorIntervalOne()
        {
            using var fixture = new Fixture();
            var renderer = fixture.renderer;
            renderer.m_SortNthFrame = 1;
            renderer.m_ReuseSortAcrossEyes = false;
            Record(renderer, fixture.camera, Time.frameCount - 1);
            Set(renderer, "m_FrameCounter", 1);
            Require(ShouldSort(renderer, fixture.camera),
                "Inspector interval one was silently raised to two in Play mode.");
            Require(ShouldSort(renderer, fixture.camera) &&
                    !(bool)Call(renderer, "HasSortOrderForCamera", fixture.secondary),
                "A sort decision changed shared order ownership before commands were recorded.");
            Record(renderer, fixture.camera, Time.frameCount);
            Set(renderer, "m_FrameCounter", 3);
            Require(ShouldSort(renderer, fixture.camera),
                "The second multi-pass eye skipped a due interval-one frame.");
        }

        static void ValidateRenderedFrameCadence()
        {
            using var fixture = new Fixture();
            var renderer = fixture.renderer;
            renderer.m_SortNthFrame = 2;
            renderer.m_ReuseSortAcrossEyes = false;
            Record(renderer, fixture.camera, 100);
            Require(Normal(renderer, fixture.camera, 2, 100),
                "The second eye did not sort on a due frame when eye reuse was disabled.");
            for (int callback = 0; callback < 8; callback++)
            {
                Set(renderer, "m_FrameCounter", callback);
                Require(!Normal(renderer, fixture.camera, 2, 101),
                    "Extra render callbacks advanced the configured frame interval.");
                Require(Normal(renderer, fixture.secondary, 2, 101),
                    "A secondary camera was allowed to reuse another camera's shared order.");
            }
            Require(Normal(renderer, fixture.camera, 2, 102) &&
                    Normal(renderer, fixture.camera, 2, 102),
                "The due frame was skipped or acknowledged before a sort was recorded.");
            Record(renderer, fixture.camera, 102);
            Require(Normal(renderer, fixture.camera, 2, 102),
                "Per-eye callbacks permanently selected alternating even/odd eyes.");
            Record(renderer, fixture.camera, 102);
            Require(!Normal(renderer, fixture.camera, 2, 103) &&
                    Normal(renderer, fixture.camera, 2, 104),
                "Rendered-frame cadence did not resume after both eyes sorted.");
        }

        static void ValidateCameraOwnership()
        {
            using var fixture = new Fixture();
            var renderer = fixture.renderer;
            renderer.m_SortNthFrame = 4;
            renderer.m_ReuseSortAcrossEyes = false;
            Record(renderer, fixture.camera, 200);
            Require(!Normal(renderer, fixture.camera, 4, 201), "The owning camera did not reuse its valid order.");
            Require(Normal(renderer, fixture.secondary, 4, 201),
                "A new camera skipped sorting on an off-interval frame.");
            Require(!Normal(renderer, fixture.camera, 4, 201),
                "Merely considering a secondary camera invalidated the current order.");
            Record(renderer, fixture.secondary, 201);
            Require(Normal(renderer, fixture.camera, 4, 201) &&
                    Normal(renderer, fixture.camera, 4, 201),
                "Game view reused the secondary camera's order on its skipped interval.");
            Record(renderer, fixture.camera, 201);
            Require(!Normal(renderer, fixture.camera, 4, 202) &&
                    Normal(renderer, fixture.camera, 4, 205),
                "An interleaved camera's callback count replaced elapsed-frame scheduling.");
        }

        static void ValidateEyeReuseAndPublication()
        {
            using var fixture = new Fixture();
            var renderer = fixture.renderer;
            renderer.m_SortNthFrame = 4;
            renderer.m_ReuseSortAcrossEyes = true;
            Record(renderer, fixture.camera, Time.frameCount);
            Require(!ShouldSort(renderer, fixture.camera),
                "Opt-in stereo reuse repeated an unchanged same-camera sort in the same frame.");
            Call(renderer, "MarkLodSelectionChanged");
            Set(renderer, "m_LodSortKeysNeedReset", false);
            Require(ShouldSort(renderer, fixture.camera) && ShouldSort(renderer, fixture.camera),
                "Eye reuse acknowledged or skipped a new identity-ordered selection.");
            Record(renderer, fixture.camera, Time.frameCount);
            Require(!ShouldSort(renderer, fixture.camera),
                "A successful publication sort did not restore safe same-frame eye reuse.");
            Record(renderer, fixture.secondary, Time.frameCount);
            Require(ShouldSort(renderer, fixture.camera),
                "Same-frame eye reuse ignored another camera overwriting the shared order.");
            Record(renderer, fixture.camera, Time.frameCount);
            Require(!ShouldSort(renderer, fixture.camera),
                "Eye reuse did not resume after restoring the correct camera's order.");
        }

        static void ValidateMobileCameraOwnership()
        {
            using var fixture = new Fixture();
            var renderer = fixture.renderer;
            renderer.m_SortNthFrame = 4;
            renderer.m_ReuseSortAcrossEyes = true;
            renderer.m_StableSortWhileRotatingOnMobile = true;
            Record(renderer, fixture.camera, Time.frameCount);
            Require(!ShouldSort(renderer, fixture.camera),
                "Stable stereo sorting repeated its own same-frame order.");
            Require(ShouldSort(renderer, fixture.secondary),
                "Stable sorting reused an order owned by a different camera.");
            Record(renderer, fixture.secondary, Time.frameCount);
            Require(ShouldSort(renderer, fixture.camera),
                "Stable sorting left Game view with a secondary camera's order.");
            Record(renderer, fixture.camera, Time.frameCount);
            Require(!ShouldSort(renderer, fixture.camera),
                "Stable same-frame eye reuse was not restored after an ownership switch.");
        }

        sealed class Fixture : IDisposable
        {
            readonly GameObject owner = new GameObject("Sort interval renderer validation");
            readonly GameObject cameraOwner = new GameObject("Sort interval camera validation");
            readonly GameObject secondaryOwner = new GameObject("Sort interval secondary camera validation");
            readonly GaussianSplatPagedScene scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            public readonly SplatBoxRenderer renderer;
            public readonly Camera camera;
            public readonly Camera secondary;

            public Fixture()
            {
                owner.SetActive(false);
                cameraOwner.SetActive(false);
                secondaryOwner.SetActive(false);
                scene.Initialize(Vector3.zero, Vector3.one, 1, new[]
                {
                    new GaussianSplatPageEntry { pageId = 0, splatCount = 2 }
                });
                renderer = owner.AddComponent<SplatBoxRenderer>();
                camera = cameraOwner.AddComponent<Camera>();
                secondary = secondaryOwner.AddComponent<Camera>();
                Set(renderer, "m_PagedScene", scene);
                Set(renderer, "m_ActiveSplatCount", 2);
                Set(renderer, "m_LodSelectionRevision", 1u);
                renderer.m_StableSortWhileRotatingOnMobile = false;
                renderer.m_FrustumCullOnMobile = false;
            }

            public void Dispose()
            {
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
                UnityEngine.Object.DestroyImmediate(secondaryOwner);
                UnityEngine.Object.DestroyImmediate(scene);
            }
        }

        static bool ShouldSort(SplatBoxRenderer renderer, Camera camera) =>
            (bool)Call(renderer, "ShouldSortThisFrame", camera);
        static bool NeedsView(SplatBoxRenderer renderer, Camera camera) =>
            (bool)Call(renderer, "ShouldCalculateEditorLodView", camera);
        static bool Normal(SplatBoxRenderer renderer, Camera camera, int interval, int frame) =>
            (bool)Call(renderer, "ShouldSortNormalFrame", camera, interval, frame);
        static void Record(SplatBoxRenderer renderer, Camera camera, int frame) =>
            Call(renderer, "RecordSortContext", camera, frame);
        static object Call(object target, string method, params object[] args) =>
            target.GetType().GetMethod(method, PrivateInstance).Invoke(target, args);
        static void Set(object target, string field, object value) =>
            target.GetType().GetField(field, PrivateInstance).SetValue(target, value);
        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
