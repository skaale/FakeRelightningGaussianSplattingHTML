uint _TestOrder;
RWStructuredBuffer<float4> _TestResults;

[numthreads(1, 1, 1)]
void CompareSH(uint3 id : SV_DispatchThreadID)
{
    SplatData full = LoadSplatData(0);
    SplatData limited = LoadSplatData(0, _TestOrder);
    float3 direction = normalize(float3(0.2 + id.x * 0.17, -0.8, 0.6 - id.x * 0.2));
    float3 reference = ShadeSH(full.sh, direction, _TestOrder, false);
    float3 optimized = ShadeSH(limited.sh, direction, _TestOrder, false);
    // Check coefficients independently: half shading can round differently after inlining
    // the two load paths, but every coefficient used by the selected band must still match.
    float3 loadError = abs((float3)full.sh.col - (float3)limited.sh.col);
    if (_TestOrder >= 1)
    {
        loadError = max(loadError, abs((float3)full.sh.sh1 - (float3)limited.sh.sh1));
        loadError = max(loadError, abs((float3)full.sh.sh2 - (float3)limited.sh.sh2));
        loadError = max(loadError, abs((float3)full.sh.sh3 - (float3)limited.sh.sh3));
    }
    if (_TestOrder >= 2)
    {
        loadError = max(loadError, abs((float3)full.sh.sh4 - (float3)limited.sh.sh4));
        loadError = max(loadError, abs((float3)full.sh.sh5 - (float3)limited.sh.sh5));
        loadError = max(loadError, abs((float3)full.sh.sh6 - (float3)limited.sh.sh6));
        loadError = max(loadError, abs((float3)full.sh.sh7 - (float3)limited.sh.sh7));
        loadError = max(loadError, abs((float3)full.sh.sh8 - (float3)limited.sh.sh8));
    }
    if (_TestOrder >= 3)
    {
        loadError = max(loadError, abs((float3)full.sh.sh9 - (float3)limited.sh.sh9));
        loadError = max(loadError, abs((float3)full.sh.sh10 - (float3)limited.sh.sh10));
        loadError = max(loadError, abs((float3)full.sh.sh11 - (float3)limited.sh.sh11));
        loadError = max(loadError, abs((float3)full.sh.sh12 - (float3)limited.sh.sh12));
        loadError = max(loadError, abs((float3)full.sh.sh13 - (float3)limited.sh.sh13));
        loadError = max(loadError, abs((float3)full.sh.sh14 - (float3)limited.sh.sh14));
        loadError = max(loadError, abs((float3)full.sh.sh15 - (float3)limited.sh.sh15));
    }
    _TestResults[id.x * 3] = float4(reference, full.opacity);
    _TestResults[id.x * 3 + 1] = float4(optimized, limited.opacity);
    _TestResults[id.x * 3 + 2] = float4(loadError, abs(full.opacity - limited.opacity));
}
