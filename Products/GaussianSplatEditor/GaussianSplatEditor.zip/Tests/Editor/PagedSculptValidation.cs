// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GaussianSplatting.Tests
{
    /// <summary>Checks every paged sculpt operation and ordered journal replay.</summary>
    public static class PagedSculptValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object value, string name) => (T)value.GetType().GetField(name, Flags).GetValue(value);
        static void Set(object value, string name, object data) => value.GetType().GetField(name, Flags).SetValue(value, data);
        static object Call(object value, string name, params object[] args) => value.GetType().GetMethod(name, Flags).Invoke(value, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(Vector3 value, Vector3 expected, string message) =>
            Require(Vector3.Distance(value, expected) < .001f, message + ": got " + value + ", expected " + expected);

        sealed class Fixture : IDisposable
        {
            public readonly object wrapper, inner;
            public readonly SplatBoxRenderer renderer;
            public readonly SplatBoxPageGpuState page;
            public readonly GameObject owner;
            public Fixture(string shader)
            {
                var type = typeof(PagedSmudgeValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                wrapper = Activator.CreateInstance(type, Flags, null, new object[] { shader }, null);
                inner = Get<object>(wrapper, "inner"); renderer = Get<SplatBoxRenderer>(wrapper, "renderer");
                page = Get<SplatBoxPageGpuState>(wrapper, "page"); owner = Get<GameObject>(wrapper, "owner");
            }
            public void Positions(params Vector3[] positions) => Call(wrapper, "Positions", new object[] { positions });
            public Vector3 Original(int index) => (Vector3)Call(wrapper, "Position", index);
            public Vector3[] Offsets() => (Vector3[])Call(wrapper, "Offsets");
            public Vector3 Position(int index) => Original(index) + Offsets()[index];
            public void Replay() => Call(wrapper, "Replay");
            public void Expect(int index, Vector3 expected, string context)
            {
                Near(Position(index), expected, context + " GPU");
                Near(page.lodTree.nodes[index - page.atlasOffset].center, expected, context + " CPU");
            }
            public void Stroke(Action action)
            {
                renderer.BeginPagedSculptStroke(); action(); renderer.EndPagedSculptStroke();
            }
            public void Dispose() => ((IDisposable)wrapper).Dispose();
        }

        static float Weight(float distance, float radius, float falloff) => distance >= radius ? 0 :
            falloff < .01f ? 1 : falloff > .45f && falloff < .55f ? 1 - distance / radius :
            1 - Mathf.Pow(distance / radius, 1 / falloff);

        static void PinchFlattenRestore(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 source = new Vector3(.2f, .2f, 3), center = new Vector3(0, 0, 3);
            f.Positions(new Vector3(0, 0, 4), source, new Vector3(3, 0, 3), new Vector3(-.2f, .2f, 3));
            var originalBytes = new uint[384]; Get<GraphicsBuffer>(f.inner, "pos").GetData(originalBytes);
            foreach (float falloff in new[] { 0f, .3f, .5f, 1f })
            {
                f.renderer.ResetPagedSculpt();
                float weight = Weight(Vector3.Distance(source, center), 1, falloff) * .65f;
                f.Stroke(() => f.renderer.PinchSplatsGPU(center, 1, falloff, .65f));
                f.Expect(33, source + (center - source) * weight, "Pinch falloff " + falloff);
                f.Expect(34, new Vector3(3, 0, 3), "Pinch outside brush");
                f.renderer.ResetPagedSculpt();
                Vector3 normal = new Vector3(1, 2, 0).normalized;
                f.Stroke(() => f.renderer.FlattenSplatsGPU(center, normal * 4, 1, falloff, .65f));
                Vector3 flattened = source - normal * Vector3.Dot(source - center, normal) * weight;
                f.Expect(33, flattened, "Flatten falloff " + falloff);
                f.Expect(34, new Vector3(3, 0, 3), "Flatten outside brush");
                f.Stroke(() => f.renderer.RestorePositionsInSphereGPU(flattened, .1f, 0, .5f));
                f.Expect(33, Vector3.Lerp(flattened, source, .5f), "Partial restore");
                Vector3 partial = Vector3.Lerp(flattened, source, .5f);
                f.Stroke(() => f.renderer.RestorePositionsInSphereGPU(partial, .1f, 0, 1));
                f.Expect(33, source, "Full restore");
                f.Replay(); f.Expect(33, source, "Restore replay");
            }
            var after = new uint[originalBytes.Length]; Get<GraphicsBuffer>(f.inner, "pos").GetData(after);
            for (int i = 0; i < after.Length; ++i) Require(after[i] == originalBytes[i], "Sculpt rewrote source atlas positions");
            f.renderer.ResetPagedSculpt();
            f.Stroke(() => f.renderer.PinchSplatsGPU(center, 1, 0, -.5f));
            Vector3 expanded = source + (source - center) * .5f;
            f.Expect(33, expanded, "Negative Pinch expands");
            Require(f.page.bounds.Contains(expanded), "Negative Pinch escaped streaming bounds");
            f.Stroke(() => f.renderer.RestorePositionsInSphereGPU(expanded, .1f, 0, 4));
            f.Expect(33, source, "Restore strength above one stops at original");
        }

        static void MixedJournal(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 source = new Vector3(0, 0, 3), expected = new Vector3(.5f, .5f, 3);
            f.Stroke(() =>
            {
                f.renderer.SmudgeSplatsGPU(source, Vector3.right, .4f, 0, 1);
                f.renderer.PinchSplatsGPU(new Vector3(1, 1, 3), 2, 0, .5f);
                f.renderer.FlattenSplatsGPU(new Vector3(0, 0, 3), Vector3.right, 2, 0, .5f);
            });
            f.Expect(33, expected, "Mixed operation order");
            f.Replay(); f.Expect(33, expected, "Mixed replay order");
            Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
            f.Expect(33, source, "Mixed gesture Undo");
            Undo.PerformRedo(); f.Expect(33, expected, "Mixed gesture Redo");
            string saved = EditorJsonUtility.ToJson(f.renderer);
            f.renderer.ResetPagedSculpt();
            EditorJsonUtility.FromJsonOverwrite(saved, f.renderer);
            Set(f.renderer, "m_LodStreamer", Get<SplatBoxLodStreamer>(f.wrapper, "streamer"));
            Call(f.inner, "RecreateAtlas");
            f.Expect(33, expected, "Mixed serialized atlas recreation");
            f.Stroke(() => f.renderer.RestorePositionsInSphereGPU(expected, .1f, 0, .5f));
            f.Expect(33, (source + expected) * .5f, "Mixed restore uses original source");
            f.Replay(); f.Expect(33, (source + expected) * .5f, "Mixed restore persists");
        }

        static void RelaxAndRoughen(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 center = new Vector3(0, 0, 5);
            f.Positions(center, center - Vector3.right * .1f, center + Vector3.right * .1f, new Vector3(8, 0, 5));
            foreach (bool invert in new[] { false, true })
            {
                f.renderer.ResetPagedSculpt();
                f.Stroke(() => f.renderer.RelaxSplatsGPU(center, 1, 0, .5f, 1, invert));
                // The captured two leaf neighbours plus self form the deterministic local mean.
                float x = -.1f + (invert ? -1 : 1) * (.2f / 3) * .5f;
                f.Expect(33, center + Vector3.right * x, invert ? "Roughen direction" : "Relax mean");
                f.Expect(34, center - Vector3.right * x, "Symmetric neighbour mean");
                f.Expect(35, new Vector3(8, 0, 5), "Relax outside brush");
                f.Replay(); f.Expect(33, center + Vector3.right * x, "Relax captured replay");
                string json = EditorJsonUtility.ToJson(f.renderer);
                f.renderer.ResetPagedSculpt(); EditorJsonUtility.FromJsonOverwrite(json, f.renderer);
                Set(f.renderer, "m_LodStreamer", Get<SplatBoxLodStreamer>(f.wrapper, "streamer"));
                Call(f.inner, "RecreateAtlas"); f.Expect(33, center + Vector3.right * x, "Relax serialized field");
            }
        }

        static void LateDetailMixedJournal(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 source = new Vector3(0, 0, 3), lateSource = new Vector3(.05f, 0, 3);
            f.Positions(new Vector3(0, .5f, 4), source, new Vector3(3, 0, 3), lateSource);
            var original = (LodTreeNode[])f.page.lodTree.nodes.Clone();
            f.page.isCoarseStub = true; f.page.splatCount = 3;
            f.page.lodTree = LodTreeRuntime.BuildPrefix(new[] { original[0], original[1], original[2] });
            f.Stroke(() =>
            {
                f.renderer.SmudgeSplatsGPU(source, Vector3.right, .4f, 0, 1);
                f.renderer.PinchSplatsGPU(new Vector3(1, 1, 3), 2, 0, .5f);
                f.renderer.FlattenSplatsGPU(source, Vector3.right, 2, 0, .5f);
                f.renderer.RestorePositionsInSphereGPU(new Vector3(.5f, .5f, 3), .3f, 0, .5f);
            });
            Near(f.Offsets()[35], Vector3.zero, "Mixed sculpt wrote absent detail");
            for (int reload = 0; reload < 2; reload++)
            {
                f.page.isCoarseStub = false; f.page.splatCount = 4;
                f.page.lodTree = LodTreeRuntime.Build((LodTreeNode[])original.Clone(), true);
                f.Replay();
                f.Expect(33, new Vector3(.25f, .25f, 3), "Mixed reload existing leaf");
                f.Expect(35, new Vector3(.28125f, .25f, 3), "Mixed replay newly loaded leaf");
                f.page.isCoarseStub = true; f.page.splatCount = 3;
                f.page.lodTree = LodTreeRuntime.BuildPrefix(new[] { original[0], original[1], original[2] });
                f.Replay();
            }
        }

        static void EditorDispatch(string shader)
        {
            using var f = new Fixture(shader);
            var window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            try
            {
                Set(window, "m_TargetRenderer", f.renderer);
                foreach (string prefix in new[] { "Smudge", "Pinch", "Move", "Flatten", "Relax" })
                { Set(window, "m_" + prefix + "Falloff", 0f); Set(window, "m_" + prefix + "Strength", .5f); }
                f.owner.transform.SetPositionAndRotation(new Vector3(2, 3, 1), Quaternion.Euler(0, 0, 30));
                f.owner.transform.localScale = Vector3.one * 2;
                Vector3 source = f.Original(33), center = source + Vector3.right * .2f;
                Call(window, "ExecutePinchOptimized", f.owner.transform.TransformPoint(center), 2f);
                f.Expect(33, source + Vector3.right * .1f, "Editor Pinch transform/settings");
                f.renderer.ResetPagedSculpt();
                Call(window, "ExecuteMoveOptimized", f.owner.transform.TransformPoint(source),
                    f.owner.transform.TransformVector(Vector3.up), 2f);
                f.Expect(33, source + Vector3.up * .5f, "Editor Move transform/settings");
                Set(window, "m_SculptBrushTab", 2);
                Call(window, "ExecuteRestoreOptimized", f.owner.transform.TransformPoint(source + Vector3.up * .5f), 2f);
                f.Expect(33, source + Vector3.up * .25f, "Editor Alt restore settings");
                f.renderer.ResetPagedSculpt();
                Call(window, "ExecuteFlattenOptimized", f.owner.transform.TransformPoint(center),
                    f.owner.transform.TransformDirection(Vector3.right), 2f);
                f.Expect(33, source + Vector3.right * .1f, "Editor Flatten transform/settings");
                f.renderer.ResetPagedSculpt();
                f.owner.transform.localScale = new Vector3(2, 1, 3);
                Vector3 localNormal = new Vector3(1, 1, 0).normalized;
                Vector3 worldNormal = f.owner.transform.worldToLocalMatrix.transpose.MultiplyVector(localNormal).normalized;
                float flattenWorldRadius = f.owner.transform.lossyScale.magnitude / 1.732f;
                Call(window, "ExecuteFlattenOptimized", f.owner.transform.TransformPoint(source + localNormal * .2f),
                    worldNormal, flattenWorldRadius);
                f.Expect(33, source + localNormal * .1f, "Editor Flatten preserves plane under nonuniform scale");
                f.renderer.ResetPagedSculpt();
                f.owner.transform.localScale = Vector3.one * 2;
                Vector3 relaxCenter = new Vector3(0, 0, 5);
                f.Positions(relaxCenter, relaxCenter - Vector3.right * .25f, relaxCenter + Vector3.right * .25f,
                    relaxCenter + Vector3.right * .9f);
                Set(window, "m_RelaxNeighborRadius", .3f);
                f.Stroke(() => f.renderer.RelaxSplatsGPU(relaxCenter, 2, 0, .5f, .3f));
                Vector3 reference = f.Position(33);
                f.renderer.ResetPagedSculpt();
                float worldRadius = 2 * f.owner.transform.lossyScale.magnitude / 1.732f;
                Call(window, "ExecuteRelaxOptimized", f.owner.transform.TransformPoint(relaxCenter), worldRadius, false);
                f.Expect(33, reference, "Editor Relax applies neighbour fraction only once");
            }
            finally { UnityEngine.Object.DestroyImmediate(window); }
        }

        static uint Pack(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);
        static Vector3 Decode(uint value) => new Vector3((value & 2047) / 2047f * 20 - 10,
            ((value >> 11) & 1023) / 1023f * 20 - 10, ((value >> 21) & 2047) / 2047f * 10);
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static void PackedBrushes(string shader)
        {
            using var f = new Fixture(shader);
            string path = "Assets/__PackedSculpt_" + Guid.NewGuid().ToString("N");
            GaussianSplatPageAsset sourcePage = null;
            var asset = Get<GaussianSplatAsset>(f.inner, "asset");
            asset.Initialize(128, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
            var positions = new uint[128];
            for (int i = 0; i < positions.Length; i++) positions[i] = Pack(Vector3.one * .9f);
            positions[32] = positions[33] = Pack(new Vector3(.5f, .5f, .3f));
            positions[34] = Pack(new Vector3(.51f, .5f, .3f));
            var chunk = new GaussianSplatAsset.ChunkInfo { posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                colR = HalfRange(0, 1), colG = HalfRange(0, 1), colB = HalfRange(0, 1), colA = HalfRange(.5f, .9f),
                sclX = HalfRange(.1f, .2f), sclY = HalfRange(.1f, .2f), sclZ = HalfRange(.1f, .2f) };
            Get<GraphicsBuffer>(f.inner, "pos").SetData(positions);
            Get<GraphicsBuffer>(f.inner, "chunks").SetData(new[] { chunk });
            Set(f.renderer, "m_GpuChunksValid", true);
            Set(f.renderer, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(f.inner, "chunks")); Set(f.renderer, "m_LodUnifiedChunkCount", 1);
            try
            {
                byte[] bytes = new byte[16]; Buffer.BlockCopy(positions, 128, bytes, 0, bytes.Length);
                File.WriteAllBytes(path + "pos.bytes", bytes);
                File.WriteAllBytes(path + "tree.bytes", LodTreeNode.ToBytes(f.page.lodTree.nodes));
                var chunkBytes = new byte[Marshal.SizeOf<GaussianSplatAsset.ChunkInfo>()];
                IntPtr chunkMemory = Marshal.AllocHGlobal(chunkBytes.Length);
                try { Marshal.StructureToPtr(chunk, chunkMemory, false); Marshal.Copy(chunkMemory, chunkBytes, 0, chunkBytes.Length); }
                finally { Marshal.FreeHGlobal(chunkMemory); }
                File.WriteAllBytes(path + "chunk.bytes", chunkBytes);
                AssetDatabase.ImportAsset(path + "pos.bytes", ImportAssetOptions.ForceSynchronousImport);
                AssetDatabase.ImportAsset(path + "tree.bytes", ImportAssetOptions.ForceSynchronousImport);
                AssetDatabase.ImportAsset(path + "chunk.bytes", ImportAssetOptions.ForceSynchronousImport);
                var data = Get<TextAsset>(f.inner, "data");
                asset.SetAssetFiles(AssetDatabase.LoadAssetAtPath<TextAsset>(path + "chunk.bytes"),
                    AssetDatabase.LoadAssetAtPath<TextAsset>(path + "pos.bytes"), data, data, data);
                sourcePage = ScriptableObject.CreateInstance<GaussianSplatPageAsset>();
                sourcePage.Initialize(1, Vector3Int.zero, Vector3.one * -10, Vector3.one * 10, asset,
                    AssetDatabase.LoadAssetAtPath<TextAsset>(path + "tree.bytes"), 4, 3);
                f.page.source = sourcePage; f.page.gpuChunksValid = true; f.page.chunkInfos = new[] { chunk };
                var scene = f.renderer.pagedScene;
                scene.pages[0] = new GaussianSplatPageEntry { pageId = 1, boundsMin = Vector3.one * -10,
                    boundsMax = Vector3.one * 10, pageAsset = sourcePage, splatCount = 4, lodNodeCount = 4 };
                Vector3 source = Decode(positions[33]), other = Decode(positions[34]);
                Action<Vector3, string> check = (expected, label) =>
                {
                    Near(source + f.Offsets()[33], expected, label + " packed GPU");
                    Near(f.page.lodTree.nodes[1].center, expected, label + " packed CPU");
                };
                f.Stroke(() => f.renderer.PinchSplatsGPU(source + Vector3.right * .2f, .5f, 0, .5f));
                check(source + Vector3.right * .1f, "Pinch");
                f.Stroke(() => f.renderer.FlattenSplatsGPU(source + Vector3.up * .2f, Vector3.up, .5f, 0, .5f));
                Vector3 moved = source + new Vector3(.1f, .1f, 0); check(moved, "Flatten");
                f.Stroke(() => f.renderer.RestorePositionsInSphereGPU(moved, .05f, 0, .5f));
                check(source + new Vector3(.05f, .05f, 0), "Partial Restore");
                f.Replay(); check(source + new Vector3(.05f, .05f, 0), "Mixed replay");
                f.renderer.ResetPagedSculpt();
                f.Stroke(() => f.renderer.RelaxSplatsGPU(source, 1, 0, .5f, 1));
                Vector3 relaxed = source + (other - source) / 6; check(relaxed, "Relax");
                f.Replay(); check(relaxed, "Relax replay");
                f.Stroke(() => f.renderer.RestorePositionsInSphereGPU(relaxed, .05f, 0, 1));
                check(source, "Full Restore");
                var after = new uint[128]; Get<GraphicsBuffer>(f.inner, "pos").GetData(after, 0, 0, after.Length);
                for (int i = 0; i < positions.Length; i++) Require(after[i] == positions[i], "Packed sculpt changed source bytes");
            }
            finally
            {
                f.page.source = null; Set(f.renderer, "m_GpuLodUnifiedChunks", null);
                if (sourcePage != null) UnityEngine.Object.DestroyImmediate(sourcePage);
                AssetDatabase.DeleteAsset(path + "pos.bytes"); AssetDatabase.DeleteAsset(path + "tree.bytes");
                AssetDatabase.DeleteAsset(path + "chunk.bytes");
            }
        }

        static void RealPageReplay()
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; RenderTexture target = null;
            string scenePath = "Assets/__PagedSculptValidation_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer"); renderer.name = "Paged sculpt validation source";
                var camera = new GameObject("Paged sculpt validation camera").AddComponent<Camera>(); camera.tag = "MainCamera";
                target = new RenderTexture(640, 480, 0); target.Create(); camera.targetTexture = target;
                Preload(renderer, camera);
                renderer.BeginPagedSculptStroke();
                renderer.SmudgeSplatsGPU(new Vector3(.9f, 0, 5), Vector3.right * .4f, .05f, 0, 1);
                renderer.EndPagedSculptStroke();
                var list = Get<List<SplatBoxPageGpuState>>(renderer.lodStreamer, "m_LoadedList");
                SplatBoxPageGpuState missing = list.Find(page => page.pageId == 2);
                list.Remove(missing); // Source manifest still contains this page's fine leaves.
                try
                {
                    renderer.BeginPagedSculptStroke();
                    renderer.RelaxSplatsGPU(new Vector3(0, 0, 5), 2, 0, .5f, 1);
                    renderer.EndPagedSculptStroke();
                }
                finally { list.Add(missing); }
                Call(renderer, "ReplayPagedSmudgePage", null, missing, missing.atlasOffset);
                Call(renderer, "EnsurePagedSmudgeHierarchy");
                // All six source leaves (including the missing page and its earlier moved leaf)
                // sum to x=.4. Self is included once more, so the mean for x=-.1 is .3/7.
                Vector3 expectedMiddle = new Vector3(-.1f + (.3f / 7 + .1f) * .5f, 0, 5);
                ExpectRealLeaf(renderer, 1, 1, expectedMiddle);
                Vector3 expectedLate = new Vector3(1.3f + (1.7f / 7 - 1.3f) * .5f, 0, 5);
                ExpectRealLeaf(renderer, 2, 2, expectedLate);
                Preload(renderer, camera);
                ExpectRealLeaf(renderer, 1, 1, expectedMiddle); ExpectRealLeaf(renderer, 2, 2, expectedLate);
                AssetDatabase.SaveAssets();
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save sculpt scene");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                renderer = GameObject.Find("Paged sculpt validation source").GetComponent<SplatBoxRenderer>();
                camera = GameObject.Find("Paged sculpt validation camera").GetComponent<Camera>(); camera.targetTexture = target;
                Preload(renderer, camera);
                ExpectRealLeaf(renderer, 1, 1, expectedMiddle); ExpectRealLeaf(renderer, 2, 2, expectedLate);
                renderer.BeginPagedSculptStroke(); renderer.RestorePositionsInSphereGPU(new Vector3(0, 0, 5), 3, 0, 1); renderer.EndPagedSculptStroke();
                Preload(renderer, camera);
                ExpectRealLeaf(renderer, 1, 1, new Vector3(-.1f, 0, 5));
                ExpectRealLeaf(renderer, 2, 2, new Vector3(.9f, 0, 5));
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Preload(renderer, camera);
                ExpectRealLeaf(renderer, 1, 1, expectedMiddle); ExpectRealLeaf(renderer, 2, 2, expectedLate);
            }
            finally
            {
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); UnityEngine.Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
            }
        }

        static void SceneEventRouting()
        {
            using var f = new Fixture("Resources/BoxUtil.compute");
            var window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            var sceneView = ScriptableObject.CreateInstance<SceneView>();
            var brushOwner = new GameObject("Sculpt event validation brush"); brushOwner.SetActive(false);
            Action<SceneView> validateGui = null;
            try
            {
                Set(window, "m_TargetRenderer", f.renderer);
                Set(window, "m_PaintBrush", brushOwner.AddComponent<GaussianSplatPaintBrush>());
                var activeFields = new[] { "m_IsSmudging", "m_IsPinching", "m_IsMoving", "m_IsFlattening", "m_IsRelaxing", "m_IsRoughening", "m_IsRestoringSculpt" };
                foreach (EventType eventType in new[] { EventType.MouseLeaveWindow, EventType.Ignore, EventType.MouseMove })
                {
                    f.renderer.BeginPagedSculptStroke();
                    f.renderer.SmudgeSplatsGPU(new Vector3(0, 0, 3), Vector3.right * .02f, 1, 0, 1);
                    int before = f.renderer.pagedSculptDabCount;
                    Set(window, "m_PagedSmudgeStrokeRenderer", f.renderer);
                    foreach (string field in activeFields) Set(window, field, true);
                    Set(window, "m_SmudgeAccumulatedDelta", Vector3.one * 100);
                    Set(window, "m_SmudgeHasCachedSurface", true);
                    Call(window, "HandleSculptBrushScene", sceneView, new Event { type = eventType, button = 0 });
                    foreach (string field in activeFields) Require(!Get<bool>(window, field), eventType + " left " + field + " active");
                    Require(!Get<bool>(f.renderer, "m_PagedSmudgeStrokeOpen") &&
                        Get<SplatBoxRenderer>(window, "m_PagedSmudgeStrokeRenderer") == null &&
                        !Get<bool>(window, "m_SmudgeHasCachedSurface") &&
                        Get<Vector3>(window, "m_SmudgeAccumulatedDelta") == Vector3.zero &&
                        f.renderer.pagedSculptDabCount == before, eventType + " did not close the gesture without flushing motion");
                }

                bool ran = false, roughenRan = false; Exception failure = null;
                int gesture = 0, handledGesture = 0;
                Vector3 beforeSmallDrag = Vector3.zero;
                Vector2 cursor = Vector2.zero;
                sceneView.position = new Rect(100, 100, 640, 480);
                sceneView.ShowUtility(); sceneView.LookAtDirect(new Vector3(0, 0, 3), Quaternion.identity, 3);
                validateGui = view =>
                {
                    if (view != sceneView) return;
                    EventType expectedEvent = gesture == 2 || gesture == 3 ? EventType.MouseDrag : EventType.MouseDown;
                    if (ran && gesture > handledGesture && Event.current.rawType == expectedEvent)
                    {
                        handledGesture = gesture;
                        try
                        {
                            Require(Event.current.type == expectedEvent, "Scene View ignored sculpt gesture " + gesture);
                            // SendEvent uses host-window coordinates, whose toolbar/DPI
                            // offset varies by editor layout. Set the intended Scene GUI
                            // position inside the actual callback, where the ray is built.
                            Event.current.mousePosition = cursor + (gesture == 3 ? Vector2.right : Vector2.zero);
                            Call(window, "HandleSculptBrushScene", view, Event.current);
                            if (gesture == 1)
                                Require(Get<bool>(window, "m_IsSmudging"), "A fresh sculpt stroke did not pick its surface");
                            else if (gesture == 2)
                                Require(Get<bool>(window, "m_IsPinching"), "Shift in Smudge did not select Pinch");
                            else if (gesture == 3)
                            {
                                float moved = Vector3.Distance(beforeSmallDrag, f.Position(33));
                                Require(moved > .000001f && moved < .05f,
                                    "A small drag did not sculpt until MouseUp (fixed world-distance threshold)");
                                Call(window, "HandleSculptBrushScene", view, new Event { type = EventType.MouseLeaveWindow });
                                Set(window, "m_SculptBrushTab", 4);
                            }
                            else
                            {
                                roughenRan = true;
                                Require(Get<bool>(window, "m_IsRelaxing") && Get<bool>(window, "m_IsRoughening"),
                                    "Shift in Relax did not select Roughen");
                                Call(window, "HandleSculptBrushScene", view, new Event { type = EventType.MouseLeaveWindow });
                            }
                        }
                        catch (Exception exception) { failure = exception; }
                        return;
                    }
                    if (ran || Event.current.type != EventType.Repaint) return;
                    ran = true;
                    try
                    {
                        cursor = HandleUtility.WorldToGUIPoint(f.Position(33));
                        Set(window, "m_SculptBrushTab", 0); Set(window, "m_SmudgeRadius", 25f);
                        Set(window, "m_SmudgeStrength", .5f); Set(window, "m_SmudgeFalloff", 0f);
                        Set(window, "m_SmudgeHasCachedSurface", true);
                        Set(window, "m_SmudgeCachedDepth", Vector3.Dot(new Vector3(0, 0, 3) - view.camera.transform.position, view.camera.transform.forward));
                        Set(window, "m_SmudgeLastSurfaceUpdate", EditorApplication.timeSinceStartup + 100);
                        Set(window, "m_IsSmudging", true); Set(window, "m_SmudgeAccumulatedDelta", Vector3.one * 100);
                        f.renderer.BeginPagedSculptStroke(); Set(window, "m_PagedSmudgeStrokeRenderer", f.renderer);
                        int before = f.renderer.pagedSculptDabCount;
                        Call(window, "HandleSculptBrushScene", view, new Event { type = EventType.MouseDrag, button = 0,
                            mousePosition = cursor, modifiers = EventModifiers.Alt });
                        var dabs = Get<System.Collections.IList>(f.renderer, "m_PagedSmudgeDabs");
                        Require(Get<bool>(window, "m_IsRestoringSculpt") && !Get<bool>(window, "m_IsSmudging") &&
                            Get<Vector3>(window, "m_SmudgeAccumulatedDelta") == Vector3.zero && dabs.Count == before + 1 &&
                            Get<int>(dabs[dabs.Count - 1], "kind") == 3, "Alt pressed mid-drag did not switch only to Restore");
                        before = dabs.Count;
                        Call(window, "HandleSculptBrushScene", view, new Event { type = EventType.MouseDrag, button = 0, mousePosition = cursor });
                        Require(!Get<bool>(window, "m_IsRestoringSculpt") && Get<bool>(window, "m_IsSmudging") &&
                            f.renderer.pagedSculptDabCount == before && Get<Vector3>(window, "m_SmudgeAccumulatedDelta") == Vector3.zero,
                            "Alt release did not reinitialize the selected brush without a jump");
                        Set(window, "m_SmudgeAccumulatedDelta", Vector3.one * 100);
                        Call(window, "HandleSculptBrushScene", view, new Event { type = EventType.MouseUp, button = 0,
                            mousePosition = cursor, modifiers = EventModifiers.Alt });
                        Require(!Get<bool>(f.renderer, "m_PagedSmudgeStrokeOpen") && !Get<bool>(window, "m_IsSmudging") &&
                            f.renderer.pagedSculptDabCount == before, "Alt release flushed pending normal movement");

                    }
                    catch (Exception exception) { failure = exception; }
                };
                SceneView.duringSceneGui += validateGui;
                sceneView.SendEvent(new Event { type = EventType.Layout });
                sceneView.SendEvent(new Event { type = EventType.Repaint });
                Require(ran, "Scene event validation did not enter a real Scene GUI callback");
                if (failure != null) throw failure;
                // Send fresh gestures as real GUI events. Constructing MouseDown inside
                // Repaint after a consumed MouseUp can turn it into EventType.Ignore.
                gesture = 1;
                sceneView.SendEvent(new Event { type = EventType.MouseEnterWindow, mousePosition = cursor });
                sceneView.SendEvent(new Event { type = EventType.MouseDown, button = 0, mousePosition = cursor });
                if (failure != null) throw failure;
                Require(handledGesture == gesture, "Fresh sculpt click did not reach Scene GUI");
                gesture = 2;
                sceneView.SendEvent(new Event { type = EventType.MouseDrag, button = 0, mousePosition = cursor, modifiers = EventModifiers.Shift });
                if (failure != null) throw failure;
                Require(handledGesture == gesture, "Pinch drag did not reach Scene GUI");
                beforeSmallDrag = f.Position(33); Set(window, "m_SmudgeLastExecuteTime", -100d);
                gesture = 3;
                sceneView.SendEvent(new Event { type = EventType.MouseDrag, button = 0, mousePosition = cursor + Vector2.right });
                if (failure != null) throw failure;
                Require(handledGesture == gesture, "Small drag did not reach Scene GUI");
                gesture = 4;
                sceneView.SendEvent(new Event { type = EventType.MouseEnterWindow, mousePosition = cursor });
                sceneView.SendEvent(new Event { type = EventType.MouseDown, button = 0,
                    mousePosition = cursor, modifiers = EventModifiers.Shift });
                Require(roughenRan, "Roughen click did not enter the Scene GUI callback");
                if (failure != null) throw failure;
            }
            finally
            {
                if (validateGui != null) SceneView.duringSceneGui -= validateGui;
                sceneView.Close(); UnityEngine.Object.DestroyImmediate(window); UnityEngine.Object.DestroyImmediate(brushOwner);
            }
        }

        static void Preload(SplatBoxRenderer renderer, Camera camera) => typeof(PagedSmudgeValidation)
            .GetMethod("Preload", BindingFlags.Static | BindingFlags.NonPublic).Invoke(null, new object[] { renderer, camera });
        static void ExpectRealLeaf(SplatBoxRenderer renderer, int pageId, int index, Vector3 expected)
        {
            SplatBoxPageGpuState page = null;
            foreach (var candidate in renderer.lodStreamer.loadedPages) if (candidate.pageId == pageId) page = candidate;
            Require(page != null, "Expected streamed page is missing");
            Near(page.lodTree.nodes[index].center, expected, "Real page CPU replay");
            var basePos = new Vector3[3]; page.gpuPosData.GetData(basePos);
            var offsets = Get<GraphicsBuffer>(renderer, "m_GpuPagedSmudgeOffsets");
            var displacement = new Vector3[1]; offsets.GetData(displacement, 0, page.atlasOffset + index, 1);
            Near(basePos[index] + displacement[0], expected, "Real page GPU replay");
            Require(page.bounds.Contains(expected), "Streaming bounds exclude sculpted leaf");
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use isolated batch project with graphics device");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    PinchFlattenRestore(shader); MixedJournal(shader); LateDetailMixedJournal(shader);
                    RelaxAndRoughen(shader); EditorDispatch(shader); PackedBrushes(shader);
                }
                RealPageReplay();
                SceneEventRouting();
                Require(errors.Count == 0, "Paged sculpt logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Paged Sculpt PASS: all brush operations, falloff, Move/editor dispatch, partial/full Restore, " +
                    "ordered mixed journal, CPU/GPU parity, Relax/Roughen captured neighbours, unloaded leaves, Undo/Redo, " +
                    "saved scene replay and Scene GUI Alt/Shift/cancel event routing.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
