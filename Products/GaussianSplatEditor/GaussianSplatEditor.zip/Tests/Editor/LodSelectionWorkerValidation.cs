// SPDX-License-Identifier: MIT

using System;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    // CPU-only: -executeMethod GaussianSplatting.Tests.LodSelectionWorkerValidation.Run -quit
    public static class LodSelectionWorkerValidation
    {
        public static void Run()
        {
            ValidateSnapshotAndParity();
            ValidateTraversalLimitSnapshot();
            ValidateAtlasGather();
            ValidateCooperativeCancellation();
            ValidateDiscardAndFaults();
            ValidateEditorTeardown();
            UnityEngine.Debug.Log("SplatBox LoD worker PASS: immutable metadata/stereo/traversal-limit snapshot, synchronous parity, " +
                "single selection ownership, cooperative cancellation/reset/counting, reusable buffers, " +
                "discarded results and nonblocking disposal.");
        }

        static void ValidateSnapshotAndParity()
        {
            var pages = Pages();
            var originalPage = pages[0];
            var view = View();
            var expected = new LodActiveSplatRef[16];
            var syncWorkspace = new SplatBoxLodTraverser.Workspace();
            int count = SplatBoxLodTraverser.Traverse(pages, pages.Length, view, expected.Length, 0,
                expected, syncWorkspace);
            Require(count == 4, "Fixture must retain both pages through the right eye");
            using var worker = new SplatBoxLodSelectionWorker();
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0), "Initial selection did not start");
            Require(worker.isRunning && !worker.TryBegin(pages, pages.Length, view, 16, 0),
                "A second selection reused in-flight/unconsumed buffers");

            // Renderer inputs may change immediately after scheduling. Tree arrays themselves
            // remain immutable and are retained by reference, avoiding a multi-million-node copy.
            pages[0] = default;
            pages[1] = default;
            view.cullPlanes[0] = new float4(1, 0, 0, -1000);
            view.rightEyeCullPlanes[0] = new float4(1, 0, 0, -1000);
            view.pixelScaleFactor = 1;
            var snapshot = (SplatBoxLodTraverser.PageContext[])Field(worker, "m_Pages");
            var snapshotView = (SplatBoxLodTraverser.ViewContext)Field(worker, "m_View");
            Require(snapshot[0].pageSlot == originalPage.pageSlot &&
                ReferenceEquals(snapshot[0].nodes, originalPage.nodes),
                "Worker did not snapshot context values while retaining immutable source nodes");
            Require(!ReferenceEquals(snapshotView.cullPlanes, view.cullPlanes) &&
                !ReferenceEquals(snapshotView.rightEyeCullPlanes, view.rightEyeCullPlanes) &&
                snapshotView.rightEyeCullPlanes[0].w == 100 && snapshotView.pixelScaleFactor == 1000,
                "Worker retained mutable renderer view/frustum arrays");
            var result = Complete(worker);
            Require(result.selected == count && result.elapsedMs >= 0 &&
                !ReferenceEquals(result.workspace, syncWorkspace), "Worker result metadata is invalid");
            Require(result.atlasIndices == null && result.atlasBases == null &&
                result.selectedSlots == null && result.maxSplatIndexBySlot == null,
                "Selection without an atlas table exposed stale gathered metadata");
            for (int i = 0; i < count; ++i)
                Require(result.output[i].pageSlot == expected[i].pageSlot &&
                    result.output[i].splatIndex == expected[i].splatIndex,
                    "Worker selection differs from synchronous selection at " + i);
            Require(!worker.isRunning, "Completed selection retained exclusive ownership");
            Require(snapshot[0].nodes == null && snapshot[1].nodes == null &&
                (int)Field(worker, "m_PageCount") == 0,
                "Completed worker retained obsolete source tree arrays");

            // A subsequent request reuses the worker's storage after the old result is consumed.
            pages = Pages();
            view = View();
            Require(worker.TryBegin(pages, pages.Length, view, 8, 0), "Consumed worker did not restart");
            var second = Complete(worker);
            Require(ReferenceEquals(result.output, second.output) &&
                ReferenceEquals(result.workspace, second.workspace), "Worker needlessly replaced reusable storage");
            Require(second.selected == count, "Repeated selection lost coverage");

            Require(worker.TryBegin(pages, pages.Length, view, 8, 0), "Discard fixture did not start");
            worker.DiscardPending();
            DrainDiscarded(worker);
        }

        static void ValidateDiscardAndFaults()
        {
            var pages = Pages();
            var view = View();
            using var worker = new SplatBoxLodSelectionWorker();
            // A controlled incomplete task makes the scheduling contract deterministic even when
            // the tiny real traversal completes before the main test thread can discard it.
            var pending = new TaskCompletionSource<SplatBoxLodSelectionWorker.Result>();
            var workspace = (SplatBoxLodTraverser.Workspace)Field(worker, "m_Workspace");
            var output = new LodActiveSplatRef[16];
            var snapshot = (SplatBoxLodTraverser.PageContext[])pages.Clone();
            SetField(worker, "m_Output", output);
            SetField(worker, "m_Pages", snapshot);
            SetField(worker, "m_PageCount", snapshot.Length);
            SetField(worker, "m_Task", pending.Task);
            worker.DiscardPending();
            Require(worker.isRunning && !worker.TryComplete(out _) &&
                !worker.TryBegin(pages, pages.Length, view, 16, 0),
                "Discard allowed unfinished selection storage to be reused");
            Require(CancellationRequested(workspace) &&
                ReferenceEquals(Field(worker, "m_Workspace"), workspace) &&
                ReferenceEquals(Field(worker, "m_Output"), output) && snapshot[0].nodes != null,
                "Discard did not signal cancellation or released storage before task completion");
            pending.SetResult(default);
            Require(!worker.TryComplete(out _) && !worker.isRunning, "Discarded selection was published");
            Require(snapshot[0].nodes == null && snapshot[1].nodes == null &&
                ReferenceEquals(Field(worker, "m_Output"), output) && worker.cancelledSelectionCount == 0,
                "Retirement retained source arrays, lost reusable output, or counted an unobserved cancellation");

            pending = new TaskCompletionSource<SplatBoxLodSelectionWorker.Result>();
            SetField(worker, "m_Task", pending.Task);
            worker.DiscardPending();
            pending.SetException(new InvalidOperationException("Expected discarded worker failure"));
            Require(!worker.TryComplete(out _) && !worker.isRunning,
                "A discarded fault escaped or retained ownership");

            var failure = new InvalidOperationException("Expected worker validation failure");
            SetField(worker, "m_Task", Task.FromException<SplatBoxLodSelectionWorker.Result>(failure));
            bool caught = false;
            try { worker.TryComplete(out _); }
            catch (InvalidOperationException ex) { caught = ReferenceEquals(ex, failure); }
            Require(caught && !worker.isRunning, "Worker fault was hidden or ownership was not released");
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0), "Worker did not recover after a fault");
            Complete(worker);

            pending = new TaskCompletionSource<SplatBoxLodSelectionWorker.Result>();
            workspace = (SplatBoxLodTraverser.Workspace)Field(worker, "m_Workspace");
            output = (LodActiveSplatRef[])Field(worker, "m_Output");
            snapshot = (SplatBoxLodTraverser.PageContext[])pages.Clone();
            SetField(worker, "m_Pages", snapshot);
            SetField(worker, "m_PageCount", snapshot.Length);
            SetField(worker, "m_Task", pending.Task);
            var timer = Stopwatch.StartNew();
            worker.Dispose();
            timer.Stop();
            Require(timer.ElapsedMilliseconds < 100 && !pending.Task.IsCompleted,
                "Dispose waited for an ongoing selection");
            Require(worker.isRunning && CancellationRequested(workspace) &&
                ReferenceEquals(Field(worker, "m_Workspace"), workspace) &&
                ReferenceEquals(Field(worker, "m_Output"), output) && snapshot[0].nodes != null,
                "Dispose did not signal cancellation or released owned arrays before completion");
            Require(!worker.TryBegin(pages, pages.Length, view, 16, 0), "Disposed worker restarted");
            Require(SplatBoxLodTraverser.Traverse(pages, pages.Length, view, 16, 0, output, workspace) == 0 &&
                workspace.wasCancelled, "Disposed traversal did not observe the cancellation request");
            pending.SetResult(new SplatBoxLodSelectionWorker.Result { workspace = workspace, output = output });
            Require(!worker.TryComplete(out _), "Disposed worker published a selection");
            Require(Field(worker, "m_Pages") == null && Field(worker, "m_Task") == null,
                "Disposed task completion did not release captured source/result storage");
            Require(Field(worker, "m_Output") == null && Field(worker, "m_Workspace") == null &&
                snapshot[0].nodes == null && snapshot[1].nodes == null && worker.cancelledSelectionCount == 1,
                "Disposed canceled task retained owned arrays or was not counted once");
            // A late main-thread observer can race the disposal continuation. Re-observing that
            // same completed task must not count its cancellation a second time.
            SetField(worker, "m_Task", pending.Task);
            Require(!worker.TryComplete(out _) && worker.cancelledSelectionCount == 1,
                "The disposal continuation and final poll double-counted one canceled selection");
        }

        static void ValidateCooperativeCancellation()
        {
            var pages = Pages();
            var view = View();
            using var worker = new SplatBoxLodSelectionWorker();
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0), "Cancellation fixture did not start");
            var first = Complete(worker);
            var workspace = first.workspace;
            RequestCancellation(workspace);
            Require(CancellationRequested(workspace), "Workspace did not receive a cancellation signal");
            Require(SplatBoxLodTraverser.Traverse(pages, pages.Length, view, 16, 0, first.output, workspace) == 0 &&
                workspace.wasCancelled, "A canceled workspace did not stop traversal");

            // Even without the main-thread discard flag, a completed traversal that reports
            // cancellation must never expose its partial/stale output as a valid selection.
            SetField(worker, "m_Task", Task.FromResult(new SplatBoxLodSelectionWorker.Result
            {
                selected = 4, output = first.output, workspace = workspace
            }));
            Require(!worker.TryComplete(out var canceled) && canceled.output == null &&
                canceled.workspace == null && !worker.isRunning && worker.cancelledSelectionCount == 1,
                "A canceled result was published or was not counted");
            Require(CancellationRequested(workspace), "Consumption cleared a cancellation outside the next request");

            Require(worker.TryBegin(pages, pages.Length, view, 16, 0), "Canceled worker did not restart");
            Require(!CancellationRequested(workspace), "Accepted request did not reset cancellation before scheduling");
            var resumed = Complete(worker);
            Require(resumed.selected == 4 && !resumed.workspace.wasCancelled &&
                ReferenceEquals(resumed.output, first.output) && ReferenceEquals(resumed.workspace, workspace) &&
                worker.cancelledSelectionCount == 1,
                "Restart retained cancellation, lost coverage/storage, or reset the cumulative counter");

            // Signaling an already completed traversal cannot make it an actually canceled job.
            SetField(worker, "m_Task", Task.FromResult(resumed));
            worker.DiscardPending();
            Require(!worker.isRunning && !worker.TryComplete(out _) && worker.cancelledSelectionCount == 1,
                "Discarding an already finished selection counted a cancellation that was never observed");
        }

        static void RequestCancellation(SplatBoxLodTraverser.Workspace workspace) => workspace.GetType()
            .GetMethod("RequestCancellation", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(workspace, null);

        static bool CancellationRequested(SplatBoxLodTraverser.Workspace workspace) =>
            Volatile.Read(ref ((int[])Field(workspace, "cancellationRequest"))[0]) != 0;

        static void ValidateTraversalLimitSnapshot()
        {
            var pages = Pages();
            pages[0].nodeLimit = 1;
            pages[1].nodeLimit = 2; // One available sibling cannot replace the second root.
            using var worker = new SplatBoxLodSelectionWorker();
            Require(worker.TryBegin(pages, pages.Length, View(), 16, 0),
                "Capped worker selection did not start");
            pages[0].nodeLimit = 0;
            pages[1].nodeLimit = 3;
            var snapshot = (SplatBoxLodTraverser.PageContext[])Field(worker, "m_Pages");
            Require(snapshot[0].nodeLimit == 1 && snapshot[1].nodeLimit == 2 &&
                ReferenceEquals(snapshot[0].nodes, pages[0].nodes),
                "Worker did not isolate traversal limits while retaining immutable node arrays");
            var coarse = Complete(worker);
            Require(coarse.selected == 2 && coarse.workspace.emittedMerged == 2,
                "Renderer limit changes affected the in-flight coarse frontier");
            for (int i = 0; i < coarse.selected; i++)
                Require(coarse.output[i].splatIndex == 0, "Capped worker emitted an unavailable child");

            Require(worker.TryBegin(pages, pages.Length, View(), 16, 0),
                "Worker did not accept the next refinement step");
            var fine = Complete(worker);
            Require(fine.selected == 4 && fine.workspace.emittedLeaves == 4,
                "Worker retained stale limits after refinement advanced");
        }

        static void ValidateAtlasGather()
        {
            using var worker = new SplatBoxLodSelectionWorker();
            var pages = Pages();
            var view = View();
            var bases = new int[10];
            for (int i = 0; i < bases.Length; ++i) bases[i] = -1;
            bases[7] = 1000;
            bases[8] = 2000;
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0, bases), "Atlas gather did not start");
            bases[7] = 9000;
            bases[8] = -1;
            var result = Complete(worker);
            Require(result.atlasIndices != null && !ReferenceEquals(result.atlasBases, bases) &&
                result.atlasBases[7] == 1000 && result.atlasBases[8] == 2000,
                "Worker did not snapshot page atlas bases");
            for (int i = 0; i < result.selected; ++i)
            {
                var reference = result.output[i];
                Require(result.atlasIndices[i] == result.atlasBases[reference.pageSlot] + reference.splatIndex,
                    "Worker gathered an incorrect atlas index");
            }
            Require(result.selectedSlots[7] && result.selectedSlots[8] && !result.selectedSlots[0] &&
                result.maxSplatIndexBySlot[7] == 2 && result.maxSplatIndexBySlot[8] == 2,
                "Worker's selected-slot bounds do not describe its output");

            bases[7] = 1000;
            bases[8] = 2000;
            Require(worker.TryBegin(pages, 1, view, 16, 0, bases), "Repeated atlas gather did not start");
            var onePage = Complete(worker);
            Require(onePage.selectedSlots[7] && !onePage.selectedSlots[8] &&
                onePage.maxSplatIndexBySlot[8] == 0 && ReferenceEquals(result.atlasIndices, onePage.atlasIndices),
                "Repeated gather retained obsolete selected slots or replaced its output buffer");

            // A missing slot or an unresident negative base must never publish wrapped GPU indices.
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0, new int[8]), "Unknown slot fixture did not start");
            Require(Complete(worker).atlasIndices == null, "Unknown page slot published gathered indices");
            bases[8] = -1;
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0, bases), "Unresident slot fixture did not start");
            Require(Complete(worker).atlasIndices == null, "Unresident page published gathered indices");
        }

        static SplatBoxLodSelectionWorker.Result Complete(SplatBoxLodSelectionWorker worker)
        {
            var timer = Stopwatch.StartNew();
            while (timer.ElapsedMilliseconds < 10000)
            {
                if (worker.TryComplete(out var result)) return result;
                Thread.Sleep(1);
            }
            throw new Exception("Timed out awaiting worker selection");
        }

        static void ValidateEditorTeardown()
        {
            using var worker = new SplatBoxLodSelectionWorker();
            var pages = Pages();
            var view = View();
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0), "Editor teardown fixture did not start");
            const BindingFlags flags = BindingFlags.Static | BindingFlags.NonPublic;
            var type = typeof(SplatBoxLodSelectionWorker);
            try
            {
                type.GetMethod("DrainForEditorTeardown", flags).Invoke(null, null);
                Require(worker.TryComplete(out var result) && result.selected == 4,
                    "Editor teardown returned before the native selection completed");
                Require(!worker.TryBegin(pages, pages.Length, view, 16, 0),
                    "Editor teardown allowed another native selection to begin");
                var registry = type.GetField("s_ActiveTasks", flags).GetValue(null);
                Require((int)registry.GetType().GetProperty("Count").GetValue(registry) == 0,
                    "Editor task registry retained completed selections");
            }
            finally
            {
                type.GetField("s_EditorStopping", flags).SetValue(null, false);
            }
            Require(worker.TryBegin(pages, pages.Length, view, 16, 0), "Worker did not resume after editor transition");
            Complete(worker);
        }

        static void DrainDiscarded(SplatBoxLodSelectionWorker worker)
        {
            var timer = Stopwatch.StartNew();
            while (worker.isRunning && timer.ElapsedMilliseconds < 10000)
            {
                Require(!worker.TryComplete(out _), "Discarded real traversal was published");
                Thread.Sleep(1);
            }
            Require(!worker.isRunning, "Discarded traversal did not release ownership");
        }

        static SplatBoxLodTraverser.PageContext[] Pages()
        {
            var pages = new SplatBoxLodTraverser.PageContext[2];
            for (int p = 0; p < pages.Length; ++p)
            {
                var nodes = new[]
                {
                    new LodTreeNode { center = new float3(p * 2, 0, 10), featureSize = 4,
                        childStart = 1, childCount = 2, flags = LodTreeNode.kFlagMerged },
                    new LodTreeNode { center = new float3(p * 2 - 0.5f, 0, 10), featureSize = 0.1f },
                    new LodTreeNode { center = new float3(p * 2 + 0.5f, 0, 10), featureSize = 0.1f }
                };
                pages[p] = new SplatBoxLodTraverser.PageContext { pageSlot = 7 + p, nodes = nodes,
                    localToWorld = float4x4.identity, lodScale = 1, outsideFoveate = 1, behindFoveate = 1 };
            }
            return pages;
        }

        static SplatBoxLodTraverser.ViewContext View()
        {
            var left = new float4[6];
            var right = new float4[6];
            left[0] = new float4(1, 0, 0, -100);
            right[0] = new float4(1, 0, 0, 100);
            return new SplatBoxLodTraverser.ViewContext
            {
                cameraForward = new float3(0, 0, 1), screenHeight = 1000,
                frustumCull = true, pixelsPerUnitAtUnitDistance = 500, pixelScaleFactor = 1000,
                cosHalfFovY = 0.7f, splatScale = 1, cullPlanes = left, rightEyeCullPlanes = right
            };
        }

        static object Field(object target, string name) => target.GetType()
            .GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(target);
        static void SetField(object target, string name, object value) => target.GetType()
            .GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).SetValue(target, value);
        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
