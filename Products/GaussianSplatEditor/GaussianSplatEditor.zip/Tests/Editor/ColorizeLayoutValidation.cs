// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    public static class ColorizeLayoutValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Flags).SetValue(target, value);
        static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Flags).GetValue(target);
        static void Layout(GaussianSplatEditorWindow window)
        {
            window.SendEvent(new Event { type = EventType.Layout });
            window.SendEvent(new Event { type = EventType.Repaint });
        }

        public static void Run()
        {
            if (!Application.isBatchMode) throw new InvalidOperationException("Run Colorize layout validation in an isolated batch-mode project.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            GaussianSplatEditorWindow window = null;
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) => {
                if (message.Contains("Invalid GUILayout state") || message.Contains("Getting control") ||
                    message.Contains("ImmediateModeException")) errors.Add(message);
            };
            Application.logMessageReceived += observe;
            try
            {
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
                window.ShowUtility();
                Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.PaintBrush);
                Set(window, "m_PaintBrushMode", 1);
                Set(window, "m_ShowToolSettings", true);
                Layout(window);
                var brush = Get<GaussianSplatColorizeBrush>(window, "m_ColorizeBrush");
                if (brush == null) throw new InvalidOperationException("Colorize did not initialize during Layout.");
                var undo = Get<List<RenderTexture>>(brush, "m_UndoStack");
                var redo = Get<List<RenderTexture>>(brush, "m_RedoStack");
                // Null entries exercise availability/count changes without allocating GPU snapshots.
                var changes = new Action[] {
                    () => brush.UseNoise = true,
                    () => brush.UseNoise = false,
                    () => undo.Add(null),
                    () => { undo.Clear(); redo.Add(null); },
                    () => brush.ClearUndoHistory(),
                    () => brush.BlendMode = ColorizeBlendMode.Multiply,
                    () => brush.TargetColor = Color.gray,
                    () => Set(window, "m_PaintBrushMode", 0),
                    () => Set(window, "m_PaintBrushMode", 1),
                    () => Set(window, "m_CurrentTool", GaussianSplatEditorWindow.BrushTool.ColorizeBrush),
                    () => brush.UseNoise = true,
                    () => Set(window, "m_ShowLightingWorkspace", true),
                    () => Set(window, "m_ShowLightingWorkspace", false),
                };
                foreach (var change in changes)
                {
                    window.SendEvent(new Event { type = EventType.Layout });
                    change();
                    window.SendEvent(new Event { type = EventType.Repaint });
                    Layout(window);
                }
                if (brush.UndoCount != 0 || brush.RedoCount != 0)
                    throw new InvalidOperationException("Clear History did not clear local Colorize history.");
                if (errors.Count != 0) throw new InvalidOperationException("Colorize layout regression: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Colorize layout PASS: Paint > Colorize cold initialization, noise, history changes, mode/tool changes and lighting transitions between events.");
            }
            finally
            {
                if (window != null) window.Close();
                Application.logMessageReceived -= observe;
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            }
        }
    }
}
