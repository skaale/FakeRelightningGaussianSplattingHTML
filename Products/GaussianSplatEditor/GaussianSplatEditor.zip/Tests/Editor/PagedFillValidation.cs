// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    public static class PagedFillValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        struct View { public Vector4 clip; public uint a, b, c, d; public Vector3 world; public uint index; }
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Set(object value, string field, object data) => value.GetType().GetField(field, Flags).SetValue(value, data);
        static object Call(object value, string method, params object[] args) => value.GetType().GetMethod(method, Flags).Invoke(value, args);
        static Vector3[] Square(float x, float y, float z, float half = 0.2f) => new[] {
            new Vector3(x-half,y-half,z), new Vector3(x+half,y-half,z),
            new Vector3(x+half,y+half,z), new Vector3(x-half,y+half,z) };
        static void Polygon(GaussianSplatFillBrush brush, Vector3[] points)
        {
            brush.Clear(); brush.StartDrawing(points[0], Vector3.forward);
            for (int i = 1; i < points.Length; ++i) brush.AddVertex(points[i]);
            brush.ClosePolygon();
        }
        static void Preload(SplatBoxRenderer renderer, Camera camera)
        {
            Require(renderer.ForceRebuildPagedLodInEditor(), "Source did not initialize.");
            for (int i = 0; i < 10; ++i)
            {
                if (renderer.lodStreamer != null) Set(renderer.lodStreamer, "m_LastPageUploadFrame", -1);
                renderer.PreloadPagedLodPages(camera);
            }
        }
        static GaussianSplatAssetCreator.InputSplatData[] Samples(SplatBoxRenderer source, Vector3[] polygon, float width = 0.2f)
        {
            using var buffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, Math.Max(1, source.activeSplatCount), UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>());
            Require(source.ExportPagedPolygonSamples(polygon, Vector3.forward, 0.2f, width, buffer, out int count), "Edge sample export failed.");
            var data = new GaussianSplatAssetCreator.InputSplatData[count];
            if (count > 0) buffer.GetData(data, 0, 0, count);
            return data;
        }
        static View[] Draw(SplatBoxRenderer renderer, Camera camera, RenderTexture target)
        {
            typeof(PagedXcopyCameraValidation).GetMethod("Draw", BindingFlags.Static | BindingFlags.NonPublic)
                .Invoke(null, new object[] { camera, target, new List<SplatBoxRenderer>() });
            var data = new View[renderer.activeSplatCount];
            ((GraphicsBuffer)renderer.GetType().GetField("m_GpuView", Flags).GetValue(renderer)).GetData(data, 0, 0, data.Length);
            return data;
        }
        static Color ViewColor(View view) => new Color(Mathf.HalfToFloat((ushort)(view.c >> 16)),
            Mathf.HalfToFloat((ushort)view.c), Mathf.HalfToFloat((ushort)(view.d >> 16)), Mathf.HalfToFloat((ushort)view.d));

        public static void RunAll()
        {
            Require(Application.isBatchMode, "Run in an isolated batch project with a graphics device.");
            FillLayoutValidation.Run();
            PagedFillGenerationValidation.Run();
            PagedLodEditingValidation.RunPolygonDelete();
            PagedLodEditingValidation.Run();
            Run();
            Debug.Log("SplatBox Fill suite PASS.");
        }

        public static void Run()
        {
            Require(Application.isBatchMode, "Run in an isolated batch project with a graphics device.");
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; GaussianSplatEditorWindow window = null; RenderTexture target = null;
            var folders = new HashSet<string>();
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) => {
                if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message);
            };
            Application.logMessageReceived += observe;
            string scenePath = "Assets/__PagedFill_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var type = Assembly.Load("SplatBox.Rendering.Validation").GetType("GaussianSplatting.Tests.PagedLodEditorRecoveryValidation+Fixture", true);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var source = (SplatBoxRenderer)type.GetField("renderer", Flags).GetValue(fixture);
                Set(source, "m_UseRelightShader", true); Set(source, "m_LodFastEditorPreview", true);
                var camera = new GameObject("Fill test camera") { tag = "MainCamera" }.AddComponent<Camera>();
                target = new RenderTexture(640, 480, 0, RenderTextureFormat.ARGB32); target.Create(); camera.targetTexture = target;
                Preload(source, camera);
                var polygon = Square(0, 0, 5);
                string packageRoot = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                foreach (string path in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    Set(source, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(packageRoot + "/" + path)); Call(source, "InitializeKernels");
                    var samples = Samples(source, polygon);
                    Require(samples.Length == 2, "Expected the two displayed central leaves as edge samples, got " + samples.Length);
                    foreach (var sample in samples)
                        Require(Mathf.Abs(sample.pos.z-5) < 0.001f && Mathf.Abs(sample.pos.x) < 0.2f, "Edge sampling included distant geometry.");
                    var cutout = new GameObject("Fill sampling cutout").AddComponent<GaussianCutout>();
                    cutout.transform.position = new Vector3(-0.1f,0,5); cutout.transform.localScale = Vector3.one * 0.03f;
                    source.m_Cutouts = new[] { cutout }; source.EditDeleteSphere(new Vector3(0.1f,0,5), 0.03f);
                    Require(Samples(source, polygon).Length == 0, "Fill sampled cut or erased splats.");
                    source.m_Cutouts = Array.Empty<GaussianCutout>(); Object.DestroyImmediate(cutout); source.ResetDeletedSplats();
                    // Concave notch excludes the right leaf; replay must retain both independent polygons.
                    var concave = new[] { new Vector3(-0.2f,-0.2f,5),new Vector3(0.2f,-0.2f,5),new Vector3(0.2f,-0.05f,5),
                        new Vector3(0,-0.05f,5),new Vector3(0,0.2f,5),new Vector3(-0.2f,0.2f,5) };
                    Require(source.DeletePagedSplatsInPolygon(concave, Vector3.forward, 0.2f), "Concave polygon deletion failed.");
                    samples = Samples(source, polygon);
                    Require(samples.Length == 1 && samples[0].pos.x > 0, "Polygon delete ignored its concave notch.");
                    Require(source.DeletePagedSplatsInPolygon(Square(0.1f,0,5,0.04f), Vector3.forward, 0.2f), "Second polygon deletion failed.");
                    Preload(source, camera);
                    Require(Samples(source, polygon).Length == 0, "Polygon erase replay lost an earlier polygon or page edit.");
                    source.ResetDeletedSplats();
                }
                var holder = new GameObject("Fill test brush"); holder.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatFillBrush>(); brush.TargetRenderer = source;
                window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>(); Set(window,"m_TargetRenderer",source); Set(window,"m_FillBrush",brush);
                brush.SelectionDepth = 0.2f; brush.EdgeSampleWidth = 0.2f; brush.PositionJitter = 0;
                SplatBoxRenderer Fill()
                {
                    var before = new HashSet<SplatBoxRenderer>(Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsSortMode.None));
                    Call(window,"ExecuteFillInEditor",camera,false);
                    SplatBoxRenderer result = null;
                    foreach (var renderer in Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsSortMode.None))
                        if (!before.Contains(renderer)) { Require(result == null,"Fill created unexpected extra renderers."); result = renderer; }
                    Require(result != null,"Fill did not produce an object: " + window.GetType().GetField("m_PagedFillStatus",Flags).GetValue(window));
                    folders.Add(System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(result.m_Asset)).Replace('\\','/'));
                    return result;
                }
                Polygon(brush,polygon); brush.FillDensity = 0.5f;
                var fill = Fill(); int lowCount = fill.activeSplatCount;
                Require(lowCount > 0 && !fill.UsesPagedLod && fill.usesRelightShader, "Fill asset or saved shader preference missing.");
                Require(!((Material)fill.GetType().GetField("m_MatSplats",Flags).GetValue(fill)).shader.name.Contains("Relight"),"Fill did not match the source fast preview shader.");
                int visible = 0;
                foreach (var view in Draw(fill,camera,target)) if (view.clip.w > 0)
                {
                    visible++;
                    Require(Mathf.Abs(view.world.x) <= 0.201f && Mathf.Abs(view.world.y) <= 0.201f && Mathf.Abs(view.world.z-5) <= 0.101f,"Fill escaped its polygon/depth.");
                    var color = ViewColor(view);
                    Require(Mathf.Abs(color.r-.6f)<.02f && Mathf.Abs(color.g-.4f)<.02f && Mathf.Abs(color.b-.2f)<.02f,"Fill did not retain sampled edge color: "+color);
                }
                Require(visible > 0,"Fill did not render in the camera.");
                Call(window,"ResetAllSplatEdits"); Require(fill == null,"Reset All retained generated Fill."); Preload(source,camera);
                // Failed replacement must leave both the scene and source erase history alone.
                Polygon(brush,Square(10,0,5)); brush.DeleteBeforeFill=true; brush.UseFillColor=false;
                int rendererCount=Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsSortMode.None).Length;
                var pathsBefore=new HashSet<string>(AssetDatabase.GetAllAssetPaths());
                Call(window,"ExecuteFillInEditor",camera,false);
                Require(source.pagedLodEraseStrokeCount==0 &&
                    Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsSortMode.None).Length==rendererCount &&
                    pathsBefore.SetEquals(AssetDatabase.GetAllAssetPaths()),"Failed replacement changed source geometry or created artifacts.");
                Require(((string)window.GetType().GetField("m_PagedFillStatus",Flags).GetValue(window)).Contains("No visible edge"),
                    "Failed Fill did not explain missing edge samples.");
                Polygon(brush,polygon); Undo.ClearAll();
                Call(window,"ExecuteFillInEditor",camera,true);
                Require(source.pagedLodEraseStrokeCount==1 && Samples(source,polygon).Length==0,"Delete Area did not use persistent polygon erasure.");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                // Batch executeMethod has no editor update between Undo and this assertion.
                // Reload the transient selection as the editor's streaming updates would.
                Preload(source,camera);
                Require(source.pagedLodEraseStrokeCount==0 && Samples(source,polygon).Length==2,"Undo Delete Area did not restore the source.");
                Polygon(brush,polygon); brush.FillDensity=2; brush.UseFillColor=true; brush.FillColor=new Color(.2f,.7f,.3f,.6f); brush.FillColorBlend=1;
                var adjust=ColorAdjustments.Default; adjust.exposure=1; brush.ColorAdjust=adjust;
                brush.DeleteBeforeFill=true; Undo.FlushUndoRecordObjects(); Undo.ClearAll();
                fill=Fill(); string fillName=fill.transform.parent.name;
                Require(fill.activeSplatCount>lowCount,"Fill Density did not increase output detail.");
                Require(source.pagedLodEraseStrokeCount==1 && Samples(source,polygon).Length==0,"Delete Before Fill was not a persistent polygon edit.");
                foreach (var view in Draw(fill,camera,target)) if (view.clip.w>0)
                {
                    var color=ViewColor(view);
                    Require(color.g>color.r && color.g>color.b && color.r>.3f,"Fill color/exposure controls did not affect output: "+color);
                }
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                Require(GameObject.Find(fillName)==null && source.pagedLodEraseStrokeCount==0,"One Undo did not remove fill and restore deleted geometry.");
                Undo.PerformRedo(); Require(GameObject.Find(fillName)!=null && source.pagedLodEraseStrokeCount==1,"Redo did not restore fill and deletion together.");
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),scenePath),"Could not save Fill scene.");
                EditorSceneManager.OpenScene(scenePath,OpenSceneMode.Single);
                fill=GameObject.Find(fillName).GetComponentInChildren<SplatBoxRenderer>();
                source=GameObject.Find("Editor cold-start recovery fixture").GetComponent<SplatBoxRenderer>();
                camera=GameObject.Find("Fill test camera").GetComponent<Camera>(); camera.targetTexture=target; Preload(source,camera);
                Require(fill.m_Asset!=null && source.pagedLodEraseStrokeCount==1 && Samples(source,polygon).Length==0,"Fill or polygon delete lost scene persistence.");
                visible=0; foreach(var view in Draw(fill,camera,target)) if(view.clip.w>0) visible++;
                Require(visible>0,"Reopened Fill was invisible.");
                Set(window,"m_TargetRenderer",source); Call(window,"ResetAllSplatEdits");
                Require(fill==null && source.pagedLodEraseStrokeCount==0,"Reset All did not clear persisted Fill and polygon deletion.");
                Require(errors.Count==0,"Fill validation logged errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox paged Fill PASS: both GPU variants, edge samples, masks/erase, concave deletion replay, density/color/exposure, preview shader, Undo/Redo, Reset All and scene reopen.");
            }
            finally
            {
                Application.logMessageReceived -= observe;
                if(window!=null) Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
                if(fixture is IDisposable disposable) disposable.Dispose();
                if(target!=null) { target.Release(); Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
                foreach(var folder in folders) AssetDatabase.DeleteAsset(folder);
            }
        }
    }
}
