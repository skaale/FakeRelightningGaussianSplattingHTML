// SPDX-License-Identifier: MIT
using System;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;
using Splat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Tests
{
    /// <summary>CPU generation checks; no renderer, graphics device, or scene replacement is needed.</summary>
    public static class PagedFillGenerationValidation
    {
        const float SH0 = 0.2820948f;
        static readonly MethodInfo Build = typeof(GaussianSplatEditorWindow).GetMethod(
            "BuildPagedFillSplats", BindingFlags.Static | BindingFlags.NonPublic);
        static readonly string[] SHFields = { "sh1", "sh2", "sh3", "sh4", "sh5", "sh6", "sh7", "sh8",
            "sh9", "shA", "shB", "shC", "shD", "shE", "shF" };

        static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }

        static Splat Sample(Vector3 position, Color color)
        {
            var sample = new Splat {
                pos = position, nor = Vector3.forward,
                dc0 = (new Vector3(color.r, color.g, color.b) - Vector3.one * 0.5f) / SH0,
                opacity = Mathf.Log(color.a / (1 - color.a)),
                scale = Vector3.one * Mathf.Log(0.07f),
                // Exported InputSplatData uses PLY w,x,y,z, not Unity x,y,z,w.
                rot = new Quaternion(1, 0, 0, 0)
            };
            object boxed = sample;
            for (int i = 0; i < SHFields.Length; ++i)
                typeof(Splat).GetField(SHFields[i]).SetValue(boxed, new Vector3(i + 1, -i - 2, i + 3) * 0.001f);
            return (Splat)boxed;
        }

        static Color DecodeColor(Splat sample)
        {
            Vector3 rgb = sample.dc0 * SH0 + Vector3.one * 0.5f;
            return new Color(rgb.x, rgb.y, rgb.z, 1 / (1 + Mathf.Exp(-sample.opacity)));
        }

        static void ColorIs(Splat sample, Color expected, string label)
        {
            Color color = DecodeColor(sample);
            Require(Mathf.Abs(color.r - expected.r) < 0.0002f && Mathf.Abs(color.g - expected.g) < 0.0002f &&
                Mathf.Abs(color.b - expected.b) < 0.0002f && Mathf.Abs(color.a - expected.a) < 0.0002f,
                label + ": expected " + expected + ", got " + color);
        }

        static void SHIs(Splat actual, Splat source, float multiplier)
        {
            foreach (string name in SHFields)
            {
                var field = typeof(Splat).GetField(name);
                Vector3 value = (Vector3)field.GetValue(actual);
                Vector3 expected = (Vector3)field.GetValue(source) * multiplier;
                Require((value - expected).sqrMagnitude < 1e-12f, "Fill changed " + name + " incorrectly.");
            }
        }

        static Vector3[] Square(float half = 0.2f) => new[] {
            new Vector3(-half,-half,5), new Vector3(half,-half,5),
            new Vector3(half,half,5), new Vector3(-half,half,5) };

        static void Reset(GaussianSplatFillBrush brush)
        {
            brush.Clear(); brush.ResetTransform();
            brush.SelectionDepth = 0.1f; brush.FillDensity = 1; brush.PositionJitter = 0;
            brush.UseFillColor = false; brush.FillColor = Color.white; brush.FillColorBlend = 1;
            brush.ColorAdjust = ColorAdjustments.Default;
        }

        static Splat[] Generate(GaussianSplatFillBrush brush, Splat[] samples, Vector3[] polygon,
            Vector3 normal, Matrix4x4 sourceToWorld)
        {
            Require(Build != null, "Paged Fill generation entry point is missing.");
            try
            {
                return (Splat[])Build.Invoke(null, new object[] { samples, polygon, normal, sourceToWorld, brush });
            }
            catch (TargetInvocationException exception) when (exception.InnerException != null)
            {
                throw exception.InnerException;
            }
        }

        static Splat[] Generate(GaussianSplatFillBrush brush, Splat[] samples, Vector3[] polygon) =>
            Generate(brush, samples, polygon, Vector3.forward, Matrix4x4.identity);

        static void Reject(Action action, string label)
        {
            bool rejected = false;
            try { action(); }
            catch (InvalidOperationException) { rejected = true; }
            Require(rejected, label + " was accepted.");
        }

        static void Same(Splat[] first, Splat[] second, string label)
        {
            Require(first.Length == second.Length, label + " changed the count.");
            for (int i = 0; i < first.Length; ++i)
                Require(first[i].Equals(second[i]), label + " changed output at " + i + ".");
        }

        // Independent winding-number oracle includes points on an edge.
        static bool Contains(Vector2[] outline, Vector2 point)
        {
            int winding = 0;
            for (int i = 0; i < outline.Length; ++i)
            {
                Vector2 a = outline[i], b = outline[(i + 1) % outline.Length];
                Vector2 edge = b - a, relative = point - a;
                float cross = edge.x * relative.y - edge.y * relative.x;
                float dot = Vector2.Dot(relative, edge);
                if (Mathf.Abs(cross) < 1e-5f && dot >= -1e-5f && dot <= edge.sqrMagnitude + 1e-5f) return true;
                if (a.y <= point.y && b.y > point.y && cross > 0) ++winding;
                else if (a.y > point.y && b.y <= point.y && cross < 0) --winding;
            }
            return winding != 0;
        }

        static void WithinPolygon(Splat[] result, Vector3[] polygon, Vector3 normal,
            Matrix4x4 sourceToWorld, float depth)
        {
            Require(result.Length > 0, "Fill generated no splats.");
            Require(SplatBoxRenderer.TryBuildPagedPolygonFrame(polygon, normal, out var frame, out var outline),
                "Test polygon is invalid.");
            foreach (var sample in result)
            {
                Vector3 local = frame.MultiplyPoint3x4(sourceToWorld.MultiplyPoint3x4(sample.pos));
                Require(Contains(outline, new Vector2(local.x, local.y)), "A fill center escaped the polygon.");
                Require(Mathf.Abs(local.z) <= depth * 0.5f + 1e-4f,
                    "A fill center escaped the total selection thickness.");
            }
        }

        static void CheckGeometry(GaussianSplatFillBrush brush, Splat sample)
        {
            Reset(brush);
            var concave = new[] {
                new Vector3(-1,-1,5), new Vector3(1,-1,5), new Vector3(1,0,5),
                new Vector3(0,0,5), new Vector3(0,1,5), new Vector3(-1,1,5) };
            brush.PositionJitter = 0.5f; brush.SelectionDepth = 0.35f;
            var samples = new[] { sample, Sample(new Vector3(-0.9f,0,5), new Color(.1f,.8f,.3f,.6f)) };
            var first = Generate(brush, samples, concave);
            WithinPolygon(first, concave, Vector3.forward, Matrix4x4.identity, brush.SelectionDepth);
            foreach (var value in first)
                Require(!(value.pos.x > 0 && value.pos.y > 0), "Concave fill crossed the missing upper-right quadrant.");
            Same(first, Generate(brush, samples, concave), "Repeated jittered fill");
            Same(first, Generate(brush, new[] { samples[1], samples[0] }, concave), "GPU sample append order");
            Require(samples[0].Equals(sample), "Generation mutated its source samples.");

            Reset(brush);
            Vector3 center = new Vector3(0, 0, 5);
            Quaternion originalRotation = Quaternion.Euler(27, 18, 12);
            var original = Square(0.4f);
            for (int i = 0; i < original.Length; ++i) original[i] = center + originalRotation * (original[i] - center);
            brush.StartDrawing(original[0], originalRotation * Vector3.forward);
            for (int i = 1; i < original.Length; ++i) brush.AddVertex(original[i]);
            brush.ClosePolygon();
            brush.TransformOffset = new Vector3(2, -1, 1);
            brush.TransformRotation = Quaternion.Euler(19, 42, -13);
            brush.TransformScale = new Vector3(1.5f, 0.65f, 1.2f);
            brush.PositionJitter = 0.5f; brush.SelectionDepth = 0.3f;
            var transformed = brush.GetTransformedVertices().ToArray();
            Vector3 normal = brush.GetTransformedNormal();
            Vector3 geometricNormal = Vector3.Cross(transformed[1] - transformed[0], transformed[2] - transformed[0]).normalized;
            Require(Vector3.Dot(normal, geometricNormal) > 0.9999f, "Nonuniform brush scaling produced an incorrect plane normal.");
            var matrix = Matrix4x4.TRS(new Vector3(-2, 1, .3f), Quaternion.Euler(-14, 32, 11), new Vector3(1.6f, .7f, 1.2f));
            var transformedSample = sample;
            transformedSample.pos = matrix.inverse.MultiplyPoint3x4(transformed[0]);
            var result = Generate(brush, new[] { transformedSample }, transformed, normal, matrix);
            WithinPolygon(result, transformed, normal, matrix, brush.SelectionDepth);
            Vector3 actualCenter = Vector3.zero;
            foreach (var value in result) actualCenter += matrix.MultiplyPoint3x4(value.pos);
            actualCenter /= result.Length;
            Require(Vector3.Distance(actualCenter, brush.TransformedCenter) < 0.15f,
                "Fill ignored the polygon or source renderer transform.");

            Reset(brush);
            brush.FillDensity = .5f;
            int lowDensity = Generate(brush, new[] { sample }, Square()).Length;
            brush.FillDensity = 2;
            int highDensity = Generate(brush, new[] { sample }, Square()).Length;
            Require(highDensity > lowDensity, "Fill Density did not increase the count.");
            brush.FillDensity = 1;
            var shallow = Generate(brush, new[] { sample }, Square());
            brush.SelectionDepth = .5f;
            var deep = Generate(brush, new[] { sample }, Square());
            Require(deep.Length > shallow.Length, "Selection Depth did not add fill layers.");
            WithinPolygon(deep, Square(), Vector3.forward, Matrix4x4.identity, .5f);
        }

        static void CheckColor(GaussianSplatFillBrush brush, Splat sample)
        {
            Reset(brush);
            var samples = new[] { sample };
            foreach (var value in Generate(brush, samples, Square()))
            {
                ColorIs(value, new Color(.6f,.4f,.2f,.8f), "Unmodified sampled color");
                SHIs(value, sample, 1);
                Require(value.rot.Equals(sample.rot), "Fill changed the sampled PLY quaternion.");
                Require((value.scale - sample.scale - Vector3.one * Mathf.Log(2)).sqrMagnitude < 1e-10f,
                    "Fill did not preserve logarithmic source scale and its density adjustment.");
            }
            brush.UseFillColor = true; brush.FillColor = new Color(.2f,.7f,.3f,.6f); brush.FillColorBlend = .25f;
            foreach (var value in Generate(brush, samples, Square()))
            {
                ColorIs(value, new Color(.5f,.475f,.225f,.75f), "Fill Color blend including alpha");
                SHIs(value, sample, .75f);
            }
            brush.FillColorBlend = 1;
            foreach (var value in Generate(brush, samples, Square()))
            {
                ColorIs(value, brush.FillColor, "Full Fill Color");
                SHIs(value, sample, 0);
            }
            brush.UseFillColor = false;
            var adjustment = ColorAdjustments.Default;
            adjustment.exposure = 1; adjustment.contrast = .5f; adjustment.colorTint = new Color(.5f,1,.75f,.1f);
            brush.ColorAdjust = adjustment;
            foreach (var value in Generate(brush, samples, Square()))
                ColorIs(value, new Color(.425f,.65f,.3375f,.8f), "Exposure, contrast and tint (alpha retained)");
            adjustment = ColorAdjustments.Default; adjustment.hueShift = 120; adjustment.saturation = .5f;
            brush.ColorAdjust = adjustment;
            var red = Sample(sample.pos, new Color(1,0,0,.8f));
            foreach (var value in Generate(brush, new[] { red }, Square()))
                ColorIs(value, new Color(.5f,1,.5f,.8f), "Hue and saturation");
        }

        static void CheckFallbackAndValidation(GaussianSplatFillBrush brush, Splat sample)
        {
            Reset(brush);
            Reject(() => Generate(brush, Array.Empty<Splat>(), Square()), "Fill without edge samples or solid color");
            brush.UseFillColor = true; brush.FillColor = new Color(.2f,.7f,.3f,.6f); brush.FillColorBlend = .5f;
            Reject(() => Generate(brush, Array.Empty<Splat>(), Square()), "Partially blended color without edge samples");
            brush.FillColorBlend = 1;
            var solid = Generate(brush, Array.Empty<Splat>(), Square());
            WithinPolygon(solid, Square(), Vector3.forward, Matrix4x4.identity, brush.SelectionDepth);
            foreach (var value in solid) { ColorIs(value, brush.FillColor, "Solid-color fallback"); SHIs(value, sample, 0); }

            string[] assetsBefore = AssetDatabase.GetAllAssetPaths(); Array.Sort(assetsBefore, StringComparer.Ordinal);
            int renderersBefore = Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsInactive.Include, FindObjectsSortMode.None).Length;
            Reset(brush);
            var samples = new[] { sample };
            Reject(() => Generate(brush, samples, null), "Missing polygon");
            Reject(() => Generate(brush, samples, new[] { Vector3.zero, Vector3.right }), "Two-vertex polygon");
            Reject(() => Generate(brush, samples, new[] { Vector3.zero, Vector3.right, Vector3.right * 2 }), "Collinear polygon");
            var invalid = Square(); invalid[0].x = float.NaN;
            Reject(() => Generate(brush, samples, invalid), "Nonfinite polygon");
            Reject(() => Generate(brush, samples, Square(), Vector3.zero, Matrix4x4.identity), "Missing polygon normal");
            var invalidSample = sample; invalidSample.scale.x = float.NaN;
            Reject(() => Generate(brush, new[] { invalidSample }, Square()), "Nonfinite sample scale");
            brush.FillDensity = 5; brush.SelectionDepth = 2;
            Reject(() => Generate(brush, samples, Square(1000)), "Unbounded fill workload");
            string[] assetsAfter = AssetDatabase.GetAllAssetPaths(); Array.Sort(assetsAfter, StringComparer.Ordinal);
            Require(assetsBefore.Length == assetsAfter.Length, "Generation validation created or deleted assets.");
            for (int i = 0; i < assetsBefore.Length; ++i)
                Require(assetsBefore[i] == assetsAfter[i], "Generation validation changed an asset path.");
            Require(renderersBefore == Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsInactive.Include, FindObjectsSortMode.None).Length,
                "A rejected fill created or deleted a renderer.");
        }

        public static void Run()
        {
            GameObject holder = null;
            try
            {
                holder = new GameObject("Paged Fill generation validation") { hideFlags = HideFlags.HideAndDontSave };
                holder.SetActive(false);
                var brush = holder.AddComponent<GaussianSplatFillBrush>();
                var sample = Sample(new Vector3(.19f,0,5), new Color(.6f,.4f,.2f,.8f));
                CheckGeometry(brush, sample);
                CheckColor(brush, sample);
                CheckFallbackAndValidation(brush, sample);
                Debug.Log("PAGED_FILL_GENERATION_VALIDATION_PASS: concavity, deterministic jitter, transforms, density/depth, color/alpha/SH, fallback and mutation-free validation.");
            }
            finally { if (holder != null) Object.DestroyImmediate(holder); }
        }
    }
}
