// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    /// <summary>Runs on real editor ticks in an isolated project; never enters Play mode.</summary>
    public static class PagedLodEditorRecoveryValidation
    {
        const BindingFlags Fields = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        public static Action<SplatBoxRenderer> GuiValidation;
        static Fixture fixture;
        static readonly List<string> errors = new List<string>();
        static int phase, ticks, playTransitions;
        static double phaseStart;
        static GraphicsBuffer stableAtlas;
        static int stableSelections;
        static uint pendingRevision;
        static SplatBoxLodSelectionWorker pendingWorker;
        static SceneView sceneView;
        static bool validateViewStability;
        static bool validatePublishedOrder;
        static GameObject secondaryOwner;
        static double nextRenderTime;
        static string stableSelection;
        static readonly List<string> viewSamples = new List<string>();

        // Deliberately alternates native render callbacks with ordinary editor updates. The
        // renderer must not alternate selection resolution when the Camera itself is stationary.
        public static void RunViewStability()
        {
            Run();
            validateViewStability = true;
            viewSamples.Clear();
            Set(fixture.renderer, "m_LodPixelScaleLimit", 8f);
            // The synchronous lane makes opposing frontiers deterministic; the later async lane
            // checks that background work is neither repeatedly rejected nor republished.
            Set(fixture.renderer, "m_LodAsyncTraversal", false);
            fixture.renderer.lodDetailDistance = 2f;
            fixture.AssignScene(); fixture.PublishPages(); fixture.CreateCamera();
        }

        public static void RunPublishedOrder()
        {
            Start(true);
            validatePublishedOrder = true;
            fixture.AssignScene(); fixture.PublishPages(); fixture.CreateCamera();
        }

        // Invoke without -quit; the asynchronous editor tick driver exits the batch process.
        public static void Run() => Start(false);

        static void Start(bool overlappingDepths)
        {
            Require(!Application.isPlaying && SystemInfo.supportsComputeShaders,
                "Recovery validation requires Edit mode and a graphics device.");
            Require(SceneView.sceneViews.Count == 0, "Run the cold-camera fixture in an isolated project with Scene views closed.");
            errors.Clear(); phase = ticks = playTransitions = 0; validateViewStability = validatePublishedOrder = false;
            Application.logMessageReceived += Observe;
            EditorApplication.playModeStateChanged += ObservePlayMode;
            try
            {
                fixture = new Fixture(overlappingDepths);
                phaseStart = EditorApplication.timeSinceStartup;
                EditorApplication.update += Tick;
                EditorApplication.QueuePlayerLoopUpdate();
            }
            catch (Exception exception) { Finish(exception); }
        }

        static void Observe(string message, string stack, LogType type)
        {
            if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message);
        }
        static void ObservePlayMode(PlayModeStateChange state) => ++playTransitions;
        static void Advance()
        {
            ++phase; ticks = 0; phaseStart = EditorApplication.timeSinceStartup;
        }
        static void Tick()
        {
            try
            {
                Require(errors.Count == 0, "Editor recovery logged errors: " + string.Join("\n", errors));
                Require(!Application.isPlaying && playTransitions == 0, "Recovery entered Play mode.");
                Require(EditorApplication.timeSinceStartup - phaseStart < 25,
                    "Editor recovery timed out in phase " + phase + ": " + fixture.Describe());
                ++ticks;
                if (validatePublishedOrder) { TickPublishedOrder(); return; }
                if (validateViewStability) { TickViewStability(); return; }
                switch (phase)
                {
                    case 0:
                        if (ticks < 3) break;
                        Require(!fixture.renderer.HasValidAsset, "Cold fixture unexpectedly had a source asset.");
                        fixture.AssignScene();
                        Require(!fixture.renderer.ForceRebuildPagedLodInEditor(), "A rebuild reported success before page metadata arrived.");
                        Advance(); break;
                    case 1:
                        if (ticks < 4) break;
                        fixture.PublishPages();
                        Advance(); break;
                    case 2:
                        if (!fixture.HasResources) break;
                        stableAtlas = Get<GraphicsBuffer>(fixture.renderer, "m_GpuLodUnifiedPos");
                        stableSelections = fixture.renderer.lodSynchronousSelectionCount;
                        Advance(); break;
                    case 3:
                        if (ticks < 6) break;
                        Require(ReferenceEquals(stableAtlas, Get<GraphicsBuffer>(fixture.renderer, "m_GpuLodUnifiedPos")) &&
                            fixture.renderer.lodSynchronousSelectionCount == stableSelections,
                            "Waiting for a camera repeatedly rebuilt or reselected the preview.");
                        fixture.CreateCamera();
                        Advance(); break;
                    case 4:
                        if (!fixture.Ready) break;
                        fixture.AssertVisible();
                        Require(Time.frameCount > fixture.startFrame, "Paced page uploads did not advance real editor frames.");
                        sceneView = ScriptableObject.CreateInstance<SceneView>();
                        sceneView.ShowUtility();
                        sceneView.LookAt(new Vector3(0, 0, 5), Quaternion.identity, 4);
                        fixture.camera.transform.position = new Vector3(0.03f, 0, 0);
                        pendingRevision = Get<uint>(fixture.renderer, "m_LodSelectionRevision");
                        Call(fixture.renderer, "SelectAndGatherLodSplats", fixture.camera, null, true);
                        pendingWorker = Get<SplatBoxLodSelectionWorker>(fixture.renderer, "m_LodSelectionWorker");
                        Require(pendingWorker != null && pendingWorker.isRunning, "Closed-Game-view fixture did not queue a real worker.");
                        Advance(); break;
                    case 5:
                        if (pendingWorker.isRunning || Get<uint>(fixture.renderer, "m_LodSelectionRevision") == pendingRevision) break;
                        Require(fixture.mainRenderCallbacks == 0, "The canonical-camera fixture unexpectedly rendered Game view.");
                        fixture.AssertVisible();
                        fixture.BreakShaderRegistration();
                        Advance(); break;
                    case 6:
                        if (!fixture.Ready) break;
                        fixture.AssertVisible();
                        UnityEngine.Object.DestroyImmediate(fixture.renderer.lodStreamer);
                        Set(fixture.renderer, "m_LodStreamer", null);
                        Advance(); break;
                    case 7:
                        if (!fixture.Ready) break;
                        fixture.AssertVisible();
                        fixture.CreateJournal();
                        fixture.ForceWithPendingWorker();
                        Advance(); break;
                    case 8:
                        if (!fixture.Ready) break;
                        fixture.AssertVisible(); fixture.AssertJournal(); fixture.AssertHooks();
                        fixture.ForceAndCheckDisposal();
                        Advance(); break;
                    case 9:
                        if (!fixture.Ready) break;
                        fixture.AssertVisible(); fixture.AssertJournal(); fixture.AssertHooks();
                        GuiValidation?.Invoke(fixture.renderer);
                        Advance(); break;
                    case 10:
                        if (!fixture.Ready) break;
                        fixture.AssertVisible(); fixture.AssertJournal(); fixture.AssertHooks();
                        Require(fixture.mainRenderCallbacks == 0 && playTransitions == 0,
                            "Editor preview recovery depended on Game view or Play mode.");
                        Finish(null); return;
                }
            }
            catch (Exception exception) { Finish(exception); }
        }

        static void TickPublishedOrder()
        {
            if (!fixture.Ready || (bool)Call(fixture.renderer, "HasPendingLodRefinement")) return;
            if (phase == 0)
            {
                sceneView = ScriptableObject.CreateInstance<SceneView>(); sceneView.ShowUtility();
                AssertSceneFirstDraw("cold editor publication / single renderer");
                AssertOppositeViewDraw();
                secondaryOwner = new GameObject("Monolithic renderer to exercise multi-render path");
                secondaryOwner.SetActive(false);
                var secondary = secondaryOwner.AddComponent<SplatBoxRenderer>();
                secondary.m_Asset = fixture.FirstAsset;
                secondary.m_RenderScale = 0.4f;
                Set(secondary, "m_UseRelightShader", false);
                secondary.transform.position = new Vector3(1000, 0, 0);
                secondaryOwner.SetActive(true);
                Require(GaussianSplatRenderSystem.SplatRenderScale == 1f,
                    "A secondary renderer replaced the shared render scale.");
                pendingRevision = Get<uint>(fixture.renderer, "m_LodSelectionRevision");
                fixture.camera.fieldOfView = 58;
                Advance(); return;
            }
            if (Get<uint>(fixture.renderer, "m_LodSelectionRevision") == pendingRevision) return;
            AssertSceneFirstDraw("real editor tick publication / multiple renderers");
            Require(GaussianSplatRenderSystem.LastGatheredSplatCount >= 2,
                "Publication-order fixture did not enter the multi-renderer path.");
            Call(fixture.renderer, "PreloadPagedLodPages", fixture.camera);
            Require(Get<bool>(fixture.renderer, "m_LodSortKeysNeedReset"),
                "Null-command preload fixture did not leave pending identity-key reset.");
            AssertSceneFirstDraw("null-command preload / pending keys / multiple renderers");
            Finish(null);
        }

        static void AssertOppositeViewDraw()
        {
            Camera sceneCamera = sceneView.camera;
            sceneCamera.ResetWorldToCameraMatrix();
            sceneCamera.transform.SetPositionAndRotation(new Vector3(0, 0, 10), Quaternion.Euler(0, 180, 0));
            Color32[] sceneBefore = fixture.DrawPixels(sceneCamera);
            uint[] sceneOrder = fixture.Order();
            Color32[] game = fixture.DrawPixels(fixture.camera);
            uint[] gameOrder = fixture.Order();
            Color32[] sceneAfter = fixture.DrawPixels(sceneCamera);
            uint[] restoredOrder = fixture.Order();
            int changedPixels = 0, repeatDifference = 0;
            for (int i = 0; i < game.Length; i++)
            {
                if (Math.Abs(sceneBefore[i].r - game[i].r) + Math.Abs(sceneBefore[i].b - game[i].b) > 10)
                    changedPixels++;
                repeatDifference = Math.Max(repeatDifference, Math.Abs(sceneBefore[i].r - sceneAfter[i].r));
                repeatDifference = Math.Max(repeatDifference, Math.Abs(sceneBefore[i].b - sceneAfter[i].b));
            }
            Require(string.Join(",", sceneOrder) != string.Join(",", gameOrder) &&
                    string.Join(",", sceneOrder) == string.Join(",", restoredOrder) &&
                    changedPixels > 20 && repeatDifference <= 1,
                "Opposite Scene and Game cameras did not sort and composite their own views consistently.");
        }

        static void AssertSceneFirstDraw(string context)
        {
            Camera sceneCamera = sceneView.camera;
            sceneCamera.transform.SetPositionAndRotation(fixture.camera.transform.position, fixture.camera.transform.rotation);
            sceneCamera.pixelRect = fixture.camera.pixelRect;
            sceneCamera.projectionMatrix = fixture.camera.projectionMatrix;
            sceneCamera.worldToCameraMatrix = fixture.camera.worldToCameraMatrix;
            Color32[] before = fixture.DrawPixels(sceneCamera);
            uint revision = Get<uint>(fixture.renderer, "m_LodSelectionRevision");
            uint sorted = Get<uint>(fixture.renderer, "m_LastSortedLodSelectionRevision");
            uint[] sceneOrder = fixture.Order();
            fixture.DrawPixels(fixture.camera);
            uint[] canonicalOrder = fixture.Order();
            Color32[] after = fixture.DrawPixels(sceneCamera);
            int maxDifference = 0, covered = 0;
            for (int i = 0; i < before.Length; ++i)
            {
                if (before[i].a > 10) ++covered;
                maxDifference = Math.Max(maxDifference, Math.Abs(before[i].r - after[i].r));
                maxDifference = Math.Max(maxDifference, Math.Abs(before[i].g - after[i].g));
                maxDifference = Math.Max(maxDifference, Math.Abs(before[i].b - after[i].b));
            }
            Require(sorted == revision && string.Join(",", sceneOrder) == string.Join(",", canonicalOrder) &&
                maxDifference <= 1 && covered > 20 && !Get<bool>(fixture.renderer, "m_LodSortKeysNeedReset"),
                context + " drew Scene before canonical sorting: revision=" + revision + ", sorted=" + sorted +
                ", scene order=" + string.Join(",", sceneOrder) + ", canonical order=" + string.Join(",", canonicalOrder) +
                ", maximum pixel difference=" + maxDifference);
            Require(fixture.mainRenderCallbacks == 0, "The Scene-first fixture accidentally relied on native Game view callbacks.");
        }

        static void TickViewStability()
        {
            switch (phase)
            {
                case 0:
                    if (!fixture.Ready || (bool)Call(fixture.renderer, "HasPendingLodRefinement")) return;
                    Advance(); return;
                case 1:
                    if (EditorApplication.timeSinceStartup - phaseStart < 0.5) return;
                    Require(fixture.renderer.activeSplatCount == 6,
                        "Threshold fixture must start with all six leaves at the native viewport.");
                    stableAtlas = Get<GraphicsBuffer>(fixture.renderer, "m_GpuLodUnifiedPos");
                    sceneView = ScriptableObject.CreateInstance<SceneView>(); sceneView.ShowUtility();
                    sceneView.LookAt(new Vector3(20, 0, 5), Quaternion.Euler(0, 120, 0), 4);
                    fixture.RenderNative(fixture.camera, 64, 48, 60);
                    nextRenderTime = EditorApplication.timeSinceStartup;
                    Advance(); return;
                case 2:
                case 3:
                case 4:
                    Require(ReferenceEquals(stableAtlas, Get<GraphicsBuffer>(fixture.renderer, "m_GpuLodUnifiedPos")) && stableAtlas.IsValid(),
                        "Stationary render callbacks recreated the LoD atlas.");
                    SampleView("editor tick", phase >= 3);
                    if (EditorApplication.timeSinceStartup >= nextRenderTime)
                    {
                        fixture.RenderNative(fixture.camera, 64, 48, 60);
                        SampleView("Main render", phase >= 3);
                        string beforeScene = fixture.Selection();
                        fixture.RenderNative(sceneView.camera, 1600, 400, 110);
                        Require(fixture.Selection() == beforeScene,
                            "An unrelated Scene render callback changed the canonical selection.");
                        nextRenderTime = EditorApplication.timeSinceStartup + 0.22;
                    }
                    if (EditorApplication.timeSinceStartup - phaseStart < (phase == 2 ? 1.2 : 1.5)) return;
                    if (phase == 2)
                    {
                        stableSelection = fixture.Selection(); viewSamples.Clear();
                        Require(fixture.renderer.activeSplatCount == 6,
                            "A canonical render override replaced native-camera leaves with coarse stand-ins.");
                        pendingRevision = Get<uint>(fixture.renderer, "m_LodSelectionRevision");
                        Advance(); return;
                    }
                    Require(Get<uint>(fixture.renderer, "m_LodSelectionRevision") == pendingRevision,
                        "Stationary editor and render contexts kept rebuilding an identical selection.");
                    Require(fixture.mainRenderCallbacks >= 5 && fixture.sceneRenderCallbacks >= 5,
                        "Stability fixture did not exercise both native camera callbacks.");
                    if (phase == 3)
                    {
                        Set(fixture.renderer, "m_LodAsyncTraversal", true);
                        Advance(); return;
                    }
                    fixture.camera.transform.position = new Vector3(0, 0, -150);
                    Advance(); return;
                case 5:
                    if (fixture.renderer.activeSplatCount != 3 ||
                        Get<uint>(fixture.renderer, "m_LodSelectionRevision") == pendingRevision) return;
                    Require(ReferenceEquals(stableAtlas, Get<GraphicsBuffer>(fixture.renderer, "m_GpuLodUnifiedPos")),
                        "Real camera movement recreated the atlas.");
                    pendingRevision = Get<uint>(fixture.renderer, "m_LodSelectionRevision");
                    fixture.camera.fieldOfView = 45;
                    fixture.camera.pixelRect = new Rect(0, 0, 320, 240);
                    Advance(); return;
                case 6:
                    if (Get<uint>(fixture.renderer, "m_LodSelectionRevision") == pendingRevision) return;
                    Require(fixture.renderer.activeSplatCount == 3,
                        "Changing the native camera projection/viewport lost stationary geometry.");
                    Finish(null); return;
            }
        }

        static void SampleView(string label, bool requireStable)
        {
            string selection = fixture.Selection();
            string sample = label + "=" + selection;
            if (viewSamples.Count == 0 || viewSamples[viewSamples.Count - 1] != sample) viewSamples.Add(sample);
            if (viewSamples.Count > 20) viewSamples.RemoveAt(0);
            Require(!requireStable || selection == stableSelection,
                "Stationary editor/render callbacks oscillated between coarse and detailed geometry: " + string.Join("; ", viewSamples));
        }

        static void Finish(Exception failure)
        {
            EditorApplication.update -= Tick;
            EditorApplication.playModeStateChanged -= ObservePlayMode;
            try
            {
                GaussianSplatRenderSystem.ClearOverrideMatrices();
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideRenderTargetSize();
                if (sceneView != null) sceneView.Close();
                sceneView = null;
                if (secondaryOwner != null) UnityEngine.Object.DestroyImmediate(secondaryOwner);
                secondaryOwner = null;
                fixture?.Dispose(); fixture = null;
            }
            catch (Exception cleanup) { failure ??= cleanup; }
            Application.logMessageReceived -= Observe;
            if (failure == null && errors.Count != 0) failure = new Exception(string.Join("\n", errors));
            if (failure != null) Debug.LogException(failure);
            else if (validatePublishedOrder) Debug.Log("SplatBox editor publication order validation PASS: overlapping colored depths, opposite camera views, Scene-first cold/editor-tick/preload publications, pending key reset, and per-camera GPU sorting for single and multiple renderers.");
            else if (validateViewStability) Debug.Log("SplatBox editor view stability validation PASS: native Main/Scene callbacks with different render overrides, real editor ticks, stable atlas and stationary selection, and genuine camera-motion refresh.");
            else Debug.Log("SplatBox editor recovery validation PASS: real cold-start ticks, late manifest/pages/camera, " +
                "stable camera-less resources, shader/registration/streamer recovery, closed-Game-view worker publication, " +
                "visible GPU draws, repeated force builds, worker cancellation before atlas disposal, retained Erase/Geometry journals and unique callbacks.");
            if (Application.isBatchMode) EditorApplication.Exit(failure == null ? 0 : 1);
        }

        sealed class Fixture : IDisposable
        {
            public readonly GameObject owner;
            public readonly SplatBoxRenderer renderer;
            public Camera camera;
            public readonly int startFrame = Time.frameCount;
            public int mainRenderCallbacks, sceneRenderCallbacks;
            readonly string folder;
            readonly GaussianSplatPagedScene scene;
            readonly GaussianSplatPageAsset[] pages = new GaussianSplatPageAsset[3];
            readonly GameObject[] previousMains;
            readonly float previousScale;
            readonly int previousRegistered;
            readonly RenderTexture target;
            readonly Texture2D readback;
            readonly bool overlappingDepths;
            GameObject cameraOwner;

            public Fixture(bool overlappingDepths = false)
            {
                this.overlappingDepths = overlappingDepths;
                previousScale = GaussianSplatRenderSystem.SplatRenderScale;
                previousRegistered = GaussianSplatRenderSystem.instance.RegisteredSplatCount;
                previousMains = GameObject.FindGameObjectsWithTag("MainCamera");
                foreach (var previous in previousMains) previous.tag = "Untagged";
                folder = "Assets/__SplatBoxEditorRecovery_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder("Assets", Path.GetFileName(folder));
                for (int i = 0; i < pages.Length; ++i) pages[i] = CreatePage(i);
                scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
                scene.Initialize(new Vector3(-2, -1, 4), new Vector3(2, 1, 6), 4,
                    new[] { Entry(0, false), Entry(1, false), Entry(2, false) }, 10_000);
                AssetDatabase.CreateAsset(scene, folder + "/scene.asset");
                owner = new GameObject("Editor cold-start recovery fixture");
                owner.SetActive(false);
                renderer = owner.AddComponent<SplatBoxRenderer>();
                Set(renderer, "m_UseRelightShader", false);
                Set(renderer, "m_LodSimpleMode", false);
                Set(renderer, "m_LodSplatBudget", 10_000);
                Set(renderer, "m_EnableDistanceCulling", false);
                target = new RenderTexture(640, 480, 0, RenderTextureFormat.ARGB32);
                readback = new Texture2D(640, 480, TextureFormat.RGBA32, false, true);
                target.Create();
                Camera.onPreCull += OnCamera;
                RenderPipelineManager.beginCameraRendering += OnPipelineCamera;
                owner.SetActive(true); // Real OnEnable, deliberately before the scene is assigned.
                GaussianSplatRenderSystem.SplatRenderScale = 1f;
            }
            void OnCamera(Camera value)
            {
                if (value == camera) ++mainRenderCallbacks;
                if (value.cameraType == CameraType.SceneView) ++sceneRenderCallbacks;
            }
            void OnPipelineCamera(ScriptableRenderContext context, Camera value) => OnCamera(value);
            public bool HasResources => (bool)renderer.GetType().GetProperty("HasEditorPagedLodResources", Fields).GetValue(renderer);
            public GaussianSplatAsset FirstAsset => pages[0].splatData;
            public bool Ready => HasResources && renderer.lodStreamer != null &&
                renderer.lodStreamer.loadedPages.Count == pages.Length && !renderer.lodStreamer.hasPendingCoarseLoads &&
                renderer.activeSplatCount > 0 && (bool)renderer.GetType().GetProperty("HasValidDrawBuffers", Fields).GetValue(renderer) &&
                GaussianSplatRenderSystem.instance.IsRegistered(renderer);
            public string Describe() => "active=" + renderer.activeSplatCount + ", resources=" + HasResources +
                ", pages=" + (renderer.lodStreamer?.loadedPages.Count ?? 0) + ", camera=" + (camera != null);
            public void AssignScene() => Set(renderer, "m_PagedScene", scene);
            public void PublishPages()
            {
                for (int i = 0; i < pages.Length; ++i) scene.pages[i] = Entry(i, true);
                EditorUtility.SetDirty(scene);
            }
            public void CreateCamera()
            {
                cameraOwner = new GameObject("Editor recovery Main Camera") { tag = "MainCamera" };
                camera = cameraOwner.AddComponent<Camera>();
                // A targetTexture makes Unity render an enabled camera automatically even
                // with Game view closed. Keep it display-only; GPU checks record their own RT.
                camera.fieldOfView = 60; camera.pixelRect = new Rect(0, 0, 640, 480); camera.aspect = 640f / 480;
                Require(Camera.main == camera, "Recovery fixture did not own the canonical camera.");
            }
            public void AssertVisible()
            {
                int covered = 0;
                foreach (var pixel in DrawPixels(camera)) if (pixel.a > 10) ++covered;
                Require(covered > 20, "Recovered preview buffers produced no visible splat pixels.");
            }
            public uint[] Order()
            {
                var buffer = (GraphicsBuffer)renderer.GetType().GetProperty("drawOrderBuffer", Fields).GetValue(renderer);
                var order = new uint[renderer.activeSplatCount]; buffer.GetData(order, 0, 0, order.Length); return order;
            }
            public Color32[] DrawPixels(Camera drawCamera)
            {
                Require(Ready, "Editor resources are not drawable: " + Describe());
                var system = GaussianSplatRenderSystem.instance;
                Require(system.GatherSplatsForCamera(drawCamera), "Recovered renderer was not gathered for drawing.");
                using var cmd = new CommandBuffer { name = "Validate recovered editor preview pixels" };
                cmd.SetRenderTarget(target); cmd.SetViewport(new Rect(0, 0, 640, 480));
                cmd.ClearRenderTarget(false, true, Color.clear);
                // No native camera callback has initialized these globals: reproduce the
                // render target setup supplied by the real render pipeline explicitly.
                cmd.SetViewProjectionMatrices(drawCamera.worldToCameraMatrix, GL.GetGPUProjectionMatrix(drawCamera.projectionMatrix, true));
                cmd.SetGlobalVector("_ScreenParams", new Vector4(640, 480, 1 + 1f / 640, 1 + 1f / 480));
                cmd.SetGlobalVector("_SplatRenderTargetSize", new Vector4(640, 480, 1f / 640, 1f / 480));
                var composite = system.SortAndRenderSplats(drawCamera, cmd);
                Require(composite != null, "Recovered preview did not produce a splat draw.");
                Graphics.ExecuteCommandBuffer(cmd);
                var previous = RenderTexture.active;
                try
                {
                    RenderTexture.active = target;
                    readback.ReadPixels(new Rect(0, 0, 640, 480), 0, 0, false); readback.Apply(false);
                    return readback.GetPixels32();
                }
                finally { RenderTexture.active = previous; }
            }
            public string Selection()
            {
                var indices = new uint[renderer.activeSplatCount];
                Get<GraphicsBuffer>(renderer, "m_GpuLodAtlasIndices").GetData(indices, 0, 0, indices.Length);
                Array.Sort(indices);
                return indices.Length + " [" + string.Join(",", indices) + "]";
            }
            public void RenderNative(Camera value, int width, int height, float fieldOfView)
            {
                var oldTarget = value.targetTexture; var oldRect = value.pixelRect;
                var expectedView = value.worldToCameraMatrix;
                var expectedProjection = GL.GetGPUProjectionMatrix(Matrix4x4.Perspective(fieldOfView,
                    (float)width / height, value.nearClipPlane, value.farClipPlane), true);
                int drawCallbacks = 0;
                Action<SplatBoxRenderer, CommandBuffer, MaterialPropertyBlock> inspectDraw = (drawRenderer, cmd, properties) =>
                {
                    if (drawRenderer != renderer) return;
                    ++drawCallbacks;
                    GaussianSplatRenderSystem.GetCameraViewProj(value, out var view, out var projection);
                    var dimensions = GaussianSplatRenderSystem.GetSplatScreenParams(value);
                    Require(view == expectedView && projection == expectedProjection && dimensions.x == width && dimensions.y == height,
                        "Editor LoD selection failed to restore the render pass matrices/viewport before drawing.");
                };
                GaussianSplatRenderSystem.OnBeforeDrawSplatsForRenderer += inspectDraw;
                try
                {
                    value.targetTexture = target;
                    value.pixelRect = new Rect(0, 0, 640, 480);
                    GaussianSplatRenderSystem.SetOverrideMatrices(expectedView, expectedProjection);
                    GaussianSplatRenderSystem.SetOverrideRenderTargetSize(width, height);
                    value.Render();
                    Require(drawCallbacks > 0, "Native render callback did not reach the actual splat draw.");
                }
                finally
                {
                    GaussianSplatRenderSystem.OnBeforeDrawSplatsForRenderer -= inspectDraw;
                    GaussianSplatRenderSystem.ClearOverrideMatrices();
                    GaussianSplatRenderSystem.ClearOverrideRenderTargetSize();
                    value.targetTexture = oldTarget; value.pixelRect = oldRect;
                }
            }
            public void BreakShaderRegistration()
            {
                GaussianSplatRenderSystem.instance.UnregisterSplat(renderer);
                UnityEngine.Object.DestroyImmediate(Get<Material>(renderer, "m_MatSplats"));
                UnityEngine.Object.DestroyImmediate(Get<Material>(renderer, "m_MatComposite"));
                Set(renderer, "m_MatSplats", null); Set(renderer, "m_MatComposite", null);
                Set(renderer, "m_CSBoxUtil", null); Set(renderer, "m_ShaderSplats", null);
            }
            public void CreateJournal()
            {
                renderer.EditDeleteSphere(new Vector3(-0.9f, 0, 5), 0.06f);
                renderer.DeleteSplatsInBox(new Vector3(-0.7f, 0, 5), Vector3.one * 0.12f, Quaternion.Euler(0, 20, 0));
                renderer.EditRestoreSphere(new Vector3(-0.9f, 0, 5), 0.06f);
                renderer.EditDeleteSphere(new Vector3(-0.1f, 0, 5), 0.06f);
                AssertJournal();
            }
            public void AssertJournal()
            {
                Require(renderer.pagedLodEraseStrokeCount == 4 && renderer.editModified && renderer.pagedScene == scene,
                    "Force build changed the serialized edits or source reference.");
                var mask = Get<GraphicsBuffer>(renderer, "m_GpuPagedLodDeletedBits");
                Require(mask != null && mask.IsValid(), "Rebuilt pages lost their erased geometry mask.");
                var words = new uint[mask.count]; mask.GetData(words);
                foreach (var page in renderer.lodStreamer.loadedPages)
                    for (int i = 0; i < page.splatCount; ++i)
                    {
                        int index = page.atlasOffset + i;
                        bool erased = (words[index / 32] & (1u << (index & 31))) != 0;
                        Require(erased == ((page.pageId == 0 && i == 2) || (page.pageId == 1 && i == 1)),
                            "A rebuilt page replayed the wrong Erase/Geometry edits.");
                    }
            }
            public void AssertHooks()
            {
                int callbacks = 0;
                foreach (var handler in EditorApplication.update.GetInvocationList())
                    if (ReferenceEquals(handler.Target, renderer) && handler.Method.Name == "EditorUpdate") ++callbacks;
                Require(callbacks == 1, "Rebuild duplicated the editor update hook.");
                int pageHooks = 0;
                var changed = Get<Delegate>(renderer.lodStreamer, "OnPagesChanged");
                foreach (var handler in changed.GetInvocationList())
                    if (ReferenceEquals(handler.Target, renderer) && handler.Method.Name == "OnLodPagesChanged") ++pageHooks;
                Require(pageHooks == 1 && GaussianSplatRenderSystem.instance.RegisteredSplatCount == previousRegistered + 1,
                    "Rebuild duplicated page-change callbacks or render registration.");
            }
            public void ForceAndCheckDisposal()
            {
                var oldBuffers = new List<GraphicsBuffer>();
                foreach (string name in new[] { "m_GpuLodUnifiedPos", "m_GpuLodUnifiedOther", "m_GpuLodUnifiedSh",
                    "m_GpuLodAtlasIndices", "m_GpuView", "m_GpuIndexBuffer", "m_GpuSortKeys", "m_GpuSortDistances", "m_GpuPagedLodDeletedBits" })
                    oldBuffers.Add(Get<GraphicsBuffer>(renderer, name));
                var oldMaterial = Get<Material>(renderer, "m_MatSplats");
                Require(renderer.ForceRebuildPagedLodInEditor(), "Force build failed with valid imported pages.");
                foreach (var buffer in oldBuffers) Require(buffer == null || !buffer.IsValid(), "Force build leaked an old GPU buffer.");
                Require(oldMaterial == null, "Force build leaked its old draw material.");
                AssertHooks();
            }
            public void ForceWithPendingWorker()
            {
                Get<SplatBoxLodSelectionWorker>(renderer, "m_LodSelectionWorker")?.Dispose();
                var worker = new SplatBoxLodSelectionWorker();
                var pending = new TaskCompletionSource<SplatBoxLodSelectionWorker.Result>();
                Set(worker, "m_Task", pending.Task);
                Set(renderer, "m_LodSelectionWorker", worker);
                var workspace = Get<SplatBoxLodTraverser.Workspace>(worker, "m_Workspace");
                var atlas = Get<GraphicsBuffer>(renderer, "m_GpuLodUnifiedPos");
                bool observed = false;
                var streamer = renderer.lodStreamer;
                Action beforeAtlasDisposal = () =>
                {
                    if (observed) return;
                    observed = true;
                    Require(Get<bool>(worker, "m_Disposed") && Get<int[]>(workspace, "cancellationRequest")[0] != 0 && atlas.IsValid(),
                        "Old page residency was released before worker cancellation or after atlas disposal.");
                };
                streamer.OnPagesChanged += beforeAtlasDisposal;
                try
                {
                    ForceAndCheckDisposal();
                    Require(observed, "Force-build teardown ordering was not observed.");
                    pending.SetResult(new SplatBoxLodSelectionWorker.Result { selected = 1, atlasIndices = new uint[] { uint.MaxValue } });
                    Require(!worker.TryComplete(out _), "A disposed worker published stale atlas indices.");
                }
                finally
                {
                    streamer.OnPagesChanged -= beforeAtlasDisposal;
                    pending.TrySetResult(default); worker.Dispose();
                }
            }
            GaussianSplatPageEntry Entry(int id, bool ready) => new GaussianSplatPageEntry
            {
                pageId = id, boundsMin = pages[id].boundsMin, boundsMax = pages[id].boundsMax,
                splatCount = 3, lodNodeCount = 3, pageAsset = ready ? pages[id] : null
            };
            GaussianSplatPageAsset CreatePage(int id)
            {
                float x = overlappingDepths ? 0 : (id - 1) * 0.8f;
                float z = overlappingDepths ? 4 + id : 5;
                float offset = overlappingDepths ? 0 : 0.1f;
                var min = new Vector3(x - 0.2f, -0.2f, z - 0.2f); var max = new Vector3(x + 0.2f, 0.2f, z + 0.2f);
                var positions = new float[] { x, 0, z, x - offset, 0, z, x + offset, 0, z };
                var other = new uint[12];
                for (int i = 0; i < 3; ++i)
                {
                    other[i * 4] = 0xE0080200u;
                    other[i * 4 + 1] = other[i * 4 + 2] = other[i * 4 + 3] = math.asuint(0.07f);
                }
                var colors = new byte[(int)GaussianSplatAsset.CalcColorDataSize(3, GaussianSplatAsset.ColorFormat.Norm8x4)];
                for (int i = 0; i < colors.Length; i += 4)
                {
                    colors[i] = overlappingDepths ? (byte)(id == 0 ? 255 : 0) : (byte)153;
                    colors[i + 1] = overlappingDepths ? (byte)(id == 1 ? 255 : 0) : (byte)102;
                    colors[i + 2] = overlappingDepths ? (byte)(id == 2 ? 255 : 0) : (byte)51;
                    colors[i + 3] = 204;
                }
                var data = ScriptableObject.CreateInstance<GaussianSplatAsset>();
                data.Initialize(3, GaussianSplatAsset.VectorFormat.Float32, GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Float32, min, max, null);
                data.SetAssetFiles(null, Bytes(id + "pos", ToBytes(positions)), Bytes(id + "other", ToBytes(other)),
                    Bytes(id + "color", colors), Bytes(id + "sh", new byte[3 * 192]));
                AssetDatabase.CreateAsset(data, folder + "/data" + id + ".asset");
                var nodes = new[] { new LodTreeNode { center = new float3(x, 0, z), featureSize = 0.4f, childStart = 1, childCount = 2 },
                    new LodTreeNode { center = new float3(x - offset, 0, z), featureSize = 0.14f },
                    new LodTreeNode { center = new float3(x + offset, 0, z), featureSize = 0.14f } };
                var page = ScriptableObject.CreateInstance<GaussianSplatPageAsset>();
                page.Initialize(id, Vector3Int.zero, min, max, data, Bytes(id + "tree", LodTreeNode.ToBytes(nodes)), 3, 2);
                AssetDatabase.CreateAsset(page, folder + "/page" + id + ".asset");
                return page;
            }
            static byte[] ToBytes(Array data)
            {
                var bytes = new byte[Buffer.ByteLength(data)]; Buffer.BlockCopy(data, 0, bytes, 0, bytes.Length); return bytes;
            }
            TextAsset Bytes(string name, byte[] bytes)
            {
                string path = folder + "/" + name + ".bytes";
                File.WriteAllBytes(path, bytes); AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
            }
            public void Dispose()
            {
                Camera.onPreCull -= OnCamera;
                RenderPipelineManager.beginCameraRendering -= OnPipelineCamera;
                Undo.ClearUndo(renderer);
                UnityEngine.Object.DestroyImmediate(owner);
                if (cameraOwner != null) UnityEngine.Object.DestroyImmediate(cameraOwner);
                UnityEngine.Object.DestroyImmediate(target); UnityEngine.Object.DestroyImmediate(readback);
                AssetDatabase.DeleteAsset(folder);
                foreach (var previous in previousMains) if (previous != null) previous.tag = "MainCamera";
                GaussianSplatRenderSystem.SplatRenderScale = previousScale;
            }
        }

        static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Fields).GetValue(target);
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Fields).SetValue(target, value);
        static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Fields).Invoke(target, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    }
}
