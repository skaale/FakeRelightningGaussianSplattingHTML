// SPDX-License-Identifier: MIT

using System.Linq;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianCutout : MonoBehaviour
    {
        public enum Type
        {
            Ellipsoid,
            Box
        }

        public Type m_Type = Type.Ellipsoid;
        public bool m_Invert = false;

        public struct ShaderData // match GaussianCutoutShaderData in CS
        {
            public Matrix4x4 matrix;
            public uint typeAndFlags;
            public float expansionX;
            public float expansionY;
            public float cutDepth;
            public uint extrusionAxis;  // 0=auto/Z, 1=X, 2=Y, 3=Z
            public float offsetX;
            public float offsetY;
            public uint vertexStart;
            public uint vertexCount;
        }

        // Polygon tools live in a separate assembly; expose geometry through the base contract.
        public virtual IReadOnlyList<Vector3> polygonVertices => null;

        public static ShaderData GetShaderData(GaussianCutout self, Matrix4x4 rendererMatrix) =>
            self != null ? self.BuildShaderData(rendererMatrix) : new ShaderData { typeAndFlags = ~0u };

        public virtual ShaderData BuildShaderData(Matrix4x4 rendererMatrix)
        {
            var self = this;
            ShaderData sd = default;
            if (self && self.isActiveAndEnabled)
            {
                var tr = self.transform;
                sd.matrix = tr.worldToLocalMatrix * rendererMatrix;
                sd.typeAndFlags = ((uint)self.m_Type) | (self.m_Invert ? 0x100u : 0u);
                sd.expansionX = 1.0f;  // Default no expansion for Ellipsoid/Box
                sd.expansionY = 1.0f;
                sd.cutDepth = 100.0f;  // Default deep cut
                sd.extrusionAxis = 0;  // Not used for Ellipsoid/Box
                sd.offsetX = 0.0f;
                sd.offsetY = 0.0f;
            }
            else
            {
                sd.typeAndFlags = ~0u;
                sd.expansionX = 1.0f;
                sd.expansionY = 1.0f;
                sd.cutDepth = 100.0f;
                sd.extrusionAxis = 0;
                sd.offsetX = 0.0f;
                sd.offsetY = 0.0f;
            }
            return sd;
        }
    }
}
