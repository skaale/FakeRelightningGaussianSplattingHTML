// SPDX-License-Identifier: MIT
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        GraphicsBuffer m_GpuPagedEditSculptScratch, m_GpuPagedEditSculptEmpty, m_GpuPagedEditRelaxEmpty;
        readonly List<GraphicsBuffer> m_PagedEditSculptRetiredBuffers = new List<GraphicsBuffer>();
        readonly Dictionary<Vector4[], GraphicsBuffer> m_PagedEditRelaxBuffers = new Dictionary<Vector4[], GraphicsBuffer>();
        bool m_PagedEditSculptGpuDirty;

        // Reconstruct the positions at the time this edit was made. The scratch range is consumed
        // immediately by the following erase/color dispatch and can then be reused by the next
        // snapshot. These are GPU commands, not SetData writes to a resource still queued for use.
        bool BindPagedEditSculptSnapshot(CommandBuffer cmd, int kernel, int snapshot, int offset, int count)
        {
            if (!IsPagedEditSculptSnapshotValid(snapshot)) return false;
            if (m_PagedEditSculptGpuDirty)
            {
                DisposePagedEditSculptBuffers();
                m_PagedEditSculptGpuDirty = false;
            }
            if (snapshot != 0 && IsCurrentPagedEditSculptSnapshot(snapshot) && PagedSmudgeOffsetsValid)
            {
                // Ordinary brushing on the current geometry can read the already-replayed atlas.
                // Historical snapshots still reconstruct separately after any later deformation.
                cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedEditSculptOffsets", m_GpuPagedSmudgeOffsets);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEditSculptValid", 1);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEditSculptOffset", 0);
                return true;
            }
            if (snapshot == 0)
            {
                if (m_GpuPagedEditSculptEmpty == null)
                {
                    m_GpuPagedEditSculptEmpty = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(float) * 3)
                        { name = "PagedEditSculptEmpty" };
                    m_GpuPagedEditSculptEmpty.SetData(new[] { Vector3.zero });
                }
                cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedEditSculptOffsets", m_GpuPagedEditSculptEmpty);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEditSculptValid", 0);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEditSculptOffset", 0);
                return true;
            }
            if (!FindPagedSmudgeKernels() || !EnsureLodFormatAsset() || count <= 0) return false;
            if (m_GpuPagedEditSculptScratch == null || m_GpuPagedEditSculptScratch.count < count)
            {
                // A larger page can arrive while commands for a smaller page are still queued.
                // Retain old allocations until atlas teardown; geometric growth bounds their sum.
                if (m_GpuPagedEditSculptScratch != null) m_PagedEditSculptRetiredBuffers.Add(m_GpuPagedEditSculptScratch);
                int capacity = Mathf.NextPowerOfTwo(count);
                m_GpuPagedEditSculptScratch = new GraphicsBuffer(GraphicsBuffer.Target.Structured, capacity, sizeof(float) * 3)
                    { name = "PagedEditSculptSnapshot" };
            }
            DispatchPagedSmudgeRange(cmd, m_PagedSmudgeClearKernel, offset, count, m_GpuPagedEditSculptScratch, offset);
            foreach (var dab in EnumeratePagedEditSculptSnapshot(snapshot))
                DispatchPagedSmudge(cmd, offset, count, dab, m_GpuPagedEditSculptScratch, offset, GetPagedEditRelaxBuffer(dab));
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedEditSculptOffsets", m_GpuPagedEditSculptScratch);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEditSculptOffset", offset);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEditSculptValid", 1);
            return true;
        }

        GraphicsBuffer GetPagedEditRelaxBuffer(in PagedSmudgeDab dab)
        {
            // Historical Relax fields outlive resetting the live sculpt journal. Their buffers
            // must not be disposed by EnsurePagedSmudgeState while an edit replay is queued.
            if (dab.kind == 4 && dab.relaxCells != null && dab.relaxCells.Length > 0)
            {
                if (!m_PagedEditRelaxBuffers.TryGetValue(dab.relaxCells, out var buffer))
                {
                    buffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, dab.relaxCells.Length, sizeof(float) * 4)
                        { name = "PagedEditRelaxSnapshot" };
                    buffer.SetData(dab.relaxCells);
                    m_PagedEditRelaxBuffers.Add(dab.relaxCells, buffer);
                }
                return buffer;
            }
            if (m_GpuPagedEditRelaxEmpty == null)
            {
                m_GpuPagedEditRelaxEmpty = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(float) * 4)
                    { name = "PagedEditRelaxEmpty" };
                m_GpuPagedEditRelaxEmpty.SetData(new[] { Vector4.zero });
            }
            return m_GpuPagedEditRelaxEmpty;
        }

        void DisposePagedEditSculptBuffers()
        {
            DisposeBuffer(ref m_GpuPagedEditSculptScratch);
            DisposeBuffer(ref m_GpuPagedEditSculptEmpty);
            DisposeBuffer(ref m_GpuPagedEditRelaxEmpty);
            foreach (var buffer in m_PagedEditSculptRetiredBuffers) buffer.Dispose();
            m_PagedEditSculptRetiredBuffers.Clear();
            foreach (var buffer in m_PagedEditRelaxBuffers.Values) buffer.Dispose();
            m_PagedEditRelaxBuffers.Clear();
        }
    }
}
