using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>Stable visible-prefix compaction and GPU-written sort/view dispatch sizes.</summary>
    public sealed class GpuSplatCompaction : IDisposable
    {
        const int GroupSize = 256;
        readonly ComputeShader m_Shader;
        readonly int m_Scan = -1;
        readonly int m_Scatter = -1;
        public GraphicsBuffer groupOffsets { get; private set; }
        // [sort groups, 1, 1, visible count, view groups, 1, 1, reserved]
        public GraphicsBuffer dispatchArgs { get; private set; }
        public bool valid { get; }

        public GpuSplatCompaction()
        {
            m_Shader = Resources.Load<ComputeShader>("SplatCompact");
            if (m_Shader == null || !SystemInfo.supportsIndirectArgumentsBuffer)
                return;
            m_Scan = m_Shader.FindKernel("ScanVisibleGroups");
            m_Scatter = m_Shader.FindKernel("ScatterVisible");
            valid = m_Shader.IsSupported(m_Scan) && m_Shader.IsSupported(m_Scatter);
        }

        public void EnsureCapacity(int splatCount)
        {
            int groups = (splatCount + GroupSize - 1) / GroupSize;
            if (groupOffsets == null || groupOffsets.count < groups)
            {
                groupOffsets?.Dispose();
                groupOffsets = new GraphicsBuffer(GraphicsBuffer.Target.Structured, groups, 4)
                    { name = "SplatVisibleGroupOffsets" };
            }
            dispatchArgs ??= new GraphicsBuffer(GraphicsBuffer.Target.Structured | GraphicsBuffer.Target.IndirectArguments, 8, 4)
                { name = "SplatVisibleDispatchArgs" };
        }

        public void Dispatch(CommandBuffer cmd, int count, GraphicsBuffer distances,
            GraphicsBuffer compactDistances, GraphicsBuffer compactIndices, GraphicsBuffer drawArgs,
            uint instanceMultiplier, uint viewGroupSize)
        {
            cmd.BeginSample("GaussianSplat.CompactVisible");
            cmd.SetComputeIntParam(m_Shader, "_InputCount", count);
            cmd.SetComputeIntParam(m_Shader, "_GroupCount", (count + GroupSize - 1) / GroupSize);
            cmd.SetComputeIntParam(m_Shader, "_InstanceMultiplier", (int)Math.Max(1u, instanceMultiplier));
            cmd.SetComputeIntParam(m_Shader, "_ViewGroupSize", (int)Math.Max(1u, viewGroupSize));
            cmd.SetComputeBufferParam(m_Shader, m_Scan, "_GroupOffsets", groupOffsets);
            cmd.SetComputeBufferParam(m_Shader, m_Scan, "_DispatchArgs", dispatchArgs);
            cmd.SetComputeBufferParam(m_Shader, m_Scan, "_DrawArgs", drawArgs);
            cmd.DispatchCompute(m_Shader, m_Scan, 1, 1, 1);

            cmd.SetComputeBufferParam(m_Shader, m_Scatter, "_GroupOffsets", groupOffsets);
            cmd.SetComputeBufferParam(m_Shader, m_Scatter, "_DispatchArgs", dispatchArgs);
            cmd.SetComputeBufferParam(m_Shader, m_Scatter, "_Distances", distances);
            cmd.SetComputeBufferParam(m_Shader, m_Scatter, "_CompactDistances", compactDistances);
            cmd.SetComputeBufferParam(m_Shader, m_Scatter, "_CompactIndices", compactIndices);
            cmd.DispatchCompute(m_Shader, m_Scatter, (count + GroupSize - 1) / GroupSize, 1, 1);
            cmd.EndSample("GaussianSplat.CompactVisible");
        }

        public void Dispose()
        {
            groupOffsets?.Dispose();
            dispatchArgs?.Dispose();
            groupOffsets = null;
            dispatchArgs = null;
        }
    }
}
