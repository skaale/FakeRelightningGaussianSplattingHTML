// SPDX-License-Identifier: MIT
namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        uint m_PagedAttractorPoseRevision;
        uint m_PendingAttractorPoseRevision, m_AsyncAttractorPoseRevision;
        bool m_PendingAttractorCompleteCoverage, m_AsyncAttractorCompleteCoverage;
        bool m_PagedAttractorSelectionComplete;

        // Edit-mode selection is already omnidirectional. A complete hierarchy frontier still
        // represents every source leaf after movement, so only its preferred detail needs updating.
        // Frustum/copy clipping and omitted merged nodes cannot make that guarantee.
        bool CanRetainPagedAttractorSelection => m_HasLastLodView &&
            m_PagedAttractorSelectionComplete && !EffectiveFrustumCull &&
            PagedXcopyBoundary == null && EffectiveDrawCoarseStandIns;

        void NotifyPagedAttractorHierarchyChanged(bool topologyChanged)
        {
            if (topologyChanged) m_PagedAttractorSelectionComplete = false;
            RequestPagedAttractorSelectionRefresh();
        }

        void NotifyPagedAttractorMotion()
        {
            unchecked { m_PagedAttractorPoseRevision++; }
            RequestPagedAttractorSelectionRefresh();
        }

        void RequestPagedAttractorSelectionRefresh()
        {
            m_LodSelectionDirty = true;
            if (CanRetainPagedAttractorSelection) return;
            InvalidateLodAsyncSelection();
            m_LodSelectionInvalid = true;
        }

        void ResetPagedAttractorSelection()
        {
            unchecked { m_PagedAttractorPoseRevision++; }
            m_PagedAttractorSelectionComplete = false;
            m_PendingAttractorCompleteCoverage = m_AsyncAttractorCompleteCoverage = false;
        }

        void RecordPagedAttractorSelection(bool completeCoverage, int droppedMerged, uint capturedPose)
        {
            m_PagedAttractorSelectionComplete = completeCoverage && droppedMerged == 0;
            // A worker may have refined an earlier pose. Keep refreshing quality at the ordinary
            // cadence instead of either canceling every worker or treating that pose as final.
            if (HasPagedAttractorState && capturedPose != m_PagedAttractorPoseRevision)
                m_LodSelectionDirty = true;
        }

        bool IsPagedAttractorWorkerPoseValid(int droppedMerged)
        {
            if (!HasPagedAttractorState || m_AsyncAttractorPoseRevision == m_PagedAttractorPoseRevision ||
                (m_AsyncAttractorCompleteCoverage && droppedMerged == 0)) return true;
            // An incomplete frontier from an older pose can omit content that moved into view.
            // Repair it synchronously; do not repeatedly reject workers while showing holes.
            m_PagedAttractorSelectionComplete = false;
            m_LodSelectionInvalid = m_LodSelectionDirty = true;
            return false;
        }
    }
}
