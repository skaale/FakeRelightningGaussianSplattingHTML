// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        // Relax is a neighborhood operation, unlike the other pointwise sculpt brushes. Capture
        // its field once from original fine leaves plus the preceding journal, then serialize it
        // with the dab. Replays never depend on the selected LoD or which pages happen to reside.
        bool CapturePagedRelaxField(ref PagedSmudgeDab dab)
        {
            if (!UsesPagedLod || dab.radius <= 0f || !PagedEraseFinite(dab.neighborRadius))
                return false;
            EnsurePagedSmudgeHierarchy();
            dab.neighborRadius = Mathf.Clamp(dab.neighborRadius, .1f, 1f);
            dab.relaxGridSize = Mathf.Clamp(Mathf.CeilToInt(2f / dab.neighborRadius), 1, 20);
            int cellCount = dab.relaxGridSize * dab.relaxGridSize * dab.relaxGridSize;
            var sumX = new double[cellCount];
            var sumY = new double[cellCount];
            var sumZ = new double[cellCount];
            var counts = new int[cellCount];
            var sources = new HashSet<GaussianSplatPageAsset>();
            var capture = dab;
            int sampleCount = 0;

            void Accumulate(Vector3 original)
            {
                if (!PagedEraseFinite(original)) return;
                // Most leaves cannot reach this brush even after the preceding edits. Reject them
                // before replaying potentially long journals, while retaining displaced neighbors.
                var possible = new Bounds();
                possible.SetMinMax(original + m_PagedSmudgeDisplacementMin,
                    original + m_PagedSmudgeDisplacementMax);
                if (possible.SqrDistance(capture.center) >= capture.radius * capture.radius)
                    return;
                Vector3 position = original;
                for (int i = 0; i < m_PagedSmudgeHierarchyDabs.Count; i++)
                    position = ApplyPagedSculptPoint(position, original, m_PagedSmudgeHierarchyDabs[i]);
                if ((position - capture.center).sqrMagnitude >= capture.radius * capture.radius)
                    return;
                int3 cell = PagedRelaxCell(position, capture);
                int index = cell.x + capture.relaxGridSize * (cell.y + capture.relaxGridSize * cell.z);
                sumX[index] += position.x;
                sumY[index] += position.y;
                sumZ[index] += position.z;
                counts[index]++;
                sampleCount++;
            }

            void CaptureSource(GaussianSplatPageAsset source)
            {
                if (source == null || !sources.Add(source) || source.lodTreeData == null ||
                    source.splatData == null || source.splatData.posData == null)
                    return;
                Bounds possiblePage = ExpandPagedSmudgeBoundsUnchecked(source.bounds);
                if (possiblePage.SqrDistance(capture.center) >= capture.radius * capture.radius)
                    return;
                var asset = source.splatData;
                NativeArray<LodTreeNode> nodes = source.lodTreeData.GetData<LodTreeNode>();
                NativeArray<byte> positions = asset.posData.GetData<byte>();
                NativeArray<GaussianSplatAsset.ChunkInfo> chunks = default;
                if (asset.chunkData != null && asset.chunkData.dataSize > 0)
                    chunks = asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>();
                int stride = GaussianSplatAsset.GetVectorSize(asset.posFormat);
                int nodeCount = Mathf.Min(source.lodNodeCount, nodes.Length, positions.Length / stride);
                for (int i = 0; i < nodeCount; i++)
                {
                    if (nodes[i].IsMergedSplat) continue;
                    float3 position = DecodePagedSculptRawPosition(positions, i * stride, asset.posFormat);
                    int chunkIndex = i / GaussianSplatAsset.kChunkSize;
                    if (chunks.IsCreated && chunkIndex < chunks.Length)
                    {
                        var chunk = chunks[chunkIndex];
                        position = math.lerp(new float3(chunk.posX.x, chunk.posY.x, chunk.posZ.x),
                            new float3(chunk.posX.y, chunk.posY.y, chunk.posZ.y), position);
                    }
                    Accumulate(position);
                }
            }

            var manifest = m_PagedScene?.pages;
            if (manifest != null)
                for (int i = 0; i < manifest.Length; i++) CaptureSource(manifest[i].pageAsset);

            var loaded = m_LodStreamer?.loadedPages;
            if (loaded != null)
            {
                for (int p = 0; p < loaded.Count; p++)
                {
                    var page = loaded[p];
                    if (page?.lodTree?.nodes == null) continue;
                    if (page.source != null && page.source.lodTreeData != null && page.source.splatData?.posData != null)
                    {
                        CaptureSource(page.source);
                        continue;
                    }
                    // Synthetic/runtime-injected pages have no asset payload. Their fine leaf
                    // baseline is still useful, but a merged coarse proxy is never a fake neighbor.
                    m_PagedSmudgeTrees.TryGetValue(page, out var state);
                    var original = state?.original ?? page.lodTree;
                    Vector3[] positions = state?.originalPositions;
                    if (positions == null)
                    {
                        positions = ReadPagedSculptOriginalPositions(page, original);
                        if (state != null) state.originalPositions = positions;
                    }
                    for (int n = 0; n < original.nodes.Length; n++)
                        if (!original.nodes[n].IsMergedSplat) Accumulate(positions[n]);
                }
            }

            if (sampleCount == 0)
                return false;
            var cells = new Vector4[cellCount];
            for (int i = 0; i < cellCount; i++)
            {
                if (counts[i] == 0) continue;
                double reciprocal = 1.0 / counts[i];
                cells[i] = new Vector4((float)(sumX[i] * reciprocal), (float)(sumY[i] * reciprocal),
                    (float)(sumZ[i] * reciprocal), counts[i]);
            }
            dab.relaxCells = cells;
            return true;
        }

        static int3 PagedRelaxCell(Vector3 position, in PagedSmudgeDab dab)
        {
            float cellSize = dab.neighborRadius * dab.radius;
            Vector3 origin = dab.center - Vector3.one * dab.radius;
            Vector3 offset = position - origin;
            return new int3(Mathf.Clamp(Mathf.FloorToInt(offset.x / cellSize), 0, dab.relaxGridSize - 1),
                Mathf.Clamp(Mathf.FloorToInt(offset.y / cellSize), 0, dab.relaxGridSize - 1),
                Mathf.Clamp(Mathf.FloorToInt(offset.z / cellSize), 0, dab.relaxGridSize - 1));
        }

        static Vector3 PagedRelaxTarget(Vector3 position, in PagedSmudgeDab dab)
        {
            int size = dab.relaxGridSize;
            if (size <= 0 || size > 20 || dab.relaxCells == null || dab.relaxCells.Length != size * size * size ||
                dab.radius <= 0f || dab.neighborRadius <= 0f)
                return position;
            int3 center = PagedRelaxCell(position, dab);
            float cellSize = dab.neighborRadius * dab.radius;
            float radiusSquared = cellSize * cellSize;
            Vector3 sum = position;
            float count = 1f;
            for (int z = Mathf.Max(0, center.z - 1); z <= Mathf.Min(size - 1, center.z + 1); z++)
                for (int y = Mathf.Max(0, center.y - 1); y <= Mathf.Min(size - 1, center.y + 1); y++)
                    for (int x = Mathf.Max(0, center.x - 1); x <= Mathf.Min(size - 1, center.x + 1); x++)
                    {
                        Vector4 cell = dab.relaxCells[x + size * (y + size * z)];
                        Vector3 centroid = cell;
                        if (cell.w <= 0f || (centroid - position).sqrMagnitude >= radiusSquared) continue;
                        sum += centroid * cell.w;
                        count += cell.w;
                    }
            return sum / count;
        }
    }
}
