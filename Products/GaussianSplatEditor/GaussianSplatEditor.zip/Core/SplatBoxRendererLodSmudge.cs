// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [Serializable]
        internal struct PagedSmudgeDab
        {
            // Zero remains Smudge/Move so scenes saved before other brushes were added replay unchanged.
            public int kind; // 0: Smudge/Move, 1: Pinch, 2: Flatten, 3: Restore, 4: Relax/Roughen.
            // Object-space edits follow the renderer when its transform changes.
            public Vector3 center, delta;
            public float radius, falloff, strength;
            public Vector3 normal;
            public float neighborRadius;
            public bool invert;
            public int relaxGridSize;
            // An immutable neighborhood field makes smoothing independent of page residency.
            public Vector4[] relaxCells;
        }

        [SerializeField, HideInInspector] GaussianSplatPagedScene m_PagedSmudgeScene;
        [SerializeField, HideInInspector] List<PagedSmudgeDab> m_PagedSmudgeDabs = new List<PagedSmudgeDab>();
        [SerializeField, HideInInspector] int m_PagedSmudgeRevision;

        GraphicsBuffer m_GpuPagedSmudgeOffsets, m_GpuPagedSmudgeEmpty;
        GraphicsBuffer m_GpuPagedRelaxEmpty;
        readonly Dictionary<Vector4[], GraphicsBuffer> m_PagedRelaxBuffers = new Dictionary<Vector4[], GraphicsBuffer>();
        int m_PagedSmudgeAppliedRevision = -1;
        int m_PagedSmudgeApplyKernel = -1, m_PagedSmudgeClearKernel = -1;
        bool m_PagedSmudgeStrokeOpen, m_PagedSmudgeStrokeRecorded;
#if UNITY_EDITOR
        int m_PagedSmudgeUndoGroup = -1;
#endif
        bool HasPagedSmudgeJournal => UsesPagedLod && m_PagedSmudgeScene == m_PagedScene &&
            m_PagedSmudgeDabs != null && m_PagedSmudgeDabs.Count > 0;
        bool PagedSmudgeOffsetsValid => HasPagedSmudgeJournal && m_GpuPagedSmudgeOffsets != null &&
            m_PagedSmudgeAppliedRevision == m_PagedSmudgeRevision;
        public int pagedSmudgeDabCount => HasPagedSmudgeJournal ? m_PagedSmudgeDabs.Count : 0;
        public int pagedSculptDabCount => pagedSmudgeDabCount;

        // Keep the original API and serialized field names compatible with saved Smudge scenes.
        public void BeginPagedSculptStroke() => BeginPagedSmudgeStroke();
        public void EndPagedSculptStroke() => EndPagedSmudgeStroke();
        public void ResetPagedSculpt() => ResetPagedSmudge();

        IEnumerable<PagedSmudgeDab> EnumeratePagedSmudgeDabs()
        {
            if (HasPagedSmudgeJournal)
                for (int i = 0; i < m_PagedSmudgeDabs.Count; i++)
                    yield return m_PagedSmudgeDabs[i];
        }

        /// <summary>One drag is one Unity Undo operation, regardless of its number of dabs.</summary>
        public void BeginPagedSmudgeStroke()
        {
            if (!UsesPagedLod || m_PagedSmudgeStrokeOpen) return;
            m_PagedSmudgeStrokeOpen = true;
            m_PagedSmudgeStrokeRecorded = false;
        }

        public void EndPagedSmudgeStroke()
        {
            m_PagedSmudgeStrokeOpen = m_PagedSmudgeStrokeRecorded = false;
#if UNITY_EDITOR
            if (m_PagedSmudgeUndoGroup >= 0)
            {
                UnityEditor.Undo.FlushUndoRecordObjects();
                UnityEditor.Undo.CollapseUndoOperations(m_PagedSmudgeUndoGroup);
                m_PagedSmudgeUndoGroup = -1;
            }
#endif
        }

        void RecordPagedSmudgeUndo(string label, bool gesture = false)
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                if (gesture)
                {
                    UnityEditor.Undo.IncrementCurrentGroup();
                    m_PagedSmudgeUndoGroup = UnityEditor.Undo.GetCurrentGroup();
                    UnityEditor.Undo.SetCurrentGroupName(label);
                }
                UnityEditor.Undo.RegisterCompleteObjectUndo(this, label);
            }
#endif
        }

        public void ResetPagedSmudge()
        {
            EndPagedSmudgeStroke();
            InvalidatePagedEditSculptHistoryCache();
            if (m_PagedSmudgeDabs == null || m_PagedSmudgeDabs.Count == 0) return;
            RecordPagedSmudgeUndo("Reset All Sculpting", true);
            m_PagedSmudgeDabs.Clear();
            unchecked { m_PagedSmudgeRevision++; }
            EnsurePagedSmudgeState(null);
            MarkPagedSmudgeChanged();
            EndPagedSmudgeStroke();
        }

        bool ApplyPagedSmudge(Vector3 center, Vector3 delta, float radius, float falloff, float strength)
            => ApplyPagedSculptDab(new PagedSmudgeDab { center = center, delta = delta, radius = radius,
                falloff = falloff, strength = strength });

        bool ApplyPagedPinch(Vector3 center, float radius, float falloff, float strength)
            => ApplyPagedSculptDab(new PagedSmudgeDab { kind = 1, center = center, radius = radius,
                falloff = falloff, strength = strength });

        bool ApplyPagedFlatten(Vector3 center, Vector3 normal, float radius, float falloff, float strength)
            => ApplyPagedSculptDab(new PagedSmudgeDab { kind = 2, center = center, normal = normal,
                radius = radius, falloff = falloff, strength = strength });

        bool ApplyPagedRestore(Vector3 center, float radius, float falloff, float strength)
            => ApplyPagedSculptDab(new PagedSmudgeDab { kind = 3, center = center, radius = radius,
                falloff = falloff, strength = strength });

        bool ApplyPagedRelax(Vector3 center, float radius, float falloff, float strength, float neighborRadius, bool invert)
            => ApplyPagedSculptDab(new PagedSmudgeDab { kind = 4, center = center, radius = radius,
                falloff = falloff, strength = strength, neighborRadius = neighborRadius, invert = invert });

        bool ApplyPagedSculptDab(PagedSmudgeDab dab)
        {
            if (!UsesPagedLod || !PagedEraseFinite(dab.center) ||
                !PagedEraseFinite(dab.radius) || dab.radius <= 0 || !PagedEraseFinite(dab.radius * dab.radius) ||
                !PagedEraseFinite(dab.falloff) || !PagedEraseFinite(dab.strength) || dab.strength == 0 ||
                (dab.strength < 0 && dab.kind != 1) ||
                !FindPagedSmudgeKernels()) return false;
            dab.falloff = Mathf.Clamp01(dab.falloff);
            if (dab.kind == 0 && (!PagedEraseFinite(dab.delta) ||
                !PagedEraseFinite(dab.delta.sqrMagnitude) || dab.delta.sqrMagnitude <= 0)) return false;
            if (dab.kind == 2)
            {
                if (!PagedEraseFinite(dab.normal) || !PagedEraseFinite(dab.normal.sqrMagnitude) || dab.normal.sqrMagnitude < 1e-12f)
                    return false;
                dab.normal.Normalize();
            }
            if (dab.kind == 3)
            {
                if (!HasPagedSmudgeJournal) return false;
                // Restoration must approach the source, never overshoot it at Smudge strength > 1.
                dab.strength = Mathf.Clamp01(dab.strength);
            }
            if (dab.kind == 4)
            {
                if (!PagedEraseFinite(dab.neighborRadius) || dab.neighborRadius <= 0) return false;
                dab.neighborRadius = Mathf.Clamp(dab.neighborRadius, .1f, 1f);
            }

            GetPagedSculptDisplacementBounds(dab, out Vector3 minimum, out Vector3 maximum);
            if (!PagedEraseFinite(minimum) || !PagedEraseFinite(maximum)) return false;
            RefreshPagedSmudgeHierarchyJournal();
            if (!PagedEraseFinite(m_PagedSmudgeDisplacementMin + minimum) ||
                !PagedEraseFinite(m_PagedSmudgeDisplacementMax + maximum)) return false;
            if (dab.kind == 4 && !CapturePagedRelaxField(ref dab)) return false;

            bool standalone = !m_PagedSmudgeStrokeOpen;
            if (standalone) BeginPagedSmudgeStroke();
            string label = dab.kind == 1 ? "Pinch Paged Splats" : dab.kind == 2 ? "Flatten Paged Splats" :
                dab.kind == 3 ? "Restore Paged Splats" : dab.kind == 4 ?
                (dab.invert ? "Roughen Paged Splats" : "Relax Paged Splats") : "Smudge Paged Splats";
            using var cmd = new CommandBuffer { name = label };
            // Undo/reload reconstruction happens before appending the new dab.
            EnsurePagedSmudgeState(cmd);
            if (!m_PagedSmudgeStrokeRecorded)
            {
                RecordPagedSmudgeUndo(label, true);
                m_PagedSmudgeStrokeRecorded = true;
            }
            if (m_PagedSmudgeScene != m_PagedScene)
            {
                m_PagedSmudgeScene = m_PagedScene;
                m_PagedSmudgeDabs = new List<PagedSmudgeDab>();
            }
            m_PagedSmudgeDabs ??= new List<PagedSmudgeDab>();
            m_PagedSmudgeDabs.Add(dab);
            unchecked { m_PagedSmudgeRevision++; }
            if (EnsurePagedSmudgeBuffer(cmd))
            {
                var pages = m_LodStreamer?.loadedPages;
                if (pages != null)
                    for (int i = 0; i < pages.Count; i++)
                        if (HasUploadedPagedEraseRange(pages[i]))
                            DispatchPagedSmudge(cmd, pages[i].atlasOffset, pages[i].splatCount, dab);
                m_PagedSmudgeAppliedRevision = m_PagedSmudgeRevision;
            }
            Graphics.ExecuteCommandBuffer(cmd);
            MarkPagedSmudgeChanged();
            if (standalone) EndPagedSmudgeStroke();
            return true;
        }

        void MarkPagedSmudgeChanged()
        {
            editModified = true;
            InvalidatePagedSmudgeHierarchy();
            EnsurePagedSmudgeHierarchy();
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                MarkPagedLodEraseDirty();
                UnityEditor.PrefabUtility.RecordPrefabInstancePropertyModifications(this);
                UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
            }
#endif
        }

        void EnsurePagedSmudgeState(CommandBuffer cmd)
        {
            EnsurePagedSmudgeHierarchy();
            if (!HasPagedSmudgeJournal)
            {
                if (m_GpuPagedSmudgeOffsets != null)
                {
                    DisposePagedSmudgeBuffer();
                    InvalidatePagedSmudgeHierarchy();
                }
                return;
            }
            if (PagedSmudgeOffsetsValid && m_GpuPagedSmudgeOffsets.count == m_LodAtlasCapacity) return;
            if (cmd == null)
            {
                using var immediate = new CommandBuffer { name = "Replay Paged Smudge" };
                EnsurePagedSmudgeState(immediate);
                Graphics.ExecuteCommandBuffer(immediate);
                return;
            }
            PrunePagedRelaxBuffers();
            if (!EnsurePagedSmudgeBuffer(cmd)) return;
            ClearPagedSmudgeRange(cmd, 0, m_LodAtlasCapacity);
            var pages = m_LodStreamer?.loadedPages;
            if (pages != null)
                for (int i = 0; i < pages.Count; i++)
                    if (HasUploadedPagedEraseRange(pages[i]))
                        ReplayPagedSmudgeDabs(cmd, pages[i].atlasOffset, pages[i].splatCount);
            m_PagedSmudgeAppliedRevision = m_PagedSmudgeRevision;
            InvalidatePagedSmudgeHierarchy();
        }

        void ReplayPagedSmudgePage(CommandBuffer cmd, SplatBoxPageGpuState page, int atlasOffset)
        {
            if (!HasPagedSmudgeJournal) return;
            if (cmd == null)
            {
                using var immediate = new CommandBuffer { name = "Replay Smudged Page" };
                ReplayPagedSmudgePage(immediate, page, atlasOffset);
                Graphics.ExecuteCommandBuffer(immediate);
                return;
            }
            if (!EnsurePagedSmudgeBuffer(cmd)) return;
            // Detail slots are recycled between pages: never inherit the previous owner's edits.
            ClearPagedSmudgeRange(cmd, atlasOffset, page.splatCount);
            ReplayPagedSmudgeDabs(cmd, atlasOffset, page.splatCount);
        }

        void ReplayPagedSmudgeDabs(CommandBuffer cmd, int offset, int count)
        {
            // Test each dab against the displaced positions, not the original page bounds.
            foreach (var dab in EnumeratePagedSmudgeDabs()) DispatchPagedSmudge(cmd, offset, count, dab);
        }

        bool FindPagedSmudgeKernels()
        {
            if (m_CSBoxUtil == null) return false;
            m_PagedSmudgeApplyKernel = m_CSBoxUtil.HasKernel("CSApplyPagedSmudge") ? m_CSBoxUtil.FindKernel("CSApplyPagedSmudge") : -1;
            m_PagedSmudgeClearKernel = m_CSBoxUtil.HasKernel("CSClearPagedSmudge") ? m_CSBoxUtil.FindKernel("CSClearPagedSmudge") : -1;
            return m_PagedSmudgeApplyKernel >= 0 && m_PagedSmudgeClearKernel >= 0;
        }

        bool EnsurePagedSmudgeBuffer(CommandBuffer cmd)
        {
            if (!HasPagedSmudgeJournal || m_LodAtlasCapacity <= 0 || m_GpuLodUnifiedPos == null ||
                !EnsureLodFormatAsset() || !FindPagedSmudgeKernels()) return false;
            if (m_GpuPagedSmudgeOffsets != null && m_GpuPagedSmudgeOffsets.count == m_LodAtlasCapacity) return true;
            DisposePagedSmudgeBuffer();
            m_GpuPagedSmudgeOffsets = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_LodAtlasCapacity, sizeof(float) * 3)
                { name = "PagedSmudgeOffsets" };
            ClearPagedSmudgeRange(cmd, 0, m_LodAtlasCapacity);
            return true;
        }

        GraphicsBuffer GetPagedSmudgeEmptyBuffer()
        {
            if (m_GpuPagedSmudgeEmpty == null)
            {
                m_GpuPagedSmudgeEmpty = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(float) * 3)
                    { name = "PagedSmudgeEmpty" };
                m_GpuPagedSmudgeEmpty.SetData(new[] { Vector3.zero });
            }
            return m_GpuPagedSmudgeEmpty;
        }

        void BindPagedSmudgeOnKernel(int kernel)
        {
            if (m_CSBoxUtil == null || kernel < 0) return;
            if (!UsesPagedLod) EnsureMonolithicSculptState(null);
            bool valid = PagedSmudgeOffsetsValid || MonolithicSculptOffsetsValid;
            m_CSBoxUtil.SetBuffer(kernel, "_PagedSmudgeOffsets", valid ?
                (UsesPagedLod ? m_GpuPagedSmudgeOffsets : m_GpuMonolithicSculptOffsets) : GetPagedSmudgeEmptyBuffer());
            m_CSBoxUtil.SetInt("_PagedSmudgeValid", valid ? 1 : 0);
        }

        void BindPagedSmudgeOnCS(CommandBuffer cmd, int kernel)
        {
            EnsurePagedSmudgeState(cmd);
            EnsureMonolithicSculptState(cmd);
            bool valid = PagedSmudgeOffsetsValid || MonolithicSculptOffsetsValid;
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedSmudgeOffsets", valid ?
                (UsesPagedLod ? m_GpuPagedSmudgeOffsets : m_GpuMonolithicSculptOffsets) : GetPagedSmudgeEmptyBuffer());
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedSmudgeValid", valid ? 1 : 0);
        }

        void ClearPagedSmudgeRange(CommandBuffer cmd, int offset, int count)
        {
            DispatchPagedSmudgeRange(cmd, m_PagedSmudgeClearKernel, offset, count);
        }

        void DispatchPagedSmudge(CommandBuffer cmd, int offset, int count, in PagedSmudgeDab dab,
            GraphicsBuffer target = null, int writeBase = 0, GraphicsBuffer relaxBuffer = null)
        {
            int kernel = m_PagedSmudgeApplyKernel;
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, UsesPagedLod ? m_GpuLodUnifiedPos : m_GpuPosData);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatChunks, UsesPagedLod ? m_GpuLodUnifiedChunks ?? m_GpuChunks : m_GpuChunks);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, UsesPagedLod ?
                (m_GpuLodUnifiedChunks != null ? m_LodUnifiedChunkCount : 0) : (m_GpuChunksValid ? m_GpuChunks.count : 0));
            uint format = (uint)asset.posFormat | ((uint)asset.scaleFormat << 8) | ((uint)asset.shFormat << 16);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)format);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_SmudgeCenter", dab.center);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_SmudgeDelta", dab.delta);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeRadius", dab.radius);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeRadiusSq", dab.radius * dab.radius);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeFalloff", dab.falloff);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeStrength", dab.strength);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedSculptKind", dab.kind);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedSculptNormal", dab.normal);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_PagedRelaxNeighborRadius", dab.neighborRadius);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedRelaxInvert", dab.invert ? 1 : 0);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedRelaxGridSize", dab.relaxGridSize);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedRelaxCells", relaxBuffer ?? GetPagedRelaxBuffer(dab));
            DispatchPagedSmudgeRange(cmd, kernel, offset, count, target, writeBase,
                UsesPagedLod ? m_LodAtlasCapacity : m_SplatCount);
        }

        GraphicsBuffer GetPagedRelaxBuffer(in PagedSmudgeDab dab)
        {
            if (dab.kind == 4 && dab.relaxCells != null && dab.relaxCells.Length > 0)
            {
                if (!m_PagedRelaxBuffers.TryGetValue(dab.relaxCells, out var buffer))
                {
                    buffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, dab.relaxCells.Length, sizeof(float) * 4)
                        { name = "PagedRelaxNeighborhood" };
                    buffer.SetData(dab.relaxCells);
                    m_PagedRelaxBuffers.Add(dab.relaxCells, buffer);
                }
                return buffer;
            }
            if (m_GpuPagedRelaxEmpty == null)
            {
                m_GpuPagedRelaxEmpty = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(float) * 4)
                    { name = "PagedRelaxEmpty" };
                m_GpuPagedRelaxEmpty.SetData(new[] { Vector4.zero });
            }
            return m_GpuPagedRelaxEmpty;
        }

        void PrunePagedRelaxBuffers()
        {
            // Unity Undo deserializes new arrays. Retain only snapshots still referenced by the
            // active journal, before recording replay commands which will use their buffers.
            if (m_PagedRelaxBuffers.Count == 0) return;
            var active = new HashSet<Vector4[]>();
            foreach (var dab in EnumeratePagedSmudgeDabs())
                if (dab.relaxCells != null) active.Add(dab.relaxCells);
            if (HasMonolithicSculptJournal)
                foreach (var dab in m_MonolithicSculptDabs)
                    if (dab.relaxCells != null) active.Add(dab.relaxCells);
            var retired = new List<Vector4[]>();
            foreach (var pair in m_PagedRelaxBuffers)
                if (!active.Contains(pair.Key)) retired.Add(pair.Key);
            foreach (var cells in retired)
            {
                m_PagedRelaxBuffers[cells].Dispose();
                m_PagedRelaxBuffers.Remove(cells);
            }
        }

        void DispatchPagedSmudgeRange(CommandBuffer cmd, int kernel, int offset, int count,
            GraphicsBuffer target = null, int writeBase = 0, int sourceCapacity = -1)
        {
            int capacity = sourceCapacity >= 0 ? sourceCapacity : m_LodAtlasCapacity;
            if (offset < 0 || offset >= capacity || count <= 0) return;
            count = Mathf.Min(count, capacity - offset);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedSmudgeWrite", target ?? m_GpuPagedSmudgeOffsets);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedSculptWriteBase", writeBase);
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize == 0) return;
            int maximumDispatch = (int)groupSize * 65535;
            while (count > 0)
            {
                int batch = Mathf.Min(count, maximumDispatch);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedSmudgeOffset", offset);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedSmudgeCount", batch);
                cmd.DispatchCompute(m_CSBoxUtil, kernel, (batch + (int)groupSize - 1) / (int)groupSize, 1, 1);
                offset += batch;
                count -= batch;
            }
        }

        void DisposePagedSmudgeBuffer()
        {
            DisposeBuffer(ref m_GpuPagedSmudgeOffsets);
            DisposeBuffer(ref m_GpuPagedRelaxEmpty);
            foreach (var buffer in m_PagedRelaxBuffers.Values) buffer.Dispose();
            m_PagedRelaxBuffers.Clear();
            m_PagedSmudgeAppliedRevision = -1;
        }
    }
}
