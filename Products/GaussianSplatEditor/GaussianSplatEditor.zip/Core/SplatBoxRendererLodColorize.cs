// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [Serializable]
        internal struct PagedColorizeDab
        {
            public int sculptSnapshot; // Shared immutable sculpt state at paint time; 0 = source.
            // Keeping the transform at paint time makes edits follow the splat object
            // when it is subsequently moved, rotated, or scaled.
            public Matrix4x4 objectToWorld;
            public Vector3 center;
            public float radius;
            public Color color;
            public float strength, falloff, blendModeIntensity, noiseStrength, noiseScale;
            public int blendMode;
            // Zero size identifies the existing spherical Colorize entries.
            public Vector3 boxSize;
            public ColorAdjustments adjustments;
        }

        [Serializable]
        internal sealed class PagedColorizeStroke
        {
            public List<PagedColorizeDab> dabs = new List<PagedColorizeDab>();
        }

        [SerializeField, HideInInspector] GaussianSplatPagedScene m_PagedColorizeScene;
        [SerializeField, HideInInspector] List<PagedColorizeStroke> m_PagedColorizeStrokes = new List<PagedColorizeStroke>();
        [SerializeField, HideInInspector] int m_PagedColorizeCursor;
        [SerializeField, HideInInspector] int m_PagedColorizeUndoFloor;
        [SerializeField, HideInInspector] int m_PagedColorizeRevision;

        GraphicsBuffer m_GpuPagedColorOverrides;
        GraphicsBuffer m_GpuMonolithicColorOverrides;
        GraphicsBuffer m_GpuPagedColorEmpty;
        int m_PagedColorAppliedRevision = -1;
        ComputeShader m_PagedColorShader;
        int m_PagedColorApplyKernel = -1, m_PagedColorClearKernel = -1;
        bool m_PagedColorStrokeOpen;
        int m_PagedColorMaxUndoSteps = 20;
        PagedColorizeStroke m_PagedColorCurrentStroke;
#if UNITY_EDITOR
        int m_PagedColorUndoGroup = -1;
#endif

        bool HasPagedColorizeSource => UsesPagedLod && m_PagedColorizeScene == m_PagedScene;
        int PagedColorizeCursor => HasPagedColorizeSource && m_PagedColorizeStrokes != null
            ? Mathf.Clamp(m_PagedColorizeCursor, 0, m_PagedColorizeStrokes.Count) : 0;
        bool HasPagedColorizeJournal => PagedColorizeCursor > 0;
        bool PagedColorOverridesValid => HasPagedColorizeJournal && m_GpuPagedColorOverrides != null &&
            m_PagedColorAppliedRevision == m_PagedColorizeRevision;

        public int pagedColorizeStrokeCount => PagedColorizeCursor;
        public int pagedColorizeUndoCount => Mathf.Max(0, PagedColorizeCursor - m_PagedColorizeUndoFloor);
        public int pagedColorizeRedoCount => HasPagedColorizeSource && m_PagedColorizeStrokes != null
            ? m_PagedColorizeStrokes.Count - PagedColorizeCursor : 0;

        /// <summary>Groups all dabs until EndPagedColorizeStroke into one undoable gesture.</summary>
        public void BeginPagedColorizeStroke(int maxUndoSteps = 20)
        {
            if (!UsesPagedLod || m_PagedColorStrokeOpen)
                return;
            m_PagedColorStrokeOpen = true;
            m_PagedColorCurrentStroke = null;
            m_PagedColorMaxUndoSteps = Mathf.Max(1, maxUndoSteps);
            // Delay recording Unity Undo until the first actual dab. Empty gestures
            // must not discard redo, change the scene, or create an Undo entry.
        }

        public void EndPagedColorizeStroke()
        {
            m_PagedColorStrokeOpen = false;
            m_PagedColorCurrentStroke = null;
#if UNITY_EDITOR
            if (m_PagedColorUndoGroup >= 0)
            {
                UnityEditor.Undo.FlushUndoRecordObjects();
                UnityEditor.Undo.CollapseUndoOperations(m_PagedColorUndoGroup);
                m_PagedColorUndoGroup = -1;
            }
#endif
        }

        void RecordPagedColorizeUndo(string label, bool gesture = false)
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                if (gesture)
                {
                    UnityEditor.Undo.IncrementCurrentGroup();
                    m_PagedColorUndoGroup = UnityEditor.Undo.GetCurrentGroup();
                    UnityEditor.Undo.SetCurrentGroupName(label);
                }
                // Complete-object registration retains every dab across multiple frames,
                // unlike RecordObject's end-of-frame delta for only the first dab.
                UnityEditor.Undo.RegisterCompleteObjectUndo(this, label);
            }
#endif
        }

        public bool UndoPagedColorize()
        {
            EndPagedColorizeStroke();
            if (pagedColorizeUndoCount <= 0)
                return false;
            RecordPagedColorizeUndo("Undo Paged Colorize");
            m_PagedColorizeCursor = PagedColorizeCursor - 1;
            unchecked { m_PagedColorizeRevision++; }
            EnsurePagedColorizeState(null);
            MarkColorEditChanged();
            return true;
        }

        public bool RedoPagedColorize()
        {
            EndPagedColorizeStroke();
            if (pagedColorizeRedoCount <= 0)
                return false;
            RecordPagedColorizeUndo("Redo Paged Colorize");
            m_PagedColorizeCursor = PagedColorizeCursor + 1;
            unchecked { m_PagedColorizeRevision++; }
            EnsurePagedColorizeState(null);
            MarkColorEditChanged();
            return true;
        }

        /// <summary>Forgets undo boundaries without removing the visible color edits.</summary>
        public void ClearPagedColorizeUndoHistory()
        {
            EndPagedColorizeStroke();
            if (!HasPagedColorizeSource || (pagedColorizeUndoCount == 0 && pagedColorizeRedoCount == 0))
                return;
            RecordPagedColorizeUndo("Clear Paged Colorize History");
            int cursor = PagedColorizeCursor;
            if (m_PagedColorizeStrokes.Count > cursor)
                m_PagedColorizeStrokes.RemoveRange(cursor, m_PagedColorizeStrokes.Count - cursor);
            m_PagedColorizeUndoFloor = cursor;
            MarkColorEditChanged();
        }

        public void ResetPagedColorize()
        {
            EndPagedColorizeStroke();
            if ((m_PagedColorizeStrokes == null || m_PagedColorizeStrokes.Count == 0) && m_GpuPagedColorOverrides == null)
                return;
            RecordPagedColorizeUndo("Reset Paged Colorize");
            m_PagedColorizeStrokes?.Clear();
            ClearPagedEditSculptHistoryIfUnused();
            m_PagedColorizeScene = m_PagedScene;
            m_PagedColorizeCursor = m_PagedColorizeUndoFloor = 0;
            unchecked { m_PagedColorizeRevision++; }
            DisposePagedColorizeBuffer();
            MarkColorEditChanged();
        }

        bool ApplyPagedColorize(Vector3 center, float radius, Color color, float strength, float falloff,
            int blendMode, float blendModeIntensity, float noiseStrength, float noiseScale)
        {
            if (!UsesPagedLod || !PagedEraseFinite(center) || !PagedEraseFinite(radius) || radius <= 0f ||
                !PagedEraseFinite((Vector4)color) || !PagedEraseFinite(strength) || strength <= 0f ||
                !PagedEraseFinite(falloff) || !PagedEraseFinite(blendModeIntensity) ||
                !PagedEraseFinite(noiseStrength) || !PagedEraseFinite(noiseScale) || !FindPagedColorizeKernels())
                return false;

            var dab = new PagedColorizeDab
            {
                objectToWorld = transform.localToWorldMatrix, center = center, radius = radius,
                color = color, strength = Mathf.Clamp01(strength), falloff = Mathf.Clamp01(falloff),
                blendMode = Mathf.Clamp(blendMode, 0, 9), blendModeIntensity = Mathf.Clamp01(blendModeIntensity),
                noiseStrength = Mathf.Clamp01(noiseStrength), noiseScale = Mathf.Max(0.0001f, noiseScale)
            };
            return ApplyPagedColorizeDab(dab, "Colorize Paged Splats");
        }

        bool ApplyPagedColorizeDab(PagedColorizeDab dab, string undoLabel)
        {
            for (int i = 0; i < 16; i++)
                if (!PagedEraseFinite(dab.objectToWorld[i]))
                    return false;

            bool standalone = !m_PagedColorStrokeOpen;
            if (standalone)
                BeginPagedColorizeStroke();
            using var cmd = new CommandBuffer { name = undoLabel };
            // Reconstruct an undone/reloaded baseline once, before appending. Normal
            // brushing dispatches only the new dab against intersecting resident pages.
            EnsurePagedColorizeState(cmd);
            if (m_PagedColorCurrentStroke == null || !HasPagedColorizeSource)
            {
                RecordPagedColorizeUndo(undoLabel, true);
                if (!HasPagedColorizeSource)
                {
                    m_PagedColorizeScene = m_PagedScene;
                    m_PagedColorizeStrokes = new List<PagedColorizeStroke>();
                    m_PagedColorizeCursor = m_PagedColorizeUndoFloor = 0;
                }
                m_PagedColorizeStrokes ??= new List<PagedColorizeStroke>();
                int cursor = PagedColorizeCursor;
                if (m_PagedColorizeStrokes.Count > cursor)
                    m_PagedColorizeStrokes.RemoveRange(cursor, m_PagedColorizeStrokes.Count - cursor);
                m_PagedColorCurrentStroke = new PagedColorizeStroke();
                m_PagedColorizeStrokes.Add(m_PagedColorCurrentStroke);
                m_PagedColorizeCursor = cursor + 1;
                m_PagedColorizeUndoFloor = Mathf.Max(m_PagedColorizeUndoFloor,
                    m_PagedColorizeCursor - m_PagedColorMaxUndoSteps);
            }
            dab.sculptSnapshot = CapturePagedEditSculptSnapshot();
            m_PagedColorCurrentStroke.dabs.Add(dab);
            unchecked { m_PagedColorizeRevision++; }
            if (EnsurePagedColorizeBuffer(cmd))
            {
                var pages = m_LodStreamer?.loadedPages;
                if (pages != null)
                    for (int i = 0; i < pages.Count; i++)
                    {
                        var page = pages[i];
                        if (HasUploadedPagedEraseRange(page) && PagedColorizeIntersectsPage(dab,
                            ExpandPagedEditSculptBounds(page.bounds, dab.sculptSnapshot)))
                            DispatchPagedColorize(cmd, page.atlasOffset, page.splatCount, dab);
                    }
                m_PagedColorAppliedRevision = m_PagedColorizeRevision;
            }
            Graphics.ExecuteCommandBuffer(cmd);
            MarkColorEditChanged();
            if (standalone)
                EndPagedColorizeStroke();
            return true;
        }

        void MarkColorEditChanged()
        {
            editModified = true;
            m_FrameCounter = 0;
            InvalidatePagedLodEraseView();
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                if (UsesPagedLod)
                    MarkPagedLodEraseDirty();
                UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
            }
#endif
        }

        /// <summary>Replays only after Undo, scene reload, or atlas allocation changes.</summary>
        void EnsurePagedColorizeState(CommandBuffer cmd)
        {
            if (!HasPagedColorizeJournal)
            {
                if (m_GpuPagedColorOverrides != null)
                {
                    DisposePagedColorizeBuffer();
                    InvalidatePagedLodEraseView();
                }
                return;
            }
            if (m_GpuPagedColorOverrides != null && m_GpuPagedColorOverrides.count == m_LodAtlasCapacity &&
                m_PagedColorAppliedRevision == m_PagedColorizeRevision)
                return;
            if (cmd == null)
            {
                using var immediate = new CommandBuffer { name = "Replay Paged Colorize" };
                EnsurePagedColorizeState(immediate);
                Graphics.ExecuteCommandBuffer(immediate);
                return;
            }
            if (!EnsurePagedColorizeBuffer(cmd))
                return;
            ClearPagedColorizeRange(cmd, 0, m_LodAtlasCapacity);
            var pages = m_LodStreamer?.loadedPages;
            if (pages != null)
                for (int i = 0; i < pages.Count; i++)
                {
                    var page = pages[i];
                    if (HasUploadedPagedEraseRange(page))
                        ReplayPagedColorizeDabs(cmd, page.atlasOffset, page.splatCount, page.bounds);
                }
            m_PagedColorAppliedRevision = m_PagedColorizeRevision;
            InvalidatePagedLodEraseView();
        }

        void ReplayPagedColorizePage(CommandBuffer cmd, SplatBoxPageGpuState page, int atlasOffset)
        {
            ReplayPagedColorizeRange(cmd, atlasOffset, page.splatCount, page.bounds);
        }

        void ReplayPagedColorizeRange(CommandBuffer cmd, int atlasOffset, int count, Bounds localBounds)
        {
            if (!HasPagedColorizeJournal)
                return;
            if (cmd == null)
            {
                using var immediate = new CommandBuffer { name = "Replay Paged Page Colors" };
                ReplayPagedColorizeRange(immediate, atlasOffset, count, localBounds);
                Graphics.ExecuteCommandBuffer(immediate);
                return;
            }
            if (!EnsurePagedColorizeBuffer(cmd))
                return;
            // Atlas addresses are recycled, so remove the previous page's overrides first.
            ClearPagedColorizeRange(cmd, atlasOffset, count);
            ReplayPagedColorizeDabs(cmd, atlasOffset, count, localBounds);
            InvalidatePagedLodEraseView();
        }

        void ReplayPagedColorizeDabs(CommandBuffer cmd, int offset, int count, Bounds localBounds)
        {
            for (int s = 0; s < PagedColorizeCursor; s++)
            {
                var dabs = m_PagedColorizeStrokes[s]?.dabs;
                if (dabs == null)
                    continue;
                for (int d = 0; d < dabs.Count; d++)
                    if (PagedColorizeIntersectsPage(dabs[d], ExpandPagedEditSculptBounds(localBounds, dabs[d].sculptSnapshot)))
                        DispatchPagedColorize(cmd, offset, count, dabs[d]);
            }
        }

        static bool PagedColorizeIntersectsPage(in PagedColorizeDab dab, Bounds bounds)
        {
            var matrix = dab.objectToWorld;
            Vector3 e = bounds.extents;
            Vector3 worldExtents = new Vector3(
                Mathf.Abs(matrix.m00) * e.x + Mathf.Abs(matrix.m01) * e.y + Mathf.Abs(matrix.m02) * e.z,
                Mathf.Abs(matrix.m10) * e.x + Mathf.Abs(matrix.m11) * e.y + Mathf.Abs(matrix.m12) * e.z,
                Mathf.Abs(matrix.m20) * e.x + Mathf.Abs(matrix.m21) * e.y + Mathf.Abs(matrix.m22) * e.z);
            var worldBounds = new Bounds(matrix.MultiplyPoint3x4(bounds.center), worldExtents * 2f);
            if (dab.boxSize.x > 0)
                return worldBounds.Intersects(new Bounds(dab.center, dab.boxSize));
            return (worldBounds.ClosestPoint(dab.center) - dab.center).sqrMagnitude <= dab.radius * dab.radius + 1e-6f;
        }

        bool FindPagedColorizeKernels()
        {
            if (m_CSBoxUtil == null)
                return false;
            // Editor reimport can reorder kernels on this same shader object.
#if !UNITY_EDITOR
            if (m_PagedColorShader != m_CSBoxUtil)
#endif
            {
                m_PagedColorShader = m_CSBoxUtil;
                m_PagedColorApplyKernel = m_CSBoxUtil.HasKernel("CSApplyPagedColor")
                    ? m_CSBoxUtil.FindKernel("CSApplyPagedColor") : -1;
                m_PagedColorClearKernel = m_CSBoxUtil.HasKernel("CSClearPagedColor")
                    ? m_CSBoxUtil.FindKernel("CSClearPagedColor") : -1;
            }
            return m_PagedColorApplyKernel >= 0 && m_PagedColorClearKernel >= 0;
        }

        bool EnsurePagedColorizeBuffer(CommandBuffer cmd)
        {
            if (!HasPagedColorizeJournal || m_LodAtlasCapacity <= 0 || m_GpuLodUnifiedPos == null ||
                m_GpuLodUnifiedOther == null || m_GpuLodUnifiedColor == null ||
                !EnsureLodFormatAsset() || !FindPagedColorizeKernels())
                return false;
            if (m_GpuPagedColorOverrides != null && m_GpuPagedColorOverrides.count == m_LodAtlasCapacity)
                return true;
            DisposePagedColorizeBuffer();
            m_GpuPagedColorOverrides = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_LodAtlasCapacity, sizeof(float) * 4)
                { name = "PagedSplatColorOverrides" };
            ClearPagedColorizeRange(cmd, 0, m_LodAtlasCapacity);
            return true;
        }

        GraphicsBuffer GetPagedColorizeEmptyBuffer()
        {
            if (m_GpuPagedColorEmpty == null)
            {
                m_GpuPagedColorEmpty = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(float) * 4)
                    { name = "PagedSplatColorEmpty" };
                m_GpuPagedColorEmpty.SetData(new[] { Vector4.zero });
            }
            return m_GpuPagedColorEmpty;
        }

        // Direct kernel users also need a valid descriptor, even on monolithic renderers.
        // The common command-buffer binding below overrides this with replayed state.
        void BindPagedColorizeOnKernel(int kernel)
        {
            if (m_CSBoxUtil == null || kernel < 0)
                return;
            var overrides = GetColorOverrides();
            m_CSBoxUtil.SetBuffer(kernel, "_PagedColorOverrides", overrides ?? GetPagedColorizeEmptyBuffer());
            m_CSBoxUtil.SetInt("_PagedColorOverridesValid", overrides != null ? 1 : 0);
        }

        void BindPagedColorizeOnCS(CommandBuffer cmd, int kernel)
        {
            EnsurePagedColorizeState(cmd);
            var overrides = GetColorOverrides();
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedColorOverrides",
                overrides ?? GetPagedColorizeEmptyBuffer());
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedColorOverridesValid", overrides != null ? 1 : 0);
        }

        GraphicsBuffer GetColorOverrides() => UsesPagedLod
            ? (PagedColorOverridesValid ? m_GpuPagedColorOverrides : null)
            : m_GpuMonolithicColorOverrides;

        void ClearPagedColorizeRange(CommandBuffer cmd, int offset, int count)
        {
            ClearColorOverrideRange(cmd, m_GpuPagedColorOverrides, offset, count);
        }

        void ClearColorOverrideRange(CommandBuffer cmd, GraphicsBuffer buffer, int offset, int count)
        {
            if (offset < 0 || count <= 0 || offset >= buffer.count)
                return;
            count = Mathf.Min(count, buffer.count - offset);
            cmd.SetComputeBufferParam(m_CSBoxUtil, m_PagedColorClearKernel, "_PagedColorWrite", buffer);
            m_CSBoxUtil.GetKernelThreadGroupSizes(m_PagedColorClearKernel, out uint groupSize, out _, out _);
            if (groupSize == 0)
                return;
            // A complete hierarchy atlas can exceed the per-dimension dispatch limit.
            int maximumDispatch = (int)groupSize * 65535;
            while (count > 0)
            {
                int batchCount = Mathf.Min(count, maximumDispatch);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedColorOffset", offset);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedColorCount", batchCount);
                cmd.DispatchCompute(m_CSBoxUtil, m_PagedColorClearKernel,
                    (int)(((uint)batchCount + groupSize - 1) / groupSize), 1, 1);
                offset += batchCount;
                count -= batchCount;
            }
        }

        void DispatchPagedColorize(CommandBuffer cmd, int offset, int count, in PagedColorizeDab dab)
        {
            if (offset < 0 || count <= 0 || offset >= m_LodAtlasCapacity)
                return;
            count = Mathf.Min(count, m_LodAtlasCapacity - offset);
            DispatchColorOverride(cmd, m_GpuPagedColorOverrides, offset, count, dab);
        }

        void DispatchColorOverride(CommandBuffer cmd, GraphicsBuffer destination, int offset, int count, in PagedColorizeDab dab)
        {
            bool paged = UsesPagedLod;
            int kernel = m_PagedColorApplyKernel;
            if (!BindPagedEditSculptSnapshot(cmd, kernel, dab.sculptSnapshot, offset, count)) return;
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedColorWrite", destination);
            // An RW buffer cannot simultaneously be its own read-only SRV on all backends.
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedColorOverrides", GetPagedColorizeEmptyBuffer());
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedColorOverridesValid", 0);
            // The edit uses its captured positions through the dedicated snapshot binding.
            // Disable the live displacement here so later sculpting cannot change membership.
            if (paged)
            {
                cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedSmudgeOffsets", GetPagedSmudgeEmptyBuffer());
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedSmudgeValid", 0);
            }
            else
            {
                BindPagedSmudgeOnCS(cmd, kernel);
            }
            var positions = paged ? m_GpuLodUnifiedPos : m_GpuPosData;
            var other = paged ? m_GpuLodUnifiedOther : m_GpuOtherData;
            var chunks = paged ? m_GpuLodUnifiedChunks : (m_GpuChunksValid ? m_GpuChunks : null);
            var formatAsset = paged ? m_LodFormatAsset : asset;
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, positions);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatOther, other);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatSH, (paged ? m_GpuLodUnifiedSh : m_GpuSHData) ?? other);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatSHDataValid, 0);
            cmd.SetComputeTextureParam(m_CSBoxUtil, kernel, Props.SplatColor, paged ? m_GpuLodUnifiedColor : m_GpuColorData);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatChunks, chunks ?? m_GpuChunks);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, chunks == null ? 0 : paged ? m_LodUnifiedChunkCount : chunks.count);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.UseSplatIndexRemap, 0);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatIndexRemap,
                (paged ? m_GpuLodAtlasIndices : null) ?? m_GpuSortKeys);
            uint format = (uint)formatAsset.posFormat | ((uint)formatAsset.scaleFormat << 8) |
                ((uint)formatAsset.shFormat << 16);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)format);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, destination.count);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedColorOffset", offset);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedColorCount", count);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_PagedColorObjectToWorld", dab.objectToWorld);
            SetBoxColorAdjustmentParams(cmd, dab.center, dab.boxSize, dab.adjustments);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_ColorizeSphereCenter", dab.center);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_ColorizeSphereRadius", dab.radius);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_ColorizeTargetColor", (Vector4)dab.color);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_ColorizeBlendStrength", dab.strength);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_ColorizeFalloff", dab.falloff);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_ColorizeBlendMode", dab.blendMode);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_ColorizeBlendModeIntensity", dab.blendModeIntensity);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_ColorizeNoiseStrength", dab.noiseStrength);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_ColorizeNoiseScale", dab.noiseScale);
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize > 0)
                cmd.DispatchCompute(m_CSBoxUtil, kernel, (int)(((uint)count + groupSize - 1) / groupSize), 1, 1);
        }

        void DisposePagedColorizeBuffer()
        {
            DisposeBuffer(ref m_GpuPagedColorOverrides);
            m_PagedColorAppliedRevision = -1;
        }
    }
}
