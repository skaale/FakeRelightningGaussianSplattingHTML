// SPDX-License-Identifier: MIT
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [SerializeField, HideInInspector] GaussianSplatAsset m_MonolithicSculptSource;
        [SerializeField, HideInInspector] Hash128 m_MonolithicSculptSourceHash;
        [SerializeField, HideInInspector] List<PagedSmudgeDab> m_MonolithicSculptDabs = new();
        [SerializeField, HideInInspector] int m_MonolithicSculptRevision;
        GraphicsBuffer m_GpuMonolithicSculptOffsets, m_GpuSculptRelaxCapture;
        int m_MonolithicSculptAppliedRevision = -1;
        bool m_MonolithicSculptStrokeOpen, m_MonolithicSculptStrokeRecorded;
#if UNITY_EDITOR
        int m_MonolithicSculptUndoGroup = -1;
#endif
        public bool SupportsSculpt => HasValidAsset;
        public bool UsesSculptJournal => UsesPagedLod || UsesMonolithicSculpt;
        public bool HasSculptEdits => UsesPagedLod ? HasPagedSmudgeJournal : HasMonolithicSculptJournal;
        bool UsesMonolithicSculpt => !UsesPagedLod && HasValidAsset && !SupportsInPlacePaint;
        bool HasMonolithicSculptJournal => UsesMonolithicSculpt && m_MonolithicSculptSource == asset &&
            m_MonolithicSculptSourceHash == asset.dataHash && m_MonolithicSculptDabs != null && m_MonolithicSculptDabs.Count > 0;
        bool MonolithicSculptOffsetsValid => HasMonolithicSculptJournal && m_GpuMonolithicSculptOffsets != null &&
            m_GpuMonolithicSculptOffsets.count == m_SplatCount && m_MonolithicSculptAppliedRevision == m_MonolithicSculptRevision;

        public void BeginSculptStroke()
        {
            if (UsesPagedLod) { BeginPagedSculptStroke(); return; }
            if (!UsesMonolithicSculpt || m_MonolithicSculptStrokeOpen) return;
            m_MonolithicSculptStrokeOpen = true;
            m_MonolithicSculptStrokeRecorded = false;
        }

        public void EndSculptStroke()
        {
            EndPagedSculptStroke();
            m_MonolithicSculptStrokeOpen = m_MonolithicSculptStrokeRecorded = false;
#if UNITY_EDITOR
            if (m_MonolithicSculptUndoGroup >= 0)
            {
                UnityEditor.Undo.FlushUndoRecordObjects();
                UnityEditor.Undo.CollapseUndoOperations(m_MonolithicSculptUndoGroup);
                m_MonolithicSculptUndoGroup = -1;
            }
#endif
        }

        void RecordMonolithicSculptUndo(string label)
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                UnityEditor.Undo.IncrementCurrentGroup();
                m_MonolithicSculptUndoGroup = UnityEditor.Undo.GetCurrentGroup();
                UnityEditor.Undo.SetCurrentGroupName(label);
                UnityEditor.Undo.RegisterCompleteObjectUndo(this, label);
            }
#endif
        }

        public void ResetSculpt()
        {
            if (UsesPagedLod) { ResetPagedSculpt(); return; }
            EndSculptStroke();
            if (!HasMonolithicSculptJournal) return;
            RecordMonolithicSculptUndo("Reset All Sculpting");
            m_MonolithicSculptDabs.Clear();
            unchecked { m_MonolithicSculptRevision++; }
            EnsureMonolithicSculptState(null);
            MarkMonolithicSculptChanged();
            EndSculptStroke();
        }

        bool ApplyMonolithicSculptDab(PagedSmudgeDab dab)
        {
            if (!UsesMonolithicSculpt || !HasValidRenderSetup || !PagedEraseFinite(dab.center) ||
                !PagedEraseFinite(dab.radius) || dab.radius <= 0 || !PagedEraseFinite(dab.radius * dab.radius) ||
                !PagedEraseFinite(dab.falloff) || !PagedEraseFinite(dab.strength) || dab.strength == 0 ||
                (dab.strength < 0 && dab.kind != 1) || !FindPagedSmudgeKernels()) return false;
            dab.falloff = Mathf.Clamp01(dab.falloff);
            if (dab.kind == 0 && (!PagedEraseFinite(dab.delta) || !PagedEraseFinite(dab.delta.sqrMagnitude) || dab.delta.sqrMagnitude <= 0))
                return false;
            if (dab.kind == 2)
            {
                if (!PagedEraseFinite(dab.normal) || !PagedEraseFinite(dab.normal.sqrMagnitude) || dab.normal.sqrMagnitude < 1e-12f) return false;
                dab.normal.Normalize();
            }
            if (dab.kind == 3)
            {
                if (!HasMonolithicSculptJournal) return false;
                dab.strength = Mathf.Clamp01(dab.strength);
            }
            GetPagedSculptDisplacementBounds(dab, out var minimum, out var maximum);
            if (!PagedEraseFinite(minimum) || !PagedEraseFinite(maximum)) return false;
            EnsureMonolithicSculptState(null);
            if (dab.kind == 4 && !CaptureMonolithicRelaxField(ref dab)) return false;
            bool standalone = !m_MonolithicSculptStrokeOpen;
            if (standalone) BeginSculptStroke();
            string label = dab.kind == 1 ? "Pinch Splats" : dab.kind == 2 ? "Flatten Splats" :
                dab.kind == 3 ? "Restore Sculpting" : dab.kind == 4 ? (dab.invert ? "Roughen Splats" : "Relax Splats") : "Move Splats";
            if (!m_MonolithicSculptStrokeRecorded)
            {
                RecordMonolithicSculptUndo(label);
                m_MonolithicSculptStrokeRecorded = true;
            }
            if (m_MonolithicSculptSource != asset || m_MonolithicSculptSourceHash != asset.dataHash)
            {
                m_MonolithicSculptSource = asset;
                m_MonolithicSculptSourceHash = asset.dataHash;
                m_MonolithicSculptDabs = new List<PagedSmudgeDab>();
            }
            m_MonolithicSculptDabs ??= new List<PagedSmudgeDab>();
            m_MonolithicSculptDabs.Add(dab);
            unchecked { m_MonolithicSculptRevision++; }
            using var cmd = new CommandBuffer { name = label };
            EnsureMonolithicSculptBuffer(cmd);
            DispatchPagedSmudge(cmd, 0, m_SplatCount, dab, m_GpuMonolithicSculptOffsets);
            m_MonolithicSculptAppliedRevision = m_MonolithicSculptRevision;
            Graphics.ExecuteCommandBuffer(cmd);
            MarkMonolithicSculptChanged();
            if (standalone) EndSculptStroke();
            return true;
        }

        void MarkMonolithicSculptChanged()
        {
            editModified = true;
            m_HasSortOrderCamera = false;
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                UnityEditor.EditorUtility.SetDirty(this);
                if (gameObject.scene.IsValid() && gameObject.scene.isLoaded)
                    UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(gameObject.scene);
                UnityEditor.PrefabUtility.RecordPrefabInstancePropertyModifications(this);
                UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
                UnityEditor.SceneView.RepaintAll();
            }
#endif
        }

        void EnsureMonolithicSculptBuffer(CommandBuffer cmd)
        {
            if (m_GpuMonolithicSculptOffsets != null && m_GpuMonolithicSculptOffsets.count == m_SplatCount) return;
            DisposeBuffer(ref m_GpuMonolithicSculptOffsets);
            m_GpuMonolithicSculptOffsets = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12)
                { name = "MonolithicSculptOffsets" };
            DispatchPagedSmudgeRange(cmd, m_PagedSmudgeClearKernel, 0, m_SplatCount, m_GpuMonolithicSculptOffsets,
                sourceCapacity: m_SplatCount);
        }

        void EnsureMonolithicSculptState(CommandBuffer cmd)
        {
            if (!HasMonolithicSculptJournal)
            {
                bool hadState = m_GpuMonolithicSculptOffsets != null || m_MonolithicSculptAppliedRevision >= 0;
                DisposeBuffer(ref m_GpuMonolithicSculptOffsets);
                m_MonolithicSculptAppliedRevision = -1;
                if (hadState) PrunePagedRelaxBuffers();
                return;
            }
            if (MonolithicSculptOffsetsValid || !HasValidRenderSetup || !FindPagedSmudgeKernels()) return;
            if (cmd == null)
            {
                using var replay = new CommandBuffer { name = "Restore Monolithic Sculpting" };
                EnsureMonolithicSculptState(replay);
                Graphics.ExecuteCommandBuffer(replay);
                return;
            }
            PrunePagedRelaxBuffers();
            EnsureMonolithicSculptBuffer(cmd);
            DispatchPagedSmudgeRange(cmd, m_PagedSmudgeClearKernel, 0, m_SplatCount, m_GpuMonolithicSculptOffsets,
                sourceCapacity: m_SplatCount);
            foreach (var dab in m_MonolithicSculptDabs)
                DispatchPagedSmudge(cmd, 0, m_SplatCount, dab, m_GpuMonolithicSculptOffsets);
            m_MonolithicSculptAppliedRevision = m_MonolithicSculptRevision;
            m_HasSortOrderCamera = false;
        }

        bool CaptureMonolithicRelaxField(ref PagedSmudgeDab dab)
        {
            if (!PagedEraseFinite(dab.neighborRadius) || dab.neighborRadius <= 0 ||
                !m_CSBoxUtil.HasKernel("CSCaptureSculptRelax")) return false;
            dab.neighborRadius = Mathf.Clamp(dab.neighborRadius, .1f, 1f);
            dab.relaxGridSize = Mathf.Clamp(Mathf.CeilToInt(2 / dab.neighborRadius), 1, 20);
            int cells = dab.relaxGridSize * dab.relaxGridSize * dab.relaxGridSize;
            if (m_GpuSculptRelaxCapture == null || m_GpuSculptRelaxCapture.count != cells)
            {
                DisposeBuffer(ref m_GpuSculptRelaxCapture);
                m_GpuSculptRelaxCapture = new GraphicsBuffer(GraphicsBuffer.Target.Structured, cells, 16)
                    { name = "SculptRelaxNeighborhood" };
            }
            var sums = new int[cells * 4];
            m_GpuSculptRelaxCapture.SetData(sums);
            int kernel = m_CSBoxUtil.FindKernel("CSCaptureSculptRelax");
            // Bound each accumulated coordinate by INT_MAX even if every splat lands in one cell.
            int quantization = (int)System.Math.Min(65536L, int.MaxValue / (long)System.Math.Max(1, m_SplatCount));
            using (var cmd = new CommandBuffer { name = "Capture Sculpt Neighborhood" })
            {
                EnsureMonolithicSculptBuffer(cmd);
                cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_SplatPos", m_GpuPosData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_SplatChunks", m_GpuChunks);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_SplatChunkCount", m_GpuChunksValid ? m_GpuChunks.count : 0);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_SplatFormat", (int)asset.posFormat);
                cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_SculptRelaxCapture", m_GpuSculptRelaxCapture);
                cmd.SetComputeFloatParam(m_CSBoxUtil, "_SculptRelaxQuantization", quantization);
                cmd.SetComputeVectorParam(m_CSBoxUtil, "_SmudgeCenter", dab.center);
                cmd.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeRadius", dab.radius);
                cmd.SetComputeFloatParam(m_CSBoxUtil, "_PagedRelaxNeighborRadius", dab.neighborRadius);
                cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedRelaxGridSize", dab.relaxGridSize);
                DispatchPagedSmudgeRange(cmd, kernel, 0, m_SplatCount, m_GpuMonolithicSculptOffsets,
                    sourceCapacity: m_SplatCount);
                Graphics.ExecuteCommandBuffer(cmd);
            }
            // Only the small grid comes back to the CPU; never read millions of positions per dab.
            m_GpuSculptRelaxCapture.GetData(sums);
            dab.relaxCells = new Vector4[cells];
            bool any = false;
            for (int i = 0; i < cells; i++)
            {
                int count = sums[i * 4 + 3];
                if (count == 0) continue;
                double scale = dab.radius / ((double)count * quantization);
                dab.relaxCells[i] = new Vector4(dab.center.x + (float)(sums[i * 4] * scale),
                    dab.center.y + (float)(sums[i * 4 + 1] * scale), dab.center.z + (float)(sums[i * 4 + 2] * scale), count);
                any = true;
            }
            return any;
        }

        void DisposeMonolithicSculptBuffers()
        {
            DisposeBuffer(ref m_GpuMonolithicSculptOffsets);
            DisposeBuffer(ref m_GpuSculptRelaxCapture);
            m_MonolithicSculptAppliedRevision = -1;
        }
    }
}
