// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        sealed class PagedSmudgeTreeState
        {
            public LodTreeRuntime original, published;
            public Vector3[] originalPositions;
            public Bounds originalBounds;
            public int epoch = -1, dabCount;
        }

        readonly Dictionary<SplatBoxPageGpuState, PagedSmudgeTreeState> m_PagedSmudgeTrees =
            new Dictionary<SplatBoxPageGpuState, PagedSmudgeTreeState>();
        readonly List<SplatBoxPageGpuState> m_PagedSmudgeDisposedPages = new List<SplatBoxPageGpuState>();
        List<PagedSmudgeDab> m_PagedSmudgeHierarchyDabs = new List<PagedSmudgeDab>();
        GaussianSplatPagedScene m_PagedSmudgeHierarchyScene;
        int m_PagedSmudgeHierarchyRevision = -1, m_PagedSmudgeHierarchyEpoch;
        bool m_PagedSmudgeHierarchyDirty = true;
        Vector3 m_PagedSmudgeDisplacementMin, m_PagedSmudgeDisplacementMax;

        void InvalidatePagedSmudgeHierarchy()
        {
            m_PagedSmudgeHierarchyDirty = true;
            InvalidateLodAsyncSelection();
            m_LodSelectionInvalid = true;
            m_LodSelectionDirty = true;
            ForceResort();
            InvalidatePagedLodEraseView();
        }

        // Call before streaming and before capturing traversal contexts. A page can return from
        // the parked coarse set, or have its prefix replaced, without a journal revision change.
        void EnsurePagedSmudgeHierarchy()
        {
            RestorePagedAttractorHierarchyBase();
            RefreshPagedSmudgeHierarchyJournal();
            m_LodStreamer?.SetSculptDisplacementBounds(m_PagedSmudgeDisplacementMin,
                m_PagedSmudgeDisplacementMax);
            if (m_PagedSmudgeHierarchyDabs.Count == 0)
            {
                // Ordinary unsculpted renderers pay no per-page bookkeeping cost. Reset also
                // restores parked coarse trees now, so they cannot return with old deformations.
                bool restored = RestorePagedSmudgeOriginalTrees();
                if (restored)
                {
                    InvalidateLodAsyncSelection();
                    m_LodSelectionInvalid = m_LodSelectionDirty = true;
                    ForceResort();
                }
                EnsurePagedAttractorHierarchy();
                return;
            }
            var pages = m_LodStreamer?.loadedPages;
            if (pages == null)
                return;

            bool changed = false;
            for (int i = 0; i < pages.Count; i++)
            {
                var page = pages[i];
                if (page?.lodTree?.nodes == null)
                    continue;
                if (!m_PagedSmudgeTrees.TryGetValue(page, out var state) ||
                    !ReferenceEquals(page.lodTree, state.published))
                {
                    // Prefix resizing constructs a fresh source tree. Treat it as a new baseline,
                    // while a parked tree still points at its published snapshot and resumes it.
                    state = new PagedSmudgeTreeState
                    {
                        original = page.lodTree,
                        published = page.lodTree,
                        originalBounds = page.source != null ? page.source.bounds :
                            state != null ? state.originalBounds : page.bounds
                    };
                    m_PagedSmudgeTrees[page] = state;
                }
                page.bounds = ExpandPagedSmudgeBoundsUnchecked(state.originalBounds);
                if (state.epoch == m_PagedSmudgeHierarchyEpoch &&
                    state.dabCount == m_PagedSmudgeHierarchyDabs.Count)
                    continue;

                bool restart = state.epoch != m_PagedSmudgeHierarchyEpoch;
                var previous = page.lodTree;
                var basis = restart ? state.original : state.published;
                int firstDab = restart ? 0 : state.dabCount;
                var dabs = new List<PagedSmudgeDab>();
                for (int d = firstDab; d < m_PagedSmudgeHierarchyDabs.Count; d++)
                {
                    var dab = m_PagedSmudgeHierarchyDabs[d];
                    // Expanded bounds include every preceding displacement. Filtering against the
                    // original page alone would miss a second brush touching already-moved content.
                    if (page.bounds.SqrDistance(dab.center) <= dab.radius * dab.radius + 1e-6f)
                        dabs.Add(dab);
                }

                if (dabs.Count != 0)
                {
                    var nodes = (LodTreeNode[])basis.nodes.Clone();
                    state.originalPositions ??= ReadPagedSculptOriginalPositions(page, state.original);
                    bool originalBasis = ReferenceEquals(basis, state.original);
                    for (int n = 0; n < nodes.Length; n++)
                    {
                        Vector3 original = state.originalPositions[n];
                        Vector3 position = originalBasis ? original : (Vector3)nodes[n].center;
                        for (int d = 0; d < dabs.Count; d++)
                            position = ApplyPagedSculptPoint(position, original, dabs[d]);
                        nodes[n].center = position;
                    }
                    RefitPagedSmudgeTree(nodes, state.original, page.isCoarseStub);
                    // Child tables never change and can be shared. Node arrays must be replaced:
                    // an asynchronous/Burst selection may still be reading the previous snapshot.
                    state.published = new LodTreeRuntime
                    {
                        nodes = nodes,
                        childTable = basis.childTable,
                        childTableStart = basis.childTableStart,
                        leafCount = basis.leafCount,
                        rootExtent = nodes[0].featureSize,
                        levelOrder = basis.levelOrder
                    };
                }
                else
                    state.published = basis;
                page.lodTree = state.published;
                state.dabCount = m_PagedSmudgeHierarchyDabs.Count;
                state.epoch = m_PagedSmudgeHierarchyEpoch;
                changed |= !ReferenceEquals(previous, page.lodTree);
            }

            // Parked coarse trees retain their baseline; disposed full-detail pages must not
            // accumulate CPU tree copies over a long navigation/editing session.
            m_PagedSmudgeDisposedPages.Clear();
            foreach (var entry in m_PagedSmudgeTrees)
                if (entry.Key.lodTree == null)
                    m_PagedSmudgeDisposedPages.Add(entry.Key);
            for (int i = 0; i < m_PagedSmudgeDisposedPages.Count; i++)
                m_PagedSmudgeTrees.Remove(m_PagedSmudgeDisposedPages[i]);
            if (changed)
            {
                InvalidateLodAsyncSelection();
                m_LodSelectionInvalid = true;
                m_LodSelectionDirty = true;
                ForceResort();
            }
            EnsurePagedAttractorHierarchy();
        }

        void RefreshPagedSmudgeHierarchyJournal()
        {
            if (!m_PagedSmudgeHierarchyDirty && m_PagedSmudgeHierarchyScene == m_PagedScene &&
                m_PagedSmudgeHierarchyRevision == m_PagedSmudgeRevision &&
                (m_PagedSmudgeHierarchyDabs.Count > 0) == HasPagedSmudgeJournal)
                return;

            var dabs = new List<PagedSmudgeDab>();
            if (HasPagedSmudgeJournal)
                dabs.AddRange(EnumeratePagedSmudgeDabs());
            bool append = m_PagedSmudgeHierarchyScene == m_PagedScene &&
                dabs.Count >= m_PagedSmudgeHierarchyDabs.Count;
            for (int i = 0; append && i < m_PagedSmudgeHierarchyDabs.Count; i++)
            {
                var before = m_PagedSmudgeHierarchyDabs[i];
                var after = dabs[i];
                append = before.center.Equals(after.center) && before.delta.Equals(after.delta) &&
                    before.radius == after.radius && before.falloff == after.falloff &&
                    before.strength == after.strength && before.kind == after.kind &&
                    before.normal.Equals(after.normal) && before.neighborRadius == after.neighborRadius &&
                    before.invert == after.invert && before.relaxGridSize == after.relaxGridSize &&
                    ReferenceEquals(before.relaxCells, after.relaxCells);
            }
            if (!append)
                unchecked { m_PagedSmudgeHierarchyEpoch++; }
            m_PagedSmudgeHierarchyDabs = dabs;
            m_PagedSmudgeHierarchyScene = m_PagedScene;
            m_PagedSmudgeHierarchyRevision = m_PagedSmudgeRevision;
            m_PagedSmudgeHierarchyDirty = false;

            // Sum each operation's maximum displacement. Restore only approaches the original
            // position, already inside this envelope, so it cannot enlarge it.
            m_PagedSmudgeDisplacementMin = m_PagedSmudgeDisplacementMax = Vector3.zero;
            for (int i = 0; i < dabs.Count; i++)
            {
                GetPagedSculptDisplacementBounds(dabs[i], out Vector3 minimum, out Vector3 maximum);
                m_PagedSmudgeDisplacementMin += minimum;
                m_PagedSmudgeDisplacementMax += maximum;
            }
        }

        internal Bounds ExpandPagedSmudgeBounds(Bounds original)
        {
            RefreshPagedSmudgeHierarchyJournal();
            return ExpandPagedAttractorBounds(ExpandPagedSmudgeBoundsUnchecked(original));
        }

        Bounds ExpandPagedSmudgeBoundsUnchecked(Bounds original)
        {
            var bounds = new Bounds();
            bounds.SetMinMax(original.min + m_PagedSmudgeDisplacementMin,
                original.max + m_PagedSmudgeDisplacementMax);
            return bounds;
        }

        static void GetPagedSculptDisplacementBounds(in PagedSmudgeDab dab,
            out Vector3 minimum, out Vector3 maximum)
        {
            Vector3 extent;
            switch (dab.kind)
            {
                case 0:
                    Vector3 movement = dab.delta * dab.strength;
                    minimum = Vector3.Min(Vector3.zero, movement);
                    maximum = Vector3.Max(Vector3.zero, movement);
                    return;
                case 1:
                    extent = Vector3.one * (dab.radius * Mathf.Abs(dab.strength));
                    break;
                case 2:
                    extent = new Vector3(Mathf.Abs(dab.normal.x), Mathf.Abs(dab.normal.y), Mathf.Abs(dab.normal.z)) *
                        (dab.normal.magnitude * dab.radius * Mathf.Abs(dab.strength));
                    break;
                case 4:
                    extent = Vector3.one * (Mathf.Min(dab.neighborRadius, 2f) * dab.radius * Mathf.Abs(dab.strength));
                    break;
                default:
                    extent = Vector3.zero;
                    break;
            }
            minimum = -extent;
            maximum = extent;
        }

        static Vector3 ApplyPagedSculptPoint(Vector3 position, Vector3 original, in PagedSmudgeDab dab)
        {
            float distanceSquared = (position - dab.center).sqrMagnitude;
            if (distanceSquared >= dab.radius * dab.radius)
                return position;
            float inverseRadius = 1f / dab.radius;
            float distance = Mathf.Sqrt(distanceSquared * inverseRadius * inverseRadius);
            float weight = dab.falloff < 0.01f ? 1f :
                dab.falloff > 0.45f && dab.falloff < 0.55f ? 1f - distance :
                1f - Mathf.Pow(distance, 1f / dab.falloff);
            if (dab.kind == 3)
                return original + (position - original) * (1f - Mathf.Clamp01(weight * dab.strength));
            Vector3 direction;
            switch (dab.kind)
            {
                case 1: direction = dab.center - position; break;
                case 2: direction = -dab.normal * Vector3.Dot(position - dab.center, dab.normal); break;
                case 4:
                    direction = PagedRelaxTarget(position, dab) - position;
                    if (dab.invert) direction = -direction;
                    break;
                default: direction = dab.delta; break;
            }
            Vector3 result = position + direction * (weight * dab.strength);
            return PagedEraseFinite(result) ? result : position;
        }

        // The tree is built before position compression. At a hard brush edge even a tiny
        // quantization difference can otherwise move a CPU node while its GPU splat stays put.
        // Decode only the resident prefix directly from asset memory when beginning a replay.
        static Vector3[] ReadPagedSculptOriginalPositions(SplatBoxPageGpuState page, LodTreeRuntime original)
        {
            var positions = new Vector3[original.nodes.Length];
            for (int i = 0; i < positions.Length; i++) positions[i] = original.nodes[i].center;
            var asset = page.source != null ? page.source.splatData : null;
            if (asset == null || asset.posData == null)
                return positions;
            NativeArray<byte> data = asset.posData.GetData<byte>();
            int stride = GaussianSplatAsset.GetVectorSize(asset.posFormat);
            if ((long)positions.Length * stride > data.Length)
                return positions;
            for (int i = 0; i < positions.Length; i++)
            {
                float3 position = DecodePagedSculptRawPosition(data, i * stride, asset.posFormat);
                int chunkIndex = i / GaussianSplatAsset.kChunkSize;
                if (page.gpuChunksValid && page.chunkInfos != null && chunkIndex < page.chunkInfos.Length)
                {
                    var chunk = page.chunkInfos[chunkIndex];
                    position = math.lerp(new float3(chunk.posX.x, chunk.posY.x, chunk.posZ.x),
                        new float3(chunk.posX.y, chunk.posY.y, chunk.posZ.y), position);
                }
                positions[i] = position;
            }
            return positions;
        }

        static float3 DecodePagedSculptRawPosition(NativeArray<byte> data, int offset, GaussianSplatAsset.VectorFormat format)
        {
            switch (format)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    return new float3(math.asfloat(ReadSmudgeUInt(data, offset)),
                        math.asfloat(ReadSmudgeUInt(data, offset + 4)), math.asfloat(ReadSmudgeUInt(data, offset + 8)));
                case GaussianSplatAsset.VectorFormat.Norm16:
                    return new float3(ReadSmudgeUShort(data, offset),
                        ReadSmudgeUShort(data, offset + 2), ReadSmudgeUShort(data, offset + 4)) / 65535f;
                case GaussianSplatAsset.VectorFormat.Norm11:
                    uint packed = ReadSmudgeUInt(data, offset);
                    return new float3((packed & 2047) / 2047f,
                        ((packed >> 11) & 1023) / 1023f, ((packed >> 21) & 2047) / 2047f);
                default:
                    uint small = ReadSmudgeUShort(data, offset);
                    return new float3((small & 63) / 63f,
                        ((small >> 6) & 31) / 31f, ((small >> 11) & 31) / 31f);
            }
        }

        static uint ReadSmudgeUShort(NativeArray<byte> data, int offset) =>
            (uint)(data[offset] | data[offset + 1] << 8);

        static uint ReadSmudgeUInt(NativeArray<byte> data, int offset) =>
            ReadSmudgeUShort(data, offset) | (ReadSmudgeUShort(data, offset + 2) << 16);

        void RefitPagedSmudgeTree(LodTreeNode[] nodes, LodTreeRuntime original, bool coarse, float additionalDisplacement = 0f)
        {
            float maximumDisplacement = Vector3.Max(-m_PagedSmudgeDisplacementMin,
                m_PagedSmudgeDisplacementMax).magnitude + additionalDisplacement;
            // Both supported layouts put children after their parent. Refit in reverse order,
            // preserving original Gaussian/subtree size as well as each moved child's reach.
            for (int i = nodes.Length - 1; i >= 0; i--)
            {
                float radius = original.nodes[i].featureSize * 0.5f;
                int childCount = nodes[i].childCount;
                bool hiddenChildren = childCount == 0 && (nodes[i].IsMergedSplat ||
                    (coarse && i == 0 && nodes.Length == 1));
                if (hiddenChildren)
                    radius += maximumDisplacement + math.distance(nodes[i].center, original.nodes[i].center);
                for (int child = 0; child < childCount; child++)
                {
                    int index = original.childTable == null
                        ? (int)nodes[i].childStart + child
                        : original.childTable[original.childTableStart[i] + child];
                    if (index > i && index < nodes.Length)
                        radius = Mathf.Max(radius, math.distance(nodes[i].center, nodes[index].center) +
                            nodes[index].featureSize * 0.5f);
                }
                nodes[i].featureSize = Mathf.Max(1e-4f, radius * 2f);
            }
        }

        bool RestorePagedSmudgeOriginalTrees()
        {
            bool changed = false;
            foreach (var entry in m_PagedSmudgeTrees)
            {
                if (ReferenceEquals(entry.Key.lodTree, entry.Value.published))
                {
                    changed |= !ReferenceEquals(entry.Key.lodTree, entry.Value.original);
                    entry.Key.lodTree = entry.Value.original;
                    entry.Key.bounds = entry.Value.originalBounds;
                }
            }
            m_PagedSmudgeTrees.Clear();
            m_PagedSmudgeDisposedPages.Clear();
            return changed;
        }

        void DisposePagedSmudgeHierarchy()
        {
            RestorePagedSmudgeOriginalTrees();
            m_PagedSmudgeHierarchyDabs.Clear();
            m_PagedSmudgeHierarchyScene = null;
            m_PagedSmudgeHierarchyRevision = -1;
            m_PagedSmudgeHierarchyDirty = true;
            m_PagedSmudgeDisplacementMin = m_PagedSmudgeDisplacementMax = Vector3.zero;
            m_LodStreamer?.SetSculptDisplacementBounds(Vector3.zero, Vector3.zero);
        }
    }
}
