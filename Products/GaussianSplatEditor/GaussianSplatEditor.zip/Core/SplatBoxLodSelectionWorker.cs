// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Unity.Mathematics;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// One background selection at a time. Call the public methods from the main thread; the
    /// worker only reads immutable resident tree arrays and its own copies of page/view metadata.
    /// </summary>
    public sealed class SplatBoxLodSelectionWorker : IDisposable
    {
        public struct Result
        {
            public int selected;
            public LodActiveSplatRef[] output;
            public SplatBoxLodTraverser.Workspace workspace;
            public double elapsedMs;
            public uint[] atlasIndices;
            public int[] atlasBases;
            public bool[] selectedSlots;
            public uint[] maxSplatIndexBySlot;
        }

        SplatBoxLodTraverser.PageContext[] m_Pages;
        int m_PageCount;
        SplatBoxLodTraverser.ViewContext m_View;
        readonly float4[] m_LeftPlanes = new float4[6];
        readonly float4[] m_RightPlanes = new float4[6];
        LodActiveSplatRef[] m_Output;
        SplatBoxLodTraverser.Workspace m_Workspace = new SplatBoxLodTraverser.Workspace();
        int m_MaxSplats;
        float m_PixelScaleLimit;
        bool m_HasAtlasBases;
        int[] m_AtlasBases;
        uint[] m_AtlasIndices;
        bool[] m_SelectedSlots;
        uint[] m_MaxSplatIndexBySlot;
        volatile Task<Result> m_Task;
        bool m_DiscardResult;
        bool m_Disposed;
        int m_CancelledSelectionCount;
        int m_CancellationCountedForTask;

#if UNITY_EDITOR
        static readonly object s_ActiveTaskLock = new object();
        static readonly HashSet<Task<Result>> s_ActiveTasks = new HashSet<Task<Result>>();
        static bool s_EditorStopping;

        static SplatBoxLodSelectionWorker()
        {
            UnityEditor.AssemblyReloadEvents.beforeAssemblyReload += DrainForEditorTeardown;
            UnityEditor.EditorApplication.quitting += DrainForEditorTeardown;
            UnityEditor.EditorApplication.playModeStateChanged += OnEditorPlayModeChanged;
        }
#endif

        /// <summary>Busy until the completed result is consumed or a discarded task is retired.</summary>
        public bool isRunning => m_Task != null;

        /// <summary>Ready for a nonblocking main-thread poll, including discarded or faulted work.</summary>
        public bool hasCompleted => m_Task?.IsCompleted ?? false;

        /// <summary>
        /// Main-thread ownership check for reusable deformation snapshots. Completed work keeps
        /// its snapshot until TryComplete consumes it, just like the ordinary isRunning gate.
        /// </summary>
        internal bool IsUsingNodeSnapshot(LodTreeNode[] nodes)
        {
            if (nodes == null || m_Task == null) return false;
            for (int i = 0; i < m_PageCount; i++)
                if (ReferenceEquals(m_Pages[i].nodes, nodes)) return true;
            return false;
        }

        /// <summary>Completed selections that actually stopped after cooperative cancellation.</summary>
        public int cancelledSelectionCount => Volatile.Read(ref m_CancelledSelectionCount);

        /// <summary>
        /// Snapshots small metadata arrays, retaining the resident node/child arrays by reference.
        /// A result's output/workspace remain stable until the next accepted TryBegin call.
        /// </summary>
        public bool TryBegin(SplatBoxLodTraverser.PageContext[] pages, int pageCount,
            in SplatBoxLodTraverser.ViewContext view, int maxSplats, float pixelScaleLimit, int[] atlasBases = null)
        {
            RetireDiscardedTask();
#if UNITY_EDITOR
            if (s_EditorStopping)
                return false;
#endif
            if (m_Disposed || m_Task != null || pages == null || pageCount <= 0 || maxSplats <= 0)
                return false;
            pageCount = Math.Min(pageCount, pages.Length);
            if (pageCount <= 0)
                return false;

            // Burst compilation and its possible diagnostic logging stay on the main thread. The
            // traversal also has a managed fallback when Burst is disabled or unavailable.
            SplatBoxLodTraverser.WarmupNativeTraversal();
            if (m_Pages == null || m_Pages.Length < pageCount)
                m_Pages = new SplatBoxLodTraverser.PageContext[pageCount];
            else if (m_PageCount > pageCount)
                Array.Clear(m_Pages, pageCount, m_PageCount - pageCount);
            Array.Copy(pages, m_Pages, pageCount);
            m_PageCount = pageCount;
            m_View = view;
            m_View.cullPlanes = CopyPlanes(view.cullPlanes, m_LeftPlanes);
            m_View.rightEyeCullPlanes = CopyPlanes(view.rightEyeCullPlanes, m_RightPlanes);
            if (m_Output == null || m_Output.Length < maxSplats)
                m_Output = new LodActiveSplatRef[maxSplats];
            m_MaxSplats = maxSplats;
            m_PixelScaleLimit = pixelScaleLimit;
            m_HasAtlasBases = atlasBases != null;
            if (m_HasAtlasBases)
            {
                if (m_AtlasBases == null || m_AtlasBases.Length != atlasBases.Length)
                {
                    m_AtlasBases = new int[atlasBases.Length];
                    m_SelectedSlots = new bool[atlasBases.Length];
                    m_MaxSplatIndexBySlot = new uint[atlasBases.Length];
                }
                Array.Copy(atlasBases, m_AtlasBases, atlasBases.Length);
                if (m_AtlasIndices == null || m_AtlasIndices.Length < maxSplats)
                    m_AtlasIndices = new uint[maxSplats];
            }
            m_DiscardResult = false;
            Volatile.Write(ref m_CancellationCountedForTask, 0);
            // Only an idle owner can clear cancellation: the previous task may still have its
            // workspace arrays pinned even after its result has become obsolete.
            m_Workspace.ResetCancellation();
            m_Task = Task.Run(Select);
#if UNITY_EDITOR
            TrackEditorTask(m_Task);
#endif
            return true;
        }

        /// <summary>
        /// Never waits. Successful results borrow the worker's reusable buffers; consume them before
        /// calling TryBegin again. Faults are rethrown here on the main thread for renderer fallback.
        /// </summary>
        public bool TryComplete(out Result result)
        {
            result = default;
            var task = m_Task;
            if (task == null || !task.IsCompleted)
                return false;
            RecordCompletedCancellation(task);
            bool discard = m_DiscardResult || m_Disposed;
            m_Task = null;
            m_DiscardResult = false;
            ReleasePageSnapshot();
            if (discard)
            {
                ObserveDiscardedFault(task);
                if (m_Disposed)
                    ReleaseReferences();
                return false;
            }
            result = task.GetAwaiter().GetResult();
            if (result.workspace != null && result.workspace.wasCancelled)
            {
                result = default;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Invalidate an in-flight selection and request a cooperative stop without waiting. Its
        /// pinned handles are released by the traverser's finally block before the task is retired.
        /// </summary>
        public void DiscardPending()
        {
            m_Workspace?.RequestCancellation();
            if (m_Task == null)
            {
                ReleasePageSnapshot();
                return;
            }
            m_DiscardResult = true;
            RetireDiscardedTask();
        }

        public void Dispose()
        {
            if (m_Disposed)
                return;
            m_Disposed = true;
            DiscardPending();
            var task = m_Task;
            if (task == null)
                ReleaseReferences();
            else
            {
                // A disposed owner may never poll again. Native traversal releases its pins in
                // finally; this continuation then drops source-tree/result references and observes
                // faults, without delaying the caller or requiring a Unity synchronization context.
                task.ContinueWith(completed =>
                {
                    RecordCompletedCancellation(completed);
                    ObserveDiscardedFault(completed);
                    ReleaseReferences();
                    m_Task = null;
                }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
            }
        }

        Result Select()
        {
            var timer = Stopwatch.StartNew();
            int selected = SplatBoxLodTraverser.Traverse(m_Pages, m_PageCount, m_View,
                m_MaxSplats, m_PixelScaleLimit, m_Output, m_Workspace);
            bool validAtlasIndices = m_HasAtlasBases;
            if (m_HasAtlasBases)
            {
                Array.Clear(m_SelectedSlots, 0, m_SelectedSlots.Length);
                Array.Clear(m_MaxSplatIndexBySlot, 0, m_MaxSplatIndexBySlot.Length);
                for (int i = 0; i < selected; i++)
                {
                    var reference = m_Output[i];
                    uint slot = reference.pageSlot;
                    if (slot >= m_AtlasBases.Length)
                    {
                        validAtlasIndices = false;
                        continue;
                    }
                    m_SelectedSlots[slot] = true;
                    m_MaxSplatIndexBySlot[slot] = Math.Max(m_MaxSplatIndexBySlot[slot], reference.splatIndex);
                    int atlasBase = m_AtlasBases[slot];
                    if (atlasBase < 0 || reference.splatIndex > uint.MaxValue - (uint)atlasBase)
                    {
                        validAtlasIndices = false;
                        continue;
                    }
                    m_AtlasIndices[i] = (uint)atlasBase + reference.splatIndex;
                }
            }
            timer.Stop();
            return new Result
            {
                selected = selected, output = m_Output, workspace = m_Workspace,
                elapsedMs = timer.Elapsed.TotalMilliseconds,
                // Unknown/unresident slots deliberately leave the gathered buffer null. The
                // renderer must reject it or run its ordinary per-reference validation fallback.
                atlasIndices = validAtlasIndices ? m_AtlasIndices : null,
                atlasBases = m_HasAtlasBases ? m_AtlasBases : null,
                selectedSlots = m_HasAtlasBases ? m_SelectedSlots : null,
                maxSplatIndexBySlot = m_HasAtlasBases ? m_MaxSplatIndexBySlot : null
            };
        }

        static float4[] CopyPlanes(float4[] source, float4[] destination)
        {
            if (source == null)
                return null;
            Array.Clear(destination, 0, destination.Length);
            Array.Copy(source, destination, Math.Min(source.Length, destination.Length));
            return destination;
        }

        void RetireDiscardedTask()
        {
            var task = m_Task;
            if (task == null || !m_DiscardResult || !task.IsCompleted)
                return;
            RecordCompletedCancellation(task);
            ObserveDiscardedFault(task);
            m_Task = null;
            m_DiscardResult = false;
            ReleasePageSnapshot();
            if (m_Disposed)
                ReleaseReferences();
        }

        static void ObserveDiscardedFault(Task<Result> task)
        {
            // Reading Exception observes a fault even though an obsolete result is never applied.
            if (task.IsFaulted)
                _ = task.Exception;
        }

        void RecordCompletedCancellation(Task<Result> task)
        {
            // Never touch Result on a faulted/canceled Task. Dispose's continuation and a final
            // main-thread poll may both see completion, but each owned selection counts once.
            if (!task.IsCompletedSuccessfully || task.Result.workspace == null || !task.Result.workspace.wasCancelled)
                return;
            if (Interlocked.Exchange(ref m_CancellationCountedForTask, 1) == 0)
                Interlocked.Increment(ref m_CancelledSelectionCount);
        }

        void ReleaseReferences()
        {
            ReleasePageSnapshot();
            m_Pages = null;
            m_Output = null;
            m_Workspace = null;
            m_View = default;
            m_AtlasBases = null;
            m_AtlasIndices = null;
            m_SelectedSlots = null;
            m_MaxSplatIndexBySlot = null;
            m_HasAtlasBases = false;
        }

        void ReleasePageSnapshot()
        {
            var pages = m_Pages;
            int count = m_PageCount;
            if (pages != null && count > 0)
                Array.Clear(pages, 0, Math.Min(count, pages.Length));
            m_PageCount = 0;
            m_View = default;
        }

#if UNITY_EDITOR
        static void TrackEditorTask(Task<Result> task)
        {
            lock (s_ActiveTaskLock)
                s_ActiveTasks.Add(task);
            task.ContinueWith(completed =>
            {
                lock (s_ActiveTaskLock)
                    s_ActiveTasks.Remove(completed);
            }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
        }

        static void OnEditorPlayModeChanged(UnityEditor.PlayModeStateChange state)
        {
            if (state == UnityEditor.PlayModeStateChange.ExitingPlayMode ||
                state == UnityEditor.PlayModeStateChange.ExitingEditMode)
                DrainForEditorTeardown();
            else
                s_EditorStopping = false;
        }

        static void DrainForEditorTeardown()
        {
            // Unity is about to unload the Burst module/domain. Ordinary Dispose stays
            // nonblocking, but a raw native function pointer must finish before that teardown.
            // Only main-thread editor teardown waits; never hold the registry lock while waiting.
            s_EditorStopping = true;
            Task<Result>[] tasks;
            lock (s_ActiveTaskLock)
            {
                tasks = new Task<Result>[s_ActiveTasks.Count];
                s_ActiveTasks.CopyTo(tasks);
            }
            for (int i = 0; i < tasks.Length; i++)
            {
                try { tasks[i].GetAwaiter().GetResult(); }
                catch (Exception) { ObserveDiscardedFault(tasks[i]); }
            }
            lock (s_ActiveTaskLock)
            {
                for (int i = 0; i < tasks.Length; i++)
                    s_ActiveTasks.Remove(tasks[i]);
            }
        }
#endif
    }
}
