// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [Serializable]
        internal struct PagedLodEraseStroke
        {
            // Zero keeps existing scenes anchored to the unsculpted source. New edits retain
            // the deformation at stroke time, even after later sculpting or a sculpt reset.
            public int sculptSnapshot;
            public int kind; // 0: sphere, 1: infinite view cylinder, 2: screen circle, 3: box, 4: bounded cylinder, 5: polygon prism.
            public bool restore;
            // Capture the renderer transform with the stroke: later object movement must not
            // move an erase region relative to the splat data it originally affected.
            public Matrix4x4 objectToWorld;
            public Matrix4x4 viewProjection;
            public Matrix4x4 worldToShape;
            public Vector4 shapeSize; // Box half-extents in xyz; bounded cylinder half-height in w.
            public Vector2[] polygon; // Immutable polygon footprint in captured worldToShape XY.
            public Vector4 centerRadius;
            public Vector4 direction;
            public Vector4 screen;
            public Vector4 screenSize;
            public float maxDepth;
            // Older saved strokes retain clip.w depth. New erase strokes capture true
            // camera depth so orthographic cameras and replay protect the same layer.
            public bool useLinearDepth;
            public Vector4 depthPlane;
            public Vector4 falloffNoise;
            public Color color;
            public bool useColor;
            public float colorThreshold;
        }

        [SerializeField, HideInInspector] GaussianSplatPagedScene m_PagedEraseScene;
        [SerializeField, HideInInspector] List<PagedLodEraseStroke> m_PagedEraseStrokes = new List<PagedLodEraseStroke>();
        [SerializeField, HideInInspector] int m_PagedEraseRevision;
        GraphicsBuffer m_GpuPagedLodDeletedBits;
        int m_PagedEraseAppliedRevision = -1;
        ComputeShader m_PagedEraseShader;
        int m_PagedEraseApplyKernel = -1;
        int m_PagedEraseClearKernel = -1;
        readonly Dictionary<Vector2[], GraphicsBuffer> m_PagedErasePolygonBuffers = new Dictionary<Vector2[], GraphicsBuffer>();
        GraphicsBuffer m_PagedEraseEmptyPolygon;

        internal GraphicsBuffer pagedLodDeletedBits => m_GpuPagedLodDeletedBits;
        internal bool pagedLodDeletedBitsValid => HasPagedLodEraseJournal &&
            m_GpuPagedLodDeletedBits != null && m_PagedEraseAppliedRevision == m_PagedEraseRevision;
        public int pagedLodEraseStrokeCount => HasPagedLodEraseJournal ? m_PagedEraseStrokes.Count : 0;

        bool HasPagedLodEraseJournal => UsesPagedLod && m_PagedEraseScene == m_PagedScene &&
            m_PagedEraseStrokes != null && m_PagedEraseStrokes.Count > 0;

        /// <summary>
        /// Records a spatial edit and applies it to resident page payloads, including every LoD
        /// level. The serialized journal also applies to pages that have not streamed in yet.
        /// </summary>
        bool ApplyPagedLodErase(PagedLodEraseStroke stroke)
        {
            if (!UsesPagedLod || !IsValidPagedLodEraseStroke(stroke) || !FindPagedLodEraseKernels())
                return false;

            using var cmd = new CommandBuffer { name = "Paged Splat Erase" };
            // Bring an undone/reloaded journal up to date before appending. Ordinary strokes
            // only dispatch the new operation; they never replay the history every frame.
            EnsurePagedLodEraseState(cmd);
#if UNITY_EDITOR
            if (!Application.isPlaying)
                UnityEditor.Undo.RecordObject(this, stroke.restore ? "Restore Paged Splats" : "Erase Paged Splats");
#endif
            stroke.sculptSnapshot = CapturePagedEditSculptSnapshot();
            if (m_PagedEraseScene != m_PagedScene)
            {
                m_PagedEraseScene = m_PagedScene;
                m_PagedEraseStrokes = new List<PagedLodEraseStroke>();
            }
            m_PagedEraseStrokes ??= new List<PagedLodEraseStroke>();
            m_PagedEraseStrokes.Add(stroke);
            unchecked { m_PagedEraseRevision++; }

            if (EnsurePagedLodEraseBuffer(cmd))
            {
                var pages = m_LodStreamer?.loadedPages;
                if (pages != null)
                {
                    for (int i = 0; i < pages.Count; i++)
                    {
                        var page = pages[i];
                        if (HasUploadedPagedEraseRange(page) && PagedLodEraseIntersectsPage(stroke,
                            ExpandPagedEditSculptBounds(page.bounds, stroke.sculptSnapshot)))
                            DispatchPagedLodErase(cmd, page.atlasOffset, page.splatCount, stroke);
                    }
                }
                m_PagedEraseAppliedRevision = m_PagedEraseRevision;
            }
            Graphics.ExecuteCommandBuffer(cmd);
            editModified = true;
            InvalidatePagedLodEraseView();
#if UNITY_EDITOR
            if (!Application.isPlaying)
                MarkPagedLodEraseDirty();
#endif
            return true;
        }

        void ResetPagedLodErase()
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
                UnityEditor.Undo.RecordObject(this, "Reset Paged Splat Edits");
#endif
            m_PagedEraseStrokes?.Clear();
            ClearPagedEditSculptHistoryIfUnused();
            m_PagedEraseScene = m_PagedScene;
            unchecked { m_PagedEraseRevision++; }
            DisposePagedLodEraseBuffer();
            editModified = true;
            InvalidatePagedLodEraseView();
#if UNITY_EDITOR
            if (!Application.isPlaying)
                MarkPagedLodEraseDirty();
#endif
        }

        /// <summary>Detects serialized Undo/reload changes without changing traversal or sort state.</summary>
        void EnsurePagedLodEraseState(CommandBuffer cmd)
        {
            if (!HasPagedLodEraseJournal)
            {
                if (m_GpuPagedLodDeletedBits != null)
                {
                    DisposePagedLodEraseBuffer();
                    InvalidatePagedLodEraseView();
                }
                return;
            }
            if (m_GpuPagedLodDeletedBits != null &&
                m_GpuPagedLodDeletedBits.count == (m_LodAtlasCapacity + 31) / 32 &&
                m_PagedEraseAppliedRevision == m_PagedEraseRevision)
                return;
            if (cmd == null)
            {
                using var immediate = new CommandBuffer { name = "Replay Paged Splat Erase" };
                EnsurePagedLodEraseState(immediate);
                Graphics.ExecuteCommandBuffer(immediate);
                return;
            }
            if (!EnsurePagedLodEraseBuffer(cmd) || m_PagedEraseAppliedRevision == m_PagedEraseRevision)
                return;

            ClearPagedLodEraseRange(cmd, 0, m_LodAtlasCapacity);
            var pages = m_LodStreamer?.loadedPages;
            if (pages != null)
            {
                for (int i = 0; i < pages.Count; i++)
                {
                    var page = pages[i];
                    if (HasUploadedPagedEraseRange(page))
                        ReplayPagedLodEraseStrokes(cmd, page.atlasOffset, page.splatCount, page.bounds);
                }
            }
            m_PagedEraseAppliedRevision = m_PagedEraseRevision;
            InvalidatePagedLodEraseView();
        }

        static bool HasUploadedPagedEraseRange(SplatBoxPageGpuState page) =>
            page != null && page.IsReady && page.atlasOffset >= 0 &&
            page.uploadedAtlasOffset == page.atlasOffset && page.splatCount > 0;

        /// <summary>
        /// Called after page payload/chunk uploads. A reused atlas slot starts clean, then receives
        /// erase and restore strokes in their original order; no former page's bits can leak in.
        /// </summary>
        void ReplayPagedLodEraseRange(CommandBuffer cmd, int offset, int count)
        {
            ReplayPagedLodEraseRangeWithBounds(cmd, offset, count, null);
        }

        void ReplayPagedLodErasePage(CommandBuffer cmd, SplatBoxPageGpuState page, int offset)
        {
            ReplayPagedLodEraseRangeWithBounds(cmd, offset, page.splatCount, page.bounds);
        }

        void ReplayPagedLodEraseRangeWithBounds(CommandBuffer cmd, int offset, int count, Bounds? pageBounds)
        {
            if (!HasPagedLodEraseJournal)
                return;
            if (cmd == null)
            {
                using var immediate = new CommandBuffer { name = "Replay Paged Splat Page Edits" };
                ReplayPagedLodEraseRangeWithBounds(immediate, offset, count, pageBounds);
                Graphics.ExecuteCommandBuffer(immediate);
                return;
            }
            if (!EnsurePagedLodEraseBuffer(cmd))
                return;
            ClearPagedLodEraseRange(cmd, offset, count);
            ReplayPagedLodEraseStrokes(cmd, offset, count, pageBounds);
            InvalidatePagedLodEraseView();
        }

        void ReplayPagedLodEraseStrokes(CommandBuffer cmd, int offset, int count, Bounds? pageBounds)
        {
            for (int i = 0; i < m_PagedEraseStrokes.Count; i++)
            {
                var stroke = m_PagedEraseStrokes[i];
                if (!pageBounds.HasValue || PagedLodEraseIntersectsPage(stroke,
                    ExpandPagedEditSculptBounds(pageBounds.Value, stroke.sculptSnapshot)))
                    DispatchPagedLodErase(cmd, offset, count, stroke);
            }
        }

        bool FindPagedLodEraseKernels()
        {
            if (m_CSBoxUtil == null)
                return false;
            // Shader reimport keeps the same object but may reorder its kernels. Resolve
            // names before editor replay instead of dispatching a stale numeric index.
#if !UNITY_EDITOR
            if (m_PagedEraseShader != m_CSBoxUtil)
#endif
            {
                m_PagedEraseShader = m_CSBoxUtil;
                m_PagedEraseApplyKernel = m_CSBoxUtil.HasKernel("CSApplyPagedErase")
                    ? m_CSBoxUtil.FindKernel("CSApplyPagedErase") : -1;
                m_PagedEraseClearKernel = m_CSBoxUtil.HasKernel("CSClearPagedErase")
                    ? m_CSBoxUtil.FindKernel("CSClearPagedErase") : -1;
            }
            return m_PagedEraseApplyKernel >= 0 && m_PagedEraseClearKernel >= 0;
        }

        bool EnsurePagedLodEraseBuffer(CommandBuffer cmd)
        {
            if (!HasPagedLodEraseJournal || m_LodAtlasCapacity <= 0 || m_GpuLodUnifiedPos == null ||
                m_GpuLodUnifiedColor == null || !EnsureLodFormatAsset() || !FindPagedLodEraseKernels())
                return false;
            int words = (m_LodAtlasCapacity + 31) / 32;
            if (m_GpuPagedLodDeletedBits != null && m_GpuPagedLodDeletedBits.count == words)
                return true;
            DisposePagedLodEraseBuffer();
            m_GpuPagedLodDeletedBits = new GraphicsBuffer(GraphicsBuffer.Target.Raw, words, sizeof(uint))
                { name = "PagedSplatDeletedBits" };
            ClearPagedLodEraseRange(cmd, 0, m_LodAtlasCapacity);
            return true;
        }

        void ClearPagedLodEraseRange(CommandBuffer cmd, int offset, int count)
        {
            if (offset < 0 || (offset & 31) != 0 || count <= 0 || offset >= m_LodAtlasCapacity)
                return;
            count = Mathf.Min(count, m_LodAtlasCapacity - offset);
            cmd.SetComputeBufferParam(m_CSBoxUtil, m_PagedEraseClearKernel, "_PagedSplatDeletedBits", m_GpuPagedLodDeletedBits);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseOffset", offset);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseCount", count);
            m_CSBoxUtil.GetKernelThreadGroupSizes(m_PagedEraseClearKernel, out uint groupSize, out _, out _);
            if (groupSize > 0)
                cmd.DispatchCompute(m_CSBoxUtil, m_PagedEraseClearKernel,
                    (int)(((uint)((count + 31) / 32) + groupSize - 1) / groupSize), 1, 1);
        }

        void DispatchPagedLodErase(CommandBuffer cmd, int offset, int count, in PagedLodEraseStroke stroke)
        {
            if (offset < 0 || count <= 0 || offset >= m_LodAtlasCapacity)
                return;
            count = Mathf.Min(count, m_LodAtlasCapacity - offset);
            int kernel = m_PagedEraseApplyKernel;
            if (!BindPagedEditSculptSnapshot(cmd, kernel, stroke.sculptSnapshot, offset, count)) return;
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedSplatDeletedBits", m_GpuPagedLodDeletedBits);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuLodUnifiedPos);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatChunks, m_GpuLodUnifiedChunks ?? m_GpuChunks);
            cmd.SetComputeTextureParam(m_CSBoxUtil, kernel, Props.SplatColor, m_GpuLodUnifiedColor);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount,
                m_GpuLodUnifiedChunks != null ? m_LodUnifiedChunkCount : 0);
            uint format = (uint)m_LodFormatAsset.posFormat | ((uint)m_LodFormatAsset.scaleFormat << 8) |
                ((uint)m_LodFormatAsset.shFormat << 16);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)format);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseOffset", offset);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseCount", count);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseKind", stroke.kind);
            // Each recorded dispatch keeps its own immutable vertices. Updating a shared
            // buffer here would make every stroke in a replay use the final polygon.
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedPolygonVertices", GetPagedErasePolygonBuffer(stroke));
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedPolygonCount", stroke.kind == 5 ? stroke.polygon.Length : 0);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseRestore", stroke.restore ? 1 : 0);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_PagedEraseObjectToWorld", stroke.objectToWorld);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_PagedEraseVP", stroke.viewProjection);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_PagedEraseWorldToShape", stroke.worldToShape);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseShapeSize", stroke.shapeSize);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseCenterRadius", stroke.centerRadius);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseDirection", stroke.direction);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseScreen", stroke.screen);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseScreenSize", stroke.screenSize);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseDepth", new Vector4(stroke.maxDepth, stroke.useLinearDepth ? 1 : 0, 0, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseDepthPlane", stroke.depthPlane);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseFalloffNoise", stroke.falloffNoise);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PagedEraseColor", stroke.color);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedEraseUseColor", stroke.useColor ? 1 : 0);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_PagedEraseColorThreshold", stroke.colorThreshold);
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize > 0)
                cmd.DispatchCompute(m_CSBoxUtil, kernel, (int)(((uint)count + groupSize - 1) / groupSize), 1, 1);
        }

        void DisposePagedLodEraseBuffer()
        {
            m_GpuPagedLodDeletedBits?.Dispose();
            m_GpuPagedLodDeletedBits = null;
            m_PagedEraseAppliedRevision = -1;
            foreach (var buffer in m_PagedErasePolygonBuffers.Values) buffer.Dispose();
            m_PagedErasePolygonBuffers.Clear();
            m_PagedEraseEmptyPolygon?.Dispose();
            m_PagedEraseEmptyPolygon = null;
        }

        GraphicsBuffer GetPagedErasePolygonBuffer(in PagedLodEraseStroke stroke)
        {
            if (stroke.kind != 5)
            {
                if (m_PagedEraseEmptyPolygon == null)
                {
                    m_PagedEraseEmptyPolygon = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(float) * 2)
                        { name = "PagedEraseEmptyPolygon" };
                    m_PagedEraseEmptyPolygon.SetData(new Vector2[1]);
                }
                return m_PagedEraseEmptyPolygon;
            }
            if (!m_PagedErasePolygonBuffers.TryGetValue(stroke.polygon, out var polygonBuffer))
            {
                polygonBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, stroke.polygon.Length, sizeof(float) * 2)
                    { name = "PagedErasePolygon" };
                polygonBuffer.SetData(stroke.polygon);
                m_PagedErasePolygonBuffers.Add(stroke.polygon, polygonBuffer);
            }
            return polygonBuffer;
        }

        static bool PagedEraseFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        static bool PagedEraseFinite(Vector4 value) => PagedEraseFinite(value.x) &&
            PagedEraseFinite(value.y) && PagedEraseFinite(value.z) && PagedEraseFinite(value.w);

        static bool IsValidPagedLodEraseStroke(in PagedLodEraseStroke stroke)
        {
            if (stroke.kind < 0 || stroke.kind > 5 || !PagedEraseFinite(stroke.centerRadius) ||
                !PagedEraseFinite(stroke.direction) || !PagedEraseFinite(stroke.falloffNoise) ||
                !PagedEraseFinite(stroke.color) || !PagedEraseFinite(stroke.colorThreshold))
                return false;
            for (int i = 0; i < 16; i++)
                if (!PagedEraseFinite(stroke.objectToWorld[i]) ||
                    (stroke.kind == 2 && !PagedEraseFinite(stroke.viewProjection[i])) ||
                    ((stroke.kind == 3 || stroke.kind == 5) && !PagedEraseFinite(stroke.worldToShape[i])))
                    return false;
            if (stroke.kind == 5)
            {
                if (stroke.polygon == null || stroke.polygon.Length < 3 || stroke.polygon.Length > 128 ||
                    !PagedEraseFinite(stroke.shapeSize) || stroke.shapeSize.x <= 0 || stroke.shapeSize.y <= 0 || stroke.shapeSize.z <= 0)
                    return false;
                foreach (var point in stroke.polygon)
                    if (!PagedEraseFinite(point.x) || !PagedEraseFinite(point.y)) return false;
                return true;
            }
            if (stroke.kind == 3)
                return PagedEraseFinite(stroke.shapeSize) && stroke.shapeSize.x > 0 &&
                    stroke.shapeSize.y > 0 && stroke.shapeSize.z > 0;
            if (stroke.kind == 4)
            {
                float axisLengthSquared = ((Vector3)stroke.direction).sqrMagnitude;
                return stroke.centerRadius.w > 0 && PagedEraseFinite(stroke.shapeSize) && stroke.shapeSize.w > 0 &&
                    PagedEraseFinite(axisLengthSquared) && axisLengthSquared > 0;
            }
            if (stroke.kind == 2)
                return PagedEraseFinite(stroke.screen) && stroke.screen.z > 0 &&
                    PagedEraseFinite(stroke.screenSize) && stroke.screenSize.x > 0 && stroke.screenSize.y > 0 &&
                    PagedEraseFinite(stroke.maxDepth) && stroke.maxDepth > 0 &&
                    (!stroke.useLinearDepth || (PagedEraseFinite(stroke.depthPlane) && ((Vector3)stroke.depthPlane).sqrMagnitude > 0));
            return stroke.centerRadius.w > 0;
        }

        // Bounds contain every LoD node center. Broadphase rejection saves replay dispatches for
        // unrelated pages; malformed or near-plane bounds deliberately fall back to the GPU test.
        static bool PagedLodEraseIntersectsPage(in PagedLodEraseStroke stroke, Bounds localBounds)
        {
            if (!PagedEraseFinite(localBounds.center) || !PagedEraseFinite(localBounds.extents) ||
                localBounds.extents.x < 0 || localBounds.extents.y < 0 || localBounds.extents.z < 0)
                return true;
            if (stroke.kind == 2)
            {
                Vector2 min = new Vector2(float.MaxValue, float.MaxValue);
                Vector2 max = new Vector2(float.MinValue, float.MinValue);
                for (int i = 0; i < 8; i++)
                {
                    Vector3 corner = localBounds.center + Vector3.Scale(localBounds.extents,
                        new Vector3((i & 1) == 0 ? -1 : 1, (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1));
                    Vector3 world = stroke.objectToWorld.MultiplyPoint3x4(corner);
                    Vector4 clip = stroke.viewProjection * new Vector4(world.x, world.y, world.z, 1);
                    if (!PagedEraseFinite(clip) || clip.w <= 0)
                        return true;
                    Vector2 pixel = new Vector2((clip.x / clip.w * 0.5f + 0.5f) * stroke.screenSize.x,
                        (0.5f - clip.y / clip.w * 0.5f) * stroke.screenSize.y);
                    if (!PagedEraseFinite(pixel.x) || !PagedEraseFinite(pixel.y))
                        return true;
                    min = Vector2.Min(min, pixel);
                    max = Vector2.Max(max, pixel);
                }
                float padding = 0.001f + Mathf.Max(Mathf.Max(Mathf.Abs(min.x), Mathf.Abs(min.y)),
                    Mathf.Max(Mathf.Abs(max.x), Mathf.Abs(max.y))) * 0.00001f;
                Vector2 closest = new Vector2(Mathf.Clamp(stroke.screen.x, min.x, max.x),
                    Mathf.Clamp(stroke.screen.y, min.y, max.y));
                float radius = stroke.screen.z + padding;
                return (closest - new Vector2(stroke.screen.x, stroke.screen.y)).sqrMagnitude <= radius * radius;
            }

            // For boxes, testing the transformed page AABB in box coordinates conservatively
            // includes rotation, renderer scale and every node center in the page.
            Matrix4x4 matrix = stroke.kind == 3 || stroke.kind == 5 ? stroke.worldToShape * stroke.objectToWorld : stroke.objectToWorld;
            Vector3 center = matrix.MultiplyPoint3x4(localBounds.center);
            Vector3 e = localBounds.extents;
            Vector3 extents = new Vector3(
                Mathf.Abs(matrix.m00) * e.x + Mathf.Abs(matrix.m01) * e.y + Mathf.Abs(matrix.m02) * e.z,
                Mathf.Abs(matrix.m10) * e.x + Mathf.Abs(matrix.m11) * e.y + Mathf.Abs(matrix.m12) * e.z,
                Mathf.Abs(matrix.m20) * e.x + Mathf.Abs(matrix.m21) * e.y + Mathf.Abs(matrix.m22) * e.z);
            if (!PagedEraseFinite(center) || !PagedEraseFinite(extents))
                return true;
            float worldPadding = 0.0001f + (center.magnitude + extents.magnitude) * 0.00001f;
            if (stroke.kind == 3 || stroke.kind == 5)
                worldPadding += ((Vector3)stroke.centerRadius).magnitude * 0.00001f;
            if (!PagedEraseFinite(worldPadding))
                return true;
            if (stroke.kind == 3 || stroke.kind == 5)
                return Mathf.Abs(center.x) <= extents.x + stroke.shapeSize.x + worldPadding &&
                    Mathf.Abs(center.y) <= extents.y + stroke.shapeSize.y + worldPadding &&
                    Mathf.Abs(center.z) <= extents.z + stroke.shapeSize.z + worldPadding;
            Vector3 brushCenter = stroke.centerRadius;
            float brushRadius = stroke.centerRadius.w + worldPadding;
            if (stroke.kind == 0)
                return new Bounds(center, extents * 2).SqrDistance(brushCenter) <= brushRadius * brushRadius;

            Vector3 delta = center - brushCenter;
            Vector3 direction = stroke.direction;
            float directionLengthSquared = direction.sqrMagnitude;
            if (!PagedEraseFinite(directionLengthSquared))
                return true;
            float boundRadius = extents.magnitude + worldPadding;
            float along = Vector3.Dot(delta, direction);
            float axialRadius = boundRadius * Mathf.Sqrt(directionLengthSquared);
            if (stroke.kind == 4 ? Mathf.Abs(along) > stroke.shapeSize.w + axialRadius : along > axialRadius)
                return false;
            // The shader uses I - dd^T. Its maximum stretch is max(1, abs(1-|d|^2)),
            // so this remains conservative even if a caller supplied a non-unit direction.
            float perpendicularRadius = boundRadius * Mathf.Max(1, Mathf.Abs(1 - directionLengthSquared));
            return (delta - direction * along).magnitude <= brushRadius + perpendicularRadius;
        }

#if UNITY_EDITOR
        void MarkPagedLodEraseDirty()
        {
            UnityEditor.EditorUtility.SetDirty(this);
            if (gameObject.scene.IsValid() && gameObject.scene.isLoaded)
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(gameObject.scene);
        }
#endif

        void InvalidatePagedLodEraseView()
        {
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            if (!Application.isPlaying)
                UnityEditor.SceneView.RepaintAll();
#endif
        }
    }
}
