// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        /// <summary>
        /// Recreates the editor's transient paged preview. Source assets and serialized spatial
        /// edits are retained; page uploads continue through the normal paced streaming path.
        /// </summary>
        public bool ForceRebuildPagedLodInEditor()
        {
#if UNITY_EDITOR
            return EnsureEditorPagedLodReady(forceRebuild: true, forceRetry: true);
#else
            return false;
#endif
        }

#if UNITY_EDITOR
        [System.Flags]
        public enum EditorSettingsChange
        {
            // Zero keeps the conservative validation used by source changes and Undo/Redo.
            Full = 0,
            Appearance = 1,
            View = 2,
            Sort = 4,
            LodSelection = 8,
            Atlas = 16
        }

        EditorSettingsChange m_EditorSettingsChange;

        /// <summary>
        /// Only use for known render controls. Spatial edits, source changes and Undo must still
        /// run full validation so restored serialized edit journals reach the GPU.
        /// </summary>
        public EditorSettingsScope BeginEditorSettingsChange(EditorSettingsChange change) => new(this, change);

        public readonly struct EditorSettingsScope : System.IDisposable
        {
            readonly SplatBoxRenderer m_Renderer;
            readonly EditorSettingsChange m_Previous;

            internal EditorSettingsScope(SplatBoxRenderer renderer, EditorSettingsChange change)
            {
                m_Renderer = renderer;
                m_Previous = renderer.m_EditorSettingsChange;
                renderer.m_EditorSettingsChange = change;
            }

            public void Dispose() => m_Renderer.m_EditorSettingsChange = m_Previous;
        }

        bool ValidateEditorSettingsChange()
        {
            var change = m_EditorSettingsChange;
            if (change == EditorSettingsChange.Full) return false;
            // Colour grading is bound on every draw and needs no view/selection rebuild.
            if ((change & EditorSettingsChange.View) != 0) m_HasEditorLodCalculatedView = false;
            if ((change & EditorSettingsChange.Sort) != 0) m_HasEditorLodSortedView = false;
            if ((change & EditorSettingsChange.LodSelection) != 0) m_LodSelectionDirty = true;
            if ((change & EditorSettingsChange.Atlas) != 0) m_LodAtlasDirty = true;
            return true;
        }

        double m_EditorLodNextRecoveryTime;
        bool m_EditorLodRecovering;
        string m_EditorLodLastRecoveryError;

        void HookEditorUpdates()
        {
            UnityEditor.EditorApplication.update -= EditorUpdate;
            UnityEditor.EditorApplication.update += EditorUpdate;
        }

        void CancelEditorPagedLodWarmup()
        {
            UnityEditor.EditorApplication.delayCall -= EditorPagedLodWarmup;
            m_EditorLodWarmupScheduled = false;
        }

        // A zero selected count is valid (an empty camera view). Readiness is determined by
        // resources, never by visibility, page upload progress or an unfinished worker.
        bool HasEditorPagedLodResources => m_LodAllocatedBudget > 0 &&
            m_LodFormatAsset != null && m_LodAtlasCapacity > 0 &&
            IsLiveBuffer(m_GpuPosData) && IsLiveBuffer(m_GpuOtherData) && IsLiveBuffer(m_GpuSHData) &&
            IsLiveBuffer(m_GpuChunks) && IsLiveBuffer(m_GpuView, m_LodAllocatedBudget) &&
            IsLiveBuffer(m_GpuIndexBuffer, 6) && IsLiveBuffer(m_GpuSortKeys, m_LodAllocatedBudget) &&
            IsLiveBuffer(m_GpuSortDistances, m_LodAllocatedBudget) && IsLiveBuffer(m_GpuDrawArgs, 5) &&
            IsLiveBuffer(m_GpuLodUnifiedPos) && IsLiveBuffer(m_GpuLodUnifiedOther) && IsLiveBuffer(m_GpuLodUnifiedSh) &&
            IsLiveBuffer(m_GpuLodAtlasIndices, m_LodAllocatedBudget) && m_GpuLodUnifiedColor != null &&
            m_LodActiveScratch != null && m_LodActiveScratch.Length >= m_LodAllocatedBudget &&
            m_LodAtlasIndexScratch != null && m_LodAtlasIndexScratch.Length >= m_LodAllocatedBudget;

        bool HasEditorPagedLodSource()
        {
            if (!UsesPagedLod || hasMismatchedLodSplatOrder)
                return false;
            foreach (var entry in m_PagedScene.pages)
            {
                var page = entry.pageAsset;
                var data = page != null ? page.splatData : null;
                if (page != null && page.IsValid && data != null && data.posData != null &&
                    data.otherData != null && data.shData != null && data.colorData != null)
                    return data.shFormat < GaussianSplatAsset.SHFormat.Cluster64k;
            }
            return false;
        }

        bool EnsureEditorPagedLodReady(bool forceRebuild = false, bool forceRetry = false)
        {
            if (this == null || Application.isPlaying || UnityEditor.EditorApplication.isPlayingOrWillChangePlaymode ||
                !isActiveAndEnabled || !UsesPagedLod || m_EditorLodRecovering ||
                UnityEditor.EditorApplication.isCompiling || UnityEditor.EditorApplication.isUpdating ||
                !SystemInfo.supportsComputeShaders)
                return false;

            if (forceRebuild)
                HookEditorUpdates();
            var system = GaussianSplatRenderSystem.instance;
            bool sourceMatches = m_PrevPagedScene == m_PagedScene && m_LodStreamer != null &&
                m_LodStreamer.pagedScene == m_PagedScene;
            bool materialsReady = m_ShaderSplats != null && m_CSBoxUtil != null &&
                m_MatSplats != null && m_MatComposite != null && m_MatSplats.shader == m_ShaderSplats &&
                m_MatComposite.shader == m_ShaderSplats && m_KernelIndices != null && m_Sorter != null;
            if (!forceRebuild && sourceMatches && materialsReady && HasEditorPagedLodResources)
            {
                if (!system.IsRegistered(this))
                    system.RegisterSplat(this);
                return true;
            }

            // Source switches must stop drawing the previous atlas immediately, even while
            // the next import/recovery attempt is throttled. Keep its buffers until replacement.
            if (!sourceMatches)
                system.UnregisterSplat(this);

            double now = UnityEditor.EditorApplication.timeSinceStartup;
            if (!forceRetry && now < m_EditorLodNextRecoveryTime)
                return false;
            m_EditorLodNextRecoveryTime = now + 1.0;
            // Import can temporarily leave the manifest's payload references unavailable. Wait
            // for usable source data before touching a previous preview or reporting success.
            if (!HasEditorPagedLodSource())
            {
                system.UnregisterSplat(this);
                return false;
            }

            m_EditorLodRecovering = true;
            bool wasModified = editModified;
            try
            {
                EditorResolveShaders(logMissing: false);
                if (m_ShaderSplats == null || m_CSBoxUtil == null)
                    return false;
                CancelEditorPagedLodWarmup();
                system.UnregisterSplat(this);
                // Cancels/disposes the worker before page residency is released. Its immutable
                // tree snapshot remains owned by that worker until cooperative cancellation ends.
                DisposeResourcesForAsset();
                DestroyRenderMaterials();
                InitializeKernels();
                m_MatSplats = new Material(m_ShaderSplats) { name = "GaussianSplats" };
                m_MatComposite = new Material(m_ShaderSplats) { name = "GaussianComposite" };
                GaussianSplatRenderSystem.BindDefaultDrawMaterial(m_MatSplats);
                GaussianSplatRenderSystem.BindDefaultDrawMaterial(m_MatComposite);
                ConfigureRelightMaterialsIfNeeded();
                var sortShader = m_CSBoxUtilSort != null ? m_CSBoxUtilSort : m_CSBoxUtil;
                m_Sorter = new GpuSorting(sortShader);
                m_FrameCounter = 0;
                // Update must not tear down the fresh preview a second time on its next tick.
                m_PrevPagedScene = m_PagedScene;
                m_PrevAsset = null;
                m_PrevHash = default;
                CreateResourcesForAsset();
                editModified = wasModified || pagedLodEraseStrokeCount > 0;
                if (!HasEditorPagedLodResources)
                    return false;
                system.RegisterSplat(this);
                ScheduleEditorPagedLodWarmup();
                UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
                UnityEditor.SceneView.RepaintAll();
                m_EditorLodLastRecoveryError = null;
                return true;
            }
            catch (System.Exception exception)
            {
                // A malformed payload or allocation failure must not leave half a preview
                // registered or repeatedly throw from EditorApplication.update.
                system.UnregisterSplat(this);
                DisposeResourcesForAsset();
                DestroyRenderMaterials();
                editModified = wasModified || pagedLodEraseStrokeCount > 0;
                m_EditorLodNextRecoveryTime = UnityEditor.EditorApplication.timeSinceStartup + 5.0;
                string failure = exception.GetType().Name + ": " + exception.Message;
                if (m_EditorLodLastRecoveryError != failure)
                {
                    m_EditorLodLastRecoveryError = failure;
                    Debug.LogWarning("SplatBoxRenderer: editor paged preview could not initialize; " +
                        "it will retry. " + failure, this);
                }
                return false;
            }
            finally
            {
                m_EditorLodRecovering = false;
            }
        }
#endif
    }
}
