// SPDX-License-Identifier: MIT
using System.Collections.Generic;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        GraphicsBuffer m_GpuPagedAttractorOffsets, m_GpuPagedAttractorEmpty;
        static readonly Vector3[] s_PagedAttractorZeros = new Vector3[4096];

        struct PagedAttractorUpload
        {
            public SplatBoxPageGpuState page;
            public PagedAttractorState state;
            public int revision, count;
        }

        readonly Dictionary<int, PagedAttractorUpload> m_PagedAttractorUploads =
            new Dictionary<int, PagedAttractorUpload>();
        readonly List<int> m_PagedAttractorUploadInvalidations = new List<int>();
        // Conservative union of addresses which have ever received CPU offsets in this atlas.
        // Keeping cleared addresses here is safe; the upload cache prevents repeated clears.
        readonly List<Vector2Int> m_PagedAttractorWrittenRanges = new List<Vector2Int>();
        NativeArray<float3> m_PagedAttractorUploadStaging;
        readonly List<Vector2Int> m_PagedAttractorPendingUploads = new List<Vector2Int>();
        bool m_PagedAttractorBatchUploads;
        const int kPagedAttractorBatchMinimum = 8;
        const int kPagedAttractorMergeGap = 4096;
        long m_PagedAttractorGpuUploadCalls, m_PagedAttractorGpuUploadedBytes;
        long m_PagedAttractorGpuClearDispatches;

        bool PagedAttractorOffsetsValid => UsesPagedLod && HasPagedAttractorState &&
            m_GpuPagedAttractorOffsets != null && m_GpuPagedAttractorOffsets.IsValid() &&
            m_GpuPagedAttractorOffsets.count == m_LodAtlasCapacity;

        bool EnsurePagedAttractorGpuBuffer()
        {
            if (!UsesPagedLod || !HasPagedAttractorState || m_LodAtlasCapacity <= 0 ||
                m_GpuLodUnifiedPos == null) return false;
            if (PagedAttractorOffsetsValid) return true;
            DisposePagedAttractorGpuBuffer();
            m_GpuPagedAttractorOffsets = new GraphicsBuffer(GraphicsBuffer.Target.Structured,
                m_LodAtlasCapacity, sizeof(float) * 3) { name = "PagedAttractorOffsets" };
            // Include padding and unused detail slots without thousands of small SetData calls.
            ClearPagedAttractorGpuRange(0, m_LodAtlasCapacity);
            UploadResidentPagedAttractorOffsets();
            return true;
        }

        void UploadResidentPagedAttractorOffsets()
        {
            var pages = m_LodStreamer?.loadedPages;
            if (pages == null) return;
            bool batch = ShouldBatchPagedAttractorUploads(pages);
            if (batch) EnsurePagedAttractorUploadStaging();
            m_PagedAttractorBatchUploads = batch;
            try
            {
                for (int i = 0; i < pages.Count; i++)
                {
                    var page = pages[i];
                    if (HasUploadedPagedEraseRange(page))
                        UploadPagedAttractorRange(page, page.atlasOffset,
                            Mathf.Min(page.splatCount, m_LodAtlasCapacity - page.atlasOffset));
                }
            }
            finally
            {
                m_PagedAttractorBatchUploads = false;
                FlushPagedAttractorUploads();
            }
        }

        bool PagedAttractorUploadIsCurrent(SplatBoxPageGpuState page, PagedAttractorState state,
            int atlasOffset, int count) =>
            m_PagedAttractorUploads.TryGetValue(atlasOffset, out var previous) &&
            ReferenceEquals(previous.page, page) && ReferenceEquals(previous.state, state) &&
            previous.revision == (state != null ? state.revision : 0) && previous.count == count;

        bool ShouldBatchPagedAttractorUploads(IReadOnlyList<SplatBoxPageGpuState> pages)
        {
            int dirty = 0, first = int.MaxValue, end = 0;
            long total = 0;
            for (int i = 0; i < pages.Count; i++)
            {
                var page = pages[i];
                if (!HasUploadedPagedEraseRange(page)) continue;
                var state = FindPagedAttractorState(page);
                if (state == null) continue;
                int count = Mathf.Min(page.splatCount, m_LodAtlasCapacity - page.atlasOffset);
                if (count <= 0 || PagedAttractorUploadIsCurrent(page, state, page.atlasOffset, count)) continue;
                int copied = Mathf.Min(count, state.count);
                if (copied <= 0) continue;
                dirty++;
                first = Mathf.Min(first, page.atlasOffset);
                end = Mathf.Max(end, page.atlasOffset + copied);
                total += copied;
            }
            // Small/local effects keep the direct path and never allocate an atlas-sized mirror.
            return dirty >= kPagedAttractorBatchMinimum &&
                end - (long)first <= total + (long)(dirty - 1) * kPagedAttractorMergeGap;
        }

        void EnsurePagedAttractorUploadStaging()
        {
            if (m_PagedAttractorUploadStaging.IsCreated) return;
            m_PagedAttractorUploadStaging = new NativeArray<float3>(m_LodAtlasCapacity,
                Allocator.Persistent, NativeArrayOptions.ClearMemory);
            // Cached owners can outlive residency. Preserve their values too, since a returning
            // unchanged page may legitimately skip replay. Unowned gaps are unused atlas padding.
            foreach (var pair in m_PagedAttractorUploads)
            {
                var state = pair.Value.state;
                if (state == null) continue;
                int count = Mathf.Min(pair.Value.count, state.count);
                if (count <= 0) continue;
                state.job.Complete();
                NativeArray<float3>.Copy(state.offsets, 0, m_PagedAttractorUploadStaging, pair.Key, count);
            }
        }

        void FlushPagedAttractorUploads()
        {
            if (m_PagedAttractorPendingUploads.Count == 0) return;
            m_PagedAttractorPendingUploads.Sort((a, b) => a.x.CompareTo(b.x));
            int start = m_PagedAttractorPendingUploads[0].x;
            int end = m_PagedAttractorPendingUploads[0].y;
            try
            {
                for (int i = 1; i < m_PagedAttractorPendingUploads.Count; i++)
                {
                    var range = m_PagedAttractorPendingUploads[i];
                    if (range.x - (long)end <= kPagedAttractorMergeGap)
                    {
                        end = Mathf.Max(end, range.y);
                        continue;
                    }
                    UploadPagedAttractorStagedRange(start, end - start);
                    start = range.x;
                    end = range.y;
                }
                UploadPagedAttractorStagedRange(start, end - start);
            }
            catch
            {
                // A failed publication must not let the revision cache skip the next retry.
                m_PagedAttractorUploads.Clear();
                throw;
            }
            finally { m_PagedAttractorPendingUploads.Clear(); }
        }

        void UploadPagedAttractorStagedRange(int offset, int count)
        {
            m_GpuPagedAttractorOffsets.SetData(m_PagedAttractorUploadStaging, offset, offset, count);
            m_PagedAttractorGpuUploadCalls++;
            m_PagedAttractorGpuUploadedBytes += (long)count * sizeof(float) * 3;
        }

        void UploadPagedAttractorRange(SplatBoxPageGpuState page, int atlasOffset, int count)
        {
            if (count <= 0 || atlasOffset < 0) return;
            var state = FindPagedAttractorState(page);
            int revision = state != null ? state.revision : 0;
            if (PagedAttractorUploadIsCurrent(page, state, atlasOffset, count)) return;

            // Atlas compaction and coarse/detail replacement can overwrite part of another
            // cached range. Its old revision must not let a later replay skip restoring it.
            m_PagedAttractorUploadInvalidations.Clear();
            foreach (var pair in m_PagedAttractorUploads)
                if (pair.Key < atlasOffset + count && atlasOffset < pair.Key + pair.Value.count)
                    m_PagedAttractorUploadInvalidations.Add(pair.Key);
            foreach (int key in m_PagedAttractorUploadInvalidations)
                m_PagedAttractorUploads.Remove(key);

            int copied = state != null ? Mathf.Min(count, state.count) : 0;
            if (copied < count && PagedAttractorRangeWasWritten(atlasOffset + copied, count - copied))
                ClearPagedAttractorGpuRange(atlasOffset + copied, count - copied);
            if (copied > 0)
            {
                state.job.Complete();
                if (m_PagedAttractorUploadStaging.IsCreated)
                    NativeArray<float3>.Copy(state.offsets, 0, m_PagedAttractorUploadStaging, atlasOffset, copied);
                if (m_PagedAttractorBatchUploads)
                    m_PagedAttractorPendingUploads.Add(new Vector2Int(atlasOffset, atlasOffset + copied));
                else
                {
                    m_GpuPagedAttractorOffsets.SetData(state.offsets, 0, atlasOffset, copied);
                    m_PagedAttractorGpuUploadCalls++;
                    m_PagedAttractorGpuUploadedBytes += (long)copied * sizeof(float) * 3;
                }
                MarkPagedAttractorRangeWritten(atlasOffset, copied);
            }
            m_PagedAttractorUploads[atlasOffset] = new PagedAttractorUpload
            {
                page = page, state = state, revision = revision, count = count
            };
        }

        bool PagedAttractorRangeWasWritten(int offset, int count)
        {
            foreach (var range in m_PagedAttractorWrittenRanges)
                if (range.x < offset + count && offset < range.y) return true;
            return false;
        }

        void MarkPagedAttractorRangeWritten(int offset, int count)
        {
            int end = offset + count;
            for (int i = m_PagedAttractorWrittenRanges.Count - 1; i >= 0; i--)
            {
                var range = m_PagedAttractorWrittenRanges[i];
                if (range.x > end || offset > range.y) continue;
                offset = Mathf.Min(offset, range.x);
                end = Mathf.Max(end, range.y);
                m_PagedAttractorWrittenRanges.RemoveAt(i);
            }
            m_PagedAttractorWrittenRanges.Add(new Vector2Int(offset, end));
        }

        unsafe void ClearPagedAttractorGpuRange(int offset, int count)
        {
            if (count <= 0) return;
            if (m_PagedAttractorUploadStaging.IsCreated)
                UnsafeUtility.MemClear((float3*)NativeArrayUnsafeUtility.GetUnsafePtr(m_PagedAttractorUploadStaging) + offset,
                    (long)count * sizeof(float) * 3);
            if (m_PagedAttractorBatchUploads)
            {
                m_PagedAttractorPendingUploads.Add(new Vector2Int(offset, offset + count));
                return;
            }
            uint groupSize = 0;
            if (FindPagedSmudgeKernels())
                m_CSBoxUtil.GetKernelThreadGroupSizes(m_PagedSmudgeClearKernel, out groupSize, out _, out _);
            if (groupSize > 0)
            {
                using var clear = new CommandBuffer { name = "Clear Paged Attractor Offsets" };
                DispatchPagedSmudgeRange(clear, m_PagedSmudgeClearKernel, offset, count,
                    m_GpuPagedAttractorOffsets);
                // Execute before direct SetData uploads. Appending this to the caller's page
                // copy command would clear offsets after those uploads had already happened.
                Graphics.ExecuteCommandBuffer(clear);
                m_PagedAttractorGpuClearDispatches += (count + (long)groupSize * 65535 - 1) /
                    ((long)groupSize * 65535);
                return;
            }
            // Also support setup before a compute shader has been assigned.
            for (int i = 0; i < count; i += s_PagedAttractorZeros.Length)
            {
                int batch = Mathf.Min(s_PagedAttractorZeros.Length, count - i);
                m_GpuPagedAttractorOffsets.SetData(s_PagedAttractorZeros, 0, offset + i, batch);
                m_PagedAttractorGpuUploadCalls++;
                m_PagedAttractorGpuUploadedBytes += (long)batch * sizeof(float) * 3;
            }
        }

        // Called after a CPU simulation step or reset. State belongs to source page indices;
        // this buffer is only the current atlas projection and can be rebuilt at any time.
        void RefreshPagedAttractorGpuOffsets()
        {
            if (!HasPagedAttractorState) DisposePagedAttractorGpuBuffer();
            else if (PagedAttractorOffsetsValid) UploadResidentPagedAttractorOffsets();
            else EnsurePagedAttractorGpuBuffer();
            ForceResort();
            m_HasSortedLodSelection = false;
#if UNITY_EDITOR
            m_HasEditorLodSortedView = false;
#endif
            InvalidatePagedLodEraseView();
        }

        void ReplayPagedAttractorPage(CommandBuffer cmd, SplatBoxPageGpuState page, int atlasOffset)
        {
            if (page == null || atlasOffset < 0 || page.splatCount <= 0 ||
                !EnsurePagedAttractorGpuBuffer()) return;
            int count = Mathf.Min(page.splatCount, m_LodAtlasCapacity - atlasOffset);
            if (count > 0)
                UploadPagedAttractorRange(page, atlasOffset, count);
        }

        GraphicsBuffer GetPagedAttractorEmptyBuffer()
        {
            if (m_GpuPagedAttractorEmpty == null || !m_GpuPagedAttractorEmpty.IsValid())
            {
                m_GpuPagedAttractorEmpty = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                    sizeof(float) * 3) { name = "PagedAttractorEmpty" };
                m_GpuPagedAttractorEmpty.SetData(s_PagedAttractorZeros, 0, 0, 1);
            }
            return m_GpuPagedAttractorEmpty;
        }

        void BindPagedAttractorOnKernel(int kernel)
        {
            if (m_CSBoxUtil == null || kernel < 0) return;
            bool valid = PagedAttractorOffsetsValid || MonolithicPhysicsOffsetsValid;
            m_CSBoxUtil.SetBuffer(kernel, "_PagedAttractorOffsets",
                valid ? (UsesPagedLod ? m_GpuPagedAttractorOffsets : m_GpuPhysicsOffsets) : GetPagedAttractorEmptyBuffer());
            m_CSBoxUtil.SetInt("_PagedAttractorValid", valid ? 1 : 0);
        }

        void BindPagedAttractorOnCS(CommandBuffer cmd, int kernel)
        {
            if (m_CSBoxUtil == null || kernel < 0) return;
            EnsurePagedAttractorGpuBuffer();
            bool valid = PagedAttractorOffsetsValid || MonolithicPhysicsOffsetsValid;
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedAttractorOffsets",
                valid ? (UsesPagedLod ? m_GpuPagedAttractorOffsets : m_GpuPhysicsOffsets) : GetPagedAttractorEmptyBuffer());
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedAttractorValid", valid ? 1 : 0);
        }

        void DisposePagedAttractorGpuBuffer()
        {
            DisposeBuffer(ref m_GpuPagedAttractorOffsets);
            m_PagedAttractorUploads.Clear();
            m_PagedAttractorUploadInvalidations.Clear();
            m_PagedAttractorWrittenRanges.Clear();
            if (m_PagedAttractorUploadStaging.IsCreated) m_PagedAttractorUploadStaging.Dispose();
            m_PagedAttractorPendingUploads.Clear();
            m_PagedAttractorBatchUploads = false;
        }
        void DisposePagedAttractorGpuEmpty() => DisposeBuffer(ref m_GpuPagedAttractorEmpty);
    }
}
