// SPDX-License-Identifier: MIT
using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        // Paint writes literal positions/scales and requires an uncompressed writable texture.
        // Paged and compressed sources instead paint into the editor's separate stroke object.
        public bool SupportsInPlacePaint => !UsesPagedLod && asset != null && asset.chunkData == null &&
            asset.posFormat == GaussianSplatAsset.VectorFormat.Float32 &&
            asset.scaleFormat == GaussianSplatAsset.VectorFormat.Float32 &&
            asset.colorFormat == GaussianSplatAsset.ColorFormat.Float32x4 &&
            asset.shFormat == GaussianSplatAsset.SHFormat.Float32;

        bool ValidPaintQuery(Camera camera, Vector2 pixel, float radius) =>
            HasValidAsset && HasValidRenderSetup && activeSplatCount > 0 && camera != null &&
            camera.pixelWidth > 0 && camera.pixelHeight > 0 &&
            PagedEraseFinite(pixel.x) && PagedEraseFinite(pixel.y) && PagedEraseFinite(radius) && radius > 0;

        void BindPaintQuery(CommandBuffer cmd, KernelIndices kind, Camera camera, Vector2 pixel, float radius)
        {
            if (UsesPagedLod) EnsurePagedLodEraseState(cmd);
            SetAssetDataOnCS(cmd, kind);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_PaintQueryVP", camera.projectionMatrix * camera.worldToCameraMatrix);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmd.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, new Vector4(camera.pixelWidth, camera.pixelHeight, 0, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PaintQueryCircle", new Vector4(pixel.x, pixel.y, radius, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PaintQueryNearFar", new Vector4(camera.nearClipPlane, camera.farClipPlane, 0, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PaintQueryCameraPos", camera.transform.position);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PaintQueryCameraForward", camera.transform.forward);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PaintQueryDepthBuckets", 1);
        }

        void DispatchPaintQuery(CommandBuffer cmd, int kernel, int count)
        {
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            cmd.DispatchCompute(m_CSBoxUtil, kernel, (int)((count + groupSize - 1) / groupSize), 1, 1);
            Graphics.ExecuteCommandBuffer(cmd);
        }

        /// <summary>Camera-forward depth at a bottom-left camera-local pixel, with packed and paged decoding.</summary>
        public bool TryGetPaintSurfaceDepth(Camera camera, Vector2 screenPixels, float radius, out float depth)
            => TryGetSurfaceDepth(camera, screenPixels, radius, 1, out depth);

        /// <summary>Prefers splats under the cursor, then the front surface at that pixel.</summary>
        public bool TryGetSculptSurfaceDepth(Camera camera, Vector2 screenPixels, float radius, out float depth)
            => TryGetSurfaceDepth(camera, screenPixels, radius, 8, out depth);

        bool TryGetSurfaceDepth(Camera camera, Vector2 screenPixels, float radius, int buckets, out float depth)
        {
            depth = 0;
            if (!ValidPaintQuery(camera, screenPixels, radius)) return false;
            int kernel = GetKernelIndex(KernelIndices.PaintFindDepth);
            if (kernel < 0) return false;
            using var minimum = new GraphicsBuffer(GraphicsBuffer.Target.Structured, buckets, sizeof(uint));
            var data = new uint[buckets];
            for (int i = 0; i < buckets; i++) data[i] = uint.MaxValue;
            minimum.SetData(data);
            using var cmd = new CommandBuffer { name = "Find paint surface" };
            BindPaintQuery(cmd, KernelIndices.PaintFindDepth, camera, screenPixels, radius);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PaintQueryDepthBuckets", buckets);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PaintQueryCounter", minimum);
            DispatchPaintQuery(cmd, kernel, activeSplatCount);
            minimum.GetData(data);
            foreach (uint value in data)
            {
                if (value == uint.MaxValue) continue;
                depth = BitConverter.ToSingle(BitConverter.GetBytes(value), 0);
                return PagedEraseFinite(depth) && depth > 0;
            }
            return false;
        }

        /// <summary>Reads at most output.Length base colors near the picked surface, including alpha.</summary>
        public bool SamplePaintColors(Camera camera, Vector2 screenPixels, float radius, float surfaceDepth,
            float depthTolerance, Color[] output, out int count)
        {
            count = 0;
            if (!ValidPaintQuery(camera, screenPixels, radius) || output == null || output.Length == 0 ||
                !PagedEraseFinite(surfaceDepth) || surfaceDepth <= 0 || !PagedEraseFinite(depthTolerance) || depthTolerance < 0)
                return false;
            int kernel = GetKernelIndex(KernelIndices.PaintSampleColors);
            if (kernel < 0) return false;
            int capacity = Math.Min(output.Length, 4096);
            using var colors = new GraphicsBuffer(GraphicsBuffer.Target.Structured, capacity, sizeof(float) * 4);
            using var counter = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(uint));
            var data = new uint[1]; counter.SetData(data);
            using var cmd = new CommandBuffer { name = "Sample paint colors" };
            BindPaintQuery(cmd, KernelIndices.PaintSampleColors, camera, screenPixels, radius);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PaintQueryCounter", counter);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PaintQueryColors", colors);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PaintQueryCapacity", capacity);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_PaintQueryDepth", new Vector4(surfaceDepth, depthTolerance, 0, 0));
            DispatchPaintQuery(cmd, kernel, activeSplatCount);
            counter.GetData(data);
            count = (int)Math.Min(data[0], (uint)capacity);
            if (count > 0) colors.GetData(output, 0, 0, count);
            return true;
        }

        /// <summary>Exports an explicit painted range in InputSplatData's interleaved SH layout.</summary>
        public bool ExportPaintSplats(GraphicsBuffer output, int startIndex, int count)
        {
            if (!SupportsInPlacePaint || !HasValidRenderSetup || startIndex < 0 || count <= 0 ||
                count > splatCount - startIndex || output == null || !output.IsValid() ||
                output.count < count || output.stride != 248) return false;
            int kernel = GetKernelIndex(KernelIndices.PaintExport);
            if (kernel < 0) return false;
            using var cmd = new CommandBuffer { name = "Export painted stroke" };
            SetAssetDataOnCS(cmd, KernelIndices.PaintExport);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_FillExportBuffer", output);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PaintExportStart", startIndex);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PaintExportCount", count);
            DispatchPaintQuery(cmd, kernel, count);
            return true;
        }

        void BindPaintWrites(CommandBuffer cmd, int kernel)
        {
            // Queries can leave a compressed source's chunk count on the shared compute shader.
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatSH, m_GpuSHData);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PaintSHStride", 192);
        }
    }
}
