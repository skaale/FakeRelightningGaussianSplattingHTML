// SPDX-License-Identifier: MIT
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        GraphicsBuffer m_GpuPhysicsOffsets;
        int m_PhysicsTick;
#if UNITY_EDITOR
        double m_LastEditorPhysicsTick = -1;
#endif

        bool MonolithicPhysicsOffsetsValid => !UsesPagedLod && m_GpuPhysicsOffsets != null &&
            m_GpuPhysicsOffsets.IsValid() && m_GpuPhysicsOffsets.count == m_SplatCount;

        void EnsurePhysicsOffsets()
        {
            if (UsesPagedLod || m_SplatCount <= 0 || asset == null ||
                (!m_GpuChunksValid && asset.posFormat == GaussianSplatAsset.VectorFormat.Float32) ||
                MonolithicPhysicsOffsetsValid) return;

            DisposeBuffer(ref m_GpuPhysicsOffsets);
            m_GpuPhysicsOffsets = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12)
                { name = "MonolithicPhysicsOffsets" };
            uint groupSize = 0;
            if (FindPagedSmudgeKernels())
                m_CSBoxUtil.GetKernelThreadGroupSizes(m_PagedSmudgeClearKernel, out groupSize, out _, out _);
            if (groupSize > 0)
            {
                using var clear = new CommandBuffer { name = "Initialize Physics Offsets" };
                // The paged dispatch helper clamps to atlas capacity, which is zero for monolithic assets.
                clear.SetComputeBufferParam(m_CSBoxUtil, m_PagedSmudgeClearKernel, "_PagedSmudgeWrite", m_GpuPhysicsOffsets);
                clear.SetComputeIntParam(m_CSBoxUtil, "_PagedSculptWriteBase", 0);
                int maximumDispatch = (int)groupSize * 65535;
                for (int offset = 0; offset < m_SplatCount; offset += maximumDispatch)
                {
                    int count = Mathf.Min(maximumDispatch, m_SplatCount - offset);
                    clear.SetComputeIntParam(m_CSBoxUtil, "_PagedSmudgeOffset", offset);
                    clear.SetComputeIntParam(m_CSBoxUtil, "_PagedSmudgeCount", count);
                    clear.DispatchCompute(m_CSBoxUtil, m_PagedSmudgeClearKernel,
                        (count + (int)groupSize - 1) / (int)groupSize, 1, 1);
                }
                Graphics.ExecuteCommandBuffer(clear);
            }
            else
            {
                for (int i = 0; i < m_SplatCount; i += s_PagedAttractorZeros.Length)
                    m_GpuPhysicsOffsets.SetData(s_PagedAttractorZeros, 0, i,
                        Mathf.Min(s_PagedAttractorZeros.Length, m_SplatCount - i));
            }
        }

        void BindPhysicsOffsetsOnCS(CommandBuffer cmd, int kernel)
        {
            bool valid = MonolithicPhysicsOffsetsValid;
            cmd.SetComputeIntParam(m_CSBoxUtil, "_UseSplatPhysicsOffsets", valid ? 1 : 0);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_SplatPhysicsOffsets",
                valid ? m_GpuPhysicsOffsets : GetPagedAttractorEmptyBuffer());
        }

        void TickMonolithicPhysics()
        {
            if (UsesPagedLod || (!m_EnablePhysics && !m_EnableWind) || !HasValidAsset || !HasValidRenderSetup)
                return;
            if (m_GpuSplatVelocities == null || m_GpuSplatPrevPositions == null)
                CreatePhysicsBuffers();
            // Forces must run without an open editor window or a scene mouse event.
            if (m_EnableWind && m_PhysicsTick++ % Mathf.Max(1, m_WindUpdateEveryNthFrame) == 0)
                UpdateWindEffects();
            if (m_EnablePhysics) UpdatePhysics();
            ForceResort();
            // Edit-mode frameCount can stay unchanged between simulation ticks, and mobile
            // stable sorting otherwise keeps the old order while the camera is stationary.
            m_HasSortOrderCamera = false;
        }

#if UNITY_EDITOR
        void TickEditorMonolithicPhysics()
        {
            if (UsesPagedLod || (!m_EnablePhysics && !m_EnableWind)) return;
            double now = UnityEditor.EditorApplication.timeSinceStartup;
            if (now - m_LastEditorPhysicsTick < 1.0 / 60.0) return;
            m_LastEditorPhysicsTick = now;
            TickMonolithicPhysics();
            UnityEditor.SceneView.RepaintAll();
        }
#endif
    }
}
