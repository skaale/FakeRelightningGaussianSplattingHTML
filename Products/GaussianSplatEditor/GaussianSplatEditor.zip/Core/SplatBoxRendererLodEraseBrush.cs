// SPDX-License-Identifier: MIT

using System;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        /// <summary>
        /// Finds the front displayed splat near a camera-local pixel (bottom-left origin).
        /// Returns forward-axis depth in metres for perspective and orthographic cameras.
        /// </summary>
        public bool TryGetPagedFillSurfaceDepth(Camera camera, Vector2 screenPixels, float radius, out float depth)
        {
            depth = 0;
            if (!UsesPagedLod || !HasValidRenderSetup || activeSplatCount <= 0 || camera == null ||
                camera.pixelWidth <= 0 || camera.pixelHeight <= 0 ||
                !PagedEraseFinite(screenPixels.x) || !PagedEraseFinite(screenPixels.y) ||
                !PagedEraseFinite(radius) || radius <= 0) return false;
            int kernel = GetKernelIndex(KernelIndices.PolygonFillFindDepth);
            if (kernel < 0) return false;
            using var minimum = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(uint));
            var readback = new[] { uint.MaxValue };
            minimum.SetData(readback);
            using var cmd = new CommandBuffer { name = "Find paged polygon fill surface" };
            EnsurePagedLodEraseState(cmd);
            SetAssetDataOnCS(cmd, KernelIndices.PolygonFillFindDepth);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_FillPickDepth", minimum);
            // Camera.projectionMatrix matches WorldToScreenPoint; a GPU projection would
            // invert the pixel Y coordinate on some graphics APIs.
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_FillPickViewProjection", camera.projectionMatrix * camera.worldToCameraMatrix);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmd.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, new Vector4(camera.pixelWidth, camera.pixelHeight, 0, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_FillPickCircle", new Vector4(screenPixels.x, screenPixels.y, radius, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_FillPickNearFar", new Vector4(camera.nearClipPlane, camera.farClipPlane, 0, 0));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_FillPickCameraPosition", camera.transform.position);
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_FillPickCameraForward", camera.transform.forward);
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize == 0) return false;
            cmd.DispatchCompute(m_CSBoxUtil, kernel, (int)((activeSplatCount + groupSize - 1) / groupSize), 1, 1);
            Graphics.ExecuteCommandBuffer(cmd);
            minimum.GetData(readback);
            if (readback[0] == uint.MaxValue) return false;
            depth = BitConverter.ToSingle(BitConverter.GetBytes(readback[0]), 0);
            return PagedEraseFinite(depth) && depth > 0;
        }

        /// <summary>Projects a planar world-space polygon into an orthonormal, metre-sized frame.</summary>
        public static bool TryBuildPagedPolygonFrame(Vector3[] worldVertices, Vector3 worldNormal,
            out Matrix4x4 worldToPlane, out Vector2[] polygon)
        {
            worldToPlane = Matrix4x4.identity;
            polygon = null;
            if (worldVertices == null || worldVertices.Length < 3 || worldVertices.Length > 128 ||
                !PagedEraseFinite(worldNormal) || !PagedEraseFinite(worldNormal.sqrMagnitude) || worldNormal.sqrMagnitude < 1e-12f) return false;
            Vector3 center = Vector3.zero;
            foreach (var vertex in worldVertices)
            {
                if (!PagedEraseFinite(vertex)) return false;
                center += vertex;
            }
            center /= worldVertices.Length;
            if (!PagedEraseFinite(center)) return false;
            Vector3 normal = worldNormal.normalized;
            Vector3 tangent = Vector3.zero;
            for (int i = 1; i < worldVertices.Length && tangent.sqrMagnitude < 1e-12f; ++i)
                tangent = Vector3.ProjectOnPlane(worldVertices[i] - worldVertices[0], normal);
            if (!PagedEraseFinite(tangent.sqrMagnitude) || tangent.sqrMagnitude < 1e-12f) return false;
            tangent.Normalize();
            Vector3 bitangent = Vector3.Cross(normal, tangent).normalized;
            worldToPlane = Matrix4x4.TRS(center, Quaternion.LookRotation(normal, bitangent), Vector3.one).inverse;
            var projected = new Vector2[worldVertices.Length];
            for (int i = 0; i < projected.Length; ++i)
            {
                Vector3 value = worldToPlane.MultiplyPoint3x4(worldVertices[i]);
                if (!PagedEraseFinite(value)) return false;
                projected[i] = new Vector2(value.x, value.y);
            }
            double area = 0;
            for (int i = 0; i < projected.Length; ++i)
            {
                var a = projected[i]; var b = projected[(i + 1) % projected.Length];
                area += (double)a.x * b.y - (double)b.x * a.y;
            }
            if (Math.Abs(area) < 1e-10) return false;
            polygon = projected;
            return true;
        }

        /// <summary>
        /// Samples displayed paged splats in a band around the polygon edges. Selection depth
        /// is total thickness about the polygon plane. Output uses InputSplatData's interleaved SH layout.
        /// </summary>
        public bool ExportPagedPolygonSamples(Vector3[] worldVertices, Vector3 worldNormal,
            float selectionDepth, float edgeWidth, GraphicsBuffer output, out int count)
        {
            count = 0;
            if (!UsesPagedLod || !HasValidRenderSetup || activeSplatCount <= 0 || output == null || !output.IsValid() ||
                !PagedEraseFinite(selectionDepth) || selectionDepth <= 0 || !PagedEraseFinite(edgeWidth) || edgeWidth <= 0 ||
                !TryBuildPagedPolygonFrame(worldVertices, worldNormal, out var worldToPlane, out var polygon)) return false;
            int kernel = GetKernelIndex(KernelIndices.PolygonFillExport);
            if (kernel < 0) return false;
            using var vertices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, polygon.Length, sizeof(float) * 2);
            using var counter = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(uint));
            vertices.SetData(polygon); counter.SetData(new uint[1]);
            using var cmd = new CommandBuffer { name = "Sample paged polygon fill edges" };
            EnsurePagedLodEraseState(cmd);
            SetAssetDataOnCS(cmd, KernelIndices.PolygonFillExport);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_PagedPolygonVertices", vertices);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_PagedPolygonCount", polygon.Length);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_CloneCount", counter);
            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_FillExportBuffer", output);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_CloneCapacity", output.count);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_FillWorldToPlane", worldToPlane);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_FillHalfDepth", selectionDepth * 0.5f);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_FillEdgeWidth", edgeWidth);
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize == 0) return false;
            cmd.DispatchCompute(m_CSBoxUtil, kernel, (int)((activeSplatCount + groupSize - 1) / groupSize), 1, 1);
            Graphics.ExecuteCommandBuffer(cmd);
            var readback = new uint[1]; counter.GetData(readback);
            count = (int)Math.Min(readback[0], int.MaxValue);
            return true;
        }

        /// <summary>Records an exact polygon-prism deletion for all current and future LoD pages.</summary>
        public bool DeletePagedSplatsInPolygon(Vector3[] worldVertices, Vector3 worldNormal, float selectionDepth)
        {
            if (!UsesPagedLod || !PagedEraseFinite(selectionDepth) || selectionDepth <= 0 ||
                !TryBuildPagedPolygonFrame(worldVertices, worldNormal, out var worldToPlane, out var polygon)) return false;
            var stroke = CreatePagedLodBrushStroke(5, false, worldToPlane.inverse.MultiplyPoint3x4(Vector3.zero), 1, Vector3.zero);
            stroke.worldToShape = worldToPlane;
            stroke.polygon = polygon;
            Vector2 extent = Vector2.zero;
            foreach (var vertex in polygon) extent = Vector2.Max(extent, new Vector2(Mathf.Abs(vertex.x), Mathf.Abs(vertex.y)));
            stroke.shapeSize = new Vector4(extent.x, extent.y, selectionDepth * 0.5f, 0);
            return ApplyPagedLodErase(stroke);
        }

        /// <summary>
        /// Exports the currently displayed splats within a screen polygon, restricted to the
        /// nearest surface in each screen tile. The output stride must match ExportSplatData.
        /// </summary>
        public bool ExportPagedClone(Vector2[] polygon, Camera camera, float selectionDepth,
            GraphicsBuffer output, out int selectedCount)
        {
            selectedCount = 0;
            if (!HasValidRenderSetup || activeSplatCount <= 0 || camera == null ||
                polygon == null || polygon.Length < 3 || polygon.Length > 128 || output == null || !output.IsValid()) return false;
            int depthKernel = GetKernelIndex(KernelIndices.CloneFindDepth);
            int exportKernel = GetKernelIndex(KernelIndices.CloneExport);
            if (depthKernel < 0 || exportKernel < 0) return false;
            using var polygonBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, polygon.Length, sizeof(float) * 2);
            using var tileBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 64 * 64, sizeof(uint));
            using var countBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, sizeof(uint));
            polygonBuffer.SetData(polygon);
            var initialDepths = new uint[64 * 64];
            Array.Fill(initialDepths, uint.MaxValue);
            tileBuffer.SetData(initialDepths);
            countBuffer.SetData(new uint[1]);
            using var cmd = new CommandBuffer { name = "Select paged splats for Clone" };
            EnsurePagedLodEraseState(cmd);
            foreach (var kernel in new[] { KernelIndices.CloneFindDepth, KernelIndices.CloneExport })
            {
                SetAssetDataOnCS(cmd, kernel);
                int index = GetKernelIndex(kernel);
                cmd.SetComputeBufferParam(m_CSBoxUtil, index, "_ClonePolygon", polygonBuffer);
                cmd.SetComputeBufferParam(m_CSBoxUtil, index, "_CloneDepthTiles", tileBuffer);
            }
            cmd.SetComputeBufferParam(m_CSBoxUtil, exportKernel, "_CloneCount", countBuffer);
            cmd.SetComputeBufferParam(m_CSBoxUtil, exportKernel, "_CloneExportBuffer", output);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_ClonePolygonCount", polygon.Length);
            cmd.SetComputeIntParam(m_CSBoxUtil, "_CloneCapacity", output.count);
            cmd.SetComputeFloatParam(m_CSBoxUtil, "_CloneSelectionDepth", Mathf.Max(0.001f, selectionDepth));
            cmd.SetComputeVectorParam(m_CSBoxUtil, "_CloneNearFar", new Vector4(camera.nearClipPlane, camera.farClipPlane, 0, 0));
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_CloneViewProjection", camera.projectionMatrix * camera.worldToCameraMatrix);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, "_CloneWorldToView", camera.worldToCameraMatrix);
            cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            m_CSBoxUtil.GetKernelThreadGroupSizes(depthKernel, out uint depthGroup, out _, out _);
            m_CSBoxUtil.GetKernelThreadGroupSizes(exportKernel, out uint exportGroup, out _, out _);
            if (depthGroup == 0 || exportGroup == 0) return false;
            cmd.DispatchCompute(m_CSBoxUtil, depthKernel, (int)((activeSplatCount + depthGroup - 1) / depthGroup), 1, 1);
            cmd.DispatchCompute(m_CSBoxUtil, exportKernel, (int)((activeSplatCount + exportGroup - 1) / exportGroup), 1, 1);
            Graphics.ExecuteCommandBuffer(cmd);
            var count = new uint[1]; countBuffer.GetData(count);
            selectedCount = (int)Math.Min(count[0], int.MaxValue);
            return true;
        }

        readonly uint[] m_PagedEraseDepthReadback = new uint[1];
        // Keep backface-culling erasure close to the visible surface. Removing more
        // of a foreground surface must not also increase its reach into rear geometry.
        const float kEraseSurfaceDepth = 0.05f;

        bool ApplyPagedLodBoxErase(Vector3 center, Vector3 size, Quaternion rotation, bool restore)
        {
            float rotationLengthSquared = Quaternion.Dot(rotation, rotation);
            if (!PagedEraseFinite(center) || !PagedEraseFinite(size) || size.x <= 0 || size.y <= 0 || size.z <= 0 ||
                !PagedEraseFinite(rotationLengthSquared) || rotationLengthSquared <= 0)
                return false;
            var stroke = CreatePagedLodBrushStroke(3, restore, center, 1, Vector3.zero);
            stroke.worldToShape = Matrix4x4.TRS(center, rotation.normalized, Vector3.one).inverse;
            stroke.shapeSize = new Vector4(size.x * 0.5f, size.y * 0.5f, size.z * 0.5f, 0);
            return ApplyPagedLodErase(stroke);
        }

        bool ApplyPagedLodBoundedCylinderErase(Vector3 center, float radius, float height, Vector3 axis, bool restore)
        {
            float axisLengthSquared = axis.sqrMagnitude;
            if (!PagedEraseFinite(axis) || !PagedEraseFinite(axisLengthSquared) || axisLengthSquared <= 0)
                return false;
            var stroke = CreatePagedLodBrushStroke(4, restore, center, radius, axis);
            stroke.shapeSize = new Vector4(0, 0, 0, height * 0.5f);
            return ApplyPagedLodErase(stroke);
        }

        PagedLodEraseStroke CreatePagedLodBrushStroke(int kind, bool restore, Vector3 center,
            float radius, Vector3 direction, float falloff = 0, float noiseStrength = 0,
            float noiseScale = 1, float noiseTime = 0, bool useColor = false,
            Color color = default, float colorThreshold = 0.1f)
        {
            return new PagedLodEraseStroke
            {
                kind = kind,
                restore = restore,
                // Capture this matrix so replay follows the object after it is moved or scaled.
                objectToWorld = transform.localToWorldMatrix,
                viewProjection = Matrix4x4.identity,
                centerRadius = new Vector4(center.x, center.y, center.z, radius),
                direction = direction.normalized,
                falloffNoise = new Vector4(Mathf.Clamp01(falloff), Mathf.Clamp01(noiseStrength), noiseScale, noiseTime),
                maxDepth = float.MaxValue,
                useColor = useColor,
                color = color,
                colorThreshold = colorThreshold
            };
        }

        void RestorePagedSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam)
        {
            var stroke = CreatePagedLodBrushStroke(2, true, Vector3.zero, radiusPx, Vector3.zero);
            stroke.viewProjection = GL.GetGPUProjectionMatrix(cam.projectionMatrix, false) * cam.worldToCameraMatrix;
            stroke.screen = new Vector4(centerPx.x, centerPx.y, radiusPx, 0);
            stroke.screenSize = new Vector4(cam.pixelWidth, cam.pixelHeight, 0, 0);
            // Keep the full-depth screen footprint in the journal, including pages that are not
            // resident yet. A visible-depth query cannot find splats that have already been erased.
            ApplyPagedLodErase(stroke);
        }

        void DeletePagedSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam,
            bool backfaceCulling, float falloff, float noiseStrength, float noiseScale,
            bool useColorFilter, Color colorFilter, float colorThreshold)
        {
            if (cam == null || !HasValidAsset || !HasValidRenderSetup || activeSplatCount <= 0 ||
                radiusPx <= 0 || float.IsNaN(radiusPx) || float.IsInfinity(radiusPx))
                return;

            var stroke = CreatePagedLodBrushStroke(2, false, Vector3.zero, radiusPx, Vector3.zero,
                falloff, noiseStrength, noiseScale, Time.time, useColorFilter, colorFilter, colorThreshold);
            stroke.viewProjection = GL.GetGPUProjectionMatrix(cam.projectionMatrix, false) * cam.worldToCameraMatrix;
            stroke.screen = new Vector4(centerPx.x, centerPx.y, radiusPx, 0);
            stroke.screenSize = new Vector4(cam.pixelWidth, cam.pixelHeight, 0, 0);
            stroke.useLinearDepth = true;
            Vector3 forward = cam.transform.forward;
            stroke.depthPlane = new Vector4(forward.x, forward.y, forward.z, -Vector3.Dot(forward, cam.transform.position));

            if (backfaceCulling)
            {
                int kernel = GetKernelIndex(KernelIndices.FindEraseMinDepthInScreenCircle);
                if (kernel < 0)
                    return;
                if (m_GpuEditSelectMinDepth == null)
                    m_GpuEditSelectMinDepth = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4)
                        { name = "PagedEraseMinDepth" };
                m_PagedEraseDepthReadback[0] = FloatToSortableUint(1.0e38f);
                m_GpuEditSelectMinDepth.SetData(m_PagedEraseDepthReadback);
                using (var cmd = new CommandBuffer { name = "Paged erase visible surface" })
                {
                    // Undo may have changed the journal since the most recent rendered view.
                    EnsurePagedLodEraseState(cmd);
                    SetAssetDataOnCS(cmd, KernelIndices.FindEraseMinDepthInScreenCircle);
                    cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, "_SelectionMinDepth", m_GpuEditSelectMinDepth);
                    cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, stroke.viewProjection);
                    cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, stroke.objectToWorld);
                    cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, cam.worldToCameraMatrix * stroke.objectToWorld);
                    cmd.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, stroke.screenSize);
                    cmd.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", stroke.screen);
                    cmd.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);
                    m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
                    cmd.DispatchCompute(m_CSBoxUtil, kernel, (int)((activeSplatCount + groupSize - 1) / groupSize), 1, 1);
                    Graphics.ExecuteCommandBuffer(cmd);
                }
                // Capture the original front layer once. Recomputing on each page reload could
                // erase deeper geometry that was behind the surface when the stroke was made.
                m_GpuEditSelectMinDepth.GetData(m_PagedEraseDepthReadback);
                float depth = SortableUintToFloat(m_PagedEraseDepthReadback[0]);
                if (float.IsNaN(depth) || depth >= 1.0e37f)
                    return;
                stroke.maxDepth = depth + kEraseSurfaceDepth;
            }

            ApplyPagedLodErase(stroke);
        }
    }
}
