// SPDX-License-Identifier: MIT

using System;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// GPU-resident state for one loaded spatial page (splat buffers + LoD tree).
    /// </summary>
    public sealed class SplatBoxPageGpuState : IDisposable
    {
        public int pageId;
        public int pageSlot;
        /// <summary>Address in the unified atlas, or -1 until the page has been placed there.</summary>
        public int atlasOffset = -1;
        /// <summary>Offset this page's data was last copied to, or -1 if it still needs a copy.</summary>
        public int uploadedAtlasOffset = -1;
        /// <summary>Index into the atlas' full-detail slot pool, or -1 when the page is coarse.</summary>
        public int detailSlot = -1;
        /// <summary>
        /// Realtime timestamp of when the page acquired its detail slot. The streamer uses it to
        /// keep freshly upgraded pages from being evicted straight back by rank churn.
        /// </summary>
        public float detailAcquiredTime;
        public int splatCount;
        public int lodNodeCount;
        public Bounds bounds;
        public GaussianSplatPageAsset source;

        public GraphicsBuffer gpuPosData;
        public GraphicsBuffer gpuOtherData;
        public GraphicsBuffer gpuSHData;
        public Texture gpuColorData;
        public GraphicsBuffer gpuChunks;
        public bool gpuChunksValid;
        public GaussianSplatAsset.ChunkInfo[] chunkInfos;
        public LodTreeRuntime lodTree;
        public bool isCoarseStub;
        int m_UploadedSplatCount;
        int m_RefinementStartNodeCount;
        float m_RefinementStartTime;

        public const float RefinementDurationSeconds = 0.75f;

        public LodTreeNode[] lodTreeNodes => lodTree?.nodes;
        public int leafCount => lodTree?.leafCount ?? 0;

        public bool IsReady => gpuPosData != null && lodTree != null && lodTree.nodeCount > 0 && splatCount > 0;

        /// <summary>
        /// Limits visual refinement after a coarse page acquires its full payload. Residency and
        /// the immutable full tree stay intact; only the traversal's addressable prefix grows.
        /// </summary>
        public void BeginRefinement(int startNodeCount, float now)
        {
            int fullCount = lodTree?.nodeCount ?? 0;
            m_RefinementStartNodeCount = fullCount > 0 ? Mathf.Clamp(startNodeCount, 1, fullCount) : 0;
            m_RefinementStartTime = now;
        }

        /// <summary>
        /// Addressable tree prefix at an explicit realtime timestamp. Geometric growth gives large
        /// pages intermediate tiers instead of exposing most of their descendants in one update.
        /// </summary>
        public int RefinementNodeLimit(float now)
        {
            int fullCount = lodTree?.nodeCount ?? 0;
            int startCount = m_RefinementStartNodeCount;
            if (startCount <= 0 || startCount >= fullCount)
                return fullCount;

            float elapsed = now - m_RefinementStartTime;
            if (elapsed <= 0f)
                return startCount;
            if (elapsed >= RefinementDurationSeconds)
                return fullCount;

            double t = elapsed / RefinementDurationSeconds;
            t = t * t * (3.0 - 2.0 * t);
            int count = (int)Math.Floor(startCount * Math.Pow((double)fullCount / startCount, t));
            return Mathf.Clamp(count, startCount, fullCount - 1);
        }

        public bool HasPendingRefinement(float now)
        {
            return m_RefinementStartNodeCount > 0 &&
                   m_RefinementStartNodeCount < (lodTree?.nodeCount ?? 0) &&
                   now - m_RefinementStartTime < RefinementDurationSeconds;
        }

        public static SplatBoxPageGpuState Upload(GaussianSplatPageAsset page, int slot)
        {
            if (page == null || !page.IsValid)
                return null;

            var asset = page.splatData;
            var lodTree = LodTreeRuntime.Build(page.GetLodTreeNodes(), page.hasLevelOrderLodTree);
            if (lodTree == null)
                return null;

            var state = new SplatBoxPageGpuState
            {
                pageId = page.pageId,
                pageSlot = slot,
                splatCount = asset.splatCount,
                m_UploadedSplatCount = asset.splatCount,
                lodNodeCount = lodTree.nodeCount,
                bounds = page.bounds,
                source = page,
                lodTree = lodTree,
                isCoarseStub = false
            };

            UploadFullBuffers(state, asset);
            return state;
        }

        /// <summary>
        /// Low-detail version of a page: the top LoD levels only, which in a level-order tree are a
        /// contiguous prefix of the splat data. Keeping it a prefix means chunk-compressed formats
        /// still decode correctly, because splats stay in their original 256-splat chunks.
        /// </summary>
        public static SplatBoxPageGpuState UploadCoarseLevel(GaussianSplatPageAsset page, int slot, int maxSplats)
        {
            if (page == null || !page.IsValid)
                return null;

            // Legacy depth-first pages have no usable prefix; rebuild the scene to get a real coarse tier.
            if (!page.hasLevelOrderLodTree)
                return UploadCoarseStub(page, slot);

            var asset = page.splatData;
            if (maxSplats >= asset.splatCount)
                return Upload(page, slot);

            int count = Mathf.Min(asset.splatCount, Mathf.Max(1, maxSplats));
            var subTree = LodTreeRuntime.BuildPrefix(page.GetLodTreeNodes(count));
            if (subTree == null)
                return UploadCoarseStub(page, slot);

            count = Mathf.Min(count, subTree.nodeCount);
            var state = new SplatBoxPageGpuState
            {
                pageId = page.pageId,
                pageSlot = slot,
                splatCount = count,
                m_UploadedSplatCount = count,
                lodNodeCount = subTree.nodeCount,
                bounds = page.bounds,
                source = page,
                lodTree = subTree,
                isCoarseStub = true
            };

            UploadPrefixBuffers(state, asset, count);
            return state;
        }

        /// <summary>
        /// Adapts a coarse tree to the atlas reservation without any GPU upload. The buffers already
        /// contain this prefix; keeping the smaller tree addressable avoids holes while an atlas
        /// shrinks. A later increase can reuse the same uploaded prefix up to its original capacity.
        /// </summary>
        public bool SetCoarseSplatLimit(int maxSplats)
        {
            if (source == null || !source.hasLevelOrderLodTree || m_UploadedSplatCount <= 0)
                return false;
            int count = Mathf.Min(Mathf.Max(1, maxSplats), m_UploadedSplatCount);
            if (count == splatCount)
                return false;
            var tree = LodTreeRuntime.BuildPrefix(source.GetLodTreeNodes(count));
            if (tree == null)
                return false;
            lodTree = tree;
            splatCount = Mathf.Min(count, tree.nodeCount);
            lodNodeCount = tree.nodeCount;
            isCoarseStub = splatCount < source.splatCount;
            uploadedAtlasOffset = -1;
            return true;
        }

        /// <summary>
        /// One merged root splat per page. Only used for legacy pages that cannot supply a prefix;
        /// chunk-compressed data decodes incorrectly here, so rebuilding the scene is preferable.
        /// </summary>
        public static SplatBoxPageGpuState UploadCoarseStub(GaussianSplatPageAsset page, int slot)
        {
            if (page == null || !page.IsValid)
                return null;

            var asset = page.splatData;
            var rootNodes = page.GetLodTreeNodes(1);
            if (rootNodes == null || rootNodes.Length == 0)
                return null;

            // The stub is a single always-drawn leaf; its screen size must reflect the whole page,
            // not the averaged Gaussian scale stored on the root node.
            var root = rootNodes[0];
            root.childCount = 0;
            root.childStart = 0;
            root.featureSize = Mathf.Max(page.bounds.size.magnitude, root.featureSize);

            var stubTree = new LodTreeRuntime
            {
                nodes = new[] { root },
                childTable = new int[1],
                childTableStart = new int[1],
                leafCount = 1,
                rootExtent = root.featureSize
            };

            var state = new SplatBoxPageGpuState
            {
                pageId = page.pageId,
                pageSlot = slot,
                splatCount = 1,
                m_UploadedSplatCount = 1,
                lodNodeCount = 1,
                bounds = page.bounds,
                source = page,
                lodTree = stubTree,
                isCoarseStub = true
            };

            UploadSingleSplatBuffers(state, asset, 0);
            return state;
        }

        static void UploadFullBuffers(SplatBoxPageGpuState state, GaussianSplatAsset asset)
        {
            state.gpuPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                (int)(asset.posData.dataSize / 4), 4) { name = $"PagePos_{state.pageId}" };
            state.gpuPosData.SetData(asset.posData.GetData<uint>());

            state.gpuOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                (int)(asset.otherData.dataSize / 4), 4) { name = $"PageOther_{state.pageId}" };
            state.gpuOtherData.SetData(asset.otherData.GetData<uint>());

            state.gpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw,
                (int)(asset.shData.dataSize / 4), 4) { name = $"PageSH_{state.pageId}" };
            state.gpuSHData.SetData(asset.shData.GetData<uint>());

            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(asset.splatCount);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
            var tex = new Texture2D(texWidth, texHeight, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
            { name = $"PageColor_{state.pageId}" };
            tex.SetPixelData(asset.colorData.GetData<byte>(), 0);
            tex.Apply(false, true);
            state.gpuColorData = tex;

            if (asset.chunkData != null && asset.chunkData.dataSize != 0)
            {
                state.gpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured,
                    (int)(asset.chunkData.dataSize / UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()),
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = $"PageChunks_{state.pageId}" };
                var chunkData = asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>();
                state.gpuChunks.SetData(chunkData);
                state.chunkInfos = chunkData.ToArray();
                state.gpuChunksValid = true;
            }
            else
            {
                state.gpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = $"PageChunks_{state.pageId}" };
                state.gpuChunksValid = false;
            }
        }

        /// <summary>
        /// Uploads splats [0, count) as a contiguous range. A final partial chunk keeps its source
        /// ChunkInfo, and only the raw byte range is rounded up to whole words.
        /// </summary>
        static void UploadPrefixBuffers(SplatBoxPageGpuState state, GaussianSplatAsset asset, int count)
        {
            // Compressed vectors can occupy 2 or 6 bytes. Dividing the per-splat stride by four
            // first truncates Norm16 positions/scales and leaves the later coarse nodes reading
            // beyond the uploaded buffer. Round the byte range only after multiplying by count.
            bool clusteredSH = asset.shFormat >= GaussianSplatAsset.SHFormat.Cluster64k;
            int posWords = WordsForBytes((long)count * GaussianSplatAsset.GetVectorSize(asset.posFormat));
            int otherStride = GaussianSplatAsset.GetOtherSizeNoSHIndex(asset.scaleFormat) + (clusteredSH ? 2 : 0);
            int otherWords = WordsForBytes((long)count * otherStride);
            // Cluster indices address a shared table anywhere in the source, so that table cannot
            // be truncated in proportion to the number of resident splats.
            int shWords = clusteredSH ? (int)(asset.shData.dataSize / 4) :
                WordsForBytes(GaussianSplatAsset.CalcSHDataSize(count, asset.shFormat));

            // Slice to the prefix only. Passing the full asset NativeArray into SetData can still
            // pressure Unity's graphics ring buffer on multi-hundred-thousand-splat pages.
            var posData = asset.posData.GetData<uint>();
            state.gpuPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                posWords, 4) { name = $"PagePosCoarse_{state.pageId}" };
            state.gpuPosData.SetData(posData.GetSubArray(0, posWords));

            var otherData = asset.otherData.GetData<uint>();
            state.gpuOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                otherWords, 4) { name = $"PageOtherCoarse_{state.pageId}" };
            state.gpuOtherData.SetData(otherData.GetSubArray(0, otherWords));

            var shData = asset.shData.GetData<uint>();
            state.gpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, shWords, 4)
                { name = $"PageSHCoarse_{state.pageId}" };
            state.gpuSHData.SetData(shData.GetSubArray(0, shWords));

            var (texW, texH) = GaussianSplatAsset.CalcTextureSize(count);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
            var tex = new Texture2D(texW, texH, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
            { name = $"PageColorCoarse_{state.pageId}" };
            var srcColor = asset.colorData.GetData<byte>();
            int wanted = texW * texH * GaussianSplatAsset.GetColorSize(asset.colorFormat);
            int colorBytes = Mathf.Min(wanted, srcColor.Length);
            tex.SetPixelData(srcColor.GetSubArray(0, colorBytes), 0);
            tex.Apply(false, true);
            state.gpuColorData = tex;

            int chunkStride = UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>();
            if (asset.chunkData != null && asset.chunkData.dataSize != 0)
            {
                var allChunks = asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>();
                int chunkCount = Mathf.Clamp(
                    (count + GaussianSplatAsset.kChunkSize - 1) / GaussianSplatAsset.kChunkSize,
                    1, allChunks.Length);
                state.gpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, chunkCount, chunkStride)
                    { name = $"PageChunksCoarse_{state.pageId}" };
                state.gpuChunks.SetData(allChunks.GetSubArray(0, chunkCount));
                state.chunkInfos = allChunks.GetSubArray(0, chunkCount).ToArray();
                state.gpuChunksValid = true;
            }
            else
            {
                state.gpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, chunkStride)
                    { name = $"PageChunksCoarse_{state.pageId}" };
                state.gpuChunksValid = false;
                state.chunkInfos = null;
            }
        }

        static int WordsForBytes(long byteCount) => checked((int)((byteCount + 3) / 4));

        static void UploadSingleSplatBuffers(SplatBoxPageGpuState state, GaussianSplatAsset asset, int splatIndex)
        {
            int totalSplats = asset.splatCount;
            if (totalSplats <= 0)
                return;

            int posWordsPerSplat = Mathf.Max(1, (int)(asset.posData.dataSize / totalSplats / 4));
            int otherWordsPerSplat = Mathf.Max(1, (int)(asset.otherData.dataSize / totalSplats / 4));
            int shWordsPerSplat = Mathf.Max(1, (int)(asset.shData.dataSize / totalSplats / 4));
            int srcBase = splatIndex;

            state.gpuPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                posWordsPerSplat, 4) { name = $"PagePosCoarse_{state.pageId}" };
            state.gpuPosData.SetData(asset.posData.GetData<uint>(), srcBase * posWordsPerSplat, 0, posWordsPerSplat);

            state.gpuOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                otherWordsPerSplat, 4) { name = $"PageOtherCoarse_{state.pageId}" };
            state.gpuOtherData.SetData(asset.otherData.GetData<uint>(), srcBase * otherWordsPerSplat, 0, otherWordsPerSplat);

            state.gpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, shWordsPerSplat, 4)
                { name = $"PageSHCoarse_{state.pageId}" };
            state.gpuSHData.SetData(asset.shData.GetData<uint>(), srcBase * shWordsPerSplat, 0, shWordsPerSplat);

            int linear = srcBase;
            int col = linear % GaussianSplatAsset.kTextureWidth;
            int row = linear / GaussianSplatAsset.kTextureWidth;
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
            var (fullW, fullH) = GaussianSplatAsset.CalcTextureSize(totalSplats);
            var tex = new Texture2D(GaussianSplatAsset.kTextureWidth, 1, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
            { name = $"PageColorCoarse_{state.pageId}" };
            var fullTex = new Texture2D(fullW, fullH, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate);
            fullTex.SetPixelData(asset.colorData.GetData<byte>(), 0);
            fullTex.Apply(false, true);
            Graphics.CopyTexture(fullTex, 0, 0, col, row, 1, 1, tex, 0, 0, 0, 0);
            if (Application.isPlaying) UnityEngine.Object.Destroy(fullTex);
            else UnityEngine.Object.DestroyImmediate(fullTex);
            state.gpuColorData = tex;
            state.gpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = $"PageChunksCoarse_{state.pageId}" };
            state.gpuChunksValid = false;
            state.chunkInfos = null;
        }

        public void Dispose()
        {
            gpuPosData?.Dispose();
            gpuOtherData?.Dispose();
            gpuSHData?.Dispose();
            gpuChunks?.Dispose();
            if (gpuColorData != null)
            {
                if (Application.isPlaying)
                    UnityEngine.Object.Destroy(gpuColorData);
                else
                    UnityEngine.Object.DestroyImmediate(gpuColorData);
            }
            gpuPosData = null;
            gpuOtherData = null;
            gpuSHData = null;
            gpuChunks = null;
            gpuColorData = null;
            lodTree = null;
            chunkInfos = null;
            m_UploadedSplatCount = 0;
            m_RefinementStartNodeCount = 0;
        }
    }
}
