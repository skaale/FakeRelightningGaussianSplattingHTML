// SPDX-License-Identifier: MIT
using Unity.Burst;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Jobs;
using Unity.Mathematics;

namespace GaussianSplatting.Runtime
{
    internal struct PagedAttractorForceData
    {
        public AttractorData data;
        public quaternion rotation, inverseRotation;
        public float3 inverseScale;
        public float inverseRange, strengthScale;

        internal static PagedAttractorForceData Prepare(AttractorData data)
        {
            float3 scale = math.max(math.abs((float3)data.scale), new float3(.0001f));
            quaternion rotation = math.normalizesafe(new quaternion(data.rotation.x, data.rotation.y,
                data.rotation.z, data.rotation.w));
            return new PagedAttractorForceData
            {
                data = data, rotation = rotation, inverseRotation = math.conjugate(rotation),
                inverseScale = 1f / scale, inverseRange = 1f / data.range,
                strengthScale = math.sqrt(math.max(data.range, .0001f)) *
                    math.pow(math.max(math.csum(scale) / 3f, .0001f), .25f) * math.max(data.falloff, .1f)
            };
        }
    }

    [BurstCompile]
    internal struct PagedAttractorStepJob : IJobParallelFor
    {
        [ReadOnly] public NativeArray<float3> baseline;
        [ReadOnly] public NativeArray<PagedAttractorForceData> attractors;
        public NativeArray<float3> offsets, velocities;
        [WriteOnly] public NativeArray<byte> changed;
        public float4x4 localToWorld, worldToLocal;
        public float deltaTime, time, velocityRetention, dampingRetention, minimumVelocitySquared;
        public int substeps;

        public void Execute(int index)
        {
            float3 current = offsets[index], currentVelocity = velocities[index];
            float3 original = baseline[index];
            float currentTime = time;
            changed[index] = 0;
            for (int step = 0; step < substeps; step++)
            {
                float3 world = math.transform(localToWorld, original + current);
                float3 force = float3.zero;
                for (int a = 0; a < attractors.Length; a++) force += Force(world, attractors[a], currentTime);
                float3 localForce = math.mul((float3x3)worldToLocal, force);
                float3 velocity = currentVelocity;
                bool driven = math.lengthsq(localForce) > 1e-16f;
                if (driven) velocity = (velocity + localForce * (deltaTime * 2f)) * velocityRetention;
                float3 next = current + velocity * deltaTime;
                velocity *= dampingRetention;
                // Gentle active forces must accumulate; the settling threshold applies only idle.
                if (!driven && math.lengthsq(velocity) < minimumVelocitySquared) velocity = float3.zero;
                if (math.all(math.isfinite(next)) && math.all(math.isfinite(velocity)))
                {
                    if (math.any(next != current)) changed[index] = 1;
                    current = next;
                    currentVelocity = velocity;
                }
                currentTime += deltaTime;
            }
            offsets[index] = current;
            velocities[index] = currentVelocity;
        }

        internal static float3 Force(float3 world, AttractorData data, float time) =>
            Force(world, PagedAttractorForceData.Prepare(data), time);

        static float3 Force(float3 world, PagedAttractorForceData prepared, float time)
        {
            var data = prepared.data;
            if (data.enabled < .5f || data.range <= 0f) return float3.zero;
            float3 relative = math.rotate(prepared.inverseRotation, world - (float3)data.position) * prepared.inverseScale;
            float distance = math.length(relative);
            if (distance > data.range || distance < .001f) return float3.zero;
            float normalized = distance * prepared.inverseRange;
            float remaining = math.max(0f, 1f - normalized);
            float attenuation = data.falloff == 1f ? remaining : math.pow(remaining, data.falloff);
            float3 direction = -relative / distance;
            float3 force;
            switch (data.mode)
            {
                case 0:
                    force = new float3(-direction.z, 0f, direction.x) * .8f + direction * .2f;
                    force.y = data.vortexHeight * (1f - normalized);
                    break;
                case 1: force = direction; break;
                case 2: force = -direction; break;
                case 3:
                    float perpendicular, secondary;
                    float3 waveDirection, curlDirection;
                    if (data.waveAxis == 0)
                    {
                        perpendicular = relative.z; secondary = relative.y;
                        waveDirection = new float3(1, 0, 0); curlDirection = new float3(0, 1, 0);
                    }
                    else if (data.waveAxis == 1)
                    {
                        perpendicular = math.length(relative.xz); secondary = math.atan2(relative.z, relative.x);
                        waveDirection = new float3(0, 1, 0);
                        float radius = math.max(perpendicular, .001f);
                        curlDirection = new float3(-relative.z / radius, 0, relative.x / radius);
                    }
                    else
                    {
                        perpendicular = relative.x; secondary = relative.y;
                        waveDirection = new float3(0, 0, 1); curlDirection = new float3(0, 1, 0);
                    }
                    float wave = math.sin(perpendicular * data.waveFrequency + time * data.waveSpeed) * data.waveAmplitude;
                    if (data.secondaryFrequency > .01f)
                        wave += math.sin(secondary * data.secondaryFrequency + time * data.waveSpeed * .7f) * data.waveAmplitude * .5f;
                    force = waveDirection * wave;
                    if (data.curlStrength > .01f)
                        force += curlDirection * math.cos(perpendicular * data.waveFrequency * .5f + time * data.waveSpeed * 1.3f) *
                            data.curlStrength * data.waveAmplitude;
                    break;
                default: return float3.zero;
            }
            return math.rotate(prepared.rotation, force * (data.strength * attenuation * prepared.strengthScale));
        }
    }

    [BurstCompile]
    internal struct PagedAttractorBoundsJob : IJob
    {
        [ReadOnly] public NativeArray<float3> offsets;
        [ReadOnly] public NativeArray<byte> changed;
        public NativeArray<float3> bounds;
        public void Execute()
        {
            float3 minimum = float3.zero, maximum = float3.zero;
            bool moved = false;
            for (int i = 0; i < offsets.Length; i++)
            {
                minimum = math.min(minimum, offsets[i]);
                maximum = math.max(maximum, offsets[i]);
                moved |= changed[i] != 0;
            }
            bounds[0] = minimum;
            bounds[1] = maximum;
            bounds[2] = new float3(moved ? 1f : 0f, 0, 0);
        }
    }

    /// <summary>
    /// Rebuild one page in Burst. Separate pages run concurrently, while the reverse extent
    /// pass preserves the parent/child dependency within both supported tree layouts.
    /// Managed source/destination arrays stay pinned until the owner completes this job.
    /// </summary>
    [BurstCompile]
    internal unsafe struct PagedAttractorRefitJob : IJob
    {
        [NativeDisableUnsafePtrRestriction] public LodTreeNode* source;
        [NativeDisableUnsafePtrRestriction] public LodTreeNode* destination;
        [NativeDisableUnsafePtrRestriction] public int* childTable;
        [NativeDisableUnsafePtrRestriction] public int* childTableStart;
        [ReadOnly] public NativeArray<float3> baseline, offsets;
        public int nodeCount, movingCount;
        public float maximumDisplacement;
        public bool coarse;

        public void Execute()
        {
            for (int i = 0; i < nodeCount; i++)
            {
                var node = source[i];
                if (i < movingCount) node.center = baseline[i] + offsets[i];
                destination[i] = node;
            }
            for (int i = nodeCount - 1; i >= 0; i--)
            {
                var node = destination[i];
                float radius = source[i].featureSize * .5f;
                bool hiddenChildren = node.childCount == 0 && (node.IsMergedSplat ||
                    (coarse && i == 0 && nodeCount == 1));
                if (hiddenChildren)
                    radius += maximumDisplacement + math.distance(node.center, source[i].center);
                for (int c = 0; c < node.childCount; c++)
                {
                    int child = childTable == null ? (int)node.childStart + c :
                        childTable[childTableStart[i] + c];
                    if (child > i && child < nodeCount)
                        radius = math.max(radius, math.distance(node.center, destination[child].center) +
                            destination[child].featureSize * .5f);
                }
                node.featureSize = math.max(1e-4f, radius * 2f);
                destination[i] = node;
            }
        }
    }
}
