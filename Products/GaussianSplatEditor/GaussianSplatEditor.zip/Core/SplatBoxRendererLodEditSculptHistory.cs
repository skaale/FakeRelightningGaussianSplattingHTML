// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [Serializable]
        struct PagedEditSculptHistoryNode
        {
            // IDs are list indices + 1. Zero is the original source geometry. A parent always
            // precedes its child, so branches share prefixes without recursive serialization.
            public int parent;
            public PagedSmudgeDab dab;
        }

        [SerializeField, HideInInspector] List<PagedEditSculptHistoryNode> m_PagedEditSculptHistory =
            new List<PagedEditSculptHistoryNode>();

        readonly Dictionary<int, List<int>> m_PagedEditSculptLookup = new Dictionary<int, List<int>>();
        readonly List<Vector3> m_PagedEditSculptBoundsMin = new List<Vector3>();
        readonly List<Vector3> m_PagedEditSculptBoundsMax = new List<Vector3>();
        readonly List<bool> m_PagedEditSculptValid = new List<bool>();
        List<PagedEditSculptHistoryNode> m_PagedEditSculptCachedArchive;
        bool m_PagedEditSculptHistoryCacheDirty = true;
        List<PagedSmudgeDab> m_PagedEditSculptCapturedJournal;
        GaussianSplatPagedScene m_PagedEditSculptCapturedScene;
        int m_PagedEditSculptCapturedRevision = -1;
        int m_PagedEditSculptCapturedCount, m_PagedEditSculptCapturedSnapshot;

        /// <summary>
        /// Saves the current deformation as a shared immutable prefix for an erase/color edit.
        /// The owning edit records Undo before calling this, so its snapshot ID and newly added
        /// archive nodes restore together. Sculpt reset deliberately leaves this archive intact.
        /// </summary>
        int CapturePagedEditSculptSnapshot()
        {
            EnsurePagedEditSculptHistoryCache();
            if (!HasPagedSmudgeJournal)
            {
                m_PagedEditSculptCapturedJournal = null;
                m_PagedEditSculptCapturedCount = m_PagedEditSculptCapturedSnapshot = 0;
                m_PagedEditSculptCapturedRevision = -1;
                return 0;
            }

            bool sameJournal = ReferenceEquals(m_PagedEditSculptCapturedJournal, m_PagedSmudgeDabs) &&
                m_PagedEditSculptCapturedScene == m_PagedScene;
            if (sameJournal && m_PagedEditSculptCapturedRevision == m_PagedSmudgeRevision &&
                m_PagedEditSculptCapturedCount == m_PagedSmudgeDabs.Count)
                return m_PagedEditSculptCapturedSnapshot;

            // Normal sculpting only appends. Undo/deserialization invalidates the cache; a reset
            // shrinks the list or is observed above. Repeated paint dabs on unchanged geometry
            // therefore capture in O(1), including histories with large Relax neighborhood fields.
            bool append = sameJournal && m_PagedSmudgeRevision > m_PagedEditSculptCapturedRevision &&
                m_PagedSmudgeDabs.Count > m_PagedEditSculptCapturedCount &&
                (long)m_PagedSmudgeRevision - m_PagedEditSculptCapturedRevision ==
                    m_PagedSmudgeDabs.Count - m_PagedEditSculptCapturedCount;
            int first = append ? m_PagedEditSculptCapturedCount : 0;
            int snapshot = append ? m_PagedEditSculptCapturedSnapshot : 0;
            for (int i = first; i < m_PagedSmudgeDabs.Count; i++)
                snapshot = FindOrAppendPagedEditSculptNode(snapshot, m_PagedSmudgeDabs[i]);

            m_PagedEditSculptCapturedJournal = m_PagedSmudgeDabs;
            m_PagedEditSculptCapturedScene = m_PagedScene;
            m_PagedEditSculptCapturedRevision = m_PagedSmudgeRevision;
            m_PagedEditSculptCapturedCount = m_PagedSmudgeDabs.Count;
            m_PagedEditSculptCapturedSnapshot = snapshot;
            return snapshot;
        }

        IEnumerable<PagedSmudgeDab> EnumeratePagedEditSculptSnapshot(int id)
        {
            EnsurePagedEditSculptHistoryCache();
            if (!IsValidPagedEditSculptSnapshot(id) || id == 0)
                yield break;
            // Only the lightweight ID stack is duplicated for enumeration. The persisted journal
            // and potentially large immutable Relax fields remain shared across edit snapshots.
            var chain = new Stack<int>();
            while (id != 0)
            {
                chain.Push(id);
                id = m_PagedEditSculptHistory[id - 1].parent;
            }
            while (chain.Count > 0)
                yield return m_PagedEditSculptHistory[chain.Pop() - 1].dab;
        }

        Bounds ExpandPagedEditSculptBounds(Bounds original, int id)
        {
            EnsurePagedEditSculptHistoryCache();
            if (!IsValidPagedEditSculptSnapshot(id) || id == 0)
                return original;
            var result = new Bounds();
            result.SetMinMax(original.min + m_PagedEditSculptBoundsMin[id - 1],
                original.max + m_PagedEditSculptBoundsMax[id - 1]);
            return result;
        }

        bool IsPagedEditSculptSnapshotValid(int id)
        {
            EnsurePagedEditSculptHistoryCache();
            return IsValidPagedEditSculptSnapshot(id);
        }

        bool IsCurrentPagedEditSculptSnapshot(int id) => HasPagedSmudgeJournal &&
            !m_PagedEditSculptHistoryCacheDirty &&
            ReferenceEquals(m_PagedEditSculptCapturedJournal, m_PagedSmudgeDabs) &&
            m_PagedEditSculptCapturedScene == m_PagedScene &&
            m_PagedEditSculptCapturedRevision == m_PagedSmudgeRevision &&
            m_PagedEditSculptCapturedCount == m_PagedSmudgeDabs.Count &&
            m_PagedEditSculptCapturedSnapshot == id;

        void ClearPagedEditSculptHistoryIfUnused()
        {
            if (m_PagedEditSculptHistory == null || m_PagedEditSculptHistory.Count == 0)
                return;
            if (m_PagedEraseStrokes != null)
                for (int i = 0; i < m_PagedEraseStrokes.Count; i++)
                    if (m_PagedEraseStrokes[i].sculptSnapshot != 0)
                        return;
            // Redo entries still own their geometry snapshots. Clearing only the visible color
            // cursor would make a subsequent redo repaint a different set of source splats.
            if (m_PagedColorizeStrokes != null)
                for (int s = 0; s < m_PagedColorizeStrokes.Count; s++)
                {
                    var dabs = m_PagedColorizeStrokes[s]?.dabs;
                    if (dabs == null) continue;
                    for (int d = 0; d < dabs.Count; d++)
                        if (dabs[d].sculptSnapshot != 0)
                            return;
                }
            m_PagedEditSculptHistory.Clear();
            InvalidatePagedEditSculptHistoryCache();
            m_PagedEditSculptGpuDirty = true;
        }

        void InvalidatePagedEditSculptHistoryCache()
        {
            // OnValidate may run on Unity's loading thread. Defer collection mutation until the
            // next main-thread use, but never use a cached lookup or capture after invalidation.
            m_PagedEditSculptHistoryCacheDirty = true;
        }

        void EnsurePagedEditSculptHistoryCache()
        {
            m_PagedEditSculptHistory ??= new List<PagedEditSculptHistoryNode>();
            if (!m_PagedEditSculptHistoryCacheDirty &&
                ReferenceEquals(m_PagedEditSculptCachedArchive, m_PagedEditSculptHistory) &&
                m_PagedEditSculptValid.Count == m_PagedEditSculptHistory.Count)
                return;
            m_PagedEditSculptLookup.Clear();
            m_PagedEditSculptBoundsMin.Clear();
            m_PagedEditSculptBoundsMax.Clear();
            m_PagedEditSculptValid.Clear();
            m_PagedEditSculptCapturedJournal = null;
            m_PagedEditSculptCapturedScene = null;
            m_PagedEditSculptCapturedRevision = -1;
            m_PagedEditSculptCapturedCount = m_PagedEditSculptCapturedSnapshot = 0;
            m_PagedEditSculptCachedArchive = m_PagedEditSculptHistory;
            for (int i = 0; i < m_PagedEditSculptHistory.Count; i++)
                CachePagedEditSculptNode(i + 1);
            m_PagedEditSculptHistoryCacheDirty = false;
        }

        bool IsValidPagedEditSculptSnapshot(int id) => id == 0 ||
            (id > 0 && id <= m_PagedEditSculptValid.Count && m_PagedEditSculptValid[id - 1]);

        int FindOrAppendPagedEditSculptNode(int parent, in PagedSmudgeDab dab)
        {
            int key = PagedEditSculptNodeHash(parent, dab);
            if (m_PagedEditSculptLookup.TryGetValue(key, out var candidates))
                for (int i = 0; i < candidates.Count; i++)
                {
                    int candidateId = candidates[i];
                    var candidate = m_PagedEditSculptHistory[candidateId - 1];
                    if (candidate.parent == parent && PagedEditSculptDabsEqual(candidate.dab, dab))
                        return candidateId;
                }
            var saved = dab;
            if (dab.relaxCells != null && dab.relaxCells.Length > 0)
                saved.relaxCells = (Vector4[])dab.relaxCells.Clone();
            m_PagedEditSculptHistory.Add(new PagedEditSculptHistoryNode { parent = parent, dab = saved });
            int id = m_PagedEditSculptHistory.Count;
            CachePagedEditSculptNode(id);
            return id;
        }

        void CachePagedEditSculptNode(int id)
        {
            var node = m_PagedEditSculptHistory[id - 1];
            bool valid = node.parent >= 0 && node.parent < id && IsValidPagedEditSculptSnapshot(node.parent);
            Vector3 minimum = Vector3.zero, maximum = Vector3.zero;
            if (valid)
            {
                GetPagedSculptDisplacementBounds(node.dab, out minimum, out maximum);
                if (node.parent > 0)
                {
                    minimum += m_PagedEditSculptBoundsMin[node.parent - 1];
                    maximum += m_PagedEditSculptBoundsMax[node.parent - 1];
                }
                valid = PagedEraseFinite(minimum) && PagedEraseFinite(maximum);
            }
            m_PagedEditSculptValid.Add(valid);
            m_PagedEditSculptBoundsMin.Add(minimum);
            m_PagedEditSculptBoundsMax.Add(maximum);
            if (!valid) return;
            int key = PagedEditSculptNodeHash(node.parent, node.dab);
            if (!m_PagedEditSculptLookup.TryGetValue(key, out var candidates))
                m_PagedEditSculptLookup.Add(key, candidates = new List<int>());
            candidates.Add(id);
        }

        static bool PagedEditSculptDabsEqual(in PagedSmudgeDab a, in PagedSmudgeDab b)
        {
            if (a.kind != b.kind || !a.center.Equals(b.center) || !a.delta.Equals(b.delta) ||
                a.radius != b.radius || a.falloff != b.falloff || a.strength != b.strength ||
                !a.normal.Equals(b.normal) || a.neighborRadius != b.neighborRadius || a.invert != b.invert ||
                a.relaxGridSize != b.relaxGridSize)
                return false;
            if (ReferenceEquals(a.relaxCells, b.relaxCells)) return true;
            int count = a.relaxCells?.Length ?? 0;
            if (count != (b.relaxCells?.Length ?? 0)) return false;
            for (int i = 0; i < count; i++)
                if (!a.relaxCells[i].Equals(b.relaxCells[i])) return false;
            return true;
        }

        static int PagedEditSculptNodeHash(int parent, in PagedSmudgeDab dab)
        {
            unchecked
            {
                int hash = parent;
                hash = hash * 397 ^ dab.kind;
                hash = hash * 397 ^ dab.center.GetHashCode();
                hash = hash * 397 ^ dab.delta.GetHashCode();
                hash = hash * 397 ^ dab.radius.GetHashCode();
                hash = hash * 397 ^ dab.falloff.GetHashCode();
                hash = hash * 397 ^ dab.strength.GetHashCode();
                hash = hash * 397 ^ dab.normal.GetHashCode();
                hash = hash * 397 ^ dab.neighborRadius.GetHashCode();
                hash = hash * 397 ^ (dab.invert ? 1 : 0);
                hash = hash * 397 ^ dab.relaxGridSize;
                int count = dab.relaxCells?.Length ?? 0;
                hash = hash * 397 ^ count;
                for (int i = 0; i < count; i++) hash = hash * 397 ^ dab.relaxCells[i].GetHashCode();
                return hash;
            }
        }
    }
}
