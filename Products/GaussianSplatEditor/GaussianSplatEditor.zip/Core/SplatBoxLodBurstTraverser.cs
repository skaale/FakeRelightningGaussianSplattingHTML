// SPDX-License-Identifier: MIT

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using AOT;
using Unity.Burst;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Native version of the best-first traversal. Resident trees stay in their managed arrays:
    /// they are pinned for this synchronous call, so neither a whole-tree copy nor persistent
    /// duplicate native trees are needed as pages stream in and out.
    /// </summary>
    [BurstCompile]
    internal static unsafe class SplatBoxLodBurstTraverser
    {
        internal struct NativePage
        {
            public LodTreeNode* nodes;
            public int nodeCount;
            public int* childTable;
            public int childTableLength;
            public int* childTableStart;
            public int childTableStartLength;
            public float4x4 localToWorld;
            public float featureScale, lodScale, outsideFoveate, behindFoveate;
            public int pageSlot;
        }

        struct NativeView
        {
            public float3 cameraWorld, cameraForward;
            public float pixelScaleFactor, pixelsPerUnitAtUnitDistance, cosHalfFovY, maxStandInPixels, splatScale;
            public int orthographic, skipMerged, frustumCull;
            public float4* planes;
            public int planeCount;
            public float4* rightPlanes;
            public int rightPlaneCount;
        }

        struct Traversal
        {
            [NoAlias] public NativePage* pages;
            public int pageCount, maxSplats;
            public float pixelScaleLimit;
            public NativeView view;
            [NoAlias] public SplatBoxLodTraverser.QueueEntry* heap;
            [NoAlias] public SplatBoxLodTraverser.QueueEntry* children;
            [NoAlias] public LodActiveSplatRef* output;
            public int* cancellationRequest;
            public int heapCount, outCount, budgetExhausted, emittedLeaves, emittedMerged, droppedMerged, managedExecution, depthFirst;
            public int allowDepthFirst, cancelled, completeFrontierOnly;
            public float exhaustedPixelScale;
        }

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        delegate int TraverseDelegate(Traversal* traversal);
        static FunctionPointer<TraverseDelegate> s_Kernel;
        static TraverseDelegate s_Invoke;
        static bool s_CompilationFailed;

        public static bool TryTraverse(SplatBoxLodTraverser.PageContext[] pages, int pageCount,
            in SplatBoxLodTraverser.ViewContext view, int maxSplats, float pixelScaleLimit,
            LodActiveSplatRef[] output, SplatBoxLodTraverser.Workspace workspace, out int selected,
            bool completeFrontierOnly = false)
        {
            selected = 0;
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0 || workspace == null ||
                !Warmup())
                return false;
            pageCount = Math.Min(pageCount, pages.Length);
            maxSplats = Math.Min(maxSplats, output.Length);
            if (maxSplats <= 0)
                return false;
            if (workspace.nativePages == null || workspace.nativePages.Length < pageCount)
                workspace.nativePages = new NativePage[pageCount];
            if (workspace.nativePins == null || workspace.nativePins.Length < pageCount * 3)
                workspace.nativePins = new GCHandle[pageCount * 3];
            int heapCapacity = Math.Max(maxSplats, pageCount);
            if (workspace.heap.Length < heapCapacity)
                Array.Resize(ref workspace.heap, heapCapacity);
            // childCount is serialized as ushort. The native kernel must never resize managed
            // storage while its pointers are pinned, including for unusually wide legacy nodes.
            if (workspace.children.Length < ushort.MaxValue)
                Array.Resize(ref workspace.children, ushort.MaxValue);

            int pinned = 0;
            try
            {
                for (int p = 0; p < pageCount; p++)
                {
                    ref SplatBoxLodTraverser.PageContext page = ref pages[p];
                    page.featureScale = math.max(math.max(math.length(page.localToWorld.c0.xyz),
                        math.length(page.localToWorld.c1.xyz)), math.max(math.length(page.localToWorld.c2.xyz), 1e-6f));
                    workspace.nativePages[p] = new NativePage
                    {
                        nodes = (LodTreeNode*)Pin(page.nodes, workspace.nativePins, ref pinned),
                        nodeCount = page.EffectiveNodeCount,
                        childTable = (int*)Pin(page.childTable, workspace.nativePins, ref pinned),
                        childTableLength = page.childTable?.Length ?? 0,
                        childTableStart = (int*)Pin(page.childTableStart, workspace.nativePins, ref pinned),
                        childTableStartLength = page.childTableStart?.Length ?? 0,
                        localToWorld = page.localToWorld,
                        featureScale = page.featureScale,
                        lodScale = page.lodScale,
                        outsideFoveate = page.outsideFoveate,
                        behindFoveate = page.behindFoveate,
                        pageSlot = page.pageSlot
                    };
                }
                fixed (NativePage* nativePages = workspace.nativePages)
                fixed (SplatBoxLodTraverser.QueueEntry* heap = workspace.heap)
                fixed (SplatBoxLodTraverser.QueueEntry* children = workspace.children)
                fixed (LodActiveSplatRef* active = output)
                fixed (float4* planes = view.cullPlanes)
                fixed (float4* rightPlanes = view.rightEyeCullPlanes)
                fixed (int* cancellationRequest = workspace.cancellationRequest)
                {
                    var traversal = new Traversal
                    {
                        pages = nativePages, pageCount = pageCount, maxSplats = maxSplats,
                        pixelScaleLimit = pixelScaleLimit, heap = heap, children = children, output = active,
                        cancellationRequest = cancellationRequest,
                        allowDepthFirst = completeFrontierOnly || !workspace.budgetExhausted ? 1 : 0,
                        completeFrontierOnly = completeFrontierOnly ? 1 : 0,
                        view = new NativeView
                        {
                            cameraWorld = view.cameraWorld, cameraForward = view.cameraForward,
                            pixelScaleFactor = view.pixelScaleFactor,
                            pixelsPerUnitAtUnitDistance = view.pixelsPerUnitAtUnitDistance,
                            cosHalfFovY = view.cosHalfFovY, maxStandInPixels = view.maxStandInPixels,
                            splatScale = view.splatScale, orthographic = view.orthographic ? 1 : 0,
                            skipMerged = view.skipMergedSplats ? 1 : 0, frustumCull = view.frustumCull ? 1 : 0,
                            planes = planes, planeCount = view.cullPlanes?.Length ?? 0,
                            rightPlanes = rightPlanes, rightPlaneCount = view.rightEyeCullPlanes?.Length ?? -1
                        }
                    };
                    selected = s_Invoke(&traversal);
                    workspace.heapCount = 0;
                    workspace.usedBurst = traversal.managedExecution == 0;
                    workspace.usedDepthFirst = traversal.depthFirst != 0;
                    workspace.budgetExhausted = traversal.budgetExhausted != 0;
                    workspace.exhaustedPixelScale = traversal.exhaustedPixelScale;
                    workspace.emittedLeaves = traversal.emittedLeaves;
                    workspace.emittedMerged = traversal.emittedMerged;
                    workspace.droppedMerged = traversal.droppedMerged;
                    workspace.wasCancelled = traversal.cancelled != 0;
                }
                return true;
            }
            finally
            {
                for (int i = 0; i < pinned; i++)
                {
                    workspace.nativePins[i].Free();
                    workspace.nativePins[i] = default;
                }
            }
        }

        internal static bool Warmup()
        {
            if (!BurstCompiler.IsEnabled || s_CompilationFailed)
                return false;
            if (s_Kernel.IsCreated)
                return true;
            try
            {
                s_Kernel = BurstCompiler.CompileFunctionPointer<TraverseDelegate>(Run);
                s_Invoke = s_Kernel.Invoke;
                return true;
            }
            catch (Exception ex)
            {
                s_CompilationFailed = true;
                Debug.LogWarning("SplatBox: native LoD traversal unavailable; using managed traversal. " + ex.Message);
                return false;
            }
        }

        static void* Pin(Array array, GCHandle[] handles, ref int count)
        {
            if (array == null || array.Length == 0)
                return null;
            GCHandle handle = GCHandle.Alloc(array, GCHandleType.Pinned);
            handles[count++] = handle;
            return handle.AddrOfPinnedObject().ToPointer();
        }

        [BurstCompile(CompileSynchronously = true, FloatMode = FloatMode.Strict,
            FloatPrecision = FloatPrecision.Standard, OptimizeFor = OptimizeFor.Performance)]
        [MonoPInvokeCallback(typeof(TraverseDelegate))]
        static int Run([NoAlias] Traversal* t)
        {
            t->managedExecution = 0;
            MarkManagedExecution(ref t->managedExecution);
            if (PollCancellation(t))
                return 0;
            if (t->allowDepthFirst != 0 && TryDepthFirst(t))
            {
                t->depthFirst = 1;
                return t->outCount;
            }
            if (t->cancelled != 0)
                return 0;
            // Never expose a partial depth-first frontier when global budget priority matters.
            t->heapCount = t->outCount = t->budgetExhausted = 0;
            t->emittedLeaves = t->emittedMerged = t->droppedMerged = 0;
            t->exhaustedPixelScale = 0f;
            if (t->completeFrontierOnly != 0)
            {
                t->budgetExhausted = 1;
                return 0;
            }
            return RunBestFirst(t);
        }

        static bool TryDepthFirst(Traversal* t)
        {
            int processed = 0;
            for (int p = 0; p < t->pageCount; p++)
            {
                if ((processed++ & 63) == 0 && PollCancellation(t))
                    return false;
                NativePage* page = &t->pages[p];
                if (page->nodes == null || page->nodeCount == 0)
                    continue;
                LodTreeNode node = page->nodes[0];
                float3 world = math.mul(page->localToWorld, new float4(node.center, 1f)).xyz;
                float feature = node.featureSize * page->featureScale;
                if (!Visible(&t->view, world, feature))
                    continue;
                if (t->heapCount >= t->maxSplats)
                    return false;
                t->heap[t->heapCount++] = new SplatBoxLodTraverser.QueueEntry
                {
                    pageIndex = p, nodeIndex = 0,
                    pixelScale = PixelScale(&t->view, world, feature, page)
                };
            }
            while (t->heapCount > 0)
            {
                if ((processed++ & 63) == 0 && PollCancellation(t))
                    return false;
                SplatBoxLodTraverser.QueueEntry top = t->heap[--t->heapCount];
                NativePage* page = &t->pages[top.pageIndex];
                if (!HasCompleteChildren(page, top.nodeIndex) ||
                    (t->pixelScaleLimit > 0f && top.pixelScale < t->pixelScaleLimit))
                {
                    Emit(t, page, top.nodeIndex);
                    continue;
                }
                int visible = CollectChildren(t, page, top);
                if (t->outCount + t->heapCount + visible > t->maxSplats)
                    return false;
                for (int c = 0; c < visible; c++)
                {
                    SplatBoxLodTraverser.QueueEntry child = t->children[c];
                    if (page->nodes[child.nodeIndex].childCount == 0 ||
                        (t->pixelScaleLimit > 0f && child.pixelScale < t->pixelScaleLimit))
                        Emit(t, page, child.nodeIndex);
                    else
                        t->heap[t->heapCount++] = child;
                }
            }
            return true;
        }

        static int RunBestFirst(Traversal* t)
        {
            int processed = 0;
            for (int p = 0; p < t->pageCount; p++)
            {
                if ((processed++ & 63) == 0 && PollCancellation(t))
                    return 0;
                NativePage* page = &t->pages[p];
                if (page->nodes == null || page->nodeCount == 0)
                    continue;
                LodTreeNode node = page->nodes[0];
                float3 world = math.mul(page->localToWorld, new float4(node.center, 1f)).xyz;
                float feature = node.featureSize * page->featureScale;
                if (Visible(&t->view, world, feature))
                    Push(t, new SplatBoxLodTraverser.QueueEntry
                    {
                        pageIndex = p, nodeIndex = 0,
                        pixelScale = PixelScale(&t->view, world, feature, page)
                    });
            }
            while (t->heapCount > 0)
            {
                if ((processed++ & 63) == 0 && PollCancellation(t))
                    return 0;
                if (t->outCount >= t->maxSplats)
                {
                    Exhausted(t, t->heap[0].pixelScale);
                    break;
                }
                SplatBoxLodTraverser.QueueEntry top = Pop(t);
                NativePage* page = &t->pages[top.pageIndex];
                if (page->nodes == null || top.nodeIndex >= page->nodeCount)
                    continue;
                LodTreeNode node = page->nodes[top.nodeIndex];
                if (!HasCompleteChildren(page, top.nodeIndex))
                {
                    Emit(t, page, top.nodeIndex);
                    continue;
                }
                if (t->pixelScaleLimit > 0f && top.pixelScale < t->pixelScaleLimit)
                {
                    Emit(t, page, top.nodeIndex);
                    break;
                }
                // Once the frontier fills the budget, most remaining nodes cannot split. Avoid
                // transforming/projecting every child just to discover that again. This shortcut
                // requires a complete contiguous range and proof that all children are visible;
                // nodes touching a frustum edge still reserve their actual visible-child count.
                if (t->outCount + t->heapCount + node.childCount > t->maxSplats &&
                    page->childTable == null && node.childStart > top.nodeIndex &&
                    (long)node.childStart + node.childCount <= page->nodeCount &&
                    EntireSubtreeVisible(&t->view, page, node))
                {
                    Exhausted(t, top.pixelScale);
                    Emit(t, page, top.nodeIndex);
                    continue;
                }
                int visible = CollectChildren(t, page, top);
                if (t->outCount + t->heapCount + visible > t->maxSplats)
                {
                    Exhausted(t, top.pixelScale);
                    Emit(t, page, top.nodeIndex);
                    continue;
                }
                for (int c = 0; c < visible; c++)
                {
                    SplatBoxLodTraverser.QueueEntry child = t->children[c];
                    if (page->nodes[child.nodeIndex].childCount == 0 ||
                        (t->pixelScaleLimit > 0f && child.pixelScale < t->pixelScaleLimit))
                        Emit(t, page, child.nodeIndex);
                    else
                        Push(t, child);
                }
            }
            for (int i = 0; i < t->heapCount && t->outCount < t->maxSplats; i++)
            {
                if ((processed++ & 63) == 0 && PollCancellation(t))
                    return 0;
                SplatBoxLodTraverser.QueueEntry entry = t->heap[i];
                NativePage* page = &t->pages[entry.pageIndex];
                if (page->nodes != null && entry.nodeIndex < page->nodeCount)
                    Emit(t, page, entry.nodeIndex);
            }
            return t->outCount;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool PollCancellation(Traversal* t)
        {
            if (t->cancellationRequest == null ||
                Interlocked.CompareExchange(ref *t->cancellationRequest, 0, 0) == 0)
                return false;
            t->heapCount = t->outCount = t->budgetExhausted = 0;
            t->emittedLeaves = t->emittedMerged = t->droppedMerged = t->depthFirst = 0;
            t->exhaustedPixelScale = 0f;
            t->cancelled = 1;
            return true;
        }

        [BurstDiscard]
        static void MarkManagedExecution(ref int managed) => managed = 1;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool HasCompleteChildren(NativePage* page, uint nodeIndex)
        {
            LodTreeNode node = page->nodes[nodeIndex];
            if (node.childCount == 0)
                return false;
            int start = page->childTableStart != null && nodeIndex < page->childTableStartLength
                ? page->childTableStart[nodeIndex] : -1;
            if (start >= 0 && page->childTable != null)
            {
                if ((long)start + node.childCount > page->childTableLength)
                    return false;
                for (int c = 0; c < node.childCount; c++)
                {
                    int child = page->childTable[start + c];
                    if (child <= 0 || child >= page->nodeCount)
                        return false;
                }
                return true;
            }
            return node.childStart > nodeIndex && (long)node.childStart + node.childCount <= page->nodeCount;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static int CollectChildren(Traversal* t, NativePage* page, SplatBoxLodTraverser.QueueEntry parent)
        {
            LodTreeNode node = page->nodes[parent.nodeIndex];
            int start = page->childTableStart != null && parent.nodeIndex < page->childTableStartLength
                ? page->childTableStart[parent.nodeIndex] : -1;
            int visible = 0;
            for (int c = 0; c < node.childCount; c++)
            {
                int index = start >= 0 && page->childTable != null && start + c < page->childTableLength
                    ? page->childTable[start + c] : (int)node.childStart + c;
                if (index <= 0 || index >= page->nodeCount)
                    continue;
                LodTreeNode child = page->nodes[index];
                float3 world = math.mul(page->localToWorld, new float4(child.center, 1f)).xyz;
                float feature = child.featureSize * page->featureScale;
                if (!Visible(&t->view, world, feature))
                    continue;
                t->children[visible++] = new SplatBoxLodTraverser.QueueEntry
                {
                    pageIndex = parent.pageIndex, nodeIndex = (uint)index,
                    pixelScale = child.childCount == 0 ? 0f : PixelScale(&t->view, world, feature, page)
                };
            }
            return visible;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static float PixelScale(NativeView* view, float3 world, float feature, NativePage* page)
        {
            float3 toCenter = world - view->cameraWorld;
            float distance = math.length(toCenter);
            float radius = feature * 0.5f;
            float size = feature * math.max(0.01f, page->lodScale);
            if (view->orthographic == 0)
                size /= math.max(distance - radius, 0.05f);
            if (distance > radius)
            {
                float facing = math.dot(view->cameraForward, toCenter) / distance;
                if (facing < 0f)
                    size *= math.max(0.05f, page->behindFoveate);
                else if (facing < view->cosHalfFovY)
                    size *= math.max(0.05f, page->outsideFoveate);
            }
            return size * view->pixelScaleFactor;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool Visible(NativeView* view, float3 center, float feature)
        {
            if (view->frustumCull == 0 || view->planes == null)
                return true;
            float radius = math.max(feature, 1e-3f);
            return Intersects(view->planes, view->planeCount, center, radius) ||
                (view->rightPlaneCount >= 0 && Intersects(view->rightPlanes, view->rightPlaneCount, center, radius));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool EntireSubtreeVisible(NativeView* view, NativePage* page, LodTreeNode node)
        {
            if (view->frustumCull == 0 || view->planes == null)
                return true;
            float3 center = math.mul(page->localToWorld, new float4(node.center, 1f)).xyz;
            // featureSize encloses the subtree. Using the full diameter plus the visibility-test
            // minimum radius also encloses every child's deliberately oversized culling sphere.
            float radius = node.featureSize * page->featureScale + 1e-3f;
            return InsideFrustum(view->planes, view->planeCount, center, radius) ||
                (view->rightPlaneCount >= 0 && InsideFrustum(view->rightPlanes, view->rightPlaneCount, center, radius));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool InsideFrustum(float4* planes, int count, float3 center, float radius)
        {
            for (int i = 0; i < count; i++)
            {
                float4 plane = planes[i];
                if (math.dot(plane.xyz, center) + plane.w < radius)
                    return false;
            }
            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static bool Intersects(float4* planes, int count, float3 center, float radius)
        {
            for (int i = 0; i < count; i++)
            {
                float4 plane = planes[i];
                if (math.dot(plane.xyz, center) + plane.w < -radius)
                    return false;
            }
            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void Exhausted(Traversal* t, float scale)
        {
            if (t->budgetExhausted != 0)
                return;
            t->budgetExhausted = 1;
            t->exhaustedPixelScale = scale;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void Emit(Traversal* t, NativePage* page, uint index)
        {
            LodTreeNode node = page->nodes[index];
            if (node.childCount != 0 || (node.flags & LodTreeNode.kFlagMerged) != 0)
            {
                bool drop = t->view.skipMerged != 0;
                if (!drop && t->view.maxStandInPixels > 0f)
                {
                    float feature = node.featureSize * page->featureScale;
                    float pixels = feature * t->view.splatScale * t->view.pixelsPerUnitAtUnitDistance;
                    if (t->view.orthographic == 0)
                    {
                        float3 world = math.mul(page->localToWorld, new float4(node.center, 1f)).xyz;
                        float distance = math.length(world - t->view.cameraWorld) - feature * 0.5f;
                        drop = distance <= 0f;
                        pixels /= distance;
                    }
                    drop |= pixels > t->view.maxStandInPixels;
                }
                if (drop)
                {
                    t->droppedMerged++;
                    return;
                }
                t->emittedMerged++;
            }
            else
                t->emittedLeaves++;
            if (t->outCount < t->maxSplats)
                t->output[t->outCount++] = new LodActiveSplatRef { pageSlot = (uint)page->pageSlot, splatIndex = index };
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static void Push(Traversal* t, SplatBoxLodTraverser.QueueEntry entry)
        {
            int i = t->heapCount++;
            while (i > 0)
            {
                int parent = (i - 1) >> 1;
                if (t->heap[parent].pixelScale >= entry.pixelScale)
                    break;
                t->heap[i] = t->heap[parent];
                i = parent;
            }
            t->heap[i] = entry;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        static SplatBoxLodTraverser.QueueEntry Pop(Traversal* t)
        {
            SplatBoxLodTraverser.QueueEntry top = t->heap[0];
            int count = --t->heapCount;
            if (count > 0)
            {
                SplatBoxLodTraverser.QueueEntry entry = t->heap[count];
                int i = 0;
                while (true)
                {
                    int left = i * 2 + 1;
                    if (left >= count)
                        break;
                    int right = left + 1;
                    int largest = right < count && t->heap[right].pixelScale > t->heap[left].pixelScale ? right : left;
                    t->heap[i] = t->heap[largest];
                    i = largest;
                }
                while (i > 0)
                {
                    int parent = (i - 1) >> 1;
                    if (t->heap[parent].pixelScale > entry.pixelScale)
                        break;
                    t->heap[i] = t->heap[parent];
                    i = parent;
                }
                t->heap[i] = entry;
            }
            return top;
        }
    }
}
