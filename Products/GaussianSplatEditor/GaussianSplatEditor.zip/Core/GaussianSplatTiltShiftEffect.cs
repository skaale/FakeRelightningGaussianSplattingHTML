// SPDX-License-Identifier: MIT
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Live settings bridge for the VR menu and legacy runtime appliers.
    /// The SplatBox editor saves its authored look on the camera component.
    /// </summary>
    public static class GaussianTiltShiftGlobalSettings
    {
        // Indicates that a runtime control is driving the bridge; not a persistent source of settings.
        public static bool Active = false;

        public static bool Enabled = false;
        public static int BlurMode = 0; // 0=TiltShift, 1=DoF, 2=Both
        public static float FocusPosition = 0.58f;
        public static float FocusWidth = 0.05f;
        public static float TiltAngle = 0f;
        public static float FocusDistance = 10f;
        public static float FocusRange = 5f;
        public static float NearBlurStrength = 0.5f;
        public static float FarBlurStrength = 0.8f;
        public static float BlurStrength = 10f;
        public static float TopBlurStrength = 1f;
        public static float BottomBlurStrength = 1f;
        // Shift the top / bottom edge of the sharp focus band independently (>0 = blur edge pushed
        // away from center, <0 = pulled toward center). Used to align the band in VR.
        public static float TopBlurOffset = 0f;
        public static float BottomBlurOffset = 0f;
        public static int BlurSamples = 8;
        public static float BokehShape = 0.5f;
        public static float SaturationBoost = 1f;
        public static float ContrastBoost = 1f;
        public static float VignetteStrength = 0.58f;
        public static bool HighQualityBlur = true;
        
        /// <summary>
        /// Push current globals onto a camera effect (adds component if missing and effect is enabled).
        /// Used by the VR settings menu so tilt-shift updates apply in player builds.
        /// </summary>
        public static void SyncToCamera(Camera cam)
        {
            if (cam == null)
                return;

            var effect = cam.GetComponent<GaussianSplatTiltShiftEffect>();
            if (effect == null && Enabled)
                effect = cam.gameObject.AddComponent<GaussianSplatTiltShiftEffect>();

            if (effect == null)
                return;

            effect.effectEnabled = Enabled;
            effect.blurMode = (GaussianSplatTiltShiftEffect.BlurMode)BlurMode;
            effect.focusPosition = FocusPosition;
            effect.focusWidth = FocusWidth;
            effect.tiltAngle = TiltAngle;
            effect.focusDistance = FocusDistance;
            effect.focusRange = FocusRange;
            effect.nearBlurStrength = NearBlurStrength;
            effect.farBlurStrength = FarBlurStrength;
            effect.blurStrength = BlurStrength;
            effect.topBlurStrength = TopBlurStrength;
            effect.bottomBlurStrength = BottomBlurStrength;
            effect.topBlurOffset = TopBlurOffset;
            effect.bottomBlurOffset = BottomBlurOffset;
            effect.blurSamples = BlurSamples;
            effect.bokehShape = BokehShape;
            effect.saturationBoost = SaturationBoost;
            effect.contrastBoost = ContrastBoost;
            effect.vignetteStrength = VignetteStrength;
            effect.highQualityBlur = HighQualityBlur;
        }

        /// <summary>Initialize runtime controls from the saved camera look, including explicit Off.</summary>
        public static void CopyFrom(GaussianSplatTiltShiftEffect effect)
        {
            if (effect == null) return;
            Enabled = effect.effectEnabled;
            BlurMode = (int)effect.blurMode;
            FocusPosition = effect.focusPosition;
            FocusWidth = effect.focusWidth;
            TiltAngle = effect.tiltAngle;
            FocusDistance = effect.focusDistance;
            FocusRange = effect.focusRange;
            NearBlurStrength = effect.nearBlurStrength;
            FarBlurStrength = effect.farBlurStrength;
            BlurStrength = effect.blurStrength;
            TopBlurStrength = effect.topBlurStrength;
            BottomBlurStrength = effect.bottomBlurStrength;
            TopBlurOffset = effect.topBlurOffset;
            BottomBlurOffset = effect.bottomBlurOffset;
            BlurSamples = effect.blurSamples;
            BokehShape = effect.bokehShape;
            SaturationBoost = effect.saturationBoost;
            ContrastBoost = effect.contrastBoost;
            VignetteStrength = effect.vignetteStrength;
            HighQualityBlur = effect.highQualityBlur;
        }

        public static void Reset()
        {
            Active = false;
            Enabled = false;
            BlurMode = 0;
            FocusPosition = 0.58f;
            FocusWidth = 0.05f;
            TiltAngle = 0f;
            FocusDistance = 10f;
            FocusRange = 5f;
            NearBlurStrength = 0.5f;
            FarBlurStrength = 0.8f;
            BlurStrength = 10f;
            TopBlurStrength = 1f;
            BottomBlurStrength = 1f;
            TopBlurOffset = 0f;
            BottomBlurOffset = 0f;
            BlurSamples = 8;
            BokehShape = 0.5f;
            SaturationBoost = 1f;
            ContrastBoost = 1f;
            VignetteStrength = 0.58f;
            HighQualityBlur = true;
        }
    }
    
    /// <summary>
    /// Tilt-shift miniature effect for Gaussian Splats.
    /// Creates a diorama/toy-like appearance by simulating tilt-shift photography.
    /// Authored through SplatBox's Camera panel. Built-in renders directly; URP uses the renderer feature.
    /// </summary>
    [ExecuteInEditMode]
    [RequireComponent(typeof(Camera))]
    [ImageEffectAllowedInSceneView]
    public class GaussianSplatTiltShiftEffect : MonoBehaviour
    {
        // The SplatBox Camera panel owns these scene-saved values, including an explicit Off.
        [HideInInspector] public bool authoredInSplatBoxEditor;

        public enum BlurMode
        {
            TiltShift,      // Horizontal band focus (miniature effect)
            DepthOfField,   // Near/far camera blur
            Both            // Combined effects
        }
        
        [Header("Blur Mode")]
        [Tooltip("Type of blur effect to apply")]
        public BlurMode blurMode = BlurMode.TiltShift;
        
        [Header("Tilt-Shift Focus (Miniature Effect)")]
        [Range(0f, 1f)]
        [Tooltip("Vertical position of the focus band (0=bottom, 1=top)")]
        public float focusPosition = 0.58f;
        
        [Range(0.001f, 0.8f)]
        [Tooltip("Width of the focus band (larger = more in focus)")]
        public float focusWidth = 0.05f;
        
        [Range(-45f, 45f)]
        [Tooltip("Rotation angle of the focus plane")]
        public float tiltAngle = 0f;
        
        [Header("Depth of Field (Camera Blur)")]
        [Tooltip("Distance along the camera view direction to the center of the sharp focus range")]
        public float focusDistance = 10f;
        
        [Range(0.1f, 50f)]
        [Tooltip("Range around focus distance that stays sharp")]
        public float focusRange = 5f;
        
        [Range(0f, 1f)]
        [Tooltip("Blur strength for objects closer than focus")]
        public float nearBlurStrength = 0.5f;
        
        [Range(0f, 1f)]
        [Tooltip("Blur strength for objects farther than focus")]
        public float farBlurStrength = 0.8f;
        
        [Header("Blur Settings")]
        [Range(0f, 25f)]
        [Tooltip("Strength of the blur in virtual 720p pixels. It is scaled automatically for high-resolution XR eye textures.")]
        public float blurStrength = 10f;

        [Range(0f, 2f)]
        [Tooltip("Multiplier for blur above the focus band")]
        public float topBlurStrength = 1f;

        [Range(0f, 2f)]
        [Tooltip("Multiplier for blur below the focus band")]
        public float bottomBlurStrength = 1f;

        [Range(-0.5f, 0.5f)]
        [Tooltip("Moves the top blur edge up (+) or down (-) independently of the focus band, to align the sharp band in VR.")]
        public float topBlurOffset = 0f;

        [Range(-0.5f, 0.5f)]
        [Tooltip("Moves the bottom blur edge down (+) or up (-) independently of the focus band, to align the sharp band in VR.")]
        public float bottomBlurOffset = 0f;
        
        [Range(3, 16)]
        [Tooltip("Number of blur samples (higher = smoother but slower)")]
        public int blurSamples = 8;
        
        [Range(0f, 1f)]
        [Tooltip("Bokeh shape intensity (0=uniform, 1=ring-shaped)")]
        public float bokehShape = 0.5f;
        
        [Header("Miniature Color Enhancement")]
        [Range(0.5f, 2f)]
        [Tooltip("Boost color saturation for toy-like appearance")]
        public float saturationBoost = 1f;
        
        [Range(0.5f, 2f)]
        [Tooltip("Boost contrast for sharper miniature look")]
        public float contrastBoost = 1f;
        
        [Range(0f, 1f)]
        [Tooltip("Vignette darkening at edges")]
        public float vignetteStrength = 0.58f;
        
        [Header("Quality")]
        [Tooltip("Use high-quality multi-pass blur (slower but better)")]
        public bool highQualityBlur = true;
        
        [Tooltip("Enable/disable the effect")]
        public bool effectEnabled = true;

        // Serialized so the shader reference is saved with the component and included in builds.
        [SerializeField, HideInInspector] private Shader m_TiltShiftShader;
        private Shader m_BuiltinTiltShiftShader;
        private Material m_Material;
        private Camera m_Camera;
        private RenderTexture m_SplatDofDepth;
        private bool m_SplatDofDepthReady;
        private static readonly int PropSplatDofDepth = Shader.PropertyToID("_GaussianSplatDofDepth");
        private static readonly int PropSplatDofDepthValid = Shader.PropertyToID("_GaussianSplatDofDepthValid");
        private static readonly int PropSplatDofDepthFlipY = Shader.PropertyToID("_GaussianSplatDofDepthFlipY");
        
        private static readonly int PropFocusPosition = Shader.PropertyToID("_FocusPosition");
        private static readonly int PropFocusWidth = Shader.PropertyToID("_FocusWidth");
        private static readonly int PropBlurStrength = Shader.PropertyToID("_BlurStrength");
        private static readonly int PropTopBlurStrength = Shader.PropertyToID("_TopBlurStrength");
        private static readonly int PropBottomBlurStrength = Shader.PropertyToID("_BottomBlurStrength");
        private static readonly int PropTopBlurOffset = Shader.PropertyToID("_TopBlurOffset");
        private static readonly int PropBottomBlurOffset = Shader.PropertyToID("_BottomBlurOffset");
        private static readonly int PropBlurSamples = Shader.PropertyToID("_BlurSamples");
        private static readonly int PropTiltAngle = Shader.PropertyToID("_TiltAngle");
        private static readonly int PropSaturationBoost = Shader.PropertyToID("_SaturationBoost");
        private static readonly int PropContrastBoost = Shader.PropertyToID("_ContrastBoost");
        private static readonly int PropVignetteStrength = Shader.PropertyToID("_VignetteStrength");
        private static readonly int PropBokehShape = Shader.PropertyToID("_BokehShape");
        private static readonly int PropBlurMode = Shader.PropertyToID("_BlurMode");
        private static readonly int PropFocusDistance = Shader.PropertyToID("_FocusDistance");
        private static readonly int PropFocusRange = Shader.PropertyToID("_FocusRange");
        private static readonly int PropNearBlurStrength = Shader.PropertyToID("_NearBlurStrength");
        private static readonly int PropFarBlurStrength = Shader.PropertyToID("_FarBlurStrength");

        private void OnEnable()
        {
            m_Camera = GetComponent<Camera>();
            CreateMaterial();
        }

        private void OnPreCull()
        {
            if (effectEnabled && blurMode != BlurMode.TiltShift && m_Camera != null)
                m_Camera.depthTextureMode |= DepthTextureMode.Depth;
        }

        // The built-in splat draw writes this camera-owned target before OnRenderImage consumes it.
        // URP owns an equivalent transient texture in its render graph instead.
        internal void ResetSplatDofDepth() => m_SplatDofDepthReady = false;

        internal RenderTexture PrepareSplatDofDepth(Camera camera)
        {
            ResetSplatDofDepth();
            if (!isActiveAndEnabled || !effectEnabled || blurMode == BlurMode.TiltShift ||
                blurStrength < 0.01f || SystemInfo.supportedRenderTargetCount < 2)
            {
                ReleaseSplatDofDepth();
                return null;
            }
            int width = Mathf.Max(1, camera.pixelWidth), height = Mathf.Max(1, camera.pixelHeight);
            if (m_SplatDofDepth != null && (m_SplatDofDepth.width != width || m_SplatDofDepth.height != height))
                ReleaseSplatDofDepth();
            if (m_SplatDofDepth == null)
            {
                m_SplatDofDepth = new RenderTexture(width, height, 0, RenderTextureFormat.ARGBHalf,
                    RenderTextureReadWrite.Linear)
                {
                    name = "Gaussian Splat DoF Depth", hideFlags = HideFlags.HideAndDontSave,
                    filterMode = FilterMode.Bilinear, wrapMode = TextureWrapMode.Clamp,
                    antiAliasing = 1, useMipMap = false, autoGenerateMips = false
                };
            }
            if (!m_SplatDofDepth.IsCreated()) m_SplatDofDepth.Create();
            m_SplatDofDepthReady = m_SplatDofDepth.IsCreated();
            return m_SplatDofDepthReady ? m_SplatDofDepth : null;
        }

        private void ReleaseSplatDofDepth()
        {
            m_SplatDofDepthReady = false;
            if (m_SplatDofDepth == null) return;
            m_SplatDofDepth.Release();
            if (Application.isPlaying) Destroy(m_SplatDofDepth);
            else DestroyImmediate(m_SplatDofDepth);
            m_SplatDofDepth = null;
        }

        private void OnDisable()
        {
            CleanupResources();
        }

        private void OnDestroy()
        {
            CleanupResources();
        }

        private void FindTiltShiftShader()
        {
            if (m_TiltShiftShader == null)
                m_TiltShiftShader = Shader.Find("Hidden/Gaussian Splatting/TiltShift");
        }

#if UNITY_EDITOR
        private void OnValidate() => FindTiltShiftShader();
        private void Reset() => FindTiltShiftShader();
#endif

        private void CreateMaterial()
        {
            Shader shader;
            if (GraphicsSettings.currentRenderPipeline == null)
            {
                // Keep the legacy image-effect pass in its own shader. On D3D12 the mixed
                // URP/Built-in shader can report the fallback pass yet render solid white.
                // Resources also includes this shader in existing player scenes without a resave.
                if (m_BuiltinTiltShiftShader == null)
                    m_BuiltinTiltShiftShader = Resources.Load<Shader>("GaussianTiltShiftBuiltin");
                shader = m_BuiltinTiltShiftShader;
            }
            else
            {
                FindTiltShiftShader();
                shader = m_TiltShiftShader;
            }
            if (m_Material != null && m_Material.shader == shader) return;
            DestroyMaterial();
            if (shader == null)
            {
                Debug.LogWarning("GaussianSplatTiltShiftEffect: TiltShift shader not found!");
                return;
            }
            
            if (!shader.isSupported)
            {
                Debug.LogWarning("GaussianSplatTiltShiftEffect: TiltShift shader not supported!");
                return;
            }
            
            m_Material = new Material(shader);
            m_Material.hideFlags = HideFlags.HideAndDontSave;
        }

        private void CleanupResources()
        {
            ReleaseSplatDofDepth();
            DestroyMaterial();
        }

        private void DestroyMaterial()
        {
            if (m_Material != null)
            {
                if (Application.isPlaying)
                    Destroy(m_Material);
                else
                    DestroyImmediate(m_Material);
                m_Material = null;
            }
        }

        private void UpdateMaterialProperties()
        {
            if (m_Material == null) return;
            
            m_Material.SetFloat(PropFocusPosition, focusPosition);
            m_Material.SetFloat(PropFocusWidth, focusWidth);
            m_Material.SetFloat(PropBlurStrength, blurStrength);
            m_Material.SetFloat(PropTopBlurStrength, topBlurStrength);
            m_Material.SetFloat(PropBottomBlurStrength, bottomBlurStrength);
            m_Material.SetFloat(PropTopBlurOffset, topBlurOffset);
            m_Material.SetFloat(PropBottomBlurOffset, bottomBlurOffset);
            m_Material.SetFloat(PropBlurSamples, blurSamples);
            m_Material.SetFloat(PropTiltAngle, tiltAngle);
            m_Material.SetFloat(PropSaturationBoost, saturationBoost);
            m_Material.SetFloat(PropContrastBoost, contrastBoost);
            m_Material.SetFloat(PropVignetteStrength, vignetteStrength);
            m_Material.SetFloat(PropBokehShape, bokehShape);
            m_Material.SetFloat(PropBlurMode, (float)blurMode);
            m_Material.SetFloat(PropFocusDistance, focusDistance);
            m_Material.SetFloat(PropFocusRange, focusRange);
            m_Material.SetFloat(PropNearBlurStrength, nearBlurStrength);
            m_Material.SetFloat(PropFarBlurStrength, farBlurStrength);
            m_Material.SetInt(PropSplatDofDepthValid, m_SplatDofDepthReady ? 1 : 0);
            m_Material.SetTexture(PropSplatDofDepth,
                m_SplatDofDepthReady ? (Texture)m_SplatDofDepth : Texture2D.blackTexture);
        }

        // This is the key method for built-in render pipeline
        // In URP, the GaussianTiltShiftRendererFeature reads settings from this component
        private void OnRenderImage(RenderTexture source, RenderTexture destination)
        {
            // In URP, the Renderer Feature handles rendering - this component just provides settings
            if (GraphicsSettings.currentRenderPipeline != null)
            {
                ReleaseSplatDofDepth();
                Graphics.Blit(source, destination);
                return;
            }
            
            if (!effectEnabled || blurStrength < 0.01f)
            {
                ReleaseSplatDofDepth();
                Graphics.Blit(source, destination);
                return;
            }
            
            CreateMaterial();
            if (m_Material == null)
            {
                ResetSplatDofDepth();
                Graphics.Blit(source, destination);
                return;
            }
            
            UpdateMaterialProperties();
            m_Material.SetFloat(PropSplatDofDepthFlipY, 0f);
            
            // The standalone built-in shader uses its combined pass.
            try { Graphics.Blit(source, destination, m_Material, 0); }
            finally { ResetSplatDofDepth(); }
        }

        /// <summary>
        /// Get the tilt-shift material for external use
        /// </summary>
        public Material GetMaterial()
        {
            CreateMaterial();
            UpdateMaterialProperties();
            return m_Material;
        }

        /// <summary>
        /// Set focus position from world space point
        /// </summary>
        public void SetFocusFromWorldPoint(Vector3 worldPoint)
        {
            if (m_Camera == null) return;
            
            Vector3 viewportPos = m_Camera.WorldToViewportPoint(worldPoint);
            focusPosition = Mathf.Clamp01(viewportPos.y);
        }

        /// <summary>
        /// Reset to default miniature effect settings
        /// </summary>
        public void ResetToDefaults()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.5f;
            focusWidth = 0.05f;
            tiltAngle = 0f;
            focusDistance = 10f;
            focusRange = 5f;
            nearBlurStrength = 0.5f;
            farBlurStrength = 0.8f;
            blurStrength = 10f;
            topBlurOffset = 0f;
            bottomBlurOffset = 0f;
            blurSamples = 8;
            bokehShape = 0.5f;
            saturationBoost = 1f;
            contrastBoost = 1f;
            vignetteStrength = 0.58f;
            highQualityBlur = true;
            effectEnabled = true;
        }

        /// <summary>
        /// Apply a preset for extreme miniature look
        /// </summary>
        public void ApplyMiniaturePreset()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.35f;
            focusWidth = 0.15f;
            tiltAngle = 0f;
            blurStrength = 6f;
            blurSamples = 10;
            bokehShape = 0.6f;
            saturationBoost = 1.5f;
            contrastBoost = 1.25f;
            vignetteStrength = 0.35f;
        }

        /// <summary>
        /// Apply a preset for subtle tilt effect
        /// </summary>
        public void ApplySubtlePreset()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.45f;
            focusWidth = 0.35f;
            tiltAngle = 0f;
            blurStrength = 2.5f;
            blurSamples = 6;
            bokehShape = 0.3f;
            saturationBoost = 1.15f;
            contrastBoost = 1.08f;
            vignetteStrength = 0.15f;
        }

        /// <summary>
        /// Apply a preset for diagonal tilt
        /// </summary>
        public void ApplyDiagonalPreset()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.5f;
            focusWidth = 0.2f;
            tiltAngle = 30f;
            blurStrength = 5f;
            blurSamples = 8;
            bokehShape = 0.5f;
            saturationBoost = 1.35f;
            contrastBoost = 1.2f;
            vignetteStrength = 0.3f;
        }

        /// <summary>
        /// Apply depth of field preset - portrait style (shallow DoF)
        /// </summary>
        public void ApplyPortraitDoFPreset()
        {
            blurMode = BlurMode.DepthOfField;
            focusDistance = 5f;
            focusRange = 2f;
            nearBlurStrength = 0.3f;
            farBlurStrength = 0.9f;
            blurStrength = 5f;
            blurSamples = 8;
            bokehShape = 0.7f;
            saturationBoost = 1.1f;
            contrastBoost = 1.05f;
            vignetteStrength = 0.2f;
        }

        /// <summary>
        /// Apply depth of field preset - landscape style (deep focus far)
        /// </summary>
        public void ApplyLandscapeDoFPreset()
        {
            blurMode = BlurMode.DepthOfField;
            focusDistance = 20f;
            focusRange = 15f;
            nearBlurStrength = 0.7f;
            farBlurStrength = 0.2f;
            blurStrength = 4f;
            blurSamples = 8;
            bokehShape = 0.4f;
            saturationBoost = 1.2f;
            contrastBoost = 1.1f;
            vignetteStrength = 0.15f;
        }

        /// <summary>
        /// Apply combined tilt-shift + DoF preset
        /// </summary>
        public void ApplyCinematicPreset()
        {
            blurMode = BlurMode.Both;
            focusPosition = 0.45f;
            focusWidth = 0.3f;
            tiltAngle = 0f;
            focusDistance = 8f;
            focusRange = 4f;
            nearBlurStrength = 0.4f;
            farBlurStrength = 0.6f;
            blurStrength = 4f;
            blurSamples = 10;
            bokehShape = 0.5f;
            saturationBoost = 1.25f;
            contrastBoost = 1.15f;
            vignetteStrength = 0.3f;
        }
    }
}
