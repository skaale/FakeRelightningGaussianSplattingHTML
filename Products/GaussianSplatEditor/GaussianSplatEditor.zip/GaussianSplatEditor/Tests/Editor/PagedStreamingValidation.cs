using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Runtime;
using UnityEditor;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    // Run with a graphics device:
    // -executeMethod GaussianSplatting.Tests.PagedStreamingValidation.Run -quit
    public static class PagedStreamingValidation
    {
        const int SplatCount = 513;
        const int PrefixCount = 256;
        const BindingFlags PrivateInstance = BindingFlags.Instance | BindingFlags.NonPublic;

        public static void Run()
        {
            string folder = "Assets/__SplatBoxPagedStreamingValidation_" + Guid.NewGuid().ToString("N");
            Directory.CreateDirectory(folder);
            var objects = new List<UnityEngine.Object>();
            try
            {
                foreach (GaussianSplatAsset.VectorFormat format in Enum.GetValues(typeof(GaussianSplatAsset.VectorFormat)))
                {
                    var asset = CreateAsset(folder, "vector_" + format, format, format,
                        GaussianSplatAsset.SHFormat.Float16, objects);
                    var page = CreatePage(asset, 0, Vector3.one * 3, folder, objects);
                    ValidatePrefix(page);
                    ValidatePrefix(page, 129);
                }
                var clustered = CreateAsset(folder, "clustered", GaussianSplatAsset.VectorFormat.Norm16,
                    GaussianSplatAsset.VectorFormat.Norm16, GaussianSplatAsset.SHFormat.Cluster4k, objects);
                ValidatePrefix(CreatePage(clustered, 10, Vector3.one * 3, folder, objects));

                var uncompressed = CreateAsset(folder, "uncompressed", GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.VectorFormat.Float32, GaussianSplatAsset.SHFormat.Float32, objects);
                ValidateStationaryStreaming(uncompressed, folder, objects);
                ValidateInitialCoarseTarget(uncompressed, folder, objects);
                ValidateRotationStreaming(uncompressed, folder, objects);
                ValidateDeferredDetailTransitions(uncompressed, folder, objects);
                ValidateCompletedWorkerBeforeStreaming(uncompressed, folder, objects);
                ValidateVisibleDistanceStreaming(uncompressed, folder, objects);
                ValidateSmallPageResidency(uncompressed, folder, objects);
                ValidateEditorResidencyCapacity(objects);
                Debug.Log("SplatBox paged streaming PASS: compressed prefix ranges, shared SH tables, " +
                    "stationary progress, paced coarse target growth, rotation refinement, worker-safe detail ownership, completed-worker publication before streaming, visible distant detail ranking, transformed bounds, editor residency capacity, per-frame upload pacing and retired detail slots.");
            }
            finally
            {
                // Streamers own their GPU resources, so destroy GameObjects before source assets.
                for (int i = objects.Count - 1; i >= 0; --i)
                {
                    // Edit-mode fixtures never enter Awake/OnEnable, so Unity need not invoke
                    // MonoBehaviour.OnDestroy. Release ownership explicitly in this harness.
                    if (objects[i] is GameObject root)
                        root.GetComponent<SplatBoxLodStreamer>()?.UnloadAll();
                    if (objects[i] != null) UnityEngine.Object.DestroyImmediate(objects[i]);
                }
                AssetDatabase.DeleteAsset(folder);
            }
        }

        static void ValidatePrefix(GaussianSplatPageAsset page, int count = PrefixCount)
        {
            using var state = SplatBoxPageGpuState.UploadCoarseLevel(page, 0, count);
            Require(state != null && state.IsReady && state.isCoarseStub, "Coarse upload was not ready");
            Require(state.splatCount == count, "Coarse upload exceeded its exact atlas reservation");
            var asset = page.splatData;
            bool clustered = asset.shFormat >= GaussianSplatAsset.SHFormat.Cluster64k;
            int expectedPos = (count * GaussianSplatAsset.GetVectorSize(asset.posFormat) + 3) / 4;
            int expectedOther = (count *
                (GaussianSplatAsset.GetOtherSizeNoSHIndex(asset.scaleFormat) + (clustered ? 2 : 0)) + 3) / 4;
            int expectedSH = clustered ? (int)(asset.shData.dataSize / 4) :
                (int)((GaussianSplatAsset.CalcSHDataSize(count, asset.shFormat) + 3) / 4);
            ValidateBuffer(state.gpuPosData, asset.posData, expectedPos, "position " + asset.posFormat);
            ValidateBuffer(state.gpuOtherData, asset.otherData, expectedOther, "other " + asset.scaleFormat);
            ValidateBuffer(state.gpuSHData, asset.shData, expectedSH, "SH " + asset.shFormat);
            var residentPos = state.gpuPosData;
            state.uploadedAtlasOffset = 123;
            Require(state.SetCoarseSplatLimit(65) && state.splatCount == 65 && state.IsReady,
                "Coarse tree did not shrink to the atlas reservation");
            Require(ReferenceEquals(residentPos, state.gpuPosData) && state.uploadedAtlasOffset < 0,
                "Coarse tree shrink replaced GPU data or retained stale atlas residency");
            Require(state.SetCoarseSplatLimit(count) && state.splatCount == count && state.IsReady,
                "Coarse tree did not restore its existing uploaded prefix");
        }

        static void ValidateBuffer(GraphicsBuffer buffer, TextAsset source, int expectedWords, string label)
        {
            Require(buffer.count == expectedWords, label + " prefix buffer has an incorrect byte range");
            var actual = new uint[expectedWords];
            buffer.GetData(actual);
            var expected = source.GetData<uint>();
            for (int i = 0; i < actual.Length; ++i)
                Require(actual[i] == expected[i], label + " prefix data mismatch at word " + i);
        }

        static void ValidateStationaryStreaming(GaussianSplatAsset asset, string folder, List<UnityEngine.Object> objects)
        {
            var entries = new GaussianSplatPageEntry[4];
            for (int i = 0; i < entries.Length; ++i)
            {
                Vector3 min = new Vector3(3 + i * 3, -1, -1);
                var page = CreatePage(asset, 100 + i, min, folder, objects);
                entries[i] = new GaussianSplatPageEntry
                {
                    pageId = page.pageId, pageAsset = page, boundsMin = page.boundsMin,
                    boundsMax = page.boundsMax, splatCount = page.splatCount, lodNodeCount = page.lodNodeCount
                };
            }
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(Vector3.zero, Vector3.one * 20, 3, entries);
            SetField(scene, "m_CoarsePageSplats", PrefixCount);
            SetField(scene, "m_MaxLoadedPages", 2);
            var root = new GameObject("Paged streaming validation");
            objects.Add(root);
            var camera = root.AddComponent<Camera>();
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            streamer.SetAtlasLimits(2, false);

            streamer.UpdateStreaming(camera, root.transform, force: true);
            Require(streamer.loadedPages.Count == 1 && streamer.loadedPages[0].isCoarseStub,
                "Cold start must upload one coarse page");
            var firstCoarse = streamer.loadedPages[0];
            streamer.UpdateStreaming(camera, root.transform, force: true);
            Require(streamer.loadedPages.Count == 1 && ReferenceEquals(firstCoarse, streamer.loadedPages[0]),
                "Forced calls in the same frame exceeded the upload budget");

            AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(entries[0].pageId, out var near) && !near.isCoarseStub,
                "A stationary viewer's nearest page did not refine while far coarse pages were pending");
            Require(streamer.hasPendingCoarseLoads, "Fixture did not exercise partial scene residency");
            for (int i = 0; i < 10; ++i)
                AdvanceStreaming(streamer, camera, root.transform);
            Require(!streamer.hasPendingCoarseLoads && streamer.loadedPages.Count == entries.Length,
                "Stationary streaming did not finish scene coverage");
            int fullCount = 0;
            foreach (var page in streamer.loadedPages)
            {
                Require(page.IsReady, "Resident page lost GPU/tree data");
                if (!page.isCoarseStub) ++fullCount;
            }
            Require(fullCount == 2, "Stationary streaming did not fill the two available detail slots");
            ValidateCoarseTargetGrowth(streamer, camera, root.transform);

            SplatBoxPageGpuState coarse = null;
            foreach (var page in streamer.loadedPages)
                if (page.isCoarseStub) coarse = page;
            Require(coarse != null, "Fixture has no coarse page for atlas resizing");
            var residentPos = coarse.gpuPosData;
            streamer.SetAtlasLimits(2, false, 129);
            Require(coarse.splatCount == 129 && coarse.IsReady && ReferenceEquals(residentPos, coarse.gpuPosData),
                "Reduced atlas coarse reservation lost resident coverage or uploaded new GPU data");
            Require(streamer.coarsePageSplats == 129, "Streamer ignored the atlas coarse reservation");
            streamer.SetAtlasLimits(1, false, 129);
            AdvanceStreaming(streamer, camera, root.transform);
            var freeSlots = (Stack<int>)GetField(streamer, "m_FreeDetailSlots");
            foreach (int slot in freeSlots)
                Require(slot >= 0 && slot < 1, "Retired atlas slot was returned to the free pool");
            foreach (var page in streamer.loadedPages)
                Require(page.detailSlot < 1, "Page retained a retired atlas slot");
            streamer.SetAtlasLimits(0, false, 129);
            AdvanceStreaming(streamer, camera, root.transform);
            Require(freeSlots.Count == 0, "Zero-capacity atlas still offered detail slots");
            foreach (var page in streamer.loadedPages)
                Require(page.isCoarseStub && page.IsReady && page.splatCount <= 129,
                    "Atlas shrink lost coarse scene coverage or restored an oversized parked tier");
        }

        static void ValidateCoarseTargetGrowth(SplatBoxLodStreamer streamer, Camera camera, Transform transform)
        {
            const int target = 384;
            var original = new Dictionary<int, SplatBoxPageGpuState>();
            foreach (var page in streamer.loadedPages)
                original.Add(page.pageId, page);
            var parked = (Dictionary<int, SplatBoxPageGpuState>)GetField(streamer, "m_ParkedCoarse");
            Require(parked.Count == 2, "Coarse growth fixture must retain two parked original prefixes");
            streamer.SetAtlasLimits(2, false, target, target);
            Require(streamer.coarsePageSplats == target && streamer.detailSlotCapacity == 2,
                "Atlas coarse target changed the detail-slot budget or ignored the target");
            foreach (var page in streamer.loadedPages)
                Require(ReferenceEquals(page, original[page.pageId]) &&
                    (!page.isCoarseStub || page.splatCount == PrefixCount),
                    "Changing the coarse target uploaded every live prefix immediately");

            AdvanceStreaming(streamer, camera, transform);
            int grown = 0;
            var afterFirst = new Dictionary<int, SplatBoxPageGpuState>();
            foreach (var page in streamer.loadedPages)
            {
                afterFirst.Add(page.pageId, page);
                var before = original[page.pageId];
                Require(page.IsReady && page.pageSlot == before.pageSlot && page.detailSlot == before.detailSlot,
                    "Coarse target refresh changed a slot or lost resident coverage");
                if (!ReferenceEquals(page, before))
                {
                    grown++;
                    Require(page.isCoarseStub && page.splatCount == target && before.gpuPosData == null,
                        "Coarse replacement failed to grow its payload or release the retired buffers");
                    float start = (float)GetField(page, "m_RefinementStartTime");
                    Require(page.RefinementNodeLimit(start) == PrefixCount,
                        "A larger coarse payload skipped its original visual frontier");
                }
            }
            Require(grown == 1 && (bool)GetField(streamer, "m_HasPendingStreamingWork"),
                "Coarse refresh must upload one page and retain stationary pending work");
            ValidateResidentSelectionIndices(streamer);
            streamer.UpdateStreaming(camera, transform, force: true);
            foreach (var page in streamer.loadedPages)
                Require(ReferenceEquals(page, afterFirst[page.pageId]),
                    "Repeated same-frame calls uploaded a second coarse replacement");

            AdvanceStreaming(streamer, camera, transform);
            foreach (var page in streamer.loadedPages)
            {
                var before = original[page.pageId];
                Require(page.pageSlot == before.pageSlot && page.detailSlot == before.detailSlot && page.IsReady,
                    "Stationary coarse growth changed slot ownership or lost coverage");
                Require(page.isCoarseStub ? page.splatCount == target : ReferenceEquals(page, before),
                    "Stationary coarse growth stopped early or replaced an existing full-detail page");
            }
            Require(!(bool)GetField(streamer, "m_HasPendingStreamingWork") && streamer.detailSlotCapacity == 2,
                "Completed coarse growth remained pending or changed the detail-slot budget");
            foreach (var entry in parked)
                Require(entry.Value.IsReady && entry.Value.splatCount == PrefixCount,
                    "Growing the live coarse target rebuilt parked prefixes before they were needed");
            ValidateResidentSelectionIndices(streamer);

            // Dropping the optional target restores the scene default. A later restoration must
            // reuse the already uploaded larger buffers, and the target belongs in the API cache key.
            var buffers = new Dictionary<int, GraphicsBuffer>();
            foreach (var page in streamer.loadedPages)
                if (page.isCoarseStub) buffers.Add(page.pageId, page.gpuPosData);
            streamer.SetAtlasLimits(2, false, target);
            Require(streamer.coarsePageSplats == PrefixCount, "Zero optional target did not preserve the scene default");
            streamer.SetAtlasLimits(2, false, target, target);
            foreach (var page in streamer.loadedPages)
                if (page.isCoarseStub)
                    Require(page.splatCount == target && ReferenceEquals(buffers[page.pageId], page.gpuPosData),
                        "Restoring an uploaded coarse target allocated replacement GPU buffers");
            ValidateResidentSelectionIndices(streamer);
        }

        static void ValidateResidentSelectionIndices(SplatBoxLodStreamer streamer)
        {
            int pageCount = streamer.loadedPages.Count;
            var contexts = new SplatBoxLodTraverser.PageContext[pageCount];
            for (int i = 0; i < pageCount; i++)
            {
                var page = streamer.loadedPages[i];
                contexts[i] = new SplatBoxLodTraverser.PageContext { pageSlot = page.pageSlot,
                    nodes = page.lodTree.nodes, nodeLimit = page.RefinementNodeLimit(Time.realtimeSinceStartup),
                    childTable = page.lodTree.childTable, childTableStart = page.lodTree.childTableStart,
                    localToWorld = float4x4.identity, lodScale = 1, outsideFoveate = 1, behindFoveate = 1 };
            }
            var output = new LodActiveSplatRef[SplatCount * pageCount];
            var view = new SplatBoxLodTraverser.ViewContext { orthographic = true, pixelScaleFactor = 1,
                cameraForward = new float3(0, 0, 1), cosHalfFovY = -1, splatScale = 1 };
            int selected = SplatBoxLodTraverser.Traverse(contexts, pageCount, view, output.Length, 0,
                output, new SplatBoxLodTraverser.Workspace());
            Require(selected >= pageCount, "Coarse target refresh lost a resident page's frontier");
            for (int i = 0; i < selected; i++)
            {
                var page = streamer.GetPageBySlot((int)output[i].pageSlot);
                Require(page != null && output[i].splatIndex < page.splatCount,
                    "Coarse target refresh emitted an index outside its uploaded payload");
            }
        }

        static void ValidateInitialCoarseTarget(GaussianSplatAsset asset, string folder,
            List<UnityEngine.Object> objects)
        {
            var page = CreatePage(asset, 600, new Vector3(-1, -1, 8), folder, objects);
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(page.boundsMin, page.boundsMax, 2, new[]
            {
                new GaussianSplatPageEntry { pageId = page.pageId, pageAsset = page,
                    boundsMin = page.boundsMin, boundsMax = page.boundsMax, splatCount = page.splatCount }
            });
            SetField(scene, "m_CoarsePageSplats", PrefixCount);
            var root = new GameObject("Initial atlas coarse target validation");
            objects.Add(root);
            var camera = root.AddComponent<Camera>();
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            streamer.SetAtlasLimits(1, false, 384, 384);
            streamer.UpdateStreaming(camera, root.transform, force: true);
            Require(streamer.TryGetPageState(page.pageId, out var resident) && resident.IsReady &&
                resident.isCoarseStub && resident.splatCount == 384 && streamer.detailSlotCapacity == 1,
                "Initial coarse upload ignored the atlas-funded target");
            ValidateResidentSelectionIndices(streamer);
        }

        static void ValidateRotationStreaming(GaussianSplatAsset asset, string folder, List<UnityEngine.Object> objects)
        {
            var front = CreatePage(asset, 300, new Vector3(-1, -1, 20), folder, objects);
            var back = CreatePage(asset, 301, new Vector3(-1, -1, -22), folder, objects);
            var entries = new[]
            {
                new GaussianSplatPageEntry { pageId = front.pageId, pageAsset = front,
                    boundsMin = front.boundsMin, boundsMax = front.boundsMax, splatCount = front.splatCount },
                new GaussianSplatPageEntry { pageId = back.pageId, pageAsset = back,
                    boundsMin = back.boundsMin, boundsMax = back.boundsMax, splatCount = back.splatCount }
            };
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(back.boundsMin, front.boundsMax, 2, entries);
            SetField(scene, "m_CoarsePageSplats", PrefixCount);
            SetField(scene, "m_MaxLoadedPages", 1);
            var root = new GameObject("Rotation streaming validation");
            objects.Add(root);
            var cameraObject = new GameObject("Rotation streaming camera");
            objects.Add(cameraObject);
            var camera = cameraObject.AddComponent<Camera>();
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            streamer.SetAtlasLimits(1, false);
            streamer.UpdateStreaming(camera, root.transform, force: true);
            for (int i = 0; i < 4; ++i)
                AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(front.pageId, out var frontDetail) && !frontDetail.isCoarseStub &&
                streamer.TryGetPageState(back.pageId, out var backCoarse) && backCoarse.isCoarseStub,
                "Rotation fixture did not reserve its one detail slot for the original view");

            // A settled edit-mode camera must be able to move its detail slot to the newly faced
            // page. The prior edit-mode eviction ban left that page coarse indefinitely.
            frontDetail.detailAcquiredTime = -1000f;
            camera.transform.rotation = Quaternion.Euler(0, 180, 0);
            AdvanceStreaming(streamer, camera, root.transform);
            streamer.TryGetPageState(back.pageId, out var backDetail);
            streamer.TryGetPageState(front.pageId, out var frontCoarse);
            Require(backDetail != null && !backDetail.isCoarseStub && frontCoarse != null && frontCoarse.isCoarseStub,
                "Rotation left newly visible distant geometry at coarse detail");
            Require(streamer.loadedPages.Count == entries.Length && frontCoarse.IsReady && backDetail.IsReady,
                "Rotating detail replacement lost coarse scene coverage");

            streamer.UpdateStreaming(camera, root.transform, force: true);
            Require(streamer.TryGetPageState(back.pageId, out var sameFrame) && ReferenceEquals(sameFrame, backDetail),
                "Rotation replacement exceeded the per-frame upload budget");

            // Rotating straight back must respect the existing hold time instead of swapping the
            // slot repeatedly. Once it expires, pending work must complete without translation.
            camera.transform.rotation = Quaternion.identity;
            AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(back.pageId, out var held) && ReferenceEquals(held, backDetail) &&
                !held.isCoarseStub, "Camera rotation bypassed detail-slot hysteresis");
            backDetail.detailAcquiredTime = -1000f;
            AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(front.pageId, out var restored) && !restored.isCoarseStub &&
                streamer.TryGetPageState(back.pageId, out var retained) && retained.isCoarseStub && retained.IsReady,
                "Stationary streaming did not finish a rotation update after the slot hold expired");

            // URP's tracked eye pose can differ from Camera.transform during VR rendering. A turn
            // represented only by raw eye views must rank the same pages as a transform-driven turn.
            restored.detailAcquiredTime = -1000f;
            try
            {
                Matrix4x4 projection = Matrix4x4.Perspective(60f, 1f, 0.1f, 100f);
                Matrix4x4 flip = Matrix4x4.Scale(new Vector3(1, 1, -1));
                Matrix4x4 monoView = flip * Matrix4x4.Rotate(Quaternion.Euler(0, 90, 0)).inverse;
                GaussianSplatRenderSystem.SetOverrideMatrices(monoView, projection);
                Require(Vector3.Dot(GaussianSplatRenderSystem.GetStreamingViewDirection(camera), Vector3.right) > 0.999f,
                    "Streaming direction ignored the current raw mono eye view");
                Quaternion rotation = Quaternion.Euler(0, 180, 0);
                Matrix4x4 leftView = flip * Matrix4x4.TRS(new Vector3(-0.032f, 0, 0), rotation, Vector3.one).inverse;
                Matrix4x4 rightView = flip * Matrix4x4.TRS(new Vector3(0.032f, 0, 0), rotation, Vector3.one).inverse;
                GaussianSplatRenderSystem.SetOverrideMatrices(leftView, projection);
                GaussianSplatRenderSystem.SetOverrideStereoMatrices(leftView, projection, rightView, projection);
                Require(Vector3.Dot(camera.transform.forward, Vector3.forward) > 0.999f &&
                    Vector3.Dot(GaussianSplatRenderSystem.GetStreamingViewDirection(camera), Vector3.back) > 0.999f,
                    "Raw stereo streaming fixture did not separate tracked eye pose from Camera.transform");
                AdvanceStreaming(streamer, camera, root.transform);
                Require(streamer.TryGetPageState(back.pageId, out var trackedDetail) && !trackedDetail.isCoarseStub &&
                    streamer.TryGetPageState(front.pageId, out var trackedCoarse) && trackedCoarse.isCoarseStub && trackedCoarse.IsReady,
                    "A VR eye-only rotation left the newly faced page coarse or lost background coverage");
            }
            finally
            {
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideMatrices();
            }
        }

        static void AdvanceStreaming(SplatBoxLodStreamer streamer, Camera camera, Transform transform,
            bool allowDetailTransitions = true)
        {
            // Simulate a later frame without sleeping or entering Play Mode. Do not force the
            // update, so camera movement/rotation and pending-work scheduling are exercised.
            SetField(streamer, "m_LastPageUploadFrame", -1);
            SetField(streamer, "m_LastStreamTime", -1000f);
            streamer.UpdateStreaming(camera, transform, allowDetailTransitions: allowDetailTransitions);
        }

        static void ValidateDeferredDetailTransitions(GaussianSplatAsset asset, string folder,
            List<UnityEngine.Object> objects)
        {
            var front = CreatePage(asset, 700, new Vector3(-1, -1, 20), folder, objects);
            var back = CreatePage(asset, 701, new Vector3(-1, -1, -22), folder, objects);
            var far = CreatePage(asset, 702, new Vector3(80, -1, 80), folder, objects);
            var entries = new[] { Entry(front), Entry(back), Entry(far) };
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(back.boundsMin, far.boundsMax, 2, entries);
            SetField(scene, "m_CoarsePageSplats", PrefixCount);
            SetField(scene, "m_MaxLoadedPages", 1);
            var root = new GameObject("Deferred detail ownership validation");
            objects.Add(root);
            var cameraOwner = new GameObject("Deferred detail ownership camera");
            objects.Add(cameraOwner);
            var camera = cameraOwner.AddComponent<Camera>();
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            streamer.SetAtlasLimits(1, false);
            streamer.UpdateStreaming(camera, root.transform, force: true);
            AdvanceStreaming(streamer, camera, root.transform);
            AdvanceStreaming(streamer, camera, root.transform);
            SplatBoxPageGpuState waiting = null;
            Require(streamer.TryGetPageState(front.pageId, out var held) && !held.isCoarseStub &&
                streamer.TryGetPageState(back.pageId, out waiting) && waiting.isCoarseStub &&
                !streamer.TryGetPageState(far.pageId, out _),
                "Deferred transition fixture did not retain a detail page and pending coarse arrival.");
            int ownedSlot = held.detailSlot;
            held.detailAcquiredTime = -1000f;
            camera.transform.rotation = Quaternion.Euler(0, 180, 0);

            AdvanceStreaming(streamer, camera, root.transform, allowDetailTransitions: false);
            Require(streamer.TryGetPageState(front.pageId, out var retained) && ReferenceEquals(retained, held) &&
                retained.detailSlot == ownedSlot && !retained.isCoarseStub &&
                streamer.TryGetPageState(back.pageId, out var stillWaiting) && ReferenceEquals(stillWaiting, waiting),
                "A deferred rank update replaced detail ownership while the worker could still address it.");
            Require(streamer.TryGetPageState(far.pageId, out var arrived) && arrived.isCoarseStub && arrived.IsReady &&
                !streamer.hasPendingCoarseLoads,
                "Deferring detail transitions also stalled coarse scene coverage.");

            streamer.SetAtlasLimits(1, false, 384, 384);
            AdvanceStreaming(streamer, camera, root.transform, allowDetailTransitions: false);
            AdvanceStreaming(streamer, camera, root.transform, allowDetailTransitions: false);
            Require(streamer.TryGetPageState(front.pageId, out retained) && ReferenceEquals(retained, held) &&
                retained.detailSlot == ownedSlot && !retained.isCoarseStub &&
                streamer.TryGetPageState(back.pageId, out stillWaiting) && stillWaiting.isCoarseStub &&
                stillWaiting.splatCount == 384 && streamer.TryGetPageState(far.pageId, out arrived) &&
                arrived.isCoarseStub && arrived.splatCount == 384,
                "Deferred streaming changed detail ownership or failed to grow resident coarse prefixes.");

            AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(back.pageId, out var upgraded) && !upgraded.isCoarseStub &&
                streamer.TryGetPageState(front.pageId, out var downgraded) && downgraded.isCoarseStub && downgraded.IsReady,
                "The default transition policy failed to move the released slot to the newly faced page.");
            camera.transform.position = new Vector3(0, 0, -200);
            AdvanceStreaming(streamer, camera, root.transform, allowDetailTransitions: false);
            Require(streamer.TryGetPageState(back.pageId, out var outside) && outside.isCoarseStub && outside.IsReady,
                "Deferral pinned full detail beyond the mandatory unload radius.");
            camera.transform.position = Vector3.zero;
            AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(back.pageId, out upgraded) && !upgraded.isCoarseStub,
                "A page failed to regain detail after returning inside the load radius.");
            streamer.SetAtlasLimits(0, false, 384, 384);
            AdvanceStreaming(streamer, camera, root.transform, allowDetailTransitions: false);
            foreach (var page in streamer.loadedPages)
                Require(page.isCoarseStub && page.IsReady && page.detailSlot < 0,
                    "Deferral retained an invalid detail slot after a mandatory atlas shrink.");
        }

        static void ValidateCompletedWorkerBeforeStreaming(GaussianSplatAsset asset, string folder,
            List<UnityEngine.Object> objects)
        {
            var front = CreatePage(asset, 710, new Vector3(-1, -1, 20), folder, objects);
            var back = CreatePage(asset, 711, new Vector3(-1, -1, -22), folder, objects);
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(back.boundsMin, front.boundsMax, 2, new[] { Entry(front), Entry(back) });
            SetField(scene, "m_CoarsePageSplats", PrefixCount);
            SetField(scene, "m_MaxLoadedPages", 1);
            var root = new GameObject("Completed worker before streaming validation");
            root.SetActive(false);
            objects.Add(root);
            var cameraOwner = new GameObject("Completed worker driving camera");
            objects.Add(cameraOwner);
            var camera = cameraOwner.AddComponent<Camera>();
            var previousMains = GameObject.FindGameObjectsWithTag("MainCamera");
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            float originalRenderScale = GaussianSplatRenderSystem.SplatRenderScale;
            var renderer = root.AddComponent<SplatBoxRenderer>();
            using var indices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 10_000, 4);
            using var viewBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 10_000, 4);
            using var sortKeys = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 10_000, 4);
            using var worker = new SplatBoxLodSelectionWorker();
            Action observer = null;
            try
            {
                foreach (var existing in previousMains) existing.tag = "Untagged";
                cameraOwner.tag = "MainCamera";
                streamer.Configure(scene, root.transform);
                streamer.SetAtlasLimits(1, false);
                streamer.UpdateStreaming(camera, root.transform, force: true);
                for (int i = 0; i < 4; ++i) AdvanceStreaming(streamer, camera, root.transform);
                SplatBoxPageGpuState waiting = null;
                Require(streamer.TryGetPageState(front.pageId, out var held) && !held.isCoarseStub &&
                    streamer.TryGetPageState(back.pageId, out waiting) && waiting.isCoarseStub,
                    "Completed worker fixture did not establish replaceable detail ownership.");
                held.atlasOffset = 2048;
                waiting.atlasOffset = 4096;
                held.detailAcquiredTime = -1000f;
                camera.transform.rotation = Quaternion.Euler(0, 180, 0);
                SetField(renderer, "m_PagedScene", scene);
                SetField(renderer, "m_LodStreamer", streamer);
                SetField(renderer, "m_CSBoxUtil", AssetDatabase.LoadAssetAtPath<ComputeShader>(
                    UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly)
                        .assetPath + "/Resources/BoxUtil.compute"));
                SetField(renderer, "m_LodSimpleMode", false);
                SetField(renderer, "m_LodSplatBudget", 10_000);
                SetField(renderer, "m_LodAllocatedBudget", 10_000);
                SetField(renderer, "m_LodActiveScratch", new LodActiveSplatRef[10_000]);
                SetField(renderer, "m_LodAtlasIndexScratch", new uint[10_000]);
                SetField(renderer, "m_GpuLodAtlasIndices", indices);
                renderer.m_GpuView = viewBuffer;
                renderer.m_GpuSortKeys = sortKeys;
                SetField(renderer, "m_LodAtlasDirty", false);
                SetField(renderer, "m_ActiveSplatCount", 77);
                SetField(renderer, "m_LodSelectionWorker", worker);
                Call(renderer, "RecordLodViewpoint", camera);
                SetField(renderer, "m_AsyncLodSettingsHash", Call(renderer, "LodSelectionSettingsHash"));
                SetField(renderer, "m_AsyncLodViewSignature", GetField(renderer, "m_LastLodViewSignature"));
                SetField(renderer, "m_AsyncLodViewPos", camera.transform.position);
                SetField(renderer, "m_AsyncLodViewRot", camera.transform.rotation);
                var tree = LodTreeRuntime.Build(new[]
                {
                    new LodTreeNode { center = new float3(0, 0, 5), featureSize = 1, childStart = 1, childCount = 2 },
                    new LodTreeNode { center = new float3(-0.1f, 0, 5), featureSize = 0.1f },
                    new LodTreeNode { center = new float3(0.1f, 0, 5), featureSize = 0.1f }
                }, true);
                var contexts = new[] { new SplatBoxLodTraverser.PageContext
                {
                    pageSlot = held.pageSlot, nodes = tree.nodes, localToWorld = float4x4.identity,
                    lodScale = 1, outsideFoveate = 1, behindFoveate = 1
                } };
                var view = new SplatBoxLodTraverser.ViewContext
                {
                    orthographic = true, cameraForward = new float3(0, 0, 1), pixelScaleFactor = 1000,
                    pixelsPerUnitAtUnitDistance = 500, cosHalfFovY = -1, splatScale = 1
                };
                int[] bases = new int[Math.Max(held.pageSlot, waiting.pageSlot) + 1];
                for (int i = 0; i < bases.Length; ++i) bases[i] = -1;
                bases[held.pageSlot] = held.atlasOffset;
                Require(worker.TryBegin(contexts, 1, view, 4, 0, bases), "Completed-worker traversal did not start.");
                var task = (System.Threading.Tasks.Task<SplatBoxLodSelectionWorker.Result>)GetField(worker, "m_Task");
                Require(task.Wait(5000) && worker.isRunning,
                    "The real worker did not finish while retaining its unpublished snapshot.");
                bool observedStreaming = false;
                observer = () =>
                {
                    observedStreaming = true;
                    Require(renderer.activeSplatCount == 2 && !worker.isRunning,
                        "Streaming invalidated ownership before the already completed selection was published.");
                    Require(streamer.TryGetPageState(back.pageId, out var replacement) && !replacement.isCoarseStub,
                        "Consuming the completed worker did not grant the normal slot-transition opportunity.");
                    // Stop at the observation boundary; no atlas allocation or next selection is needed.
                    throw new StreamingObservationComplete();
                };
                streamer.OnPagesChanged += observer;
                SetField(streamer, "m_LastPageUploadFrame", -1);
                SetField(streamer, "m_LastStreamTime", -1000f);
                try { renderer.UpdatePagedLod(camera, null); }
                catch (StreamingObservationComplete) { }
                Require(observedStreaming, "Completed-worker update did not reach the ownership transition callback.");
            }
            finally
            {
                if (observer != null) streamer.OnPagesChanged -= observer;
                cameraOwner.tag = "Untagged";
                foreach (var existing in previousMains) if (existing != null) existing.tag = "MainCamera";
                GaussianSplatRenderSystem.SplatRenderScale = originalRenderScale;
                SetField(renderer, "m_GpuLodAtlasIndices", null);
                renderer.m_GpuView = null;
                renderer.m_GpuSortKeys = null;
                SetField(renderer, "m_LodSelectionWorker", null);
                streamer.UnloadAll();
            }
        }

        sealed class StreamingObservationComplete : Exception { }

        static GaussianSplatPageEntry Entry(GaussianSplatPageAsset page) => new GaussianSplatPageEntry
        {
            pageId = page.pageId, pageAsset = page, boundsMin = page.boundsMin, boundsMax = page.boundsMax,
            splatCount = page.splatCount, lodNodeCount = page.lodNodeCount
        };

        static void ValidateVisibleDistanceStreaming(GaussianSplatAsset asset, string folder,
            List<UnityEngine.Object> objects)
        {
            // Match the constrained Android layout: four detail slots and five pages. All four
            // nearer pages begin behind the new view, but used to win by unweighted distance.
            var entries = new GaussianSplatPageEntry[5];
            for (int i = 0; i < entries.Length; i++)
            {
                var page = CreatePage(asset, 500 + i,
                    new Vector3(-1, -1, i == 0 ? 8 : -8), folder, objects);
                entries[i] = new GaussianSplatPageEntry { pageId = page.pageId, pageAsset = page,
                    boundsMin = page.boundsMin, boundsMax = page.boundsMax, splatCount = page.splatCount };
            }
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(new Vector3(-1, -1, -8), new Vector3(1, 1, 10), 2, entries);
            SetField(scene, "m_CoarsePageSplats", PrefixCount);
            SetField(scene, "m_MaxLoadedPages", 4);
            var root = new GameObject("Visible distant detail streaming validation");
            objects.Add(root);
            var cameraObject = new GameObject("Visible distant detail camera");
            objects.Add(cameraObject);
            var camera = cameraObject.AddComponent<Camera>();
            camera.transform.rotation = Quaternion.Euler(0, 180, 0);
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            streamer.SetAtlasLimits(4, false);
            streamer.UpdateStreaming(camera, root.transform, force: true);
            for (int i = 0; i < 12; i++)
                AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.detailSlotCapacity == 4 && !streamer.hasPendingCoarseLoads &&
                streamer.TryGetPageState(entries[0].pageId, out var distantCoarse) && distantCoarse.isCoarseStub,
                "Distant detail fixture did not fill its four slots in the original view");
            for (int i = 1; i < entries.Length; i++)
            {
                Require(streamer.TryGetPageState(entries[i].pageId, out var page) && !page.isCoarseStub,
                    "A nearer page did not acquire its original detail slot");
                page.detailAcquiredTime = -1000f;
            }

            camera.transform.rotation = Quaternion.identity;
            AdvanceStreaming(streamer, camera, root.transform);
            Require(streamer.TryGetPageState(entries[0].pageId, out var distantDetail) &&
                !distantDetail.isCoarseStub && distantDetail.IsReady,
                "A visible page at eight metres lost all four slots to nearer pages behind the camera");
            int full = 0, coarse = 0;
            foreach (var page in streamer.loadedPages)
            {
                Require(page.IsReady, "Visible-distance slot replacement lost coarse coverage");
                if (page.isCoarseStub) coarse++; else full++;
            }
            Require(full == 4 && coarse == 1 && streamer.loadedPages.Count == 5,
                "Visible-distance ranking changed the residency budget or lost a page");

            ValidateDetailRankBounds(streamer, objects);
        }

        static void ValidateDetailRankBounds(SplatBoxLodStreamer streamer, List<UnityEngine.Object> objects)
        {
            var visible = new GaussianSplatPageEntry
                { boundsMin = new Vector3(-1, -1, 8), boundsMax = new Vector3(1, 1, 10) };
            var behind = new GaussianSplatPageEntry
                { boundsMin = new Vector3(-1, -1, -8), boundsMax = new Vector3(1, 1, -6) };
            Require(Mathf.Abs(DetailRank(streamer, visible, 8) - 8) < 0.001f &&
                Mathf.Abs(DetailRank(streamer, behind, 6) - 22) < 0.001f,
                "Distant view ranking did not apply its bounded behind-camera penalty");

            var contact = new GaussianSplatPageEntry
                { boundsMin = new Vector3(-1, -1, -2.25f), boundsMax = new Vector3(1, 1, -0.25f) };
            Require(Mathf.Abs(DetailRank(streamer, contact, 0.25f) - 0.00025f) < 0.000001f,
                "View ranking displaced a true contact page");
            // Its centre is behind, but the bounds reach in front of the head plane. A lateral
            // separation keeps this fixture outside the absolute contact tier.
            var straddling = new GaussianSplatPageEntry
                { boundsMin = new Vector3(3, -1, -20), boundsMax = new Vector3(5, 1, 2) };
            Require(Mathf.Abs(DetailRank(streamer, straddling, 3) - 3) < 0.001f,
                "Centre-only ranking penalized a large page crossing the head plane");

            var transformObject = new GameObject("Detail ranking transformed bounds validation");
            objects.Add(transformObject);
            transformObject.transform.SetPositionAndRotation(new Vector3(4, 0, -4), Quaternion.Euler(0, 45, 0));
            transformObject.transform.localScale = new Vector3(-2, 1, 0.5f);
            var transformed = new GaussianSplatPageEntry
                { boundsMin = new Vector3(-4, -1, -1), boundsMax = new Vector3(4, 1, 1) };
            Require(Mathf.Abs(DetailRank(streamer, transformed, 3, transformObject.transform) - 3) < 0.001f,
                "Rotated, nonuniform or mirrored bounds lost their forward support");
        }

        static float DetailRank(SplatBoxLodStreamer streamer, GaussianSplatPageEntry entry, float distance,
            Transform transform = null) => (float)typeof(SplatBoxLodStreamer)
            .GetMethod("DetailRank", PrivateInstance)
            .Invoke(streamer, new object[] { Vector3.zero, Vector3.forward, entry, transform, distance });

        static void ValidateSmallPageResidency(GaussianSplatAsset asset, string folder, List<UnityEngine.Object> objects)
        {
            var page = CreatePage(asset, 200, new Vector3(100, -1, -1), folder, objects);
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            scene.Initialize(page.boundsMin, page.boundsMax, 2, new[]
            {
                new GaussianSplatPageEntry { pageId = page.pageId, pageAsset = page,
                    boundsMin = page.boundsMin, boundsMax = page.boundsMax, splatCount = page.splatCount }
            });
            SetField(scene, "m_CoarsePageSplats", 1024);
            var root = new GameObject("Small page residency validation");
            objects.Add(root);
            var camera = root.AddComponent<Camera>();
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            streamer.SetAtlasLimits(0, false, 1024);
            streamer.UpdateStreaming(camera, root.transform, force: true);
            Require(streamer.TryGetPageState(page.pageId, out var original) && !original.isCoarseStub,
                "Small page should fit in its permanent atlas region");
            SetField(streamer, "m_LastPageUploadFrame", -1);
            streamer.UpdateStreaming(camera, root.transform, force: true);
            Require(streamer.TryGetPageState(page.pageId, out var current) && ReferenceEquals(original, current),
                "Distant small page was unnecessarily disposed and uploaded again");
        }

        static void ValidateEditorResidencyCapacity(List<UnityEngine.Object> objects)
        {
            const int totalSplats = 6_000_000;
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            objects.Add(scene);
            // Metadata is sufficient here: do not allocate a multi-million-splat GPU fixture.
            scene.Initialize(Vector3.zero, Vector3.one, 1, new[]
            {
                new GaussianSplatPageEntry { pageId = 400, splatCount = totalSplats / 2 },
                new GaussianSplatPageEntry { pageId = 401, splatCount = totalSplats / 2 }
            });
            var root = new GameObject("Editor residency capacity validation");
            objects.Add(root);
            var streamer = root.AddComponent<SplatBoxLodStreamer>();
            streamer.Configure(scene, root.transform);
            Require(!streamer.wantsFullSceneResidency && !SplatBoxLodStreamer.CanEditorLoadAllPages(scene),
                "Editor residency lost its conservative default before atlas sizing");
            streamer.SetEditorFullSceneSplatCapacity(totalSplats - 1);
            Require(!streamer.wantsFullSceneResidency, "Editor residency exceeded the supplied atlas capacity");
            streamer.SetEditorFullSceneSplatCapacity(totalSplats);
            Require(streamer.wantsFullSceneResidency && streamer.loadsEveryPageAtFullDetail,
                "A scene that fits the supplied editor atlas capacity remained artificially sparse");
            streamer.SetAtlasLimits(0, false);
            Require(streamer.wantsFullSceneResidency && !streamer.loadsEveryPageAtFullDetail,
                "Editor residency ignored the exact atlas-layout affordability veto");
            streamer.SetAtlasLimits(0, true);
            Require(streamer.loadsEveryPageAtFullDetail, "An affordable editor layout did not enable full residency");
            streamer.SetEditorFullSceneSplatCapacity(0);
            Require(!streamer.wantsFullSceneResidency && !streamer.loadsEveryPageAtFullDetail,
                "Editor residency retained a scene after its available atlas capacity shrank");
            Require(!SplatBoxLodStreamer.CanEditorLoadAllPages(scene),
                "The existing static editor-residency API lost its conservative default");
        }

        static GaussianSplatAsset CreateAsset(string folder, string name, GaussianSplatAsset.VectorFormat pos,
            GaussianSplatAsset.VectorFormat scale, GaussianSplatAsset.SHFormat sh, List<UnityEngine.Object> objects)
        {
            var asset = ScriptableObject.CreateInstance<GaussianSplatAsset>();
            objects.Add(asset);
            asset.Initialize(SplatCount, pos, scale, GaussianSplatAsset.ColorFormat.Norm8x4, sh,
                Vector3.zero, Vector3.one, null);
            bool clustered = sh >= GaussianSplatAsset.SHFormat.Cluster64k;
            int shBytes = clustered ? GaussianSplatAsset.GetSHCount(sh, SplatCount) * 96 :
                (int)GaussianSplatAsset.CalcSHDataSize(SplatCount, sh);
            asset.SetAssetFiles(null,
                CreateData(folder, name + "_pos", SplatCount * GaussianSplatAsset.GetVectorSize(pos)),
                CreateData(folder, name + "_other", SplatCount *
                    (GaussianSplatAsset.GetOtherSizeNoSHIndex(scale) + (clustered ? 2 : 0))),
                CreateData(folder, name + "_color", (int)GaussianSplatAsset.CalcColorDataSize(SplatCount,
                    GaussianSplatAsset.ColorFormat.Norm8x4)), CreateData(folder, name + "_sh", shBytes));
            return asset;
        }

        static GaussianSplatPageAsset CreatePage(GaussianSplatAsset asset, int id, Vector3 min,
            string folder, List<UnityEngine.Object> objects)
        {
            var nodes = new LodTreeNode[SplatCount];
            nodes[0] = new LodTreeNode { childStart = 1, childCount = SplatCount - 1, featureSize = 2 };
            for (int i = 1; i < nodes.Length; ++i)
                nodes[i].featureSize = 0.1f;
            string path = folder + "/tree_" + id + "_" + asset.posFormat + "_" + asset.shFormat + ".bytes";
            File.WriteAllBytes(path, LodTreeNode.ToBytes(nodes));
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            var page = ScriptableObject.CreateInstance<GaussianSplatPageAsset>();
            objects.Add(page);
            page.Initialize(id, Vector3Int.zero, min, min + Vector3.one * 2, asset,
                AssetDatabase.LoadAssetAtPath<TextAsset>(path), SplatCount, SplatCount - 1);
            return page;
        }

        static TextAsset CreateData(string folder, string name, int length)
        {
            var bytes = new byte[(length + 7) / 8 * 8];
            for (int i = 0; i < bytes.Length; ++i)
                bytes[i] = (byte)(i * 37 + 11);
            string path = folder + "/" + name + ".bytes";
            File.WriteAllBytes(path, bytes);
            AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
            return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
        }

        static object GetField(object target, string name) => target.GetType().GetField(name, PrivateInstance).GetValue(target);
        static void SetField(object target, string name, object value) => target.GetType().GetField(name, PrivateInstance).SetValue(target, value);
        static object Call(object target, string name, params object[] args) =>
            target.GetType().GetMethod(name, PrivateInstance).Invoke(target, args);
        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
