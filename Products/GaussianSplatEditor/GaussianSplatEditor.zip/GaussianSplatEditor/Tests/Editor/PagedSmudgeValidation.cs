// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace GaussianSplatting.Tests
{
    /// <summary>GPU and hierarchy regressions for persistent paged Smudge edits.</summary>
    public static class PagedSmudgeValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        static T Get<T>(object target, string name) => (T)target.GetType().GetField(name, Flags).GetValue(target);
        static void Set(object target, string name, object value) => target.GetType().GetField(name, Flags).SetValue(target, value);
        static object Call(object target, string name, params object[] args) => target.GetType().GetMethod(name, Flags).Invoke(target, args);
        static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
        static void Near(Vector3 actual, Vector3 expected, string context) =>
            Require(Vector3.Distance(actual, expected) < .001f, context + ": got " + actual + ", expected " + expected);

        sealed class Fixture : IDisposable
        {
            public readonly object inner;
            public readonly SplatBoxRenderer renderer;
            public readonly GameObject owner;
            public readonly Camera camera;
            public readonly SplatBoxPageGpuState page;
            public readonly SplatBoxLodStreamer streamer;
            public readonly string shaderPath;
            public Fixture(string path)
            {
                shaderPath = path;
                var type = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                inner = Activator.CreateInstance(type, Flags, null, new object[] { path, true }, null);
                renderer = Get<SplatBoxRenderer>(inner, "renderer"); owner = Get<GameObject>(inner, "owner");
                camera = Get<Camera>(inner, "camera"); page = Get<SplatBoxPageGpuState>(inner, "page");
                streamer = Get<SplatBoxLodStreamer>(inner, "streamer");
                owner.transform.position = Vector3.zero;
                Call(inner, "UsePagedPlaceholder");
                Positions(new Vector3(.3f, .5f, 4), new Vector3(0, 0, 3), new Vector3(0, 0, 5), new Vector3(-.5f, 0, 4));
                var shader = Get<ComputeShader>(inner, "shader");
                Require(shader.IsSupported(shader.FindKernel("CSApplyPagedSmudge")) &&
                    shader.IsSupported(shader.FindKernel("CSClearPagedSmudge")), "Smudge kernels unsupported: " + path);
            }
            public Vector3 Position(int index) => (Vector3)Call(inner, "Position", index);
            public void Positions(params Vector3[] positions)
            {
                for (int i = 0; i < positions.Length; ++i) Call(inner, "SetPosition", 32 + i, positions[i]);
                page.splatCount = page.lodNodeCount = positions.Length;
                var nodes = new LodTreeNode[positions.Length];
                for (int i = 0; i < nodes.Length; ++i)
                    nodes[i] = new LodTreeNode { center = positions[i], featureSize = i == 0 ? 3.2f : .2f,
                        childStart = i == 0 ? 1u : 0u, childCount = i == 0 ? (ushort)(positions.Length - 1) : (ushort)0 };
                page.lodTree = LodTreeRuntime.Build(nodes, true);
                Call(inner, "UpdatePageBounds");
            }
            public void Stroke(Vector3 center, Vector3 delta, float radius = .4f, float falloff = 0, float strength = 1)
            {
                renderer.BeginPagedSmudgeStroke();
                renderer.SmudgeSplatsGPU(center, delta, radius, falloff, strength);
                renderer.EndPagedSmudgeStroke();
            }
            public void Ensure()
            {
                Call(renderer, "EnsurePagedSmudgeState", new object[] { null });
                Call(renderer, "EnsurePagedSmudgeHierarchy");
            }
            public Vector3[] Offsets()
            {
                Ensure();
                var buffer = Get<GraphicsBuffer>(renderer, "m_GpuPagedSmudgeOffsets");
                var result = new Vector3[128];
                if (buffer != null) buffer.GetData(result);
                return result;
            }
            public void Replay() => Call(renderer, "ReplayPagedSmudgePage", null, page, page.atlasOffset);
            public void Select(uint[] active, uint[] order) => Call(inner, "Select", active, order);
            public void ExpectView(Vector3 expected, int slot = 0)
            {
                Array views = (Array)Call(inner, "Views");
                Near(Get<Vector3>(views.GetValue(slot), "world"), owner.transform.TransformPoint(expected), "Draw/picking position");
            }
            public uint[] Sort()
            {
                string root = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;
                Set(renderer, "m_Sorter", new GpuSorting(AssetDatabase.LoadAssetAtPath<ComputeShader>(root + "/" +
                    shaderPath.Replace("BoxUtil.compute", "BoxUtilSort.compute"))));
                var args = Get<GpuSorting.Args>(renderer, "m_SorterArgs");
                args.inputKeys = renderer.m_GpuSortDistances; args.inputValues = renderer.m_GpuSortKeys;
                Set(renderer, "m_SorterArgs", args);
                using var cmd = new CommandBuffer { name = "Validate sculpted depth sorting" };
                Call(renderer, "SortPoints", cmd, camera, owner.transform.localToWorldMatrix);
                Graphics.ExecuteCommandBuffer(cmd);
                var result = new uint[128]; renderer.m_GpuSortKeys.GetData(result); return result;
            }
            public void Dispose() => ((IDisposable)inner).Dispose();
        }

        static void GeometrySortingAndHistory(string shader)
        {
            using var f = new Fixture(shader);
            f.Select(new uint[] { 33, 34 }, new uint[] { 0, 1 });
            uint[] initialOrder = f.Sort();
            Require(initialOrder[0] == 0 && initialOrder[1] == 1, "Fixture did not sort front to back before sculpting.");
            var source = new uint[384]; Get<GraphicsBuffer>(f.inner, "pos").GetData(source);
            var sourceNodes = f.page.lodTree.nodes;
            f.Stroke(new Vector3(0, 0, 3), Vector3.forward * 4);
            Near(f.Offsets()[33], Vector3.forward * 4, "Smudge displacement");
            Near(f.Offsets()[34], Vector3.zero, "Outside brush moved");
            Near(sourceNodes[1].center, new Vector3(0, 0, 3), "Sculpt mutated worker's old node snapshot");
            Near(f.page.lodTree.nodes[1].center, new Vector3(0, 0, 7), "CPU node disagrees with GPU");
            uint[] editedOrder = f.Sort();
            Require(editedOrder[0] == 1 && editedOrder[1] == 0, "Depth sorting used original positions after Smudge.");
            f.ExpectView(new Vector3(0, 0, 7), 1);
            Require(f.renderer.TryGetPaintSurfaceDepth(f.camera, new Vector2(320, 240), 8, out float depth) && Mathf.Abs(depth - 5) < .001f,
                "Surface query still picked the original front splat after it moved behind the back splat.");
            var after = new uint[source.Length]; Get<GraphicsBuffer>(f.inner, "pos").GetData(after);
            for (int i = 0; i < source.Length; ++i) Require(source[i] == after[i], "Smudge rewrote source atlas bytes.");

            // Sequential dabs use the moved position, including re-entry into a later brush.
            f.renderer.BeginPagedSmudgeStroke();
            f.renderer.SmudgeSplatsGPU(new Vector3(0, 0, 7), Vector3.right, .4f, .5f, .5f);
            f.renderer.SmudgeSplatsGPU(new Vector3(.5f, 0, 7), Vector3.up, .4f, .5f, .5f);
            f.renderer.EndPagedSmudgeStroke();
            Vector3 accumulated = new Vector3(.5f, .5f, 4);
            Near(f.Offsets()[33], accumulated, "Sequential dabs did not follow moved positions");
            Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); f.Ensure();
            Near(f.Offsets()[33], Vector3.forward * 4, "One Undo did not remove the complete gesture");
            Undo.PerformRedo(); f.Ensure();
            Near(f.Offsets()[33], accumulated, "Redo did not restore the complete gesture");
            f.renderer.ResetPagedSmudge();
            Near(f.Offsets()[33], Vector3.zero, "Reset retained displacement");
            Near(f.page.lodTree.nodes[1].center, new Vector3(0, 0, 3), "Reset retained sculpted LoD nodes");
        }

        static void ReloadAndAtlasReuse(string shader)
        {
            using var f = new Fixture(shader);
            Vector3 lateSource = new Vector3(.1f, 0, 3);
            Call(f.inner, "SetPosition", 35, lateSource);
            var originalNodes = new[] {
                new LodTreeNode { center = new float3(.3f, .5f, 4), featureSize = 3.2f, childCount = 3, childStart = 1 },
                new LodTreeNode { center = new float3(0, 0, 3), featureSize = .2f },
                new LodTreeNode { center = new float3(0, 0, 5), featureSize = .2f },
                new LodTreeNode { center = lateSource, featureSize = .2f }
            };
            f.page.splatCount = 3; f.page.isCoarseStub = true;
            f.page.lodTree = LodTreeRuntime.BuildPrefix(new[] { originalNodes[0], originalNodes[1], originalNodes[2] });
            f.Stroke(new Vector3(0, 0, 3), Vector3.right, .5f, 0, .75f);
            Near(f.Offsets()[35], Vector3.zero, "Smudge wrote nonresident detail");
            // A full-page upload introduces a node absent from the original coarse prefix.
            f.page.splatCount = 4; f.page.isCoarseStub = false;
            f.page.lodTree = LodTreeRuntime.Build((LodTreeNode[])originalNodes.Clone(), true);
            f.Replay(); f.Ensure();
            Near(f.Offsets()[35], Vector3.right * .75f, "Newly loaded child missed the journal");
            Near(f.page.lodTree.nodes[3].center, lateSource + Vector3.right * .75f, "New child's CPU node missed journal");
            f.Replay();
            Near(f.Offsets()[35], Vector3.right * .75f, "Repeated replay applied a dab twice");

            // A slot reused for unrelated geometry must not retain its former owner's delta.
            Call(f.inner, "SetPosition", 35, new Vector3(8, 0, 3));
            f.Replay(); Near(f.Offsets()[35], Vector3.zero, "Recycled atlas slot retained old displacement");
            Call(f.inner, "SetPosition", 35, lateSource); f.Replay();
            for (int i = 0; i < 4; ++i) Call(f.inner, "SetPosition", 64 + i, f.Position(32 + i));
            f.page.atlasOffset = f.page.uploadedAtlasOffset = 64;
            f.Replay(); Near(f.Offsets()[67], Vector3.right * .75f, "Replay depended on atlas address");
            f.Select(new uint[] { 67, 65 }, new uint[] { 0, 1 });
            f.ExpectView(lateSource + Vector3.right * .75f);

            string journal = EditorJsonUtility.ToJson(f.renderer);
            f.renderer.ResetPagedSmudge();
            EditorJsonUtility.FromJsonOverwrite(journal, f.renderer);
            Set(f.renderer, "m_LodStreamer", f.streamer);
            Call(f.inner, "RecreateAtlas");
            f.page.lodTree = LodTreeRuntime.Build((LodTreeNode[])originalNodes.Clone(), true);
            f.Ensure();
            Near(f.Offsets()[67], Vector3.right * .75f, "Serialized journal / recreated atlas lost edit");
            f.owner.transform.SetPositionAndRotation(new Vector3(1, 2, 0), Quaternion.Euler(0, 0, 20));
            f.Replay(); f.ExpectView(lateSource + Vector3.right * .75f);
            f.renderer.ResetPagedSmudge(); f.Ensure();
            Near(f.page.lodTree.nodes[3].center, lateSource, "Reload/reset did not restore source node");
        }

        static void SelectionAndStreamingBounds(string shader)
        {
            using var f = new Fixture(shader);
            f.Positions(new Vector3(-1, 0, 5), new Vector3(-2, 0, 5), new Vector3(0, 0, 5));
            f.Stroke(new Vector3(-2, 0, 5), Vector3.right * 4, .3f);
            f.Ensure();
            LodTreeNode root = f.page.lodTree.nodes[0], moved = f.page.lodTree.nodes[1];
            Near(moved.center, new Vector3(2, 0, 5), "Hierarchy leaf was not sculpted");
            Require(root.featureSize * .5f >= math.distance(root.center, moved.center) + moved.featureSize * .5f - .001f,
                "Parent extent no longer encloses moved child");
            Require(f.page.bounds.Contains(moved.center), "Loaded page bounds exclude sculpted child");
            var pages = new[] { new SplatBoxLodTraverser.PageContext { pageSlot = 0, nodes = f.page.lodTree.nodes,
                localToWorld = float4x4.identity, lodScale = 1, outsideFoveate = 1, behindFoveate = 1 } };
            var view = new SplatBoxLodTraverser.ViewContext { cameraWorld = float3.zero, cameraForward = new float3(0, 0, 1),
                pixelScaleFactor = 1000, pixelsPerUnitAtUnitDistance = 500, cosHalfFovY = .7f, screenHeight = 480,
                frustumCull = true, splatScale = 1, cullPlanes = new[] { new float4(1, 0, 0, -1) } };
            var selected = new LodActiveSplatRef[8];
            int count = SplatBoxLodTraverser.Traverse(pages, 1, view, selected.Length, .01f, selected, new SplatBoxLodTraverser.Workspace());
            Require(count == 1 && selected[0].splatIndex == 1, "LoD culling/refinement lost the leaf moved into the view");
            // The same bound expansion must be available before a page has a resident CPU tree.
            var entry = new GaussianSplatPageEntry { pageId = 99, boundsMin = new Vector3(-2, 0, 5), boundsMax = new Vector3(0, .2f, 5.2f) };
            Bounds unloaded = (Bounds)Call(f.streamer, "GetEditedPageBounds", entry);
            Require(unloaded.Contains(new Vector3(2, .1f, 5.1f)), "Unloaded-page streaming bounds exclude possible sculpted geometry");
            float distance = (float)Call(f.streamer, "DistanceToPage", new Vector3(2, .1f, 5.1f), entry, f.owner.transform);
            Require(distance < .001f, "Streaming distance still uses original page bounds");
            f.renderer.ResetPagedSmudge(); f.Ensure();
            Bounds reset = (Bounds)Call(f.streamer, "GetEditedPageBounds", entry);
            Near(reset.min, entry.boundsMin, "Reset did not restore streaming bounds minimum");
            Near(reset.max, entry.boundsMax, "Reset did not restore streaming bounds maximum");
        }

        static void RepeatedPinchKeepsUneditedCoverage(string shader)
        {
            using var f = new Fixture(shader);
            var root = new Vector3(0, 0, 5);
            var editedBranch = new Vector3(-3, 0, 5);
            var untouchedBranch = new Vector3(2, 0, 5);
            var leaf = new Vector3(-3.1f, 0, 5);
            f.Positions(root, editedBranch, untouchedBranch, leaf);
            f.page.isCoarseStub = true;
            f.page.lodTree = LodTreeRuntime.BuildPrefix(new[]
            {
                new LodTreeNode { center = root, featureSize = 8, childStart = 1, childCount = 2 },
                new LodTreeNode { center = editedBranch, featureSize = .6f, childStart = 3, childCount = 1 },
                new LodTreeNode { center = untouchedBranch, featureSize = .6f, childStart = 4, childCount = 1 },
                new LodTreeNode { center = leaf, featureSize = .2f }
            });
            LodTreeNode before = f.page.lodTree.nodes[2];
            Require(before.IsMergedSplat && before.childCount == 0, "Fixture did not truncate the untouched branch.");

            var distantBounds = new Bounds(new Vector3(6, 0, 5), Vector3.one * .5f);
            var distantTree = LodTreeRuntime.BuildPrefix(new[]
            {
                new LodTreeNode { center = distantBounds.center, featureSize = .6f, childStart = 1, childCount = 1 }
            });
            var distantPage = new SplatBoxPageGpuState
            {
                pageId = 2, pageSlot = 1, splatCount = 1, isCoarseStub = true, bounds = distantBounds, lodTree = distantTree
            };
            var distantEntry = new GaussianSplatPageEntry
            {
                pageId = distantPage.pageId, boundsMin = distantBounds.min, boundsMax = distantBounds.max
            };
            Get<List<SplatBoxPageGpuState>>(f.streamer, "m_LoadedList").Add(distantPage);
            var manifest = f.renderer.pagedScene;
            manifest.Initialize(manifest.worldBoundsMin, manifest.worldBoundsMax, manifest.pageCellSize,
                new[] { manifest.pages[0], distantEntry });
            Set(f.streamer, "m_PagedScene", manifest);
            float originalDistance = f.streamer.DistanceToLoadedPage(root, distantPage, f.owner.transform);
            Require(Mathf.Abs(originalDistance - 5.75f) < .001f, "Distant-page streaming fixture has the wrong baseline.");

            // The points converge inside a fixed brush footprint. Repeated dabs used to grow an
            // envelope across both pages and inflate stand-ins whose source geometry never moved.
            var pinchCenter = new Vector3(-3.5f, 0, 5);
            const int dabs = 16;
            f.renderer.BeginPagedSculptStroke();
            for (int i = 0; i < dabs; i++)
                f.renderer.PinchSplatsGPU(pinchCenter, 1.25f, 0, .5f);
            f.renderer.EndPagedSculptStroke();

            Require(f.renderer.pagedSculptDabCount == dabs, "Fixture did not apply every Pinch dab.");
            Near(leaf + f.Offsets()[35], pinchCenter, "Repeated Pinch GPU position");
            Near(f.page.lodTree.nodes[3].center, pinchCenter, "Repeated Pinch hierarchy position");
            Require(f.page.bounds.Contains(f.page.lodTree.nodes[3].center), "The edited page no longer encloses the pinched leaf.");
            LodTreeNode after = f.page.lodTree.nodes[2];
            Near(after.center, before.center, "Pinch moved an unrelated coarse branch");
            Require(Mathf.Abs(after.featureSize - before.featureSize) < .001f,
                "Pinch enlarged an unrelated stand-in, risking its removal by the screen-size filter.");
            Near(distantPage.lodTree.nodes[0].center, distantBounds.center, "Pinch moved an unrelated page hierarchy");
            Require(Mathf.Abs(distantPage.lodTree.nodes[0].featureSize - .6f) < .001f,
                "Pinch enlarged the stand-in for an unrelated page.");
            Near(distantPage.bounds.min, distantBounds.min, "Pinch expanded a distant resident page's minimum");
            Near(distantPage.bounds.max, distantBounds.max, "Pinch expanded a distant resident page's maximum");
            Bounds streamingBounds = f.streamer.GetEditedPageBounds(distantEntry);
            Near(streamingBounds.min, distantBounds.min, "Pinch expanded a distant streaming bound's minimum");
            Near(streamingBounds.max, distantBounds.max, "Pinch expanded a distant streaming bound's maximum");
            Require(Mathf.Abs(f.streamer.DistanceToLoadedPage(root, distantPage, f.owner.transform) - originalDistance) < .001f,
                "Pinch changed the unrelated page's streaming priority distance.");
        }

        static uint Norm11(Vector3 value) => (uint)Mathf.RoundToInt(value.x * 2047) |
            ((uint)Mathf.RoundToInt(value.y * 1023) << 11) | ((uint)Mathf.RoundToInt(value.z * 2047) << 21);
        static uint HalfRange(float low, float high) => Mathf.FloatToHalf(low) | ((uint)Mathf.FloatToHalf(high) << 16);
        static void MonolithicFalloffParity(string shader)
        {
            using var paged = new Fixture(shader);
            var type = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
            object monolithic = Activator.CreateInstance(type, Flags, null, new object[] { shader, false }, null);
            try
            {
                var renderer = Get<SplatBoxRenderer>(monolithic, "renderer");
                Vector3 source = new Vector3(0, 0, 3), center = source + Vector3.right * .2f;
                Vector3 delta = new Vector3(.4f, .2f, 1);
                foreach (float falloff in new[] { 0f, .3f, .5f, 1f })
                {
                    paged.renderer.ResetPagedSmudge();
                    Call(monolithic, "SetPosition", 33, source);
                    renderer.SmudgeSplatsGPU(center, delta, .5f, falloff, 2);
                    var data = new Vector3[128]; Get<GraphicsBuffer>(monolithic, "pos").GetData(data);
                    paged.Stroke(center, delta, .5f, falloff, 2);
                    Near(source + paged.Offsets()[33], data[33], "Paged/monolithic falloff parity at " + falloff);
                    Near(paged.page.lodTree.nodes[1].center, data[33], "GPU/CPU falloff parity at " + falloff);
                }
            }
            finally { ((IDisposable)monolithic).Dispose(); }
        }

        static void PackedPages(string shader)
        {
            using var f = new Fixture(shader);
            string sourcePath = "Assets/__SmudgePackedPositions_" + Guid.NewGuid().ToString("N") + ".bytes";
            GaussianSplatPageAsset sourcePage = null;
            var asset = Get<GaussianSplatAsset>(f.inner, "asset");
            asset.Initialize(128, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4, GaussianSplatAsset.SHFormat.Norm6, Vector3.one * -10, Vector3.one * 10, null);
            var data = Get<TextAsset>(f.inner, "data"); asset.SetAssetFiles(data, data, data, data, data);
            var positions = new uint[128]; var others = new uint[256];
            for (int i = 0; i < positions.Length; ++i)
            { positions[i] = Norm11(Vector3.one * .9f); others[i * 2] = 0xE0080200u; others[i * 2 + 1] = Norm11(Vector3.one * .5f); }
            positions[33] = Norm11(new Vector3(.5f, .5f, .3f));
            Get<GraphicsBuffer>(f.inner, "pos").SetData(positions); Get<GraphicsBuffer>(f.inner, "other").SetData(others);
            var chunk = new GaussianSplatAsset.ChunkInfo { posX = new float2(-10, 10), posY = new float2(-10, 10), posZ = new float2(0, 10),
                colR = HalfRange(0, 1), colG = HalfRange(0, 1), colB = HalfRange(0, 1), colA = HalfRange(.5f, .9f),
                sclX = HalfRange(.1f, .2f), sclY = HalfRange(.1f, .2f), sclZ = HalfRange(.1f, .2f) };
            Get<GraphicsBuffer>(f.inner, "chunks").SetData(new[] { chunk }); Set(f.renderer, "m_GpuChunksValid", true);
            Set(f.renderer, "m_GpuLodUnifiedChunks", Get<GraphicsBuffer>(f.inner, "chunks"));
            Set(f.renderer, "m_LodUnifiedChunkCount", 1);
            try
            {
                Vector3 decoded = new Vector3(Mathf.Round(.5f * 2047) / 2047 * 20 - 10,
                    Mathf.Round(.5f * 1023) / 1023 * 20 - 10, Mathf.Round(.3f * 2047) / 2047 * 10);
                var sourceBytes = new byte[4 * sizeof(uint)];
                Buffer.BlockCopy(positions, 32 * sizeof(uint), sourceBytes, 0, sourceBytes.Length);
                File.WriteAllBytes(sourcePath, sourceBytes);
                AssetDatabase.ImportAsset(sourcePath, ImportAssetOptions.ForceSynchronousImport);
                asset.SetAssetFiles(data, AssetDatabase.LoadAssetAtPath<TextAsset>(sourcePath), data, data, data);
                sourcePage = ScriptableObject.CreateInstance<GaussianSplatPageAsset>();
                sourcePage.Initialize(1, Vector3Int.zero, Vector3.one * -10, Vector3.one * 10, asset, null, 4, 3);
                f.page.source = sourcePage; f.page.gpuChunksValid = true; f.page.chunkInfos = new[] { chunk };
                f.Select(new uint[] { 33 }, new uint[] { 0 });
                f.Stroke(decoded, Vector3.right, .4f, 0, .5f);
                Near(f.Offsets()[33], Vector3.right * .5f, "Compressed positions were smudged before decoding");
                Near(f.page.lodTree.nodes[1].center, decoded + Vector3.right * .5f, "Compressed CPU node did not use decoded position");
                f.ExpectView(decoded + Vector3.right * .5f);
                f.Replay(); f.ExpectView(decoded + Vector3.right * .5f);
                var actual = new uint[128]; Get<GraphicsBuffer>(f.inner, "pos").GetData(actual, 0, 0, actual.Length);
                for (int i = 0; i < actual.Length; ++i) Require(actual[i] == positions[i], "Smudge rewrote compressed position bytes");
                f.renderer.ResetPagedSmudge(); f.ExpectView(decoded);
                Vector3 authoredCenter = decoded + Vector3.right * .01f;
                f.page.lodTree.nodes[1].center = authoredCenter;
                f.Stroke(decoded + Vector3.right * .008f, Vector3.up, .004f);
                Near(f.Offsets()[33], Vector3.zero, "Hard brush moved GPU point outside its radius");
                Near(f.page.lodTree.nodes[1].center, authoredCenter, "A hard brush missing the decoded splat changed its hierarchy center");
                f.Stroke(decoded, Vector3.up, .004f);
                Near(f.Offsets()[33], Vector3.up, "Hard brush missed decoded GPU point");
                Near(f.page.lodTree.nodes[1].center, decoded + Vector3.up, "Hard brush CPU/GPU displacement disagreed");
            }
            finally
            {
                Set(f.renderer, "m_GpuLodUnifiedChunks", null); f.page.source = null;
                if (sourcePage != null) UnityEngine.Object.DestroyImmediate(sourcePage);
                AssetDatabase.DeleteAsset(sourcePath);
            }
        }

        static void Preload(SplatBoxRenderer renderer, Camera camera)
        {
            Require(renderer.ForceRebuildPagedLodInEditor(), "Saved-scene Smudge renderer did not initialize");
            for (int i = 0; i < 10; i++)
            {
                if (renderer.lodStreamer != null) Set(renderer.lodStreamer, "m_LastPageUploadFrame", -1);
                renderer.PreloadPagedLodPages(camera);
            }
        }

        static void ExpectSavedGeometry(SplatBoxRenderer renderer, Camera camera, Vector3 delta)
        {
            var offsets = Get<GraphicsBuffer>(renderer, "m_GpuPagedSmudgeOffsets");
            var data = new Vector3[offsets?.count ?? 1]; offsets?.GetData(data);
            Require(renderer.lodStreamer.loadedPages.Count == 3, "Saved-scene fixture lost a page");
            foreach (var page in renderer.lodStreamer.loadedPages)
            {
                for (int i = 0; i < page.splatCount; i++)
                {
                    Vector3 expected = page.pageId == 1 ? delta : Vector3.zero;
                    Near(offsets != null ? data[page.atlasOffset + i] : Vector3.zero, expected, "Real uploaded page replay");
                    Require(Mathf.Abs(page.lodTree.nodes[i].center.z - 5 - expected.z) < .001f,
                        "Real uploaded CPU node did not replay saved Smudge");
                }
            }
            Require(renderer.TryGetPaintSurfaceDepth(camera, new Vector2(320, 240), 16, out float depth) &&
                Mathf.Abs(depth - 5 - delta.z) < .001f, "Saved-scene picking ignored sculpted geometry: " + depth);
        }

        static void SavedSceneReload()
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            object fixture = null; RenderTexture target = null;
            GaussianSplatting.Editor.GaussianSplatEditorWindow window = null;
            string scenePath = "Assets/__SmudgeSceneValidation_" + Guid.NewGuid().ToString("N") + ".unity";
            try
            {
                var type = typeof(PagedLodEditorRecoveryValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                fixture = Activator.CreateInstance(type, Flags, null, new object[] { false }, null);
                Call(fixture, "AssignScene"); Call(fixture, "PublishPages");
                var renderer = Get<SplatBoxRenderer>(fixture, "renderer"); renderer.name = "Smudge scene validation source";
                var camera = new GameObject("Smudge scene validation camera").AddComponent<Camera>(); camera.tag = "MainCamera";
                target = new RenderTexture(640, 480, 0); target.Create(); camera.targetTexture = target;
                var sourceBytes = new List<string>();
                foreach (var page in renderer.pagedScene.pages)
                    sourceBytes.Add(Convert.ToBase64String(page.pageAsset.splatData.posData.bytes));
                Preload(renderer, camera);
                renderer.BeginPagedSmudgeStroke();
                renderer.SmudgeSplatsGPU(new Vector3(0, 0, 5), Vector3.forward * 2, .3f, 0, 1);
                renderer.EndPagedSmudgeStroke();
                ExpectSavedGeometry(renderer, camera, Vector3.forward * 2);
                Preload(renderer, camera); // Real teardown, streaming upload and replay hook.
                ExpectSavedGeometry(renderer, camera, Vector3.forward * 2);
                renderer.enabled = false; renderer.enabled = true; Preload(renderer, camera);
                ExpectSavedGeometry(renderer, camera, Vector3.forward * 2);
                AssetDatabase.SaveAssets();
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath), "Could not save Smudge scene");
                EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
                renderer = GameObject.Find("Smudge scene validation source").GetComponent<SplatBoxRenderer>();
                camera = GameObject.Find("Smudge scene validation camera").GetComponent<Camera>(); camera.targetTexture = target;
                Preload(renderer, camera);
                Require(renderer.pagedSmudgeDabCount == 1, "Saved scene lost renderer-owned Smudge journal");
                ExpectSavedGeometry(renderer, camera, Vector3.forward * 2);
                for (int i = 0; i < sourceBytes.Count; i++)
                    Require(sourceBytes[i] == Convert.ToBase64String(renderer.pagedScene.pages[i].pageAsset.splatData.posData.bytes),
                        "Scene rebuild or save modified source page bytes");
                renderer.ResetPagedSmudge(); Preload(renderer, camera);
                ExpectSavedGeometry(renderer, camera, Vector3.zero);
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Preload(renderer, camera);
                ExpectSavedGeometry(renderer, camera, Vector3.forward * 2);
                window = ScriptableObject.CreateInstance<GaussianSplatting.Editor.GaussianSplatEditorWindow>();
                Set(window, "m_TargetRenderer", renderer);
                Call(window, "ResetAllSplatEdits"); Preload(renderer, camera);
                ExpectSavedGeometry(renderer, camera, Vector3.zero);
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Preload(renderer, camera);
                ExpectSavedGeometry(renderer, camera, Vector3.forward * 2);
            }
            finally
            {
                if (window != null) UnityEngine.Object.DestroyImmediate(window);
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                if (fixture is IDisposable disposable) disposable.Dispose();
                if (target != null) { target.Release(); UnityEngine.Object.DestroyImmediate(target); }
                AssetDatabase.DeleteAsset(scenePath);
            }
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders, "Use an isolated batch project with a graphics device.");
            var errors = new List<string>();
            Application.LogCallback observe = (message, stack, type) =>
            { if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert) errors.Add(message); };
            Application.logMessageReceived += observe;
            try
            {
                foreach (string shader in new[] { "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute" })
                {
                    GeometrySortingAndHistory(shader); ReloadAndAtlasReuse(shader);
                    SelectionAndStreamingBounds(shader); RepeatedPinchKeepsUneditedCoverage(shader);
                    PackedPages(shader); MonolithicFalloffParity(shader);
                }
                SavedSceneReload();
                Require(errors.Count == 0, "Paged Smudge validation logged errors: " + string.Join(" | ", errors));
                Debug.Log("SplatBox Paged Smudge PASS: sequential gestures, immutable source/worker snapshots, Undo/Redo/reset, " +
                    "depth sorting and picking, new detail/recycled atlas replay, serialized journal, LoD parent extents/culling, " +
                    "unloaded streaming bounds, untouched coverage during Pinch, packed source positions, " +
                    "real rebuild/reopen and editor Reset All on both compute shaders.");
            }
            finally { Application.logMessageReceived -= observe; }
        }
    }
}
