using System;
using System.Linq;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    public static class VisibleSortValidation
    {
        const string Root = "Packages/com.gaussiansplatting.splatbox/";

        public static void Run()
        {
            foreach (string folder in new[] { "Resources/", "Shaders/" })
            {
                var distance = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + folder + "BoxUtil.compute");
                var sorter = new GpuSorting(AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + folder + "BoxUtilSort.compute"));
                Require(sorter.Valid && sorter.SupportsIndirect, folder + " indirect sort unsupported");
                foreach (int count in new[] { 1, 255, 256, 257, 3839, 3840, 3841, 65537, 100003 })
                    Validate(distance, sorter, count);
            }
            Debug.Log("SplatBox visible sort PASS: both shader copies, stable CPU reference, empty/full/mixed views, stereo union, repeated visibility changes and dispatch boundaries.");
        }

        static void Validate(ComputeShader shader, GpuSorting sorter, int count)
        {
            using var compaction = new GpuSplatCompaction();
            Require(compaction.valid, "Compaction unsupported");
            compaction.EnsureCapacity(count);
            using var distances = new GraphicsBuffer(GraphicsBuffer.Target.Structured, count, 4);
            using var indices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, count, 4);
            using var positions = new GraphicsBuffer(GraphicsBuffer.Target.Raw, count * 3, 4);
            using var chunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 64);
            using var remap = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 4);
            using var drawArgs = new GraphicsBuffer(GraphicsBuffer.Target.Structured | GraphicsBuffer.Target.IndirectArguments, 5, 4);
            using var cmd = new CommandBuffer();
            var resources = GpuSorting.SupportResources.Load((uint)count);
            try
            {
                int kernel = shader.FindKernel("CSCalcDistances");
                var pos = new Vector3[count];
                var keys = new uint[count];
                var sortedIndices = new uint[count];
                var sortedKeys = new uint[count];
                var dispatch = new uint[8];
                var draw = new uint[5];
                // The second eye sees x=2. Its union must be retained by the cull.
                var rightEye = Matrix4x4.Translate(new Vector3(-2, 0, 0));
                for (int mode = 0; mode < 6; ++mode)
                {
                    uint multiplier = mode % 2 == 0 ? 1u : 2u;
                    int expectedVisible = 0;
                    for (int i = 0; i < count; ++i)
                    {
                        bool visible = mode == 0 || (mode == 2 && i % 7 == 0) ||
                            (mode == 3 && i % 7 != 0) || (mode == 4 && (i / 256) % 3 == 1) ||
                            (mode == 5 && i == count - 1);
                        if (visible) ++expectedVisible;
                        pos[i] = new Vector3(visible ? (i % 2 == 0 ? 0 : 2) : 10, 0, (i * 37 % 129) * 0.1f);
                    }
                    positions.SetData(pos);
                    drawArgs.SetData(new uint[] { 6, 0, 0, 0, 0 });
                    cmd.Clear();
                    cmd.SetComputeIntParam(shader, "_SplatCount", count);
                    cmd.SetComputeIntParam(shader, "_SplatChunkCount", 0);
                    cmd.SetComputeIntParam(shader, "_SplatFormat", 0);
                    cmd.SetComputeIntParam(shader, "_UseSplatIndexRemap", 0);
                    cmd.SetComputeIntParam(shader, "_SortByCameraDistance", 1);
                    cmd.SetComputeIntParam(shader, "_SortKeyBits", 16);
                    cmd.SetComputeIntParam(shader, "_StableSort", 0);
                    cmd.SetComputeFloatParam(shader, "_SortDepthScale", 1f / 50);
                    cmd.SetComputeIntParam(shader, "_FrustumCullEnabled", 1);
                    cmd.SetComputeIntParam(shader, "_CompactSortEnabled", 1);
                    cmd.SetComputeIntParam(shader, "_CullViewCount", 2);
                    cmd.SetComputeIntParam(shader, "_DrawInstanceMultiplier", (int)multiplier);
                    cmd.SetComputeFloatParam(shader, "_FrustumCullPadding", 0.15f);
                    cmd.SetComputeFloatParam(shader, "_FrustumCullNearSkip", 0.1f);
                    cmd.SetComputeMatrixParam(shader, "_MatrixObjectToWorld", Matrix4x4.identity);
                    cmd.SetComputeMatrixParam(shader, "_MatrixMV", Matrix4x4.identity);
                    cmd.SetComputeMatrixArrayParam(shader, "_CullMatrixVP", new[] { Matrix4x4.identity, rightEye });
                    cmd.SetComputeVectorParam(shader, "_VecWorldSpaceCameraPos", Vector4.zero);
                    cmd.SetComputeBufferParam(shader, kernel, "_SplatPos", positions);
                    cmd.SetComputeBufferParam(shader, kernel, "_SplatChunks", chunks);
                    cmd.SetComputeBufferParam(shader, kernel, "_SplatIndexRemap", remap);
                    cmd.SetComputeBufferParam(shader, kernel, "_SplatSortDistances", distances);
                    cmd.SetComputeBufferParam(shader, kernel, "_SplatSortKeys", indices);
                    cmd.SetComputeBufferParam(shader, kernel, "_DrawArgs", drawArgs);
                    cmd.SetComputeBufferParam(shader, kernel, "_CullGroupOffsets", compaction.groupOffsets);
                    cmd.DispatchCompute(shader, kernel, (count + 255) / 256, 1, 1);
                    Graphics.ExecuteCommandBuffer(cmd);
                    distances.GetData(keys);
                    var expected = Enumerable.Range(0, count).Where(i => keys[i] < 65535).OrderBy(i => keys[i]).ToArray();
                    Require(expected.Length == expectedVisible, $"Cull union mismatch: count={count}, mode={mode}");

                    cmd.Clear();
                    compaction.Dispatch(cmd, count, distances, resources.altBuffer, resources.altPayloadBuffer, drawArgs, multiplier, 256);
                    var args = new GpuSorting.Args { count = (uint)count, inputKeys = resources.altBuffer,
                        inputValues = resources.altPayloadBuffer, resources = resources, keyBits = 16,
                        indirectDispatchArgs = compaction.dispatchArgs };
                    args.resources.altBuffer = distances;
                    args.resources.altPayloadBuffer = indices;
                    sorter.Dispatch(cmd, args);
                    Graphics.ExecuteCommandBuffer(cmd);
                    compaction.dispatchArgs.GetData(dispatch);
                    drawArgs.GetData(draw);
                    resources.altBuffer.GetData(sortedKeys);
                    resources.altPayloadBuffer.GetData(sortedIndices);
                    Require(dispatch[3] == expected.Length && draw[0] == 6 && draw[1] == expected.Length * multiplier,
                        $"Visible count mismatch: count={count}, mode={mode}");
                    Require(dispatch[0] == Math.Max(1, (expected.Length + 3839) / 3840) && dispatch[1] == 1 && dispatch[2] == 1 &&
                        dispatch[4] == Math.Max(1, (expected.Length + 255) / 256) && dispatch[5] == 1 && dispatch[6] == 1,
                        "Invalid indirect dispatch dimensions");
                    for (int i = 0; i < expected.Length; ++i)
                        Require(sortedIndices[i] == expected[i] && sortedKeys[i] == keys[expected[i]],
                            $"Stable order mismatch: count={count}, mode={mode}, slot={i}, actual={sortedIndices[i]}, expected={expected[i]}");

                    // Switching the feature off must still work with reused scratch after a compact frame.
                    distances.SetData(keys);
                    indices.SetData(Enumerable.Range(0, count).Select(i => (uint)i).ToArray());
                    cmd.Clear();
                    sorter.Dispatch(cmd, new GpuSorting.Args { count = (uint)count, inputKeys = distances,
                        inputValues = indices, resources = resources, keyBits = 16 });
                    Graphics.ExecuteCommandBuffer(cmd);
                    indices.GetData(sortedIndices);
                    for (int i = 0; i < expected.Length; ++i)
                        Require(sortedIndices[i] == expected[i], "Direct/compact order mismatch");
                }
            }
            finally { resources.Dispose(); }
        }

        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
