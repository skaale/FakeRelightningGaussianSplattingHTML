using System;
using System.IO;
using System.Linq;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    // Run with Unity -batchmode -force-vulkan -projectPath <project>
    // -executeMethod GaussianSplatting.Tests.MobileRenderingValidation.Run -quit.
    // Requires a graphics device; do not pass -nographics. Results go to Library/SplatBoxValidation.
    public static class MobileRenderingValidation
    {
        const string Root = "Packages/com.gaussiansplatting.splatbox/";

        public static void RunAll()
        {
            Run();
            RelightSelectionValidation.Run();
            BuildAndroidShaders();
        }

        public static void Run()
        {
            if (!SystemInfo.supportsComputeShaders)
                throw new Exception("Compute shader validation requires a graphics device.");
            ValidateQuadExtents();
            ValidateSH("CompareResourceSH.compute");
            ValidateSH("CompareSourceSH.compute");
            ValidateDrawShaders();
            VisibleSortValidation.Run();
            Debug.Log("SplatBox validation PASS: quad coverage, SH formats/orders and draw shader compilation.");
        }

        static void ValidateQuadExtents()
        {
            var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + "Tests/Editor/QuadExtent.compute");
            int kernel = shader.FindKernel("Extents");
            var opacity = new float[32768];
            // Every finite nonnegative half value, plus all three selection encodings.
            for (int i = 0; i < 31744; ++i)
                opacity[i] = Mathf.HalfToFloat((ushort)i);
            opacity[32765] = -1;
            opacity[32766] = -2;
            opacity[32767] = -3;
            using var input = new GraphicsBuffer(GraphicsBuffer.Target.Structured, opacity.Length, 4);
            using var output = new GraphicsBuffer(GraphicsBuffer.Target.Structured, opacity.Length, 4);
            input.SetData(opacity);
            shader.SetBuffer(kernel, "_TestOpacity", input);
            shader.SetBuffer(kernel, "_TestExtents", output);
            var extents = new float[opacity.Length];
            for (int enabled = 0; enabled <= 1; ++enabled)
            {
                shader.SetInt("_SplatTightQuads", enabled);
                shader.Dispatch(kernel, opacity.Length / 64, 1, 1);
                output.GetData(extents);
                for (int i = 0; i < opacity.Length; ++i)
                {
                    float radius = extents[i];
                    Require(!float.IsNaN(radius) && radius >= 0 && radius <= 2.00001f, "Invalid quad extent");
                    if (enabled == 0 || opacity[i] < 0)
                        Require(radius == 2, "Disabled optimization/selection changed footprint");
                    else if (radius < 2)
                    {
                        // Maximum alpha anywhere outside a tightened quad occurs on the nearest edge.
                        // Emulate fragment half rounding; sharpening/depth fades only reduce this alpha.
                        float gaussian = Mathf.HalfToFloat(Mathf.FloatToHalf(Mathf.Exp(-radius * radius)));
                        float alpha = Mathf.HalfToFloat(Mathf.FloatToHalf(gaussian * opacity[i]));
                        Require(alpha < 1f / 255f, "Tight quad removes a visible fragment at opacity " + opacity[i]);
                    }
                }
            }
        }

        static void ValidateSH(string file)
        {
            var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + "Tests/Editor/" + file);
            int kernel = shader.FindKernel("CompareSH");
            using var pos = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 3, 4);
            using var other = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 8, 4);
            using var sh = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 48, 4);
            using var chunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 64);
            using var remap = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 4);
            using var result = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 24, 16);
            var color = new Texture2D(1, 1, TextureFormat.RGBAFloat, false, true);
            try
            {
                pos.SetData(new float[] { 0.1f, 0.2f, 0.3f });
                other.SetData(new uint[] { 0, FloatBits(0.2f), FloatBits(0.3f), FloatBits(0.4f), 0, 0, 0, 0 });
                remap.SetData(new uint[] { 0 });
                uint range = (uint)Mathf.FloatToHalf(-0.25f) | ((uint)Mathf.FloatToHalf(0.4f) << 16);
                chunks.SetData(new[] { new GaussianSplatAsset.ChunkInfo
                {
                    colR = 0x3c000000, colG = 0x3c000000, colB = 0x3c000000, colA = 0x3c000000,
                    sclX = 0x3c000000, sclY = 0x3c000000, sclZ = 0x3c000000,
                    shR = range, shG = range, shB = range
                } });
                color.SetPixel(0, 0, new Color(0.6f, 0.5f, 0.4f, 0.7f));
                color.Apply();
                shader.SetBuffer(kernel, "_SplatPos", pos);
                shader.SetBuffer(kernel, "_SplatOther", other);
                shader.SetBuffer(kernel, "_SplatSH", sh);
                shader.SetBuffer(kernel, "_SplatChunks", chunks);
                shader.SetBuffer(kernel, "_SplatIndexRemap", remap);
                shader.SetTexture(kernel, "_SplatColor", color);
                shader.SetBuffer(kernel, "_TestResults", result);
                shader.SetInt("_UseSplatIndexRemap", 1);
                shader.SetInt("_SplatSHDataValid", 1);
                var words = new uint[48];
                var actual = new Vector4[24];
                for (int format = 0; format <= 4; ++format)
                {
                    for (int i = 0; i < words.Length; ++i)
                        words[i] = format == 0 ? FloatBits((i + 1) * 0.004f) :
                            format == 1 || format == 4 ? (uint)Mathf.FloatToHalf((i + 1) * 0.004f) |
                                ((uint)Mathf.FloatToHalf((i + 1) * -0.003f) << 16) : 0x8a4b2371u + (uint)i * 19733u;
                    sh.SetData(words);
                    shader.SetInt("_SplatFormat", format << 16);
                    for (int chunked = 0; chunked <= 1; ++chunked)
                    for (int order = 0; order <= 3; ++order)
                    {
                        shader.SetInt("_SplatChunkCount", chunked);
                        shader.SetInt("_TestOrder", order);
                        shader.Dispatch(kernel, 8, 1, 1);
                        result.GetData(actual);
                        for (int i = 0; i < actual.Length; i += 3)
                        {
                            Require(actual[i + 2].sqrMagnitude == 0,
                                $"Loaded SH coefficient mismatch in {file}: format={format}, chunked={chunked}, order={order}");
                            bool colorMatches = (actual[i] - actual[i + 1]).sqrMagnitude < 1e-10f;
                            if (EditorUserBuildSettings.activeBuildTarget == BuildTarget.Android)
                            {
                                // Android variants use real half arithmetic; different inlining/FMA
                                // choices can change the final color after cancellation between bands.
                                // Coefficients are checked exactly above; bound color drift by one half
                                // step at unit intensity (and scale that bound for HDR values).
                                colorMatches = actual[i].w == actual[i + 1].w;
                                for (int channel = 0; channel < 3; ++channel)
                                    colorMatches &= Mathf.Abs(actual[i][channel] - actual[i + 1][channel]) <=
                                        Mathf.Max(1, Mathf.Abs(actual[i][channel])) / 1024f;
                            }
                            Require(colorMatches,
                                $"SH mismatch in {file}: format={format}, chunked={chunked}, order={order}, " +
                                $"reference=({actual[i].x:R},{actual[i].y:R},{actual[i].z:R},{actual[i].w:R}), " +
                                $"optimized=({actual[i + 1].x:R},{actual[i + 1].y:R},{actual[i + 1].z:R},{actual[i + 1].w:R})");
                        }
                    }
                }
            }
            finally { UnityEngine.Object.DestroyImmediate(color); }
        }

        static void ValidateDrawShaders()
        {
            string[] shaders = { "Resources/RenderSplats.shader", "Resources/RenderSplatsRelight.shader",
                "Shaders/RenderGaussianSplats.shader", "Shaders/Relight/RenderGaussianSplats.shader" };
            foreach (string path in shaders)
            {
                var shader = AssetDatabase.LoadAssetAtPath<Shader>(Root + path);
                var material = new Material(shader);
                try
                {
                    foreach (string keyword in new[] { "", "STEREO_INSTANCING_ON", "STEREO_MULTIVIEW_ON" })
                    {
                        material.DisableKeyword("STEREO_INSTANCING_ON");
                        material.DisableKeyword("STEREO_MULTIVIEW_ON");
                        if (keyword.Length > 0) material.EnableKeyword(keyword);
                        for (int pass = 0; pass < material.passCount; ++pass)
                            ShaderUtil.CompilePass(material, pass, true);
                    }
                    var errors = ShaderUtil.GetShaderMessages(shader).Where(m => m.severity == ShaderCompilerMessageSeverity.Error);
                    Require(!errors.Any(), path + ": " + string.Join("; ", errors.Select(m => m.message)));
                }
                finally { UnityEngine.Object.DestroyImmediate(material); }
            }
        }

        // Optional Android build validation. Uses a separate Library output directory and does not
        // change player settings, scenes or the installed headset application.
        public static void BuildAndroidShaders()
        {
            string output = "Library/SplatBoxValidation/Android";
            Directory.CreateDirectory(output);
            var assets = new[] { "Resources/RenderSplats.shader", "Resources/RenderSplatsRelight.shader",
                "Shaders/RenderGaussianSplats.shader", "Shaders/Relight/RenderGaussianSplats.shader",
                "Resources/BoxUtil.compute", "Shaders/BoxUtil.compute",
                "Resources/BoxUtilSort.compute", "Shaders/BoxUtilSort.compute",
                "Resources/SplatCompact.compute", "Shaders/SplatCompact.compute" }.Select(p => Root + p).ToArray();
            var manifest = BuildPipeline.BuildAssetBundles(output, new[] { new AssetBundleBuild
            { assetBundleName = "splatbox-shader-validation", assetNames = assets } },
                BuildAssetBundleOptions.ForceRebuildAssetBundle, BuildTarget.Android);
            Require(manifest != null, "Android shader bundle compilation failed");
            Debug.Log("SplatBox Android shader build PASS.");
        }

        static uint FloatBits(float value) => BitConverter.ToUInt32(BitConverter.GetBytes(value), 0);
        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
