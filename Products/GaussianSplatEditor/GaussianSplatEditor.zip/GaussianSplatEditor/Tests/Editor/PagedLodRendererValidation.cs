using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Tests
{
    // GPU-backed atlas copies plus page-ownership and refresh regressions.
    public static class PagedLodRendererValidation
    {
        const BindingFlags PrivateInstance = BindingFlags.NonPublic | BindingFlags.Instance;
        static string Root => UnityEditor.PackageManager.PackageInfo
            .FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";

        [MenuItem("Tools/Gaussian Splatting/Validate Paged LoD Streaming")]
        public static void RunAll()
        {
            PagedLodTraversalValidation.Run();
            PagedStreamingValidation.Run();
            LodSelectionWorkerValidation.Run();
            ProgressiveLodValidation.RunAll();
            SplatColorAdjustmentValidation.Run();
            Run();
        }

        public static void Run()
        {
            ValidatePageOwnership();
            ValidateEmptySelectionCadence();
            ValidateProjectionChanges();
            ValidateViewCoverageCadence();
            ValidateMobileMotionPrefetch();
            ValidateMobileTranslationPrefetch();
            ValidateBoundedMobileCoverage();
            ValidateCoarsePrefixDetail();
            ValidateProgressiveRefinement();
            ValidatePixelCutoffIsolation();
            ValidateExtendedDistanceDetail();
            ValidateRuntimeDistanceSettings();
            ValidateCoarseCoverageBudget();
            ValidateEditorResidencyBudget();
            ValidateDrivingCameraOwnership();
            ValidatePlayModeSortGating(Application.isPlaying);
            ValidateAsyncPublication();
            ValidateAtlasCopy("Resources/BoxUtil.compute");
            ValidateAtlasCopy("Shaders/BoxUtil.compute");
            Debug.Log("SplatBox paged renderer validation PASS: slot ownership, view-motion coverage, coarse-prefix detail, stationary progressive refinement, quality floor isolation, extended distance detail and runtime settings, bounded editor residency, driving camera ownership, selection sort gating, empty-view cadence, packed atlas copies.");
        }

        public static void RunPlayModeSortValidation()
        {
            Require(Application.isPlaying, "Play-mode sort validation must run after entering Play mode.");
            ValidatePlayModeSortGating(true);
            Debug.Log("SplatBox Play-mode LoD sort validation PASS: skipped intervals, stereo pass reuse and pending selection ownership.");
        }

        static void Set(object target, string field, object value) =>
            target.GetType().GetField(field, PrivateInstance).SetValue(target, value);
        static T Get<T>(object target, string field) =>
            (T)target.GetType().GetField(field, PrivateInstance).GetValue(target);
        static object Call(object target, string method, params object[] args) =>
            target.GetType().GetMethod(method, PrivateInstance).Invoke(target, args);

        static void ValidatePageOwnership()
        {
            var go = new GameObject("Paged ownership validation");
            go.SetActive(false);
            try
            {
                var renderer = go.AddComponent<SplatBoxRenderer>();
                var streamer = go.AddComponent<SplatBoxLodStreamer>();
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_ActiveSplatCount", 100);
                Set(renderer, "m_LodLastFullPageCount", 1);
                Set(renderer, "m_HasLastLodView", true);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                var oldPage = new SplatBoxPageGpuState { pageId = 1, pageSlot = 1, detailSlot = 0 };
                var newPage = new SplatBoxPageGpuState { pageId = 2, pageSlot = 2, detailSlot = 0 };
                Get<List<SplatBoxPageGpuState>>(renderer, "m_LodSelectedDetailPages").Add(oldPage);
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(newPage);
                Call(renderer, "OnLodPagesChanged");
                Require(Get<bool>(renderer, "m_LodSelectionInvalid"), "Reused detail slot retained the old selection.");
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "Invalid page ownership must bypass selection throttling.");
            }
            finally { UnityEngine.Object.DestroyImmediate(go); }
        }

        static void ValidateEmptySelectionCadence()
        {
            var go = new GameObject("Paged empty-view validation");
            go.SetActive(false);
            try
            {
                var renderer = go.AddComponent<SplatBoxRenderer>();
                Set(renderer, "m_ActiveSplatCount", 0);
                Set(renderer, "m_HasLastLodView", true);
                Set(renderer, "m_LodSelectionDirty", false);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "A valid empty view must not traverse every render call.");
                Set(renderer, "m_LodPendingSettledReselect", true);
                Set(renderer, "m_LodLastPageEventTime", Time.realtimeSinceStartup);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup - 0.3f);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "Continuous coarse arrivals must become visible before the entire stream settles.");
            }
            finally { UnityEngine.Object.DestroyImmediate(go); }
        }

        static void ValidateProgressiveRefinement()
        {
            var owner = new GameObject("Stationary progressive LoD validation");
            owner.SetActive(false);
            try
            {
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                var streamer = owner.AddComponent<SplatBoxLodStreamer>();
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_HasLastLodView", true);
                Set(renderer, "m_LodSelectionDirty", false);
                var nodes = new LodTreeNode[85];
                for (int i = 0; i < nodes.Length; i++)
                    nodes[i] = new LodTreeNode
                    {
                        center = new float3(0, 0, 5), featureSize = i < 5 ? 1f : 0.1f,
                        childStart = i < 21 ? (uint)(i * 4 + 1) : 0,
                        childCount = (ushort)(i < 21 ? 4 : 0)
                    };
                var page = new SplatBoxPageGpuState
                {
                    pageSlot = 0, atlasOffset = 0, splatCount = nodes.Length,
                    lodTree = LodTreeRuntime.Build(nodes, true)
                };
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(page);
                float now = Time.realtimeSinceStartup;
                page.BeginRefinement(5, now - SplatBoxPageGpuState.RefinementDurationSeconds * 0.5f);
                Set(renderer, "m_LastPlayLodSelectTime", now);
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "Progressive refinement ignored the normal selection interval.");
                Set(renderer, "m_LastPlayLodSelectTime", now - 0.2f);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "A stationary camera stopped a resident page's refinement.");
                var output = new LodActiveSplatRef[85];
                int intermediate = (int)Call(renderer, "SelectLoadedSplatsWithLod", null,
                    streamer.loadedPages, output.Length, output, false);
                Require(intermediate > 4 && intermediate < 64,
                    "The camera-null preload bypassed the intermediate hierarchy frontier.");
                Require(Get<bool>(renderer, "m_LodRefinementSelectionPending"),
                    "An incomplete frontier did not keep its final selection pending.");

                page.BeginRefinement(5, now - SplatBoxPageGpuState.RefinementDurationSeconds - 1f);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "The last refinement step disappeared when its clock expired.");
                int complete = (int)Call(renderer, "SelectLoadedSplatsWithLod", null,
                    streamer.loadedPages, output.Length, output, false);
                Require(complete == 64 && !Get<bool>(renderer, "m_LodRefinementSelectionPending"),
                    "The final frontier did not reach all leaves and stop refinement.");
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "A completed stationary page kept requesting traversal.");
            }
            finally { UnityEngine.Object.DestroyImmediate(owner); }
        }

        static void ValidatePixelCutoffIsolation()
        {
            var owner = new GameObject("LoD quality floor isolation validation");
            owner.SetActive(false);
            try
            {
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                renderer.lodSimpleMode = true;
                renderer.lodQuality = 0.5f;
                float[] nearestDistances = { 0f, 0.5f, 2f, 8f, 16f, float.MaxValue };
                foreach (float detailDistance in new[] { 2f, 8f })
                {
                    renderer.SetLodDetailDistance(detailDistance);
                    foreach (float nearestDistance in nearestDistances)
                    {
                        Set(renderer, "m_LodNearestPageDist", nearestDistance);
                        float cutoff = (float)Call(renderer, "EffectiveTraversalPixelCutoff");
                        Require(Mathf.Abs(cutoff - Mathf.Sqrt(6f)) < 0.0001f,
                            "An unrelated page's distance overrode the configured quality floor.");
                    }
                }

                Set(renderer, "m_LodSimpleMode", false);
                Set(renderer, "m_LodPixelScaleLimit", 0f);
                foreach (float nearestDistance in nearestDistances)
                {
                    Set(renderer, "m_LodNearestPageDist", nearestDistance);
                    Require(Mathf.Abs((float)Call(renderer, "EffectiveTraversalPixelCutoff") - 1f) < 0.0001f,
                        "A containing page bypassed the automatic one-pixel floor.");
                }

                // An explicitly finer floor remains available independently of unrelated bounds.
                Set(renderer, "m_LodPixelScaleLimit", 0.05f);
                foreach (float nearestDistance in nearestDistances)
                {
                    Set(renderer, "m_LodNearestPageDist", nearestDistance);
                    Require(Mathf.Abs((float)Call(renderer, "EffectiveTraversalPixelCutoff") - 0.05f) < 0.0001f,
                        "An unrelated page's distance overrode an explicitly finer pixel floor.");
                }
            }
            finally { UnityEngine.Object.DestroyImmediate(owner); }
        }

        static void ValidateExtendedDistanceDetail()
        {
            float originalRenderScale = GaussianSplatRenderSystem.SplatRenderScale;
            var owner = new GameObject("Extended distance LoD validation");
            owner.SetActive(false);
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            var target = new RenderTexture(640, 480, 0);
            SplatBoxLodStreamer streamer = null;
            try
            {
                const int pageId = 44;
                Vector3 min = new Vector3(-1f, -1f, 8f);
                Vector3 max = new Vector3(1f, 1f, 10f);
                scene.Initialize(min, max, 1, new[]
                {
                    new GaussianSplatPageEntry
                    {
                        pageId = pageId, boundsMin = min, boundsMax = max, splatCount = 21, lodNodeCount = 21
                    }
                });
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                streamer = owner.AddComponent<SplatBoxLodStreamer>();
                streamer.Configure(scene, owner.transform);
                Set(renderer, "m_PagedScene", scene);
                Set(renderer, "m_LodStreamer", streamer);
                var camera = owner.AddComponent<Camera>();
                camera.enabled = false;
                camera.fieldOfView = 60f;
                camera.targetTexture = target;
                // Renderer validation can change this global while adding inactive components.
                // Keep the fixture's 480-pixel projection independent of earlier fixtures.
                GaussianSplatRenderSystem.SplatRenderScale = 1f;
                var nodes = new LodTreeNode[21];
                for (int i = 0; i < nodes.Length; ++i)
                    nodes[i] = new LodTreeNode
                    {
                        center = new float3(i * 0.0005f, 0f, 8.5f),
                        featureSize = i == 0 ? 0.02f : i < 5 ? 0.005f : 0.001f,
                        childStart = i < 5 ? (uint)(i * 4 + 1) : 0,
                        childCount = i < 5 ? (ushort)4 : (ushort)0
                    };
                var tree = LodTreeRuntime.Build(nodes, true);
                var page = new SplatBoxPageGpuState
                {
                    pageId = pageId, pageSlot = 0, atlasOffset = 0, uploadedAtlasOffset = 0,
                    splatCount = nodes.Length, lodNodeCount = nodes.Length, lodTree = tree
                };
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(page);
                Require(Mathf.Abs(streamer.DistanceToLoadedPage(Vector3.zero, page, owner.transform) - 8f) < 0.0001f,
                    "Distant detail fixture did not use the configured page's eight-metre AABB distance.");
                const int selectionBudget = 64;
                var output = new LodActiveSplatRef[selectionBudget];
                int configuredBudget = renderer.EffectiveLodBudget;
                renderer.SetLodDetailDistance(2f);
                int originalCount = (int)Call(renderer, "SelectLoadedSplatsWithLod", camera,
                    streamer.loadedPages, selectionBudget, output, false);
                int originalLeaves = renderer.lastLodLeafCount;
                Require(originalCount == 1 && output[0].splatIndex == 0,
                    "The old distance profile did not exercise the blurred distant root.");
                renderer.SetLodDetailDistance(8f);
                int extendedCount = (int)Call(renderer, "SelectLoadedSplatsWithLod", camera,
                    streamer.loadedPages, selectionBudget, output, false);
                Require(extendedCount == 16 && renderer.lastLodLeafCount > originalLeaves &&
                        renderer.lastLodLeafCount == extendedCount,
                    "Extending detail distance did not refine the eight-metre surface to its resident leaves.");
                Require(extendedCount <= selectionBudget && renderer.EffectiveLodBudget == configuredBudget &&
                        ReferenceEquals(page.lodTree, tree) && ReferenceEquals(page.lodTreeNodes, nodes) &&
                        page.splatCount == 21 && page.atlasOffset == 0 && page.uploadedAtlasOffset == 0,
                    "Distant sharpening changed the global budget, resident tree or atlas payload.");
            }
            finally
            {
                streamer?.UnloadAll();
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(scene);
                UnityEngine.Object.DestroyImmediate(target);
                GaussianSplatRenderSystem.SplatRenderScale = originalRenderScale;
            }
        }

        static void ValidateRuntimeDistanceSettings()
        {
            var owner = new GameObject("Runtime LoD distance settings validation");
            owner.SetActive(false);
            try
            {
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                renderer.SetLodDetailDistance(2f);
                Set(renderer, "m_HasLastLodView", true);
                Set(renderer, "m_LodSelectionInvalid", false);
                Set(renderer, "m_LodSelectionDirty", false);
                Set(renderer, "m_LodAtlasDirty", false);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                uint generation = Get<uint>(renderer, "m_LodAsyncGeneration");
                int hash = (int)Call(renderer, "LodSelectionSettingsHash");
                int budget = renderer.EffectiveLodBudget;
                renderer.SetLodDetailDistance(8f);
                Require(renderer.lodDetailDistance == 8f && Get<bool>(renderer, "m_LodSelectionDirty") &&
                        Get<bool>(renderer, "m_LodAtlasDirty") &&
                        Get<uint>(renderer, "m_LodAsyncGeneration") != generation &&
                        (int)Call(renderer, "LodSelectionSettingsHash") != hash,
                    "Changing detail distance left the old stationary or asynchronous selection valid.");
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "A detail-distance change bypassed the normal selection interval.");
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup - 0.2f);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", new object[] { null }),
                    "A stationary camera did not refresh after changing detail distance.");

                Set(renderer, "m_LodSelectionDirty", false);
                Set(renderer, "m_LodAtlasDirty", false);
                generation = Get<uint>(renderer, "m_LodAsyncGeneration");
                renderer.SetLodDetailDistance(8f);
                Require(!Get<bool>(renderer, "m_LodSelectionDirty") && !Get<bool>(renderer, "m_LodAtlasDirty") &&
                        Get<uint>(renderer, "m_LodAsyncGeneration") == generation,
                    "Applying an unchanged detail distance restarted selection work.");
                renderer.SetLodDetailDistance(-1f);
                Require(renderer.lodDetailDistance == 2f, "Detail distance did not clamp to its minimum.");
                renderer.SetLodDetailDistance(100f);
                Require(renderer.lodDetailDistance == 32f && renderer.EffectiveLodBudget == budget,
                    "Detail distance exceeded its range or changed the splat budget.");
            }
            finally { UnityEngine.Object.DestroyImmediate(owner); }
        }

        static void ValidateCoarseCoverageBudget()
        {
            var pages = new[]
            {
                new GaussianSplatPageEntry { pageId = 1, splatCount = 400000 },
                new GaussianSplatPageEntry { pageId = 2, splatCount = 400000 },
                new GaussianSplatPageEntry { pageId = 3, splatCount = 400000 }
            };
            Require(CoveragePrefix(pages, 8192, 12288, 1650000, 400000, 4) == 12288,
                "Available atlas space did not improve distant coarse coverage while keeping four detail slots.");
            Require(CoveragePrefix(pages, 8192, 12288, 1630000, 400000, 4) == 8192,
                "Distant coarse coverage consumed space reserved for an existing detail slot.");
            Require(CoveragePrefix(pages, 16384, 12288, 1650000, 400000, 4) == 16384,
                "Automatic coarse coverage reduced an explicitly larger scene prefix.");
            int prefix = CoveragePrefix(pages, 8192, 16384, 1645000, 400000, 4);
            Require(prefix == 14336 && prefix % GaussianSplatAsset.kTextureWidth == 0 &&
                    (long)prefix * pages.Length + 400000L * 4 <= 1645000,
                "Coarse coverage did not select the largest aligned prefix inside the unchanged slot budget.");
            int withoutDetail = CoveragePrefix(pages, 8192, 12288, 40000, 400000, 0);
            Require(withoutDetail == 12288 && (long)withoutDetail * pages.Length <= 40000,
                "A coarse-only layout failed to use its available coverage budget.");
        }

        static int CoveragePrefix(GaussianSplatPageEntry[] pages, int basePrefix, int requestedPrefix,
            int capacity, int detailStride, int detailSlots)
        {
            return (int)typeof(SplatBoxRenderer).GetMethod("SelectCoarseCoveragePrefix",
                BindingFlags.NonPublic | BindingFlags.Static).Invoke(null,
                new object[] { pages, basePrefix, requestedPrefix, capacity, detailStride, detailSlots });
        }

        static void ValidateAtlasCopy(string path)
        {
            var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + path);
            Require(shader != null, "Missing atlas copy shader: " + path);
            int kernel = shader.FindKernel("CSCopyBufferRange");
            shader.GetKernelThreadGroupSizes(kernel, out uint threads, out _, out _);
            // Include odd final splats and the half-word packing used by High quality pages.
            int[] posStrides = { 2, 4, 6, 12 };
            int[] otherStrides = { 6, 8, 10, 16 };
            int[] shStrides = { 32, 60, 96, 192 };
            foreach (int count in new[] { 1, 3, 256, 257 })
            for (int format = 0; format < posStrides.Length; format++)
            {
                const int offset = 2048;
                int pos = posStrides[format], other = otherStrides[format], sh = shStrides[format];
                using var srcPos = Source(count, pos);
                using var srcOther = Source(count, other);
                using var srcSh = Source(count, sh);
                using var dstPos = Destination(offset + count + 4, pos);
                using var dstOther = Destination(offset + count + 4, other);
                using var dstSh = Destination(offset + count + 4, sh);
                shader.SetInt("_LodCopyCount", count);
                shader.SetInt("_LodCopyDstOffset", offset);
                shader.SetInt("_LodPosBytesPerSplat", pos);
                shader.SetInt("_LodOtherBytesPerSplat", other);
                shader.SetInt("_LodShBytesPerSplat", sh);
                shader.SetBuffer(kernel, "_LodCopySrcPos", srcPos);
                shader.SetBuffer(kernel, "_LodCopySrcOther", srcOther);
                shader.SetBuffer(kernel, "_LodCopySrcSh", srcSh);
                shader.SetBuffer(kernel, "_LodCopyDstPos", dstPos);
                shader.SetBuffer(kernel, "_LodCopyDstOther", dstOther);
                shader.SetBuffer(kernel, "_LodCopyDstSh", dstSh);
                int blocks = (count + 3) / 4;
                shader.Dispatch(kernel, (blocks + (int)threads - 1) / (int)threads, 1, 1);
                CheckCopy(dstPos, count, offset, pos, path);
                CheckCopy(dstOther, count, offset, other, path);
                CheckCopy(dstSh, count, offset, sh, path);
            }
        }

        static void ValidateAsyncPublication()
        {
            var go = new GameObject("Paged async-publication validation");
            go.SetActive(false);
            var worker = new SplatBoxLodSelectionWorker();
            using var indices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 4, 4);
            SplatBoxRenderer renderer = null;
            SplatBoxLodStreamer streamer = null;
            GameObject cameraOwner = null;
            try
            {
                renderer = go.AddComponent<SplatBoxRenderer>();
                streamer = go.AddComponent<SplatBoxLodStreamer>();
                var tree = LodTreeRuntime.Build(new[]
                {
                    new LodTreeNode { center = new float3(0, 0, 5), featureSize = 1, childStart = 1, childCount = 2 },
                    new LodTreeNode { center = new float3(-0.1f, 0, 5), featureSize = 0.1f },
                    new LodTreeNode { center = new float3(0.1f, 0, 5), featureSize = 0.1f }
                }, true);
                var contexts = new[] { new SplatBoxLodTraverser.PageContext
                {
                    pageSlot = 0, nodes = tree.nodes, localToWorld = float4x4.identity,
                    lodScale = 1, outsideFoveate = 1, behindFoveate = 1
                } };
                var view = new SplatBoxLodTraverser.ViewContext
                {
                    cameraForward = new float3(0, 0, 1), pixelScaleFactor = 1000,
                    pixelsPerUnitAtUnitDistance = 500, cosHalfFovY = 0.5f, splatScale = 1
                };
                var page = new SplatBoxPageGpuState
                {
                    pageSlot = 0, atlasOffset = 2048, splatCount = 1, isCoarseStub = true, lodTree = tree
                };
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(page);
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_LodSelectionWorker", worker);
                Set(renderer, "m_GpuLodAtlasIndices", indices);
                Set(renderer, "m_LodAtlasIndexScratch", new uint[4]);
                Set(renderer, "m_ActiveSplatCount", 77);
                Set(renderer, "m_AsyncLodSettingsHash", Call(renderer, "LodSelectionSettingsHash"));
                Require(worker.TryBegin(contexts, 1, view, 4, 0), "Background traversal did not start.");
                Require(!DrainRenderer(renderer, worker), "A downgraded page accepted expired detail indices.");
                Require(Get<int>(renderer, "m_ActiveSplatCount") == 77,
                    "Rejected worker selection changed the existing active payload.");

                page.splatCount = 3;
                Set(renderer, "m_AsyncLodViewPos", new Vector3(3, 4, 5));
                Set(renderer, "m_AsyncLodViewRot", Quaternion.Euler(0, 25, 0));
                Set(renderer, "m_LodPageEventSequence", 1u);
                Require(worker.TryBegin(contexts, 1, view, 4, 0, new[] { 2048 }), "Second background traversal did not start.");
                Require(DrainRenderer(renderer, worker), "Valid worker selection was not published.");
                var actual = new uint[4];
                indices.GetData(actual);
                Require(Get<int>(renderer, "m_ActiveSplatCount") == 2 && actual[0] == 2049 && actual[1] == 2050,
                    "Worker selection resolved the wrong resident atlas addresses.");
                Require(Get<Vector3>(renderer, "m_LastLodViewPos") == new Vector3(3, 4, 5),
                    "Publication recorded the current camera instead of the worker snapshot.");
                Require(Get<bool>(renderer, "m_LodPendingSettledReselect"),
                    "Page arrivals during a worker pass were lost at publication.");

                Require(worker.TryBegin(contexts, 1, view, 4, 0), "Third background traversal did not start.");
                Set(renderer, "m_LodDetailScale", 2f);
                Require(!DrainRenderer(renderer, worker), "Changed LOD settings accepted an obsolete worker result.");

                Set(renderer, "m_LodDetailScale", 1f);
                Require(worker.TryBegin(contexts, 1, view, 4, 0, new[] { 2048 }), "Fourth background traversal did not start.");
                page.atlasOffset = 4096;
                Require(!DrainRenderer(renderer, worker), "Relocated atlas region accepted obsolete gathered addresses.");

                page.atlasOffset = 2048;
                cameraOwner = new GameObject("Paged async-publication camera");
                cameraOwner.SetActive(false);
                var camera = cameraOwner.AddComponent<Camera>();
                camera.fieldOfView = 60;
                Call(renderer, "RecordLodViewpoint", camera);
                Set(renderer, "m_LodDrivingCamera", camera);
                Set(renderer, "m_AsyncLodViewSignature", Get<int>(renderer, "m_LastLodViewSignature"));
                Set(renderer, "m_AsyncLodViewPos", camera.transform.position);
                Set(renderer, "m_AsyncLodViewRot", camera.transform.rotation);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                Require(worker.TryBegin(contexts, 1, view, 4, 0, new[] { 2048 }), "Rotation regression traversal did not start.");
                camera.transform.rotation = Quaternion.Euler(0, 40, 0);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", camera),
                    "A turn beyond selected coverage waited for the normal cadence while a worker owned traversal.");
                Require(!DrainRenderer(renderer, worker), "A rapid turn accepted an obsolete worker frustum.");
                Require(Get<int>(renderer, "m_ActiveSplatCount") == 2,
                    "Rejected camera snapshot changed the existing active payload.");

                camera.transform.rotation = Quaternion.identity;
                Call(renderer, "RecordLodViewpoint", camera);
                Set(renderer, "m_AsyncLodViewSignature", Get<int>(renderer, "m_LastLodViewSignature"));
                Require(worker.TryBegin(contexts, 1, view, 4, 0, new[] { 2048 }), "Moderate-motion traversal did not start.");
                camera.transform.SetPositionAndRotation(new Vector3(0.01f, 0, 0), Quaternion.Euler(0, 2, 0));
                Require(DrainRenderer(renderer, worker), "Small camera motion starved a still-covered background selection.");
                Require(Get<Vector3>(renderer, "m_LastLodViewPos") == Vector3.zero &&
                        Quaternion.Angle(Get<Quaternion>(renderer, "m_LastLodViewRot"), Quaternion.identity) < 0.01f,
                    "Moderate-motion publication recorded the current pose instead of its selection snapshot.");

                // The currently published frontier can have a larger translation reserve than
                // the worker that is completing. Validate the worker's own immutable snapshot.
                camera.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);
                Set(renderer, "m_LodNearestPageDist", 0f);
                Set(renderer, "m_PendingLodTranslationPrefetch", 1f);
                Call(renderer, "RecordLodViewpoint", camera);
                Set(renderer, "m_AsyncLodTranslationPrefetch", 0f);
                Require(worker.TryBegin(contexts, 1, view, 4, 0, new[] { 2048 }),
                    "Unprefetched translation regression traversal did not start.");
                camera.transform.position = new Vector3(0, 0, -0.625f);
                Require(!DrainRenderer(renderer, worker),
                    "Worker publication borrowed a translation reserve absent from its own snapshot.");

                Set(renderer, "m_AsyncLodTranslationPrefetch", 1f);
                Require(worker.TryBegin(contexts, 1, view, 4, 0, new[] { 2048 }),
                    "Prefetched translation regression traversal did not start.");
                Require(DrainRenderer(renderer, worker) &&
                        Get<float>(renderer, "m_LastLodTranslationPrefetch") == 1f &&
                        renderer.lodSynchronousSelectionCount == 0,
                    "Covered backward motion rejected a prefetched worker or lost its published reserve.");
            }
            finally
            {
                worker.Dispose();
                if (renderer != null) Set(renderer, "m_GpuLodAtlasIndices", null);
                streamer?.UnloadAll();
                UnityEngine.Object.DestroyImmediate(go);
                if (cameraOwner != null) UnityEngine.Object.DestroyImmediate(cameraOwner);
            }
        }

        static void ValidateProjectionChanges()
        {
            var go = new GameObject("Paged projection-change validation");
            go.SetActive(false);
            float renderScale = GaussianSplatRenderSystem.SplatRenderScale;
            try
            {
                var renderer = go.AddComponent<SplatBoxRenderer>();
                var camera = go.AddComponent<Camera>();
                camera.fieldOfView = 60;
                Call(renderer, "RecordLodViewpoint", camera);
                Require(!(bool)Call(renderer, "HasLodViewChanged", camera), "Unchanged camera invalidated the view.");
                camera.fieldOfView = 100;
                Require((bool)Call(renderer, "HasLodViewChanged", camera), "FOV change left the old frustum selected.");
                Call(renderer, "RecordLodViewpoint", camera);
                GaussianSplatRenderSystem.SplatRenderScale = 0.37f;
                Require((bool)Call(renderer, "HasLodViewChanged", camera), "Render-target scale change left the old detail selected.");
            }
            finally
            {
                GaussianSplatRenderSystem.SplatRenderScale = renderScale;
                UnityEngine.Object.DestroyImmediate(go);
            }
        }

        static void ValidateViewCoverageCadence()
        {
            var go = new GameObject("Paged view-coverage validation");
            go.SetActive(false);
            var cameraOwner = new GameObject("Paged view-coverage camera");
            cameraOwner.SetActive(false);
            try
            {
                var renderer = go.AddComponent<SplatBoxRenderer>();
                var camera = cameraOwner.AddComponent<Camera>();
                camera.fieldOfView = 60;
                Set(renderer, "m_LodNearestPageDist", 1f);
                Set(renderer, "m_LodSelectionDirty", false);
                Call(renderer, "RecordLodViewpoint", camera);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                camera.transform.SetPositionAndRotation(new Vector3(0.01f, 0, 0), Quaternion.Euler(0, 1, 0));
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelection", camera),
                    "Ordinary covered motion bypassed the normal selection cadence.");
                Require(!(bool)Call(renderer, "LodViewCoverageExceeded", camera,
                        Vector3.zero, Quaternion.identity, 1f / 3f),
                    "Small motion unnecessarily requested an early background selection.");
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup - 0.1f);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", camera),
                    "Covered camera motion did not refresh at the normal cadence.");

                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                camera.transform.SetPositionAndRotation(Vector3.zero, Quaternion.Euler(0, 3, 0));
                Require((bool)Call(renderer, "LodViewCoverageExceeded", camera,
                        Vector3.zero, Quaternion.identity, 1f / 3f) &&
                        !(bool)Call(renderer, "RequiresImmediateLodSelection", camera),
                    "Covered rotation must request an early worker before requiring synchronous fallback.");
                camera.transform.rotation = Quaternion.Euler(0, 40, 0);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", camera),
                    "Rapid rotation left the old frustum selected until the cadence elapsed.");
                camera.transform.SetPositionAndRotation(new Vector3(0.6f, 0, 0), Quaternion.identity);
                Require((bool)Call(renderer, "ShouldRefreshLodSelection", camera),
                    "Rapid translation left the old frustum selected until the cadence elapsed.");

                Set(renderer, "m_LodSimpleMode", false);
                Set(renderer, "m_LodFrustumCull", false);
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelection", camera),
                    "A selection without frustum culling unnecessarily forced immediate motion refreshes.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(go);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
            }
        }

        static void ValidateMobileMotionPrefetch()
        {
            var owner = new GameObject("Mobile LoD motion-prefetch validation");
            owner.SetActive(false);
            var cameraOwner = new GameObject("Mobile LoD motion-prefetch camera");
            cameraOwner.SetActive(false);
            try
            {
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                var camera = cameraOwner.AddComponent<Camera>();
                camera.fieldOfView = 60f;
                camera.aspect = 1f;
                int budget = renderer.EffectiveLodBudget;
                float renderScale = GaussianSplatRenderSystem.SplatRenderScale;
                var paddingMethod = typeof(SplatBoxRenderer).GetMethod("LodCullPaddingForPlatform",
                    BindingFlags.NonPublic | BindingFlags.Static);
                var fractionMethod = typeof(SplatBoxRenderer).GetMethod("LodEarlyCoverageFractionForPlatform",
                    BindingFlags.NonPublic | BindingFlags.Static);
                float androidPadding = (float)paddingMethod.Invoke(null,
                    new object[] { true, 10f, RuntimePlatform.Android });
                float desktopPadding = (float)paddingMethod.Invoke(null,
                    new object[] { true, 10f, RuntimePlatform.WindowsPlayer });
                float androidFraction = (float)fractionMethod.Invoke(null,
                    new object[] { true, RuntimePlatform.Android });
                Require(androidPadding == 50f && desktopPadding == 15f &&
                        (float)paddingMethod.Invoke(null, new object[] { false, 7f, RuntimePlatform.Android }) == 7f &&
                        (float)fractionMethod.Invoke(null, new object[] { false, RuntimePlatform.Android }) == 1f / 3f,
                    "Mobile prefetch changed desktop defaults or explicit Advanced padding.");
                Require(Mathf.Abs(androidPadding * 0.4f * androidFraction - 2f) < 0.0001f,
                    "Widening mobile coverage postponed the early worker start beyond two degrees.");

                Set(renderer, "m_LodNearestPageDist", 10f);
                Call(renderer, "RecordLodViewpoint", camera);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                const float workerSeconds = 0.25f;
                const float turnSpeed = 60f;
                camera.transform.rotation = Quaternion.Euler(-turnSpeed * workerSeconds, 0, 0);
                Require(!(bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                            Vector3.zero, Quaternion.identity, 1f, androidPadding) &&
                        (bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                            Vector3.zero, Quaternion.identity, 1f, desktopPadding),
                    "A normal headset turn still required synchronous selection with mobile prefetch.");
                camera.transform.rotation = Quaternion.Euler(-20.1f, 0, 0);
                Require((bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                        Vector3.zero, Quaternion.identity, 1f, androidPadding),
                    "Mobile prefetch allowed movement beyond its safe frustum reserve.");

                // Page and refinement work must not delay a moving headset's early worker, but
                // the same pending work remains rate-limited when the camera stops.
                Set(renderer, "m_LodSelectionDirty", true);
                Set(renderer, "m_LodPendingSettledReselect", true);
                Set(renderer, "m_LodLastPageEventTime", Time.realtimeSinceStartup);
                Set(renderer, "m_LodRefinementSelectionPending", true);
                camera.transform.rotation = Quaternion.Euler(-3f, 0, 0);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                Require((bool)Call(renderer, "ShouldRefreshLodSelectionForPlatform", camera,
                        RuntimePlatform.Android, true),
                    "Pending streaming or refinement postponed early mobile motion selection.");
                camera.transform.rotation = Quaternion.identity;
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelectionForPlatform", camera,
                        RuntimePlatform.Android, true),
                    "Mobile prefetch bypassed the stationary streaming/refinement cadence.");

                // Verify that the extra reserve actually exists in the selection's padded
                // frustum, rather than merely relaxing the stale-result guard.
                var page = new SplatBoxLodTraverser.PageContext
                {
                    pageSlot = 0, localToWorld = float4x4.identity, lodScale = 1f,
                    outsideFoveate = 1f, behindFoveate = 1f,
                    nodes = new[] { new LodTreeNode
                    {
                        center = new float3(0, Mathf.Tan(49f * Mathf.Deg2Rad) * 10f, 10f),
                        featureSize = 0.001f
                    } }
                };
                var output = new LodActiveSplatRef[1];
                var workspace = new SplatBoxLodTraverser.Workspace();
                var mobileView = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    workspace, androidPadding);
                Require(SplatBoxLodTraverser.Traverse(new[] { page }, 1, mobileView, 1, 0f,
                        output, new SplatBoxLodTraverser.Workspace()) == 1,
                    "Mobile selection did not prefetch the region exposed by its twenty-degree safety reserve.");
                var formerMobileView = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    workspace, 30f);
                Require(SplatBoxLodTraverser.Traverse(new[] { page }, 1, formerMobileView, 1, 0f,
                        output, new SplatBoxLodTraverser.Workspace()) == 0,
                    "Mobile latency fixture was already covered by the former thirty-degree padding.");
                var desktopView = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    workspace, desktopPadding);
                Require(SplatBoxLodTraverser.Traverse(new[] { page }, 1, desktopView, 1, 0f,
                        output, new SplatBoxLodTraverser.Workspace()) == 0,
                    "Mobile prefetch fixture did not exercise the additional selection coverage.");
                camera.transform.rotation = Quaternion.Euler(-20f, 0, 0);
                var turnedView = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    workspace, 0f);
                Require(SplatBoxLodTraverser.Traverse(new[] { page }, 1, turnedView, 1, 0f,
                        output, new SplatBoxLodTraverser.Workspace()) == 1,
                    "Angular-prefetch fixture did not become visible within the published safety reserve.");
                Require(renderer.EffectiveLodBudget == budget &&
                        GaussianSplatRenderSystem.SplatRenderScale == renderScale,
                    "Mobile motion prefetch changed the splat budget or render resolution.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
            }
        }

        static void ValidateMobileTranslationPrefetch()
        {
            var owner = new GameObject("Mobile LoD translation-prefetch validation");
            owner.SetActive(false);
            var cameraOwner = new GameObject("Mobile LoD translation-prefetch camera");
            cameraOwner.SetActive(false);
            try
            {
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                var camera = cameraOwner.AddComponent<Camera>();
                camera.fieldOfView = 60f;
                camera.aspect = 1f;
                camera.nearClipPlane = 0.3f;
                camera.farClipPlane = 100f;
                var radiusMethod = typeof(SplatBoxRenderer).GetMethod("LodTranslationPrefetchForPlatform",
                    BindingFlags.NonPublic | BindingFlags.Static);
                var padMethod = typeof(SplatBoxRenderer).GetMethod("PadLodTranslationFrustum",
                    BindingFlags.NonPublic | BindingFlags.Static);
                float radius = (float)radiusMethod.Invoke(null, new object[] { true, RuntimePlatform.Android });
                Require(radius == 1f &&
                        (float)radiusMethod.Invoke(null, new object[] { false, RuntimePlatform.Android }) == 0f &&
                        (float)radiusMethod.Invoke(null, new object[] { true, RuntimePlatform.WindowsPlayer }) == 0f,
                    "Translation prefetch changed desktop or Advanced culling.");

                Set(renderer, "m_LodNearestPageDist", 0f);
                Call(renderer, "RecordLodViewpoint", camera);
                camera.transform.position = new Vector3(0, 0, -0.75f);
                Require((bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                        Vector3.zero, Quaternion.identity, 1f, 50f),
                    "A cold profile change assumed a translation reserve absent from the published frontier.");
                camera.transform.position = Vector3.zero;
                Set(renderer, "m_PendingLodTranslationPrefetch", radius);
                Call(renderer, "RecordLodViewpoint", camera);
                Set(renderer, "m_PendingLodTranslationPrefetch", 0f);
                camera.transform.position = new Vector3(0, 0, -0.75f);
                Require(!(bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                        Vector3.zero, Quaternion.identity, 1f, 50f),
                    "Covered backward motion still forced a synchronous selection.");
                camera.transform.position = new Vector3(0, 0, -0.81f);
                Require((bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                        Vector3.zero, Quaternion.identity, 1f, 50f),
                    "Translation prefetch allowed motion beyond its captured safety reserve.");

                // The worker starts after the early threshold, rather than at the selected pose.
                // Account for that offset as well as a quarter second of full stick locomotion.
                const float workerSeconds = 0.25f;
                const float walkSpeed = 2.5f;
                const float turnSpeed = 60f;
                float earlyFraction = (float)typeof(SplatBoxRenderer).GetMethod(
                    "LodEarlyCoverageFractionForPlatform", BindingFlags.NonPublic | BindingFlags.Static)
                    .Invoke(null, new object[] { true, RuntimePlatform.Android });
                camera.transform.SetPositionAndRotation(
                    new Vector3(0, 0, -(radius * 0.8f * earlyFraction + walkSpeed * workerSeconds)),
                    Quaternion.Euler(0, 50f * 0.4f * earlyFraction + turnSpeed * workerSeconds, 0));
                Require(!(bool)Call(renderer, "LodViewCoverageExceededForPadding", camera,
                        Vector3.zero, Quaternion.identity, 1f, 50f),
                    "Full-speed walking and turning exhausted mobile coverage before a 250-ms worker could finish.");
                Set(renderer, "m_LodSelectionDirty", true);
                Set(renderer, "m_LodPendingSettledReselect", true);
                Set(renderer, "m_LodLastPageEventTime", Time.realtimeSinceStartup);
                Set(renderer, "m_LodRefinementSelectionPending", true);
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                camera.transform.SetPositionAndRotation(new Vector3(0, 0, -0.09f), Quaternion.identity);
                Require((bool)Call(renderer, "ShouldRefreshLodSelectionForPlatform", camera,
                        RuntimePlatform.Android, true),
                    "Pending page/refinement work postponed the early backward-motion worker.");

                // A backward step exposes content behind the old near plane, so angular FOV
                // padding alone cannot justify the relaxed translation guard.
                Matrix4x4 projection = Matrix4x4.Perspective(60f, 1f, 0.3f, 100f);
                Matrix4x4 flip = Matrix4x4.Scale(new Vector3(1, 1, -1));
                Matrix4x4 leftView = flip * Matrix4x4.Translate(new Vector3(0.03f, 0, 0));
                Matrix4x4 rightView = flip * Matrix4x4.Translate(new Vector3(-0.03f, 0, 0));
                GaussianSplatRenderSystem.SetOverrideMatrices(leftView, projection);
                GaussianSplatRenderSystem.SetOverrideStereoMatrices(leftView, projection, rightView, projection);
                var view = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    new SplatBoxLodTraverser.Workspace(), 50f);
                var leftPlanes = (float4[])view.cullPlanes.Clone();
                var rightPlanes = (float4[])view.rightEyeCullPlanes.Clone();
                var pages = new[] { new SplatBoxLodTraverser.PageContext
                {
                    pageSlot = 0, localToWorld = float4x4.identity, lodScale = 1f,
                    outsideFoveate = 1f, behindFoveate = 1f,
                    nodes = new[] { new LodTreeNode { center = new float3(0, 0, 0.05f), featureSize = 0.001f } }
                } };
                var output = new LodActiveSplatRef[1];
                Require(SplatBoxLodTraverser.Traverse(pages, 1, view, 1, 0f, output,
                        new SplatBoxLodTraverser.Workspace()) == 0,
                    "Backward-motion fixture was already inside the old near plane.");
                Require((float)padMethod.Invoke(null, new object[] { view, radius }) == radius,
                    "The selection did not record its actually applied translation reserve.");
                for (int i = 0; i < leftPlanes.Length; i++)
                    Require(math.distance(leftPlanes[i].xyz, view.cullPlanes[i].xyz) < 0.000001f &&
                            math.distance(rightPlanes[i].xyz, view.rightEyeCullPlanes[i].xyz) < 0.000001f &&
                            Mathf.Abs(view.cullPlanes[i].w - leftPlanes[i].w - radius) < 0.00001f &&
                            Mathf.Abs(view.rightEyeCullPlanes[i].w - rightPlanes[i].w - radius) < 0.00001f,
                        "Translation prefetch did not expand every normalized plane of both eyes.");
                Require(SplatBoxLodTraverser.Traverse(pages, 1, view, 1, 0f, output,
                        new SplatBoxLodTraverser.Workspace()) == 1,
                    "The prefetched frontier lost content newly visible after a backward step.");
                leftView = flip * Matrix4x4.Translate(new Vector3(0.03f, 0, 0.75f));
                rightView = flip * Matrix4x4.Translate(new Vector3(-0.03f, 0, 0.75f));
                GaussianSplatRenderSystem.SetOverrideMatrices(leftView, projection);
                GaussianSplatRenderSystem.SetOverrideStereoMatrices(leftView, projection, rightView, projection);
                var movedView = SplatBoxLodTraverser.ViewContext.FromCamera(camera, true,
                    new SplatBoxLodTraverser.Workspace(), 0f);
                Require(SplatBoxLodTraverser.Traverse(pages, 1, movedView, 1, 0f, output,
                        new SplatBoxLodTraverser.Workspace()) == 1,
                    "Backward-motion fixture did not become visible in the headset's fresh frustum.");

                Set(renderer, "m_PendingLodTranslationPrefetch", radius);
                Require((int)Call(renderer, "SelectLoadedSplatsWithLod", null,
                        Array.Empty<SplatBoxPageGpuState>(), 1, output, false) == 0 &&
                        Get<float>(renderer, "m_PendingLodTranslationPrefetch") == 0f,
                    "An empty/camera-less selection claimed unused translation prefetch.");
                Call(renderer, "RecordLodViewpoint", new object[] { null });
                Require(Get<float>(renderer, "m_LastLodTranslationPrefetch") == 0f,
                    "A camera-less selection retained another snapshot's translation reserve.");
            }
            finally
            {
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideMatrices();
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
            }
        }

        static void ValidateBoundedMobileCoverage()
        {
            var owner = new GameObject("Bounded mobile coverage validation");
            owner.SetActive(false);
            var cameraOwner = new GameObject("Bounded mobile coverage camera");
            cameraOwner.SetActive(false);
            var target = new RenderTexture(640, 480, 0);
            var paused = new System.Threading.Tasks.TaskCompletionSource<SplatBoxLodSelectionWorker.Result>();
            using var indices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 8, 4);
            SplatBoxLodSelectionWorker worker = null;
            SplatBoxLodStreamer streamer = null;
            SplatBoxRenderer renderer = null;
            try
            {
                renderer = owner.AddComponent<SplatBoxRenderer>();
                streamer = owner.AddComponent<SplatBoxLodStreamer>();
                var camera = cameraOwner.AddComponent<Camera>();
                camera.fieldOfView = 60;
                camera.targetTexture = target;
                var nodes = new LodTreeNode[21];
                for (int i = 0; i < nodes.Length; i++)
                    nodes[i] = new LodTreeNode
                    {
                        center = new float3(0, 0, 5), featureSize = i == 0 ? 1f : i < 5 ? 0.3f : 0.03f,
                        childCount = i < 5 ? (ushort)4 : (ushort)0,
                        childStart = i < 5 ? (uint)(i * 4 + 1) : 0
                    };
                var page = new SplatBoxPageGpuState
                {
                    pageSlot = 0, atlasOffset = 2048, splatCount = nodes.Length,
                    isCoarseStub = true, lodTree = LodTreeRuntime.Build(nodes, true)
                };
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(page);
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_LodDrivingCamera", camera);
                Set(renderer, "m_LodActiveScratch", new LodActiveSplatRef[8]);
                Set(renderer, "m_LodAtlasIndexScratch", new uint[8]);
                Set(renderer, "m_GpuLodAtlasIndices", indices);
                int budget = renderer.EffectiveLodBudget;
                float quality = renderer.lodQuality;
                float renderScale = GaussianSplatRenderSystem.SplatRenderScale;
                var scratch = new LodActiveSplatRef[8];

                Call(renderer, "SelectLoadedSplatsWithLod", camera, streamer.loadedPages, 8, scratch, false);
                Require(renderer.lastLodBudgetExhausted, "Dense-view fixture did not exhaust its synthetic budget.");
                float measuredCutoff = Get<float>(renderer, "m_LastLodBudgetCutoff");
                camera.transform.rotation = Quaternion.Euler(0, 180, 0);
                Require((int)Call(renderer, "SelectLoadedSplatsWithLod", camera, streamer.loadedPages,
                            8, scratch, false) == 0 && !renderer.lastLodBudgetExhausted &&
                        Get<float>(renderer, "m_LastLodBudgetCutoff") == measuredCutoff,
                    "A sparse exact view erased the measured dense-view budget cutoff.");
                Call(renderer, "RecordLodViewpoint", camera);
                camera.transform.rotation = Quaternion.identity;
                Require((bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                        RuntimePlatform.Android, true),
                    "A rapid return from a sparse view did not reuse its measured budget-pressure hint.");
                Require(!(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                            RuntimePlatform.WindowsPlayer, true) &&
                        !(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                            RuntimePlatform.Android, false),
                    "Bounded mobile coverage changed desktop or edit-mode selection.");
                Set(renderer, "m_LodSimpleMode", false);
                Require(!(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                        RuntimePlatform.Android, true), "Bounded coverage changed explicit Advanced selection.");
                Set(renderer, "m_LodSimpleMode", true);
                Set(renderer, "m_LodAsyncTraversal", false);
                Require(!(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                        RuntimePlatform.Android, true), "Bounded coverage changed synchronous-only selection.");
                Set(renderer, "m_LodAsyncTraversal", true);
                camera.fieldOfView = 70;
                Require(!(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                        RuntimePlatform.Android, true), "Budget history escaped its captured projection.");
                camera.fieldOfView = 60;
                renderer.lodQuality = quality * 0.5f;
                Require(!(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                        RuntimePlatform.Android, true), "Budget history escaped its captured quality settings.");
                renderer.lodQuality = quality;
                Set(renderer, "m_LastLodBudgetCutoff", 0f);
                Require(!(bool)Call(renderer, "ShouldUseBoundedLodCoverage", camera, false,
                        RuntimePlatform.Android, true), "A view without prior pressure used a provisional repair.");
                Set(renderer, "m_LastLodBudgetCutoff", measuredCutoff);

                // Model an obsolete native task that still owns its pinned arrays. Publication
                // must not wait for it or reuse its arrays, and refinement must queue once it retires.
                worker = new SplatBoxLodSelectionWorker();
                Set(worker, "m_Task", paused.Task);
                Set(renderer, "m_LodSelectionWorker", worker);
                Call(renderer, "SelectAndGatherLodSplatsForPlatform", camera, null, false,
                    RuntimePlatform.Android, true);
                int provisional = Get<int>(renderer, "m_ActiveSplatCount");
                uint revision = Get<uint>(renderer, "m_LodSelectionRevision");
                Require(provisional == 4 && renderer.usesProvisionalLodCoverage &&
                        renderer.lodProvisionalCoverageCount == 1 && renderer.lodSynchronousSelectionCount == 1 &&
                        worker.isRunning && ReferenceEquals(Get<System.Threading.Tasks.Task<SplatBoxLodSelectionWorker.Result>>(
                            worker, "m_Task"), paused.Task),
                    "Coverage repair waited for or overwrote a running worker, or published a partial frontier.");
                Require(Get<Vector3>(renderer, "m_LastLodViewPos") == camera.transform.position &&
                        Quaternion.Angle(Get<Quaternion>(renderer, "m_LastLodViewRot"), camera.transform.rotation) < 0.001f,
                    "Provisional coverage recorded an obsolete camera pose.");
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                Require((bool)Call(renderer, "ShouldRefreshLodSelectionForPlatform", camera,
                        RuntimePlatform.Android, true), "A stationary provisional selection failed to request exact refinement.");
                paused.SetResult(default);
                Require(!(bool)Call(renderer, "TryApplyAsyncLodSelection", new object[] { null }),
                    "An obsolete worker result replaced the fresh provisional selection.");
                Call(renderer, "SelectAndGatherLodSplatsForPlatform", camera, null, true,
                    RuntimePlatform.Android, true);
                Require(worker.isRunning && renderer.lodSynchronousSelectionCount == 1 &&
                        renderer.lodProvisionalCoverageCount == 1 &&
                        Get<uint>(renderer, "m_LodSelectionRevision") == revision &&
                        Mathf.Approximately(Get<float>(renderer, "m_AsyncLodPixelCutoff"), renderer.lodPixelScaleLimit) &&
                        !ReferenceEquals(Get<LodActiveSplatRef[]>(worker, "m_Output"),
                            Get<LodActiveSplatRef[]>(renderer, "m_LodActiveScratch")),
                    "Exact refinement republished coverage, changed quality, or borrowed the main-thread output array.");
                camera.transform.rotation = Quaternion.Euler(0, 60, 0);
                Require(!DrainRenderer(renderer, worker) && renderer.usesProvisionalLodCoverage &&
                        Get<int>(renderer, "m_ActiveSplatCount") == provisional &&
                        Get<uint>(renderer, "m_LodSelectionRevision") == revision,
                    "A stale exact worker overwrote coverage or cleared its outstanding refinement request.");
                camera.transform.rotation = Quaternion.identity;
                Call(renderer, "SelectAndGatherLodSplatsForPlatform", camera, null, true,
                    RuntimePlatform.Android, true);
                Require(DrainRenderer(renderer, worker) && !renderer.usesProvisionalLodCoverage &&
                        Get<int>(renderer, "m_ActiveSplatCount") > provisional &&
                        renderer.lodProvisionalCoverageCount == 1,
                    "Exact requested-quality refinement failed to replace the temporary coverage once.");
                Set(renderer, "m_LastPlayLodSelectTime", Time.realtimeSinceStartup);
                Require(!(bool)Call(renderer, "ShouldRefreshLodSelectionForPlatform", camera,
                        RuntimePlatform.Android, true), "Completed exact refinement endlessly refreshed a stationary provisional view.");
                Require(renderer.EffectiveLodBudget == budget && renderer.lodQuality == quality &&
                        GaussianSplatRenderSystem.SplatRenderScale == renderScale,
                    "Bounded coverage changed the configured quality, budget or render resolution.");

                ValidateSmallPriorityCoverageFallback(renderer);
            }
            finally
            {
                paused.TrySetResult(default);
                worker?.Dispose();
                if (renderer != null) Set(renderer, "m_GpuLodAtlasIndices", null);
                streamer?.UnloadAll();
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
                UnityEngine.Object.DestroyImmediate(target);
            }
        }

        static void ValidateSmallPriorityCoverageFallback(SplatBoxRenderer renderer)
        {
            // All three threshold attempts overflow. A full-budget heap would select 100k;
            // the temporary global-priority fallback must stay at 65,536 and cover whole subtrees.
            const int leafCount = 262144;
            const int nodeCount = (leafCount * 4 - 1) / 3;
            const int internalCount = nodeCount - leafCount;
            var nodes = new LodTreeNode[nodeCount];
            for (int i = 0; i < nodes.Length; i++)
                nodes[i] = new LodTreeNode
                {
                    center = new float3(0, 0, 5), featureSize = i < internalCount ? 1f : 0.001f,
                    childCount = i < internalCount ? (ushort)4 : (ushort)0,
                    childStart = i < internalCount ? (uint)(i * 4 + 1) : 0
                };
            Set(renderer, "m_LodPageContextScratch", new[] { new SplatBoxLodTraverser.PageContext
            {
                pageSlot = 0, nodes = nodes, localToWorld = float4x4.identity, lodScale = 1,
                outsideFoveate = 1, behindFoveate = 1
            } });
            Set(renderer, "m_LodWorkspace", new SplatBoxLodTraverser.Workspace());
            Set(renderer, "m_LastLodBudgetCutoff", 1f);
            var view = new SplatBoxLodTraverser.ViewContext
            {
                cameraForward = new float3(0, 0, 1), pixelScaleFactor = 1000,
                pixelsPerUnitAtUnitDistance = 500, cosHalfFovY = -1, splatScale = 1,
                maxStandInPixels = SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels
            };
            var output = new LodActiveSplatRef[100000];
            int selected = (int)Call(renderer, "TraverseBoundedLodCoverage", view, 1, output.Length, output);
            Require(selected > 0 && selected <= 65536 && !renderer.usesDepthFirstLodTraversal,
                "Failed DFS coverage attempts fell through into a full-budget heap or published partial output.");
            var selectedNodes = new HashSet<uint>();
            for (int i = 0; i < selected; i++)
                Require(selectedNodes.Add(output[i].splatIndex), "Bounded coverage emitted a duplicate subtree.");
            int coveredLeaves = 0;
            foreach (uint node in selectedNodes)
            {
                int depth = 0;
                for (uint ancestor = node; ancestor > 0;)
                {
                    ancestor = (ancestor - 1) / 4;
                    Require(!selectedNodes.Contains(ancestor), "Bounded coverage emitted overlapping parent and child subtrees.");
                    depth++;
                }
                coveredLeaves += 1 << ((9 - depth) * 2);
            }
            Require(coveredLeaves == leafCount, "The small priority fallback lost whole-subtree coverage.");
        }

        static void ValidateCoarsePrefixDetail()
        {
            var go = new GameObject("Paged coarse-prefix detail validation");
            go.SetActive(false);
            var target = new RenderTexture(640, 480, 0);
            SplatBoxLodStreamer streamer = null;
            try
            {
                var renderer = go.AddComponent<SplatBoxRenderer>();
                streamer = go.AddComponent<SplatBoxLodStreamer>();
                var camera = go.AddComponent<Camera>();
                camera.fieldOfView = 60;
                camera.targetTexture = target;
                Set(renderer, "m_LodStreamer", streamer);
                var tree = LodTreeRuntime.Build(new[]
                {
                    new LodTreeNode { center = new float3(0, 0, 20), featureSize = 0.1f, childStart = 1, childCount = 2 },
                    new LodTreeNode { center = new float3(-0.02f, 0, 20), featureSize = 0.01f },
                    new LodTreeNode { center = new float3(0.02f, 0, 20), featureSize = 0.01f }
                }, true);
                var page = new SplatBoxPageGpuState
                {
                    pageSlot = 0, atlasOffset = 0, splatCount = 3, isCoarseStub = true, lodTree = tree
                };
                Get<List<SplatBoxPageGpuState>>(streamer, "m_LoadedList").Add(page);
                var coarse = new LodActiveSplatRef[4];
                var full = new LodActiveSplatRef[4];
                int coarseCount = (int)Call(renderer, "SelectLoadedSplatsWithLod", camera,
                    streamer.loadedPages, 4, coarse, false);
                Require(coarseCount == 2 && coarse[0].splatIndex != 0 && coarse[1].splatIndex != 0,
                    "A resident coarse prefix stopped at a blurred root despite finer resident nodes and spare budget.");
                page.isCoarseStub = false;
                int fullCount = (int)Call(renderer, "SelectLoadedSplatsWithLod", camera,
                    streamer.loadedPages, 4, full, false);
                Require(fullCount == coarseCount, "Identical resident trees changed density at coarse/full residency transition.");
                for (int i = 0; i < coarseCount; i++)
                    Require(coarse[i].splatIndex == full[i].splatIndex,
                        "Identical resident trees selected different detail at coarse/full residency transition.");
            }
            finally
            {
                streamer?.UnloadAll();
                UnityEngine.Object.DestroyImmediate(go);
                UnityEngine.Object.DestroyImmediate(target);
            }
        }

        static void ValidateEditorResidencyBudget()
        {
            var go = new GameObject("Paged editor-residency budget validation");
            go.SetActive(false);
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            var format = ScriptableObject.CreateInstance<GaussianSplatAsset>();
            SplatBoxLodStreamer streamer = null;
            try
            {
                const int pageSplats = 3_000_000;
                scene.Initialize(Vector3.zero, Vector3.one * 20, 10, new[]
                {
                    new GaussianSplatPageEntry { pageId = 10, splatCount = pageSplats },
                    new GaussianSplatPageEntry { pageId = 20, splatCount = pageSplats }
                });
                format.Initialize(1, GaussianSplatAsset.VectorFormat.Norm16,
                    GaussianSplatAsset.VectorFormat.Norm16, GaussianSplatAsset.ColorFormat.Float16x4,
                    GaussianSplatAsset.SHFormat.Norm11, Vector3.zero, Vector3.one, null);
                var renderer = go.AddComponent<SplatBoxRenderer>();
                streamer = go.AddComponent<SplatBoxLodStreamer>();
                streamer.Configure(scene, go.transform);
                Set(renderer, "m_PagedScene", scene);
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_LodFormatAsset", format);
                Require((bool)Call(renderer, "SetLodFormatStrides", format), "High-quality atlas strides were rejected.");
                Require(!SplatBoxLodStreamer.CanEditorLoadAllPages(scene),
                    "The public editor-residency helper unexpectedly changed its default four-million-splat limit.");

                foreach (int budget in new[] { 1024, 256 })
                {
                    Set(renderer, "m_LodAtlasBudgetMB", budget);
                    renderer.SetLodDetailDistance(2f);
                    Call(renderer, "EnsureAtlasLayout");
                    int capacity = (int)Call(renderer, "MaxAtlasSplatCapacity");
                    int total = Get<int>(renderer, "m_AtlasLayoutTotal");
                    bool wholeScene = budget == 1024;
                    Require(Get<bool>(renderer, "m_AtlasLayoutIsPerPage") == wholeScene &&
                            streamer.loadsEveryPageAtFullDetail == wholeScene,
                        "Editor full-scene residency did not follow the configured byte budget.");
                    Require(renderer.effectiveLodAtlasBudgetMB == budget && total <= capacity,
                        "Editor residency exceeded or silently raised its atlas memory ceiling.");
                    int[] offsets = Get<int[]>(renderer, "m_AtlasPageOffset");
                    int[] reserves = Get<int[]>(renderer, "m_AtlasPageReserve");
                    for (int i = 0; i < scene.pageCount; i++)
                    {
                        Require(offsets[i] >= 0 && reserves[i] > 0 &&
                                (long)offsets[i] + reserves[i] <= capacity,
                            "A permanent page region escaped the byte-bounded atlas.");
                        Require(wholeScene ? reserves[i] >= pageSplats : reserves[i] < pageSplats,
                            "Permanent page reservations did not switch between full data and coarse prefixes.");
                    }
                    int detailEnd = Get<int>(renderer, "m_AtlasDetailStart") +
                        renderer.lodAtlasDetailSlots * renderer.lodAtlasSlotSplats;
                    Require(detailEnd <= capacity &&
                            (wholeScene || streamer.detailSlotCapacity == renderer.lodAtlasDetailSlots),
                        "The streamer detail pool exceeded or disagreed with the memory-bounded layout.");
                    Require(Get<GraphicsBuffer>(renderer, "m_GpuLodUnifiedPos") == null &&
                            Get<GraphicsBuffer>(renderer, "m_GpuLodAtlasIndices") == null,
                        "Planning editor residency unexpectedly allocated the synthetic multi-million-splat atlas.");

                    int originalSlots = renderer.lodAtlasDetailSlots;
                    renderer.SetLodDetailDistance(8f);
                    Call(renderer, "EnsureAtlasLayout");
                    Require((int)Call(renderer, "MaxAtlasSplatCapacity") == capacity &&
                            renderer.lodAtlasDetailSlots == originalSlots &&
                            Get<int>(renderer, "m_AtlasLayoutTotal") <= capacity,
                        "Extending distant coverage changed atlas capacity or removed an existing detail slot.");
                    int coverageTarget = Get<int>(renderer, "m_AtlasCoarsePageSplatTarget");
                    Require(wholeScene ? coverageTarget == 0 : coverageTarget == 12288,
                        "Distant coverage target did not follow the actual streaming/per-page layout.");
                    Require(wholeScene || streamer.coarsePageSplats == coverageTarget,
                        "The streamer did not adopt its atlas-funded distant coverage prefix.");
                    Require(Get<GraphicsBuffer>(renderer, "m_GpuLodUnifiedPos") == null &&
                            Get<GraphicsBuffer>(renderer, "m_GpuLodAtlasIndices") == null,
                        "Changing distant coverage allocated an atlas while only planning residency.");
                }
            }
            finally
            {
                streamer?.UnloadAll();
                UnityEngine.Object.DestroyImmediate(go);
                UnityEngine.Object.DestroyImmediate(scene);
                UnityEngine.Object.DestroyImmediate(format);
            }
        }

        static void ValidateDrivingCameraOwnership()
        {
            var previousMainObjects = GameObject.FindGameObjectsWithTag("MainCamera");
            var owner = new GameObject("Paged driving-camera ownership validation");
            owner.SetActive(false);
            var driverOwner = new GameObject("Paged selection Main Camera");
            var otherOwner = new GameObject("Paged secondary render callback");
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            using var cmd = new CommandBuffer { name = "Non-driver LoD callback validation" };
            try
            {
                foreach (var existing in previousMainObjects)
                    existing.tag = "Untagged";
                var driver = driverOwner.AddComponent<Camera>();
                driverOwner.tag = "MainCamera";
                driver.transform.SetPositionAndRotation(new Vector3(2, 3, 4), Quaternion.Euler(0, 15, 0));
                var other = otherOwner.AddComponent<Camera>();
                other.enabled = false;
                other.transform.SetPositionAndRotation(new Vector3(20, 30, 40), Quaternion.Euler(0, 150, 0));
                Require(Camera.main == driver, "Driving-camera fixture did not own the MainCamera tag.");

                scene.Initialize(Vector3.zero, Vector3.one, 1, new[]
                {
                    new GaussianSplatPageEntry { pageId = 0, splatCount = 2 }
                });
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                var streamer = owner.AddComponent<SplatBoxLodStreamer>();
                streamer.Configure(scene, owner.transform);
                var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(Root + "Resources/BoxUtil.compute");
                Set(renderer, "m_PagedScene", scene);
                Set(renderer, "m_LodStreamer", streamer);
                Set(renderer, "m_CSBoxUtil", shader);
                Require(renderer.UsesPagedLod && renderer.lodStreamer == streamer && shader != null,
                    "Driving-camera fixture failed the ordinary UpdatePagedLod setup checks.");
                Set(renderer, "m_ActiveSplatCount", 77);
                Set(renderer, "m_LodSelectionRevision", 9u);
                Set(renderer, "m_LodDrivingCamera", driver);
                Call(renderer, "RecordLodViewpoint", driver);
                var position = Get<Vector3>(renderer, "m_LastLodViewPos");
                var rotation = Get<Quaternion>(renderer, "m_LastLodViewRot");
                int signature = Get<int>(renderer, "m_LastLodViewSignature");
                uint generation = Get<uint>(renderer, "m_LodAsyncGeneration");
                int commandBytes = cmd.sizeInBytes;

                foreach (int width in new[] { 320, 1600 })
                {
                    // This emulates URP installing a secondary camera's eye/target state before
                    // its callback. Renaming the argument to Main Camera must not consume it.
                    GaussianSplatRenderSystem.SetOverrideMatrices(other.worldToCameraMatrix,
                        Matrix4x4.Perspective(width == 320 ? 30 : 110, 2f, 0.1f, 100f));
                    GaussianSplatRenderSystem.SetOverrideRenderTargetSize(width, width / 2);
                    renderer.UpdatePagedLod(other, cmd);
                    Require(Get<int>(renderer, "m_ActiveSplatCount") == 77 &&
                        Get<uint>(renderer, "m_LodSelectionRevision") == 9u &&
                        Get<Camera>(renderer, "m_LodDrivingCamera") == driver &&
                        Get<Vector3>(renderer, "m_LastLodViewPos") == position &&
                        Quaternion.Angle(Get<Quaternion>(renderer, "m_LastLodViewRot"), rotation) < 0.001f &&
                        Get<int>(renderer, "m_LastLodViewSignature") == signature &&
                        Get<uint>(renderer, "m_LodAsyncGeneration") == generation,
                        "A non-driver render callback mutated the Main Camera's published LoD selection.");
                    Require(cmd.sizeInBytes == commandBytes && streamer.loadedPages.Count == 0 &&
                        Get<GraphicsBuffer>(renderer, "m_GpuLodAtlasIndices") == null,
                        "A non-driver render callback streamed pages, allocated selection data or queued GPU work.");
                }
            }
            finally
            {
                GaussianSplatRenderSystem.ClearOverrideRenderTargetSize();
                GaussianSplatRenderSystem.ClearOverrideStereoVP();
                GaussianSplatRenderSystem.ClearOverrideMatrices();
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(driverOwner);
                UnityEngine.Object.DestroyImmediate(otherOwner);
                UnityEngine.Object.DestroyImmediate(scene);
                foreach (var existing in previousMainObjects)
                    if (existing != null) existing.tag = "MainCamera";
            }
        }

        static void ValidatePlayModeSortGating(bool usePlayModePath)
        {
            var owner = new GameObject("Paged selection-sort validation");
            owner.SetActive(false);
            var cameraOwner = new GameObject("Paged selection-sort camera");
            cameraOwner.SetActive(false);
            var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
            try
            {
                scene.Initialize(Vector3.zero, Vector3.one, 1, new[]
                {
                    new GaussianSplatPageEntry { pageId = 0, splatCount = 2 }
                });
                var renderer = owner.AddComponent<SplatBoxRenderer>();
                var camera = cameraOwner.AddComponent<Camera>();
                Set(renderer, "m_PagedScene", scene);
                Set(renderer, "m_ActiveSplatCount", 2);
                Set(renderer, "m_LodSelectionRevision", 4u);
                renderer.m_SortNthFrame = 4;
                renderer.m_ReuseSortAcrossEyes = false;
                renderer.m_StableSortWhileRotatingOnMobile = false;
                renderer.m_FrustumCullOnMobile = false;
                Call(renderer, "RecordSortContext", camera, Time.frameCount - 1);
                Require(!(bool)Call(renderer, "RequiresPagedLodDepthSort"),
                    "A recorded selection remained pending for depth sorting.");
                if (usePlayModePath)
                    Require(!(bool)Call(renderer, "ShouldSortThisFrame", camera),
                        "An unchanged selection ignored the configured skipped sort interval.");

                Call(renderer, "MarkLodSelectionChanged");
                // ResetLodSortKeys has already queued identity keys before ShouldSortThisFrame.
                Set(renderer, "m_LodSortKeysNeedReset", false);
                Require((bool)Call(renderer, "RequiresPagedLodDepthSort"),
                    "Publishing a new selection retained the previous selection's sort ownership.");
                if (usePlayModePath)
                {
                    Require((bool)Call(renderer, "ShouldSortThisFrame", camera),
                        "New LoD selection drew identity order on a skipped Play-mode sort frame.");
                    Require((bool)Call(renderer, "ShouldSortThisFrame", camera),
                        "A sort decision acknowledged the selection before sort commands were recorded.");
                }
                Call(renderer, "RecordSortContext", camera, Time.frameCount - 1);
                Require(!(bool)Call(renderer, "RequiresPagedLodDepthSort"),
                    "Successful sorting did not acknowledge the published selection.");
                if (usePlayModePath)
                {
                    Require(!(bool)Call(renderer, "ShouldSortThisFrame", camera),
                        "The new-selection guard disabled interval reuse after sorting.");
                    Require((bool)Call(renderer, "ShouldSortNormalFrame", camera, 4, Time.frameCount + 3),
                        "The normal sort interval stopped running after a selection was acknowledged.");

                    renderer.m_ReuseSortAcrossEyes = true;
                    Call(renderer, "MarkLodSelectionChanged");
                    Set(renderer, "m_LodSortKeysNeedReset", false);
                    Require((bool)Call(renderer, "ShouldSortThisFrame", camera),
                        "Second-eye sort reuse left a newly published selection in identity order.");
                    Call(renderer, "RecordSortContext", camera, Time.frameCount);
                    Require(!(bool)Call(renderer, "ShouldSortThisFrame", camera),
                        "Stereo pass reuse was lost after sorting the new selection.");
                }

                // Preserve the existing mobile stable-sort publication guard as well.
                Set(renderer, "m_LastSortFrame", -1);
                Call(renderer, "MarkLodSelectionChanged");
                Require((bool)Call(renderer, "ShouldRefreshMobileStableSort", camera, 4),
                    "Mobile stable sorting failed to sort a newly published selection.");
                Require(!(bool)Call(renderer, "ShouldRefreshMobileStableSort", camera, 4),
                    "Mobile stable sorting repeated its sort in the same stereo frame.");
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(owner);
                UnityEngine.Object.DestroyImmediate(cameraOwner);
                UnityEngine.Object.DestroyImmediate(scene);
            }
        }

        static bool DrainRenderer(SplatBoxRenderer renderer, SplatBoxLodSelectionWorker worker)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();
            bool applied = false;
            while (worker.isRunning && timer.Elapsed.TotalSeconds < 15)
            {
                applied |= (bool)Call(renderer, "TryApplyAsyncLodSelection", new object[] { null });
                if (worker.isRunning) Thread.Sleep(1);
            }
            Require(!worker.isRunning, "Background renderer validation timed out.");
            return applied;
        }

        static int Words(int count, int stride) => (count * stride + 3) / 4;
        static uint Pattern(int word) => 0x173a491du + (uint)word * 19733u;
        static GraphicsBuffer Source(int count, int stride)
        {
            var data = new uint[Words(count, stride)];
            for (int i = 0; i < data.Length; i++) data[i] = Pattern(i);
            var buffer = new GraphicsBuffer(GraphicsBuffer.Target.Raw, data.Length, 4);
            buffer.SetData(data);
            return buffer;
        }
        static GraphicsBuffer Destination(int count, int stride)
        {
            var buffer = new GraphicsBuffer(GraphicsBuffer.Target.Raw, Words(count, stride), 4);
            buffer.SetData(new uint[buffer.count]);
            return buffer;
        }
        static void CheckCopy(GraphicsBuffer buffer, int count, int offset, int stride, string path)
        {
            var data = new uint[buffer.count];
            buffer.GetData(data);
            int start = offset * stride / 4, words = Words(count, stride);
            for (int i = 0; i < data.Length; i++)
            {
                uint expected = i >= start && i < start + words ? Pattern(i - start) : 0;
                Require(data[i] == expected, $"Atlas copy mismatch: {path}, count={count}, stride={stride}, word={i}");
            }
        }
        static void Require(bool condition, string message)
        {
            if (!condition) throw new Exception(message);
        }
    }
}
