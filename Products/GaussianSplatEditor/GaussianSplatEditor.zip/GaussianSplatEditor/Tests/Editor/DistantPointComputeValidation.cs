using System;
using System.Runtime.InteropServices;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Tests
{
    /// <summary>Exercise the production view kernel, including atlas remapping and retained hide rules.</summary>
    public static class DistantPointComputeValidation
    {
        const int Count = 3;

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        struct View
        {
            public uint clipX, clipY, clipZ, clipW;
            public uint axis1, axis2, color1, color2;
            public uint worldX, worldY, worldZ, splatIndex;
        }

        [MenuItem("Tools/Gaussian Splatting/Validate Distant Point Compute")]
        public static void Run()
        {
            Require(SystemInfo.supportsComputeShaders, "Distant point compute validation needs a graphics device.");
            string root = UnityEditor.PackageManager.PackageInfo
                .FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath + "/";
            Validate(root + "Resources/BoxUtil.compute");
            Validate(root + "Shaders/BoxUtil.compute");
            Debug.Log("SplatBox distant point compute validation PASS: production view kernels preserve near and " +
                "threshold output exactly, skip only distant axes, retain colour/opacity/world position/index, " +
                "and respect deletion, cutouts and distance culling across both shader copies.");
        }

        static void Validate(string path)
        {
            var shader = AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
            Require(shader != null, "Missing production compute shader: " + path);
            int kernel = shader.FindKernel("CSCalcViewData");
            Require(shader.IsSupported(kernel), "Unsupported production view kernel: " + path);
            using var positions = new GraphicsBuffer(GraphicsBuffer.Target.Raw, Count * 3, 4);
            using var other = new GraphicsBuffer(GraphicsBuffer.Target.Raw, Count * 4, 4);
            using var sh = new GraphicsBuffer(GraphicsBuffer.Target.Raw, Count * 48, 4);
            using var chunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1, 64);
            using var remap = new GraphicsBuffer(GraphicsBuffer.Target.Structured, Count, 4);
            using var order = new GraphicsBuffer(GraphicsBuffer.Target.Structured, Count, 4);
            using var selected = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4);
            using var deleted = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4);
            using var cutouts = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                Marshal.SizeOf<GaussianCutout.ShaderData>());
            using var drawArgs = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 5, 4);
            using var output = new GraphicsBuffer(GraphicsBuffer.Target.Structured, Count, Marshal.SizeOf<View>());
            var color = new Texture2D(16, 16, TextureFormat.RGBAFloat, false, true);
            try
            {
                // Physical source positions become logical indices [far, near, boundary], then
                // the draw order restores [near, boundary, far]. Neither indirection is identity.
                positions.SetData(new float[] { 0, 0, 2, 0, 0, 4, 0, 0, 6 });
                var otherData = new uint[Count * 4];
                var shData = new float[Count * 48];
                for (int i = 0; i < Count; i++)
                {
                    otherData[i * 4] = 0xE0080200u; // Packed identity quaternion, largest component W.
                    otherData[i * 4 + 1] = math.asuint(0.1f);
                    otherData[i * 4 + 2] = math.asuint(0.15f);
                    otherData[i * 4 + 3] = math.asuint(0.2f);
                    // The second coefficient uses view Z and changes this fixture's colour;
                    // dropping SH on the point branch would therefore fail colour parity.
                    shData[i * 48 + 3] = 0.1f;
                    shData[i * 48 + 4] = 0.05f;
                    shData[i * 48 + 5] = -0.02f;
                }
                other.SetData(otherData);
                sh.SetData(shData);
                chunks.SetData(new GaussianSplatAsset.ChunkInfo[1]);
                remap.SetData(new uint[] { 2, 0, 1 });
                order.SetData(new uint[] { 1, 2, 0 });
                selected.SetData(new uint[1]);
                deleted.SetData(new uint[1]);
                cutouts.SetData(new GaussianCutout.ShaderData[1]);
                drawArgs.SetData(new uint[] { 6, Count, 0, 0, 0 });
                var pixels = new Color[16 * 16];
                for (int i = 0; i < pixels.Length; i++) pixels[i] = new Color(0.6f, 0.5f, 0.4f, 0.7f);
                color.SetPixels(pixels);
                color.Apply();

                shader.SetBuffer(kernel, "_SplatPos", positions);
                shader.SetBuffer(kernel, "_SplatOther", other);
                shader.SetBuffer(kernel, "_SplatSH", sh);
                shader.SetBuffer(kernel, "_SplatChunks", chunks);
                shader.SetBuffer(kernel, "_SplatIndexRemap", remap);
                shader.SetBuffer(kernel, "_OrderBuffer", order);
                shader.SetBuffer(kernel, "_SplatSelectedBits", selected);
                shader.SetBuffer(kernel, "_SplatDeletedBits", deleted);
                shader.SetBuffer(kernel, "_SplatCutouts", cutouts);
                shader.SetBuffer(kernel, "_DrawArgs", drawArgs);
                shader.SetBuffer(kernel, "_SplatViewData", output);
                shader.SetTexture(kernel, "_SplatColor", color);
                shader.SetInt("_SplatCount", Count);
                shader.SetInt("_SplatFormat", 0); // Float32 position, scale and SH.
                shader.SetInt("_SplatChunkCount", 0);
                shader.SetInt("_UseSplatIndexRemap", 1);
                shader.SetInt("_SplatSHDataValid", 1);
                shader.SetInt("_SHOrder", 3);
                shader.SetInt("_SHOnly", 0);
                shader.SetInt("_VisibleLimitValid", 0);
                shader.SetInt("_DrawInstanceMultiplier", 1);
                shader.SetFloat("_SplatScale", 1);
                shader.SetFloat("_SplatOpacityScale", 0.8f);
                shader.SetFloat("_LodDetailDistance", 4);
                shader.SetFloat("_KillRadius", 5);

                // A translated object proves that classification uses world units. Distinct eye
                // origins put the boundary node beyond four metres from either eye, while it
                // remains exactly at the shared head-centre threshold and must stay Gaussian.
                var head = new Vector3(10, 2, 3);
                var objectToWorld = Matrix4x4.Translate(head);
                var view = Matrix4x4.Scale(new Vector3(1, 1, -1)) * objectToWorld.inverse;
                var projection = Matrix4x4.Perspective(60, 4f / 3f, 0.1f, 100);
                shader.SetMatrix("_MatrixObjectToWorld", objectToWorld);
                shader.SetMatrix("_MatrixWorldToObject", objectToWorld.inverse);
                shader.SetMatrix("_MatrixVP", projection * view);
                shader.SetMatrix("_MatrixMV", view * objectToWorld);
                shader.SetMatrix("_MatrixP", projection);
                shader.SetVector("_VecScreenParams", new Vector4(640, 480, 1f / 640, 1f / 480));
                shader.SetVector("_LodCameraWorldPos", head);
                shader.SetVector("_CullOrigin", head);

                foreach (int albedoOnly in new[] { 0, 1 })
                foreach (float eyeOffset in new[] { -0.032f, 0.032f })
                {
                    shader.SetInt("_AlbedoOnly", albedoOnly);
                    shader.SetVector("_VecWorldSpaceCameraPos", head + Vector3.right * eyeOffset);
                    ResetHideRules(shader);
                    var baseline = Dispatch(shader, kernel, output, false);
                    var points = Dispatch(shader, kernel, output, true);
                    for (int i = 0; i < Count; i++)
                    {
                        Require(baseline[i].clipW != 0 && (baseline[i].axis1 != 0 || baseline[i].axis2 != 0) &&
                            baseline[i].color2 != 0, "Invalid baseline view fixture in " + path);
                        uint expectedIndex = i == 0 ? 1u : i == 1 ? 2u : 0u;
                        Require(baseline[i].splatIndex == expectedIndex &&
                            baseline[i].worldX == math.asuint(10f) && baseline[i].worldY == math.asuint(2f) &&
                            baseline[i].worldZ == math.asuint(5f + i * 2f),
                            "View remapping/world-transform fixture failed in " + path);
                        var expected = baseline[i];
                        if (i == 2) expected.axis1 = expected.axis2 = 0;
                        Require(expected.Equals(points[i]), "Point mode changed more than distant axes, or " +
                            "changed the shared-eye boundary/near output in " + path + ", slot " + i);
                    }
                    RequireEqual(baseline, Dispatch(shader, kernel, output, false), path + " after disabling points");
                }

                // The distant sample must still obey each production hide path.
                ResetHideRules(shader);
                shader.SetInt("_SplatBitsValid", 1);
                deleted.SetData(new uint[] { 1 }); // Far logical index 0.
                ValidateHiddenFar(shader, kernel, output, path + " deletion");
                deleted.SetData(new uint[1]);
                ResetHideRules(shader);
                cutouts.SetData(new[] { new GaussianCutout.ShaderData
                {
                    matrix = Matrix4x4.Translate(new Vector3(0, 0, -6)), typeAndFlags = 1
                } });
                shader.SetInt("_SplatCutoutsCount", 1);
                ValidateHiddenFar(shader, kernel, output, path + " cutout");
                ResetHideRules(shader);
                shader.SetInt("_EnableDistanceCulling", 1);
                ValidateHiddenFar(shader, kernel, output, path + " distance cull");
            }
            finally
            {
                shader.SetInt("_LodDistantPointCloud", 0);
                ResetHideRules(shader);
                UnityEngine.Object.DestroyImmediate(color);
            }
        }

        static View[] Dispatch(ComputeShader shader, int kernel, GraphicsBuffer output, bool points)
        {
            output.SetData(new View[Count]);
            shader.SetInt("_LodDistantPointCloud", points ? 1 : 0);
            shader.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            shader.Dispatch(kernel, (Count + (int)groupSize - 1) / (int)groupSize, 1, 1);
            var result = new View[Count];
            output.GetData(result);
            return result;
        }

        static void ValidateHiddenFar(ComputeShader shader, int kernel, GraphicsBuffer output, string label)
        {
            var baseline = Dispatch(shader, kernel, output, false);
            var points = Dispatch(shader, kernel, output, true);
            Require(baseline[0].clipW != 0 && baseline[1].clipW != 0 && baseline[2].clipW == 0,
                "Hide fixture did not isolate the distant sample: " + label);
            RequireEqual(baseline, points, label);
        }

        static void ResetHideRules(ComputeShader shader)
        {
            shader.SetInt("_SplatBitsValid", 0);
            shader.SetInt("_SplatCutoutsCount", 0);
            shader.SetInt("_EnableDistanceCulling", 0);
            shader.SetInt("_VisibleLimitValid", 0);
        }

        static void RequireEqual(View[] expected, View[] actual, string label)
        {
            for (int i = 0; i < expected.Length; i++)
                Require(expected[i].Equals(actual[i]), "View data changed in " + label + ", slot " + i);
        }

        static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException(message);
        }
    }
}
