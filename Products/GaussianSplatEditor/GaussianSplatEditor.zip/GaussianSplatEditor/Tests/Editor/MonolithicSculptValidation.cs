// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Tests
{
    public static class MonolithicSculptValidation
    {
        const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const int Count = 128;
        static T Get<T>(object o, string field) => (T)o.GetType().GetField(field, Flags).GetValue(o);
        static void Set(object o, string field, object value) => o.GetType().GetField(field, Flags).SetValue(o, value);
        static object Call(object o, string method, params object[] args) => o.GetType().GetMethod(method, Flags).Invoke(o, args);
        static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
        static void Near(Vector3 actual, Vector3 expected, string message) => Require(Vector3.Distance(actual, expected) < .001f,
            message + ": " + actual.ToString("G9") + " != " + expected.ToString("G9"));
        static string Root => UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(SplatBoxRenderer).Assembly).assetPath;

        static byte[] Pack(Vector3[] positions, GaussianSplatAsset.VectorFormat format)
        {
            using var stream = new MemoryStream(); using var writer = new BinaryWriter(stream);
            foreach (var point in positions)
            {
                Vector3 p = (point - new Vector3(-1, -1, 2)) * .5f;
                uint Q(float v, int maximum) => (uint)Mathf.RoundToInt(v * maximum);
                if (format == GaussianSplatAsset.VectorFormat.Float32) { writer.Write(p.x); writer.Write(p.y); writer.Write(p.z); }
                else if (format == GaussianSplatAsset.VectorFormat.Norm16)
                { writer.Write((ushort)Q(p.x, 65535)); writer.Write((ushort)Q(p.y, 65535)); writer.Write((ushort)Q(p.z, 65535)); }
                else if (format == GaussianSplatAsset.VectorFormat.Norm11)
                    writer.Write(Q(p.x, 2047) | Q(p.y, 1023) << 11 | Q(p.z, 2047) << 21);
                else writer.Write((ushort)(Q(p.x, 63) | Q(p.y, 31) << 6 | Q(p.z, 31) << 11));
            }
            return stream.ToArray();
        }

        sealed class Fixture : IDisposable
        {
            public readonly object inner;
            public readonly SplatBoxRenderer renderer;
            public readonly Camera camera;
            public readonly Vector3[] baseline;
            public readonly uint[] source;
            public Fixture(string shader, GaussianSplatAsset.VectorFormat format)
            {
                var type = typeof(PagedLodEditingValidation).GetNestedType("Fixture", BindingFlags.NonPublic);
                inner = Activator.CreateInstance(type, Flags, null, new object[] { shader, false }, null);
                renderer = Get<SplatBoxRenderer>(inner, "renderer"); camera = Get<Camera>(inner, "camera");
                renderer.transform.position = Vector3.zero;
                var asset = Get<GaussianSplatAsset>(inner, "asset"); var data = Get<TextAsset>(inner, "data");
                asset.Initialize(Count, format, GaussianSplatAsset.VectorFormat.Float32, GaussianSplatAsset.ColorFormat.Float32x4,
                    GaussianSplatAsset.SHFormat.Float32, new Vector3(-1,-1,2), new Vector3(1,1,4), null);
                asset.SetAssetFiles(data, data, data, data, data);
                var positions = new Vector3[Count];
                for (int i = 0; i < Count; i++) positions[i] = new Vector3(.8f,.8f,3.9f);
                positions[32] = new Vector3(0,0,3); positions[33] = new Vector3(.2f,.2f,3); positions[34] = new Vector3(.4f,.2f,3);
                Get<GraphicsBuffer>(inner, "pos").SetData(Pack(positions, format));
                Get<GraphicsBuffer>(inner, "chunks").SetData(new[] { new GaussianSplatAsset.ChunkInfo {
                    posX = new float2(-1,1), posY = new float2(-1,1), posZ = new float2(2,4),
                    colR = 0x3c000000, colG = 0x3c000000, colB = 0x3c000000, colA = 0x3c000000 } });
                Set(renderer, "m_GpuChunksValid", true);
                baseline = Positions(); source = new uint[384]; Get<GraphicsBuffer>(inner, "pos").GetData(source);
                Require(renderer.SupportsSculpt && renderer.UsesSculptJournal && !renderer.SupportsInPlacePaint,
                    "Packed model was not admitted to sculpting");
            }
            public Vector3[] Positions()
            {
                var views = (Array)Call(inner, "Views"); var result = new Vector3[Count];
                for (int i = 0; i < Count; i++) result[i] = Get<Vector3>(views.GetValue(i), "world");
                return result;
            }
            public void Expect(Vector3 point, string message)
            { var p = Positions(); Near(p[33], point, message); Near(p[0], baseline[0], message + " outside radius"); }
            public void Stroke(Action action) { renderer.BeginSculptStroke(); action(); renderer.EndSculptStroke(); }
            public void Replay() { Call(renderer, "DisposeMonolithicSculptBuffers"); Call(renderer, "EnsureMonolithicSculptState", new object[] { null }); }
            public void Dispose() => ((IDisposable)inner).Dispose();
        }

        static void Brushes(string shader, GaussianSplatAsset.VectorFormat format)
        {
            using var f = new Fixture(shader, format);
            var r = f.renderer; Vector3 original = f.baseline[33]; Vector3 right = new Vector3(.08f,0,0);
            f.Stroke(() => { r.SmudgeSplatsGPU(original, right, .07f, 0, 1); r.SmudgeSplatsGPU(original + right, right, .07f, 0, 1); });
            f.Expect(original + right * 2, "Smudge/Move");
            Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); f.Expect(original, "Whole-drag Undo");
            Undo.PerformRedo(); f.Expect(original + right * 2, "Whole-drag Redo");
            f.Replay(); f.Expect(original + right * 2, "Buffer recreation");
            r.ResetSculpt(); f.Expect(original, "Reset");
            for (int falloff = 0; falloff <= 2; falloff++)
            {
                float value = falloff * .5f;
                Vector3 center = original + new Vector3(.1f, .05f, 0);
                float d = Vector3.Distance(original, center) / .2f;
                float weight = value == 0 ? 1 : value == .5f ? 1 - d : 1 - Mathf.Pow(d, 1 / value);
                f.Stroke(() => r.PinchSplatsGPU(center, .2f, value, .5f));
                Vector3 pinched = original + (center - original) * weight * .5f;
                f.Expect(pinched, "Pinch falloff");
                f.Stroke(() => r.FlattenSplatsGPU(pinched + Vector3.up * .1f, Vector3.up * 3, .2f, 0, .5f));
                Vector3 flat = pinched + Vector3.up * .05f;
                f.Expect(flat, "Flatten after Pinch");
                f.Stroke(() => r.RestorePositionsInSphereGPU(flat, .05f, 0, .5f));
                Vector3 partial = Vector3.Lerp(flat, original, .5f); f.Expect(partial, "Partial restore");
                f.Stroke(() => r.RestorePositionsInSphereGPU(partial, .05f, 0, 2)); f.Expect(original, "ALT full restore");
                f.Replay(); f.Expect(original, "Mixed-stroke replay"); r.ResetSculpt();
            }
            Vector3 neighbor = f.baseline[34], middle = (neighbor + original) * .5f;
            f.Stroke(() => r.RelaxSplatsGPU(middle, .3f, 0, .5f, 1));
            f.Expect(original + (neighbor - original) / 6, "Relax captured neighbors");
            f.Replay(); f.Expect(original + (neighbor - original) / 6, "Relax replay");
            r.ResetSculpt();
            f.Stroke(() => r.RelaxSplatsGPU(middle, .3f, 0, .5f, 1, true));
            f.Expect(original - (neighbor - original) / 6, "SHIFT Roughen");
            f.Replay(); f.Expect(original - (neighbor - original) / 6, "Roughen replay");
            r.ResetSculpt();
            f.Stroke(() => r.SmudgeSplatsGPU(original, Vector3.forward, .07f, 0, 1));
            Vector3 shifted = original + Vector3.forward; f.Expect(shifted, "Visible deformation");
            Vector3 pixel = f.camera.WorldToScreenPoint(shifted);
            Require(r.TryGetPaintSurfaceDepth(f.camera, pixel, 3, out float depth) && Mathf.Abs(depth - shifted.z) < .01f,
                "Brush surface picking ignored sculpted positions");

            // Physics must add motion to the sculpted baseline, not add the sculpt twice each tick.
            r.enableWind = true; r.windGravity = r.windDamping = r.windMinVelocity = 0;
            var velocities = new Vector3[Count]; velocities[33] = Vector3.right;
            Get<GraphicsBuffer>(r, "m_GpuSplatVelocities").SetData(velocities);
            Call(r, "UpdatePhysicsInternal"); f.Expect(shifted + Vector3.right * .016f, "Sculpt plus motion");
            Call(r, "UpdatePhysicsInternal"); f.Expect(shifted + Vector3.right * .032f, "No doubled sculpt offset");
            var bytes = new uint[384]; Get<GraphicsBuffer>(f.inner, "pos").GetData(bytes);
            for (int i = 0; i < bytes.Length; i++) Require(bytes[i] == f.source[i], "Sculpt modified compressed source bytes");
        }

        static void ViewDirections(string shader)
        {
            using var f = new Fixture(shader, GaussianSplatAsset.VectorFormat.Norm11);
            var window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            var radiusMethod = typeof(GaussianSplatEditorWindow).GetMethod("SculptWorldRadius", BindingFlags.Static | BindingFlags.NonPublic);
            var deltaMethod = typeof(GaussianSplatEditorWindow).GetMethod("SculptDragDelta", BindingFlags.Static | BindingFlags.NonPublic);
            var depthDeltaMethod = typeof(GaussianSplatEditorWindow).GetMethod("SculptDepthDragDelta", BindingFlags.Static | BindingFlags.NonPublic);
            var target = f.renderer.transform; var camera = f.camera;
            camera.nearClipPlane = .0001f; camera.farClipPlane = 1000;
            Set(window, "m_TargetRenderer", f.renderer);
            double time = 1;
            try
            {
                foreach (bool ortho in new[] { false, true })
                foreach (float scale in new[] { .01f, 1f })
                foreach (float distance in new[] { 2f, 8f })
                foreach (Vector3 direction in new[] { Vector3.forward, Vector3.back, Vector3.left, Vector3.right, Vector3.up, Vector3.down })
                {
                    void NearView(Vector3 actual, Vector3 expected, string message) =>
                        Require(Vector3.Distance(actual,expected) < scale * .001f,
                            message + $": {actual.ToString("F7")} vs {expected.ToString("F7")}; direction={direction}, ortho={ortho}, scale={scale}, distance={distance}");
                    f.renderer.ResetSculpt();
                    target.SetPositionAndRotation(new Vector3(2,-1,4) * scale, Quaternion.Euler(23,37,-11)); target.localScale = Vector3.one * scale;
                    Vector3 localCenter = new Vector3(.2f,.2f,3);
                    Vector3 forward = target.rotation * direction;
                    Vector3 up = target.rotation * (Mathf.Abs(direction.y) > .9f ? Vector3.forward : Vector3.up);
                    camera.transform.SetPositionAndRotation(target.TransformPoint(localCenter) - forward * distance * scale, Quaternion.LookRotation(forward,up));
                    camera.orthographic = ortho; camera.orthographicSize = scale;
                    camera.nearClipPlane = .01f * scale; camera.farClipPlane = distance * scale * 10;
                    float foregroundDepth = (distance - .35f) * scale;
                    float foregroundPixelScale = ortho ? 2f * camera.orthographicSize / camera.pixelHeight
                        : 2f * foregroundDepth * Mathf.Tan(camera.fieldOfView * Mathf.Deg2Rad * .5f) / camera.pixelHeight;
                    var points = new Vector3[Count];
                    for (int i=0;i<Count;i++) points[i] = new Vector3(.8f,-.8f,3.9f);
                    points[33] = localCenter;
                    points[34] = target.InverseTransformPoint(target.TransformPoint(localCenter) - forward * .35f * scale + camera.transform.right * foregroundPixelScale * 8f);
                    Get<GraphicsBuffer>(f.inner,"pos").SetData(Pack(points,GaussianSplatAsset.VectorFormat.Norm11));
                    Vector3 original = f.Positions()[33];
                    Vector3 pixel = camera.WorldToViewportPoint(original);
                    Ray ray = camera.ViewportPointToRay(pixel);
                    object[] pick = { camera, ray, time++, false, false, false, Vector3.zero };
                    Require((bool)Call(window,"TryGetSculptHitPoint",pick), "No surface from " + direction + ", ortho=" + ortho);
                    Vector3 hit = (Vector3)pick[6]; NearView(hit,original,"Picked foreground beside the cursor");
                    Vector3 foreground = f.Positions()[34];
                    Ray foregroundRay = camera.ViewportPointToRay(camera.WorldToViewportPoint(foreground));
                    pick = new object[] { camera,foregroundRay,time+.5,false,true,true,Vector3.zero };
                    Require((bool)Call(window,"TryGetSculptHitPoint",pick),"Move lost its drag plane");
                    Require(Mathf.Abs(Vector3.Dot((Vector3)pick[6]-hit,forward))<scale*.001f,
                        "Move jumped onto foreground depth during a drag");
                    float radius = (float)radiusMethod.Invoke(null,new object[]{hit,camera,20f});
                    Vector3 edge = camera.WorldToViewportPoint(hit + camera.transform.up * radius);
                    float pixelRadius = (edge.y-camera.WorldToViewportPoint(hit).y)*camera.pixelHeight;
                    Require(Mathf.Abs(pixelRadius-20f)<.02f,$"Brush size changed with depth/view projection: {pixelRadius}; ortho={ortho}");
                    Vector3 offAxis = hit + camera.transform.right * distance * scale * .2f;
                    float offRadius = (float)radiusMethod.Invoke(null,new object[]{offAxis,camera,20f});
                    Require(Mathf.Abs(radius-offRadius)<.0001f,"Off-axis brush inflated with ray distance");

                    Vector3 endpoint = hit + camera.transform.right * radius * .15f + camera.transform.up * radius * .1f;
                    Vector3 delta = (Vector3)deltaMethod.Invoke(null,new object[]{ray,endpoint,forward});
                    NearView(delta,endpoint-hit,"Drag lost a camera-plane direction");
                    Require(Mathf.Abs(Vector3.Dot(delta,forward))<.00001f,"Drag added unintended depth");
                    // Changing surface depth with a stationary cursor must not move geometry.
                    var deeperPlane = new Plane(forward,hit + forward * .2f * scale);
                    Require(deeperPlane.Raycast(ray,out float rayDistance),"Depth plane missed ray");
                    Vector3 depthDelta = (Vector3)deltaMethod.Invoke(null,new object[]{ray,ray.GetPoint(rayDistance),forward});
                    NearView(depthDelta,Vector3.zero,"Surface refresh introduced motion");
                    Set(window,"m_MoveStrength",1f); Set(window,"m_MoveFalloff",0f);
                    f.Stroke(()=>Call(window,"ExecuteMoveOptimized",hit,delta,radius));
                    NearView(f.Positions()[33],original+delta,"Move failed from " + direction + ", ortho=" + ortho);
                    f.renderer.ResetSculpt();
                    Set(window,"m_MoveDepthDrag",true); Set(window,"m_MoveDepthCenter",hit);
                    Set(window,"m_MoveDepthAxis",forward); Set(window,"m_MoveDepthRadius",radius);
                    Set(window,"m_MoveStrength",.5f);
                    Vector3 push = (Vector3)depthDeltaMethod.Invoke(null,new object[]{-10f,forward,radius/20f});
                    NearView(push,forward*radius*.5f,"Up did not push along view depth");
                    f.Stroke(() =>
                    {
                        // Travel farther than the original footprint, then reverse. The
                        // brush must follow the actual weighted displacement each time.
                        for (int step=0;step<8;step++)
                        {
                            Set(window,"m_SmudgeAccumulatedDelta",push);
                            Call(window,"FlushMoveBrush",hit+camera.transform.right*radius*20,radius*4);
                            NearView(f.Positions()[33],original+push*.5f*(step+1),"Repeated depth push lost its splats");
                        }
                        for (int step=0;step<8;step++)
                        {
                            Set(window,"m_SmudgeAccumulatedDelta",-push);
                            Call(window,"FlushMoveBrush",hit+camera.transform.up*radius*20,radius*4);
                        }
                    });
                    NearView(f.Positions()[33],original,"Pull did not reverse the depth push");
                    Set(window,"m_MoveDepthDrag",false); f.renderer.ResetSculpt();
                    Set(window,"m_PinchStrength",.5f); Set(window,"m_PinchFalloff",0f);
                    f.Stroke(()=>Call(window,"ExecutePinchOptimized",hit+forward*radius*.2f,radius));
                    NearView(f.Positions()[33],original+forward*radius*.1f,"Pinch lost depth direction");
                    f.renderer.ResetSculpt();
                    Set(window,"m_FlattenStrength",.5f); Set(window,"m_FlattenFalloff",0f);
                    f.Stroke(()=>Call(window,"ExecuteFlattenOptimized",hit+forward*radius*.2f,forward,radius));
                    NearView(f.Positions()[33],original+forward*radius*.1f,"Flatten lost depth direction");

                    // MouseDown must bypass a recent hover result after sculpting changes depth.
                    Vector3 current = f.Positions()[33]; ray = camera.ViewportPointToRay(camera.WorldToViewportPoint(current));
                    pick = new object[] { camera,ray,time-.999,true,false,false,Vector3.zero };
                    Require((bool)Call(window,"TryGetSculptHitPoint",pick),"Fresh stroke lost deformed surface");
                    NearView((Vector3)pick[6],current,"New stroke reused stale hover depth");
                    // A miss at the next stroke must not reuse the last model surface.
                    pick = new object[] { camera,camera.ViewportPointToRay(new Vector3(.01f,.99f)),time++,true,false,false,Vector3.zero };
                    Require(!(bool)Call(window,"TryGetSculptHitPoint",pick),"Miss reused a previous surface");
                }
            }
            finally { Object.DestroyImmediate(window); }
            Debug.Log("SplatBox Sculpt view directions PASS: six directions, rotated models, small scale, near/far depths, perspective/orthographic radius, cursor-local picking, Move/Pinch/Flatten and fresh-stroke depth.");
        }

        static void DepthMoveSceneEvents(SplatBoxRenderer renderer, Func<Vector3> position, bool ortho)
        {
            var window = ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            var scene = ScriptableObject.CreateInstance<SceneView>();
            Action<SceneView> callback = null;
            try
            {
                Vector3 original = position();
                Set(window,"m_TargetRenderer",renderer); Set(window,"m_SculptBrushTab",2);
                Set(window,"m_MoveStrength",.5f); Set(window,"m_MoveFalloff",0f);
                scene.position = new Rect(100,100,640,480); scene.ShowUtility();
                scene.LookAt(original,Quaternion.identity,3,ortho,true);
                bool prepared = false; int stage = 0, handled = 0; Exception failure = null;
                Vector2 cursor = Vector2.zero, offset = Vector2.zero;
                Vector3 forward = Vector3.zero; float worldPerPoint = 0;
                callback = view =>
                {
                    if (view != scene || failure != null) return;
                    try
                    {
                        if (!prepared && Event.current.type == EventType.Repaint)
                        { prepared=true; cursor=HandleUtility.WorldToGUIPoint(original); forward=view.camera.transform.forward; return; }
                        if (!prepared || stage <= handled || (Event.current.rawType != EventType.MouseDown &&
                            Event.current.rawType != EventType.MouseDrag && Event.current.rawType != EventType.MouseUp)) return;
                        handled=stage;
                        // Use scene-local coordinates inside the callback, independent of
                        // the host window's toolbar offset and monitor DPI.
                        Event.current.mousePosition=cursor+offset;
                        Call(window,"HandleSculptBrushScene",view,Event.current);
                        if(stage==1 || stage==8)
                        {
                            Require(Get<bool>(window,"m_IsMoving") && Get<bool>(window,"m_MoveDepthDrag"),
                                stage==1 ? "CTRL did not start depth Move" : "Depth option required CTRL");
                            worldPerPoint=Get<float>(window,"m_MoveDepthWorldPerPoint");
                        }
                        else if(stage==2) Near(position(),original+forward*worldPerPoint*20,"Depth drag moved sideways or ignored Strength");
                        else if(stage==3 || stage==4)
                        {
                            Require(Get<bool>(window,"m_MoveDepthDrag"),"CTRL release changed an active depth gesture");
                            Near(position(),original+forward*worldPerPoint*40,"Depth gesture lost its center or accepted horizontal motion");
                        }
                        else if(stage==5 || stage==6) Near(position(),original,"Pull did not return to start, or pending drag executed before throttle");
                        else if(stage==7)
                        {
                            Near(position(),original+forward*worldPerPoint*5,"MouseUp lost pending depth movement");
                            Require(!Get<bool>(window,"m_IsMoving") && !Get<bool>(window,"m_MoveDepthDrag"),"MouseUp retained depth mode");
                        }
                        else if(stage==9)
                            Near(position(),original+forward*worldPerPoint*15,"Depth option did not push without CTRL");
                        else if(stage==10)
                            Require(Get<bool>(window,"m_IsRestoringSculpt") && !Get<bool>(window,"m_IsMoving"),"ALT did not override depth Move");
                    }
                    catch(Exception error) { failure=error; }
                };
                SceneView.duringSceneGui+=callback;
                scene.SendEvent(new Event {type=EventType.Layout}); scene.SendEvent(new Event {type=EventType.Repaint});
                Require(prepared,"Depth Move fixture did not enter Scene GUI");
                void Send(int step, EventType type, Vector2 at, EventModifiers modifiers=EventModifiers.None, bool throttle=false)
                {
                    stage=step; offset=at;
                    Set(window,"m_SmudgeLastExecuteTime",throttle ? EditorApplication.timeSinceStartup+100 : -100d);
                    scene.SendEvent(new Event {type=type,button=0,mousePosition=cursor+at,modifiers=modifiers});
                    if(failure!=null) throw failure;
                    Require(handled==stage,"Depth Move event did not reach Scene GUI: "+stage);
                }
                scene.SendEvent(new Event {type=EventType.MouseEnterWindow,mousePosition=cursor});
                Send(1,EventType.MouseDown,Vector2.zero,EventModifiers.Control);
                Send(2,EventType.MouseDrag,new Vector2(25,-40),EventModifiers.Control | EventModifiers.Shift);
                Send(3,EventType.MouseDrag,new Vector2(75,-80));
                Send(4,EventType.MouseDrag,new Vector2(125,-80));
                Send(5,EventType.MouseDrag,new Vector2(125,0));
                Send(6,EventType.MouseDrag,new Vector2(125,-10),throttle:true);
                Send(7,EventType.MouseUp,new Vector2(125,-10));
                Vector3 completed=position(); Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                Near(position(),original,"Depth stroke did not Undo as one gesture");
                Undo.PerformRedo(); Near(position(),completed,"Depth stroke Redo failed");
                Set(window,"m_MoveDepthMode",true);
                Send(8,EventType.MouseDown,Vector2.zero);
                Send(9,EventType.MouseDrag,new Vector2(0,-20));
                Send(10,EventType.MouseDrag,Vector2.zero,EventModifiers.Alt);
                Send(11,EventType.MouseUp,Vector2.zero,EventModifiers.Alt);
                Call(window,"FinishPagedSmudgeStroke");
            }
            finally
            {
                if(callback!=null) SceneView.duringSceneGui-=callback;
                scene.Close(); Object.DestroyImmediate(window);
            }
        }

        public static void RunMoveDepth()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders,"Use an isolated batch project with graphics");
            var errors=new List<string>(); Application.LogCallback observe=(message,stack,type)=>
            { if(type==LogType.Error || type==LogType.Exception || type==LogType.Assert) errors.Add(message); };
            Application.logMessageReceived+=observe;
            try
            {
                foreach(string shader in new[]{"Resources/BoxUtil.compute","Shaders/BoxUtil.compute"}) ViewDirections(shader);
                foreach(bool ortho in new[]{false,true})
                {
                    using(var mono=new Fixture("Resources/BoxUtil.compute",GaussianSplatAsset.VectorFormat.Norm11))
                        DepthMoveSceneEvents(mono.renderer,()=>mono.Positions()[33],ortho);
                    var type=typeof(PagedSculptValidation).GetNestedType("Fixture",BindingFlags.NonPublic);
                    using(var paged=(IDisposable)Activator.CreateInstance(type,Flags,null,new object[]{"Resources/BoxUtil.compute"},null))
                        DepthMoveSceneEvents(Get<SplatBoxRenderer>(paged,"renderer"),()=> (Vector3)Call(paged,"Position",33),ortho);
                }
                typeof(PagedSculptValidation).GetMethod("SceneEventRouting",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,null);
                Require(errors.Count==0,"Depth Move errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox Depth Move PASS: Screen/Depth option, CTRL gesture, push/pull on six view directions, perspective/orthographic, tracked brush center and Strength, horizontal rejection, CTRL/SHIFT/ALT, pending MouseUp, Undo/Redo on compressed monolithic and paged models.");
            }
            finally { Application.logMessageReceived-=observe; }
        }

        static void ResetAllTools(SplatBoxRenderer renderer, Func<Vector3[]> positions, Action replay)
        {
            var window=ScriptableObject.CreateInstance<GaussianSplatEditorWindow>();
            try
            {
                Set(window,"m_TargetRenderer",renderer);
                Vector3[] original=positions(); Vector3 center=original[0];
                Require(!renderer.HasSculptEdits,"New model reported sculpt edits");
                renderer.BeginSculptStroke();
                renderer.SmudgeSplatsGPU(center,Vector3.right*.2f,1,0,.5f);
                renderer.PinchSplatsGPU(center+Vector3.forward*.2f,1,.3f,.3f);
                renderer.FlattenSplatsGPU(center+Vector3.up*.2f,Vector3.up,1,0,.5f);
                renderer.RelaxSplatsGPU(center,1,0,.2f,.5f);
                renderer.RelaxSplatsGPU(center,1,0,.2f,.5f,true);
                renderer.SmudgeSplatsGPU(center,Vector3.forward*.3f,1,.4f,.75f);
                renderer.EndSculptStroke();
                Vector3[] edited=positions();
                Require(renderer.HasSculptEdits && Vector3.Distance(edited[0],original[0])>.001f,"Mixed sculpt fixture did not deform");
                void Expect(Vector3[] expected,string reason)
                {
                    var actual=positions();
                    for(int i=0;i<expected.Length;i++) Near(actual[i],expected[i],reason+" splat "+i);
                }
                // Reset while a depth drag still has pending movement. Releasing the
                // mouse later must not recreate the cleared deformation.
                renderer.BeginSculptStroke(); Set(window,"m_PagedSmudgeStrokeRenderer",renderer);
                Set(window,"m_IsMoving",true); Set(window,"m_MoveDepthDrag",true);
                Set(window,"m_SmudgeAccumulatedDelta",Vector3.one*100); Set(window,"m_SmudgeHasCachedSurface",true);
                Set(window,"m_MoveRadius",3.5f); Set(window,"m_MoveStrength",.45f);
                Call(window,"ResetAllSculptingForTarget");
                Require(!renderer.HasSculptEdits && !Get<bool>(window,"m_IsMoving") && !Get<bool>(window,"m_MoveDepthDrag") &&
                    !Get<bool>(window,"m_SmudgeHasCachedSurface") && Get<Vector3>(window,"m_SmudgeAccumulatedDelta")==Vector3.zero &&
                    Get<SplatBoxRenderer>(window,"m_PagedSmudgeStrokeRenderer")==null,"Reset left an active stroke or stale preview");
                Require(Get<float>(window,"m_MoveRadius")==3.5f && Get<float>(window,"m_MoveStrength")==.45f,
                    "Reset geometry changed the brush settings");
                Expect(original,"Reset did not restore the original shape");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                Require(renderer.HasSculptEdits,"Undo did not restore sculpt history"); Expect(edited,"Undo reset");
                Undo.PerformRedo(); Require(!renderer.HasSculptEdits,"Redo did not clear sculpt history"); Expect(original,"Redo reset");
                replay(); Expect(original,"GPU recreation revived cleared sculpting");
                int group=Undo.GetCurrentGroup(); Call(window,"ResetAllSculptingForTarget");
                Require(Undo.GetCurrentGroup()==group,"An empty reset created an Undo operation");
                renderer.BeginSculptStroke(); renderer.SmudgeSplatsGPU(center,Vector3.up*.05f,.2f,0,1); renderer.EndSculptStroke();
                var next=positions(); Call(window,"ResetAllSculptingForTarget"); Expect(original,"Reset after a new stroke");
                Undo.FlushUndoRecordObjects(); Undo.PerformUndo(); Expect(next,"Undo new reset restored older sculpting");
                Undo.PerformUndo(); Expect(original,"Undo reset merged with the preceding stroke");
            }
            finally { Object.DestroyImmediate(window); }
        }

        public static void RunResetSculpt()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders,"Use an isolated batch project with graphics");
            var errors=new List<string>(); Application.LogCallback observe=(message,stack,type)=>
            { if(type==LogType.Error || type==LogType.Exception || type==LogType.Assert) errors.Add(message); };
            Application.logMessageReceived+=observe;
            try
            {
                foreach(string shader in new[]{"Resources/BoxUtil.compute","Shaders/BoxUtil.compute"})
                {
                    foreach(GaussianSplatAsset.VectorFormat format in Enum.GetValues(typeof(GaussianSplatAsset.VectorFormat)))
                    {
                        using var f=new Fixture(shader,format);
                        ResetAllTools(f.renderer,()=>{var all=f.Positions(); return new[]{all[33],all[34],all[0]};},f.Replay);
                        var source=new uint[f.source.Length]; Get<GraphicsBuffer>(f.inner,"pos").GetData(source);
                        for(int i=0;i<source.Length;i++) Require(source[i]==f.source[i],"Reset modified the imported source");
                    }
                    var type=typeof(PagedSculptValidation).GetNestedType("Fixture",BindingFlags.NonPublic);
                    using(var f=(IDisposable)Activator.CreateInstance(type,Flags,null,new object[]{shader},null))
                        ResetAllTools(Get<SplatBoxRenderer>(f,"renderer"),()=>new[]{(Vector3)Call(f,"Position",33),
                            (Vector3)Call(f,"Position",34),(Vector3)Call(f,"Position",35)},()=>Call(f,"Replay"));
                }
                SavedScene();
                Require(errors.Count==0,"Reset sculpt errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox Reset All Sculpting PASS: mixed brushes and depth movement, active-stroke cancellation, settings preserved, independent Undo/Redo, repeated reset, fresh strokes, GPU recreation, saved-scene Undo and immutable sources; compressed monolithic and paged models on both shaders.");
            }
            finally { Application.logMessageReceived-=observe; }
        }

        static void SavedScene()
        {
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            string folder = "Assets/__MonolithicSculpt_" + Guid.NewGuid().ToString("N");
            AssetDatabase.CreateFolder("Assets", Path.GetFileName(folder));
            SplatBoxRenderer renderer = null;
            TextAsset Data(string name, byte[] bytes)
            {
                string path = folder + "/" + name + ".bytes"; File.WriteAllBytes(path, bytes);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                return AssetDatabase.LoadAssetAtPath<TextAsset>(path);
            }
            try
            {
                var asset = ScriptableObject.CreateInstance<GaussianSplatAsset>();
                asset.Initialize(Count, GaussianSplatAsset.VectorFormat.Norm11, GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.ColorFormat.Float32x4, GaussianSplatAsset.SHFormat.Float32, Vector3.zero, Vector3.one * 4, null);
                var positions = new Vector3[Count]; for (int i = 0; i < Count; i++) positions[i] = new Vector3(.2f,.2f,3);
                var chunks = new float[] { 0,0,0,0,-1,1,-1,1,2,4,0,0,0,0,0,0 };
                var chunkBytes = new byte[64]; Buffer.BlockCopy(chunks,0,chunkBytes,0,64);
                var (width,height) = GaussianSplatAsset.CalcTextureSize(Count);
                asset.SetAssetFiles(Data("chunk",chunkBytes),Data("position",Pack(positions,GaussianSplatAsset.VectorFormat.Norm11)),
                    Data("other",new byte[Count*16]),Data("color",new byte[width*height*16]),Data("sh",new byte[Count*48*4]));
                AssetDatabase.CreateAsset(asset,folder+"/source.asset");
                var owner = new GameObject("Saved monolithic sculpture"); owner.SetActive(false);
                renderer = owner.AddComponent<SplatBoxRenderer>(); Set(renderer,"m_Asset",asset);
                Set(renderer,"m_CSBoxUtil",AssetDatabase.LoadAssetAtPath<ComputeShader>(Root+"/Resources/BoxUtil.compute"));
                Call(renderer,"CreateResourcesForAsset");
                renderer.BeginSculptStroke(); renderer.SmudgeSplatsGPU(positions[0],Vector3.right*.25f,.2f,0,1); renderer.EndSculptStroke();
                Require(EditorSceneManager.SaveScene(SceneManager.GetActiveScene(),folder+"/sculpt.unity"),"Scene did not save");
                Call(renderer,"DisposeResourcesForAsset"); renderer=null;
                EditorSceneManager.OpenScene(folder+"/sculpt.unity",OpenSceneMode.Single);
                renderer=SceneManager.GetActiveScene().GetRootGameObjects()[0].GetComponent<SplatBoxRenderer>();
                Call(renderer,"CreateResourcesForAsset"); Call(renderer,"EnsureMonolithicSculptState",new object[]{null});
                var offsets=new Vector3[Count]; Get<GraphicsBuffer>(renderer,"m_GpuMonolithicSculptOffsets").GetData(offsets);
                Near(offsets[0],Vector3.right*.25f,"Saved scene did not recover sculpting");
                renderer.ResetSculpt(); Undo.FlushUndoRecordObjects(); Undo.PerformUndo();
                Call(renderer,"EnsureMonolithicSculptState",new object[]{null});
                Get<GraphicsBuffer>(renderer,"m_GpuMonolithicSculptOffsets").GetData(offsets);
                Near(offsets[0],Vector3.right*.25f,"Reset Undo after scene reload");
            }
            finally
            {
                if(renderer!=null) { Undo.ClearUndo(renderer); Call(renderer,"DisposeResourcesForAsset"); }
                EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single); AssetDatabase.DeleteAsset(folder);
            }
        }

        public static void Run()
        {
            Require(Application.isBatchMode && SystemInfo.supportsComputeShaders,"Use an isolated batch project with graphics");
            var errors=new List<string>(); Application.LogCallback observe=(message,stack,type)=>
            { if(type==LogType.Error || type==LogType.Exception || type==LogType.Assert) errors.Add(message); };
            Application.logMessageReceived+=observe;
            try
            {
                foreach(string shader in new[]{"Resources/BoxUtil.compute","Shaders/BoxUtil.compute"})
                foreach(GaussianSplatAsset.VectorFormat format in Enum.GetValues(typeof(GaussianSplatAsset.VectorFormat))) Brushes(shader,format);
                foreach(string shader in new[]{"Resources/BoxUtil.compute","Shaders/BoxUtil.compute"}) ViewDirections(shader);
                SavedScene();
                Require(errors.Count==0,"Monolithic sculpt errors: "+string.Join(" | ",errors));
                Debug.Log("SplatBox Monolithic Sculpt PASS: all packed position formats, Smudge/Move/Pinch/Flatten/Relax/Roughen/Restore, drag Undo/Redo, rendering/picking, source immutability, scene reload and physics composition on both compute copies.");
            }
            finally { Application.logMessageReceived-=observe; }
        }
    }
}
