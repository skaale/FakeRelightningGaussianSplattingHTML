# splatLOD

Progressive Gaussian splat LoD, spatial page streaming, and Quest rendering improvements for the SplatBox Unity package.

The repository root contains the `com.gaussiansplatting.splatbox` Unity package.

Companion packages from the project's `Packages` folder are included in [`Packages~/`](Packages~/):

| Folder | Package |
| --- | --- |
| `Decimate` | SplatBox Smart Decimate |
| `packageEquirectangularProjector` | Splat Equirectangular Projector |
| `packageMixamoSplatRigger` | Mixamo Splat Rigger |
| `SplatToVoxel` | Splat To Voxel |

The `~` suffix prevents Unity from importing these companion copies as part of the root package. To use a companion as an embedded package, copy its folder into the destination project's `Packages` directory.

`Packages~/manifest.json` and `Packages~/packages-lock.json` record the source project's package dependencies. The companion folders are snapshots; changes to their original sibling folders must be copied here before a future commit.

Paged LoD uses Burst traversal and background selection in Play mode and players. Camera motion queues selections before their padded view expires; larger turns refresh immediately. Page streaming continues while the camera is stationary, and compressed page uploads preserve packed position and scale data. The desktop editor, including Game view in Play mode, keeps all page detail resident when it fits the configured atlas budget, with streaming as the fallback. New selections are depth-sorted before drawing even when the normal sort interval would skip that frame. Android players default to a 256 MB resident atlas ceiling; page upload and rendering buffers use additional memory.

When a coarse page gains full detail, traversal opens its tree progressively over 0.75 seconds, including while the camera is stationary. Each parent remains selected until its entire child group is available. **Detail Distance (m)** defaults to 8 metres, with detail priority fading to its ordinary scale at 16 metres. Increase this range to sharpen surfaces farther from the camera. Quality controls the pixel cutoff: standing inside a page's bounds does not lower the stopping floor for the whole scene. Pages wholly behind the camera yield detail slots to visible pages, while contact pages retain priority. The global splat budget, atlas ceiling and stereo frustum culling still apply. This animates visible refinement; the full page payload still uploads when its detail slot is acquired.

Longer detail ranges also use available atlas space for a finer resident tier across the scene. The default 8-metre range requests up to 50% more coarse nodes, only when the atlas can retain the same number of full-detail slots. Existing v3 page assets supply these nodes directly; no page rebuild is needed. Prefix upgrades follow the same per-frame upload pacing and progressive traversal as full-detail upgrades.

The URP feature enables medium fixed foveation on supported Android XR displays using SRP foveation. Its inspector provides a switch and strength control; existing nonzero runtime levels are preserved. Foveation applies to the splat target and is disabled before compositing. Unsupported rasterization modes use the ordinary path. Standard splat colours are graded per vertex, while selection and mesh texture colours retain fragment grading so their appearance is preserved.

Traversal uses a direct hierarchy walk when the complete requested frontier fits the splat budget. If it does not fit, that attempt is discarded and the original global best-first traversal allocates the budget. Android Simple mode also prefetches a wider CPU view and requests background selections early during head motion; GPU culling still draws only the visible splats.

Budget-limited selections reuse their previous budget-pressure state to avoid repeating an unsuccessful full-frontier walk. Heap removal preserves the original priority and tie ordering with fewer comparisons. Obsolete background requests stop cooperatively. Android Simple mode includes 1 metre of world-space translation prefetch for both eyes and 50 degrees of CPU view padding. Its 0.8-metre and 20-degree safety reserves allow a 250 ms background selection to finish at the demo's 2.5 m/s walking and 60 degrees/s turning speeds. GPU culling continues to use the visible view.

If sudden motion outruns that reserve, Android Simple mode first rebuilds a complete hierarchy frontier using the last achieved detail cutoff. Three bounded attempts can raise that temporary cutoff; if they still do not fit, a priority search capped at 65,536 splats repairs coverage. This may briefly show coarser detail during a fast turn. Full-budget refinement continues on the worker and replaces the temporary selection even if the camera stops. Partial traversal output is never published.

The optional **Quest FPS HUD** sample contains an accurate headset frame counter and the demo settings used during device validation. It does not include the captured scene data or APK builds.

Create pages with **Tools > Gaussian Splatting > Create Paged LoD Scene** using Medium, High (the default), or Very High quality. Clustered SH formats are unsupported for the shared page atlas. Existing v3 page assets remain compatible; older assets whose tree and splat ordering differ must be rebuilt.

Run **Tools > Gaussian Splatting > Validate Paged LoD Streaming** in the Unity Editor to check traversal, stereo culling, worker publication, streaming, and packed GPU atlas copies. For batch validation with a graphics device, use `-executeMethod GaussianSplatting.Tests.PagedLodRendererValidation.RunAll -quit`. CPU-only checks are also available as `PagedLodTraversalValidation.Run` and `LodSelectionWorkerValidation.Run` in the same namespace.
