// SPDX-License-Identifier: MIT

using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        sealed class PagedSmudgeTreeState
        {
            public LodTreeRuntime original, published;
            public Vector3[] originalPositions;
            public BitArray editedCenters;
            public float[] hiddenSubtreeRadii;
            public Bounds originalBounds;
            public int epoch = -1, dabCount;
        }

        readonly Dictionary<SplatBoxPageGpuState, PagedSmudgeTreeState> m_PagedSmudgeTrees =
            new Dictionary<SplatBoxPageGpuState, PagedSmudgeTreeState>();
        readonly List<SplatBoxPageGpuState> m_PagedSmudgeDisposedPages = new List<SplatBoxPageGpuState>();
        List<PagedSmudgeDab> m_PagedSmudgeHierarchyDabs = new List<PagedSmudgeDab>();
        GaussianSplatPagedScene m_PagedSmudgeHierarchyScene;
        int m_PagedSmudgeHierarchyRevision = -1, m_PagedSmudgeHierarchyEpoch;
        bool m_PagedSmudgeHierarchyDirty = true;
        Vector3 m_PagedSmudgeDisplacementMin, m_PagedSmudgeDisplacementMax;
        readonly Dictionary<Bounds, (int dabCount, Bounds bounds)> m_PagedSculptBounds = new();
        int m_PagedSculptBoundsRevision;

        void InvalidatePagedSmudgeHierarchy()
        {
            m_PagedSmudgeHierarchyDirty = true;
            RequestPagedSmudgeSelectionRefresh();
            InvalidatePagedLodEraseView();
        }

        void RequestPagedSmudgeSelectionRefresh()
        {
            // A sculpt refit preserves atlas indices. Keep drawing the published selection
            // while its replacement is built, and sort it using the newly edited positions.
            InvalidateLodAsyncSelection();
            m_LodSelectionDirty = true;
            m_HasSortOrderCamera = false;
            ForceResort();
        }

        // Call before streaming and before capturing traversal contexts. A page can return from
        // the parked coarse set, or have its prefix replaced, without a journal revision change.
        void EnsurePagedSmudgeHierarchy()
        {
            RestorePagedAttractorHierarchyBase();
            RefreshPagedSmudgeHierarchyJournal();
            m_LodStreamer?.SetSculptBoundsSource(m_PagedSmudgeHierarchyDabs.Count > 0 ? this : null,
                m_PagedSculptBoundsRevision);
            if (m_PagedSmudgeHierarchyDabs.Count == 0)
            {
                // Ordinary unsculpted renderers pay no per-page bookkeeping cost. Reset also
                // restores parked coarse trees now, so they cannot return with old deformations.
                if (RestorePagedSmudgeOriginalTrees())
                    RequestPagedSmudgeSelectionRefresh();
                EnsurePagedAttractorHierarchy();
                return;
            }
            var pages = m_LodStreamer?.loadedPages;
            if (pages == null)
                return;

            bool changed = false;
            for (int i = 0; i < pages.Count; i++)
            {
                var page = pages[i];
                if (page?.lodTree?.nodes == null)
                    continue;
                if (!m_PagedSmudgeTrees.TryGetValue(page, out var state) ||
                    !ReferenceEquals(page.lodTree, state.published))
                {
                    // Prefix resizing constructs a fresh source tree. Treat it as a new baseline,
                    // while a parked tree still points at its published snapshot and resumes it.
                    state = new PagedSmudgeTreeState
                    {
                        original = page.lodTree,
                        published = page.lodTree,
                        originalBounds = page.source != null ? page.source.bounds :
                            state != null ? state.originalBounds : page.bounds
                    };
                    m_PagedSmudgeTrees[page] = state;
                }
                page.bounds = ExpandPagedSmudgeBoundsUnchecked(state.originalBounds);
                if (state.epoch == m_PagedSmudgeHierarchyEpoch &&
                    state.dabCount == m_PagedSmudgeHierarchyDabs.Count)
                    continue;

                bool restart = state.epoch != m_PagedSmudgeHierarchyEpoch;
                var previous = page.lodTree;
                var basis = restart ? state.original : state.published;
                if (restart)
                {
                    state.editedCenters?.SetAll(false);
                    state.hiddenSubtreeRadii = null;
                }
                int firstDab = restart ? 0 : state.dabCount;
                var dabs = new List<PagedSmudgeDab>();
                for (int d = firstDab; d < m_PagedSmudgeHierarchyDabs.Count; d++)
                {
                    var dab = m_PagedSmudgeHierarchyDabs[d];
                    // Expanded bounds include every preceding displacement. Filtering against the
                    // original page alone would miss a second brush touching already-moved content.
                    if (page.bounds.SqrDistance(dab.center) <= dab.radius * dab.radius + 1e-6f)
                        dabs.Add(dab);
                }

                if (dabs.Count != 0)
                {
                    state.published = ApplyPagedSculptTreeDabs(state, basis, page, dabs);
                }
                else
                    state.published = basis;
                page.lodTree = state.published;
                state.dabCount = m_PagedSmudgeHierarchyDabs.Count;
                state.epoch = m_PagedSmudgeHierarchyEpoch;
                changed |= !ReferenceEquals(previous, page.lodTree);
            }

            // Parked coarse trees retain their baseline; disposed full-detail pages must not
            // accumulate CPU tree copies over a long navigation/editing session.
            m_PagedSmudgeDisposedPages.Clear();
            foreach (var entry in m_PagedSmudgeTrees)
                if (entry.Key.lodTree == null)
                    m_PagedSmudgeDisposedPages.Add(entry.Key);
            for (int i = 0; i < m_PagedSmudgeDisposedPages.Count; i++)
                m_PagedSmudgeTrees.Remove(m_PagedSmudgeDisposedPages[i]);
            if (changed)
                RequestPagedSmudgeSelectionRefresh();
            EnsurePagedAttractorHierarchy();
        }

        void RefreshPagedSmudgeHierarchyJournal()
        {
            if (!m_PagedSmudgeHierarchyDirty && m_PagedSmudgeHierarchyScene == m_PagedScene &&
                m_PagedSmudgeHierarchyRevision == m_PagedSmudgeRevision &&
                (m_PagedSmudgeHierarchyDabs.Count > 0) == HasPagedSmudgeJournal)
                return;

            var dabs = new List<PagedSmudgeDab>();
            if (HasPagedSmudgeJournal)
                dabs.AddRange(EnumeratePagedSmudgeDabs());
            bool append = m_PagedSmudgeHierarchyScene == m_PagedScene &&
                dabs.Count >= m_PagedSmudgeHierarchyDabs.Count;
            for (int i = 0; append && i < m_PagedSmudgeHierarchyDabs.Count; i++)
            {
                var before = m_PagedSmudgeHierarchyDabs[i];
                var after = dabs[i];
                append = before.center.Equals(after.center) && before.delta.Equals(after.delta) &&
                    before.radius == after.radius && before.falloff == after.falloff &&
                    before.strength == after.strength && before.kind == after.kind &&
                    before.normal.Equals(after.normal) && before.neighborRadius == after.neighborRadius &&
                    before.invert == after.invert && before.relaxGridSize == after.relaxGridSize &&
                    ReferenceEquals(before.relaxCells, after.relaxCells);
            }
            if (!append)
            {
                m_PagedSculptBounds.Clear();
                unchecked { m_PagedSmudgeHierarchyEpoch++; }
            }
            if (!append || dabs.Count != m_PagedSmudgeHierarchyDabs.Count)
                unchecked { m_PagedSculptBoundsRevision++; }
            m_PagedSmudgeHierarchyDabs = dabs;
            m_PagedSmudgeHierarchyScene = m_PagedScene;
            m_PagedSmudgeHierarchyRevision = m_PagedSmudgeRevision;
            m_PagedSmudgeHierarchyDirty = false;

            // Sum each operation's maximum displacement. Restore only approaches the original
            // position, already inside this envelope, so it cannot enlarge it.
            m_PagedSmudgeDisplacementMin = m_PagedSmudgeDisplacementMax = Vector3.zero;
            for (int i = 0; i < dabs.Count; i++)
            {
                GetPagedSculptDisplacementBounds(dabs[i], out Vector3 minimum, out Vector3 maximum);
                m_PagedSmudgeDisplacementMin += minimum;
                m_PagedSmudgeDisplacementMax += maximum;
            }
        }

        internal Bounds ExpandPagedSmudgeBounds(Bounds original)
        {
            RefreshPagedSmudgeHierarchyJournal();
            return ExpandPagedAttractorBounds(ExpandPagedSmudgeBoundsUnchecked(original));
        }

        internal Bounds ExpandPagedSmudgeBoundsUnchecked(Bounds original)
        {
            int count = m_PagedSmudgeHierarchyDabs.Count;
            if (count == 0) return original;
            if (!m_PagedSculptBounds.TryGetValue(original, out var cached))
                cached = (0, original);
            if (cached.dabCount == count) return cached.bounds;
            Bounds bounds = cached.bounds;
            for (int i = cached.dabCount; i < count; i++)
                bounds = ExpandBoundsForSculptDab(bounds, m_PagedSmudgeHierarchyDabs[i]);
            m_PagedSculptBounds[original] = (count, bounds);
            return bounds;
        }

        // Only points in the intersection can move. Keep the old bounds as well so Restore
        // can always bring a point back toward its source, even on a currently unloaded page.
        static Bounds ExpandBoundsForSculptDab(Bounds bounds, in PagedSmudgeDab dab)
        {
            if (dab.kind == 3 || bounds.SqrDistance(dab.center) >= dab.radius * dab.radius)
                return bounds;
            Vector3 radius = Vector3.one * dab.radius;
            Vector3 min = Vector3.Max(bounds.min, dab.center - radius);
            Vector3 max = Vector3.Min(bounds.max, dab.center + radius);
            if (dab.kind == 1)
            {
                // Every falloff weight lies between zero and full strength. Checking both
                // endpoints also covers outward Pinch and strengths that overshoot the center.
                if (dab.strength >= 0f && dab.strength <= 1f && bounds.Contains(dab.center))
                    return bounds;
                Vector3 a = Vector3.LerpUnclamped(min, dab.center, dab.strength);
                Vector3 b = Vector3.LerpUnclamped(max, dab.center, dab.strength);
                min = Vector3.Min(a, b);
                max = Vector3.Max(a, b);
            }
            else
            {
                GetPagedSculptDisplacementBounds(dab, out Vector3 deltaMin, out Vector3 deltaMax);
                min += deltaMin;
                max += deltaMax;
            }
            if (!bounds.Contains(min) || !bounds.Contains(max))
                bounds.SetMinMax(Vector3.Min(bounds.min, min), Vector3.Max(bounds.max, max));
            return bounds;
        }

        static void GetPagedSculptDisplacementBounds(in PagedSmudgeDab dab,
            out Vector3 minimum, out Vector3 maximum)
        {
            Vector3 extent;
            switch (dab.kind)
            {
                case 0:
                    Vector3 movement = dab.delta * dab.strength;
                    minimum = Vector3.Min(Vector3.zero, movement);
                    maximum = Vector3.Max(Vector3.zero, movement);
                    return;
                case 1:
                    extent = Vector3.one * (dab.radius * Mathf.Abs(dab.strength));
                    break;
                case 2:
                    extent = new Vector3(Mathf.Abs(dab.normal.x), Mathf.Abs(dab.normal.y), Mathf.Abs(dab.normal.z)) *
                        (dab.normal.magnitude * dab.radius * Mathf.Abs(dab.strength));
                    break;
                case 4:
                    extent = Vector3.one * (Mathf.Min(dab.neighborRadius, 2f) * dab.radius * Mathf.Abs(dab.strength));
                    break;
                default:
                    extent = Vector3.zero;
                    break;
            }
            minimum = -extent;
            maximum = extent;
        }

        static Vector3 ApplyPagedSculptPoint(Vector3 position, Vector3 original, in PagedSmudgeDab dab)
        {
            float distanceSquared = (position - dab.center).sqrMagnitude;
            if (distanceSquared >= dab.radius * dab.radius)
                return position;
            float inverseRadius = 1f / dab.radius;
            float distance = Mathf.Sqrt(distanceSquared * inverseRadius * inverseRadius);
            float weight = dab.falloff < 0.01f ? 1f :
                dab.falloff > 0.45f && dab.falloff < 0.55f ? 1f - distance :
                1f - Mathf.Pow(distance, 1f / dab.falloff);
            if (dab.kind == 3)
                return original + (position - original) * (1f - Mathf.Clamp01(weight * dab.strength));
            Vector3 direction;
            switch (dab.kind)
            {
                case 1: direction = dab.center - position; break;
                case 2: direction = -dab.normal * Vector3.Dot(position - dab.center, dab.normal); break;
                case 4:
                    direction = PagedRelaxTarget(position, dab) - position;
                    if (dab.invert) direction = -direction;
                    break;
                default: direction = dab.delta; break;
            }
            Vector3 result = position + direction * (weight * dab.strength);
            return PagedEraseFinite(result) ? result : position;
        }

        // The tree is built before position compression. At a hard brush edge even a tiny
        // quantization difference can otherwise move a CPU node while its GPU splat stays put.
        // Decode only the resident prefix directly from asset memory when beginning a replay.
        static Vector3[] ReadPagedSculptOriginalPositions(SplatBoxPageGpuState page, LodTreeRuntime original)
        {
            var positions = new Vector3[original.nodes.Length];
            for (int i = 0; i < positions.Length; i++) positions[i] = original.nodes[i].center;
            var asset = page.source != null ? page.source.splatData : null;
            if (asset == null || asset.posData == null)
                return positions;
            NativeArray<byte> data = asset.posData.GetData<byte>();
            int stride = GaussianSplatAsset.GetVectorSize(asset.posFormat);
            if ((long)positions.Length * stride > data.Length)
                return positions;
            for (int i = 0; i < positions.Length; i++)
            {
                float3 position = DecodePagedSculptRawPosition(data, i * stride, asset.posFormat);
                int chunkIndex = i / GaussianSplatAsset.kChunkSize;
                if (page.gpuChunksValid && page.chunkInfos != null && chunkIndex < page.chunkInfos.Length)
                {
                    var chunk = page.chunkInfos[chunkIndex];
                    position = math.lerp(new float3(chunk.posX.x, chunk.posY.x, chunk.posZ.x),
                        new float3(chunk.posX.y, chunk.posY.y, chunk.posZ.y), position);
                }
                positions[i] = position;
            }
            return positions;
        }

        static float3 DecodePagedSculptRawPosition(NativeArray<byte> data, int offset, GaussianSplatAsset.VectorFormat format)
        {
            switch (format)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    return new float3(math.asfloat(ReadSmudgeUInt(data, offset)),
                        math.asfloat(ReadSmudgeUInt(data, offset + 4)), math.asfloat(ReadSmudgeUInt(data, offset + 8)));
                case GaussianSplatAsset.VectorFormat.Norm16:
                    return new float3(ReadSmudgeUShort(data, offset),
                        ReadSmudgeUShort(data, offset + 2), ReadSmudgeUShort(data, offset + 4)) / 65535f;
                case GaussianSplatAsset.VectorFormat.Norm11:
                    uint packed = ReadSmudgeUInt(data, offset);
                    return new float3((packed & 2047) / 2047f,
                        ((packed >> 11) & 1023) / 1023f, ((packed >> 21) & 2047) / 2047f);
                default:
                    uint small = ReadSmudgeUShort(data, offset);
                    return new float3((small & 63) / 63f,
                        ((small >> 6) & 31) / 31f, ((small >> 11) & 31) / 31f);
            }
        }

        static uint ReadSmudgeUShort(NativeArray<byte> data, int offset) =>
            (uint)(data[offset] | data[offset + 1] << 8);

        static uint ReadSmudgeUInt(NativeArray<byte> data, int offset) =>
            ReadSmudgeUShort(data, offset) | (ReadSmudgeUShort(data, offset + 2) << 16);

        static LodTreeRuntime ApplyPagedSculptTreeDabs(PagedSmudgeTreeState state, LodTreeRuntime basis,
            SplatBoxPageGpuState page, List<PagedSmudgeDab> dabs)
        {
            state.originalPositions ??= ReadPagedSculptOriginalPositions(page, state.original);
            LodTreeNode[] nodes = null;
            bool loneCoarseRoot = page.isCoarseStub && basis.nodes.Length == 1;
            for (int n = 0; n < basis.nodes.Length; n++)
            {
                var source = state.original.nodes[n];
                Vector3 original = state.originalPositions[n];
                bool wasEdited = state.editedCenters?[n] ?? false;
                bool edited = wasEdited;
                Vector3 position = edited ? (Vector3)basis.nodes[n].center : original;
                for (int d = 0; d < dabs.Count; d++)
                {
                    Vector3 next = ApplyPagedSculptPoint(position, original, dabs[d]);
                    edited = edited || !next.Equals(position);
                    position = next;
                }

                // Brush tests use decoded GPU positions. Keep the authored hierarchy centers
                // until a splat is edited. Restore then returns an edited center to its decoded source.
                if (edited && !wasEdited)
                {
                    state.editedCenters ??= new BitArray(basis.nodes.Length);
                    state.editedCenters[n] = true;
                }
                float3 center = edited ? (float3)position : source.center;
                if (!math.all(center == basis.nodes[n].center))
                {
                    nodes ??= (LodTreeNode[])basis.nodes.Clone();
                    nodes[n].center = center;
                }

                if (HasHiddenPagedSculptDescendants(source, loneCoarseRoot))
                {
                    float previousRadius = Mathf.Max(source.featureSize * 0.5f, state.hiddenSubtreeRadii?[n] ?? 0f);
                    float radius = previousRadius;
                    for (int d = 0; d < dabs.Count; d++)
                        radius = ExpandPagedSculptSubtreeRadius(source.center, radius, dabs[d]);
                    if (radius > previousRadius)
                    {
                        state.hiddenSubtreeRadii ??= new float[basis.nodes.Length];
                        state.hiddenSubtreeRadii[n] = radius;
                        nodes ??= (LodTreeNode[])basis.nodes.Clone();
                    }
                }
            }

            if (nodes == null)
                return basis;
            RefitPagedSmudgeTree(nodes, state.original, loneCoarseRoot, state.hiddenSubtreeRadii);
            // The worker can still hold the previous node array. Share only the immutable child tables.
            return new LodTreeRuntime
            {
                nodes = nodes,
                childTable = basis.childTable,
                childTableStart = basis.childTableStart,
                leafCount = basis.leafCount,
                rootExtent = nodes[0].featureSize,
                levelOrder = basis.levelOrder
            };
        }

        static bool HasHiddenPagedSculptDescendants(in LodTreeNode node, bool loneCoarseRoot) =>
            node.childCount == 0 && (node.IsMergedSplat || loneCoarseRoot);

        static float ExpandPagedSculptSubtreeRadius(Vector3 center, float radius, in PagedSmudgeDab dab)
        {
            // Restore approaches each source position, so both endpoints are inside this sphere.
            if (dab.kind == 3)
                return radius;
            float reach = radius + dab.radius;
            float distanceSquared = (center - dab.center).sqrMagnitude;
            if (distanceSquared > reach * reach + 1e-6f)
                return radius;
            float distance = Mathf.Sqrt(distanceSquared);
            if (dab.kind == 1 && dab.strength >= 0f && dab.strength <= 1f)
            {
                // A positive pinch moves along a segment toward the brush center. Repeated
                // pinches inside the subtree cannot enlarge its sphere.
                return radius + Mathf.Max(0f, distance - radius) * dab.strength;
            }

            GetPagedSculptDisplacementBounds(dab, out Vector3 minimum, out Vector3 maximum);
            float displacement = Vector3.Max(-minimum, maximum).magnitude;
            // Moving descendants start inside both spheres. Either sphere can bound their final reach.
            return Mathf.Max(radius, Mathf.Min(radius, distance + dab.radius) + displacement);
        }

        static void RefitPagedSmudgeTree(LodTreeNode[] nodes, LodTreeRuntime original, bool loneCoarseRoot,
            float[] hiddenSubtreeRadii)
        {
            // Both supported layouts put children after their parent. Refit in reverse order,
            // preserving original Gaussian/subtree size as well as each moved child's reach.
            for (int i = nodes.Length - 1; i >= 0; i--)
            {
                ref LodTreeNode node = ref nodes[i];
                var source = original.nodes[i];
                bool centerMoved = !math.all(node.center == source.center);
                float radius = source.featureSize * 0.5f;
                if (HasHiddenPagedSculptDescendants(source, loneCoarseRoot))
                {
                    radius = Mathf.Max(radius, hiddenSubtreeRadii?[i] ?? 0f) + math.distance(node.center, source.center);
                }
                for (int child = 0; child < node.childCount; child++)
                {
                    int index = original.childTable == null
                        ? (int)node.childStart + child
                        : original.childTable[original.childTableStart[i] + child];
                    if (index <= i || index >= nodes.Length)
                        continue;
                    var currentChild = nodes[index];
                    var sourceChild = original.nodes[index];
                    if (centerMoved || !math.all(currentChild.center == sourceChild.center) ||
                        currentChild.featureSize != sourceChild.featureSize)
                    {
                        radius = Mathf.Max(radius, math.distance(node.center, currentChild.center) +
                            currentChild.featureSize * 0.5f);
                    }
                }
                node.featureSize = radius * 2f;
            }
        }

        bool RestorePagedSmudgeOriginalTrees()
        {
            bool changed = false;
            foreach (var entry in m_PagedSmudgeTrees)
            {
                if (ReferenceEquals(entry.Key.lodTree, entry.Value.published))
                {
                    changed |= !ReferenceEquals(entry.Key.lodTree, entry.Value.original);
                    entry.Key.lodTree = entry.Value.original;
                    entry.Key.bounds = entry.Value.originalBounds;
                }
            }
            m_PagedSmudgeTrees.Clear();
            m_PagedSmudgeDisposedPages.Clear();
            return changed;
        }

        void DisposePagedSmudgeHierarchy()
        {
            RestorePagedSmudgeOriginalTrees();
            m_PagedSmudgeHierarchyDabs.Clear();
            m_PagedSmudgeHierarchyScene = null;
            m_PagedSmudgeHierarchyRevision = -1;
            m_PagedSmudgeHierarchyDirty = true;
            m_PagedSculptBounds.Clear();
            m_PagedSmudgeDisplacementMin = m_PagedSmudgeDisplacementMax = Vector3.zero;
            m_LodStreamer?.SetSculptBoundsSource(null, 0);
        }
    }
}
