// SPDX-License-Identifier: MIT

using System;
using System.Runtime.InteropServices;
using System.Threading;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Spark-inspired LoD tree traversal.
    ///
    /// The splat budget is the primary driver: page roots seed a max-heap ordered by on-screen
    /// size, and the largest node is refined repeatedly until the budget is spent. That keeps the
    /// whole scene represented while detail concentrates where it is actually visible.
    /// </summary>
    public static class SplatBoxLodTraverser
    {
        internal struct QueueEntry
        {
            public float pixelScale;
            public int pageIndex;
            public uint nodeIndex;
        }

        public struct PageContext
        {
            public int pageSlot;
            public LodTreeNode[] nodes;
            /// <summary>
            /// Optional resident-tree prefix available to this selection. Zero leaves the whole
            /// tree available. A node stays merged until its complete child group fits the prefix.
            /// This changes traversal without modifying the tree shared with background workers.
            /// </summary>
            public int nodeLimit;
            public int[] childTable;
            public int[] childTableStart;
            public float4x4 localToWorld;
            public float lodScale;
            public float outsideFoveate;
            public float behindFoveate;

            /// <summary>
            /// World units per local unit, derived from <see cref="localToWorld"/> by
            /// <see cref="Traverse"/> once per page. Node centres are transformed to world space but
            /// featureSize stays in the page's own space, so scaling the renderer's transform used to
            /// grow every splat on screen while the traversal kept measuring the original sizes
            /// against the new, larger distances.
            /// </summary>
            internal float featureScale;

            internal int EffectiveNodeCount => nodes == null ? 0 :
                nodeLimit > 0 ? Math.Min(nodeLimit, nodes.Length) : nodes.Length;
        }

        public struct ViewContext
        {
            public float3 cameraWorld;
            public float3 cameraForward;
            public float screenHeight;
            public bool frustumCull;
            public bool orthographic;

            /// <summary>
            /// Drop merged stand-in splats instead of drawing them, leaving only real scene splats.
            /// The scene then has holes wherever detail is not resident, but everything drawn is
            /// genuine — useful when a scene was built with a bad merge baked into its pages.
            /// </summary>
            public bool skipMergedSplats;

            /// <summary>
            /// Pixels a one-unit object spans one unit from the camera. Precomputed so the stand-in
            /// coverage test costs a divide instead of a tangent per node.
            /// </summary>
            public float pixelsPerUnitAtUnitDistance;

            /// <summary>
            /// Scale that turns angular size into the pixel domain the traversal orders and thresholds
            /// by. Twice <see cref="pixelsPerUnitAtUnitDistance"/>, which is how this measure has always
            /// been defined, so saved Pixel Scale Limit values keep their meaning.
            /// </summary>
            public float pixelScaleFactor;

            /// <summary>
            /// Cosine of the cone enclosing the visible viewport, for the off-centre foveation test.
            /// The field name is retained for callers; a vertical-FOV cone excludes visible corners.
            /// </summary>
            public float cosHalfFovY;

            /// <summary>
            /// On-screen size in pixels above which a merged stand-in is dropped instead of drawn.
            /// Zero disables the check.
            /// </summary>
            public float maxStandInPixels;

            /// <summary>Global renderer scale applied to every Gaussian covariance.</summary>
            public float splatScale;

            /// <summary>
            /// Cull planes as (normal.xyz, distance). Kept in this form because the per-node test then
            /// costs one dot product, where <see cref="Plane"/> makes it a managed call per plane.
            /// </summary>
            public float4[] cullPlanes;

            /// <summary>Second eye's frustum. A node visible in either eye must be retained.</summary>
            public float4[] rightEyeCullPlanes;

            /// <summary>
            /// Default cap for merged stand-ins. Paged scenes keep the whole model filled with
            /// coarse tiers, so the renderer default is the top of the slider (512). Lower values
            /// drop large stand-ins and leave holes until detail streams in.
            /// </summary>
            public const float kDefaultMaxStandInPixels = 512f;

            public static ViewContext FromCamera(Camera camera, bool frustumCull, Workspace workspace,
                float cullPaddingDeg = 0f, bool skipMergedSplats = false,
                float maxStandInPixels = kDefaultMaxStandInPixels, float splatScale = 1f)
            {
                GaussianSplatRenderSystem.GetCameraViewProj(camera, out Matrix4x4 cameraView,
                    out Matrix4x4 projection);
                Matrix4x4 cameraToWorld = cameraView.inverse;
                Matrix4x4 leftView = cameraView, rightView = cameraView;
                Matrix4x4 leftProjection = projection, rightProjection = projection;
                bool stereo = GaussianSplatRenderSystem.s_OverrideStereoViewCount == 2 || camera.stereoEnabled;
                if (GaussianSplatRenderSystem.s_OverrideStereoViewCount == 2)
                {
                    leftView = GaussianSplatRenderSystem.s_OverrideStereoView[0];
                    rightView = GaussianSplatRenderSystem.s_OverrideStereoView[1];
                    leftProjection = GaussianSplatRenderSystem.s_OverrideStereoProjection[0];
                    rightProjection = GaussianSplatRenderSystem.s_OverrideStereoProjection[1];
                }
                else if (camera.stereoEnabled)
                {
                    leftView = camera.GetStereoViewMatrix(Camera.StereoscopicEye.Left);
                    rightView = camera.GetStereoViewMatrix(Camera.StereoscopicEye.Right);
                    leftProjection = camera.GetStereoProjectionMatrix(Camera.StereoscopicEye.Left);
                    rightProjection = camera.GetStereoProjectionMatrix(Camera.StereoscopicEye.Right);
                }
                Vector3 cameraWorld = cameraToWorld.GetColumn(3);
                Vector3 cameraForward = -cameraToWorld.GetColumn(2);
                if (stereo)
                {
                    Matrix4x4 leftToWorld = leftView.inverse, rightToWorld = rightView.inverse;
                    cameraWorld = ((Vector3)leftToWorld.GetColumn(3) + (Vector3)rightToWorld.GetColumn(3)) * 0.5f;
                    cameraForward = -((Vector3)leftToWorld.GetColumn(2) + (Vector3)rightToWorld.GetColumn(2));
                }
                float screenHeight = Mathf.Max(1f, GaussianSplatRenderSystem.GetSplatScreenParams(camera).y);
                // Read the actual projection and eye render-target height. Camera.fieldOfView and
                // pixelHeight need not describe an OpenXR eye or an off-axis/custom projection.
                float projectionScale = Mathf.Abs(projection.m11);
                if (stereo)
                {
                    projectionScale = Mathf.Max(
                        Mathf.Abs(leftProjection.m11), Mathf.Abs(rightProjection.m11));
                }
                float pixelsPerUnit = screenHeight * projectionScale * 0.5f;
                cameraForward.Normalize();
                // Foveation starts outside the whole viewport, not outside a vertical-FOV circle.
                // Include both eyes and their offsets from the shared head centre, otherwise a
                // visible horizontal edge or asymmetric eye can lose detail while the camera turns.
                float foveationCosine = camera.orthographic ? -1f :
                    ViewportConeCosine(leftProjection, leftView, cameraWorld, cameraForward);
                if (stereo && !camera.orthographic)
                    foveationCosine = Mathf.Min(foveationCosine,
                        ViewportConeCosine(rightProjection, rightView, cameraWorld, cameraForward));
                var ctx = new ViewContext
                {
                    // Match streaming focus (view-matrix origin) so page distance and node projection
                    // agree — important for XR and for Main Camera–driven LoD in the Game view.
                    cameraWorld = cameraWorld,
                    cameraForward = math.normalizesafe((float3)cameraForward, new float3(0f, 0f, 1f)),
                    screenHeight = screenHeight,
                    frustumCull = frustumCull,
                    orthographic = camera.orthographic,
                    skipMergedSplats = skipMergedSplats,
                    pixelsPerUnitAtUnitDistance = pixelsPerUnit,
                    pixelScaleFactor = 2f * pixelsPerUnit,
                    cosHalfFovY = foveationCosine,
                    maxStandInPixels = maxStandInPixels,
                    splatScale = Mathf.Max(0.01f, Mathf.Abs(splatScale)),
                    cullPlanes = null,
                    rightEyeCullPlanes = null
                };

                if (frustumCull && workspace != null)
                {
                    if (stereo)
                    {
                        CalculatePaddedFrustum(leftProjection, leftView,
                            cullPaddingDeg, camera.orthographic, workspace.planeScratch, workspace.cullPlanes);
                        CalculatePaddedFrustum(rightProjection, rightView,
                            cullPaddingDeg, camera.orthographic, workspace.planeScratch, workspace.rightEyeCullPlanes);
                        ctx.rightEyeCullPlanes = workspace.rightEyeCullPlanes;
                    }
                    else
                    {
                        CalculatePaddedFrustum(projection, cameraView, cullPaddingDeg,
                            camera.orthographic, workspace.planeScratch, workspace.cullPlanes);
                    }
                    ctx.cullPlanes = workspace.cullPlanes;
                }
                return ctx;
            }

            static float ViewportConeCosine(Matrix4x4 projection, Matrix4x4 view,
                Vector3 cameraWorld, Vector3 cameraForward)
            {
                Matrix4x4 inverseViewProjection = (projection * view).inverse;
                float cosine = 1f;
                // Raw camera projections use -1/+1 for the near/far clip planes. Testing both
                // includes stereo eye-origin offsets at close range as well as far-field rays.
                for (int z = -1; z <= 1; z += 2)
                for (int y = -1; y <= 1; y += 2)
                for (int x = -1; x <= 1; x += 2)
                {
                    Vector4 corner = inverseViewProjection * new Vector4(x, y, z, 1f);
                    // Homogeneous subtraction also handles an infinite far plane (w == 0).
                    Vector3 direction = new Vector3(corner.x, corner.y, corner.z) - cameraWorld * corner.w;
                    if (corner.w < 0f)
                        direction = -direction;
                    float length = direction.magnitude;
                    if (length <= 1e-6f || float.IsNaN(length) || float.IsInfinity(length))
                        return -1f;
                    cosine = Mathf.Min(cosine, Vector3.Dot(cameraForward, direction / length));
                }
                return Mathf.Clamp(cosine - 1e-5f, -1f, 1f);
            }

            /// <summary>
            /// Expand the supplied projection without replacing its off-axis principal point with a
            /// symmetric Camera.fieldOfView approximation. Stereo callers keep each eye separately.
            /// </summary>
            static void CalculatePaddedFrustum(Matrix4x4 projection, Matrix4x4 view, float paddingDeg,
                bool orthographic, Plane[] scratch, float4[] planes)
            {
                if (paddingDeg >= 0.01f && !orthographic)
                {
                    float pad = Mathf.Deg2Rad * paddingDeg * 0.5f;
                    float halfX = Mathf.Atan(1f / Mathf.Max(Mathf.Abs(projection.m00), 1e-6f));
                    float halfY = Mathf.Atan(1f / Mathf.Max(Mathf.Abs(projection.m11), 1e-6f));
                    float scaleX = Mathf.Tan(halfX) / Mathf.Tan(Mathf.Min(halfX + pad, 89.5f * Mathf.Deg2Rad));
                    float scaleY = Mathf.Tan(halfY) / Mathf.Tan(Mathf.Min(halfY + pad, 89.5f * Mathf.Deg2Rad));
                    projection.SetRow(0, projection.GetRow(0) * scaleX);
                    projection.SetRow(1, projection.GetRow(1) * scaleY);
                }
                GeometryUtility.CalculateFrustumPlanes(projection * view, scratch);
                for (int i = 0; i < 6; i++)
                {
                    Plane p = scratch[i];
                    planes[i] = new float4(p.normal.x, p.normal.y, p.normal.z, p.distance);
                }
            }
        }

        /// <summary>Reusable scratch so per-frame traversal does not allocate.</summary>
        public sealed class Workspace
        {
            internal QueueEntry[] heap = new QueueEntry[1024];
            internal int heapCount;
            internal QueueEntry[] children = new QueueEntry[16];
            internal readonly Plane[] planeScratch = new Plane[6];
            internal readonly float4[] cullPlanes = new float4[6];
            internal readonly float4[] rightEyeCullPlanes = new float4[6];
            internal SplatBoxLodBurstTraverser.NativePage[] nativePages;
            internal GCHandle[] nativePins;
            internal readonly int[] cancellationRequest = new int[1];

            internal void RequestCancellation() => Interlocked.Exchange(ref cancellationRequest[0], 1);
            internal void ResetCancellation() => Interlocked.Exchange(ref cancellationRequest[0], 0);

            /// <summary>The latest traversal stopped after its owner invalidated the request.</summary>
            public bool wasCancelled;

            /// <summary>Whether the most recent selection used the native Burst kernel.</summary>
            public bool usedBurst;

            /// <summary>The complete requested frontier fit without priority-queue refinement.</summary>
            public bool usedDepthFirst;

            /// <summary>
            /// Set when the last traversal ran out of budget before it ran out of detail worth
            /// adding. Because refinement is globally best-first this is the normal end state for a
            /// scene bigger than the budget, not a failure.
            /// </summary>
            public bool budgetExhausted;

            /// <summary>
            /// On-screen size (pixels) of the largest node left unrefined when the budget ran out.
            /// Purely diagnostic: it tells you how coarse the survivors are. Measured in the same
            /// scaled domain the traversal orders by (featureSize × lodScale × foveation).
            /// </summary>
            public float exhaustedPixelScale;

            /// <summary>Selection composition from the last traversal, for diagnostics.</summary>
            public int emittedLeaves;
            public int emittedMerged;
            public int droppedMerged;
        }

        /// <summary>
        /// Closest a node is ever treated as being. Only reached by nodes the camera sits inside,
        /// which are exactly the ones that must refine first.
        /// </summary>
        const float kMinNodeDistance = 0.05f;

        /// <summary>
        /// On-screen size of a node in the scaled pixel domain the traversal orders and thresholds by.
        /// Runs once per visited node, so everything that only depends on the camera is precomputed in
        /// <see cref="ViewContext"/>. <paramref name="worldFeatureSize"/> is the node diameter already
        /// brought into world units by <see cref="PageContext.featureScale"/>.
        /// </summary>
        public static float ComputePixelScale(
            in ViewContext view,
            float3 centerWorld,
            float worldFeatureSize,
            float lodScale,
            float outsideFoveate,
            float behindFoveate)
        {
            float3 toCenter = centerWorld - view.cameraWorld;
            float dist = math.length(toCenter);

            // Measured from the near face of the node rather than its centre. A node's own extent is
            // most of its distance once you are close to it, so the centre measure reports a
            // room-sized subtree with its front edge in your face as being half a room away and
            // leaves it unrefined — the reason close-ups stalled at coarse detail. This is also how
            // CoversTooMuchScreen measures, so refinement order and the stand-in cull now agree.
            float radius = worldFeatureSize * 0.5f;
            float near = math.max(dist - radius, kMinNodeDistance);
            float angularSize = worldFeatureSize * math.max(0.01f, lodScale);
            if (!view.orthographic)
                angularSize /= near;

            // Foveation only means anything for a node the camera is outside of: once you are inside
            // one, part of it is in front of you wherever its centre happens to lie.
            if (dist > radius)
            {
                // Cosine of the angle off the view axis. Unity view space looks down -Z, so a node's
                // view-space direction is this same quantity: comparing cosines against the half-FOV
                // gives the identical off-centre test as measuring the angle, without the arc-cosine.
                float facing = math.dot(view.cameraForward, toCenter) / dist;
                if (facing < 0f)
                    angularSize *= math.max(0.05f, behindFoveate);
                else if (facing < view.cosHalfFovY)
                    angularSize *= math.max(0.05f, outsideFoveate);
            }

            return angularSize * view.pixelScaleFactor;
        }

        /// <summary>
        /// World units per local unit for a page transform. The largest axis, so an anisotropic scale
        /// refines against the axis that grows splats the most on screen.
        /// </summary>
        static float ComputeFeatureScale(in float4x4 localToWorld)
        {
            float sx = math.length(localToWorld.c0.xyz);
            float sy = math.length(localToWorld.c1.xyz);
            float sz = math.length(localToWorld.c2.xyz);
            return math.max(math.max(sx, sy), math.max(sz, 1e-6f));
        }

        static bool IsVisible(in ViewContext view, float3 centerWorld, float worldFeatureSize)
        {
            if (!view.frustumCull || view.cullPlanes == null)
                return true;

            // Test the full diameter rather than the radius: popping at the screen edge is worse
            // than carrying a few extra splats.
            float radius = math.max(worldFeatureSize, 1e-3f);
            return IntersectsFrustum(view.cullPlanes, centerWorld, radius) ||
                (view.rightEyeCullPlanes != null && IntersectsFrustum(view.rightEyeCullPlanes, centerWorld, radius));
        }

        static bool IntersectsFrustum(float4[] planes, float3 centerWorld, float radius)
        {
            for (int i = 0; i < planes.Length; i++)
            {
                float4 p = planes[i];
                if (math.dot(p.xyz, centerWorld) + p.w < -radius)
                    return false;
            }
            return true;
        }

        public static int Traverse(
            PageContext[] pages,
            int pageCount,
            in ViewContext view,
            int maxSplats,
            float pixelScaleLimit,
            LodActiveSplatRef[] output,
            Workspace workspace)
        {
            if (SplatBoxLodBurstTraverser.TryTraverse(pages, pageCount, view, maxSplats,
                pixelScaleLimit, output, workspace, out int selected))
                return selected;
            return TraverseManaged(pages, pageCount, view, maxSplats, pixelScaleLimit, output, workspace);
        }

        /// <summary>Compile once on the main thread before dispatching background selections.</summary>
        public static bool WarmupNativeTraversal() => SplatBoxLodBurstTraverser.Warmup();

        /// <summary>
        /// Builds the entire frontier requested by the pixel floor without a priority queue.
        /// Returns false with selected == 0 if it cannot fit or the owner cancels. Array contents
        /// from a failed attempt are unspecified and must not be published. Existing visibility,
        /// complete-child-group and stand-in filters still apply; an empty complete view is valid.
        /// </summary>
        public static bool TryTraverseCompleteFrontier(
            PageContext[] pages, int pageCount, in ViewContext view, int maxSplats,
            float pixelScaleLimit, LodActiveSplatRef[] output, Workspace workspace, out int selected)
        {
            if (SplatBoxLodBurstTraverser.TryTraverse(pages, pageCount, view, maxSplats,
                pixelScaleLimit, output, workspace, out selected, completeFrontierOnly: true))
            {
                if (workspace.usedDepthFirst && !workspace.wasCancelled)
                    return true;
                selected = 0;
                return false;
            }
            return TryTraverseCompleteFrontierManaged(pages, pageCount, view, maxSplats,
                pixelScaleLimit, output, workspace, out selected);
        }

        /// <summary>Managed equivalent of the bounded complete-frontier attempt.</summary>
        public static bool TryTraverseCompleteFrontierManaged(
            PageContext[] pages, int pageCount, in ViewContext view, int maxSplats,
            float pixelScaleLimit, LodActiveSplatRef[] output, Workspace workspace, out int selected)
        {
            selected = 0;
            if (workspace == null)
                return false;
            ResetWorkspace(workspace);
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0)
                return false;
            maxSplats = Mathf.Min(maxSplats, output.Length);
            pageCount = Mathf.Min(pageCount, pages.Length);
            if (maxSplats <= 0 || PollCancellation(workspace))
                return false;
            int capacity = Mathf.Max(maxSplats, pageCount);
            if (workspace.heap.Length < capacity)
                Array.Resize(ref workspace.heap, capacity);
            if (TryTraverseDepthFirst(pages, pageCount, view, maxSplats, pixelScaleLimit,
                output, workspace, out selected))
            {
                workspace.usedDepthFirst = true;
                return true;
            }
            selected = 0;
            if (!workspace.wasCancelled)
            {
                ResetWorkspace(workspace);
                workspace.budgetExhausted = true;
            }
            return false;
        }

        /// <summary>Managed fallback, using a linear walk when the complete frontier fits.</summary>
        public static int TraverseManaged(
            PageContext[] pages,
            int pageCount,
            in ViewContext view,
            int maxSplats,
            float pixelScaleLimit,
            LodActiveSplatRef[] output,
            Workspace workspace)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0 || workspace == null)
                return 0;
            maxSplats = Mathf.Min(maxSplats, output.Length);
            pageCount = Mathf.Min(pageCount, pages.Length);
            if (maxSplats <= 0)
                return 0;
            bool tryDepthFirst = !workspace.budgetExhausted;
            ResetWorkspace(workspace);
            if (PollCancellation(workspace))
                return 0;
            int capacity = Mathf.Max(maxSplats, pageCount);
            if (workspace.heap.Length < capacity)
                Array.Resize(ref workspace.heap, capacity);
            if (tryDepthFirst && TryTraverseDepthFirst(pages, pageCount, view, maxSplats, pixelScaleLimit,
                output, workspace, out int count))
            {
                workspace.usedDepthFirst = true;
                return count;
            }
            if (workspace.wasCancelled)
                return 0;
            // A partial DFS result has no global priority guarantee. Discard its count and
            // diagnostics, then run the unchanged budgeted traversal from the roots.
            return TraverseManagedBestFirst(pages, pageCount, view, maxSplats, pixelScaleLimit,
                output, workspace);
        }

        static void ResetWorkspace(Workspace workspace)
        {
            workspace.usedBurst = false;
            workspace.usedDepthFirst = false;
            workspace.heapCount = 0;
            workspace.budgetExhausted = false;
            workspace.exhaustedPixelScale = 0f;
            workspace.emittedLeaves = 0;
            workspace.emittedMerged = 0;
            workspace.droppedMerged = 0;
            workspace.wasCancelled = false;
        }

        static bool PollCancellation(Workspace workspace)
        {
            if (Volatile.Read(ref workspace.cancellationRequest[0]) == 0)
                return false;
            ResetWorkspace(workspace);
            workspace.wasCancelled = true;
            return true;
        }

        static bool TryTraverseDepthFirst(PageContext[] pages, int pageCount, in ViewContext view,
            int maxSplats, float pixelScaleLimit, LodActiveSplatRef[] output, Workspace workspace,
            out int outCount)
        {
            outCount = 0;
            int processed = 0;
            for (int p = 0; p < pageCount; p++)
            {
                if ((processed++ & 63) == 0 && PollCancellation(workspace))
                    return false;
                ref PageContext page = ref pages[p];
                if (page.EffectiveNodeCount == 0)
                    continue;
                page.featureScale = ComputeFeatureScale(page.localToWorld);
                LodTreeNode node = page.nodes[0];
                float3 world = math.mul(page.localToWorld, new float4(node.center, 1f)).xyz;
                float feature = node.featureSize * page.featureScale;
                if (!IsVisible(view, world, feature))
                    continue;
                if (workspace.heapCount >= maxSplats)
                    return false;
                workspace.heap[workspace.heapCount++] = new QueueEntry
                {
                    pageIndex = p, nodeIndex = 0,
                    pixelScale = ComputePixelScale(view, world, feature, page.lodScale,
                        page.outsideFoveate, page.behindFoveate)
                };
            }
            while (workspace.heapCount > 0)
            {
                if ((processed++ & 63) == 0 && PollCancellation(workspace))
                    return false;
                QueueEntry top = workspace.heap[--workspace.heapCount];
                ref PageContext page = ref pages[top.pageIndex];
                if (!HasCompleteChildren(page, top.nodeIndex) ||
                    (pixelScaleLimit > 0f && top.pixelScale < pixelScaleLimit))
                {
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    continue;
                }
                int visible = CollectVisibleChildren(ref page, top, view, workspace);
                if (outCount + workspace.heapCount + visible > maxSplats)
                    return false;
                for (int c = 0; c < visible; c++)
                {
                    QueueEntry child = workspace.children[c];
                    if (page.nodes[child.nodeIndex].childCount == 0 ||
                        (pixelScaleLimit > 0f && child.pixelScale < pixelScaleLimit))
                        EmitUnlessEngulfing(ref page, child.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    else
                        workspace.heap[workspace.heapCount++] = child;
                }
            }
            return true;
        }

        /// <summary>Original globally best-first algorithm, retained as the budgeted fallback.</summary>
        static int TraverseManagedBestFirst(
            PageContext[] pages,
            int pageCount,
            in ViewContext view,
            int maxSplats,
            float pixelScaleLimit,
            LodActiveSplatRef[] output,
            Workspace workspace)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0 || workspace == null)
                return 0;

            maxSplats = Mathf.Min(maxSplats, output.Length);
            pageCount = Mathf.Min(pageCount, pages.Length);
            if (maxSplats <= 0)
                return 0;

            ResetWorkspace(workspace);
            if (PollCancellation(workspace))
                return 0;
            int outCount = 0;
            int processed = 0;

            for (int p = 0; p < pageCount; p++)
            {
                if ((processed++ & 63) == 0 && PollCancellation(workspace))
                    return 0;
                ref PageContext ctx = ref pages[p];
                if (ctx.EffectiveNodeCount == 0)
                    continue;

                ctx.featureScale = ComputeFeatureScale(ctx.localToWorld);

                float3 centerWorld = math.mul(ctx.localToWorld, new float4(ctx.nodes[0].center, 1f)).xyz;
                float feature = ctx.nodes[0].featureSize * ctx.featureScale;
                // Visibility uses the true extent; lodScale is a quality knob and must not shrink bounds.
                if (!IsVisible(view, centerWorld, feature))
                    continue;

                float ps = ComputePixelScale(view, centerWorld, feature, ctx.lodScale,
                    ctx.outsideFoveate, ctx.behindFoveate);
                HeapPush(workspace, new QueueEntry { pixelScale = ps, pageIndex = p, nodeIndex = 0 });
            }

            while (workspace.heapCount > 0)
            {
                if ((processed++ & 63) == 0 && PollCancellation(workspace))
                    return 0;
                // Every remaining node would be emitted into a full output array, so stop walking
                // the tree for them. Refinement is largest-first, so the top of the heap is the
                // coarsest thing the budget could not pay for.
                if (outCount >= maxSplats)
                {
                    if (!workspace.budgetExhausted)
                    {
                        workspace.budgetExhausted = true;
                        workspace.exhaustedPixelScale = workspace.heap[0].pixelScale;
                    }
                    break;
                }

                QueueEntry top = HeapPop(workspace);

                ref PageContext page = ref pages[top.pageIndex];
                if (top.nodeIndex >= page.EffectiveNodeCount)
                    continue;

                if (!HasCompleteChildren(page, top.nodeIndex))
                {
                    // A partially available child group must keep its parent. Emitting only the
                    // available siblings would lose coverage, even if the missing ones are culled.
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    continue;
                }

                // Nodes come out largest-first, so once the top is under the detail floor every
                // remaining node is too: keep them all as coarse merged splats.
                if (pixelScaleLimit > 0f && top.pixelScale < pixelScaleLimit)
                {
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    break;
                }

                // Only visible children replace this node. Charging for culled siblings wastes the
                // budget at the view edge and can leave a large parent selected despite ample room.
                int visibleChildren = CollectVisibleChildren(ref page, top, view, workspace);
                // Refining swaps this node for its children; everything still queued also has to fit.
                if (outCount + workspace.heapCount + visibleChildren > maxSplats)
                {
                    if (!workspace.budgetExhausted)
                    {
                        workspace.budgetExhausted = true;
                        workspace.exhaustedPixelScale = top.pixelScale;
                    }
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    continue;
                }

                ExpandChildren(ref page, visibleChildren, view, pixelScaleLimit, output,
                    ref outCount, maxSplats, workspace);
            }

            for (int i = 0; i < workspace.heapCount && outCount < maxSplats; i++)
            {
                if ((processed++ & 63) == 0 && PollCancellation(workspace))
                    return 0;
                ref readonly QueueEntry entry = ref workspace.heap[i];
                ref PageContext entryPage = ref pages[entry.pageIndex];
                if (entry.nodeIndex >= entryPage.EffectiveNodeCount)
                    continue;
                EmitUnlessEngulfing(ref entryPage, entry.nodeIndex, view, output, ref outCount, maxSplats, workspace);
            }
            workspace.heapCount = 0;

            return outCount;
        }

        static bool HasCompleteChildren(in PageContext page, uint nodeIndex)
        {
            LodTreeNode node = page.nodes[nodeIndex];
            if (node.childCount == 0)
                return false;

            int count = page.EffectiveNodeCount;
            int tableStart = page.childTableStart != null && nodeIndex < page.childTableStart.Length
                ? page.childTableStart[nodeIndex] : -1;
            if (tableStart >= 0 && page.childTable != null)
            {
                if ((long)tableStart + node.childCount > page.childTable.Length)
                    return false;
                for (int c = 0; c < node.childCount; c++)
                {
                    int child = page.childTable[tableStart + c];
                    if (child <= 0 || child >= count)
                        return false;
                }
                return true;
            }
            return node.childStart > nodeIndex && (long)node.childStart + node.childCount <= count;
        }

        static int CollectVisibleChildren(
            ref PageContext page,
            in QueueEntry parent,
            in ViewContext view,
            Workspace workspace)
        {
            LodTreeNode node = page.nodes[parent.nodeIndex];
            int childCount = node.childCount;
            if (workspace.children.Length < childCount)
                Array.Resize(ref workspace.children, Mathf.NextPowerOfTwo(childCount));
            int tableStart = page.childTableStart != null && parent.nodeIndex < page.childTableStart.Length
                ? page.childTableStart[parent.nodeIndex]
                : -1;

            int visibleCount = 0;
            for (int c = 0; c < childCount; c++)
            {
                int childIdx;
                if (tableStart >= 0 && page.childTable != null && tableStart + c < page.childTable.Length)
                    childIdx = page.childTable[tableStart + c];
                else
                    childIdx = (int)node.childStart + c;

                if (childIdx <= 0 || childIdx >= page.EffectiveNodeCount)
                    continue;

                LodTreeNode child = page.nodes[childIdx];
                float3 childWorld = math.mul(page.localToWorld, new float4(child.center, 1f)).xyz;
                float childFeature = child.featureSize * page.featureScale;
                if (!IsVisible(view, childWorld, childFeature))
                    continue;

                // Terminal nodes are emitted directly and never compared in the heap.
                float childPs = child.childCount == 0 ? 0f :
                    ComputePixelScale(view, childWorld, childFeature, page.lodScale,
                        page.outsideFoveate, page.behindFoveate);

                workspace.children[visibleCount++] = new QueueEntry
                {
                    pixelScale = childPs,
                    pageIndex = parent.pageIndex,
                    nodeIndex = (uint)childIdx
                };
            }
            return visibleCount;
        }

        static void ExpandChildren(
            ref PageContext page,
            int childCount,
            in ViewContext view,
            float pixelScaleLimit,
            LodActiveSplatRef[] output,
            ref int outCount,
            int maxSplats,
            Workspace workspace)
        {
            for (int c = 0; c < childCount; c++)
            {
                QueueEntry child = workspace.children[c];
                // A child under the detail floor can never be refined further, so emit it now
                // instead of paying a heap insert to have it popped straight back out. Terminal
                // children also have no refinement work, even when they span many pixels nearby.
                if (page.nodes[child.nodeIndex].childCount == 0 ||
                    (pixelScaleLimit > 0f && child.pixelScale < pixelScaleLimit))
                {
                    EmitUnlessEngulfing(ref page, child.nodeIndex, view, output, ref outCount,
                        maxSplats, workspace);
                    continue;
                }
                HeapPush(workspace, child);
            }
        }

        /// <summary>
        /// Emits a node, dropping merged stand-ins that cannot usefully represent their subtree: any
        /// blob smeared across a large part of the view, and all of them when
        /// <see cref="ViewContext.skipMergedSplats"/> is set. Leaves are genuine scene content and
        /// always render.
        /// </summary>
        static void EmitUnlessEngulfing(
            ref PageContext page,
            uint nodeIndex,
            in ViewContext view,
            LodActiveSplatRef[] output,
            ref int outCount,
            int maxSplats,
            Workspace workspace)
        {
            LodTreeNode node = page.nodes[nodeIndex];
            if (node.IsMergedSplat)
            {
                if (view.skipMergedSplats)
                {
                    workspace.droppedMerged++;
                    return;
                }

                float3 world = math.mul(page.localToWorld, new float4(node.center, 1f)).xyz;
                if (CoversTooMuchScreen(view, world, node.featureSize * page.featureScale))
                {
                    workspace.droppedMerged++;
                    return;
                }
                workspace.emittedMerged++;
            }
            else
            {
                workspace.emittedLeaves++;
            }
            Emit(output, ref outCount, maxSplats, page.pageSlot, nodeIndex);
        }

        /// <summary>
        /// True when a stand-in would cover too much of the screen to be worth drawing. Refinement is
        /// best-first, so a blob this big only survives when the page has no finer data resident or the
        /// budget ran out — either way it is the average of a subtree the camera is nearly inside, so it
        /// hides the real geometry behind a flat wash. It is also ruinously expensive: blend cost grows
        /// with area, while the budget it spends is counted in splats, so one of these displaces
        /// thousands of refined splats it cannot come close to representing. Leaving a hole reads better
        /// and lets the streamer bring in the detail that belongs there.
        /// </summary>
        static bool CoversTooMuchScreen(in ViewContext view, float3 centerWorld, float worldFeatureSize)
        {
            if (view.maxStandInPixels <= 0f)
                return false;

            if (view.orthographic)
                return worldFeatureSize * view.splatScale * view.pixelsPerUnitAtUnitDistance > view.maxStandInPixels;

            // Measured from the near side of the blob, so containing the camera falls out as the
            // limit case rather than needing its own test.
            float radius = worldFeatureSize * 0.5f;
            float dist = math.length(centerWorld - view.cameraWorld) - radius;
            if (dist <= 0f)
                return true;

            // The compute shader applies _SplatScale to the covariance before projection. Include
            // that same linear scale here so "Max Stand-in Size" means final rendered pixels.
            float pixels = worldFeatureSize * view.splatScale * view.pixelsPerUnitAtUnitDistance / dist;
            return pixels > view.maxStandInPixels;
        }

        static void Emit(LodActiveSplatRef[] output, ref int outCount, int maxSplats, int pageSlot, uint splatIndex)
        {
            if (outCount >= maxSplats)
                return;
            output[outCount++] = new LodActiveSplatRef
            {
                pageSlot = (uint)pageSlot,
                splatIndex = splatIndex
            };
        }

        static void HeapPush(Workspace ws, in QueueEntry entry)
        {
            if (ws.heapCount == ws.heap.Length)
                Array.Resize(ref ws.heap, ws.heap.Length * 2);

            int i = ws.heapCount++;
            while (i > 0)
            {
                int parent = (i - 1) >> 1;
                if (ws.heap[parent].pixelScale >= entry.pixelScale)
                    break;
                ws.heap[i] = ws.heap[parent];
                i = parent;
            }
            ws.heap[i] = entry;
        }

        static QueueEntry HeapPop(Workspace ws)
        {
            QueueEntry top = ws.heap[0];
            int count = --ws.heapCount;
            if (count > 0)
            {
                QueueEntry entry = ws.heap[count];
                int i = 0;
                while (true)
                {
                    int left = 2 * i + 1;
                    if (left >= count)
                        break;
                    int right = left + 1;
                    int largest = left;
                    if (right < count && ws.heap[right].pixelScale > ws.heap[largest].pixelScale)
                        largest = right;
                    ws.heap[i] = ws.heap[largest];
                    i = largest;
                }
                // Floyd's removal compares siblings on the downward walk, then locates the
                // tail entry on that path. Equality bubbles upward to preserve the original
                // heap's exact tie placement and subsequent global refinement order.
                while (i > 0)
                {
                    int parent = (i - 1) >> 1;
                    if (ws.heap[parent].pixelScale > entry.pixelScale)
                        break;
                    ws.heap[i] = ws.heap[parent];
                    i = parent;
                }
                ws.heap[i] = entry;
            }
            return top;
        }

        public static int FillLeafFallback(
            PageContext[] pages,
            int pageCount,
            int maxSplats,
            LodActiveSplatRef[] output)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0)
                return 0;

            int limit = Mathf.Min(maxSplats, output.Length);
            pageCount = Mathf.Min(pageCount, pages.Length);
            if (limit <= 0 || pageCount <= 0)
                return 0;

            int perPage = Mathf.Max(1, limit / pageCount);
            int outCount = 0;
            for (int p = 0; p < pageCount && outCount < limit; p++)
            {
                ref readonly PageContext ctx = ref pages[p];
                if (ctx.nodes == null || ctx.nodes.Length == 0)
                    continue;
                int added = 0;
                for (uint i = 0; i < ctx.nodes.Length && added < perPage && outCount < limit; i++)
                {
                    if (!ctx.nodes[i].IsLeaf)
                        continue;
                    output[outCount++] = new LodActiveSplatRef
                    {
                        pageSlot = (uint)ctx.pageSlot,
                        splatIndex = i
                    };
                    added++;
                }
            }
            return outCount;
        }

        /// <summary>
        /// Select splats 0..N-1 from each loaded page when LoD traversal finds nothing visible.
        /// </summary>
        public static int FillSequentialFallback(
            PageContext[] pages,
            int pageCount,
            int maxSplats,
            LodActiveSplatRef[] output)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0)
                return 0;

            maxSplats = Mathf.Min(maxSplats, output.Length);
            pageCount = Mathf.Min(pageCount, pages.Length);
            int outCount = 0;
            for (int p = 0; p < pageCount && outCount < maxSplats; p++)
            {
                ref readonly PageContext ctx = ref pages[p];
                int splatCount = ctx.nodes?.Length ?? 0;
                if (splatCount <= 0)
                    continue;
                for (uint i = 0; i < splatCount && outCount < maxSplats; i++)
                {
                    output[outCount++] = new LodActiveSplatRef
                    {
                        pageSlot = (uint)ctx.pageSlot,
                        splatIndex = i
                    };
                }
            }
            return outCount;
        }
    }
}
