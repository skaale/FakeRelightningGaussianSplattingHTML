// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Loads spatial pages for a GaussianSplatPagedScene.
    /// Every page keeps a coarse tier resident so the whole scene stays visible at distance; the
    /// view-ranked pages within the load radius borrow one of maxLoadedPages full-detail slots.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SplatBoxLodStreamer : MonoBehaviour
    {
        [SerializeField] GaussianSplatPagedScene m_PagedScene;
        [SerializeField] Transform m_SplatTransform;
        [Tooltip("Distance from the camera to the nearest edge of a page at which it becomes a " +
                 "candidate for one of the full-detail slots.")]
        [SerializeField] float m_LoadRadius = 48f;
        [Tooltip("Distance to the nearest edge of a page beyond which it always drops back to its " +
                 "coarse tier. Keep it above Load Radius so pages do not thrash at the boundary.")]
        [SerializeField] float m_UnloadRadius = 58f;
        [SerializeField] int m_MaxLoadedPages = 16;
        [Tooltip("Splats kept resident for pages outside the detail radius so the whole scene stays visible.")]
        [SerializeField] int m_CoarsePageSplats = 8192;
        [SerializeField] float m_StreamUpdateInterval = 0.25f;
        [SerializeField] float m_StreamMoveThreshold = 0.5f;

        readonly Dictionary<int, SplatBoxPageGpuState> m_Loaded = new Dictionary<int, SplatBoxPageGpuState>();
        readonly List<int> m_LoadOrder = new List<int>();
        readonly List<SplatBoxPageGpuState> m_LoadedList = new List<SplatBoxPageGpuState>();
        // Coarse tiers are small and every page needs one sooner or later, so parked copies are
        // kept alive rather than rebuilt each time a page leaves the detail radius.
        readonly Dictionary<int, SplatBoxPageGpuState> m_ParkedCoarse = new Dictionary<int, SplatBoxPageGpuState>();
        readonly Stack<int> m_FreeDetailSlots = new Stack<int>();
        readonly HashSet<int> m_HeldDetailSlots = new HashSet<int>();
        readonly List<(GaussianSplatPageEntry entry, float dist, float rank)> m_RankedScratch = new List<(GaussianSplatPageEntry, float, float)>();
        readonly List<int> m_ToDowngradeScratch = new List<int>();
        readonly List<(int pageId, float rank)> m_DowngradeCandidateScratch = new List<(int, float)>();
        readonly HashSet<int> m_DetailPageScratch = new HashSet<int>();

        int m_NextPageSlot;
        int m_DetailSlotCapacity;
        int m_DetailSlotLimit = int.MaxValue;
        int m_CoarsePageSplatLimit = int.MaxValue;
        int m_AtlasCoarsePageSplatTarget;
        bool m_AllowFullSceneResidency = true;
        bool m_CopyResidency;
        [NonSerialized] int m_EditorFullSceneSplatCapacity = kEditorFullDetailSplatCap;
        float m_LastStreamTime = -999f;
        Vector3 m_LastStreamFocus;
        Vector3 m_LastStreamViewDir = Vector3.forward;
        bool m_HasLastStreamFocus;
        int m_LastPageUploadFrame = -1;
        bool m_LastUploadWasCoarse;
        bool m_HasPendingStreamingWork;
        Vector3 m_SculptDisplacementMin, m_SculptDisplacementMax;
        SplatBoxRenderer m_SculptBoundsSource;
        int m_SculptBoundsRevision;
        readonly Dictionary<int, Bounds> m_AttractorPageBounds = new Dictionary<int, Bounds>();
        // Pure rotation used to be ignored (skip only checked focus position), so looking around
        // left detail slots aimed at the old view and the new direction showed coarse holes.
        const float kStreamRotateThresholdDeg = 8f;
        const float kStreamRotateInterval = 0.08f;

        /// <summary>Conservative editor residency limit until the renderer supplies its atlas capacity.</summary>
        public const int kEditorFullDetailSplatCap = 4_000_000;

        /// <summary>
        /// Minimum time a page keeps a detail slot before rank churn may evict it. The wanted set
        /// is view-dependent, so without this a small camera drift swaps borderline pages between
        /// full detail and coarse on every streaming update.
        /// </summary>
        const float kDetailSlotHoldSeconds = 2f;

        /// <summary>
        /// Within this distance of a page, load full leaf data immediately (edit + play) and give
        /// the page absolute priority for a detail slot.
        /// </summary>
        const float kHighestDetailDistance = 0.5f;

        /// <summary>
        /// Maximum distance penalty for pages wholly behind the camera. Contact pages remain
        /// absolute priorities, while visible geometry can outrank nearer pages behind the head.
        /// </summary>
        const float kBehindDetailPenaltyDistance = 16f;

        /// <summary>
        /// Coarse pages inside this radius force an immediate streaming update even if the normal
        /// interval has not elapsed.
        /// </summary>
        const float kUrgentCoarseDistance = 0.5f;

        public GaussianSplatPagedScene pagedScene => m_PagedScene;
        public IReadOnlyList<SplatBoxPageGpuState> loadedPages => m_LoadedList;
        public int coarsePageSplats => Mathf.Max(1, Mathf.Min(
            Mathf.Max(m_CoarsePageSplats, m_AtlasCoarsePageSplatTarget), m_CoarsePageSplatLimit));
        public float loadRadius => Mathf.Max(1f, m_LoadRadius);
        public event Action OnPagesChanged;

        /// <summary>
        /// Conservative local-space displacement of sculpted content, including pages which are
        /// not resident yet. Keeping this independent of residency lets an edited page acquire a
        /// detail slot near its new position after its full tree has been unloaded.
        /// </summary>
        public void SetSculptDisplacementBounds(Vector3 minimum, Vector3 maximum)
        {
            minimum = Vector3.Min(Vector3.zero, minimum);
            maximum = Vector3.Max(Vector3.zero, maximum);
            if (m_SculptDisplacementMin == minimum && m_SculptDisplacementMax == maximum)
                return;
            m_SculptDisplacementMin = minimum;
            m_SculptDisplacementMax = maximum;
            m_HasLastStreamFocus = false;
            m_HasPendingStreamingWork = true;
        }

        internal void SetSculptBoundsSource(SplatBoxRenderer source, int revision)
        {
            if (ReferenceEquals(source, m_SculptBoundsSource) && revision == m_SculptBoundsRevision)
                return;
            m_SculptBoundsSource = source;
            m_SculptBoundsRevision = revision;
            m_HasPendingStreamingWork = true;
        }

        public Bounds GetEditedPageBounds(in GaussianSplatPageEntry entry)
        {
            var bounds = new Bounds();
            bounds.SetMinMax(entry.boundsMin, entry.boundsMax);
            if (m_SculptBoundsSource != null)
                bounds = m_SculptBoundsSource.ExpandPagedSmudgeBoundsUnchecked(bounds);
            if (m_SculptDisplacementMin != Vector3.zero || m_SculptDisplacementMax != Vector3.zero)
                bounds.SetMinMax(bounds.min + m_SculptDisplacementMin, bounds.max + m_SculptDisplacementMax);
            if (m_AttractorPageBounds.TryGetValue(entry.pageId, out var animated)) bounds.Encapsulate(animated);
            return bounds;
        }

        public void SetAttractorPageBounds(int pageId, Bounds bounds)
        {
            if (m_AttractorPageBounds.TryGetValue(pageId, out var previous) && previous.Equals(bounds)) return;
            m_AttractorPageBounds[pageId] = bounds;
            // The envelope is current immediately. Re-rank pages at the pending-work cadence
            // instead of bypassing it for every tiny animation step of every affected page.
            m_HasPendingStreamingWork = true;
        }

        public void ClearAttractorPageBounds()
        {
            if (m_AttractorPageBounds.Count == 0) return;
            m_AttractorPageBounds.Clear();
            m_HasLastStreamFocus = false;
            m_HasPendingStreamingWork = true;
        }

        /// <summary>True while at least one page still needs its coarse GPU upload.</summary>
        public bool hasPendingCoarseLoads
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return false;
                int expected = 0;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                {
                    if (m_PagedScene.pages[i].pageAsset != null && m_PagedScene.pages[i].pageAsset.IsValid)
                        expected++;
                }
                return m_Loaded.Count < expected;
            }
        }

        /// <summary>Number of pages that can be held at full detail at once, after any atlas limit.</summary>
        public int detailSlotCapacity => m_DetailSlotCapacity;

        /// <summary>
        /// Detail slots this streamer wants, before the atlas gets a say. Independent of the current
        /// limit, so the renderer can use it as a stable input when sizing the atlas.
        /// </summary>
        public int requestedDetailSlots
        {
            get
            {
                int pageCount = m_PagedScene?.pageCount ?? 0;
                return pageCount > 0 ? Mathf.Clamp(m_MaxLoadedPages, 1, pageCount) : 0;
            }
        }

        /// <summary>
        /// Editor preview: keep every page at full detail, including Game view in Play mode, when
        /// it fits the renderer's atlas capacity. Exact layout and
        /// alignment still decide affordability — see <see cref="loadsEveryPageAtFullDetail"/>.
        /// </summary>
        public bool wantsFullSceneResidency
        {
            get
            {
                if (m_CopyResidency)
                    return CanEditorLoadAllPages(m_PagedScene, m_EditorFullSceneSplatCapacity);
#if UNITY_EDITOR
                return CanEditorLoadAllPages(m_PagedScene, m_EditorFullSceneSplatCapacity);
#else
                return false;
#endif
            }
        }

        /// <summary>True when full-scene residency is both wanted and affordable.</summary>
        public bool loadsEveryPageAtFullDetail => m_AllowFullSceneResidency && wantsFullSceneResidency;

        internal void SetCopyResidency(bool enabled)
        {
            if (m_CopyResidency == enabled) return;
            m_CopyResidency = enabled;
            m_HasPendingStreamingWork = true;
        }

        /// <summary>Supplies the memory- and hardware-bounded atlas capacity for editor residency.</summary>
        public void SetEditorFullSceneSplatCapacity(int splatCapacity)
        {
            splatCapacity = Mathf.Max(0, splatCapacity);
            if (m_EditorFullSceneSplatCapacity == splatCapacity)
                return;
            m_EditorFullSceneSplatCapacity = splatCapacity;
            m_HasPendingStreamingWork = true;
        }

        public static bool CanEditorLoadAllPages(GaussianSplatPagedScene scene) =>
            CanEditorLoadAllPages(scene, kEditorFullDetailSplatCap);

        static bool CanEditorLoadAllPages(GaussianSplatPagedScene scene, int splatCapacity)
        {
            if (scene?.pages == null)
                return false;
            long total = 0;
            for (int i = 0; i < scene.pages.Length; i++)
                total += scene.pages[i].splatCount;
            return total <= splatCapacity;
        }

        public void Configure(GaussianSplatPagedScene scene, Transform splatTransform)
        {
            // Anything already loaded belongs to the previous scene, and its detail slots are about
            // to be handed out again, so it has to go before the slot pool is rebuilt.
            if (!ReferenceEquals(m_PagedScene, scene))
            {
                ClearAttractorPageBounds();
                SetSculptBoundsSource(null, 0);
                SetSculptDisplacementBounds(Vector3.zero, Vector3.zero);
                if (m_Loaded.Count > 0 || m_ParkedCoarse.Count > 0)
                    UnloadAll();
            }

            m_PagedScene = scene;
            m_SplatTransform = splatTransform != null ? splatTransform : transform;
            if (scene != null)
            {
                m_LoadRadius = scene.loadRadius;
                m_UnloadRadius = scene.unloadRadius;
                m_MaxLoadedPages = scene.maxLoadedPages;
                m_CoarsePageSplats = scene.coarsePageSplats;
            }
            m_HasLastStreamFocus = false;
            m_HasPendingStreamingWork = true;
            ResetDetailSlots();
        }

        /// <summary>
        /// Tells the streamer what the atlas can actually accommodate, so it never asks for a slot
        /// or a residency mode the renderer has no memory for. Set by the renderer after it lays the
        /// atlas out.
        /// </summary>
        public void SetAtlasLimits(int detailSlotLimit, bool allowFullSceneResidency,
            int coarsePageSplatLimit = int.MaxValue, int coarsePageSplatTarget = 0)
        {
            detailSlotLimit = Mathf.Max(0, detailSlotLimit);
            coarsePageSplatLimit = Mathf.Max(1, coarsePageSplatLimit);
            coarsePageSplatTarget = Mathf.Max(0, coarsePageSplatTarget);
            if (detailSlotLimit == m_DetailSlotLimit && allowFullSceneResidency == m_AllowFullSceneResidency &&
                coarsePageSplatLimit == m_CoarsePageSplatLimit &&
                coarsePageSplatTarget == m_AtlasCoarsePageSplatTarget)
                return;
            m_DetailSlotLimit = detailSlotLimit;
            m_CoarsePageSplatLimit = coarsePageSplatLimit;
            m_AtlasCoarsePageSplatTarget = coarsePageSplatTarget;
            m_AllowFullSceneResidency = allowFullSceneResidency;
            m_HasPendingStreamingWork = true;
            bool changed = false;
            foreach (var kv in m_Loaded)
            {
                if (kv.Value != null && (kv.Value.isCoarseStub ||
                    (!loadsEveryPageAtFullDetail && kv.Value.detailSlot < 0)))
                {
                    int previousCount = kv.Value.splatCount;
                    changed |= kv.Value.SetCoarseSplatLimit(coarsePageSplats);
                    if (kv.Value.splatCount > previousCount)
                        kv.Value.BeginRefinement(previousCount, Time.realtimeSinceStartup);
                }
            }
            foreach (var kv in m_ParkedCoarse)
            {
                // A smaller reservation must be respected immediately. Growing parked tiers waits
                // until they are used again, avoiding a burst of replacement GPU allocations.
                if (kv.Value != null && kv.Value.splatCount > coarsePageSplats)
                    kv.Value.SetCoarseSplatLimit(coarsePageSplats);
            }
            ResetDetailSlots();
            if (changed)
                OnPagesChanged?.Invoke();
        }

        void ResetDetailSlots()
        {
            m_DetailSlotCapacity = Mathf.Min(requestedDetailSlots, m_DetailSlotLimit);

            // Slots already held stay held; pages left holding one outside the new capacity are
            // downgraded by ReleaseDetailSlots on the next streaming update.
            m_HeldDetailSlots.Clear();
            foreach (var kv in m_Loaded)
            {
                if (kv.Value != null && kv.Value.detailSlot >= 0)
                    m_HeldDetailSlots.Add(kv.Value.detailSlot);
            }

            m_FreeDetailSlots.Clear();
            for (int i = m_DetailSlotCapacity - 1; i >= 0; i--)
            {
                if (!m_HeldDetailSlots.Contains(i))
                    m_FreeDetailSlots.Push(i);
            }
        }

        void OnDestroy()
        {
            UnloadAll();
        }

        public void UnloadAll()
        {
            foreach (var kv in m_Loaded)
                kv.Value.Dispose();
            m_Loaded.Clear();
            foreach (var kv in m_ParkedCoarse)
                kv.Value.Dispose();
            m_ParkedCoarse.Clear();
            m_LoadOrder.Clear();
            m_LoadedList.Clear();
            m_NextPageSlot = 0;
            m_HasLastStreamFocus = false;
            m_HasPendingStreamingWork = true;
            m_LastPageUploadFrame = -1;
            m_LastUploadWasCoarse = false;
            ResetDetailSlots();
            OnPagesChanged?.Invoke();
        }

        /// <summary>
        /// Advance paced page uploads. An in-flight selection can defer ordinary full-detail
        /// transitions while coarse coverage and mandatory residency-limit changes still progress.
        /// </summary>
        public void UpdateStreaming(Camera camera, Transform splatTransform, bool force = false,
            bool allowDetailTransitions = true)
        {
            if (m_PagedScene == null || m_PagedScene.pageCount == 0)
                return;
            // Render callbacks and editor warmup can call us several times in one frame. The
            // upload budget applies to all of them, including force/close-up updates.
            if (m_LastPageUploadFrame == Time.frameCount)
                return;
            if (m_DetailSlotCapacity <= 0)
                ResetDetailSlots();

            Transform xf = splatTransform != null ? splatTransform : m_SplatTransform;
            if (xf == null)
                xf = transform;

            Vector3 focus = camera != null
                ? GaussianSplatRenderSystem.GetStreamingFocusPosition(camera)
                : xf.position;
            Vector3 viewDir = camera != null
                ? GaussianSplatRenderSystem.GetStreamingViewDirection(camera)
                : xf.forward;

            // Close-up: a coarse page under the nose has no leaf data to refine, so never wait
            // on the stream interval when one is that close (edit mode and play).
            if (!force && m_DetailSlotCapacity > 0 && HasCoarsePageWithin(focus, xf, kUrgentCoarseDistance))
                force = true;

            if (!force && ShouldSkipStreamingUpdate(focus, viewDir))
                return;

            m_LastStreamFocus = focus;
            m_HasLastStreamFocus = true;
            m_LastStreamTime = Time.realtimeSinceStartup;
            m_LastStreamViewDir = viewDir;

            m_RankedScratch.Clear();
            var pages = m_PagedScene.pages;
            for (int i = 0; i < pages.Length; i++)
            {
                ref GaussianSplatPageEntry entry = ref pages[i];
                if (entry.pageAsset == null || !entry.pageAsset.IsValid)
                    continue;
                float dist = DistanceToPage(focus, entry, xf);
                m_RankedScratch.Add((entry, dist, DetailRank(focus, viewDir, entry, xf, dist)));
            }
            m_RankedScratch.Sort((a, b) => a.rank.CompareTo(b.rank));

            bool hasPendingCoarse = false;
            for (int i = 0; i < m_RankedScratch.Count; i++)
            {
                if (!m_Loaded.ContainsKey(m_RankedScratch[i].entry.pageId))
                {
                    hasPendingCoarse = true;
                    break;
                }
            }

            // Authoring wants the whole model visible, so load every page at full detail while the
            // scene is small enough to fit comfortably in the atlas. Every page keeps its own atlas
            // region in that mode, so no detail slots are handed out.
            bool changed = false;
            bool uploaded = false;
            if (loadsEveryPageAtFullDetail && !hasPendingCoarse)
            {
                m_HasPendingStreamingWork = false;
                for (int i = 0; i < m_RankedScratch.Count; i++)
                {
                    var entry = m_RankedScratch[i].entry;
                    if (!m_Loaded.TryGetValue(entry.pageId, out var page) || !page.isCoarseStub)
                        continue;
                    m_HasPendingStreamingWork = true;
                    if (allowDetailTransitions && !uploaded && EnsureFullPage(entry, useDetailSlot: false))
                    {
                        changed = uploaded = true;
                        m_LastPageUploadFrame = Time.frameCount;
                        m_LastUploadWasCoarse = false;
                    }
                }

                if (changed)
                    OnPagesChanged?.Invoke();
                return;
            }

            // Pick the pages that deserve full detail, then release slots, then hand them out.
            // Contact range (< 0.5 m) is reserved first. All remaining slots fill by view rank
            // inside the load radius, so nearby pages behind the head cannot monopolize detail.
            m_DetailPageScratch.Clear();
            for (int i = 0; i < m_RankedScratch.Count && m_DetailPageScratch.Count < m_DetailSlotCapacity; i++)
            {
                var (entry, dist, _) = m_RankedScratch[i];
                if (dist > kHighestDetailDistance)
                    continue;
                m_DetailPageScratch.Add(entry.pageId);
            }
            for (int i = 0; i < m_RankedScratch.Count && m_DetailPageScratch.Count < m_DetailSlotCapacity; i++)
            {
                var (entry, dist, _) = m_RankedScratch[i];
                if ((!m_CopyResidency && dist > m_LoadRadius) || m_DetailPageScratch.Contains(entry.pageId))
                    continue;
                m_DetailPageScratch.Add(entry.pageId);
            }

            // Alternate detail upgrades with coarse arrivals during cold start. Loading a new far
            // coarse page on every call used to prevent any close page from upgrading until the
            // entire model was resident, even with the viewer standing inside that page.
            bool preferDetail = !hasPendingCoarse || m_LastUploadWasCoarse;
            bool hasWantedCoarse = false;
            for (int i = 0; i < m_RankedScratch.Count; i++)
            {
                int pageId = m_RankedScratch[i].entry.pageId;
                if (m_DetailPageScratch.Contains(pageId) &&
                    m_Loaded.TryGetValue(pageId, out var page) && page.isCoarseStub)
                {
                    hasWantedCoarse = true;
                    break;
                }
            }

            if (ReleaseDetailSlots(focus, viewDir, xf,
                allowDetailTransitions && preferDetail && hasWantedCoarse))
                changed = true;

            for (int i = 0; i < m_RankedScratch.Count && allowDetailTransitions && preferDetail && !uploaded; i++)
            {
                var entry = m_RankedScratch[i].entry;
                if (!m_DetailPageScratch.Contains(entry.pageId))
                    continue;
                if (!m_Loaded.ContainsKey(entry.pageId))
                    continue; // Coarse not resident yet; nearest-first loop will get it next.
                if (EnsureFullPage(entry, useDetailSlot: true))
                {
                    changed = uploaded = true;
                    m_LastPageUploadFrame = Time.frameCount;
                    m_LastUploadWasCoarse = false;
                }
            }

            // Keep every page covered. Once a detail upload has used this frame's budget, its
            // coarse counterpart waits until the next frame instead of sharing the upload burst.
            for (int i = 0; i < m_RankedScratch.Count && !uploaded; i++)
            {
                var entry = m_RankedScratch[i].entry;
                if (m_Loaded.ContainsKey(entry.pageId) || !LoadCoarseStub(entry))
                    continue;
                changed = uploaded = true;
                m_LastPageUploadFrame = Time.frameCount;
                m_LastUploadWasCoarse = true;
            }

            // Atlas slack can fund a finer permanent tier without taking any detail slots. Replace
            // undersized live prefixes one upload at a time; their old coverage remains resident
            // until the larger payload is ready, including while the viewer is stationary.
            for (int i = 0; i < m_RankedScratch.Count && !uploaded; i++)
            {
                var entry = m_RankedScratch[i].entry;
                if (!RefreshCoarsePrefix(entry))
                    continue;
                changed = uploaded = true;
                m_LastPageUploadFrame = Time.frameCount;
                m_LastUploadWasCoarse = true;
            }

            m_HasPendingStreamingWork = false;
            for (int i = 0; i < m_RankedScratch.Count; i++)
            {
                int pageId = m_RankedScratch[i].entry.pageId;
                if (!m_Loaded.TryGetValue(pageId, out var page) ||
                    (page.isCoarseStub && (loadsEveryPageAtFullDetail || m_DetailPageScratch.Contains(pageId))) ||
                    NeedsCoarseRefresh(m_RankedScratch[i].entry, page))
                {
                    m_HasPendingStreamingWork = true;
                    break;
                }
            }

            if (changed)
                OnPagesChanged?.Invoke();
        }

        bool HasCoarsePageWithin(Vector3 focus, Transform xf, float radius)
        {
            var pages = m_PagedScene.pages;
            for (int i = 0; i < pages.Length; i++)
            {
                ref var entry = ref pages[i];
                if (!m_Loaded.TryGetValue(entry.pageId, out var page) || page == null || !page.isCoarseStub)
                    continue;
                if (DistanceToPage(focus, entry, xf) <= radius)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Detail slots are scarce, so wholly behind-camera pages rank as if they were farther away
        /// at every non-contact distance. Bounds crossing the head plane remain neutral even when
        /// their centre is behind the camera; their forward part can still be visible.
        /// </summary>
        float DetailRank(Vector3 focus, Vector3 viewDir, in GaussianSplatPageEntry entry, Transform xf, float dist)
        {
            // Contact range always wins the slot race — close-ups need their full trees.
            if (dist <= kHighestDetailDistance)
                return dist * 0.001f;
            Bounds editedBounds = GetEditedPageBounds(entry);
            Vector3 localCenter = editedBounds.center;
            Vector3 localExtents = editedBounds.extents;
            Vector3 worldCenter = xf != null ? xf.TransformPoint(localCenter) : localCenter;
            Vector3 axisX = new Vector3(localExtents.x, 0f, 0f);
            Vector3 axisY = new Vector3(0f, localExtents.y, 0f);
            Vector3 axisZ = new Vector3(0f, 0f, localExtents.z);
            if (xf != null)
            {
                axisX = xf.TransformVector(axisX);
                axisY = xf.TransformVector(axisY);
                axisZ = xf.TransformVector(axisZ);
            }
            // Project the complete transformed bounds, including rotation, nonuniform scale and
            // mirrored axes. A centre-only test incorrectly penalizes large pages crossing the view.
            float forwardExtent = Mathf.Abs(Vector3.Dot(viewDir, axisX)) +
                                  Mathf.Abs(Vector3.Dot(viewDir, axisY)) +
                                  Mathf.Abs(Vector3.Dot(viewDir, axisZ));
            float frontmost = Vector3.Dot(worldCenter - focus, viewDir) + forwardExtent;
            float behindWeight = Mathf.Clamp01(-frontmost / Mathf.Max(dist, kHighestDetailDistance));
            return dist + kBehindDetailPenaltyDistance * behindWeight;
        }

        /// <summary>
        /// Drops full-detail pages back to their coarse tier: anything past the unload radius, plus
        /// at most one rank replacement that can actually upload this frame. Hysteresis keeps
        /// recently-left pages at detail while the replacement waits for its upload turn.
        /// </summary>
        bool ReleaseDetailSlots(Vector3 focus, Vector3 viewDir, Transform xf, bool allowRankEviction)
        {
            m_ToDowngradeScratch.Clear();
            m_DowngradeCandidateScratch.Clear();

            int wantedAlreadyFull = 0;
            foreach (var kv in m_Loaded)
            {
                if (kv.Value.isCoarseStub)
                    continue;

                var entryOpt = m_PagedScene.FindPage(kv.Key);
                if (!entryOpt.HasValue)
                {
                    m_ToDowngradeScratch.Add(kv.Key);
                    continue;
                }

                // Full pages too big for their permanent atlas region need a slot to be addressable.
                // A page without one, or holding a slot that the atlas has since dropped, cannot be
                // drawn at all, so send it back to its coarse tier.
                bool needsSlot = kv.Value.splatCount > coarsePageSplats;
                // Small pages already fit in their permanent coarse region. There is no smaller
                // tier to downgrade them to, and re-uploading them at distance only wastes work.
                if (!needsSlot && kv.Value.detailSlot < 0)
                    continue;
                if (kv.Value.detailSlot >= m_DetailSlotCapacity ||
                    (needsSlot && kv.Value.detailSlot < 0))
                {
                    m_ToDowngradeScratch.Add(kv.Key);
                    continue;
                }

                bool isWanted = m_DetailPageScratch.Contains(kv.Key);
                if (isWanted)
                {
                    wantedAlreadyFull++;
                    continue;
                }

                float dist = DistanceToPage(focus, entryOpt.Value, xf);
                if (!m_CopyResidency && dist > m_UnloadRadius)
                    m_ToDowngradeScratch.Add(kv.Key);
                else
                    m_DowngradeCandidateScratch.Add((kv.Key, DetailRank(focus, viewDir, entryOpt.Value, xf, dist)));
            }

            // A single upload can replace at most one page this frame. Evicting the entire wanted
            // set first made a turn temporarily downgrade many visible pages, then refill them one
            // at a time. Slots already being returned by mandatory downgrades cover that demand.
            int shortfall = allowRankEviction
                ? Mathf.Min(1, (m_DetailPageScratch.Count - wantedAlreadyFull) -
                    m_FreeDetailSlots.Count - m_ToDowngradeScratch.Count)
                : 0;
            if (shortfall > 0 && m_DowngradeCandidateScratch.Count > 0)
            {
                m_DowngradeCandidateScratch.Sort((a, b) => b.rank.CompareTo(a.rank));
                float now = Time.realtimeSinceStartup;
                for (int i = 0; i < m_DowngradeCandidateScratch.Count && shortfall > 0; i++)
                {
                    int pageId = m_DowngradeCandidateScratch[i].pageId;
                    // Rank-based eviction is what lets borderline pages ping-pong between full
                    // detail and coarse as the view drifts, which shows up as the scene pulsing
                    // once a second. A page keeps its slot for a minimum time; whatever outranks
                    // it can wait that long, drawing its stand-ins meanwhile. Pages that left the
                    // unload radius or lost their slot to a layout change still drop immediately.
                    if (m_Loaded.TryGetValue(pageId, out var held) &&
                        now - held.detailAcquiredTime < kDetailSlotHoldSeconds)
                        continue;
                    m_ToDowngradeScratch.Add(pageId);
                    shortfall--;
                }
            }

            bool changed = false;
            for (int i = 0; i < m_ToDowngradeScratch.Count; i++)
            {
                int pageId = m_ToDowngradeScratch[i];
                if (!m_Loaded.ContainsKey(pageId))
                    continue;

                var entryOpt = m_PagedScene.FindPage(pageId);
                if (!entryOpt.HasValue)
                    RemovePage(pageId);
                else
                    ReplaceWithCoarseStub(entryOpt.Value);
                changed = true;
            }
            return changed;
        }

        bool ShouldSkipStreamingUpdate(Vector3 focus, Vector3 viewDir)
        {
            if (!m_HasLastStreamFocus)
                return false;

            float moved = Vector3.Distance(focus, m_LastStreamFocus);
            float turnedDeg = Vector3.Angle(viewDir, m_LastStreamViewDir);
            float elapsed = Time.realtimeSinceStartup - m_LastStreamTime;

            // A stationary headset still needs to finish loading and retry pages whose previous
            // detail owner is waiting out its hold time. Movement only gates settled streaming.
            if (m_HasPendingStreamingWork)
                return elapsed < Mathf.Min(m_StreamUpdateInterval, 0.05f);

            // Rotation-only looks (Scene View orbit, VR look-around) must re-rank detail slots.
            // Position-only skip left the old view's pages loaded and the new facing direction empty.
            if (turnedDeg >= kStreamRotateThresholdDeg)
            {
                float rotInterval = Mathf.Min(m_StreamUpdateInterval, kStreamRotateInterval);
                return elapsed < rotInterval;
            }

            // In play/VR the headset translates continuously, so once it has moved meaningfully
            // use a shorter interval so pages underfoot upgrade before the user walks past them.
            float interval = m_StreamUpdateInterval;
            if (Application.isPlaying && moved >= m_StreamMoveThreshold * 0.25f)
                interval = Mathf.Min(interval, 0.1f);

            if (elapsed < interval)
                return true;

            return moved < m_StreamMoveThreshold;
        }

        /// <summary>
        /// Distance from a world-space focus to the nearest edge of a loaded page (0 inside it).
        /// Used by the renderer to boost LoD priority for pages the viewer is standing in or near.
        /// </summary>
        public float DistanceToLoadedPage(Vector3 worldFocus, SplatBoxPageGpuState page, Transform splatTransform)
        {
            if (page == null || m_PagedScene == null)
                return float.MaxValue;
            var entry = m_PagedScene.FindPage(page.pageId);
            if (!entry.HasValue)
                return float.MaxValue;
            return DistanceToPage(worldFocus, entry.Value, splatTransform);
        }

        /// <summary>
        /// Distance from the focus point to the nearest part of a page, zero while standing inside it.
        /// Pages are grid cells many metres across, so their centres say little about how close their
        /// content is: measured centre to centre, the page under your feet reports the distance to its
        /// far side and loses its detail slot to smaller neighbours you are only looking past.
        /// </summary>
        float DistanceToPage(Vector3 worldFocus, GaussianSplatPageEntry entry, Transform splatTransform)
        {
            Bounds bounds = GetEditedPageBounds(entry);
            if (splatTransform == null)
                return DistanceToBounds(worldFocus, bounds.min, bounds.max);

            // Bounds are axis aligned in the splat's own space, so the test runs there and the
            // resulting distance is converted back. Exact for the usual uniform scale; a non-uniform
            // one has no single conversion, and the mean keeps it between the per-axis extremes.
            Vector3 local = splatTransform.InverseTransformPoint(worldFocus);
            Vector3 scale = splatTransform.lossyScale;
            float unitsPerLocal = (Mathf.Abs(scale.x) + Mathf.Abs(scale.y) + Mathf.Abs(scale.z)) / 3f;
            return DistanceToBounds(local, bounds.min, bounds.max) * unitsPerLocal;
        }

        static float DistanceToBounds(Vector3 p, Vector3 min, Vector3 max)
        {
            float dx = Mathf.Max(Mathf.Max(min.x - p.x, 0f), p.x - max.x);
            float dy = Mathf.Max(Mathf.Max(min.y - p.y, 0f), p.y - max.y);
            float dz = Mathf.Max(Mathf.Max(min.z - p.z, 0f), p.z - max.z);
            return Mathf.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        bool LoadCoarseStub(GaussianSplatPageEntry entry)
        {
            var state = TakeParkedCoarse(entry.pageId);
            if (state == null)
            {
                state = SplatBoxPageGpuState.UploadCoarseLevel(entry.pageAsset, m_NextPageSlot, coarsePageSplats);
                if (state == null)
                    return false;
                m_NextPageSlot++;
            }

            m_Loaded[entry.pageId] = state;
            m_LoadedList.Add(state);
            m_LoadOrder.Add(entry.pageId);
            return true;
        }

        bool NeedsCoarseRefresh(in GaussianSplatPageEntry entry, SplatBoxPageGpuState state) =>
            state != null && state.isCoarseStub && entry.pageAsset != null &&
            entry.pageAsset.hasLevelOrderLodTree &&
            state.splatCount < Mathf.Min(coarsePageSplats, entry.pageAsset.splatCount);

        bool RefreshCoarsePrefix(in GaussianSplatPageEntry entry)
        {
            if (!m_Loaded.TryGetValue(entry.pageId, out var previous) || !NeedsCoarseRefresh(entry, previous))
                return false;

            int previousCount = previous.splatCount;
            if (previous.SetCoarseSplatLimit(coarsePageSplats))
            {
                previous.BeginRefinement(previousCount, Time.realtimeSinceStartup);
                return true;
            }

            // Upload before replacing ownership: a failed allocation must leave the old page's
            // payload and frontier intact. The renderer recopies the new prefix at its fixed address.
            var replacement = SplatBoxPageGpuState.UploadCoarseLevel(entry.pageAsset, previous.pageSlot,
                coarsePageSplats);
            if (replacement == null)
                return false;
            replacement.BeginRefinement(previousCount, Time.realtimeSinceStartup);
            int listIndex = m_LoadedList.IndexOf(previous);
            m_Loaded[entry.pageId] = replacement;
            if (listIndex >= 0)
                m_LoadedList[listIndex] = replacement;
            else
                m_LoadedList.Add(replacement);
            previous.Dispose();
            return true;
        }

        /// <summary>
        /// Takes a page's coarse tier out of the parked set. Coarse tiers are cheap to keep and
        /// expensive to rebuild, so they survive the round trip through full detail.
        /// </summary>
        SplatBoxPageGpuState TakeParkedCoarse(int pageId)
        {
            if (!m_ParkedCoarse.TryGetValue(pageId, out var state))
                return null;
            m_ParkedCoarse.Remove(pageId);
            if (state == null || !state.IsReady)
            {
                state?.Dispose();
                return null;
            }
            int previousCount = state.splatCount;
            if (state.SetCoarseSplatLimit(coarsePageSplats) && state.splatCount > previousCount)
                state.BeginRefinement(previousCount, Time.realtimeSinceStartup);
            return state;
        }

        void ParkCoarse(int pageId, SplatBoxPageGpuState coarse)
        {
            if (coarse == null)
                return;
            if (m_ParkedCoarse.TryGetValue(pageId, out var previous) && !ReferenceEquals(previous, coarse))
                previous?.Dispose();
            m_ParkedCoarse[pageId] = coarse;
        }

        bool EnsureFullPage(GaussianSplatPageEntry entry, bool useDetailSlot)
        {
            if (m_Loaded.TryGetValue(entry.pageId, out var existing) && !existing.isCoarseStub)
                return false;

            int detailSlot = -1;
            if (useDetailSlot)
            {
                if (m_FreeDetailSlots.Count == 0)
                    return false; // No atlas room right now; the page stays coarse until one frees up.
                detailSlot = m_FreeDetailSlots.Pop();
            }

            int slot = existing?.pageSlot ?? m_NextPageSlot++;
            var state = SplatBoxPageGpuState.Upload(entry.pageAsset, slot);
            if (state == null)
            {
                if (detailSlot >= 0)
                    m_FreeDetailSlots.Push(detailSlot);
                return false;
            }
            state.detailSlot = detailSlot;
            state.detailAcquiredTime = Time.realtimeSinceStartup;
            if (existing != null)
                state.BeginRefinement(existing.splatCount, state.detailAcquiredTime);

            int listIndex = existing != null ? m_LoadedList.IndexOf(existing) : -1;
            ParkCoarse(entry.pageId, existing);

            m_Loaded[entry.pageId] = state;
            // Replace in place so page ordering — and therefore every other page's atlas address —
            // stays put.
            if (listIndex >= 0)
            {
                m_LoadedList[listIndex] = state;
            }
            else
            {
                m_LoadedList.Add(state);
                m_LoadOrder.Add(entry.pageId);
            }
            return true;
        }

        void ReplaceWithCoarseStub(GaussianSplatPageEntry entry)
        {
            if (!m_Loaded.TryGetValue(entry.pageId, out var existing) || existing.isCoarseStub)
                return;

            int slot = existing.pageSlot;
            int listIndex = m_LoadedList.IndexOf(existing);
            ReturnDetailSlot(existing.detailSlot);
            existing.Dispose();

            var state = TakeParkedCoarse(entry.pageId)
                        ?? SplatBoxPageGpuState.UploadCoarseLevel(entry.pageAsset, slot, coarsePageSplats);
            if (state == null)
            {
                if (listIndex >= 0)
                    m_LoadedList.RemoveAt(listIndex);
                m_Loaded.Remove(entry.pageId);
                m_LoadOrder.Remove(entry.pageId);
                return;
            }

            state.pageSlot = slot;
            m_Loaded[entry.pageId] = state;
            if (listIndex >= 0)
                m_LoadedList[listIndex] = state;
            else
                m_LoadedList.Add(state);
        }

        void RemovePage(int pageId)
        {
            if (!m_Loaded.TryGetValue(pageId, out var state))
                return;
            ReturnDetailSlot(state.detailSlot);
            state.Dispose();
            m_Loaded.Remove(pageId);
            m_LoadedList.Remove(state);
            m_LoadOrder.Remove(pageId);
        }

        void ReturnDetailSlot(int slot)
        {
            // A layout shrink retires the upper slots. Returning them to the free pool would let
            // the next page acquire an atlas address that no longer exists.
            if (slot >= 0 && slot < m_DetailSlotCapacity)
                m_FreeDetailSlots.Push(slot);
        }

        /// <summary>
        /// Marks every page as needing a fresh copy into the atlas. Parked coarse tiers are included:
        /// they still believe their data is resident, which stops being true once the atlas is
        /// reallocated underneath them.
        /// </summary>
        public void InvalidateAtlasResidency()
        {
            for (int i = 0; i < m_LoadedList.Count; i++)
            {
                if (m_LoadedList[i] != null)
                    m_LoadedList[i].uploadedAtlasOffset = -1;
            }
            foreach (var kv in m_ParkedCoarse)
            {
                if (kv.Value != null)
                    kv.Value.uploadedAtlasOffset = -1;
            }
        }

        public bool TryGetPageState(int pageId, out SplatBoxPageGpuState state) =>
            m_Loaded.TryGetValue(pageId, out state);

        public SplatBoxPageGpuState GetPageBySlot(int pageSlot)
        {
            for (int i = 0; i < m_LoadedList.Count; i++)
            {
                if (m_LoadedList[i].pageSlot == pageSlot)
                    return m_LoadedList[i];
            }
            return null;
        }
    }
}
