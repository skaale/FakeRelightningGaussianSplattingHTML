// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        sealed class PagedAttractorState : IDisposable
        {
            public GaussianSplatPageAsset source;
            public int pageId, revision, sculptRevision = -1, sculptEpoch = -1, sculptCount = -1;
            public List<PagedSmudgeDab> sculptJournal;
            public Bounds originalBounds;
            public NativeArray<float3> original, baseline, offsets, velocities, bounds;
            public NativeArray<byte> changed;
            public JobHandle job;
            public int count => original.IsCreated ? original.Length : 0;
            public void Dispose()
            {
                job.Complete();
                if (original.IsCreated) original.Dispose();
                if (baseline.IsCreated) baseline.Dispose();
                if (offsets.IsCreated) offsets.Dispose();
                if (velocities.IsCreated) velocities.Dispose();
                if (bounds.IsCreated) bounds.Dispose();
                if (changed.IsCreated) changed.Dispose();
            }
        }

        sealed class PagedAttractorTree
        {
            public LodTreeRuntime baseline, published;
            public Bounds baselineBounds, publishedBounds;
            public int revision = -1;
            public int sculptRevision = -1, sculptEpoch = -1;
            // One live snapshot, one retained by the selection worker and one writable buffer.
            public readonly LodTreeRuntime[] snapshots = new LodTreeRuntime[3];
            public LodTreeRuntime pending;
            public SplatBoxPageGpuState pendingPage;
            public PagedAttractorState pendingState;
            public JobHandle refitJob;
            public GCHandle sourcePin, destinationPin, childPin, childStartPin;

            public void CompleteRefit()
            {
                try { refitJob.Complete(); }
                finally
                {
                    if (sourcePin.IsAllocated) sourcePin.Free();
                    if (destinationPin.IsAllocated) destinationPin.Free();
                    if (childPin.IsAllocated) childPin.Free();
                    if (childStartPin.IsAllocated) childStartPin.Free();
                }
            }
        }

        readonly Dictionary<GaussianSplatPageAsset, PagedAttractorState> m_PagedAttractorSources =
            new Dictionary<GaussianSplatPageAsset, PagedAttractorState>();
        readonly Dictionary<int, PagedAttractorState> m_PagedAttractorSynthetic = new Dictionary<int, PagedAttractorState>();
        readonly List<PagedAttractorState> m_PagedAttractorStates = new List<PagedAttractorState>();
        readonly Dictionary<SplatBoxPageGpuState, PagedAttractorTree> m_PagedAttractorTrees =
            new Dictionary<SplatBoxPageGpuState, PagedAttractorTree>();
        readonly List<SplatBoxPageGpuState> m_PagedAttractorDisposedTrees = new List<SplatBoxPageGpuState>();
        readonly List<PagedAttractorTree> m_PagedAttractorRefits = new List<PagedAttractorTree>();
        NativeArray<AttractorData> m_PagedAttractorForces;
        NativeArray<PagedAttractorForceData> m_PagedAttractorPreparedForces;
        readonly List<AttractorData> m_PagedAttractorValidForces = new List<AttractorData>();
        GaussianSplatPagedScene m_PagedAttractorScene;
        Vector3 m_PagedAttractorDisplacementMin, m_PagedAttractorDisplacementMax;
        double m_PagedAttractorLastTick = -1, m_PagedAttractorAccumulator;
        float m_PagedAttractorTime;
        bool m_PagedAttractorTickWasEnabled;

        bool HasPagedAttractorState => UsesPagedLod && m_PagedAttractorScene == m_PagedScene && m_PagedAttractorStates.Count > 0;

        void EnsurePagedAttractorSource()
        {
            if (m_PagedAttractorScene == m_PagedScene) return;
            DisposePagedAttractors();
            m_PagedAttractorScene = m_PagedScene;
        }

        void SetPagedAttractorData(AttractorData[] values)
        {
            if (!UsesPagedLod) return;
            EnsurePagedAttractorSource();
            var valid = m_PagedAttractorValidForces;
            valid.Clear();
            if (values != null)
                foreach (var value in values)
                {
                    if (value.enabled < .5f || value.mode < 0 || value.mode > 3 || value.range <= 0 ||
                        !PagedEraseFinite(value.position) || !PagedEraseFinite(value.scale) ||
                        !PagedEraseFinite(value.strength) || !PagedEraseFinite(value.range) ||
                        !PagedEraseFinite(value.falloff) || !PagedEraseFinite(value.vortexHeight) ||
                        !PagedEraseFinite(value.waveFrequency) || !PagedEraseFinite(value.waveAmplitude) ||
                        !PagedEraseFinite(value.waveSpeed) || !PagedEraseFinite(value.curlStrength) ||
                        !PagedEraseFinite(value.secondaryFrequency) ||
                        !PagedEraseFinite(new Vector4(value.rotation.x, value.rotation.y, value.rotation.z, value.rotation.w))) continue;
                    valid.Add(value);
                }
            int previousCount = m_PagedAttractorForces.IsCreated ? m_PagedAttractorForces.Length : 0;
            bool resized = !m_PagedAttractorForces.IsCreated || m_PagedAttractorForces.Length != valid.Count;
            if (resized)
            {
                if (m_PagedAttractorForces.IsCreated) m_PagedAttractorForces.Dispose();
                m_PagedAttractorForces = new NativeArray<AttractorData>(valid.Count, Allocator.Persistent);
            }
            if (!m_PagedAttractorPreparedForces.IsCreated || m_PagedAttractorPreparedForces.Length != valid.Count)
            {
                if (m_PagedAttractorPreparedForces.IsCreated) m_PagedAttractorPreparedForces.Dispose();
                m_PagedAttractorPreparedForces = new NativeArray<PagedAttractorForceData>(valid.Count, Allocator.Persistent);
                resized = true;
            }
            for (int i = 0; i < valid.Count; i++)
            {
                var value = valid[i];
                if (!resized && SamePagedAttractorData(m_PagedAttractorForces[i], value)) continue;
                m_PagedAttractorForces[i] = value;
                m_PagedAttractorPreparedForces[i] = PagedAttractorForceData.Prepare(value);
            }
            if (previousCount > 0 && valid.Count == 0) ClearPagedAttractorVelocities();
        }

        static bool SamePagedAttractorData(AttractorData a, AttractorData b) =>
            a.position.Equals(b.position) && a.rotation.Equals(b.rotation) && a.scale.Equals(b.scale) &&
            a.strength == b.strength && a.range == b.range && a.falloff == b.falloff && a.mode == b.mode &&
            a.enabled == b.enabled && a.vortexHeight == b.vortexHeight && a.waveFrequency == b.waveFrequency &&
            a.waveAmplitude == b.waveAmplitude && a.waveSpeed == b.waveSpeed && a.waveAxis == b.waveAxis &&
            a.curlStrength == b.curlStrength && a.secondaryFrequency == b.secondaryFrequency;

        void TickPagedAttractors()
        {
            if (!UsesPagedLod || !m_EnableWind || !m_PagedAttractorForces.IsCreated || m_PagedAttractorForces.Length == 0)
            {
                if (m_PagedAttractorTickWasEnabled) ClearPagedAttractorVelocities();
                m_PagedAttractorTickWasEnabled = false;
                m_PagedAttractorLastTick = -1;
                m_PagedAttractorAccumulator = 0;
                return;
            }
            m_PagedAttractorTickWasEnabled = true;
            double now = Time.realtimeSinceStartupAsDouble;
#if UNITY_EDITOR
            if (!Application.isPlaying) now = UnityEditor.EditorApplication.timeSinceStartup;
#endif
            if (m_PagedAttractorLastTick < 0) { m_PagedAttractorLastTick = now; return; }
            double elapsed = Math.Max(0, now - m_PagedAttractorLastTick);
            m_PagedAttractorLastTick = now;
            m_PagedAttractorAccumulator += Math.Min(elapsed, 1.0 / 15.0);
            const float step = 1f / 60f;
            int steps = 0;
            float firstStepTime = 0;
            while (m_PagedAttractorAccumulator >= step && steps < 4)
            {
                m_PagedAttractorTime += step;
                if (steps == 0) firstStepTime = m_PagedAttractorTime;
                steps++;
                m_PagedAttractorAccumulator -= step;
            }
            // Integrate the same fixed substeps inside each node job: one schedule, memory pass,
            // bounds reduction and publication even when a slow frame needs four catch-up steps.
            if (steps > 0 && SimulatePagedAttractorSubsteps(step, firstStepTime, steps, out bool moved))
                PublishPagedAttractorStep(moved);
        }

        // Explicit deterministic hook for validation. Animation is transient; saved sculpt edits
        // remain the baseline and neither source assets nor their persistent journals are mutated.
        void StepPagedAttractors(float deltaTime, float time)
        {
            if (SimulatePagedAttractors(deltaTime, time, out bool moved)) PublishPagedAttractorStep(moved);
        }

        bool SimulatePagedAttractors(float deltaTime, float time, out bool moved) =>
            SimulatePagedAttractorSubsteps(deltaTime, time, 1, out moved);

        bool SimulatePagedAttractorSubsteps(float deltaTime, float time, int substeps, out bool moved)
        {
            moved = false;
            if (!UsesPagedLod || !m_EnableWind || !PagedEraseFinite(deltaTime) || deltaTime <= 0 ||
                !PagedEraseFinite(time) || !m_PagedAttractorForces.IsCreated || m_PagedAttractorForces.Length == 0) return false;
            EnsurePagedAttractorSource();
            if (!m_PagedAttractorForces.IsCreated || m_PagedAttractorForces.Length == 0) return false;
            m_PagedAttractorTickWasEnabled = true;
            deltaTime = Mathf.Min(deltaTime, 1f / 15f);
            Matrix4x4 localToWorld = transform.localToWorldMatrix, worldToLocal = transform.worldToLocalMatrix;
            if (!PagedEraseFinite(localToWorld.determinant) || Mathf.Abs(localToWorld.determinant) < 1e-12f) return false;
            RefreshPagedSmudgeHierarchyJournal();
            AdmitPagedAttractorSources(localToWorld);
            float velocityRetention = math.pow(.995f, deltaTime / .016f);
            float dampingRetention = Mathf.Max(0f, 1f - Mathf.Clamp01(m_WindDamping) * deltaTime * 2f);
            float minimumVelocity = Mathf.Max(0, m_WindMinVelocity);
            for (int s = 0; s < m_PagedAttractorStates.Count; s++)
            {
                var state = m_PagedAttractorStates[s];
                RefreshPagedAttractorBaseline(state);
                var step = new PagedAttractorStepJob
                {
                    baseline = state.baseline, offsets = state.offsets, velocities = state.velocities,
                    attractors = m_PagedAttractorPreparedForces, changed = state.changed,
                    localToWorld = localToWorld, worldToLocal = worldToLocal, deltaTime = deltaTime, time = time,
                    substeps = Mathf.Clamp(substeps, 1, 4), velocityRetention = velocityRetention,
                    dampingRetention = dampingRetention, minimumVelocitySquared = minimumVelocity * minimumVelocity
                };
                var simulation = step.Schedule(state.count, 256);
                state.job = new PagedAttractorBoundsJob { offsets = state.offsets, changed = state.changed,
                    bounds = state.bounds }.Schedule(simulation);
            }
            for (int s = 0; s < m_PagedAttractorStates.Count; s++)
            {
                var state = m_PagedAttractorStates[s];
                state.job.Complete();
                if (state.bounds[2].x != 0) { state.revision++; moved = true; }
            }
            return true;
        }

        void PublishPagedAttractorStep(bool moved)
        {
            m_PagedAttractorDisplacementMin = m_PagedAttractorDisplacementMax = Vector3.zero;
            for (int s = 0; s < m_PagedAttractorStates.Count; s++)
            {
                var state = m_PagedAttractorStates[s];
                m_PagedAttractorDisplacementMin = Vector3.Min(m_PagedAttractorDisplacementMin, state.bounds[0]);
                m_PagedAttractorDisplacementMax = Vector3.Max(m_PagedAttractorDisplacementMax, state.bounds[1]);
                PublishPagedAttractorStreamingBounds(state);
            }
            EnsurePagedAttractorHierarchy();
            if (moved)
            {
                editModified = true;
                RefreshPagedAttractorGpuOffsets();
                NotifyPagedAttractorMotion();
#if UNITY_EDITOR
                if (!Application.isPlaying) UnityEditor.SceneView.RepaintAll();
#endif
            }
        }

        bool PagedAttractorIntersects(Bounds localBounds, Matrix4x4 localToWorld)
        {
            Vector3 center = localToWorld.MultiplyPoint3x4(localBounds.center), e = localBounds.extents;
            Vector3 extent = new Vector3(
                Mathf.Abs(localToWorld.m00) * e.x + Mathf.Abs(localToWorld.m01) * e.y + Mathf.Abs(localToWorld.m02) * e.z,
                Mathf.Abs(localToWorld.m10) * e.x + Mathf.Abs(localToWorld.m11) * e.y + Mathf.Abs(localToWorld.m12) * e.z,
                Mathf.Abs(localToWorld.m20) * e.x + Mathf.Abs(localToWorld.m21) * e.y + Mathf.Abs(localToWorld.m22) * e.z);
            var world = new Bounds(center, extent * 2f);
            for (int i = 0; i < m_PagedAttractorForces.Length; i++)
            {
                var force = m_PagedAttractorForces[i];
                float scale = Mathf.Max(Mathf.Max(Mathf.Abs(force.scale.x), Mathf.Abs(force.scale.y)),
                    Mathf.Max(Mathf.Abs(force.scale.z), .0001f));
                float radius = force.range * scale;
                if (world.SqrDistance(force.position) <= radius * radius) return true;
            }
            return false;
        }

        void AdmitPagedAttractorSources(Matrix4x4 localToWorld)
        {
            var entries = m_PagedScene.pages;
            if (entries != null)
                for (int i = 0; i < entries.Length; i++)
                {
                    var source = entries[i].pageAsset;
                    if (source == null || m_PagedAttractorSources.ContainsKey(source) || !source.IsValid ||
                        !PagedAttractorIntersects(ExpandPagedSmudgeBoundsUnchecked(source.bounds), localToWorld)) continue;
                    CreatePagedAttractorSource(source, entries[i].pageId);
                }
            var loaded = m_LodStreamer?.loadedPages;
            if (loaded == null) return;
            for (int i = 0; i < loaded.Count; i++)
            {
                var page = loaded[i];
                if (page?.lodTree?.nodes == null) continue;
                if (page.source != null && page.source.IsValid)
                {
                    if (!m_PagedAttractorSources.ContainsKey(page.source) &&
                        PagedAttractorIntersects(ExpandPagedSmudgeBoundsUnchecked(page.source.bounds), localToWorld))
                        CreatePagedAttractorSource(page.source, page.pageId);
                    continue;
                }
                if (m_PagedAttractorSynthetic.ContainsKey(page.pageId) || !PagedAttractorIntersects(page.bounds, localToWorld)) continue;
                var tree = PagedAttractorBaseTree(page);
                if (m_PagedSmudgeTrees.TryGetValue(page, out var sculpt)) tree = sculpt.original;
                Vector3[] originals = ReadPagedSculptOriginalPositions(page, tree);
                var state = AllocatePagedAttractorState(originals.Length, page.pageId, page.bounds);
                for (int n = 0; n < originals.Length; n++) state.original[n] = originals[n];
                m_PagedAttractorSynthetic.Add(page.pageId, state);
            }
        }

        void CreatePagedAttractorSource(GaussianSplatPageAsset source, int pageId)
        {
            var asset = source.splatData;
            if (asset?.posData == null) return;
            var positions = asset.posData.GetData<byte>();
            int stride = GaussianSplatAsset.GetVectorSize(asset.posFormat);
            int count = Mathf.Min(source.lodNodeCount, asset.splatCount, positions.Length / stride);
            if (count <= 0) return;
            var state = AllocatePagedAttractorState(count, pageId, source.bounds);
            state.source = source;
            NativeArray<GaussianSplatAsset.ChunkInfo> chunks = default;
            if (asset.chunkData != null && asset.chunkData.dataSize > 0) chunks = asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>();
            for (int i = 0; i < count; i++)
            {
                float3 position = DecodePagedSculptRawPosition(positions, i * stride, asset.posFormat);
                int chunk = i / GaussianSplatAsset.kChunkSize;
                if (chunks.IsCreated && chunk < chunks.Length)
                {
                    var c = chunks[chunk];
                    position = math.lerp(new float3(c.posX.x, c.posY.x, c.posZ.x), new float3(c.posX.y, c.posY.y, c.posZ.y), position);
                }
                state.original[i] = position;
            }
            m_PagedAttractorSources.Add(source, state);
        }

        PagedAttractorState AllocatePagedAttractorState(int count, int pageId, Bounds bounds)
        {
            var state = new PagedAttractorState { pageId = pageId, originalBounds = bounds };
            try
            {
                state.original = new NativeArray<float3>(count, Allocator.Persistent);
                state.baseline = new NativeArray<float3>(count, Allocator.Persistent);
                state.offsets = new NativeArray<float3>(count, Allocator.Persistent);
                state.velocities = new NativeArray<float3>(count, Allocator.Persistent);
                state.changed = new NativeArray<byte>(count, Allocator.Persistent);
                state.bounds = new NativeArray<float3>(3, Allocator.Persistent);
                m_PagedAttractorStates.Add(state);
                return state;
            }
            catch { state.Dispose(); throw; }
        }

        void RefreshPagedAttractorBaseline(PagedAttractorState state)
        {
            int count = HasPagedSmudgeJournal ? m_PagedSmudgeDabs.Count : 0;
            if (state.sculptRevision == m_PagedSmudgeRevision && state.sculptEpoch == m_PagedSmudgeHierarchyEpoch &&
                state.sculptCount == count && ReferenceEquals(state.sculptJournal, m_PagedSmudgeDabs)) return;
            for (int n = 0; n < state.count; n++)
            {
                Vector3 original = state.original[n], position = original;
                for (int d = 0; d < m_PagedSmudgeHierarchyDabs.Count; d++)
                    position = ApplyPagedSculptPoint(position, original, m_PagedSmudgeHierarchyDabs[d]);
                state.baseline[n] = position;
            }
            state.sculptRevision = m_PagedSmudgeRevision;
            state.sculptEpoch = m_PagedSmudgeHierarchyEpoch;
            state.sculptCount = count;
            state.sculptJournal = m_PagedSmudgeDabs;
            state.revision++;
        }

        PagedAttractorState FindPagedAttractorState(SplatBoxPageGpuState page)
        {
            if (!HasPagedAttractorState || page == null) return null;
            if (page.source != null && m_PagedAttractorSources.TryGetValue(page.source, out var source)) return source;
            return m_PagedAttractorSynthetic.TryGetValue(page.pageId, out var synthetic) ? synthetic : null;
        }

        LodTreeRuntime PagedAttractorBaseTree(SplatBoxPageGpuState page) =>
            m_PagedAttractorTrees.TryGetValue(page, out var cached) && ReferenceEquals(page.lodTree, cached.published)
                ? cached.baseline : page.lodTree;

        void RestorePagedAttractorHierarchyBase()
        {
            foreach (var pair in m_PagedAttractorTrees)
                if (ReferenceEquals(pair.Key.lodTree, pair.Value.published))
                {
                    pair.Key.lodTree = pair.Value.baseline;
                    pair.Key.bounds = pair.Value.baselineBounds;
                }
        }

        LodTreeRuntime GetWritablePagedAttractorSnapshot(PagedAttractorTree cache, LodTreeRuntime baseline)
        {
            for (int i = 0; i < cache.snapshots.Length; i++)
            {
                var snapshot = cache.snapshots[i];
                if (snapshot != null && (ReferenceEquals(snapshot, cache.published) ||
                    (m_LodSelectionWorker?.IsUsingNodeSnapshot(snapshot.nodes) ?? false))) continue;
                if (snapshot == null || snapshot.nodes.Length != baseline.nodes.Length)
                    cache.snapshots[i] = snapshot = new LodTreeRuntime { nodes = new LodTreeNode[baseline.nodes.Length] };
                snapshot.childTable = baseline.childTable;
                snapshot.childTableStart = baseline.childTableStart;
                snapshot.leafCount = baseline.leafCount;
                snapshot.levelOrder = baseline.levelOrder;
                return snapshot;
            }
            // There can be only one worker snapshot per page and one current publication.
            throw new InvalidOperationException("Paged attractor snapshots are all in use.");
        }

        unsafe void EnsurePagedAttractorHierarchy()
        {
            if (!HasPagedAttractorState) return;
            RefreshPagedSmudgeHierarchyJournal();
            var pages = m_LodStreamer?.loadedPages;
            if (pages == null) return;
            bool changed = false, topologyChanged = false;
            m_PagedAttractorRefits.Clear();
            try
            {
                for (int p = 0; p < pages.Count; p++)
                {
                    var page = pages[p];
                    var state = FindPagedAttractorState(page);
                    if (state == null || page?.lodTree?.nodes == null) continue;
                    state.job.Complete();
                    RefreshPagedAttractorBaseline(state);
                    var tree = PagedAttractorBaseTree(page);
                    if (!m_PagedAttractorTrees.TryGetValue(page, out var cache))
                        m_PagedAttractorTrees.Add(page, cache = new PagedAttractorTree());
                    if (ReferenceEquals(tree, cache.baseline) && cache.revision == state.revision)
                    {
                        page.lodTree = cache.published;
                        page.bounds = cache.publishedBounds;
                        continue;
                    }
                    Bounds baselineBounds = ReferenceEquals(page.lodTree, cache.published) && ReferenceEquals(tree, cache.baseline)
                        ? cache.baselineBounds : page.bounds;
                    topologyChanged |= !ReferenceEquals(tree, cache.baseline) ||
                        cache.sculptRevision != state.sculptRevision || cache.sculptEpoch != state.sculptEpoch;
                    cache.baseline = tree;
                    cache.baselineBounds = baselineBounds;
                    cache.pending = GetWritablePagedAttractorSnapshot(cache, tree);
                    cache.pendingPage = page;
                    cache.pendingState = state;
                    // Register before pinning/scheduling, so a partial failure releases every pin.
                    cache.refitJob = default;
                    m_PagedAttractorRefits.Add(cache);
                    cache.sourcePin = GCHandle.Alloc(tree.nodes, GCHandleType.Pinned);
                    cache.destinationPin = GCHandle.Alloc(cache.pending.nodes, GCHandleType.Pinned);
                    if (tree.childTable != null) cache.childPin = GCHandle.Alloc(tree.childTable, GCHandleType.Pinned);
                    if (tree.childTableStart != null) cache.childStartPin = GCHandle.Alloc(tree.childTableStart, GCHandleType.Pinned);
                    float displacement = math.length(math.max(-state.bounds[0], state.bounds[1]));
                    cache.refitJob = new PagedAttractorRefitJob
                    {
                        source = (LodTreeNode*)cache.sourcePin.AddrOfPinnedObject(),
                        destination = (LodTreeNode*)cache.destinationPin.AddrOfPinnedObject(),
                        childTable = cache.childPin.IsAllocated ? (int*)cache.childPin.AddrOfPinnedObject() : null,
                        childTableStart = cache.childStartPin.IsAllocated ? (int*)cache.childStartPin.AddrOfPinnedObject() : null,
                        baseline = state.baseline, offsets = state.offsets,
                        nodeCount = tree.nodes.Length, movingCount = Mathf.Min(tree.nodes.Length, state.count),
                        // The source tree already encloses the sculpted geometry.
                        maximumDisplacement = displacement,
                        coarse = page.isCoarseStub
                    }.Schedule();
                }
                // Schedule every page before waiting so large models use the worker pool instead
                // of repeatedly traversing millions of nodes in managed code on the main thread.
                for (int i = 0; i < m_PagedAttractorRefits.Count; i++) m_PagedAttractorRefits[i].refitJob.Complete();
                for (int i = 0; i < m_PagedAttractorRefits.Count; i++)
                {
                    var cache = m_PagedAttractorRefits[i];
                    cache.published = cache.pending;
                    cache.published.rootExtent = cache.published.nodes[0].featureSize;
                    cache.publishedBounds = PagedAttractorStateBounds(cache.pendingState);
                    cache.revision = cache.pendingState.revision;
                    cache.sculptRevision = cache.pendingState.sculptRevision;
                    cache.sculptEpoch = cache.pendingState.sculptEpoch;
                    cache.pendingPage.lodTree = cache.published;
                    cache.pendingPage.bounds = cache.publishedBounds;
                    PublishPagedAttractorStreamingBounds(cache.pendingState);
                    changed = true;
                }
            }
            finally
            {
                Exception completionFailure = null;
                for (int i = 0; i < m_PagedAttractorRefits.Count; i++)
                {
                    var cache = m_PagedAttractorRefits[i];
                    try { cache.CompleteRefit(); }
                    catch (Exception ex) { completionFailure ??= ex; }
                    cache.pending = null;
                    cache.pendingPage = null;
                    cache.pendingState = null;
                }
                m_PagedAttractorRefits.Clear();
                if (completionFailure != null) throw completionFailure;
            }
            m_PagedAttractorDisposedTrees.Clear();
            foreach (var pair in m_PagedAttractorTrees) if (pair.Key.lodTree == null) m_PagedAttractorDisposedTrees.Add(pair.Key);
            foreach (var page in m_PagedAttractorDisposedTrees) m_PagedAttractorTrees.Remove(page);
            if (changed)
            {
                NotifyPagedAttractorHierarchyChanged(topologyChanged);
                ForceResort();
            }
        }

        Bounds PagedAttractorStateBounds(PagedAttractorState state)
        {
            var bounds = ExpandPagedSmudgeBoundsUnchecked(state.originalBounds);
            bounds.SetMinMax(bounds.min + (Vector3)state.bounds[0], bounds.max + (Vector3)state.bounds[1]);
            return bounds;
        }

        void PublishPagedAttractorStreamingBounds(PagedAttractorState state) =>
            m_LodStreamer?.SetAttractorPageBounds(state.pageId, PagedAttractorStateBounds(state));

        Bounds ExpandPagedAttractorBounds(Bounds bounds)
        {
            if (HasPagedAttractorState)
                bounds.SetMinMax(bounds.min + m_PagedAttractorDisplacementMin, bounds.max + m_PagedAttractorDisplacementMax);
            return bounds;
        }

        void ClearPagedAttractorVelocities()
        {
            foreach (var state in m_PagedAttractorStates)
            {
                state.job.Complete();
                for (int i = 0; i < state.count; i++) state.velocities[i] = float3.zero;
            }
            m_PagedAttractorLastTick = -1;
            m_PagedAttractorAccumulator = 0;
            m_PagedAttractorTickWasEnabled = false;
        }

        public void ResetPagedAttractors()
        {
            ClearPagedAttractorState();
            RefreshPagedAttractorGpuOffsets();
            InvalidateLodAsyncSelection();
            m_LodSelectionInvalid = m_LodSelectionDirty = true;
            ForceResort();
            InvalidatePagedLodEraseView();
        }

        void ClearPagedAttractorState()
        {
            ResetPagedAttractorSelection();
            DisposePagedAttractorGpuBuffer();
            RestorePagedAttractorHierarchyBase();
            m_PagedAttractorTrees.Clear();
            m_PagedAttractorDisposedTrees.Clear();
            foreach (var state in m_PagedAttractorStates) state.Dispose();
            m_PagedAttractorStates.Clear();
            m_PagedAttractorSources.Clear();
            m_PagedAttractorSynthetic.Clear();
            m_PagedAttractorDisplacementMin = m_PagedAttractorDisplacementMax = Vector3.zero;
            m_PagedAttractorLastTick = -1;
            m_PagedAttractorAccumulator = 0;
            m_PagedAttractorTime = 0;
            m_PagedAttractorTickWasEnabled = false;
            m_LodStreamer?.ClearAttractorPageBounds();
        }

        void DisposePagedAttractors()
        {
            ClearPagedAttractorState();
            if (m_PagedAttractorForces.IsCreated) m_PagedAttractorForces.Dispose();
            if (m_PagedAttractorPreparedForces.IsCreated) m_PagedAttractorPreparedForces.Dispose();
            m_PagedAttractorValidForces.Clear();
            m_PagedAttractorScene = null;
        }
    }
}
