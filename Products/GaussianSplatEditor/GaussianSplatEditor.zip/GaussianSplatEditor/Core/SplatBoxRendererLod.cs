// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [Header("Paged LoD Streaming (Quest)")]
        [Tooltip("When set, splats are streamed by spatial page and rendered up to a configurable maximum LoD budget.")]
        [SerializeField] GaussianSplatPagedScene m_PagedScene;
        [SerializeField] SplatBoxLodStreamer m_LodStreamer;
        [SerializeField, HideInInspector] GaussianCutout m_PagedXcopyBoundary;
        // Scene references let the editor reset only copies belonging to this renderer.
        [SerializeField, HideInInspector] SplatBoxRenderer m_PagedXcopySource;
        [SerializeField, HideInInspector] GameObject m_PagedXcopyRoot;
        [Tooltip("Simple derives every LoD quality setting from one Quality slider. Advanced exposes " +
                 "the individual knobs. Detail Distance is available in both modes.")]
        [SerializeField] bool m_LodSimpleMode = true;
        [Tooltip("How much detail the scene keeps into the distance. Raising it grows the splat " +
                 "budget and lets refinement continue to finer screen sizes; lowering it is faster.")]
        [Range(0f, 1f)] [SerializeField] float m_LodQuality = 0.5f;
        [Tooltip("Keep finer detail out to this distance from a page, blending to ordinary distance " +
                 "detail by twice this range. Also sets the camera distance where Distant Point Cloud starts.")]
        [Range(2f, 32f)] [SerializeField] float m_LodDetailDistance = kDefaultLodDetailDistance;
        [Tooltip("Draw selected LoD nodes beyond Detail Distance as points. This changes their " +
                 "representation without loading extra source splats.")]
        [SerializeField] bool m_LodDistantPointCloud = false;
        [Tooltip("Maximum splats drawn at once. Detail is spent on whatever is largest on screen.")]
        [Range(50_000, 2_000_000)] [SerializeField] int m_LodSplatBudget = 500_000;
        [Tooltip("Use the standard Gaussian shader for paged LoD while editing. The relight shader " +
                 "evaluates scene lighting six times per splat (once per quad vertex), which is very " +
                 "expensive for large previews. Play mode and builds still use the configured shader.")]
        [SerializeField] bool m_LodFastEditorPreview = true;
        [Tooltip("Stop refining a node once it covers fewer than this many screen pixels. " +
                 "0 = tune automatically to fit the budget, which is usually what you want.")]
        [Range(0f, 8f)] [SerializeField] float m_LodPixelScaleLimit = 0f;
        [Tooltip("Quality multiplier. Below 1 the scene is treated as smaller on screen, so less of " +
                 "the budget is spent on detail. Does not change the budget itself.")]
        [Range(0.1f, 2f)] [SerializeField] float m_LodDetailScale = 1f;
        [Tooltip("Skip LoD nodes outside the camera frustum so the budget is spent on what you can see.")]
        [SerializeField] bool m_LodFrustumCull = true;
        [Tooltip("Draw the merged stand-in splats that represent pages held at coarse detail. Turn " +
                 "this off to draw only real splats: the scene gets holes where detail is missing, " +
                 "but nothing is approximated. Useful for pages built by an older, broken merge.")]
        [SerializeField] bool m_LodDrawCoarseStandIns = true;
        [Tooltip("Drop a coarse stand-in once it would cover more than this many screen pixels. Blend " +
                 "cost grows with area while the splat budget only counts splats, so one huge stand-in " +
                 "costs thousands of refined splats and represents almost nothing. Lower is faster and " +
                 "leaves holes until detail streams in; raise it if holes bother you more than speed.")]
        [Range(0f, 512f)] [SerializeField] float m_LodMaxStandInPixels =
            SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels;
        [Tooltip("Extra degrees of field of view used when culling. Guards against splats popping at " +
                 "the edge of the view; stereo cameras get an additional margin automatically.")]
        [Range(0f, 45f)] [SerializeField] float m_LodCullPaddingDeg = 10f;
        [Tooltip("GPU memory ceiling for the resident page atlas. Fewer pages are held at full detail " +
                 "when the budget is tight. Keep this well below total VRAM (256 MB or less on Quest).")]
        [Range(64, 4096)] [SerializeField] int m_LodAtlasBudgetMB = 1024;
        [Tooltip("Atlas memory ceiling in Android players. Page upload buffers and render/sort " +
                 "buffers need additional memory. The smaller of this and Atlas Budget is used.")]
        [Range(64, 1024)] [SerializeField] int m_LodMobileAtlasBudgetMB = 256;
        [Tooltip("Run steady-state traversal on a worker in Edit mode, Play mode and players. Existing valid " +
                 "splats stay visible until the new selection is ready.")]
        [SerializeField] bool m_LodAsyncTraversal = true;
        [Range(0.05f, 1f)] [SerializeField] float m_OutsideFoveate = 0.4f;
        [Range(0.05f, 1f)] [SerializeField] float m_BehindFoveate = 0.2f;

        int m_ActiveSplatCount;
        int m_LodAllocatedBudget;
        int m_UnifiedAtlasSplatCount;
        int m_LodAtlasCapacity;
        GraphicsBuffer m_GpuLodAtlasIndices;
        GraphicsBuffer m_GpuLodUnifiedPos;
        GraphicsBuffer m_GpuLodUnifiedOther;
        GraphicsBuffer m_GpuLodUnifiedSh;
        Texture2D m_GpuLodUnifiedColor;
        GraphicsBuffer m_GpuLodUnifiedChunks;
        int m_LodUnifiedChunkCount;
        LodActiveSplatRef[] m_LodActiveScratch;
        uint[] m_LodAtlasIndexScratch;
        bool m_LodAtlasDirty = true;
        bool m_LodSelectionDirty = true;
        int m_LodPosBytesPerSplat;
        int m_LodOtherBytesPerSplat;
        int m_LodShBytesPerSplat;
        GaussianSplatAsset m_LodFormatAsset;
        GaussianSplatPagedScene m_PrevPagedScene;

        public bool UsesPagedLod => m_PagedScene != null && m_PagedScene.pageCount > 0;
        public int activeSplatCount => UsesPagedLod ? m_ActiveSplatCount : m_SplatCount;
        public GaussianSplatPagedScene pagedScene => m_PagedScene;
        public SplatBoxLodStreamer lodStreamer => m_LodStreamer;
        Matrix4x4 m_LastCopyBoundaryMatrix;
        bool m_HadCopyBoundary;

        // Existing Xcopy objects already serialize this child cutout. Detect it without requiring
        // users to paste again or changing the source renderer's ordinary LoD behaviour.
        internal GaussianCutout PagedXcopyBoundary
        {
            get
            {
                if (!UsesPagedLod || m_Cutouts == null || transform.parent == null) return null;
                foreach (var boundary in m_Cutouts)
                    if (boundary != null && boundary.GetType() == typeof(GaussianCutout) && boundary.isActiveAndEnabled && boundary.m_Invert &&
                        boundary.m_Type == GaussianCutout.Type.Box &&
                        (m_PagedXcopyBoundary != null ? boundary == m_PagedXcopyBoundary : boundary.name == "Xcopy boundary") &&
                        boundary.transform.IsChildOf(transform.parent))
                        return boundary;
                return null;
            }
        }

        void ConfigurePagedCopyView(ref SplatBoxLodTraverser.ViewContext view)
        {
            var boundary = PagedXcopyBoundary;
            if (boundary == null) return;
            view.hasCopyBoundary = true;
            view.copyLocalToBox = boundary.transform.worldToLocalMatrix * transform.localToWorldMatrix;
            // One selection is shared by Main and Scene cameras. Restrict it spatially to the
            // copied area, not to either camera's frustum, so both views retain coverage.
            view.frustumCull = false;
            view.skipMergedSplats = false;
            view.maxStandInPixels = 0;
        }

        void RefreshPagedCopyBoundary()
        {
            var boundary = PagedXcopyBoundary;
            bool present = boundary != null;
            Matrix4x4 matrix = present ? boundary.transform.worldToLocalMatrix * transform.localToWorldMatrix : Matrix4x4.identity;
            if (present == m_HadCopyBoundary && (!present || matrix == m_LastCopyBoundaryMatrix)) return;
            m_HadCopyBoundary = present;
            m_LastCopyBoundaryMatrix = matrix;
            InvalidateLodAsyncSelection();
            m_LodSelectionInvalid = true;
            m_LodSelectionDirty = true;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
#endif
        }

        /// <summary>
        /// Screen size below which refinement stops; 0 spends the whole budget. Reports the value
        /// actually in effect, which in Simple mode is derived from the Quality slider.
        /// </summary>
        public float lodPixelScaleLimit => EffectivePixelScaleLimit;

        /// <summary>Quality multiplier applied to on-screen size during LoD traversal.</summary>
        public float lodDetailScale => m_LodDetailScale;

        public const float kDefaultLodDetailDistance = 8f;

        /// <summary>World-space distance over which finer page detail is preferred.</summary>
        public float lodDetailDistance
        {
            get => Mathf.Clamp(m_LodDetailDistance, 2f, 32f);
            set => SetLodDetailDistance(value);
        }

        /// <summary>Draw selected distant LoD nodes as points without changing selection or residency.</summary>
        public bool lodDistantPointCloud
        {
            get => m_LodDistantPointCloud;
            set
            {
                if (m_LodDistantPointCloud == value)
                    return;
                m_LodDistantPointCloud = value;
#if UNITY_EDITOR
                m_HasEditorLodCalculatedView = false;
                m_HasEditorLodSortedView = false;
                UnityEditor.SceneView.RepaintAll();
#endif
            }
        }

        /// <summary>
        /// Whether merged stand-in splats are drawn for pages held at coarse detail. Always true in
        /// Simple mode, where the whole scene staying visible is part of the contract.
        /// </summary>
        public bool drawsCoarseStandIns => EffectiveDrawCoarseStandIns;

        /// <summary>Full-detail page slots the atlas currently provides.</summary>
        public int lodAtlasDetailSlots => m_AtlasDetailSlots;

        /// <summary>
        /// Splats each detail slot reserves. Slots are uniform and sized for the largest page in the
        /// scene, so one oversized page inflates the cost of every slot.
        /// </summary>
        public int lodAtlasSlotSplats => m_AtlasDetailStride;

        public int effectiveLodAtlasBudgetMB => Application.platform == RuntimePlatform.Android
            ? Mathf.Max(64, Mathf.Min(m_LodAtlasBudgetMB, m_LodMobileAtlasBudgetMB))
            : Mathf.Max(64, m_LodAtlasBudgetMB);

        /// <summary>Names of the LoD quality fields, for editor tooling that writes them.</summary>
        public const string kPropLodPixelScaleLimit = "m_LodPixelScaleLimit";
        public const string kPropLodDetailScale = "m_LodDetailScale";
        public const string kPropLodDetailDistance = "m_LodDetailDistance";
        public const string kPropLodDistantPointCloud = "m_LodDistantPointCloud";
        public const string kPropLodDrawCoarseStandIns = "m_LodDrawCoarseStandIns";
        public const string kPropLodSimpleMode = "m_LodSimpleMode";
        public const string kPropLodQuality = "m_LodQuality";

        /// <summary>Total splats across every page of the paged scene (all LoD levels included).</summary>
        public int pagedSceneSplatCount
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return 0;
                int total = 0;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                    total += m_PagedScene.pages[i].splatCount;
                return total;
            }
        }

        /// <summary>Original source splats represented by the leaf nodes across all pages.</summary>
        public long pagedSceneLeafCount
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return 0;
                long total = 0;
                foreach (var page in m_PagedScene.pages)
                    if (page.pageAsset != null)
                        total += page.pageAsset.leafCount;
                return total;
            }
        }

        /// <summary>
        /// True when any page still uses the depth-first LoD layout, which cannot supply a coarse
        /// prefix — those pages fall back to a single splat when they are outside the detail radius.
        /// </summary>
        public bool hasLegacyLodPages
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return false;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                {
                    var asset = m_PagedScene.pages[i].pageAsset;
                    if (asset != null && !asset.hasLevelOrderLodTree)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// True for page assets exported before tree and payload ordering were kept in sync.
        /// Those assets cannot render correctly because a selected node addresses another splat.
        /// </summary>
        public bool hasMismatchedLodSplatOrder
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return false;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                {
                    var asset = m_PagedScene.pages[i].pageAsset;
                    if (asset != null && !asset.hasMatchingLodSplatOrder)
                        return true;
                }
                return false;
            }
        }

        /// <summary>Pages currently held at full detail (the rest keep a coarse LoD prefix).</summary>
        public int detailPageCount
        {
            get
            {
                if (m_LodStreamer == null)
                    return 0;
                var pages = m_LodStreamer.loadedPages;
                int count = 0;
                for (int i = 0; i < pages.Count; i++)
                {
                    if (pages[i] != null && !pages[i].isCoarseStub)
                        count++;
                }
                return count;
            }
        }

        // ---- Simple quality mode ----------------------------------------------------------------
        // One Quality slider stands in for the detailed knobs. The mappings are public statics so
        // the inspector and the VR settings menu can show the numbers a quality value stands for.
        // In Simple mode the detailed fields are ignored, not overwritten: switching back to
        // Advanced finds them exactly as they were left.

        /// <summary>Smallest splat budget the Quality slider will ask for.</summary>
        public const int kLodQualityMinBudget = 100_000;
        /// <summary>Largest splat budget the Quality slider will ask for.</summary>
        public const int kLodQualityMaxBudget = 2_000_000;

        /// <summary>
        /// Splat budget for a Quality value. Log-spaced so the slider feels even: every step scales
        /// the budget by the same factor instead of adding a fixed amount. Rounded to 25k steps so a
        /// drag crosses a handful of buffer reallocations rather than one per slider pixel.
        /// </summary>
        public static int LodQualityToBudget(float quality)
        {
            float t = Mathf.Clamp01(quality);
            float budget = Mathf.Exp(Mathf.Lerp(
                Mathf.Log(kLodQualityMinBudget), Mathf.Log(kLodQualityMaxBudget), t));
            return Mathf.RoundToInt(budget / 25_000f) * 25_000;
        }

        /// <summary>Quality value whose budget mapping is nearest to <paramref name="budget"/>.</summary>
        public static float LodQualityFromBudget(int budget)
        {
            float clamped = Mathf.Clamp(budget, kLodQualityMinBudget, kLodQualityMaxBudget);
            return Mathf.InverseLerp(
                Mathf.Log(kLodQualityMinBudget), Mathf.Log(kLodQualityMaxBudget), Mathf.Log(clamped));
        }

        /// <summary>
        /// Screen size (pixels) below which refinement stops, for a Quality value: 6 px at 0 down to
        /// the 1 px automatic floor at 1, exponential so the middle of the slider looks balanced.
        /// </summary>
        public static float LodQualityToPixelCutoff(float quality) =>
            Mathf.Pow(6f, 1f - Mathf.Clamp01(quality));

        /// <summary>Foveation factor for nodes outside the view frustum, for a Quality value.</summary>
        public static float LodQualityToOutsideFoveate(float quality) =>
            Mathf.Lerp(0.25f, 0.55f, Mathf.Clamp01(quality));

        /// <summary>Foveation factor for nodes behind the camera, for a Quality value.</summary>
        public static float LodQualityToBehindFoveate(float quality) =>
            Mathf.Lerp(0.1f, 0.3f, Mathf.Clamp01(quality));

        // Detail Scale is deliberately not derived from Quality: it stays a live multiplier in both
        // modes (default 1) because the VR settings menu drives it at runtime.
        float EffectivePixelScaleLimit => m_LodSimpleMode
            ? LodQualityToPixelCutoff(m_LodQuality)
            : m_LodPixelScaleLimit;
        float EffectiveOutsideFoveate => m_LodSimpleMode
            ? LodQualityToOutsideFoveate(m_LodQuality)
            : m_OutsideFoveate;
        float EffectiveBehindFoveate => m_LodSimpleMode
            ? LodQualityToBehindFoveate(m_LodQuality)
            : m_BehindFoveate;
        // Keep the whole scene filled: coarse stand-ins are what cover pages that have not yet
        // taken a detail slot. Simple mode always uses the full slider so the first frame is not a
        // sea of holes or tiny blobs.
        float EffectiveMaxStandInPixels => m_LodSimpleMode
            ? SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels
            : m_LodMaxStandInPixels;
        // Android traversal can take several headset frames. Prefetch more surrounding coverage
        // in Simple mode so ordinary turns can finish on the worker instead of forcing a main-
        // thread traversal. Advanced padding remains explicit; GPU culling still uses the live view.
        float EffectiveCullPaddingDeg => LodCullPaddingForPlatform(
            m_LodSimpleMode, m_LodCullPaddingDeg, Application.platform);

        // The twenty-degree / 0.8-metre safety reserves leave over 250 ms after the early
        // request at the scene's 60 degrees/s turn and 2.5 metres/s walking speeds.
        static float LodCullPaddingForPlatform(bool simpleMode, float configuredPadding, RuntimePlatform platform) =>
            simpleMode ? (platform == RuntimePlatform.Android ? 50f : 15f) : configuredPadding;

        static float LodEarlyCoverageFractionForPlatform(bool simpleMode, RuntimePlatform platform) =>
            simpleMode && platform == RuntimePlatform.Android ? 1f / 10f : 1f / 3f;

        float EffectiveTranslationPrefetchRadius => LodTranslationPrefetchForPlatform(m_LodSimpleMode, Application.platform);

        static float LodTranslationPrefetchForPlatform(bool simpleMode, RuntimePlatform platform) =>
            simpleMode && platform == RuntimePlatform.Android ? 1f : 0f;

        // Edit mode shares one selection between the Game and Scene views. Culling that selection
        // to either camera makes the other view appear to have missing parts, even with every page
        // resident. Keep the preview's selection omnidirectional; each camera still clips its draw.
        static bool LodFrustumCullForEditorPreview(bool requested, bool isPlaying) => requested && isPlaying;
        bool EffectiveFrustumCull
        {
            get
            {
                bool requested = m_LodSimpleMode || m_LodFrustumCull;
#if UNITY_EDITOR
                return LodFrustumCullForEditorPreview(requested, Application.isPlaying);
#else
                return requested;
#endif
            }
        }
        bool EffectiveDrawCoarseStandIns => m_LodSimpleMode || m_LodDrawCoarseStandIns;

        /// <summary>Whether the one-slider Simple quality mode is active.</summary>
        public bool lodSimpleMode
        {
            get => m_LodSimpleMode;
            set
            {
                if (m_LodSimpleMode == value)
                    return;
                m_LodSimpleMode = value;
                m_LodSelectionDirty = true;
            }
        }

        /// <summary>Simple-mode quality, 0 = fastest, 1 = best. Ignored in Advanced mode.</summary>
        public float lodQuality
        {
            get => m_LodQuality;
            set => SetLodQuality(value);
        }

        public void SetLodQuality(float quality)
        {
            float clamped = Mathf.Clamp01(quality);
            if (Mathf.Approximately(m_LodQuality, clamped))
                return;

            m_LodQuality = clamped;
            m_LodSelectionDirty = true;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            UnityEditor.SceneView.RepaintAll();
#endif
        }

        /// <summary>
        /// Maximum splats the LoD system may draw. Allocated buffer capacity can be larger so
        /// changing quality does not require a reallocation for every budget change.
        /// </summary>
        public int EffectiveLodBudget => Mathf.Clamp(
            m_LodSimpleMode ? LodQualityToBudget(m_LodQuality) : m_LodSplatBudget,
            10_000, 2_000_000);

        /// <summary>
        /// On-screen size (pixels) at which refinement actually stopped last selection, exposed for
        /// the inspector. 0 means the budget covered every leaf in view.
        /// </summary>
        public float currentLodPixelScaleLimit => m_LastEffectiveCutoff;

        /// <summary>Real leaf splats in the last LoD selection (diagnostic).</summary>
        public int lastLodLeafCount => m_LodWorkspace?.emittedLeaves ?? 0;

        /// <summary>Merged stand-in splats in the last LoD selection (diagnostic).</summary>
        public int lastLodMergedCount => m_LodWorkspace?.emittedMerged ?? 0;

        /// <summary>Merged stand-in splats dropped from the last LoD selection (diagnostic).</summary>
        public int lastLodMergedDropCount => m_LodWorkspace?.droppedMerged ?? 0;

        void EnsureLodStreamer()
        {
            if (!UsesPagedLod)
                return;
            if (m_LodStreamer == null)
                m_LodStreamer = GetComponent<SplatBoxLodStreamer>();
            if (m_LodStreamer == null)
                m_LodStreamer = gameObject.AddComponent<SplatBoxLodStreamer>();
            if (m_LodStreamer.pagedScene != m_PagedScene)
                m_LodStreamer.Configure(m_PagedScene, transform);
            m_LodStreamer.OnPagesChanged -= OnLodPagesChanged;
            m_LodStreamer.OnPagesChanged += OnLodPagesChanged;
        }

        void OnLodPagesChanged()
        {
            unchecked { m_LodPageEventSequence++; }
            SplatBoxLodDiagnostics.RecordPageEvent();
            m_LodAtlasDirty = true;
            m_LodLastPageEventTime = Time.realtimeSinceStartup;

            // A released detail slot may already belong to a different page. The old selection
            // must not survive the atlas copy, even when the number of full pages stayed constant.
            // Coarse regions have permanent addresses and are safe to retain between refreshes.
            var currentPages = m_LodStreamer?.loadedPages;
            m_LodResidentDetailScratch.Clear();
            if (currentPages != null)
            {
                for (int i = 0; i < currentPages.Count; i++)
                {
                    var page = currentPages[i];
                    if (page != null && !page.isCoarseStub)
                        m_LodResidentDetailScratch.Add(page);
                }
            }
            for (int i = 0; i < m_LodSelectedDetailPages.Count; i++)
            {
                if (!m_LodResidentDetailScratch.Contains(m_LodSelectedDetailPages[i]))
                {
                    InvalidateLodAsyncSelection();
                    m_LodSelectionInvalid = true;
                    m_LodSelectionDirty = true;
                    break;
                }
            }

            // Cold start still needs an immediate selection.
            if (m_ActiveSplatCount <= 0)
            {
                m_LodSelectionDirty = true;
                m_LodPendingSettledReselect = true;
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    UnityEditor.SceneView.RepaintAll();
#endif
                return;
            }

            // Full-detail upgrades/downgrades change what leaf data exists and must reselect soon.
            // Pure coarse stub arrivals used to dirty selection every frame while 100+ pages streamed
            // in, re-splitting the budget each time and flickering near surfaces between leaf and
            // giant stand-in sizes. Fold those into one settled refresh after the burst quietens.
            int fullPages = 0;
            var loaded = m_LodStreamer?.loadedPages;
            if (loaded != null)
            {
                for (int i = 0; i < loaded.Count; i++)
                {
                    if (loaded[i] != null && !loaded[i].isCoarseStub)
                        fullPages++;
                }
            }

            if (fullPages != m_LodLastFullPageCount)
            {
                m_LodLastFullPageCount = fullPages;
                m_LodSelectionDirty = true;
                m_LodPendingSettledReselect = true;
            }
            else
            {
                m_LodPendingSettledReselect = true;
            }
#if UNITY_EDITOR
            if (!Application.isPlaying)
                UnityEditor.SceneView.RepaintAll();
#endif
        }

        int m_LodLastFullPageCount = -1;

        void InitPagedLodResources()
        {
            if (!UsesPagedLod)
                return;

            EnsureLodStreamer();

            if (hasMismatchedLodSplatOrder)
            {
                m_ActiveSplatCount = 0;
                Debug.LogError(
                    "SplatBoxRenderer: this paged LoD scene was built with mismatched tree and splat " +
                    "ordering. It cannot render correctly and can select unexpectedly huge splats. " +
                    "Rebuild it with Tools > Gaussian Splatting > Create Paged LoD Scene.");
                return;
            }

            m_LodFormatAsset = null;
            if (!EnsureLodFormatAsset())
            {
                Debug.LogError("SplatBoxRenderer: Paged scene has no valid page assets.");
                return;
            }

            m_SplatCount = EffectiveLodBudget;
            if (!SetLodFormatStrides(m_LodFormatAsset))
                return;

            int maxAtlasSplats = EstimateMaxAtlasSplats();
            AllocateLodAtlasBuffers(maxAtlasSplats);
            int capacity = LodBudgetCapacity(EffectiveLodBudget);
            AllocateActiveRenderBuffers(capacity);

            m_LodActiveScratch = new LodActiveSplatRef[capacity];
            m_LodAtlasIndexScratch = new uint[capacity];
            m_LodAllocatedBudget = capacity;
            m_LodAtlasDirty = true;
            m_LodSelectionDirty = true;
            m_ActiveSplatCount = 0;
            m_LodLastFullPageCount = -1;
            SyncPagedLodChunkBindings(false);

            PreloadPagedLodPages(ResolvePagedLodCamera());
#if UNITY_EDITOR
            // OnEnable often runs before any Scene view camera exists. Preload then only sees the
            // object pivot and may leave activeSplatCount at 0 until something (historically: enter
            // and exit Play mode) re-inits with a real view. Schedule a follow-up once the editor
            // has a camera so the Scene view fills without that Play-mode dance.
            if (!Application.isPlaying)
                ScheduleEditorPagedLodWarmup();
#endif
        }

        /// <summary>
        /// Camera that drives streaming and LoD selection. Prefer the tagged Main Camera so Game
        /// view / Play / VR focus matches the camera the user positions near the splats. Scene view
        /// is only a fallback when no Main Camera exists yet.
        /// </summary>
        static Camera ResolvePagedLodCamera()
        {
            var main = Camera.main;
            if (main != null)
                return main;
#if UNITY_EDITOR
            if (!Application.isPlaying && UnityEditor.SceneView.lastActiveSceneView != null)
                return UnityEditor.SceneView.lastActiveSceneView.camera;
#endif
            return null;
        }

        void SyncPagedLodChunkBindings(bool chunksPopulated = false)
        {
            if (!UsesPagedLod)
                return;
            if (chunksPopulated && m_GpuLodUnifiedChunks != null && m_LodUnifiedChunkCount > 0)
            {
                m_GpuChunks = m_GpuLodUnifiedChunks;
                m_GpuChunksValid = true;
            }
            else
            {
                m_GpuChunks ??= new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = "LodDummyChunks" };
                m_GpuChunksValid = false;
            }
        }

        struct PagedLodGpuBindings
        {
            public GraphicsBuffer pos;
            public GraphicsBuffer other;
            public GraphicsBuffer sh;
            public GraphicsBuffer chunks;
            public Texture color;
            public int chunkCount;
        }

        void GetSplatComputeBindings(
            out GraphicsBuffer posBuf,
            out GraphicsBuffer otherBuf,
            out GraphicsBuffer shBuf,
            out Texture colorTex,
            out GraphicsBuffer chunkBuf,
            out int chunkCount,
            out GraphicsBuffer remapBuf,
            out int useRemap)
        {
            posBuf = m_GpuPosData;
            otherBuf = m_GpuOtherData;
            shBuf = m_GpuSHData;
            colorTex = m_GpuColorData;
            chunkBuf = m_GpuChunks;
            chunkCount = m_GpuChunksValid ? m_GpuChunks.count : 0;
            remapBuf = m_GpuSortKeys;
            useRemap = 0;

            if (TryGetPagedLodGpuBindings(out var paged))
            {
                posBuf = paged.pos;
                otherBuf = paged.other;
                shBuf = paged.sh;
                colorTex = paged.color;
                chunkBuf = paged.chunks;
                chunkCount = paged.chunkCount;
                remapBuf = m_GpuLodAtlasIndices;
                useRemap = 1;
            }
        }

        bool TryGetPagedLodGpuBindings(out PagedLodGpuBindings bindings)
        {
            bindings = default;
            if (!UsesPagedLod || m_GpuLodUnifiedPos == null || m_GpuLodAtlasIndices == null ||
                m_UnifiedAtlasSplatCount <= 0)
                return false;
            bindings.pos = m_GpuLodUnifiedPos;
            bindings.other = m_GpuLodUnifiedOther;
            bindings.sh = m_GpuLodUnifiedSh;
            bindings.color = m_GpuLodUnifiedColor;
            bindings.chunks = m_GpuLodUnifiedChunks ?? m_GpuChunks;
            bindings.chunkCount = m_GpuChunksValid && m_LodUnifiedChunkCount > 0
                ? m_LodUnifiedChunkCount
                : 0;
            return true;
        }

        // Row alignment (a multiple of the 256-splat chunk size) lets each page's colour data move
        // in a single full-width CopyTexture instead of one call per texture row, and keeps every
        // page's chunk-compressed data aligned to its own ChunkInfo entries.
        const int kAtlasSplatAlignment = GaussianSplatAsset.kTextureWidth;

        static int AlignAtlasSplatOffset(int splatOffset) =>
            (splatOffset + kAtlasSplatAlignment - 1) / kAtlasSplatAlignment * kAtlasSplatAlignment;

        // Fixed atlas addressing. Each page owns a permanent region big enough for its coarse tier,
        // and full-detail pages additionally borrow one of a small pool of equally sized detail
        // slots. Because a page's address never depends on what else is loaded, streaming one page
        // in or out no longer shifts — and therefore no longer re-copies — every other page.
        readonly Dictionary<int, int> m_AtlasPageIndex = new Dictionary<int, int>();
        int[] m_AtlasPageOffset;
        int[] m_AtlasPageReserve;
        int m_AtlasDetailStart;
        int m_AtlasDetailStride;
        int m_AtlasDetailSlots;
        int m_AtlasCoarsePageSplats = int.MaxValue;
        int m_AtlasCoarsePageSplatTarget;
        int m_AtlasRequestedDetailSlots = -1;
        int m_AtlasRequestedCoarsePageSplats = -1;
        int m_AtlasRequestedDistanceCoverageSplats = -1;
        int m_AtlasLayoutBudgetMB = -1;
        int m_AtlasLayoutTotal;
        bool m_AtlasLayoutIsPerPage;
        bool m_AtlasWantedPerPage;

        int EstimateMaxAtlasSplats()
        {
            EnsureAtlasLayout();
            return Mathf.Max(m_AtlasLayoutTotal, 1);
        }

        void EnsureAtlasLayout()
        {
            if (m_PagedScene?.pages == null || m_PagedScene.pages.Length == 0)
            {
                m_AtlasPageOffset = null;
                m_AtlasPageReserve = null;
                m_AtlasLayoutTotal = 0;
                return;
            }

            // Packed pages can fit the desktop atlas well beyond the streamer's conservative
            // standalone cap. Let the actual format, memory budget and driver limits decide.
            bool isCopy = PagedXcopyBoundary != null;
            m_LodStreamer?.SetCopyResidency(isCopy);
#if UNITY_EDITOR
            m_LodStreamer?.SetEditorFullSceneSplatCapacity(MaxAtlasSplatCapacity());
#else
            if (isCopy) m_LodStreamer?.SetEditorFullSceneSplatCapacity(MaxAtlasSplatCapacity());
#endif
            // Keyed on what was asked for rather than what the budget allowed: the layout can
            // legitimately return less than was requested, and comparing against the result would
            // rebuild every frame — or latch a reduced layout in place after the budget is raised.
            bool wantsPerPage = m_LodStreamer != null && m_LodStreamer.wantsFullSceneResidency;
            int requestedSlots = m_LodStreamer != null
                ? m_LodStreamer.requestedDetailSlots
                : Mathf.Clamp(m_PagedScene.maxLoadedPages, 1, m_PagedScene.pages.Length);
            int distanceCoverageSplats = Mathf.CeilToInt(m_PagedScene.coarsePageSplats *
                Mathf.Lerp(1f, 1.5f, Mathf.InverseLerp(2f, 8f, lodDetailDistance)));

            if (m_AtlasPageOffset != null &&
                m_AtlasPageOffset.Length == m_PagedScene.pages.Length &&
                m_AtlasWantedPerPage == wantsPerPage &&
                m_AtlasRequestedDetailSlots == requestedSlots &&
                m_AtlasRequestedCoarsePageSplats == m_PagedScene.coarsePageSplats &&
                m_AtlasRequestedDistanceCoverageSplats == distanceCoverageSplats &&
                m_AtlasLayoutBudgetMB == effectiveLodAtlasBudgetMB)
                return;

            m_AtlasWantedPerPage = wantsPerPage;
            m_AtlasRequestedDetailSlots = requestedSlots;
            m_AtlasRequestedCoarsePageSplats = m_PagedScene.coarsePageSplats;
            m_AtlasRequestedDistanceCoverageSplats = distanceCoverageSplats;
            m_AtlasLayoutBudgetMB = effectiveLodAtlasBudgetMB;
            BuildAtlasLayout(wantsPerPage, requestedSlots);
            if (m_ActiveSplatCount > 0)
            {
                InvalidateLodAsyncSelection();
                m_LodSelectionInvalid = true;
                m_LodSelectionDirty = true;
            }

            // The layout may have had to shrink the detail pool, or drop full-scene residency
            // entirely, to fit in memory. The streamer has to agree, or it will load pages the atlas
            // has nowhere to put.
            m_LodStreamer?.SetAtlasLimits(
                m_AtlasLayoutIsPerPage ? int.MaxValue : m_AtlasDetailSlots,
                m_AtlasLayoutIsPerPage, m_AtlasCoarsePageSplats, m_AtlasCoarsePageSplatTarget);
        }

        /// <summary>
        /// Splats the atlas may hold. Every resident splat costs position, rotation/scale, SH and
        /// colour, and SH alone can be 192 bytes, so an unbounded layout runs straight past the
        /// graphics buffer size limit.
        /// </summary>
        int MaxAtlasSplatCapacity()
        {
            long colorBytes = m_LodFormatAsset != null
                ? GaussianSplatAsset.GetColorSize(m_LodFormatAsset.colorFormat)
                : 4;
            long bytesPerSplat = Math.Max(1,
                (long)m_LodPosBytesPerSplat + m_LodOtherBytesPerSplat + m_LodShBytesPerSplat + colorBytes);

            long budgetBytes = (long)effectiveLodAtlasBudgetMB * 1024 * 1024;
            long capacity = budgetBytes / bytesPerSplat;

            // No single buffer may exceed the driver limit either, and the colour texture is bounded
            // by the maximum texture height.
            long maxBufferBytes = SystemInfo.maxGraphicsBufferSize > 0
                ? SystemInfo.maxGraphicsBufferSize
                : 2L * 1024 * 1024 * 1024;
            // Quest 3's Adreno 740 exposes a 128 MiB maxStorageBufferRange. The allocation limit
            // alone does not guarantee that a larger buffer can be bound as shader storage.
            if (Application.platform == RuntimePlatform.Android &&
                SystemInfo.graphicsDeviceType == GraphicsDeviceType.Vulkan)
                maxBufferBytes = Math.Min(maxBufferBytes, 128L * 1024 * 1024);
            int largestStride = Mathf.Max(m_LodPosBytesPerSplat, m_LodOtherBytesPerSplat, m_LodShBytesPerSplat);
            capacity = Math.Min(capacity, maxBufferBytes / Math.Max(4, largestStride));
            capacity = Math.Min(capacity, (long)SystemInfo.maxTextureSize * GaussianSplatAsset.kTextureWidth);
            capacity = Math.Min(capacity, GaussianSplatAsset.kMaxSplats);

            return (int)Math.Max(kAtlasSplatAlignment, capacity);
        }

        void BuildAtlasLayout(bool perPage, int requestedDetailSlots)
        {
            var pages = m_PagedScene.pages;
            int capacity = MaxAtlasSplatCapacity();

            m_AtlasPageOffset = new int[pages.Length];
            m_AtlasPageReserve = new int[pages.Length];
            m_AtlasPageIndex.Clear();

            int largestPage = 1;
            for (int i = 0; i < pages.Length; i++)
            {
                m_AtlasPageIndex[pages[i].pageId] = i;
                largestPage = Mathf.Max(largestPage, Mathf.Max(1, pages[i].splatCount));
            }

            // Full-scene residency is all or nothing: truncating pages here would leave the streamer
            // loading data the layout has no room for, so if it does not fit we stream instead.
            int permanentTotal = 0;
            m_AtlasCoarsePageSplats = int.MaxValue;
            m_AtlasCoarsePageSplatTarget = 0;
            if (perPage)
            {
                permanentTotal = LayOutPermanentRegions(pages, int.MaxValue, capacity, out long needed);
                if (needed > capacity)
                    perPage = false;
            }

            if (!perPage)
            {
                // Permanent regions hold the coarse tiers, which are what keep the whole model
                // visible, so they only shrink when they would crowd out full detail entirely.
                int coarseCap = Mathf.Max(1, m_PagedScene.coarsePageSplats);
                permanentTotal = LayOutPermanentRegions(pages, coarseCap, capacity, out long needed);
                while (needed > capacity / 2 && coarseCap > GaussianSplatAsset.kChunkSize)
                {
                    coarseCap = Mathf.Max(GaussianSplatAsset.kChunkSize, coarseCap / 2);
                    permanentTotal = LayOutPermanentRegions(pages, coarseCap, capacity, out needed);
                }
                m_AtlasCoarsePageSplats = AlignAtlasSplatOffset(coarseCap);

                // Full pages alone cannot sharpen the distance when nearby geometry already owns
                // every slot. Use atlas slack for a finer tier on all pages, while preserving the
                // exact number of full-detail slots the configured coarse tier could afford.
                int detailStride = AlignAtlasSplatOffset(largestPage);
                int baselineSlots = Mathf.Clamp(Mathf.Max(0, capacity - permanentTotal) / detailStride,
                    0, Mathf.Max(0, requestedDetailSlots));
                int coveragePrefix = SelectCoarseCoveragePrefix(pages, m_AtlasCoarsePageSplats,
                    m_AtlasRequestedDistanceCoverageSplats, capacity, detailStride, baselineSlots);
                if (coveragePrefix > m_AtlasCoarsePageSplats)
                {
                    permanentTotal = LayOutPermanentRegions(pages, coveragePrefix, capacity, out needed);
                    m_AtlasCoarsePageSplats = coveragePrefix;
                    m_AtlasCoarsePageSplatTarget = coveragePrefix;
                }

                if (needed > capacity)
                {
                    Debug.LogWarning(
                        $"SplatBoxRenderer: the LoD atlas budget ({effectiveLodAtlasBudgetMB} MB) cannot hold a " +
                        "coarse tier for every page, so part of the model will not be drawn. Raise LoD " +
                        "Atlas Budget or rebuild the scene with fewer, larger pages.");
                }
            }

            m_AtlasLayoutIsPerPage = perPage;
            m_AtlasDetailStart = permanentTotal;
            m_AtlasDetailStride = perPage ? 0 : AlignAtlasSplatOffset(largestPage);

            int detailSlots = 0;
            if (!perPage && m_AtlasDetailStride > 0)
            {
                int roomForSlots = Mathf.Max(0, capacity - permanentTotal) / m_AtlasDetailStride;
                detailSlots = Mathf.Clamp(roomForSlots, 0, Mathf.Max(0, requestedDetailSlots));
                // Off-by-one on a large max-page setting is normal (budget math vs alignment). Only
                // warn when the cut meaningfully changes streaming behaviour.
                if (detailSlots == 0 ||
                    (requestedDetailSlots >= 4 && detailSlots * 2 < requestedDetailSlots))
                {
                    Debug.LogWarning(
                        $"SplatBoxRenderer: the LoD atlas budget ({effectiveLodAtlasBudgetMB} MB) only fits " +
                        $"{detailSlots} of the requested {requestedDetailSlots} full-detail pages. " +
                        "Raise LoD Atlas Budget, lower Max Loaded Pages, or rebuild the scene with " +
                        "smaller pages.");
                }
            }

            m_AtlasDetailSlots = detailSlots;
            m_AtlasLayoutTotal = Mathf.Max(kAtlasSplatAlignment, permanentTotal + m_AtlasDetailStride * detailSlots);
        }

        static int SelectCoarseCoveragePrefix(GaussianSplatPageEntry[] pages, int basePrefix,
            int requestedPrefix, int capacity, int detailStride, int detailSlots)
        {
            int baseline = AlignAtlasSplatOffset(Mathf.Max(1, basePrefix));
            int requested = AlignAtlasSplatOffset(Mathf.Max(baseline, requestedPrefix));
            long detailReservation = (long)Mathf.Max(0, detailStride) * Mathf.Max(0, detailSlots);
            for (int candidate = requested; candidate > baseline; candidate -= kAtlasSplatAlignment)
            {
                long needed = detailReservation;
                for (int i = 0; i < pages.Length && needed <= capacity; i++)
                    needed += AlignAtlasSplatOffset(Mathf.Min(Mathf.Max(1, pages[i].splatCount), candidate));
                if (needed <= capacity)
                    return candidate;
            }
            return baseline;
        }

        /// <summary>
        /// Assigns each page its permanent region and returns the total splats they take. Pages that
        /// would run past <paramref name="capacity"/> get a zero-size reserve, which leaves them
        /// unplaced rather than writing outside the atlas.
        /// </summary>
        int LayOutPermanentRegions(GaussianSplatPageEntry[] pages, int coarseCap, int capacity,
            out long requiredTotal)
        {
            int alignedCap = coarseCap == int.MaxValue ? int.MaxValue : AlignAtlasSplatOffset(coarseCap);
            int offset = 0;
            requiredTotal = 0;
            for (int i = 0; i < pages.Length; i++)
            {
                int splats = Mathf.Max(1, pages[i].splatCount);
                // Small pages fit their whole payload here and never need a detail slot.
                int reserve = AlignAtlasSplatOffset(Mathf.Min(splats, alignedCap));
                requiredTotal += reserve;

                if (offset + reserve > capacity)
                {
                    m_AtlasPageOffset[i] = 0;
                    m_AtlasPageReserve[i] = 0;
                    continue;
                }
                m_AtlasPageOffset[i] = offset;
                m_AtlasPageReserve[i] = reserve;
                offset += reserve;
            }
            return offset;
        }

        /// <summary>Fixed address of a page in the atlas, or -1 if it has nowhere to live.</summary>
        int ResolveAtlasOffset(SplatBoxPageGpuState page)
        {
            if (m_AtlasPageOffset == null || !m_AtlasPageIndex.TryGetValue(page.pageId, out int index))
                return -1;
            if (page.splatCount <= m_AtlasPageReserve[index])
                return m_AtlasPageOffset[index];
            if (page.detailSlot < 0 || page.detailSlot >= m_AtlasDetailSlots)
                return -1;
            return m_AtlasDetailStart + page.detailSlot * m_AtlasDetailStride;
        }

        void EnsureLodAtlasCapacity(int requiredSplats)
        {
            if (!EnsureLodFormatAsset())
                return;
            if (m_GpuLodUnifiedColor != null && requiredSplats <= m_LodAtlasCapacity)
                return;
            AllocateLodAtlasBuffers(Mathf.Max(requiredSplats, EstimateMaxAtlasSplats()));
        }

        /// <summary>
        /// Format metadata comes from the first valid page asset. Editor streaming can preload
        /// before InitPagedLodResources finishes (or after a rebuild clears the field), so resolve
        /// it lazily instead of NRE-ing in AllocateLodAtlasBuffers.
        /// </summary>
        bool EnsureLodFormatAsset()
        {
            if (m_LodFormatAsset != null && m_LodFormatAsset.splatCount > 0 &&
                m_LodFormatAsset.posData != null && m_LodFormatAsset.otherData != null &&
                m_LodFormatAsset.shData != null)
                return m_LodPosBytesPerSplat > 0 || SetLodFormatStrides(m_LodFormatAsset);

            if (!UsesPagedLod || m_PagedScene?.pages == null)
                return false;

            for (int i = 0; i < m_PagedScene.pages.Length; i++)
            {
                var pageAsset = m_PagedScene.pages[i].pageAsset;
                var splatData = pageAsset != null ? pageAsset.splatData : null;
                if (pageAsset == null || !pageAsset.IsValid || splatData == null || splatData.splatCount <= 0 ||
                    splatData.posData == null || splatData.otherData == null || splatData.shData == null ||
                    splatData.colorData == null)
                    continue;

                m_LodFormatAsset = splatData;
                return SetLodFormatStrides(splatData);
            }

            return false;
        }

        bool SetLodFormatStrides(GaussianSplatAsset asset)
        {
            // Cluster lookup indices are page-local; concatenating their independent SH tables
            // cannot be decoded with a single atlas descriptor. Unclustered High/Medium are safe.
            if (asset.shFormat >= GaussianSplatAsset.SHFormat.Cluster64k)
            {
                m_LodPosBytesPerSplat = m_LodOtherBytesPerSplat = m_LodShBytesPerSplat = 0;
                Debug.LogError("SplatBoxRenderer: paged LoD requires unclustered SH. Rebuild with " +
                               "Quality = Medium, High or Very High.");
                return false;
            }
            m_LodPosBytesPerSplat = GaussianSplatAsset.GetVectorSize(asset.posFormat);
            m_LodOtherBytesPerSplat = GaussianSplatAsset.GetOtherSizeNoSHIndex(asset.scaleFormat);
            m_LodShBytesPerSplat = (int)GaussianSplatAsset.CalcSHDataSize(1, asset.shFormat);
            return true;
        }

        static int LodBufferWordCount(int splatCount, int bytesPerSplat) =>
            Mathf.Max(1, (int)(((long)splatCount * bytesPerSplat + 3) / 4));

        void AllocateLodAtlasBuffers(int atlasSplatCapacity)
        {
            if (!EnsureLodFormatAsset())
            {
                Debug.LogError("SplatBoxRenderer: cannot allocate LoD atlas — no page splat asset with valid format data.");
                return;
            }

            // Last line of defence: an oversized capacity would throw out of the GraphicsBuffer
            // constructor and leave the renderer with no atlas at all.
            atlasSplatCapacity = Mathf.Clamp(atlasSplatCapacity, kAtlasSplatAlignment, MaxAtlasSplatCapacity());

            DisposeLodAtlasBuffers();
            m_LodAtlasCapacity = atlasSplatCapacity;
            if (m_ActiveSplatCount > 0)
            {
                InvalidateLodAsyncSelection();
                m_LodSelectionInvalid = true;
                m_LodSelectionDirty = true;
            }
            m_UnifiedAtlasSplatCount = 0;
            InvalidateUploadedAtlasOffsets();
            int posCount = LodBufferWordCount(atlasSplatCapacity, m_LodPosBytesPerSplat);
            int otherCount = LodBufferWordCount(atlasSplatCapacity, m_LodOtherBytesPerSplat);
            int shCount = LodBufferWordCount(atlasSplatCapacity, m_LodShBytesPerSplat);
            m_GpuLodUnifiedPos = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, posCount), 4) { name = "LodUnifiedPos" };
            m_GpuLodUnifiedOther = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, otherCount), 4) { name = "LodUnifiedOther" };
            m_GpuLodUnifiedSh = new GraphicsBuffer(GraphicsBuffer.Target.Raw,
                Mathf.Max(1, shCount), 4) { name = "LodUnifiedSh" };
            m_GpuLodAtlasIndices = new GraphicsBuffer(GraphicsBuffer.Target.Structured,
                Mathf.Max(m_LodAllocatedBudget, LodBudgetCapacity(EffectiveLodBudget)), 4)
                { name = "LodGatherIndices" };
            var (texW, texH) = GaussianSplatAsset.CalcTextureSize(atlasSplatCapacity);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(m_LodFormatAsset.colorFormat);
            m_GpuLodUnifiedColor = new Texture2D(texW, texH, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
            { name = "LodUnifiedColor" };

            m_GpuLodUnifiedChunks?.Dispose();
            m_LodUnifiedChunkCount = (atlasSplatCapacity + GaussianSplatAsset.kChunkSize - 1) / GaussianSplatAsset.kChunkSize;
            if (m_LodFormatAsset.chunkData != null && m_LodFormatAsset.chunkData.dataSize != 0)
            {
                m_GpuLodUnifiedChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_LodUnifiedChunkCount,
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = "LodUnifiedChunks" };
            }
            else
            {
                m_GpuLodUnifiedChunks = null;
                m_LodUnifiedChunkCount = 0;
            }
        }

        void AllocateActiveRenderBuffers(int budget)
        {
            if (!EnsureLodFormatAsset())
                return;

            m_GpuPosData?.Dispose();
            m_GpuOtherData?.Dispose();
            m_GpuSHData?.Dispose();
            if (m_GpuColorData != null)
            {
                if (Application.isPlaying) Destroy(m_GpuColorData);
                else DestroyImmediate(m_GpuColorData);
            }

            // Paged rendering reads selected splats directly from the unified atlas through
            // m_GpuLodAtlasIndices. These legacy active-data buffers are only non-null fallbacks
            // required by shared renderer bindings; allocating a second full copy of every selected
            // splat wastes well over 100 MB at a 500k Very High budget.
            int posCount = LodBufferWordCount(1, m_LodPosBytesPerSplat);
            int otherCount = LodBufferWordCount(1, m_LodOtherBytesPerSplat);
            int shCount = LodBufferWordCount(1, m_LodShBytesPerSplat);
            m_GpuPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, posCount), 4) { name = "LodActivePos" };
            m_GpuOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, otherCount), 4) { name = "LodActiveOther" };
            m_GpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, Mathf.Max(1, shCount), 4)
                { name = "LodActiveSH" };
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(m_LodFormatAsset.colorFormat);
            m_GpuColorData = new Texture2D(4, 4, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
                { name = "LodActiveColorFallback" };

            if (m_GpuView == null || m_GpuView.count != budget)
            {
                m_GpuView?.Dispose();
                m_GpuView = new GraphicsBuffer(GraphicsBuffer.Target.Structured, budget, kGpuViewDataSize);
            }
            if (m_GpuIndexBuffer == null)
            {
                m_GpuIndexBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Index, 36, 2);
                m_GpuIndexBuffer.SetData(new ushort[]
                {
                    0, 1, 2, 1, 3, 2, 4, 6, 5, 5, 6, 7, 0, 2, 4, 4, 2, 6,
                    1, 5, 3, 5, 7, 3, 0, 4, 1, 4, 5, 1, 2, 3, 6, 3, 7, 6
                });
            }
            InitSortBuffers(budget);
        }

        /// <summary>
        /// The LoD budget is editable at runtime, but it also sizes the view, sort, remap and CPU
        /// selection buffers. Keep those capacities synchronized so raising the budget genuinely
        /// allows a close view to refine beyond the old limit instead of silently clamping to it.
        /// The unified page atlas is independent and is deliberately retained.
        /// </summary>
        // Keep capacity in reasonably sized steps and retain it when the requested budget falls.
        // This avoids reallocating and clearing multiple large buffers on every slider movement.
        static int LodBudgetCapacity(int budget) =>
            Mathf.Min(kLodQualityMaxBudget, ((budget + 249_999) / 250_000) * 250_000);

        void EnsureLodBudgetCapacity()
        {
            int budget = EffectiveLodBudget;
            m_SplatCount = budget;
            int capacity = m_LodAllocatedBudget;
            bool valid =
                capacity >= budget &&
                m_LodActiveScratch != null && m_LodActiveScratch.Length >= capacity &&
                m_LodAtlasIndexScratch != null && m_LodAtlasIndexScratch.Length >= capacity &&
                m_GpuLodAtlasIndices != null && m_GpuLodAtlasIndices.count >= capacity &&
                m_GpuView != null && m_GpuView.count >= capacity &&
                m_GpuSortKeys != null && m_GpuSortKeys.count >= capacity;
            if (valid)
                return;

            InvalidateLodAsyncSelection();
            SplatBoxLodDiagnostics.RecordBudgetRealloc();
            capacity = Mathf.Max(capacity, LodBudgetCapacity(budget));
            AllocateActiveRenderBuffers(capacity);

            m_GpuLodAtlasIndices?.Dispose();
            m_GpuLodAtlasIndices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, capacity, 4)
                { name = "LodGatherIndices" };
            m_LodActiveScratch = new LodActiveSplatRef[capacity];
            m_LodAtlasIndexScratch = new uint[capacity];
            m_LodAllocatedBudget = capacity;
            m_ActiveSplatCount = 0;
            m_DrawArgsValid = false;
            m_LodSelectionDirty = true;
            m_LodSortKeysNeedReset = false;
            m_HasLastLodView = false;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
#endif
        }

        /// <summary>Fresh atlas buffers hold no page data, so every page has to be copied again.</summary>
        void InvalidateUploadedAtlasOffsets() => m_LodStreamer?.InvalidateAtlasResidency();

        void DisposeLodAtlasBuffers()
        {
            DisposePagedAttractorGpuBuffer();
            DisposePagedEditSculptBuffers();
            DisposePagedLodEraseBuffer();
            DisposePagedColorizeBuffer();
            DisposePagedSmudgeBuffer();
            if (ReferenceEquals(m_GpuChunks, m_GpuLodUnifiedChunks))
            {
                m_GpuChunks = null;
                m_GpuChunksValid = false;
            }
            m_GpuLodUnifiedPos?.Dispose();
            m_GpuLodUnifiedOther?.Dispose();
            m_GpuLodUnifiedSh?.Dispose();
            m_GpuLodAtlasIndices?.Dispose();
            m_GpuLodUnifiedPos = null;
            m_GpuLodUnifiedOther = null;
            m_GpuLodUnifiedSh = null;
            m_GpuLodAtlasIndices = null;
            if (m_GpuLodUnifiedColor != null)
            {
                if (Application.isPlaying) Destroy(m_GpuLodUnifiedColor);
                else DestroyImmediate(m_GpuLodUnifiedColor);
                m_GpuLodUnifiedColor = null;
            }
            m_LodAtlasCapacity = 0;
            m_UnifiedAtlasSplatCount = 0;
            m_LodUnifiedChunkCount = 0;
            m_GpuLodUnifiedChunks?.Dispose();
            m_GpuLodUnifiedChunks = null;
        }

        void DisposePagedLodResources()
        {
            DisposePagedSmudgeHierarchy();
            InvalidateLodAsyncSelection();
            m_LodSelectionWorker?.Dispose();
            m_LodSelectionWorker = null;
            if (m_LodStreamer != null)
            {
                m_LodStreamer.OnPagesChanged -= OnLodPagesChanged;
                m_LodStreamer.UnloadAll();
            }
            DisposeLodAtlasBuffers();
            m_LodSelectedDetailPages.Clear();
            m_LodResidentDetailScratch.Clear();
            m_LodSelectionInvalid = false;
            m_LodRefinementSelectionPending = false;
            m_LodCoverageRefinementPending = false;
            m_LastLodBudgetCutoff = 0f;
            m_LodPageContextScratch = null;
            m_LodActiveScratch = null;
            m_LodAtlasIndexScratch = null;
            m_LodAllocatedBudget = 0;
            m_LodFormatAsset = null;
            m_LodPosBytesPerSplat = m_LodOtherBytesPerSplat = m_LodShBytesPerSplat = 0;
            m_AtlasPageOffset = m_AtlasPageReserve = null;
            m_AtlasPageIndex.Clear();
            m_AtlasLayoutTotal = 0;
            m_ActiveSplatCount = 0;
            m_HasLastLodView = false;
            m_LodDrivingCamera = null;
            m_LodAsyncFailed = false;
            m_LodAtlasDirty = m_LodSelectionDirty = true;
            m_LodSortKeysNeedReset = false;
            m_LodPendingSettledReselect = false;
            m_LastPlayLodSelectTime = -999f;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
#endif
        }

        SplatBoxLodTraverser.PageContext[] m_LodPageContextScratch;
        SplatBoxLodTraverser.Workspace m_LodWorkspace;
        Vector3 m_LastLodViewPos;
        Quaternion m_LastLodViewRot = Quaternion.identity;
        bool m_HasLastLodView;
        int m_LastLodViewSignature;
        int m_AsyncLodViewSignature;
        float m_PendingLodTranslationPrefetch;
        float m_LastLodTranslationPrefetch;
        float m_AsyncLodTranslationPrefetch;
        Camera m_LodDrivingCamera;
        bool m_LodSelectionInvalid;
        // The last requested frontier was still refining. Keep one final request due after the
        // clock expires, so a stationary camera cannot stop just short of the complete tree.
        bool m_LodRefinementSelectionPending;
        // A bounded current-view frontier is temporary; one exact requested-quality worker must
        // replace it even if the camera stops before another ordinary refresh becomes due.
        bool m_LodCoverageRefinementPending;
        bool m_PendingLodCoverageProvisional;
        readonly List<SplatBoxPageGpuState> m_LodSelectedDetailPages = new List<SplatBoxPageGpuState>();
        readonly HashSet<SplatBoxPageGpuState> m_LodResidentDetailScratch = new HashSet<SplatBoxPageGpuState>();
        bool[] m_LodSelectedSlotScratch;
        uint m_LodSelectionRevision;
        bool m_LodSortKeysNeedReset;
        SplatBoxLodSelectionWorker m_LodSelectionWorker;
        uint m_LodAsyncGeneration;
        uint m_AsyncLodGeneration;
        uint m_LodPageEventSequence;
        uint m_AsyncLodPageEventSequence;
        int m_AsyncLodSettingsHash;
        float m_AsyncLodPixelCutoff;
        float m_AsyncLodStartTime;
        Vector3 m_AsyncLodViewPos;
        Quaternion m_AsyncLodViewRot;
        bool m_LodAsyncFailed;
        float m_LastLodWorkerMs;
        string m_LastLodSynchronousReason = "none";
        int m_LodSynchronousSelectionCount;
        int m_LodProvisionalCoverageCount;

        void InvalidateLodAsyncSelection()
        {
            unchecked { m_LodAsyncGeneration++; }
            m_LodSelectionWorker?.DiscardPending();
        }

        public void UpdatePagedLod(Camera cam, CommandBuffer cmd)
        {
            if (!UsesPagedLod || m_CSBoxUtil == null || cam == null)
                return;
            RefreshPagedCopyBoundary();
            if (m_LodStreamer == null)
                EnsureLodStreamer();
            Camera driver = ResolvePagedLodCamera();
            // URP's global eye matrices and target dimensions belong to the incoming callback.
            // Replacing its Camera reference with Main Camera does not replace those globals:
            // a Scene/preview/overlay callback would still build Main Camera's selection from
            // another view. Leave the published selection untouched until the driver renders.
            if (driver != null && cam != driver)
                return;
            using var editorCameraContext = GaussianSplatRenderSystem.UseEditorLodCameraContext(cam);
            if (hasMismatchedLodSplatOrder)
            {
                m_ActiveSplatCount = 0;
                return;
            }

            // This runs once per camera that renders the splats, but streaming and the selection
            // are single global states. Only the driving camera's view may shape them: when every
            // camera re-selected for its own frustum, the Scene view, Game view and previews took
            // turns culling the selection for themselves, and each view flickered between "built
            // for me" and "built for another view" — more violently the larger the budget, since
            // a bigger budget concentrates more of the scene inside one frustum.
            if (driver != null)
                cam = driver;
            m_LodDrivingCamera = cam;

            EnsureLodBudgetCapacity();
            EnsureLodStreamer();
            EnsurePagedSmudgeHierarchy();
            if (!m_LodAtlasDirty)
            {
                EnsurePagedSmudgeState(cmd);
                EnsurePagedLodEraseState(cmd);
                EnsurePagedColorizeState(cmd);
            }

            bool wasDirty = m_LodSelectionDirty;
            bool viewChanged = HasLodViewChanged(cam);
            // A completed worker still owns its snapshot until TryComplete consumes it. Publish
            // before an ordinary slot eviction can discard that finished work. Dirty atlas data
            // must be copied first, so those results retain the validated late-publication path.
            bool ranSelection = !m_LodAtlasDirty && TryApplyAsyncLodSelection(cmd);
            bool allowDetailTransitions = m_LodSelectionWorker == null || !m_LodSelectionWorker.isRunning;
            m_LodStreamer.UpdateStreaming(cam, transform, allowDetailTransitions: allowDetailTransitions);
            EnsurePagedSmudgeHierarchy();

            // A selection can also be rebuilt by an editor command that has no render command
            // buffer. Restore a valid identity permutation before this camera draws it.
            if (m_LodSortKeysNeedReset && cmd != null)
                ResetLodSortKeys(cmd);

            bool rebuildAtlas = m_LodAtlasDirty;
            if (rebuildAtlas)
            {
                m_LodTimer.Restart();
                RebuildLodUnifiedAtlas(cmd);
                m_LastLodAtlasMs = (float)m_LodTimer.Elapsed.TotalMilliseconds;
            }

            wasDirty |= m_LodSelectionDirty;
            viewChanged |= HasLodViewChanged(cam);
            bool lateSelection = TryApplyAsyncLodSelection(cmd);
            ranSelection |= lateSelection;
            bool immediateSelection = RequiresImmediateLodSelection(cam);
            bool retiredAfterDeferredStreaming = !allowDetailTransitions &&
                (m_LodSelectionWorker == null || !m_LodSelectionWorker.isRunning);
            // A result can finish or be rejected during streaming/atlas uploads. If streaming was deferred,
            // leave its newly idle worker free until next frame's ordinary transition opportunity
            // rather than immediately taking another snapshot and starving slot reassignment.
            if ((immediateSelection || !retiredAfterDeferredStreaming) && ShouldRefreshLodSelection(cam) &&
                (m_LodSelectionWorker == null || !m_LodSelectionWorker.isRunning || immediateSelection))
            {
                uint before = m_LodSelectionRevision;
                SelectAndGatherLodSplats(cam, cmd, allowAsync: !immediateSelection);
                ranSelection |= before != m_LodSelectionRevision;
            }

            if (ranSelection)
            {
                SplatBoxLodDiagnostics.RecordSelection(m_ActiveSplatCount, wasDirty, viewChanged,
                    ramping: HasPendingLodRefinement(), m_LodWorkspace?.budgetExhausted ?? false,
                    m_LodWorkspace?.droppedMerged ?? 0);
            }
            SplatBoxLodDiagnostics.Heartbeat(m_ActiveSplatCount);
        }

        readonly System.Diagnostics.Stopwatch m_LodTimer = new System.Diagnostics.Stopwatch();
        float m_LastLodSelectMs;
        float m_LastLodAtlasMs;

        /// <summary>
        /// Main-thread milliseconds spent scheduling or publishing the last LoD selection. Includes
        /// traversal and atlas index gathering when a synchronous selection is required.
        /// </summary>
        public float lastLodSelectMs => m_LastLodSelectMs;

        /// <summary>Main-thread milliseconds the last atlas rebuild took.</summary>
        public float lastLodAtlasMs => m_LastLodAtlasMs;
        public float lastLodWorkerMs => m_LastLodWorkerMs;
        public bool usesBurstLodTraversal => m_LodWorkspace?.usedBurst ?? false;
        public bool usesDepthFirstLodTraversal => m_LodWorkspace?.usedDepthFirst ?? false;
        public bool lastLodBudgetExhausted => m_LodWorkspace?.budgetExhausted ?? false;
        public string lastLodSynchronousReason => m_LastLodSynchronousReason;
        public int lodSynchronousSelectionCount => m_LodSynchronousSelectionCount;
        public int cancelledLodWorkerSelections => m_LodSelectionWorker?.cancelledSelectionCount ?? 0;
        public bool usesProvisionalLodCoverage => m_LodCoverageRefinementPending;
        public int lodProvisionalCoverageCount => m_LodProvisionalCoverageCount;

        /// <summary>
        /// Re-selecting walks the whole LoD budget. Both editor and play use a steady cadence so
        /// orbit/look-around updates frustum selection without freezing until the camera stops
        /// (that lag left missing splats in the new view direction).
        /// </summary>
        bool ShouldRefreshLodSelection(Camera cam) =>
            ShouldRefreshLodSelectionForPlatform(cam, Application.platform, Application.isPlaying);

        bool ShouldRefreshLodSelectionForPlatform(Camera cam, RuntimePlatform platform, bool isPlaying)
        {
            float now = Time.realtimeSinceStartup;
            bool dueByInterval = now - m_LastPlayLodSelectTime >= EffectiveLodSelectInterval;
            float padding = LodCullPaddingForPlatform(m_LodSimpleMode, m_LodCullPaddingDeg, platform);

            if (m_LodSelectionInvalid || (m_HasLastLodView &&
                LodViewCoverageExceededForPadding(cam, m_LastLodViewPos, m_LastLodViewRot, 1f, padding)))
                return true;

            // Queue the exact replacement as soon as a canceled old worker retires. The caller
            // waits for an idle worker, so this does not republish the provisional frontier.
            if (m_LodCoverageRefinementPending && m_LodAsyncTraversal && !m_LodAsyncFailed)
                return true;

            bool earlyMotion = m_LodAsyncTraversal && !m_LodAsyncFailed &&
                m_HasLastLodView && HasLodViewChanged(cam) &&
                LodViewCoverageExceededForPadding(cam, m_LastLodViewPos, m_LastLodViewRot,
                    LodEarlyCoverageFractionForPlatform(m_LodSimpleMode, platform), padding);
            // Keep the Android worker's start near two degrees even though its safety reserve is
            // now twenty. Page arrivals or progressive refinement must not postpone that start;
            // their normal cadence still applies while the camera is stationary.
            if (platform == RuntimePlatform.Android && m_LodSimpleMode && earlyMotion)
                return true;

            if (m_LodSelectionDirty)
                return dueByInterval || !m_HasLastLodView;

            if (ShouldApplyPendingSettledReselect())
                return dueByInterval;

            if (HasPendingLodRefinement())
                return dueByInterval;

            if (!HasLodViewChanged(cam))
                return false;

            // Queue covered camera motion before the old frustum runs out of padding. The worker
            // still owns at most one selection; only an uncovered view forces synchronous work.
            return dueByInterval || (!m_LodPendingSettledReselect && earlyMotion);
        }

        bool HasPendingLodRefinement()
        {
            if (m_LodRefinementSelectionPending)
                return true;
            var pages = m_LodStreamer?.loadedPages;
            if (pages == null)
                return false;
            float now = Time.realtimeSinceStartup;
            for (int i = 0; i < pages.Count; i++)
                if (pages[i] != null && pages[i].HasPendingRefinement(now))
                    return true;
            return false;
        }

        Vector3 m_LodMotionPos;
        Quaternion m_LodMotionRot = Quaternion.identity;
        float m_LodLastMotionTime = -999f;
        bool m_HasLodMotionSample;
        bool m_LodPendingSettledReselect;
        float m_LodLastPageEventTime = -999f;
        float m_LastPlayLodSelectTime = -999f;
        // ~12 Hz. Fast enough that orbiting does not show empty frustum sides; slow enough that
        // traverse+upload+sort cannot run every Scene View repaint.
        const float kLodSelectInterval = 0.08f;

        float EffectiveLodSelectInterval => kLodSelectInterval;

        /// <summary>
        /// True while the driving camera has moved or rotated recently (diagnostics / page defer).
        /// </summary>
        bool IsLodCameraMoving(Camera cam)
        {
            if (cam == null)
                return false;

            var xf = cam.transform;
            float now = Time.realtimeSinceStartup;
            if (!m_HasLodMotionSample)
            {
                m_LodMotionPos = xf.position;
                m_LodMotionRot = xf.rotation;
                m_LodLastMotionTime = now;
                m_HasLodMotionSample = true;
                return false;
            }

            const float kMoveThreshold = 0.01f;
            const float kRotateThresholdDeg = 0.25f;
            bool moved =
                (xf.position - m_LodMotionPos).sqrMagnitude > kMoveThreshold * kMoveThreshold ||
                Quaternion.Angle(xf.rotation, m_LodMotionRot) > kRotateThresholdDeg;
            m_LodMotionPos = xf.position;
            m_LodMotionRot = xf.rotation;
            if (moved)
                m_LodLastMotionTime = now;

            return now - m_LodLastMotionTime < kLodSelectInterval;
        }

#if UNITY_EDITOR
        bool IsEditorLodCameraMoving(Camera cam) => IsLodCameraMoving(cam);
#endif

        /// <summary>
        /// True when streaming finished a burst of page swaps and enough quiet time passed to fold
        /// them into one rate-limited reselection.
        /// </summary>
        bool ShouldApplyPendingSettledReselect()
        {
            if (!m_LodPendingSettledReselect)
                return false;
            // Longer than the select interval so a burst of coarse uploads (one per frame) collapses
            // into a single refresh after streaming quiets, instead of reselecting on every arrival.
            float now = Time.realtimeSinceStartup;
            return now - m_LodLastPageEventTime >= 0.25f ||
                   now - m_LastPlayLodSelectTime >= 0.25f;
        }

        float m_LastLodSelectTime;

        /// <summary>Changes whenever the active atlas-index list changes.</summary>
        internal uint lodSelectionRevision => m_LodSelectionRevision;

        bool RequiresImmediateLodSelection(Camera cam) =>
            m_LodSelectionInvalid || (m_HasLastLodView &&
                LodViewCoverageExceeded(cam, m_LastLodViewPos, m_LastLodViewRot));

        bool LodViewCoverageExceeded(Camera cam, Vector3 selectedPosition, Quaternion selectedRotation,
            float coverageFraction = 1f) =>
            LodViewCoverageExceededForPadding(cam, selectedPosition, selectedRotation,
                coverageFraction, EffectiveCullPaddingDeg);

        bool LodViewCoverageExceededForPadding(Camera cam, Vector3 selectedPosition, Quaternion selectedRotation,
            float coverageFraction, float padding) =>
            LodViewCoverageExceededForSnapshot(cam, selectedPosition, selectedRotation,
                coverageFraction, padding, m_LastLodTranslationPrefetch);

        bool LodViewCoverageExceededForSnapshot(Camera cam, Vector3 selectedPosition, Quaternion selectedRotation,
            float coverageFraction, float padding, float translationPrefetch)
        {
            if (cam == null || !EffectiveFrustumCull)
                return false;

            GetLodViewPose(cam, out Vector3 position, out Quaternion rotation);
            // Padding expands each frustum edge by half the configured angle. Reserve a fifth of
            // that margin for motion between render callbacks instead of waiting for visible holes.
            float rotationMargin = Mathf.Max(0.5f, padding * 0.4f);
            if (Quaternion.Angle(rotation, selectedRotation) > rotationMargin * coverageFraction)
                return true;

            // A captured world-space reserve covers translation in every direction, including
            // backwards across the old near plane. Never infer it from the current profile: the
            // published or queued selection may have been built without that reserve.
            float distance = Mathf.Max(0.5f, m_LodNearestPageDist);
            float translationMargin = (translationPrefetch > 0f
                ? translationPrefetch * 0.8f
                : Mathf.Clamp(distance * Mathf.Tan(rotationMargin * Mathf.Deg2Rad), 0.05f, 0.5f)) * coverageFraction;
            return (position - selectedPosition).sqrMagnitude > translationMargin * translationMargin;
        }

        static void GetLodViewPose(Camera cam, out Vector3 position, out Quaternion rotation)
        {
            GaussianSplatRenderSystem.GetCameraViewProj(cam, out Matrix4x4 view, out _);
            Matrix4x4 leftToWorld = view.inverse;
            Matrix4x4 rightToWorld = leftToWorld;
            if (GaussianSplatRenderSystem.s_OverrideStereoViewCount == 2)
            {
                leftToWorld = GaussianSplatRenderSystem.s_OverrideStereoView[0].inverse;
                rightToWorld = GaussianSplatRenderSystem.s_OverrideStereoView[1].inverse;
            }
            else if (cam.stereoEnabled)
            {
                leftToWorld = cam.GetStereoViewMatrix(Camera.StereoscopicEye.Left).inverse;
                rightToWorld = cam.GetStereoViewMatrix(Camera.StereoscopicEye.Right).inverse;
            }
            position = ((Vector3)leftToWorld.GetColumn(3) + (Vector3)rightToWorld.GetColumn(3)) * 0.5f;
            Vector3 forward = -((Vector3)leftToWorld.GetColumn(2) + (Vector3)rightToWorld.GetColumn(2));
            Vector3 up = (Vector3)leftToWorld.GetColumn(1) + (Vector3)rightToWorld.GetColumn(1);
            rotation = Quaternion.LookRotation(forward, up);
        }

        bool HasLodViewChanged(Camera cam)
        {
            if (cam == null)
                return false;
            if (!m_HasLastLodView)
                return true;

            const float kMoveThreshold = 0.02f;
            const float kRotateThresholdDeg = 0.5f;
            GetLodViewPose(cam, out Vector3 position, out Quaternion rotation);
            return (position - m_LastLodViewPos).sqrMagnitude > kMoveThreshold * kMoveThreshold ||
                   Quaternion.Angle(rotation, m_LastLodViewRot) > kRotateThresholdDeg ||
                   LodViewSignature(cam) != m_LastLodViewSignature;
        }

        void RecordLodViewpoint(Camera cam)
        {
            m_LastLodTranslationPrefetch = m_PendingLodTranslationPrefetch;
            if (cam == null)
                return;
            GetLodViewPose(cam, out m_LastLodViewPos, out m_LastLodViewRot);
            m_LastLodViewSignature = LodViewSignature(cam);
            m_HasLastLodView = true;
        }

        static int LodViewSignature(Camera cam)
        {
            GaussianSplatRenderSystem.GetCameraViewProj(cam, out _, out Matrix4x4 projection);
            unchecked
            {
                int signature = cam.GetEntityId().GetHashCode();
                signature = signature * 397 ^ projection.GetHashCode();
                signature = signature * 397 ^ GaussianSplatRenderSystem.GetSplatScreenParams(cam).GetHashCode();
                signature = signature * 397 ^ cam.orthographic.GetHashCode();
                if (GaussianSplatRenderSystem.s_OverrideStereoViewCount == 2)
                    signature = signature * 397 ^ GaussianSplatRenderSystem.s_OverrideStereoProjection[1].GetHashCode();
                else if (cam.stereoEnabled)
                    signature = signature * 397 ^ cam.GetStereoProjectionMatrix(Camera.StereoscopicEye.Right).GetHashCode();
                return signature;
            }
        }

        void RebuildLodUnifiedAtlas(CommandBuffer cmd)
        {
            SplatBoxLodDiagnostics.RecordAtlasRebuild();
            m_LodAtlasDirty = false;
            EnsureAtlasLayout();
            var pages = m_LodStreamer.loadedPages;
            if (m_AtlasLayoutTotal <= 0 || pages.Count == 0)
            {
                m_UnifiedAtlasSplatCount = 0;
                SyncPagedLodChunkBindings(false);
                return;
            }

            EnsureLodAtlasCapacity(m_AtlasLayoutTotal);

            int copyKernel = GetKernelIndex(KernelIndices.CopyBufferRange);
            bool copiedChunks = false;
            int resident = 0;
            for (int p = 0; p < pages.Count; p++)
            {
                var page = pages[p];
                if (page == null || !page.IsReady)
                    continue;

                int atlasOffset = ResolveAtlasOffset(page);
                page.atlasOffset = atlasOffset;
                if (atlasOffset < 0)
                    continue;

                // A page's address is fixed, so anything already sitting in the right place is left
                // alone and only genuinely new data is copied.
                if (page.uploadedAtlasOffset != atlasOffset)
                {
                    CopyPageToAtlasGpu(cmd, copyKernel, page, atlasOffset);
                    page.uploadedAtlasOffset = atlasOffset;
                }
                copiedChunks = copiedChunks || (page.gpuChunksValid && page.chunkInfos != null);
                resident++;
            }

            m_UnifiedAtlasSplatCount = resident > 0 ? m_AtlasLayoutTotal : 0;
            SyncPagedLodChunkBindings(copiedChunks);
            EnsurePagedSmudgeState(cmd);
            EnsurePagedLodEraseState(cmd);
            EnsurePagedColorizeState(cmd);
            // Fixed atlas addresses mean an existing selection stays valid when a far coarse page
            // is merely copied in. Selection is dirtied by OnLodPagesChanged when full-detail
            // residency changes, or by the settled-reselect path after a quiet burst.
            m_LodLastPageEventTime = Time.realtimeSinceStartup;
            if (m_ActiveSplatCount <= 0)
            {
                m_LodSelectionDirty = true;
                m_LodPendingSettledReselect = true;
            }
            else if (!m_LodSelectionDirty)
            {
                m_LodPendingSettledReselect = true;
            }
        }

        bool CopyPageToAtlasGpu(CommandBuffer cmd, int copyKernel, SplatBoxPageGpuState page, int atlasOffset)
        {
            if (page.splatCount <= 0)
                return false;

            bool copiedGpu = false;
            if (cmd != null && copyKernel >= 0)
            {
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodCopyCount, page.splatCount);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodCopyDstOffset, atlasOffset);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodPosBytesPerSplat, m_LodPosBytesPerSplat);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodOtherBytesPerSplat, m_LodOtherBytesPerSplat);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodShBytesPerSplat, m_LodShBytesPerSplat);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopySrcPos, page.gpuPosData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopySrcOther, page.gpuOtherData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopySrcSh, page.gpuSHData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopyDstPos, m_GpuLodUnifiedPos);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopyDstOther, m_GpuLodUnifiedOther);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopyDstSh, m_GpuLodUnifiedSh);

                uint gsX = 64;
                m_CSBoxUtil.GetKernelThreadGroupSizes(copyKernel, out gsX, out _, out _);
                if (gsX > 0)
                {
                    // Copy four splats per thread so 2/6-byte packed strides stay word aligned.
                    int copyBlocks = (page.splatCount + 3) / 4;
                    int groups = (copyBlocks + (int)gsX - 1) / (int)gsX;
                    if (groups > 0)
                    {
                        cmd.DispatchCompute(m_CSBoxUtil, copyKernel, groups, 1, 1);
                        copiedGpu = true;
                    }
                }
            }

            if (!copiedGpu)
                CopyPageToAtlasCpu(page, atlasOffset);

            if (page.gpuColorData is Texture2D pageTex && m_GpuLodUnifiedColor != null)
                CopySplatColorRange(pageTex, m_GpuLodUnifiedColor, 0, atlasOffset, page.splatCount);

            if (page.gpuChunksValid && m_GpuLodUnifiedChunks != null && page.chunkInfos != null)
            {
                int dstChunk = atlasOffset / GaussianSplatAsset.kChunkSize;
                int chunkCount = Mathf.Min(page.chunkInfos.Length,
                    (page.splatCount + GaussianSplatAsset.kChunkSize - 1) / GaussianSplatAsset.kChunkSize);
                if (dstChunk + chunkCount <= m_LodUnifiedChunkCount)
                    m_GpuLodUnifiedChunks.SetData(page.chunkInfos, 0, dstChunk, chunkCount);
            }

            ReplayPagedSmudgePage(cmd, page, atlasOffset);
            ReplayPagedAttractorPage(cmd, page, atlasOffset);
            ReplayPagedLodErasePage(cmd, page, atlasOffset);
            ReplayPagedColorizePage(cmd, page, atlasOffset);
            return true;
        }

        void CopyPageToAtlasCpu(SplatBoxPageGpuState page, int atlasOffset)
        {
            var asset = page.source != null ? page.source.splatData : null;
            if (asset == null || page.splatCount <= 0)
                return;

            int posWords = LodBufferWordCount(page.splatCount, m_LodPosBytesPerSplat);
            int otherWords = LodBufferWordCount(page.splatCount, m_LodOtherBytesPerSplat);
            int shWords = LodBufferWordCount(page.splatCount, m_LodShBytesPerSplat);
            int dstPosBase = atlasOffset * m_LodPosBytesPerSplat / 4;
            int dstOtherBase = atlasOffset * m_LodOtherBytesPerSplat / 4;
            int dstShBase = atlasOffset * m_LodShBytesPerSplat / 4;

            m_GpuLodUnifiedPos.SetData(asset.posData.GetData<uint>(), 0, dstPosBase, posWords);
            m_GpuLodUnifiedOther.SetData(asset.otherData.GetData<uint>(), 0, dstOtherBase, otherWords);
            m_GpuLodUnifiedSh.SetData(asset.shData.GetData<uint>(), 0, dstShBase, shWords);
        }

        /// <summary>
        /// Copies a range of splat colours between textures that use the shader's 16x16 Morton-tile
        /// layout. A splat offset is not a row-major pixel offset: for example splat 2048 starts at
        /// pixel (128,0), not (0,1). Treating it as row-major was placing every page's colours at the
        /// wrong atlas coordinates.
        /// </summary>
        static void CopySplatColorRange(
            Texture2D src, Texture2D dst, int srcSplatStart, int dstSplatStart, int splatCount)
        {
            if (src == null || dst == null || splatCount <= 0)
                return;

            const int tileSize = 16;
            const int splatsPerTile = tileSize * tileSize;

            // Atlas regions are chunk aligned. Copy whole Morton tiles, batching adjacent tiles into
            // a single CopyTexture region. The final tile may contain padding, which is safe because
            // every atlas region is padded to kAtlasSplatAlignment.
            if (srcSplatStart % splatsPerTile == 0 && dstSplatStart % splatsPerTile == 0)
            {
                int srcTilesPerRow = src.width / tileSize;
                int dstTilesPerRow = dst.width / tileSize;
                int srcTile = srcSplatStart / splatsPerTile;
                int dstTile = dstSplatStart / splatsPerTile;
                int tilesLeft = (splatCount + splatsPerTile - 1) / splatsPerTile;

                while (tilesLeft > 0)
                {
                    int srcTileX = srcTile % srcTilesPerRow;
                    int srcTileY = srcTile / srcTilesPerRow;
                    int dstTileX = dstTile % dstTilesPerRow;
                    int dstTileY = dstTile / dstTilesPerRow;
                    int run = Mathf.Min(
                        tilesLeft,
                        srcTilesPerRow - srcTileX,
                        dstTilesPerRow - dstTileX);
                    if (run <= 0 ||
                        (srcTileY + 1) * tileSize > src.height ||
                        (dstTileY + 1) * tileSize > dst.height)
                        break;

                    Graphics.CopyTexture(
                        src, 0, 0, srcTileX * tileSize, srcTileY * tileSize, run * tileSize, tileSize,
                        dst, 0, 0, dstTileX * tileSize, dstTileY * tileSize);
                    srcTile += run;
                    dstTile += run;
                    tilesLeft -= run;
                }
                return;
            }

            // Defensive slow path for a future caller that supplies an unaligned range.
            for (int i = 0; i < splatCount; i++)
            {
                Vector2Int srcPixel = SplatIndexToColorPixel(srcSplatStart + i, src.width);
                Vector2Int dstPixel = SplatIndexToColorPixel(dstSplatStart + i, dst.width);
                if (srcPixel.y >= src.height || dstPixel.y >= dst.height)
                    break;
                Graphics.CopyTexture(
                    src, 0, 0, srcPixel.x, srcPixel.y, 1, 1,
                    dst, 0, 0, dstPixel.x, dstPixel.y);
            }
        }

        static Vector2Int SplatIndexToColorPixel(int index, int textureWidth)
        {
            uint t = (uint)(index & 0xFF);
            t = (t & 0xFF) | ((t & 0xFE) << 7);
            t &= 0x5555;
            t = (t ^ (t >> 1)) & 0x3333;
            t = (t ^ (t >> 2)) & 0x0F0F;

            int tile = index >> 8;
            int tilesPerRow = textureWidth / 16;
            return new Vector2Int(
                (tile % tilesPerRow) * 16 + (int)(t & 0xF),
                (tile / tilesPerRow) * 16 + (int)(t >> 8));
        }

        void SelectAndGatherLodSplats(Camera cam, CommandBuffer cmd, bool allowAsync = false)
        {
            m_LodTimer.Restart();
            SelectAndGatherLodSplatsCore(cam, cmd, allowAsync);
            m_LastLodSelectMs = (float)m_LodTimer.Elapsed.TotalMilliseconds;
        }

        void SelectAndGatherLodSplatsCore(Camera cam, CommandBuffer cmd, bool allowAsync = false)
            => SelectAndGatherLodSplatsForPlatform(cam, cmd, allowAsync,
                Application.platform, Application.isPlaying);

        void SelectAndGatherLodSplatsForPlatform(Camera cam, CommandBuffer cmd, bool allowAsync,
            RuntimePlatform platform, bool isPlaying)
        {
            var pages = m_LodStreamer.loadedPages;
            if (pages.Count == 0)
            {
                m_PendingLodTranslationPrefetch = 0f;
                if (m_ActiveSplatCount > 0 || m_LodSelectionInvalid)
                    MarkLodSelectionChanged();
                m_ActiveSplatCount = 0;
                m_LodSelectionInvalid = false;
                m_LodSelectionDirty = false;
                m_LodPendingSettledReselect = false;
                m_LodRefinementSelectionPending = false;
                m_LodCoverageRefinementPending = false;
                m_LodSelectedDetailPages.Clear();
                m_LastPlayLodSelectTime = Time.realtimeSinceStartup;
                RecordLodViewpoint(cam);
                return;
            }

            m_LastLodSelectTime = Time.realtimeSinceStartup;

            // Final selections run at the full budget. Android and Edit mode can briefly publish bounded
            // current-view coverage after a rapid turn outruns an expensive budgeted worker;
            // exact background refinement then replaces it. Ordinary navigation keeps its budget.
            int budget = EffectiveLodBudget;

            bool background = allowAsync && m_LodAsyncTraversal &&
                              !m_LodAsyncFailed && !RequiresImmediateLodSelection(cam) && m_HasLastLodView;
            string synchronousReason = m_LodSelectionInvalid ? "page-ownership" :
                !m_HasLastLodView ? "initial" :
                RequiresImmediateLodSelection(cam) ? "view-coverage" :
                (!m_LodAsyncTraversal || m_LodAsyncFailed) ? "async-disabled" : "explicit";
            bool boundedCoverage = ShouldUseBoundedLodCoverage(cam, background,
                platform, isPlaying);
            if (!background)
                InvalidateLodAsyncSelection();
            int selected = SelectLoadedSplatsWithLodCore(cam, pages, budget, m_LodActiveScratch,
                background, boundedCoverage);
            if (selected < 0)
                return; // A worker owns the new traversal; keep drawing the current selection.
            m_LastLodSynchronousReason = background ? "async-unavailable" : synchronousReason;
            unchecked { m_LodSynchronousSelectionCount++; }
            ApplyLodSelection(pages, selected, m_LodActiveScratch, cam, cmd);
            RecordPagedAttractorSelection(m_PendingAttractorCompleteCoverage,
                m_LodWorkspace?.droppedMerged ?? 0, m_PendingAttractorPoseRevision);
            m_LodCoverageRefinementPending = m_PendingLodCoverageProvisional;
            if (m_LodCoverageRefinementPending)
                unchecked { m_LodProvisionalCoverageCount++; }
        }

        bool ShouldUseBoundedLodCoverage(Camera cam, bool background, RuntimePlatform platform, bool isPlaying) =>
            !background && ((isPlaying && platform == RuntimePlatform.Android) ||
                (!isPlaying && (platform == RuntimePlatform.WindowsEditor ||
                    platform == RuntimePlatform.OSXEditor || platform == RuntimePlatform.LinuxEditor))) &&
            m_LodSimpleMode &&
            m_LodAsyncTraversal && !m_LodAsyncFailed && m_HasLastLodView &&
            HasLodBudgetPressureHistory(cam) &&
            RequiresImmediateLodSelection(cam);

        bool HasLodBudgetPressureHistory(Camera cam) => cam != null && m_LastLodBudgetCutoff > 0f &&
            ReferenceEquals(m_LastLodBudgetScene, m_PagedScene) &&
            m_LastLodBudgetSettingsHash == LodSelectionSettingsHash() &&
            m_LastLodBudgetViewSignature == LodViewSignature(cam);

        void RecordLodBudgetPressure(float cutoff, int settingsHash, int viewSignature)
        {
            m_LastLodBudgetCutoff = cutoff;
            m_LastLodBudgetSettingsHash = settingsHash;
            m_LastLodBudgetViewSignature = viewSignature;
            m_LastLodBudgetScene = m_PagedScene;
        }

        void ApplyLodSelection(IReadOnlyList<SplatBoxPageGpuState> pages, int selected,
            LodActiveSplatRef[] active, Camera cam, CommandBuffer cmd,
            uint[] gatheredIndices = null, bool[] selectedSlots = null)
        {
            if (m_LodAtlasIndexScratch != null && selected > m_LodAtlasIndexScratch.Length)
                selected = m_LodAtlasIndexScratch.Length;
            if (selected <= 0)
                m_PendingLodTranslationPrefetch = 0f;
            RecordLodViewpoint(cam);

            // Resolving each selected splat's page by scanning the page list would be hundreds of
            // thousands of scans per selection, so the offsets are gathered into a slot table first.
            int[] slotAtlasBase = BuildSlotAtlasBaseTable(pages);
            if (m_LodSelectedSlotScratch == null || m_LodSelectedSlotScratch.Length < slotAtlasBase.Length)
                m_LodSelectedSlotScratch = new bool[slotAtlasBase.Length];
            else
                Array.Clear(m_LodSelectedSlotScratch, 0, m_LodSelectedSlotScratch.Length);
            if (gatheredIndices != null && selectedSlots != null)
            {
                Array.Copy(selectedSlots, m_LodSelectedSlotScratch,
                    Mathf.Min(selectedSlots.Length, m_LodSelectedSlotScratch.Length));
            }
            else
            {
                for (int i = 0; i < selected; i++)
                {
                    uint slot = active[i].pageSlot;
                    if (slot < (uint)m_LodSelectedSlotScratch.Length)
                        m_LodSelectedSlotScratch[slot] = true;
                    int atlasBase = slot < (uint)slotAtlasBase.Length ? slotAtlasBase[slot] : 0;
                    m_LodAtlasIndexScratch[i] = (uint)(atlasBase + active[i].splatIndex);
                }
            }

            m_LodSelectedDetailPages.Clear();
            for (int i = 0; i < pages.Count; i++)
            {
                var page = pages[i];
                if (page != null && !page.isCoarseStub && page.pageSlot >= 0 &&
                    page.pageSlot < m_LodSelectedSlotScratch.Length && m_LodSelectedSlotScratch[page.pageSlot])
                    m_LodSelectedDetailPages.Add(page);
            }
            m_LodSelectionInvalid = false;

            m_ActiveSplatCount = selected;
            m_LodPendingSettledReselect = false;
            m_LastPlayLodSelectTime = Time.realtimeSinceStartup;
            if (selected <= 0)
            {
                MarkLodSelectionChanged();
                m_LodSelectionDirty = false;
                return;
            }

            m_GpuLodAtlasIndices.SetData(gatheredIndices ?? m_LodAtlasIndexScratch, 0, 0, selected);
            MarkLodSelectionChanged();
            if (cmd != null)
                ResetLodSortKeys(cmd);
            m_LodSelectionDirty = false;
        }

        int LodSelectionSettingsHash()
        {
            unchecked
            {
                int hash = EffectiveLodBudget;
                hash = hash * 397 ^ EffectivePixelScaleLimit.GetHashCode();
                hash = hash * 397 ^ m_LodDetailScale.GetHashCode();
                hash = hash * 397 ^ lodDetailDistance.GetHashCode();
                hash = hash * 397 ^ m_SplatScale.GetHashCode();
                hash = hash * 397 ^ EffectiveOutsideFoveate.GetHashCode();
                hash = hash * 397 ^ EffectiveBehindFoveate.GetHashCode();
                hash = hash * 397 ^ EffectiveMaxStandInPixels.GetHashCode();
                hash = hash * 397 ^ EffectiveCullPaddingDeg.GetHashCode();
                hash = hash * 397 ^ EffectiveTranslationPrefetchRadius.GetHashCode();
                hash = hash * 397 ^ EffectiveFrustumCull.GetHashCode();
                hash = hash * 397 ^ EffectiveDrawCoarseStandIns.GetHashCode();
                var copyBoundary = PagedXcopyBoundary;
                if (copyBoundary != null)
                    hash = hash * 397 ^ (copyBoundary.transform.worldToLocalMatrix * transform.localToWorldMatrix).GetHashCode();
                return hash * 397 ^ transform.localToWorldMatrix.GetHashCode();
            }
        }

        bool TryApplyAsyncLodSelection(CommandBuffer cmd)
        {
            if (m_LodSelectionWorker == null)
                return false;
            SplatBoxLodSelectionWorker.Result result;
            try
            {
                if (!m_LodSelectionWorker.TryComplete(out result))
                    return false;
            }
            catch (Exception ex)
            {
                m_LodAsyncFailed = true;
                m_LodSelectionDirty = true;
                Debug.LogWarning("SplatBox: background LoD traversal failed; using synchronous selection. " + ex.Message);
                return false;
            }
            if (m_AsyncLodGeneration != m_LodAsyncGeneration ||
                !IsPagedAttractorWorkerPoseValid(result.workspace?.droppedMerged ?? 0) ||
                m_AsyncLodSettingsHash != LodSelectionSettingsHash() ||
                (m_LodDrivingCamera != null &&
                    (m_AsyncLodViewSignature != LodViewSignature(m_LodDrivingCamera) ||
                     LodViewCoverageExceededForSnapshot(m_LodDrivingCamera, m_AsyncLodViewPos,
                         m_AsyncLodViewRot, 1f, EffectiveCullPaddingDeg, m_AsyncLodTranslationPrefetch))))
            {
                m_LodSelectionDirty = true;
                return false;
            }
            var pages = m_LodStreamer.loadedPages;
            int[] bases = BuildSlotAtlasBaseTable(pages);
            // A page can downgrade while the worker is traversing its immutable former tree.
            // Publish only indices that still have resident payloads in the current atlas.
            if (result.atlasIndices != null)
            {
                for (int slot = 0; slot < result.selectedSlots.Length; slot++)
                {
                    if (!result.selectedSlots[slot])
                        continue;
                    if (slot >= bases.Length || bases[slot] < 0 || bases[slot] != result.atlasBases[slot] ||
                        result.maxSplatIndexBySlot[slot] >= (uint)m_LodSlotSplatCount[slot])
                    {
                        m_LodSelectionDirty = true;
                        return false;
                    }
                }
            }
            else
            {
                for (int i = 0; i < result.selected; i++)
                {
                    var entry = result.output[i];
                    if (entry.pageSlot >= (uint)bases.Length || bases[entry.pageSlot] < 0 ||
                        entry.splatIndex >= (uint)m_LodSlotSplatCount[entry.pageSlot])
                    {
                        m_LodSelectionDirty = true;
                        return false;
                    }
                }
            }
            m_LodTimer.Restart();
            m_PendingLodTranslationPrefetch = m_AsyncLodTranslationPrefetch;
            ApplyLodSelection(pages, result.selected, result.output, null, cmd,
                result.atlasIndices, result.selectedSlots);
            m_LastLodSelectMs = (float)m_LodTimer.Elapsed.TotalMilliseconds;
            m_LastLodWorkerMs = (float)result.elapsedMs;
            m_LastLodViewPos = m_AsyncLodViewPos;
            m_LastLodViewRot = m_AsyncLodViewRot;
            m_LastLodViewSignature = m_AsyncLodViewSignature;
            m_HasLastLodView = true;
            m_LastPlayLodSelectTime = m_AsyncLodStartTime;
            m_LodWorkspace ??= new SplatBoxLodTraverser.Workspace();
            m_LodWorkspace.budgetExhausted = result.workspace.budgetExhausted;
            m_LodWorkspace.exhaustedPixelScale = result.workspace.exhaustedPixelScale;
            m_LodWorkspace.emittedLeaves = result.workspace.emittedLeaves;
            m_LodWorkspace.emittedMerged = result.workspace.emittedMerged;
            m_LodWorkspace.droppedMerged = result.workspace.droppedMerged;
            m_LodWorkspace.usedBurst = result.workspace.usedBurst;
            m_LodWorkspace.usedDepthFirst = result.workspace.usedDepthFirst;
            RecordPagedAttractorSelection(m_AsyncAttractorCompleteCoverage,
                result.workspace.droppedMerged, m_AsyncAttractorPoseRevision);
            m_LodCoverageRefinementPending = false;
            m_LastEffectiveCutoff = (result.workspace.budgetExhausted
                ? result.workspace.exhaustedPixelScale : m_AsyncLodPixelCutoff) / Mathf.Max(0.01f, m_LodDetailScale);
            if (result.workspace.budgetExhausted)
                RecordLodBudgetPressure(m_LastEffectiveCutoff, m_AsyncLodSettingsHash, m_AsyncLodViewSignature);
            if (m_AsyncLodPageEventSequence != m_LodPageEventSequence)
                m_LodPendingSettledReselect = true;
            return true;
        }

        void MarkLodSelectionChanged()
        {
            unchecked { m_LodSelectionRevision++; }
            m_LodSortKeysNeedReset = true;
            // The old frustum-cull prefix addressed the previous selection; draw everything until the next cull.
            m_DrawArgsValid = false;
        }

        /// <summary>
        /// Selection indices address a new logical array after every LoD pass, so the old draw
        /// permutation is meaningless. Reset it to identity; the next draw must depth-sort the
        /// new selection before projecting view data, even when an editor tick published it.
        /// </summary>
        void ResetLodSortKeys(CommandBuffer cmd)
        {
            if (cmd == null || m_GpuSortKeys == null || m_ActiveSplatCount <= 0)
                return;

            SplatBoxLodDiagnostics.RecordKeyReset();
            int kernel = GetKernelIndex(KernelIndices.SetIndices);
            if (kernel < 0)
                return;

            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize == 0)
                return;

            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatSortKeys, m_GpuSortKeys);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_ActiveSplatCount);
            cmd.DispatchCompute(m_CSBoxUtil, kernel,
                (m_ActiveSplatCount + (int)groupSize - 1) / (int)groupSize, 1, 1);
            m_LodSortKeysNeedReset = false;
            m_OrderBufferChanged = true; // slot-ordered view buffer must be rebuilt for the identity order
        }

        int[] m_LodSlotAtlasBase;
        int[] m_LodSlotSplatCount;

        int[] BuildSlotAtlasBaseTable(IReadOnlyList<SplatBoxPageGpuState> pages)
        {
            int maxSlot = 0;
            for (int i = 0; i < pages.Count; i++)
            {
                if (pages[i] != null)
                    maxSlot = Mathf.Max(maxSlot, pages[i].pageSlot);
            }

            if (m_LodSlotAtlasBase == null || m_LodSlotAtlasBase.Length <= maxSlot)
            {
                m_LodSlotAtlasBase = new int[maxSlot + 1];
                m_LodSlotSplatCount = new int[maxSlot + 1];
            }
            for (int i = 0; i < m_LodSlotAtlasBase.Length; i++)
            {
                m_LodSlotAtlasBase[i] = -1;
                m_LodSlotSplatCount[i] = 0;
            }

            for (int i = 0; i < pages.Count; i++)
            {
                var p = pages[i];
                if (p != null && p.atlasOffset >= 0 && p.pageSlot >= 0 && p.pageSlot < m_LodSlotAtlasBase.Length)
                {
                    m_LodSlotAtlasBase[p.pageSlot] = p.atlasOffset;
                    m_LodSlotSplatCount[p.pageSlot] = p.splatCount;
                }
            }
            return m_LodSlotAtlasBase;
        }

        int SelectLoadedSplatsWithLod(Camera cam, IReadOnlyList<SplatBoxPageGpuState> pages, int maxSplats,
            LodActiveSplatRef[] output, bool background = false) =>
            SelectLoadedSplatsWithLodCore(cam, pages, maxSplats, output, background, false);

        int SelectLoadedSplatsWithLodCore(Camera cam, IReadOnlyList<SplatBoxPageGpuState> pages, int maxSplats,
            LodActiveSplatRef[] output, bool background, bool boundedCoverage)
        {
            EnsurePagedSmudgeHierarchy();
            m_PendingLodTranslationPrefetch = 0f;
            m_PendingAttractorPoseRevision = m_PagedAttractorPoseRevision;
            m_PendingAttractorCompleteCoverage = false;
            m_PendingLodCoverageProvisional = false;
            if (output == null || output.Length == 0 || maxSplats <= 0)
                return 0;

            maxSplats = Mathf.Min(maxSplats, output.Length);
            int pageCount = pages.Count;
            if (m_LodPageContextScratch == null || m_LodPageContextScratch.Length < pageCount)
                m_LodPageContextScratch = new SplatBoxLodTraverser.PageContext[pageCount];

            var localToWorld = transform.localToWorldMatrix;
            float outsideFoveate = EffectiveOutsideFoveate;
            float behindFoveate = EffectiveBehindFoveate;
            // Give nearby pages more of the shared budget, while retaining useful refinement
            // several metres ahead instead of waiting until the surface is within arm's reach.
            Vector3 focus = cam != null
                ? GaussianSplatRenderSystem.GetStreamingFocusPosition(cam)
                : transform.position;
            float proximityBoostRange = lodDetailDistance * 2f;
            const float kMaxProximityBoost = 8f;
            float nearestPageDist = float.MaxValue;
            int contextCount = 0;
            float refinementTime = Time.realtimeSinceStartup;
            m_LodRefinementSelectionPending = false;
            for (int i = 0; i < pageCount; i++)
            {
                var p = pages[i];
                var tree = p?.lodTree;
                if (tree == null || tree.nodeCount == 0)
                    continue;
                if (p.atlasOffset < 0)
                    continue; // Not placed in the atlas, so its splats cannot be addressed yet.

                float pageDist = m_LodStreamer != null
                    ? m_LodStreamer.DistanceToLoadedPage(focus, p, transform)
                    : 0f;
                nearestPageDist = Mathf.Min(nearestPageDist, pageDist);
                float lodScale;
                if (pageDist <= kHighestDetailDistance)
                {
                    // Contact range: full boost so leaf nodes win the budget race.
                    lodScale = m_LodDetailScale * kMaxProximityBoost;
                }
                else
                {
                    float t = Mathf.InverseLerp(kHighestDetailDistance, proximityBoostRange, pageDist);
                    // Continuous falloff through the requested detail distance and its outer fade.
                    lodScale = m_LodDetailScale * Mathf.Lerp(kMaxProximityBoost, 1f, t * t);
                }

                // Measure coarse prefixes in the same pixel domain as full pages. Reducing their
                // scale also lowers the refinement cutoff, leaving distant coverage at a few large
                // stand-ins even when the splat budget has room for the resident children. Prefix
                // length already bounds their cost; the proximity boost still favours close pages.

                int nodeLimit = p.RefinementNodeLimit(refinementTime);
                m_LodRefinementSelectionPending |= p.HasPendingRefinement(refinementTime);
                LodTreeNode[] originalStandInNodes = null;
                if (m_PagedSmudgeTrees.TryGetValue(p, out var sculpt) &&
                    !ReferenceEquals(sculpt.published, sculpt.original) &&
                    ReferenceEquals(PagedAttractorBaseTree(p), sculpt.published))
                    originalStandInNodes = sculpt.original.nodes;
                m_LodPageContextScratch[contextCount++] = new SplatBoxLodTraverser.PageContext
                {
                    pageSlot = p.pageSlot,
                    nodes = tree.nodes,
                    originalStandInNodes = originalStandInNodes,
                    nodeLimit = nodeLimit,
                    childTable = tree.childTable,
                    childTableStart = tree.childTableStart,
                    localToWorld = localToWorld,
                    lodScale = lodScale,
                    outsideFoveate = outsideFoveate,
                    behindFoveate = behindFoveate
                };
            }

            if (contextCount == 0)
                return 0;

            m_LodWorkspace ??= new SplatBoxLodTraverser.Workspace();
            // A preload without a camera still needs a complete hierarchy frontier. Scanning genuine
            // leaves would bypass a page's refinement limit and omit its coarse coverage.
            if (cam == null)
            {
                m_PendingAttractorCompleteCoverage = PagedXcopyBoundary == null && contextCount <= maxSplats;
                var preloadView = new SplatBoxLodTraverser.ViewContext
                {
                    orthographic = true, pixelScaleFactor = 1f, pixelsPerUnitAtUnitDistance = 1f,
                    cameraForward = new Unity.Mathematics.float3(0, 0, 1), cosHalfFovY = -1f,
                    splatScale = m_SplatScale
                };
                ConfigurePagedCopyView(ref preloadView);
                return SplatBoxLodTraverser.Traverse(m_LodPageContextScratch, contextCount, preloadView,
                    maxSplats, 0f, output, m_LodWorkspace);
            }

            bool frustumCull = EffectiveFrustumCull;
            m_PendingAttractorCompleteCoverage = !frustumCull && PagedXcopyBoundary == null &&
                EffectiveDrawCoarseStandIns && contextCount <= maxSplats;
            float cullPadding = EffectiveCullPaddingDeg;
            float maxStandInPixels = EffectiveMaxStandInPixels;
            bool skipMerged = !EffectiveDrawCoarseStandIns;
            var view = SplatBoxLodTraverser.ViewContext.FromCamera(
                cam, frustumCull, m_LodWorkspace, cullPadding, skipMerged,
                maxStandInPixels, m_SplatScale);
            ConfigurePagedCopyView(ref view);
            m_PendingLodTranslationPrefetch = PadLodTranslationFrustum(view, EffectiveTranslationPrefetchRadius);

            m_LodNearestPageDist = nearestPageDist;
            if (boundedCoverage)
            {
                int selected = TraverseBoundedLodCoverage(view, contextCount, maxSplats, output);
                m_PendingLodCoverageProvisional = true;
                // The worker snapshots page/view metadata and owns separate output/workspace
                // arrays, so it can refine while the main thread publishes this complete frontier.
                TryBeginLodSelection(cam, pages, view, contextCount, maxSplats);
                return selected;
            }
            if (background)
            {
                if (TryBeginLodSelection(cam, pages, view, contextCount, maxSplats) ||
                    m_LodCoverageRefinementPending)
                    return -1;
            }
            // An empty view is valid. Retrying without culling or stand-in filters brought back
            // offscreen pages and giant merged splats, spending the whole budget when looking away.
            int exactSelected = TraverseWithinBudget(view, contextCount, maxSplats, output);
            if (m_LodWorkspace.budgetExhausted)
                RecordLodBudgetPressure(m_LastEffectiveCutoff, LodSelectionSettingsHash(), LodViewSignature(cam));
            return exactSelected;
        }

        bool TryBeginLodSelection(Camera cam, IReadOnlyList<SplatBoxPageGpuState> pages,
            in SplatBoxLodTraverser.ViewContext view, int contextCount, int maxSplats)
        {
            m_LodSelectionWorker ??= new SplatBoxLodSelectionWorker();
            float cutoff = EffectiveTraversalPixelCutoff();
            if (!m_LodSelectionWorker.TryBegin(m_LodPageContextScratch, contextCount, view, maxSplats,
                cutoff, BuildSlotAtlasBaseTable(pages)))
                return false;
            m_AsyncLodGeneration = m_LodAsyncGeneration;
            m_AsyncLodPageEventSequence = m_LodPageEventSequence;
            m_AsyncLodSettingsHash = LodSelectionSettingsHash();
            m_AsyncLodPixelCutoff = cutoff;
            m_AsyncLodStartTime = Time.realtimeSinceStartup;
            GetLodViewPose(cam, out m_AsyncLodViewPos, out m_AsyncLodViewRot);
            m_AsyncLodViewSignature = LodViewSignature(cam);
            m_AsyncLodTranslationPrefetch = m_PendingLodTranslationPrefetch;
            m_AsyncAttractorPoseRevision = m_PendingAttractorPoseRevision;
            m_AsyncAttractorCompleteCoverage = m_PendingAttractorCompleteCoverage;
            return true;
        }

        int TraverseBoundedLodCoverage(in SplatBoxLodTraverser.ViewContext view, int contextCount,
            int maxSplats, LodActiveSplatRef[] output)
        {
            // Convert the last achieved cutoff back into the current raw priority domain. A
            // changed Detail Scale must not reuse the previous scale's raw pixel threshold.
            float cutoff = Mathf.Max(EffectiveTraversalPixelCutoff(),
                (m_LastLodBudgetCutoff > 0f ? m_LastLodBudgetCutoff : m_LastEffectiveCutoff) *
                Mathf.Max(0.01f, m_LodDetailScale));
            int selected;
            for (int attempt = 0; attempt < 3; attempt++, cutoff *= 1.25f)
            {
                if (SplatBoxLodTraverser.TryTraverseCompleteFrontier(m_LodPageContextScratch,
                    contextCount, view, maxSplats, cutoff, output, m_LodWorkspace, out selected))
                {
                    m_LastEffectiveCutoff = cutoff / Mathf.Max(0.01f, m_LodDetailScale);
                    return selected;
                }
            }
            // An unusually denser new view can defeat all three thresholds. Spend a small fixed
            // frontier on the ordinary global-priority algorithm so large roots still refine; a
            // roots-only shortcut would drop oversized stand-ins and leave holes. This temporary
            // coverage may be coarser until the full-budget exact worker replaces it.
            m_LodWorkspace.budgetExhausted = true; // Do not repeat the unsuccessful DFS first.
            selected = SplatBoxLodTraverser.Traverse(m_LodPageContextScratch, contextCount, view,
                Mathf.Min(maxSplats, 65_536), EffectiveTraversalPixelCutoff(), output, m_LodWorkspace);
            m_LastEffectiveCutoff = (m_LodWorkspace.budgetExhausted
                ? m_LodWorkspace.exhaustedPixelScale : EffectiveTraversalPixelCutoff()) /
                Mathf.Max(0.01f, m_LodDetailScale);
            return selected;
        }

        static float PadLodTranslationFrustum(in SplatBoxLodTraverser.ViewContext view, float radius)
        {
            if (!view.frustumCull || view.cullPlanes == null || view.cullPlanes.Length == 0 || radius <= 0f)
                return 0f;
            // GeometryUtility supplies normalized world planes. Moving every boundary out by
            // radius encloses all translated frusta within that world-space distance, including
            // their near/far boundaries. Angular padding alone cannot cover a backward step.
            for (int i = 0; i < view.cullPlanes.Length; i++)
                view.cullPlanes[i].w += radius;
            if (view.rightEyeCullPlanes != null && !ReferenceEquals(view.cullPlanes, view.rightEyeCullPlanes))
                for (int i = 0; i < view.rightEyeCullPlanes.Length; i++)
                    view.rightEyeCullPlanes[i].w += radius;
            return radius;
        }

        float m_LastEffectiveCutoff;
        // Keep the last measured full-budget pressure across sparse views; otherwise returning
        // to dense content would seed the bounded repair from the one-pixel requested floor.
        float m_LastLodBudgetCutoff;
        int m_LastLodBudgetSettingsHash;
        int m_LastLodBudgetViewSignature;
        GaussianSplatPagedScene m_LastLodBudgetScene;
        float m_LodNearestPageDist = float.MaxValue;
        const float kAutomaticPixelScaleLimit = 1f;
        /// <summary>Within this distance of a page AABB, apply the maximum page-priority boost.</summary>
        const float kHighestDetailDistance = 0.5f;

        /// <summary>
        /// One globally best-first traversal. A zero inspector value means the automatic one-pixel
        /// floor, not unlimited refinement: nodes below a pixel cannot add useful image detail, but
        /// projecting and sorting their descendants is still expensive. Detail Scale multiplies the
        /// measured node size before this floor, which makes that quality control effective even when
        /// the explicit Pixel Scale Limit is left at zero.
        /// </summary>
        int TraverseWithinBudget(in SplatBoxLodTraverser.ViewContext view, int contextCount, int maxSplats,
            LodActiveSplatRef[] output)
        {
            float effectiveLimit = EffectiveTraversalPixelCutoff();
            int selected = SplatBoxLodTraverser.Traverse(
                m_LodPageContextScratch, contextCount, view, maxSplats, effectiveLimit, output,
                m_LodWorkspace);

            float toRealPixels = 1f / Mathf.Max(0.01f, m_LodDetailScale);
            m_LastEffectiveCutoff = (m_LodWorkspace.budgetExhausted
                ? m_LodWorkspace.exhaustedPixelScale
                : effectiveLimit) * toRealPixels;
            return selected;
        }

        float EffectiveTraversalPixelCutoff()
        {
            float requestedLimit = EffectivePixelScaleLimit;
            // A page's bounds can contain the head while its visible content is metres away.
            // Lowering the global floor from that distance over-refines every other page too.
            // Distance priority already comes from lodScale; quality controls the stopping floor.
            return requestedLimit > 0f ? requestedLimit : kAutomaticPixelScaleLimit;
        }

        public void PreloadPagedLodPages(Camera cam)
        {
            if (!UsesPagedLod)
                return;
            cam = cam != null ? cam : ResolvePagedLodCamera();
            using var editorCameraContext = GaussianSplatRenderSystem.UseEditorLodCameraContext(cam);
            if (!EnsureLodFormatAsset())
                return;
            EnsureLodStreamer();
            EnsurePagedSmudgeHierarchy();
            bool allowDetailTransitions = m_LodSelectionWorker == null || !m_LodSelectionWorker.isRunning;
            m_LodStreamer.UpdateStreaming(cam, transform,
                force: true, allowDetailTransitions: allowDetailTransitions);
            EnsurePagedSmudgeHierarchy();
            m_LodAtlasDirty = true;
            // First view must select immediately — deferred streaming reselection is only for
            // mid-navigation page swaps, not the cold start.
            m_LodPendingSettledReselect = false;
            m_LodSelectionDirty = true;

            if (m_CSBoxUtil == null || m_LodStreamer.loadedPages.Count == 0)
                return;

            // While coarse stubs are still streaming in, skip the synchronous atlas rebuild. Combining
            // SetData uploads with a full atlas ExecuteCommandBuffer in the same call overflows the
            // graphics ring buffer on large paged scenes. The render path rebuilds when dirty.
            if (m_LodStreamer.hasPendingCoarseLoads)
                return;

            var cmd = new CommandBuffer { name = "PreloadPagedLodAtlas" };
            RebuildLodUnifiedAtlas(cmd);
            Graphics.ExecuteCommandBuffer(cmd);
            cmd.Release();
            SelectAndGatherLodSplats(cam, null);
        }

        public void SetLodDetailDistance(float distance)
        {
            float clamped = Mathf.Clamp(distance, 2f, 32f);
            if (Mathf.Approximately(m_LodDetailDistance, clamped))
                return;

            m_LodDetailDistance = clamped;
            InvalidateLodAsyncSelection();
            m_LodSelectionDirty = true;
            m_LodAtlasDirty = true;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            UnityEditor.SceneView.RepaintAll();
#endif
        }

        public void SetLodDetailScale(float scale)
        {
            float clamped = Mathf.Clamp(scale, 0.1f, 2f);
            if (Mathf.Approximately(m_LodDetailScale, clamped))
                return;

            m_LodDetailScale = clamped;
            m_LodSelectionDirty = true;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            UnityEditor.SceneView.RepaintAll();
#endif
        }

#if UNITY_EDITOR
        bool m_EditorLodWarmupScheduled;

        void ScheduleEditorPagedLodWarmup()
        {
            if (m_EditorLodWarmupScheduled)
                return;
            m_EditorLodWarmupScheduled = true;
            UnityEditor.EditorApplication.delayCall += EditorPagedLodWarmup;
        }

        void EditorPagedLodWarmup()
        {
            m_EditorLodWarmupScheduled = false;
            if (this == null || Application.isPlaying || !UsesPagedLod || !isActiveAndEnabled)
                return;
            if (!EnsureEditorPagedLodReady())
                return;
            EditorTickPagedLodStreaming();
        }

        /// <summary>
        /// Keeps page streaming and LoD selection in sync with the Scene view while not in Play mode.
        /// The URP render pass also calls UpdatePagedLod, but this keeps streaming responsive between repaints.
        /// </summary>
        internal void EditorTickPagedLodStreaming()
        {
            if (!UsesPagedLod || Application.isPlaying)
                return;
            if ((m_LodStreamer == null || m_CSBoxUtil == null) && !EnsureEditorPagedLodReady())
                return;

            EnsureLodStreamer();
            var cam = ResolvePagedLodCamera();
            // Initial creation may prefill once without a camera. Until one appears, regular
            // editor updates should wait instead of rebuilding a viewless atlas every tick.
            if (cam == null)
                return;
            using var editorCameraContext = GaussianSplatRenderSystem.UseEditorLodCameraContext(cam);

            // Cold start / paced coarse upload: keep ticking until every page has a coarse stub.
            // Uploading all pages in one Preload blows the graphics ring buffer on large scenes.
            if (!m_HasLastLodView || m_LodStreamer.loadedPages.Count == 0 ||
                m_LodStreamer.hasPendingCoarseLoads)
            {
                PreloadPagedLodPages(cam);
                if (!m_HasLastLodView || m_LodStreamer.hasPendingCoarseLoads)
                    ScheduleEditorPagedLodWarmup();
                // Streaming is throttled by Time.frameCount. Editor callbacks alone do not
                // advance it when Game view is closed, so explicitly request the next loop.
                UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
                UnityEditor.SceneView.RepaintAll();
                return;
            }

            // The render path publishes completed work before reassigning detail slots. Keep the
            // same ownership guard between repaints, including a finished but unconsumed worker.
            EnsurePagedSmudgeHierarchy();
            bool allowDetailTransitions = m_LodSelectionWorker == null || !m_LodSelectionWorker.isRunning;
            m_LodStreamer.UpdateStreaming(cam, transform, allowDetailTransitions: allowDetailTransitions);
            EnsurePagedSmudgeHierarchy();

            if (ShouldRepaintEditorLod(cam))
            {
                // The tagged Main Camera remains the selection owner, even with Game view
                // closed. Publish/upload for that camera here instead of waiting indefinitely
                // for a render callback that may never occur.
                if (HasEditorPagedLodResources)
                {
                    using var cmd = new CommandBuffer { name = "Editor Paged LoD Update" };
                    UpdatePagedLod(cam, cmd);
                    Graphics.ExecuteCommandBuffer(cmd);
                }
                UnityEditor.EditorApplication.QueuePlayerLoopUpdate();
                UnityEditor.SceneView.RepaintAll();
            }
        }

        bool ShouldRepaintEditorLod(Camera cam) =>
            m_LodAtlasDirty || (m_LodSelectionWorker?.hasCompleted ?? false) ||
            ((m_LodSelectionWorker == null || !m_LodSelectionWorker.isRunning ||
                RequiresImmediateLodSelection(cam)) && ShouldRefreshLodSelection(cam));
#endif
    }
}
