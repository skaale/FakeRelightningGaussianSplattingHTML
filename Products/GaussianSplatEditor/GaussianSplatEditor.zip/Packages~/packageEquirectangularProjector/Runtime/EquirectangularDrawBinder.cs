// SPDX-License-Identifier: MIT

#if SPLATBOX
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Binds a live equirectangular projector immediately before its target
    /// renderer draws. Material property blocks are cleared every draw, so the
    /// binding must happen in the render loop rather than MonoBehaviour.Update.
    /// </summary>
    public static class EquirectangularDrawBinder
    {
        static readonly int Enabled = Shader.PropertyToID("_EquirectEnabled");
        static readonly int Texture = Shader.PropertyToID("_EquirectTexture");
        static readonly int ProjectorPosition = Shader.PropertyToID("_EquirectProjectorPosition");
        static readonly int ProjectorScale = Shader.PropertyToID("_EquirectProjectorScale");
        static readonly int ProjectorRotation = Shader.PropertyToID("_EquirectProjectorRotation");
        static readonly int BlendMode = Shader.PropertyToID("_EquirectBlendMode");
        static readonly int Opacity = Shader.PropertyToID("_EquirectOpacity");
        static readonly int TintColor = Shader.PropertyToID("_EquirectTintColor");
        static readonly int FlipHorizontal = Shader.PropertyToID("_EquirectFlipHorizontal");
        static readonly int FlipVertical = Shader.PropertyToID("_EquirectFlipVertical");
        static readonly int UVOffsetX = Shader.PropertyToID("_EquirectUVOffsetX");
        static readonly int UVOffsetY = Shader.PropertyToID("_EquirectUVOffsetY");
        static readonly int TileX = Shader.PropertyToID("_EquirectTileX");
        static readonly int TileY = Shader.PropertyToID("_EquirectTileY");
        static readonly int UseDistanceFiltering = Shader.PropertyToID("_EquirectUseDistanceFiltering");
        static readonly int MinDistance = Shader.PropertyToID("_EquirectMinDistance");
        static readonly int MaxDistance = Shader.PropertyToID("_EquirectMaxDistance");

        static readonly Dictionary<SplatBoxRenderer, GaussianSplatEquirectangularProjector> Projectors = new();

        static EquirectangularDrawBinder()
        {
            GaussianSplatRenderSystem.OnBeforeDrawSplatsForRenderer += Bind;
        }

        public static void Register(GaussianSplatEquirectangularProjector projector)
        {
            if (projector == null)
                return;

            Unregister(projector);
            SplatBoxRenderer renderer = projector.targetRenderer;
            if (renderer != null)
                Projectors[renderer] = projector;
        }

        public static void Unregister(GaussianSplatEquirectangularProjector projector)
        {
            if (projector == null)
                return;

            SplatBoxRenderer matchedRenderer = null;
            foreach (var pair in Projectors)
            {
                if (pair.Value == projector)
                {
                    matchedRenderer = pair.Key;
                    break;
                }
            }

            if (matchedRenderer != null)
                Projectors.Remove(matchedRenderer);
        }

        static void Bind(
            SplatBoxRenderer renderer,
            CommandBuffer commandBuffer,
            MaterialPropertyBlock properties)
        {
            if (!Projectors.TryGetValue(renderer, out var projector) ||
                projector == null || !projector.isActiveAndEnabled || !projector.isProjectionActive)
            {
                Disable(properties);
                return;
            }

            UnityEngine.Texture texture = projector.GetActiveTexture();
            var data = projector.GetProjectionData();
            if (texture == null || data.opacity <= 0f)
            {
                Disable(properties);
                return;
            }

            properties.SetInt(Enabled, 1);
            properties.SetTexture(Texture, texture);
            properties.SetVector(ProjectorPosition, data.projectorPosition);
            properties.SetVector(ProjectorScale, data.projectorScale);
            properties.SetVector(ProjectorRotation, new Vector4(
                data.projectorRotation.x,
                data.projectorRotation.y,
                data.projectorRotation.z,
                data.projectorRotation.w));
            properties.SetInt(BlendMode, data.blendMode);
            properties.SetFloat(Opacity, data.opacity);
            properties.SetVector(TintColor, data.tintColor);
            properties.SetInt(FlipHorizontal, data.flipHorizontal);
            properties.SetInt(FlipVertical, data.flipVertical);
            properties.SetFloat(UVOffsetX, data.uvOffsetX);
            properties.SetFloat(UVOffsetY, data.uvOffsetY);
            properties.SetFloat(TileX, data.tileX);
            properties.SetFloat(TileY, data.tileY);
            properties.SetInt(UseDistanceFiltering, data.useDistanceFiltering);
            properties.SetFloat(MinDistance, data.minDistance);
            properties.SetFloat(MaxDistance, data.maxDistance);
        }

        static void Disable(MaterialPropertyBlock properties)
        {
            properties.SetInt(Enabled, 0);
            properties.SetTexture(Texture, Texture2D.blackTexture);
        }
    }
}
#endif
