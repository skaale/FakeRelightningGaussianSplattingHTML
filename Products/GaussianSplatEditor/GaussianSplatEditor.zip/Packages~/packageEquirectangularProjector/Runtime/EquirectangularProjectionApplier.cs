// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Applies 360° equirectangular colors onto a splat renderer.
    /// Uses the renderer's native method when present, otherwise dispatches
    /// CSApplyEquirectangularProjection on the renderer's compute shader.
    /// </summary>
    public static class EquirectangularProjectionApplier
    {
        static readonly int MatrixObjectToWorld = Shader.PropertyToID("_MatrixObjectToWorld");
        static readonly int EquirectTexture = Shader.PropertyToID("_EquirectTexture");
        static readonly int EquirectColorTexture = Shader.PropertyToID("_EquirectColorTexture");
        static readonly int EquirectProjectorPosition = Shader.PropertyToID("_EquirectProjectorPosition");
        static readonly int EquirectProjectorScale = Shader.PropertyToID("_EquirectProjectorScale");
        static readonly int EquirectProjectorRotation = Shader.PropertyToID("_EquirectProjectorRotation");
        static readonly int EquirectProjectionRadius = Shader.PropertyToID("_EquirectProjectionRadius");
        static readonly int EquirectBlendMode = Shader.PropertyToID("_EquirectBlendMode");
        static readonly int EquirectOpacity = Shader.PropertyToID("_EquirectOpacity");
        static readonly int EquirectTintColor = Shader.PropertyToID("_EquirectTintColor");
        static readonly int EquirectFlipHorizontal = Shader.PropertyToID("_EquirectFlipHorizontal");
        static readonly int EquirectFlipVertical = Shader.PropertyToID("_EquirectFlipVertical");
        static readonly int EquirectUVOffsetX = Shader.PropertyToID("_EquirectUVOffsetX");
        static readonly int EquirectUVOffsetY = Shader.PropertyToID("_EquirectUVOffsetY");
        static readonly int EquirectTileX = Shader.PropertyToID("_EquirectTileX");
        static readonly int EquirectTileY = Shader.PropertyToID("_EquirectTileY");
        static readonly int EquirectUseDistanceFiltering = Shader.PropertyToID("_EquirectUseDistanceFiltering");
        static readonly int EquirectMinDistance = Shader.PropertyToID("_EquirectMinDistance");
        static readonly int EquirectMaxDistance = Shader.PropertyToID("_EquirectMaxDistance");

        sealed class OriginalColorState
        {
            public Texture2D original;
            public RenderTexture target;
        }

        static readonly Dictionary<GaussianSplatRenderer, OriginalColorState> OriginalColors = new();

        public static void Apply(GaussianSplatRenderer renderer, GaussianSplatEquirectangularProjector projector)
        {
            if (renderer == null || projector == null)
                return;

            if (!renderer.HasValidAsset || !renderer.HasValidRenderSetup)
            {
                Debug.LogWarning("Cannot apply equirectangular projection - invalid splat asset or render setup");
                return;
            }

            MethodInfo native = renderer.GetType().GetMethod("ApplyEquirectangularProjection",
                BindingFlags.Instance | BindingFlags.Public);
            if (native != null)
            {
                native.Invoke(renderer, new object[] { projector });
                return;
            }

            DispatchOnRendererCompute(renderer, projector);
        }

        public static void Clear(GaussianSplatRenderer renderer)
        {
            if (renderer == null)
                return;

            MethodInfo native = renderer.GetType().GetMethod("ClearEquirectangularProjection",
                BindingFlags.Instance | BindingFlags.Public);
            if (native != null)
            {
                native.Invoke(renderer, null);
                return;
            }

            RestoreOriginalColors(renderer);
        }

        static void DispatchOnRendererCompute(GaussianSplatRenderer renderer, GaussianSplatEquirectangularProjector projector)
        {
            Texture activeTexture = projector.GetActiveTexture();
            if (activeTexture == null)
            {
                Debug.LogWarning("Invalid projector texture");
                return;
            }

            ComputeShader cs = renderer.ComputeShader;
            if (cs == null || !cs.HasKernel("CSApplyEquirectangularProjection"))
            {
                Debug.LogError("CSApplyEquirectangularProjection kernel not found on the splat renderer compute shader");
                return;
            }

            PrepareColorTexture(renderer);

            int kernel = cs.FindKernel("CSApplyEquirectangularProjection");
            var data = projector.GetProjectionData();
            var colorTex = renderer.GpuColorData;

            using var cmb = new CommandBuffer { name = "ApplyEquirectangularProjection" };

            // Bind the renderer's complete shared splat data set. LoadSplatPos references
            // _SplatIndexRemap even when remapping is disabled, so strict graphics APIs
            // require a valid fallback buffer to be bound for this kernel.
            renderer.SetAssetDataOnCS(
                cmb,
                GaussianSplatRenderer.KernelIndices.ApplyEquirectangularProjection);
            cmb.SetComputeTextureParam(cs, kernel, EquirectTexture, activeTexture);
            cmb.SetComputeTextureParam(cs, kernel, EquirectColorTexture, colorTex);

            cmb.SetComputeMatrixParam(cs, MatrixObjectToWorld, renderer.transform.localToWorldMatrix);
            cmb.SetComputeVectorParam(cs, EquirectProjectorPosition, data.projectorPosition);
            cmb.SetComputeVectorParam(cs, EquirectProjectorScale, data.projectorScale);
            cmb.SetComputeVectorParam(cs, EquirectProjectorRotation, new Vector4(
                data.projectorRotation.x,
                data.projectorRotation.y,
                data.projectorRotation.z,
                data.projectorRotation.w));
            cmb.SetComputeFloatParam(cs, EquirectProjectionRadius, data.projectionRadius);
            cmb.SetComputeIntParam(cs, EquirectBlendMode, data.blendMode);
            cmb.SetComputeFloatParam(cs, EquirectOpacity, data.opacity);
            cmb.SetComputeVectorParam(cs, EquirectTintColor, data.tintColor);
            cmb.SetComputeIntParam(cs, EquirectFlipHorizontal, data.flipHorizontal);
            cmb.SetComputeIntParam(cs, EquirectFlipVertical, data.flipVertical);
            cmb.SetComputeFloatParam(cs, EquirectUVOffsetX, data.uvOffsetX);
            cmb.SetComputeFloatParam(cs, EquirectUVOffsetY, data.uvOffsetY);
            cmb.SetComputeFloatParam(cs, EquirectTileX, data.tileX);
            cmb.SetComputeFloatParam(cs, EquirectTileY, data.tileY);
            cmb.SetComputeIntParam(cs, EquirectUseDistanceFiltering, data.useDistanceFiltering);
            cmb.SetComputeFloatParam(cs, EquirectMinDistance, data.minDistance);
            cmb.SetComputeFloatParam(cs, EquirectMaxDistance, data.maxDistance);

            cs.GetKernelThreadGroupSizes(kernel, out uint gsX, out _, out _);
            cmb.DispatchCompute(cs, kernel, (renderer.splatCount + (int)gsX - 1) / (int)gsX, 1, 1);
            Graphics.ExecuteCommandBuffer(cmb);

            FieldInfo editModified = renderer.GetType().GetField("editModified",
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            if (editModified != null && editModified.FieldType == typeof(bool))
                editModified.SetValue(renderer, true);
        }

        static void PrepareColorTexture(GaussianSplatRenderer renderer)
        {
            RenderTexture rt = renderer.GpuColorData as RenderTexture;
            if (rt != null && rt.enableRandomWrite)
            {
                if (!OriginalColors.TryGetValue(renderer, out var existing) ||
                    existing.target != rt || existing.original == null)
                {
                    ReleaseOriginalColorState(renderer);
                    existing = new OriginalColorState
                    {
                        original = CreateOriginalColorTexture(renderer),
                        target = rt
                    };
                    OriginalColors[renderer] = existing;
                }

                // Opacity must always blend from the unmodified asset colors. Without this
                // reset, auto-apply compounds the blend every frame until it becomes opaque.
                Graphics.Blit(existing.original, rt);
                return;
            }

            Texture2D tex2D = renderer.GpuColorData as Texture2D;
            if (tex2D == null)
                return;

            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(renderer.splatCount);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(renderer.asset.colorFormat);

            rt = new RenderTexture(texWidth, texHeight, 0, texFormat)
            {
                name = "GaussianColorData",
                enableRandomWrite = true,
                useMipMap = false,
                filterMode = FilterMode.Point
            };
            rt.Create();
            Graphics.Blit(tex2D, rt);
            renderer.m_GpuColorData = rt;

            ReleaseOriginalColorState(renderer);
            OriginalColors[renderer] = new OriginalColorState
            {
                original = tex2D,
                target = rt
            };
        }

        static void RestoreOriginalColors(GaussianSplatRenderer renderer)
        {
            if (!renderer.HasValidAsset || !renderer.HasValidRenderSetup)
                return;

            RenderTexture rt = renderer.GpuColorData as RenderTexture;
            if (rt == null)
                return;

            if (OriginalColors.TryGetValue(renderer, out var state) && state.original != null)
            {
                Graphics.Blit(state.original, rt);
                ReleaseOriginalColorState(renderer);
                return;
            }

            Texture2D originalTex = CreateOriginalColorTexture(renderer);
            Graphics.Blit(originalTex, rt);
            Object.DestroyImmediate(originalTex);
        }

        static Texture2D CreateOriginalColorTexture(GaussianSplatRenderer renderer)
        {
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(renderer.splatCount);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(renderer.asset.colorFormat);

            var originalTex = new Texture2D(texWidth, texHeight, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
            {
                name = "OriginalColorData"
            };
            originalTex.SetPixelData(renderer.asset.colorData.GetData<byte>(), 0);
            originalTex.Apply(false, false);
            return originalTex;
        }

        static void ReleaseOriginalColorState(GaussianSplatRenderer renderer)
        {
            if (!OriginalColors.TryGetValue(renderer, out var state))
                return;

            if (state.original != null)
                Object.DestroyImmediate(state.original);
            OriginalColors.Remove(renderer);
        }
    }
}
