// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Video;
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Projects equirectangular (360°) textures and videos onto Gaussian splats using spherical UV mapping
    /// </summary>
    [ExecuteInEditMode]
    public class GaussianSplatEquirectangularProjector : MonoBehaviour
    {
        public enum ProjectionType
        {
            Texture,
            Video
        }

        public enum VideoFramerate
        {
            Native = 0,
            _24fps = 24,
            _30fps = 30,
            _60fps = 60,
            _90fps = 90,
            _120fps = 120
        }

        public enum BlendMode
        {
            Replace,
            Multiply,
            Additive,
            Overlay,
            AlphaBlend
        }

        [Header("Target")]
        [SerializeField] [Tooltip("Target Gaussian Splat renderer")]
        private GaussianSplatRenderer m_TargetRenderer;

        [Header("Content")]
        [SerializeField] private ProjectionType m_ProjectionType = ProjectionType.Texture;
        [SerializeField] [Tooltip("Equirectangular texture (2:1 aspect ratio recommended)")]
        private Texture2D m_EquirectangularTexture;
        [SerializeField] [Tooltip("Equirectangular video (360° video)")]
        private VideoClip m_VideoClip;
        [SerializeField] [Tooltip("Video playback framerate - Native uses original video framerate")]
        private VideoFramerate m_VideoFramerate = VideoFramerate.Native;
        [SerializeField] private bool m_VideoLoop = true;
        [SerializeField] [Range(256, 8192)] private int m_MaxVideoResolution = 3840;

        [Header("Projection Settings")]
        [SerializeField] [Tooltip("Rotation offset for the equirectangular map (degrees)")]
        private Vector3 m_RotationOffset = Vector3.zero;
        [SerializeField] [Range(0.01f, 10f)] [Tooltip("Scale/radius of the spherical projection")]
        private float m_ProjectionRadius = 1f;
        [SerializeField] [HideInInspector]
        private Vector3 m_ReferenceTransformScale = Vector3.zero;
        [SerializeField] private BlendMode m_BlendMode = BlendMode.Replace;
        [SerializeField] [Range(0f, 1f)] private float m_Opacity = 1f;
        [SerializeField] private Color m_TintColor = Color.white;

        [Header("UV Mapping")]
        [SerializeField] [Tooltip("Flip horizontal UV (mirror left/right)")]
        private bool m_FlipHorizontal = false;
        [SerializeField] [Tooltip("Flip vertical UV (mirror top/bottom)")]
        private bool m_FlipVertical = false;
        [SerializeField] [Range(-1f, 1f)] [Tooltip("UV offset horizontal")]
        private float m_UVOffsetX = 0f;
        [SerializeField] [Range(-1f, 1f)] [Tooltip("UV offset vertical")]
        private float m_UVOffsetY = 0f;
        [SerializeField] [Range(0.1f, 10f)] [Tooltip("UV tiling horizontal")]
        private float m_TileX = 1f;
        [SerializeField] [Range(0.1f, 10f)] [Tooltip("UV tiling vertical")]
        private float m_TileY = 1f;

        [Header("Filtering")]
        [SerializeField] [Tooltip("Only project on splats within this distance from projector")]
        private bool m_UseDistanceFiltering = false;
        [SerializeField] private float m_MinDistance = 0f;
        [SerializeField] private float m_MaxDistance = 10f;

        [Header("Rendering")]
        [SerializeField] [Tooltip("Apply projection every frame or only when Apply button is clicked")]
        private bool m_AutoApply = true;

        [Header("Gizmos")]
        [SerializeField] private bool m_ShowGizmos = true;
        [SerializeField] private Color m_GizmoColor = new Color(1f, 0.5f, 0f, 0.3f);

        private VideoPlayer m_VideoPlayer;
        private RenderTexture m_VideoRenderTexture;
        private Quaternion m_RotationQuaternion;
        private bool m_ProjectionApplied = false;
        private float m_PlaybackSpeedMultiplier = 1.0f;

        public Texture2D equirectangularTexture
        {
            get => m_EquirectangularTexture;
            set => m_EquirectangularTexture = value;
        }

        public VideoClip videoClip
        {
            get => m_VideoClip;
            set => m_VideoClip = value;
        }

        public VideoFramerate videoFramerate
        {
            get => m_VideoFramerate;
            set => m_VideoFramerate = value;
        }

        public ProjectionType projectionType
        {
            get => m_ProjectionType;
            set => m_ProjectionType = value;
        }

        public GaussianSplatRenderer targetRenderer => ResolveTargetRenderer();

        public float opacity
        {
            get => m_Opacity;
            set => m_Opacity = Mathf.Clamp01(value);
        }

        public bool autoApply
        {
            get => m_AutoApply;
            set => m_AutoApply = value;
        }

        public bool isProjectionActive => m_AutoApply || m_ProjectionApplied;

        public void ResetProjectionScaleReference()
        {
            m_ReferenceTransformScale = GetSafeTransformScale();
        }

        public VideoPlayer videoPlayer => m_VideoPlayer;

        public float playbackSpeedMultiplier
        {
            get => m_PlaybackSpeedMultiplier;
            set
            {
                m_PlaybackSpeedMultiplier = Mathf.Clamp(value, -4f, 4f);
                UpdateVideoPlaybackSpeed();
            }
        }

        public Texture GetActiveTexture()
        {
            if (m_ProjectionType == ProjectionType.Video && m_VideoRenderTexture != null)
                return m_VideoRenderTexture;
            return m_EquirectangularTexture;
        }

        void OnEnable()
        {
            EnsureScaleReference();

            if (m_ProjectionType == ProjectionType.Video && m_VideoClip != null)
            {
                if (m_VideoPlayer == null || m_VideoRenderTexture == null)
                    SetupVideoPlayer();
                else if (!m_VideoPlayer.isPlaying)
                    m_VideoPlayer.Play();
            }

            UpdateRotationQuaternion();
#if SPLATBOX
            EquirectangularDrawBinder.Register(this);
#endif
        }

        void OnDisable()
        {
#if SPLATBOX
            EquirectangularDrawBinder.Unregister(this);
#endif
            if (m_VideoPlayer != null && m_VideoPlayer.isPlaying)
                m_VideoPlayer.Stop();
            
            m_ProjectionApplied = false;
        }

        void Update()
        {
            if (m_AutoApply)
            {
                ApplyProjection();
            }
        }

        void UpdateRotationQuaternion()
        {
            m_RotationQuaternion = Quaternion.Euler(m_RotationOffset);
        }

        void EnsureScaleReference()
        {
            if (Mathf.Abs(m_ReferenceTransformScale.x) < 0.0001f ||
                Mathf.Abs(m_ReferenceTransformScale.y) < 0.0001f ||
                Mathf.Abs(m_ReferenceTransformScale.z) < 0.0001f)
            {
                ResetProjectionScaleReference();
            }
        }

        Vector3 GetSafeTransformScale()
        {
            Vector3 scale = transform.lossyScale;
            return new Vector3(
                Mathf.Max(Mathf.Abs(scale.x), 0.0001f),
                Mathf.Max(Mathf.Abs(scale.y), 0.0001f),
                Mathf.Max(Mathf.Abs(scale.z), 0.0001f));
        }

        void UpdateVideoPlaybackSpeed()
        {
            if (m_VideoPlayer == null || m_VideoClip == null) return;

            float baseSpeed = 1.0f;
            
            // Calculate base speed from framerate selection
            if (m_VideoFramerate != VideoFramerate.Native)
            {
                float nativeFramerate = (float)m_VideoClip.frameRate;
                float targetFramerate = (float)m_VideoFramerate;
                baseSpeed = nativeFramerate > 0 ? targetFramerate / nativeFramerate : 1.0f;
            }
            
            // Apply speed multiplier
            m_VideoPlayer.playbackSpeed = baseSpeed * m_PlaybackSpeedMultiplier;
        }

        // Video playback control methods
        public void PlayVideo()
        {
            if (m_VideoPlayer != null && m_VideoClip != null)
            {
                if (!m_VideoPlayer.isPlaying)
                    m_VideoPlayer.Play();
            }
        }

        public void PauseVideo()
        {
            if (m_VideoPlayer != null && m_VideoPlayer.isPlaying)
            {
                m_VideoPlayer.Pause();
            }
        }

        public void StopVideo()
        {
            if (m_VideoPlayer != null)
            {
                m_VideoPlayer.Stop();
                m_VideoPlayer.time = 0;
            }
        }

        public void RewindVideo(float seconds = 5f)
        {
            if (m_VideoPlayer != null && m_VideoClip != null)
            {
                m_VideoPlayer.time = Mathf.Max(0, (float)m_VideoPlayer.time - seconds);
            }
        }

        public void FastForwardVideo(float seconds = 5f)
        {
            if (m_VideoPlayer != null && m_VideoClip != null)
            {
                double maxTime = m_VideoClip.length;
                m_VideoPlayer.time = Mathf.Min((float)maxTime, (float)m_VideoPlayer.time + seconds);
            }
        }

        public void SetVideoTime(float time)
        {
            if (m_VideoPlayer != null && m_VideoClip != null)
            {
                m_VideoPlayer.time = Mathf.Clamp(time, 0, (float)m_VideoClip.length);
            }
        }

        public float GetVideoTime()
        {
            return m_VideoPlayer != null ? (float)m_VideoPlayer.time : 0f;
        }

        public float GetVideoDuration()
        {
            return m_VideoClip != null ? (float)m_VideoClip.length : 0f;
        }

        public bool IsVideoPlaying()
        {
            return m_VideoPlayer != null && m_VideoPlayer.isPlaying;
        }

        void SetupVideoPlayer()
        {
            if (m_VideoClip == null) return;

            if (m_VideoPlayer == null)
            {
                m_VideoPlayer = gameObject.GetComponent<VideoPlayer>();
                if (m_VideoPlayer == null)
                {
                    m_VideoPlayer = gameObject.AddComponent<VideoPlayer>();
                    m_VideoPlayer.hideFlags = HideFlags.HideInInspector;
                }
            }

            m_VideoPlayer.playOnAwake = false;
            m_VideoPlayer.renderMode = VideoRenderMode.RenderTexture;
            m_VideoPlayer.source = VideoSource.VideoClip;
            m_VideoPlayer.clip = m_VideoClip;
            m_VideoPlayer.isLooping = m_VideoLoop;
            m_VideoPlayer.audioOutputMode = VideoAudioOutputMode.None;
            
            // Set playback speed using unified method
            UpdateVideoPlaybackSpeed();

            if (m_VideoRenderTexture != null)
            {
                if (m_VideoRenderTexture.IsCreated())
                    m_VideoRenderTexture.Release();
                m_VideoRenderTexture = null;
            }

            int width = (int)m_VideoClip.width;
            int height = (int)m_VideoClip.height;

            if (width <= 0 || height <= 0)
            {
                width = 3840;
                height = 1920;
            }

            float aspect = (float)width / height;
            if (Mathf.Abs(aspect - 2f) > 0.05f)
            {
                Debug.LogWarning(
                    $"Equirectangular video should use a 2:1 aspect ratio (for example 3840x1920). " +
                    $"'{m_VideoClip.name}' is {width}x{height} ({aspect:F2}:1).",
                    this);
            }

            if (width > m_MaxVideoResolution)
            {
                width = m_MaxVideoResolution;
                height = Mathf.RoundToInt(width / aspect);
            }
            if (height > m_MaxVideoResolution)
            {
                height = m_MaxVideoResolution;
                width = Mathf.RoundToInt(height * aspect);
            }

            width = Mathf.Max(256, width);
            height = Mathf.Max(256, height);

            try
            {
                m_VideoRenderTexture = new RenderTexture(width, height, 0, RenderTextureFormat.ARGB32)
                {
                    name = "EquirectVideo",
                    filterMode = FilterMode.Trilinear,
                    wrapMode = TextureWrapMode.Repeat,
                    anisoLevel = 9,
                    useMipMap = true,
                    autoGenerateMips = true
                };
                
                if (!m_VideoRenderTexture.Create())
                {
                    Debug.LogError($"Failed to create video render texture ({width}x{height})");
                    m_VideoRenderTexture = null;
                    return;
                }
                
                m_VideoPlayer.targetTexture = m_VideoRenderTexture;
                m_VideoPlayer.Play();
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Video player setup failed: {e.Message}");
                if (m_VideoRenderTexture != null)
                {
                    if (m_VideoRenderTexture.IsCreated())
                        m_VideoRenderTexture.Release();
                    m_VideoRenderTexture = null;
                }
            }
        }

        void CleanupVideoPlayer()
        {
            if (m_VideoPlayer != null && m_VideoPlayer.isPlaying)
            {
                m_VideoPlayer.Stop();
                m_VideoPlayer.targetTexture = null;
            }

            if (m_VideoRenderTexture != null)
            {
                if (m_VideoRenderTexture.IsCreated())
                    m_VideoRenderTexture.Release();
                m_VideoRenderTexture = null;
            }
        }

        void OnDestroy()
        {
            if (m_VideoPlayer != null && m_VideoPlayer)
            {
                if (m_VideoPlayer.isPlaying)
                    m_VideoPlayer.Stop();
                m_VideoPlayer.targetTexture = null;
            }

            if (m_VideoRenderTexture != null)
            {
                if (m_VideoRenderTexture.IsCreated())
                    m_VideoRenderTexture.Release();
                DestroyImmediate(m_VideoRenderTexture);
                m_VideoRenderTexture = null;
            }

            m_VideoPlayer = null;
        }

        /// <summary>
        /// Applies the equirectangular projection to the target renderer
        /// </summary>
        public void ApplyProjection()
        {
            GaussianSplatRenderer targetRenderer = ResolveTargetRenderer();
            if (targetRenderer == null)
            {
                Debug.LogWarning("No Gaussian Splat Renderer found for equirectangular projection");
                return;
            }

            Texture activeTexture = GetActiveTexture();
            
            // Clear projection if texture is null or opacity is 0
            if (activeTexture == null || m_Opacity <= 0f)
            {
                // Only clear if a projection was previously applied
                if (m_ProjectionApplied)
                {
                    EquirectangularProjectionApplier.Clear(targetRenderer);
                    m_ProjectionApplied = false;
                }
                return;
            }

#if SPLATBOX
            // The video is sampled while splats are drawn. This avoids destructive
            // per-splat color baking and gives every covered fragment its own UV.
            EquirectangularDrawBinder.Register(this);
#else
            EquirectangularProjectionApplier.Apply(targetRenderer, this);
#endif
            m_ProjectionApplied = true;
        }

        GaussianSplatRenderer ResolveTargetRenderer()
        {
            if (m_TargetRenderer != null)
                return m_TargetRenderer;

#if UNITY_2023_1_OR_NEWER
            return Object.FindFirstObjectByType<GaussianSplatRenderer>();
#else
            return Object.FindObjectOfType<GaussianSplatRenderer>();
#endif
        }

        /// <summary>
        /// Gets projection data for the compute shader
        /// </summary>
        public EquirectangularProjectionData GetProjectionData()
        {
            UpdateRotationQuaternion();
            EnsureScaleReference();
            Vector3 currentScale = GetSafeTransformScale();
            
            return new EquirectangularProjectionData
            {
                projectorPosition = transform.position,
                projectorScale = new Vector3(
                    currentScale.x / m_ReferenceTransformScale.x,
                    currentScale.y / m_ReferenceTransformScale.y,
                    currentScale.z / m_ReferenceTransformScale.z),
                projectorRotation = transform.rotation * m_RotationQuaternion,
                projectionRadius = m_ProjectionRadius,
                blendMode = (int)m_BlendMode,
                opacity = m_Opacity,
                tintColor = m_TintColor,
                flipHorizontal = m_FlipHorizontal ? 1 : 0,
                flipVertical = m_FlipVertical ? 1 : 0,
                uvOffsetX = m_UVOffsetX,
                uvOffsetY = m_UVOffsetY,
                tileX = m_TileX,
                tileY = m_TileY,
                useDistanceFiltering = m_UseDistanceFiltering ? 1 : 0,
                minDistance = m_MinDistance,
                maxDistance = m_MaxDistance
            };
        }

        void OnDrawGizmos()
        {
            if (!m_ShowGizmos) return;

            Matrix4x4 previousMatrix = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(transform.position, transform.rotation, transform.lossyScale);
            Gizmos.color = m_GizmoColor;
            
            // Draw sphere representing projection volume
            Gizmos.DrawWireSphere(Vector3.zero, m_ProjectionRadius);
            
            // Draw axis
            Gizmos.color = Color.red;
            Gizmos.DrawRay(Vector3.zero, Vector3.right * m_ProjectionRadius * 0.5f);
            Gizmos.color = Color.green;
            Gizmos.DrawRay(Vector3.zero, Vector3.up * m_ProjectionRadius * 0.5f);
            Gizmos.color = Color.blue;
            Gizmos.DrawRay(Vector3.zero, Vector3.forward * m_ProjectionRadius * 0.5f);
            Gizmos.matrix = previousMatrix;
        }

        void OnDrawGizmosSelected()
        {
            if (!m_ShowGizmos) return;

            // Draw more prominent sphere when selected
            Matrix4x4 previousMatrix = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(transform.position, transform.rotation, transform.lossyScale);
            Gizmos.color = new Color(m_GizmoColor.r, m_GizmoColor.g, m_GizmoColor.b, m_GizmoColor.a * 1.5f);
            Gizmos.DrawWireSphere(Vector3.zero, m_ProjectionRadius);
            Gizmos.matrix = previousMatrix;

            // Draw distance filtering bounds if enabled
            if (m_UseDistanceFiltering)
            {
                Gizmos.color = Color.yellow;
                Gizmos.DrawWireSphere(transform.position, m_MinDistance);
                Gizmos.color = Color.cyan;
                Gizmos.DrawWireSphere(transform.position, m_MaxDistance);
            }
        }

#if UNITY_EDITOR
        void OnValidate()
        {
            EnsureScaleReference();
            m_ProjectionRadius = Mathf.Max(0.01f, m_ProjectionRadius);
            m_Opacity = Mathf.Clamp01(m_Opacity);
            m_MaxVideoResolution = Mathf.Clamp(m_MaxVideoResolution, 256, 8192);
            m_MinDistance = Mathf.Max(0f, m_MinDistance);
            m_MaxDistance = Mathf.Max(m_MinDistance + 0.01f, m_MaxDistance);
            m_UVOffsetX = Mathf.Clamp(m_UVOffsetX, -1f, 1f);
            m_UVOffsetY = Mathf.Clamp(m_UVOffsetY, -1f, 1f);
            m_TileX = Mathf.Clamp(m_TileX, 0.1f, 10f);
            m_TileY = Mathf.Clamp(m_TileY, 0.1f, 10f);

            UpdateRotationQuaternion();

            if (m_ProjectionType == ProjectionType.Video && m_VideoPlayer != null)
            {
                if (m_VideoPlayer.clip != m_VideoClip || m_VideoPlayer.isLooping != m_VideoLoop)
                {
                    m_VideoPlayer.clip = m_VideoClip;
                    m_VideoPlayer.isLooping = m_VideoLoop;
                    if (m_VideoPlayer.isPlaying)
                        m_VideoPlayer.Stop();
                    UnityEditor.EditorApplication.delayCall += () =>
                    {
                        if (this != null && m_VideoPlayer != null)
                            SetupVideoPlayer();
                    };
                }
                else if (m_VideoPlayer.clip != null)
                {
                    // Update framerate without restarting
                    if (m_VideoFramerate != VideoFramerate.Native)
                    {
                        int targetFPS = (int)m_VideoFramerate;
                        m_VideoPlayer.playbackSpeed = (float)targetFPS / 24.0f;
                    }
                    else
                    {
                        m_VideoPlayer.playbackSpeed = 1.0f;
                    }
                }
            }
            else if (m_ProjectionType == ProjectionType.Texture && m_VideoPlayer != null)
            {
                CleanupVideoPlayer();
            }
        }
#endif
    }

    /// <summary>
    /// Data structure for equirectangular projection (must match compute shader struct)
    /// </summary>
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct EquirectangularProjectionData
    {
        public Vector3 projectorPosition;
        public Vector3 projectorScale;
        public float projectionRadius;
        public Quaternion projectorRotation;
        public int blendMode;
        public float opacity;
        public Vector4 tintColor;
        public int flipHorizontal;
        public int flipVertical;
        public float uvOffsetX;
        public float uvOffsetY;
        public float tileX;
        public float tileY;
        public int useDistanceFiltering;
        public float minDistance;
        public float maxDistance;
        public float padding; // Align to 16 bytes
    }
}

