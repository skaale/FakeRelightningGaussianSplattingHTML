# Equirectangular Projection for Gaussian Splats

Package id: `com.splatworld.equirectangular-projector`

Requires a Gaussian Splat renderer already in the project:

- `org.nesnausk.gaussian-splatting` (`GaussianSplatRenderer`), or
- `com.gaussiansplatting.splatbox` (`SplatBoxRenderer`)

## Install

**This project** — already registered in `Packages/manifest.json`:

```json
"com.splatworld.equirectangular-projector": "file:packageEquirectangularProjector"
```

**Another Unity project** — Package Manager → **+** → **Add package from disk…** and select this folder’s `package.json`.

## Overview
The `GaussianSplatEquirectangularProjector` component projects equirectangular (360°) textures and videos onto Gaussian splat surfaces using spherical UV mapping. This is ideal for applying panoramic images or 360° videos to splat captures.

Create one from **GameObject → Gaussian Splatting → Equirectangular Projector**.

## Quick Setup

### 1. Add the Component
1. Create an empty GameObject in your scene
2. Add the `GaussianSplatEquirectangularProjector` component
3. Position it at the center of your splat model (where the 360° camera was located)

### 2. Configure Content
**For Static Images:**
- Set `Projection Type` to `Texture`
- Assign your equirectangular texture (2:1 aspect ratio recommended)
- Recommended texture format: 3840x1920 or 7680x3840

**For 360° Videos:**
- Set `Projection Type` to `Video`
- Assign your 360° video clip (.mp4)
- Video should be in equirectangular format (2:1 aspect ratio)

### 3. Assign Target
- Set the `Target Renderer` to your `GaussianSplatRenderer` component
- If left empty, it will auto-find the renderer in the scene

### 4. Apply Projection
**Auto-Apply Mode (Default):**
- Enable `Auto Apply` for real-time updates
- Great for videos and interactive adjustments
- Updates every frame

**Manual Mode:**
- Disable `Auto Apply`
- Click "Apply Projection (Bake)" in the Inspector
- Good for static textures to avoid runtime overhead

## Settings Explained

### Projection Settings
- **Rotation Offset**: Rotate the equirectangular map (in degrees)
  - X: Pitch (up/down tilt)
  - Y: Yaw (left/right rotation)
  - Z: Roll (rotate around forward axis)
- **Projection Radius**: Not used for distance culling (kept for future features)

### Blend Mode
- **Replace**: Completely replace splat colors
- **Multiply**: Multiply texture with existing colors
- **Additive**: Add texture colors to splats
- **Overlay**: Blend using overlay mode
- **AlphaBlend**: Blend based on texture alpha channel

### UV Mapping
- **Flip Horizontal**: Mirror the texture left/right
- **Flip Vertical**: Mirror the texture top/bottom
- **UV Offset X**: Shift texture horizontally (-1 to 1)
- **UV Offset Y**: Shift texture vertically (-1 to 1)

### Filtering
- **Use Distance Filtering**: Enable to only project on splats within distance range
- **Min/Max Distance**: Define the distance range from projector

## Common Use Cases

### 1. Applying 360° Photo to Splat Scene
```
1. Position projector at camera origin
2. Assign equirectangular photo
3. Set Opacity to 1.0
4. Set Blend Mode to Replace
5. Click "Apply Projection (Bake)"
```

### 2. Playing 360° Video on Splats
```
1. Position projector at center
2. Set Projection Type to Video
3. Assign 360° video clip
4. Enable Auto Apply
5. Press Play in Unity
```

### 3. Texture Alignment Issues
```
If texture doesn't align:
1. Adjust Rotation Offset Y to rotate horizontally
2. Try Flip Horizontal if mirrored
3. Use UV Offset X/Y for fine adjustments
```

### 4. Partial Projection (Distance Limited)
```
1. Enable Use Distance Filtering
2. Set Min Distance = 0
3. Set Max Distance = 5 (only splats within 5 units)
4. Great for layered 360° scenes
```

## Technical Details

### How It Works
1. For each splat, calculates direction from projector to splat
2. Converts 3D direction to spherical coordinates (theta, phi)
3. Maps spherical coords to UV coordinates (0-1 range)
4. Samples the equirectangular texture at those UVs
5. Blends sampled color with existing splat color

### Equirectangular UV Math
- **Theta** (longitude): `atan2(z, x) / (2*PI) + 0.5`
- **Phi** (latitude): `asin(y) / PI + 0.5`
- This maps the sphere surface to a rectangular texture

### Performance
- Real-time mode: Runs compute shader every frame
- Baked mode: Runs once, modifies splat colors permanently
- GPU-accelerated using compute shaders
- Performance depends on splat count and texture resolution

## Tips & Best Practices

### Texture Preparation
- Use 2:1 aspect ratio (e.g., 3840x1920, 7680x3840)
- PNG or JPG for static images
- H.264 MP4 for videos
- Higher resolution = better quality but slower

### Positioning
- Place projector exactly where 360° camera was
- For scanned scenes, this is usually the scan origin
- Z-axis (blue) should point forward in your scene

### Alignment
- If seam is visible, adjust Rotation Offset Y
- Common values: 0°, 90°, 180°, 270°
- Fine-tune with UV Offset X (moves seam)

### Video Playback
- Keep Max Video Resolution reasonable (1920-2048)
- Videos load into GPU memory
- Higher resolution may cause instability on some systems
- Use compressed formats (H.264)

### Distance Filtering
- Useful for multi-layer 360° captures
- Can create depth-based effects
- Combine multiple projectors with different ranges

## Troubleshooting

**Texture appears stretched:**
- Check aspect ratio (should be 2:1)
- Verify it's equirectangular format, not cubic

**Texture is upside down:**
- Enable Flip Vertical

**Texture is mirrored:**
- Enable Flip Horizontal

**Seam visible:**
- Rotate with Rotation Offset Y or UV Offset X
- Ensure texture wraps properly (no seam in source)

**Video not playing:**
- Enable Auto Apply
- Check video codec (H.264 recommended)
- Reduce Max Video Resolution

**Colors too bright/dark:**
- Adjust Opacity slider
- Try different Blend Modes
- Check Tint Color (should be white for neutral)

**No visible change:**
- Verify Target Renderer is assigned
- Check that splats are within distance range (if filtering enabled)
- Ensure texture/video is assigned
- Try Replace blend mode with full opacity

## Integration with Other Features

### Works With:
- Gaussian Splat editing tools
- Animation systems
- Physics/voxelization
- Portal rendering

### Performance Notes:
- Auto-apply mode adds per-frame compute cost
- Baked mode has no runtime cost
- Can combine with other projection types
- Multiple projectors can be used (layers blend)

## Example Workflow

```
1. Import 360° video or image
2. Create empty GameObject → Add Component → GaussianSplatEquirectangularProjector
3. Position at splat model center
4. Assign texture/video
5. Select blend mode (Replace for full coverage)
6. Enable Auto Apply (for video) or click Apply Projection (for texture)
7. Adjust rotation/UV offsets as needed
8. Done!
```

## Comparison with Other Projection Types

| Feature | Equirectangular | Box Projection | Frustum Projection |
|---------|----------------|----------------|-------------------|
| Coverage | 360° sphere | Rectangular box | Camera frustum |
| UV Mapping | Spherical | Planar | Perspective |
| Best For | Panoramas | Flat surfaces | Screen-like projections |
| Distortion | Pole distortion | None | Perspective |

## Credits
Spherical UV mapping based on standard equirectangular projection math.
Compute shader implementation optimized for Unity Gaussian Splatting package.

