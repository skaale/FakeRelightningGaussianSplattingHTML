// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatEquirectangularProjector))]
    public class GaussianSplatEquirectangularProjectorEditor : UnityEditor.Editor
    {
        [MenuItem("GameObject/Gaussian Splatting/Equirectangular Projector", false, 20)]
        static void CreateProjector()
        {
            var go = new GameObject("Equirectangular Projector");
            var projector = go.AddComponent<GaussianSplatEquirectangularProjector>();
#if UNITY_2023_1_OR_NEWER
            var renderer = Object.FindFirstObjectByType<GaussianSplatRenderer>();
#else
            var renderer = Object.FindObjectOfType<GaussianSplatRenderer>();
#endif
            if (renderer != null)
            {
                var so = new SerializedObject(projector);
                so.FindProperty("m_TargetRenderer").objectReferenceValue = renderer;
                so.ApplyModifiedPropertiesWithoutUndo();
                go.transform.position = renderer.transform.position;
            }
            Undo.RegisterCreatedObjectUndo(go, "Create Equirectangular Projector");
            Selection.activeGameObject = go;
        }

        private bool m_ShowVideoControls = true;

        private string FormatTime(float seconds)
        {
            int minutes = Mathf.FloorToInt(seconds / 60f);
            int secs = Mathf.FloorToInt(seconds % 60f);
            int millis = Mathf.FloorToInt((seconds * 100f) % 100f);
            return $"{minutes:00}:{secs:00}.{millis:00}";
        }

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            GaussianSplatEquirectangularProjector projector = (GaussianSplatEquirectangularProjector)target;

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Equirectangular (360°) Projection", EditorStyles.boldLabel);
            if (GUILayout.Button("Use Current Transform Scale as 1x"))
            {
                Undo.RecordObject(projector, "Reset Equirectangular Scale Reference");
                projector.ResetProjectionScaleReference();
                EditorUtility.SetDirty(projector);
            }
            EditorGUILayout.HelpBox(
                "Use the Transform Scale gizmo to zoom the video. X controls horizontal scale and Y controls vertical scale.",
                MessageType.None);
            EditorGUILayout.Space();

            if (projector.projectionType == GaussianSplatEquirectangularProjector.ProjectionType.Video)
            {
                if (projector.videoClip != null)
                {
                    var clip = projector.videoClip;
                    
                    // Get framerate info via reflection since it's a private field
                    var framerateField = typeof(GaussianSplatEquirectangularProjector).GetField("m_VideoFramerate", 
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    var framerate = (GaussianSplatEquirectangularProjector.VideoFramerate)framerateField.GetValue(projector);
                    
                    string framerateInfo = framerate == GaussianSplatEquirectangularProjector.VideoFramerate.Native 
                        ? $"Native: {clip.frameRate:F1} fps" 
                        : $"Target: {(int)framerate} fps (Native: {clip.frameRate:F1} fps)";
                    
                    string info = $"VIDEO MODE: {clip.width}x{clip.height}\n" +
                                 "Playing 360° video on Gaussian Splats.\n" +
                                 "Recommended aspect ratio: 2:1 (equirectangular).\n" +
                                 "Reduce Max Video Resolution if performance issues occur.\n" +
                                 $"Framerate: {framerateInfo}";
                    
                    EditorGUILayout.HelpBox(info, MessageType.Info);

                    // Video playback controls
                    EditorGUILayout.Space();
                    m_ShowVideoControls = EditorGUILayout.Foldout(m_ShowVideoControls, "Video Playback Controls", true, EditorStyles.foldoutHeader);
                    
                    if (m_ShowVideoControls)
                    {
                        EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                        
                        // Playback status
                        bool isPlaying = projector.IsVideoPlaying();
                        float currentTime = projector.GetVideoTime();
                        float duration = projector.GetVideoDuration();
                        
                        EditorGUILayout.LabelField("Status", isPlaying ? "Playing" : "Paused", EditorStyles.boldLabel);
                        EditorGUILayout.LabelField("Time", $"{FormatTime(currentTime)} / {FormatTime(duration)}");
                        
                        // Timeline slider
                        EditorGUI.BeginChangeCheck();
                        float newTime = EditorGUILayout.Slider("Timeline", currentTime, 0f, duration);
                        if (EditorGUI.EndChangeCheck())
                        {
                            projector.SetVideoTime(newTime);
                        }
                        
                        EditorGUILayout.Space();
                        
                        // Playback buttons
                        EditorGUILayout.BeginHorizontal();
                        
                        // Stop button
                        if (GUILayout.Button("⏹ Stop", GUILayout.Height(30)))
                        {
                            projector.StopVideo();
                        }
                        
                        // Play/Pause button
                        if (isPlaying)
                        {
                            if (GUILayout.Button("⏸ Pause", GUILayout.Height(30)))
                            {
                                projector.PauseVideo();
                            }
                        }
                        else
                        {
                            if (GUILayout.Button("▶ Play", GUILayout.Height(30)))
                            {
                                projector.PlayVideo();
                            }
                        }
                        
                        EditorGUILayout.EndHorizontal();
                        
                        EditorGUILayout.Space();
                        
                        // Seek buttons
                        EditorGUILayout.BeginHorizontal();
                        
                        if (GUILayout.Button("⏪ -10s", GUILayout.Height(25)))
                        {
                            projector.RewindVideo(10f);
                        }
                        
                        if (GUILayout.Button("⏪ -5s", GUILayout.Height(25)))
                        {
                            projector.RewindVideo(5f);
                        }
                        
                        if (GUILayout.Button("⏩ +5s", GUILayout.Height(25)))
                        {
                            projector.FastForwardVideo(5f);
                        }
                        
                        if (GUILayout.Button("⏩ +10s", GUILayout.Height(25)))
                        {
                            projector.FastForwardVideo(10f);
                        }
                        
                        EditorGUILayout.EndHorizontal();
                        
                        EditorGUILayout.Space();
                        
                        // Speed control
                        EditorGUILayout.LabelField("Playback Speed", EditorStyles.boldLabel);
                        
                        EditorGUI.BeginChangeCheck();
                        float speedMultiplier = EditorGUILayout.Slider("Speed Multiplier", projector.playbackSpeedMultiplier, -4f, 4f);
                        if (EditorGUI.EndChangeCheck())
                        {
                            projector.playbackSpeedMultiplier = speedMultiplier;
                        }
                        
                        EditorGUILayout.BeginHorizontal();
                        if (GUILayout.Button("0.25x")) projector.playbackSpeedMultiplier = 0.25f;
                        if (GUILayout.Button("0.5x")) projector.playbackSpeedMultiplier = 0.5f;
                        if (GUILayout.Button("1x")) projector.playbackSpeedMultiplier = 1f;
                        if (GUILayout.Button("2x")) projector.playbackSpeedMultiplier = 2f;
                        if (GUILayout.Button("4x")) projector.playbackSpeedMultiplier = 4f;
                        EditorGUILayout.EndHorizontal();
                        
                        EditorGUILayout.BeginHorizontal();
                        if (GUILayout.Button("-1x (Reverse)")) projector.playbackSpeedMultiplier = -1f;
                        if (GUILayout.Button("-2x")) projector.playbackSpeedMultiplier = -2f;
                        EditorGUILayout.EndHorizontal();
                        
                        EditorGUILayout.EndVertical();
                        
                        // Force repaint when video is playing
                        if (isPlaying)
                        {
                            Repaint();
                        }
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("Assign a 360° video clip (.mp4) to enable video projection.", MessageType.Warning);
                }
            }
            else
            {
                if (projector.equirectangularTexture != null)
                {
                    var tex = projector.equirectangularTexture;
                    float aspectRatio = (float)tex.width / tex.height;
                    string aspectInfo = Mathf.Abs(aspectRatio - 2.0f) < 0.1f ? 
                        "✓ Good (2:1)" : 
                        $"⚠ Aspect: {aspectRatio:F2}:1 (recommended: 2:1)";
                    
                    EditorGUILayout.HelpBox(
                        $"TEXTURE MODE: {tex.width}x{tex.height}\n" +
                        $"Aspect Ratio: {aspectInfo}\n" +
                        "For best results, use equirectangular textures (panoramic images).",
                        MessageType.Info);
                }
                else
                {
                    EditorGUILayout.HelpBox(
                        "Assign an equirectangular texture (360° panoramic image).\n" +
                        "Recommended aspect ratio: 2:1 (width:height).",
                        MessageType.Warning);
                }
            }

            EditorGUILayout.Space();

            if (projector.autoApply)
            {
                EditorGUILayout.HelpBox(
                    "AUTO-APPLY MODE: Projection applies every frame.\n\n" +
                    "Real-time mode is useful for:\n" +
                    "• Video playback\n" +
                    "• Interactive rotation/offset adjustment\n" +
                    "• Dynamic content updates\n\n" +
                    "Position the projector at the center of your 360° scene.\n" +
                    "Rotate to adjust the viewing angle.",
                    MessageType.Info);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    "MANUAL MODE: Click 'Apply Projection' to bake.\n\n" +
                    "Position the projector at the center of your splat model.\n" +
                    "Adjust rotation offset to align the texture.",
                    MessageType.Info);

                EditorGUILayout.Space();

                bool canApply = projector.projectionType == GaussianSplatEquirectangularProjector.ProjectionType.Texture && 
                               projector.equirectangularTexture != null;
                
                GUI.enabled = canApply;
                if (GUILayout.Button("Apply Projection (Bake)", GUILayout.Height(40)))
                {
                    Undo.RecordObject(projector, "Apply Equirectangular Projection");
                    projector.ApplyProjection();
                    EditorUtility.SetDirty(projector);
                }
                GUI.enabled = true;

                if (!canApply && projector.projectionType == GaussianSplatEquirectangularProjector.ProjectionType.Texture)
                {
                    EditorGUILayout.HelpBox("Assign an equirectangular texture to enable projection.", MessageType.Warning);
                }
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Tips", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "• Place projector at center of your 360° capture point\n" +
                "• Use Rotation Offset to align texture seams\n" +
                "• Flip Horizontal if texture appears mirrored\n" +
                "• UV Offsets allow fine-tuning texture alignment\n" +
                "• Distance filtering can limit projection to specific depth ranges",
                MessageType.None);
        }

        private void OnSceneGUI()
        {
            GaussianSplatEquirectangularProjector projector = (GaussianSplatEquirectangularProjector)target;
            
            string contentName = "No Content";
            if (projector.projectionType == GaussianSplatEquirectangularProjector.ProjectionType.Video)
            {
                contentName = projector.videoClip != null ? projector.videoClip.name + " (360° Video)" : "No Video";
            }
            else
            {
                contentName = projector.equirectangularTexture != null ? projector.equirectangularTexture.name + " (Equirect)" : "No Texture";
            }
            
            // Draw a label in scene view
            Handles.Label(projector.transform.position + Vector3.up * 0.5f, 
                "Equirectangular Projector\n" + contentName,
                new GUIStyle(GUI.skin.label) 
                { 
                    alignment = TextAnchor.MiddleCenter,
                    normal = { textColor = new Color(1f, 0.5f, 0f) }
                });

            // Draw forward direction
            Handles.color = Color.blue;
            Handles.DrawLine(projector.transform.position, 
                            projector.transform.position + projector.transform.forward * 2f);
            Handles.ArrowHandleCap(0, 
                                  projector.transform.position + projector.transform.forward * 2f,
                                  projector.transform.rotation,
                                  0.5f,
                                  EventType.Repaint);
        }
    }
}
#endif

