// SPDX-License-Identifier: MIT

Shader "Gaussian Splatting/Render Skinned Splats"
{
    Properties
    {
        _DirectionalIntensity ("Directional Light Intensity", Range(0, 2)) = 1
        _AmbientIntensity ("Ambient Light Intensity", Range(0, 2)) = 1
        _ShadowStrength ("Shadow Strength", Range(0, 1)) = 0.5
        _SSAOStrength ("SSAO Strength", Range(0, 1)) = 1.0
    }

    SubShader
    {
        Tags {
            "RenderType" = "Transparent"
            "Queue" = "Transparent"
            "RenderPipeline" = "UniversalPipeline"
        }

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }

            ZWrite Off
            Blend OneMinusDstAlpha One
            Cull Off

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma require compute
            #pragma use_dxc
            #pragma multi_compile_local __ DEBUG_SPLAT_RENDER
            #pragma multi_compile_local __ DEBUG_BINDINGS
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS_CASCADE
            #pragma multi_compile _ _ADDITIONAL_LIGHTS
            #pragma multi_compile _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile _ _SHADOWS_SOFT
            #pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX
            #pragma multi_compile_fog
            #pragma multi_compile _ STEREO_MULTIVIEW_ON

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
            #include "Packages/com.unity.render-pipelines.core/ShaderLibrary/UnityInstancing.hlsl"
            #include "GaussianSplatting.hlsl"

            // Skinning parameters (for future implementation)
            int _SkinningSelectionMode;
            float4 _SelectionBoundsCenter;
            float4 _SelectionBoundsSize;
            float4x4 _WorldToLocalMatrix;

            StructuredBuffer<uint> _OrderBuffer;
            StructuredBuffer<SplatViewData> _SplatViewData;
            ByteAddressBuffer _SplatSelectedBits;
            uint _SplatBitsValid;

            CBUFFER_START(UnityPerMaterial)
                float _DirectionalIntensity;
                float _AmbientIntensity;
                float _ShadowStrength;
                float _SSAOStrength;
                float4 _AudioColorTint;
                uint _CustomPointLightCount;
            CBUFFER_END

            struct v2f
            {
                half4 col : COLOR0;
                float2 pos : TEXCOORD0;
                float4 vertex : SV_POSITION;
                float3 normalWS : TEXCOORD1;
                float3 positionWS : TEXCOORD2;
                float4 shadowCoord : TEXCOORD3;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            struct CustomPointLight {
                float3 position;
                float3 color;
                float intensity;
                float range;
            };

            StructuredBuffer<CustomPointLight> _CustomPointLights;
            TEXTURE2D(_GaussianSSAO);
            SAMPLER(sampler_GaussianSSAO);

            // TODO: Bone transformation helper functions would go here
            // These need to be implemented in the compute shader that generates SplatViewData

            // Helper function to check if splat is selected for skinning
            bool IsSplatSelected(uint splatIndex, float3 worldPos)
            {
                if (_SkinningSelectionMode == 0) // AllSplats
                    return true;

                if (_SkinningSelectionMode == 2) // BoundsVolume
                {
                    float3 localPos = mul(_WorldToLocalMatrix, float4(worldPos, 1)).xyz;
                    float3 boundsCenter = _SelectionBoundsCenter.xyz;
                    float3 boundsSize = _SelectionBoundsSize.xyz;

                    return abs(localPos.x - boundsCenter.x) <= boundsSize.x * 0.5 &&
                           abs(localPos.y - boundsCenter.y) <= boundsSize.y * 0.5 &&
                           abs(localPos.z - boundsCenter.z) <= boundsSize.z * 0.5;
                }

                return false;
            }

            struct appdata
            {
                uint vtxID : SV_VertexID;
                uint instID : SV_InstanceID;
            };

            v2f vert(appdata input)
            {
                v2f o = (v2f)0;

                // Multi-Pass VR support (no instance ID conflicts)
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);

                uint vtxID = input.vtxID;
                uint instID = input.instID;
                uint splatIndex = _OrderBuffer[instID];

                // Get view data (this contains pre-computed clip space position and other view-dependent data)
                SplatViewData view = _SplatViewData[instID];

                // Check if this splat should be skinned (for future implementation)
                bool shouldSkin = IsSplatSelected(splatIndex, view.pos.xyz);

                // Use original vertex processing for now
                float4 centerClipPos = view.pos;
                bool behindCam = centerClipPos.w <= 0;

                if (behindCam)
                {
                    o.vertex = asfloat(0x7fc00000); // NaN discards the primitive
                }
                else
                {
                    // Unpack color from the view data
                    o.col.r = f16tof32(view.color.x >> 16);
                    o.col.g = f16tof32(view.color.x);
                    o.col.b = f16tof32(view.color.y >> 16);
                    o.col.a = f16tof32(view.color.y);

                    uint idx = vtxID;
                    float2 quadPos = float2(idx&1, (idx>>1)&1) * 2.0 - 1.0;
                    quadPos *= 2;
                    o.pos = quadPos;

                    // Calculate vertex position in clip space
                    float2 deltaScreenPos = (quadPos.x * view.axis1 + quadPos.y * view.axis2) * 2 / _ScreenParams.xy;
                    o.vertex = centerClipPos;
                    o.vertex.xy += deltaScreenPos * centerClipPos.w;

                    // Transform to world space for lighting calculations
                    o.positionWS = mul(UNITY_MATRIX_I_VP, o.vertex).xyz;

                    // Calculate normal based on view direction
                    float3 viewDir = normalize(_WorldSpaceCameraPos - o.positionWS);
                    o.normalWS = viewDir;

                    o.shadowCoord = TransformWorldToShadowCoord(o.positionWS);
                }

                return o;
            }

            half4 frag(v2f i) : SV_Target
            {
                // Calculate splat coverage
                float power = CalcPowerFromConic(float3(1, 0, 1), i.pos); // Simplified conic for fragment
                float alpha = exp(power);

                // Apply color and opacity
                half4 color = i.col;
                color.a *= saturate(alpha);

                // Apply fog
                #if defined(FOG_LINEAR) || defined(FOG_EXP) || defined(FOG_EXP2)
                float fogFactor = ComputeFogFactor(i.vertex.z);
                color.rgb = MixFog(color.rgb, fogFactor);
                #endif

                return color;
            }
            ENDHLSL
        }
    }
}
