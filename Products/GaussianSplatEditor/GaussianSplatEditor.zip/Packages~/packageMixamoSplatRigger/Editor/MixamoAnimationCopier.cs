// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Editor tool to copy animation data from one Mixamo rig to another.
    /// Supports copying animation clips, retargeting bone paths, and batch processing.
    /// </summary>
    public class MixamoAnimationCopier : EditorWindow
    {
        // Source and Target
        private Animator m_SourceAnimator;
        private Animator m_TargetAnimator;
        private GameObject m_TargetRig; // Can be any GameObject - Animator will be added if needed
        private AnimationClip[] m_SourceClips;
        private AnimationClip m_SelectedClip;
        
        // Bone mapping
        private Dictionary<string, string> m_BoneMapping = new Dictionary<string, string>();
        private bool m_AutoMapBones = true;
        private bool m_ShowBoneMapping = false;
        
        // Output settings
        private string m_OutputFolder = "Assets/CopiedAnimations";
        private string m_AnimationPrefix = "";
        private string m_AnimationSuffix = "_copied";
        private bool m_OverwriteExisting = false;
        
        // Animator Controller settings
        private bool m_CreateAnimatorController = true;
        private bool m_AddToExistingController = false;
        private bool m_AssignToTarget = true;
        private string m_ControllerName = "CopiedAnimations";
        
        // Processing options
        private bool m_CopyRootMotion = true;
        private bool m_PreserveEvents = true;
        private bool m_PreserveCurves = true;
        private float m_TimeScale = 1.0f;
        private bool m_MirrorAnimation = false;
        
        // UI state
        private Vector2 m_ScrollPos;
        private Vector2 m_ClipListScrollPos;
        private Vector2 m_MappingScrollPos;
        private bool[] m_ClipSelection;
        private string m_StatusMessage = "";
        private MessageType m_StatusType = MessageType.None;

        // Standard Mixamo bone names
        private static readonly string[] MixamoBoneNames = new string[]
        {
            "Hips",
            "Spine", "Spine1", "Spine2",
            "Neck", "Head",
            "LeftShoulder", "LeftArm", "LeftForeArm", "LeftHand",
            "LeftHandThumb1", "LeftHandThumb2", "LeftHandThumb3",
            "LeftHandIndex1", "LeftHandIndex2", "LeftHandIndex3",
            "LeftHandMiddle1", "LeftHandMiddle2", "LeftHandMiddle3",
            "LeftHandRing1", "LeftHandRing2", "LeftHandRing3",
            "LeftHandPinky1", "LeftHandPinky2", "LeftHandPinky3",
            "RightShoulder", "RightArm", "RightForeArm", "RightHand",
            "RightHandThumb1", "RightHandThumb2", "RightHandThumb3",
            "RightHandIndex1", "RightHandIndex2", "RightHandIndex3",
            "RightHandMiddle1", "RightHandMiddle2", "RightHandMiddle3",
            "RightHandRing1", "RightHandRing2", "RightHandRing3",
            "RightHandPinky1", "RightHandPinky2", "RightHandPinky3",
            "LeftUpLeg", "LeftLeg", "LeftFoot", "LeftToeBase",
            "RightUpLeg", "RightLeg", "RightFoot", "RightToeBase"
        };

        [MenuItem("Tools/Gaussian Splats/Mixamo Animation Copier")]
        public static void ShowWindow()
        {
            var window = GetWindow<MixamoAnimationCopier>("Mixamo Animation Copier");
            window.minSize = new Vector2(500, 600);
            window.Show();
        }

        private void OnEnable()
        {
            // Delay initialization to avoid Unity inspector conflicts
            EditorApplication.delayCall += DelayedInit;
        }

        private void OnDisable()
        {
            // Clean up references to prevent null reference issues
            EditorApplication.delayCall -= DelayedInit;
        }

        private void DelayedInit()
        {
            // Safety check - window might be closed before delayed call executes
            if (this == null) return;
            
            try
            {
                // Try to find source from selection
                if (Selection.activeGameObject != null)
                {
                    var animator = Selection.activeGameObject.GetComponentInChildren<Animator>();
                    if (animator != null)
                    {
                        m_SourceAnimator = animator;
                        RefreshSourceClips();
                    }
                }
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"[Animation Copier] Init warning: {e.Message}");
            }
        }

        private void OnGUI()
        {
            m_ScrollPos = EditorGUILayout.BeginScrollView(m_ScrollPos);

            DrawHeader();
            EditorGUILayout.Space(10);
            
            DrawSourceSection();
            EditorGUILayout.Space(10);
            
            DrawTargetSection();
            EditorGUILayout.Space(10);
            
            DrawBoneMappingSection();
            EditorGUILayout.Space(10);
            
            DrawOptionsSection();
            EditorGUILayout.Space(10);
            
            DrawOutputSection();
            EditorGUILayout.Space(10);
            
            DrawClipSelectionSection();
            EditorGUILayout.Space(10);
            
            DrawActionsSection();
            
            DrawStatusMessage();

            EditorGUILayout.EndScrollView();
        }

        private void DrawHeader()
        {
            EditorGUILayout.LabelField("Mixamo Animation Copier", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Copy animation data from one Mixamo rig to another.\n" +
                "• Both rigs should use Mixamo naming conventions\n" +
                "• Animation curves are remapped to target rig paths\n" +
                "• Supports batch processing of multiple clips",
                MessageType.Info);
        }

        private void DrawSourceSection()
        {
            EditorGUILayout.LabelField("Source Rig", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            m_SourceAnimator = (Animator)EditorGUILayout.ObjectField(
                "Source Animator", m_SourceAnimator, typeof(Animator), true);
            
            if (EditorGUI.EndChangeCheck())
            {
                RefreshSourceClips();
            }

            // Check if animator is valid (not null and not destroyed)
            if (m_SourceAnimator != null && m_SourceAnimator.gameObject != null)
            {
                EditorGUI.indentLevel++;
                
                // Show controller info
                try
                {
                    if (m_SourceAnimator.runtimeAnimatorController != null)
                    {
                        EditorGUILayout.LabelField("Controller", m_SourceAnimator.runtimeAnimatorController.name);
                        EditorGUILayout.LabelField("Clips Found", m_SourceClips != null ? m_SourceClips.Length.ToString() : "0");
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("No AnimatorController assigned to source.", MessageType.Warning);
                    }
                }
                catch (MissingReferenceException)
                {
                    m_SourceAnimator = null;
                    return;
                }

                // Show avatar info
                if (m_SourceAnimator != null && m_SourceAnimator.avatar != null)
                {
                    EditorGUILayout.LabelField("Avatar", m_SourceAnimator.avatar.name);
                    EditorGUILayout.LabelField("Is Human", m_SourceAnimator.avatar.isHuman.ToString());
                }
                
                EditorGUI.indentLevel--;
            }

            // Manual clip selection
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Or drag clips directly:", EditorStyles.miniLabel);
            
            EditorGUI.BeginChangeCheck();
            m_SelectedClip = (AnimationClip)EditorGUILayout.ObjectField(
                "Single Clip", m_SelectedClip, typeof(AnimationClip), false);
            if (EditorGUI.EndChangeCheck() && m_SelectedClip != null)
            {
                // Add to source clips if not already there
                if (m_SourceClips == null || !m_SourceClips.Contains(m_SelectedClip))
                {
                    var clipList = m_SourceClips != null ? m_SourceClips.ToList() : new List<AnimationClip>();
                    clipList.Add(m_SelectedClip);
                    m_SourceClips = clipList.ToArray();
                    m_ClipSelection = new bool[m_SourceClips.Length];
                    m_ClipSelection[m_ClipSelection.Length - 1] = true;
                }
            }
        }

        private void DrawTargetSection()
        {
            EditorGUILayout.LabelField("Target Rig", EditorStyles.boldLabel);
            
            // Allow selecting any GameObject as target - Animator will be added if needed
            EditorGUI.BeginChangeCheck();
            m_TargetRig = (GameObject)EditorGUILayout.ObjectField(
                "Target Rig (GameObject)", m_TargetRig, typeof(GameObject), true);
            
            if (EditorGUI.EndChangeCheck())
            {
                // Try to find or create animator on target
                if (m_TargetRig != null)
                {
                    m_TargetAnimator = m_TargetRig.GetComponent<Animator>();
                    // Don't auto-add here, just detect
                }
                else
                {
                    m_TargetAnimator = null;
                }
                
                if (m_AutoMapBones)
                {
                    AutoMapBones();
                }
            }

            // Show status of target rig
            if (m_TargetRig != null)
            {
                EditorGUI.indentLevel++;
                
                try
                {
                    // Check if target has Animator
                    if (m_TargetAnimator == null)
                    {
                        m_TargetAnimator = m_TargetRig.GetComponent<Animator>();
                    }
                    
                    if (m_TargetAnimator != null)
                    {
                        EditorGUILayout.LabelField("Animator", "✓ Found");
                        
                        // Show avatar info
                        if (m_TargetAnimator.avatar != null)
                        {
                            EditorGUILayout.LabelField("Avatar", m_TargetAnimator.avatar.name);
                            EditorGUILayout.LabelField("Is Human", m_TargetAnimator.avatar.isHuman.ToString());
                        }
                        else
                        {
                            EditorGUILayout.HelpBox("No Avatar assigned. Generic animation will be used.", MessageType.Info);
                        }
                        
                        if (m_TargetAnimator.runtimeAnimatorController != null)
                        {
                            EditorGUILayout.LabelField("Controller", m_TargetAnimator.runtimeAnimatorController.name);
                        }
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("No Animator component found. One will be added automatically when copying animations.", MessageType.Info);
                        
                        if (GUILayout.Button("Add Animator Now"))
                        {
                            AddAnimatorToTarget();
                        }
                    }
                }
                catch (MissingReferenceException)
                {
                    m_TargetAnimator = null;
                    m_TargetRig = null;
                    return;
                }
                
                EditorGUI.indentLevel--;
            }
            else
            {
                EditorGUILayout.HelpBox("Drag any GameObject here to use as the target rig. An Animator component will be added if needed.", MessageType.Info);
            }
        }
        
        private void AddAnimatorToTarget()
        {
            if (m_TargetRig == null) return;
            
            m_TargetAnimator = m_TargetRig.GetComponent<Animator>();
            if (m_TargetAnimator == null)
            {
                Undo.RecordObject(m_TargetRig, "Add Animator");
                m_TargetAnimator = Undo.AddComponent<Animator>(m_TargetRig);
                m_TargetAnimator.applyRootMotion = true;
                EditorUtility.SetDirty(m_TargetRig);
                Debug.Log($"[Animation Copier] Added Animator to {m_TargetRig.name}");
            }
        }

        private void DrawBoneMappingSection()
        {
            EditorGUILayout.LabelField("Bone Mapping", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            m_AutoMapBones = EditorGUILayout.Toggle("Auto-Map Bones", m_AutoMapBones);
            
            if (GUILayout.Button("Refresh Mapping", GUILayout.Width(120)))
            {
                AutoMapBones();
            }
            EditorGUILayout.EndHorizontal();

            m_ShowBoneMapping = EditorGUILayout.Foldout(m_ShowBoneMapping, $"Bone Mapping ({m_BoneMapping.Count} mapped)");
            
            if (m_ShowBoneMapping)
            {
                EditorGUI.indentLevel++;
                m_MappingScrollPos = EditorGUILayout.BeginScrollView(m_MappingScrollPos, GUILayout.MaxHeight(200));
                
                if (m_BoneMapping.Count > 0)
                {
                    foreach (var mapping in m_BoneMapping)
                    {
                        EditorGUILayout.BeginHorizontal();
                        EditorGUILayout.LabelField(mapping.Key, GUILayout.Width(200));
                        EditorGUILayout.LabelField("→", GUILayout.Width(20));
                        EditorGUILayout.LabelField(mapping.Value);
                        EditorGUILayout.EndHorizontal();
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("No bone mapping available. Select source and target rigs first.", MessageType.Info);
                }
                
                EditorGUILayout.EndScrollView();
                EditorGUI.indentLevel--;
            }
        }

        private void DrawOptionsSection()
        {
            EditorGUILayout.LabelField("Processing Options", EditorStyles.boldLabel);
            
            m_CopyRootMotion = EditorGUILayout.Toggle("Copy Root Motion", m_CopyRootMotion);
            m_PreserveEvents = EditorGUILayout.Toggle("Preserve Animation Events", m_PreserveEvents);
            m_PreserveCurves = EditorGUILayout.Toggle("Preserve All Curves", m_PreserveCurves);
            m_TimeScale = EditorGUILayout.Slider("Time Scale", m_TimeScale, 0.1f, 3.0f);
            m_MirrorAnimation = EditorGUILayout.Toggle("Mirror Animation (L↔R)", m_MirrorAnimation);
            
            if (m_MirrorAnimation)
            {
                EditorGUILayout.HelpBox("Mirror will swap Left/Right bone animations.", MessageType.Info);
            }
        }

        private void DrawOutputSection()
        {
            EditorGUILayout.LabelField("Output Settings", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            m_OutputFolder = EditorGUILayout.TextField("Output Folder", m_OutputFolder);
            if (GUILayout.Button("Browse", GUILayout.Width(60)))
            {
                string path = EditorUtility.OpenFolderPanel("Select Output Folder", "Assets", "");
                if (!string.IsNullOrEmpty(path))
                {
                    // Convert to relative path
                    if (path.StartsWith(Application.dataPath))
                    {
                        m_OutputFolder = "Assets" + path.Substring(Application.dataPath.Length);
                    }
                    else
                    {
                        m_OutputFolder = path;
                    }
                }
            }
            EditorGUILayout.EndHorizontal();

            m_AnimationPrefix = EditorGUILayout.TextField("Animation Prefix", m_AnimationPrefix);
            m_AnimationSuffix = EditorGUILayout.TextField("Animation Suffix", m_AnimationSuffix);
            m_OverwriteExisting = EditorGUILayout.Toggle("Overwrite Existing", m_OverwriteExisting);
            
            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("Animator Controller", EditorStyles.boldLabel);
            
            m_CreateAnimatorController = EditorGUILayout.Toggle("Create Animator Controller", m_CreateAnimatorController);
            
            if (m_CreateAnimatorController)
            {
                EditorGUI.indentLevel++;
                m_ControllerName = EditorGUILayout.TextField("Controller Name", m_ControllerName);
                m_AssignToTarget = EditorGUILayout.Toggle("Assign to Target Rig", m_AssignToTarget);
                EditorGUI.indentLevel--;
                
                EditorGUILayout.HelpBox("A new AnimatorController will be created with all copied clips and assigned to the target rig.", MessageType.Info);
            }
            else
            {
                m_AddToExistingController = EditorGUILayout.Toggle("Add to Target's Controller", m_AddToExistingController);
                
                if (m_AddToExistingController)
                {
                    if (m_TargetAnimator != null && m_TargetAnimator.runtimeAnimatorController != null)
                    {
                        EditorGUILayout.HelpBox($"Clips will be added to: {m_TargetAnimator.runtimeAnimatorController.name}", MessageType.Info);
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("Target has no AnimatorController. One will be created.", MessageType.Warning);
                        m_CreateAnimatorController = true;
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("Animation clips will be saved but NOT added to any controller. You'll need to manually add them.", MessageType.Warning);
                }
            }
        }

        private void DrawClipSelectionSection()
        {
            EditorGUILayout.LabelField("Animation Clips", EditorStyles.boldLabel);
            
            if (m_SourceClips == null || m_SourceClips.Length == 0)
            {
                EditorGUILayout.HelpBox("No animation clips found. Assign a source animator with clips or drag clips directly.", MessageType.Info);
                return;
            }

            // Selection buttons
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Select All"))
            {
                for (int i = 0; i < m_ClipSelection.Length; i++)
                    m_ClipSelection[i] = true;
            }
            if (GUILayout.Button("Select None"))
            {
                for (int i = 0; i < m_ClipSelection.Length; i++)
                    m_ClipSelection[i] = false;
            }
            EditorGUILayout.EndHorizontal();

            // Clip list
            m_ClipListScrollPos = EditorGUILayout.BeginScrollView(m_ClipListScrollPos, GUILayout.MaxHeight(200));
            
            for (int i = 0; i < m_SourceClips.Length; i++)
            {
                if (m_SourceClips[i] == null) continue;
                
                EditorGUILayout.BeginHorizontal();
                m_ClipSelection[i] = EditorGUILayout.Toggle(m_ClipSelection[i], GUILayout.Width(20));
                EditorGUILayout.LabelField(m_SourceClips[i].name);
                EditorGUILayout.LabelField($"{m_SourceClips[i].length:F2}s", GUILayout.Width(50));
                EditorGUILayout.LabelField(m_SourceClips[i].isLooping ? "Loop" : "", GUILayout.Width(40));
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.EndScrollView();
            
            int selectedCount = m_ClipSelection.Count(x => x);
            EditorGUILayout.LabelField($"Selected: {selectedCount} / {m_SourceClips.Length} clips");
        }

        private void DrawActionsSection()
        {
            EditorGUILayout.LabelField("Actions", EditorStyles.boldLabel);
            
            // Allow copying if we have a target rig (Animator will be auto-added)
            bool canCopy = m_TargetRig != null && 
                           m_SourceClips != null && 
                           m_SourceClips.Length > 0 &&
                           m_ClipSelection != null &&
                           m_ClipSelection.Any(x => x);

            EditorGUI.BeginDisabledGroup(!canCopy);
            
            if (GUILayout.Button("Copy Selected Animations", GUILayout.Height(40)))
            {
                CopySelectedAnimations();
            }
            
            EditorGUI.EndDisabledGroup();

            if (!canCopy)
            {
                string reason = "";
                if (m_TargetRig == null) reason = "No target rig selected";
                else if (m_SourceClips == null || m_SourceClips.Length == 0) reason = "No source clips available";
                else if (m_ClipSelection == null || !m_ClipSelection.Any(x => x)) reason = "No clips selected";
                
                EditorGUILayout.HelpBox(reason, MessageType.Warning);
            }

            EditorGUILayout.Space(5);

            // Additional tools
            EditorGUILayout.BeginHorizontal();
            
            if (GUILayout.Button("Analyze Source Clips"))
            {
                AnalyzeSourceClips();
            }
            
            if (GUILayout.Button("Preview Mapping"))
            {
                PreviewMapping();
            }
            
            EditorGUILayout.EndHorizontal();
        }

        private void DrawStatusMessage()
        {
            if (!string.IsNullOrEmpty(m_StatusMessage))
            {
                EditorGUILayout.Space(10);
                EditorGUILayout.HelpBox(m_StatusMessage, m_StatusType);
            }
        }

        private void RefreshSourceClips()
        {
            try
            {
                // Check if animator is valid (not null and not destroyed)
                if (m_SourceAnimator == null || m_SourceAnimator.gameObject == null)
                {
                    m_SourceClips = null;
                    m_ClipSelection = null;
                    return;
                }
                
                if (m_SourceAnimator.runtimeAnimatorController == null)
                {
                    m_SourceClips = null;
                    m_ClipSelection = null;
                    return;
                }

                // Get all clips from the animator controller
                m_SourceClips = m_SourceAnimator.runtimeAnimatorController.animationClips
                    .Where(c => c != null)
                    .Distinct()
                    .ToArray();
                
                m_ClipSelection = new bool[m_SourceClips.Length];

                if (m_AutoMapBones)
                {
                    AutoMapBones();
                }
            }
            catch (MissingReferenceException)
            {
                m_SourceAnimator = null;
                m_SourceClips = null;
                m_ClipSelection = null;
            }
        }

        private void AutoMapBones()
        {
            m_BoneMapping.Clear();
            m_TargetBoneNameMap = null; // Reset cache

            try
            {
                // Check if source animator is valid
                if (m_SourceAnimator == null || m_SourceAnimator.gameObject == null)
                    return;
                
                // Get target transform - use target rig or target animator
                Transform targetTransform = null;
                if (m_TargetRig != null)
                {
                    targetTransform = m_TargetRig.transform;
                }
                else if (m_TargetAnimator != null && m_TargetAnimator.gameObject != null)
                {
                    targetTransform = m_TargetAnimator.transform;
                }
                
                if (targetTransform == null)
                    return;

                // Get source bone paths
                var sourceBones = GetBonePaths(m_SourceAnimator.transform);
                var targetBones = GetBonePaths(targetTransform);
                
                // Build target bone name map for remapping
                BuildTargetBoneNameMap();

                // Map bones by name (Mixamo uses consistent naming)
                foreach (var sourcePath in sourceBones)
                {
                    string boneName = GetBoneName(sourcePath);
                    
                    // First try exact match
                    string targetPath = targetBones.FirstOrDefault(t => GetBoneName(t) == boneName);
                    
                    if (string.IsNullOrEmpty(targetPath))
                    {
                        // Try matching by normalized name (handles mixamorig: prefix)
                        string normalizedSourceName = NormalizeBoneName(boneName).ToLower();
                        targetPath = targetBones.FirstOrDefault(t => 
                            NormalizeBoneName(GetBoneName(t)).ToLower() == normalizedSourceName);
                    }
                    
                    if (string.IsNullOrEmpty(targetPath))
                    {
                        // Try fuzzy matching for slight variations
                        targetPath = FindSimilarBone(boneName, targetBones);
                    }
                    
                    if (!string.IsNullOrEmpty(targetPath))
                    {
                        m_BoneMapping[sourcePath] = targetPath;
                    }
                }

                Debug.Log($"[Animation Copier] Bone mapping complete: {m_BoneMapping.Count} bones mapped");
                Debug.Log($"[Animation Copier] Source bones: {sourceBones.Count}, Target bones: {targetBones.Count}");
                
                // Log some sample mappings
                int count = 0;
                foreach (var mapping in m_BoneMapping)
                {
                    if (count++ < 5)
                        Debug.Log($"[Animation Copier] Mapping: {mapping.Key} → {mapping.Value}");
                }
                
                SetStatus($"Mapped {m_BoneMapping.Count} bones between source and target.", MessageType.Info);
            }
            catch (MissingReferenceException)
            {
                // One of the objects was destroyed
                SetStatus("Lost reference to rig. Please reassign.", MessageType.Warning);
            }
        }

        private List<string> GetBonePaths(Transform root)
        {
            var paths = new List<string>();
            CollectBonePaths(root, "", paths);
            return paths;
        }

        private void CollectBonePaths(Transform current, string path, List<string> paths)
        {
            string currentPath = string.IsNullOrEmpty(path) ? current.name : path + "/" + current.name;
            paths.Add(currentPath);

            foreach (Transform child in current)
            {
                CollectBonePaths(child, currentPath, paths);
            }
        }

        private string GetBoneName(string path)
        {
            int lastSlash = path.LastIndexOf('/');
            return lastSlash >= 0 ? path.Substring(lastSlash + 1) : path;
        }

        private string FindSimilarBone(string boneName, List<string> targetBones)
        {
            // Use normalized bone name matching
            string normalizedName = NormalizeBoneName(boneName).ToLower();

            foreach (var targetPath in targetBones)
            {
                string targetName = NormalizeBoneName(GetBoneName(targetPath)).ToLower();

                if (targetName == normalizedName)
                {
                    return targetPath;
                }
            }

            return null;
        }

        private void CopySelectedAnimations()
        {
            if (!ValidateSetup())
                return;

            // Auto-add Animator to target if needed
            if (m_TargetRig != null && m_TargetAnimator == null)
            {
                AddAnimatorToTarget();
            }

            // Create output folder if needed
            if (!AssetDatabase.IsValidFolder(m_OutputFolder))
            {
                CreateFolderRecursive(m_OutputFolder);
            }

            int successCount = 0;
            int failCount = 0;
            List<AnimationClip> createdClips = new List<AnimationClip>();

            try
            {
                for (int i = 0; i < m_SourceClips.Length; i++)
                {
                    if (!m_ClipSelection[i] || m_SourceClips[i] == null)
                        continue;

                    EditorUtility.DisplayProgressBar("Copying Animations", 
                        $"Processing {m_SourceClips[i].name}...", 
                        (float)i / m_SourceClips.Length);

                    AnimationClip newClip = CopyAnimationClip(m_SourceClips[i]);
                    
                    if (newClip != null)
                    {
                        // Save the clip
                        string clipName = m_AnimationPrefix + m_SourceClips[i].name + m_AnimationSuffix;
                        string assetPath = $"{m_OutputFolder}/{clipName}.anim";

                        if (!m_OverwriteExisting)
                        {
                            assetPath = AssetDatabase.GenerateUniqueAssetPath(assetPath);
                        }

                        AssetDatabase.CreateAsset(newClip, assetPath);
                        createdClips.Add(newClip);
                        successCount++;
                        
                        Debug.Log($"[Animation Copier] Created: {assetPath}");
                    }
                    else
                    {
                        failCount++;
                        Debug.LogWarning($"[Animation Copier] Failed to copy: {m_SourceClips[i].name}");
                    }
                }

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                // Create or update AnimatorController
                AnimatorController controller = null;
                
                if (createdClips.Count > 0)
                {
                    if (m_CreateAnimatorController)
                    {
                        EditorUtility.DisplayProgressBar("Creating Controller", "Creating AnimatorController...", 0.9f);
                        controller = CreateAnimatorController(createdClips);
                    }
                    else if (m_AddToExistingController && m_TargetAnimator != null && m_TargetAnimator.runtimeAnimatorController != null)
                    {
                        EditorUtility.DisplayProgressBar("Updating Controller", "Adding clips to existing controller...", 0.9f);
                        controller = AddClipsToExistingController(createdClips);
                    }
                    
                    // Assign to target
                    if (m_AssignToTarget && controller != null)
                    {
                        // Make sure we have an animator (should have been added earlier)
                        if (m_TargetAnimator == null && m_TargetRig != null)
                        {
                            AddAnimatorToTarget();
                        }
                        
                        if (m_TargetAnimator != null)
                        {
                            Undo.RecordObject(m_TargetAnimator, "Assign AnimatorController");
                            m_TargetAnimator.runtimeAnimatorController = controller;
                            EditorUtility.SetDirty(m_TargetAnimator);
                            Debug.Log($"[Animation Copier] Assigned controller to {m_TargetAnimator.gameObject.name}");
                        }
                    }
                }

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                string controllerInfo = controller != null ? $"\nAnimatorController: {controller.name}" : "";
                string assignInfo = (m_AssignToTarget && controller != null) ? "\n✓ Controller assigned to target rig!" : "";
                
                SetStatus($"Successfully copied {successCount} animation(s). Failed: {failCount}{controllerInfo}{assignInfo}", 
                    failCount > 0 ? MessageType.Warning : MessageType.Info);

                // Ping the controller if created, otherwise first clip
                if (controller != null)
                {
                    EditorGUIUtility.PingObject(controller);
                    Selection.activeObject = controller;
                }
                else if (createdClips.Count > 0)
                {
                    EditorGUIUtility.PingObject(createdClips[0]);
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
        
        private AnimatorController CreateAnimatorController(List<AnimationClip> clips)
        {
            string controllerPath = $"{m_OutputFolder}/{m_ControllerName}.controller";
            
            if (!m_OverwriteExisting)
            {
                controllerPath = AssetDatabase.GenerateUniqueAssetPath(controllerPath);
            }
            
            // Create the controller
            AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath(controllerPath);
            
            // Get the root state machine
            AnimatorStateMachine rootStateMachine = controller.layers[0].stateMachine;
            
            // Add a state for each clip
            float yOffset = 0;
            bool isFirst = true;
            
            foreach (var clip in clips)
            {
                // Create state
                AnimatorState state = rootStateMachine.AddState(clip.name, new Vector3(300, yOffset, 0));
                state.motion = clip;
                
                // Set first clip as default
                if (isFirst)
                {
                    rootStateMachine.defaultState = state;
                    isFirst = false;
                }
                
                yOffset += 50;
            }
            
            // Add parameters for triggering animations
            foreach (var clip in clips)
            {
                string paramName = "Play" + clip.name.Replace(" ", "").Replace("_", "");
                if (!HasParameter(controller, paramName))
                {
                    controller.AddParameter(paramName, AnimatorControllerParameterType.Trigger);
                }
            }
            
            // Create transitions from Any State
            var states = rootStateMachine.states;
            var parameters = controller.parameters;
            
            for (int i = 0; i < clips.Count && i < parameters.Length; i++)
            {
                var transition = rootStateMachine.AddAnyStateTransition(states[i].state);
                transition.AddCondition(AnimatorConditionMode.If, 0, parameters[i].name);
                transition.duration = 0.25f;
                transition.hasExitTime = false;
            }
            
            EditorUtility.SetDirty(controller);
            AssetDatabase.SaveAssets();
            
            Debug.Log($"[Animation Copier] Created AnimatorController: {controllerPath} with {clips.Count} states");
            
            return controller;
        }
        
        private AnimatorController AddClipsToExistingController(List<AnimationClip> clips)
        {
            if (m_TargetAnimator == null || m_TargetAnimator.runtimeAnimatorController == null)
                return null;
            
            // Get the controller - it might be a RuntimeAnimatorController, we need AnimatorController
            string controllerPath = AssetDatabase.GetAssetPath(m_TargetAnimator.runtimeAnimatorController);
            AnimatorController controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(controllerPath);
            
            if (controller == null)
            {
                Debug.LogWarning("[Animation Copier] Could not get AnimatorController. Creating new one instead.");
                return CreateAnimatorController(clips);
            }
            
            // Get the root state machine
            AnimatorStateMachine rootStateMachine = controller.layers[0].stateMachine;
            
            // Find the lowest Y position of existing states
            float yOffset = 0;
            foreach (var childState in rootStateMachine.states)
            {
                if (childState.position.y > yOffset)
                    yOffset = childState.position.y;
            }
            yOffset += 60; // Start below existing states
            
            // Add states for new clips
            foreach (var clip in clips)
            {
                // Check if state already exists
                bool stateExists = rootStateMachine.states.Any(s => s.state.name == clip.name);
                if (stateExists)
                {
                    Debug.Log($"[Animation Copier] State '{clip.name}' already exists, skipping.");
                    continue;
                }
                
                AnimatorState state = rootStateMachine.AddState(clip.name, new Vector3(300, yOffset, 0));
                state.motion = clip;
                yOffset += 50;
                
                // Add trigger parameter
                string paramName = "Play" + clip.name.Replace(" ", "").Replace("_", "");
                if (!HasParameter(controller, paramName))
                {
                    controller.AddParameter(paramName, AnimatorControllerParameterType.Trigger);
                    
                    // Create transition from Any State
                    var transition = rootStateMachine.AddAnyStateTransition(state);
                    transition.AddCondition(AnimatorConditionMode.If, 0, paramName);
                    transition.duration = 0.25f;
                    transition.hasExitTime = false;
                }
            }
            
            EditorUtility.SetDirty(controller);
            AssetDatabase.SaveAssets();
            
            Debug.Log($"[Animation Copier] Added {clips.Count} clips to existing controller: {controllerPath}");
            
            return controller;
        }
        
        private bool HasParameter(AnimatorController controller, string paramName)
        {
            foreach (var param in controller.parameters)
            {
                if (param.name == paramName)
                    return true;
            }
            return false;
        }

        private AnimationClip CopyAnimationClip(AnimationClip source)
        {
            AnimationClip newClip = new AnimationClip();
            newClip.name = source.name;
            newClip.legacy = source.legacy;
            newClip.wrapMode = source.wrapMode;
            newClip.frameRate = source.frameRate;

            // Copy animation settings
            AnimationClipSettings settings = AnimationUtility.GetAnimationClipSettings(source);
            if (m_TimeScale != 1.0f)
            {
                // Adjust cycle offset for time scale
                settings.cycleOffset *= m_TimeScale;
            }
            AnimationUtility.SetAnimationClipSettings(newClip, settings);

            // Get all curve bindings from source
            EditorCurveBinding[] curveBindings = AnimationUtility.GetCurveBindings(source);
            EditorCurveBinding[] objectBindings = AnimationUtility.GetObjectReferenceCurveBindings(source);
            
            Debug.Log($"[Animation Copier] Processing {source.name}: {curveBindings.Length} curves");
            
            int remappedCount = 0;
            HashSet<string> loggedPaths = new HashSet<string>();

            // Process each curve binding
            foreach (var binding in curveBindings)
            {
                AnimationCurve curve = AnimationUtility.GetEditorCurve(source, binding);
                if (curve == null) continue;

                // Apply time scale if needed
                if (m_TimeScale != 1.0f)
                {
                    curve = ScaleAnimationCurve(curve, m_TimeScale);
                }

                // Remap path if needed
                EditorCurveBinding newBinding = RemapBinding(binding);
                
                // Log path remapping (only once per unique path)
                if (!loggedPaths.Contains(binding.path))
                {
                    loggedPaths.Add(binding.path);
                    if (binding.path != newBinding.path)
                    {
                        Debug.Log($"[Animation Copier] Remap: '{binding.path}' → '{newBinding.path}'");
                        remappedCount++;
                    }
                }

                // Handle mirroring
                if (m_MirrorAnimation)
                {
                    newBinding = MirrorBinding(newBinding);
                    
                    // Mirror rotation/position values for certain properties
                    if (ShouldMirrorValues(newBinding))
                    {
                        curve = MirrorCurveValues(curve, newBinding);
                    }
                }

                AnimationUtility.SetEditorCurve(newClip, newBinding, curve);
            }
            
            Debug.Log($"[Animation Copier] Remapped {remappedCount} unique paths out of {loggedPaths.Count}");

            // Copy object reference curves (for events, etc.)
            foreach (var binding in objectBindings)
            {
                var keyframes = AnimationUtility.GetObjectReferenceCurve(source, binding);
                if (keyframes == null) continue;

                EditorCurveBinding newBinding = RemapBinding(binding);
                
                if (m_TimeScale != 1.0f)
                {
                    // Scale keyframe times
                    for (int i = 0; i < keyframes.Length; i++)
                    {
                        keyframes[i].time /= m_TimeScale;
                    }
                }

                AnimationUtility.SetObjectReferenceCurve(newClip, newBinding, keyframes);
            }

            // Copy animation events if enabled
            if (m_PreserveEvents)
            {
                var events = AnimationUtility.GetAnimationEvents(source);
                if (events != null && events.Length > 0)
                {
                    if (m_TimeScale != 1.0f)
                    {
                        // Scale event times
                        foreach (var evt in events)
                        {
                            evt.time /= m_TimeScale;
                        }
                    }
                    AnimationUtility.SetAnimationEvents(newClip, events);
                }
            }

            return newClip;
        }

        private EditorCurveBinding RemapBinding(EditorCurveBinding binding)
        {
            EditorCurveBinding newBinding = binding;

            // Try to remap the path
            if (m_BoneMapping.TryGetValue(binding.path, out string newPath))
            {
                newBinding.path = newPath;
                return newBinding;
            }
            
            // Try to reconstruct the full target path by mapping each bone in the hierarchy
            string remappedPath = RemapPathByBoneNames(binding.path);
            if (!string.IsNullOrEmpty(remappedPath))
            {
                newBinding.path = remappedPath;
                return newBinding;
            }

            // Try to find by last bone name only
            string boneName = GetBoneName(binding.path);
            string targetPath = FindTargetPathByBoneName(boneName);
            if (!string.IsNullOrEmpty(targetPath))
            {
                newBinding.path = targetPath;
            }

            return newBinding;
        }
        
        /// <summary>
        /// Reconstruct the target path by mapping each bone name in the source path
        /// Source: "Hips/Spine/Spine1/LeftShoulder"
        /// Target: "mixamorig:Hips/mixamorig:Spine/mixamorig:Spine1/mixamorig:LeftShoulder"
        /// </summary>
        private string RemapPathByBoneNames(string sourcePath)
        {
            if (string.IsNullOrEmpty(sourcePath))
                return null;
                
            string[] sourceBones = sourcePath.Split('/');
            List<string> targetBones = new List<string>();
            
            foreach (string sourceBone in sourceBones)
            {
                string normalizedSourceBone = NormalizeBoneName(sourceBone);
                string targetBone = FindTargetBoneByNormalizedName(normalizedSourceBone);
                
                if (string.IsNullOrEmpty(targetBone))
                {
                    // Can't map this bone, try to keep original
                    targetBone = sourceBone;
                }
                
                targetBones.Add(targetBone);
            }
            
            return string.Join("/", targetBones);
        }
        
        /// <summary>
        /// Find target bone name by normalized name (strips prefixes like "mixamorig:")
        /// </summary>
        private string FindTargetBoneByNormalizedName(string normalizedName)
        {
            if (m_TargetBoneNameMap == null)
                BuildTargetBoneNameMap();
                
            if (m_TargetBoneNameMap.TryGetValue(normalizedName.ToLower(), out string targetBone))
            {
                return targetBone;
            }
            
            return null;
        }
        
        /// <summary>
        /// Find full target path by bone name
        /// </summary>
        private string FindTargetPathByBoneName(string boneName)
        {
            string normalizedName = NormalizeBoneName(boneName);
            
            foreach (var mapping in m_BoneMapping)
            {
                string targetBoneName = GetBoneName(mapping.Value);
                if (NormalizeBoneName(targetBoneName).Equals(normalizedName, System.StringComparison.OrdinalIgnoreCase))
                {
                    return mapping.Value;
                }
            }
            
            return null;
        }
        
        // Cache for target bone names
        private Dictionary<string, string> m_TargetBoneNameMap;
        
        private void BuildTargetBoneNameMap()
        {
            m_TargetBoneNameMap = new Dictionary<string, string>();
            
            Transform targetTransform = null;
            if (m_TargetRig != null)
                targetTransform = m_TargetRig.transform;
            else if (m_TargetAnimator != null)
                targetTransform = m_TargetAnimator.transform;
                
            if (targetTransform == null)
                return;
                
            // Recursively collect all bones
            CollectBoneNames(targetTransform);
        }
        
        private void CollectBoneNames(Transform current)
        {
            string boneName = current.name;
            string normalizedName = NormalizeBoneName(boneName).ToLower();
            
            if (!m_TargetBoneNameMap.ContainsKey(normalizedName))
            {
                m_TargetBoneNameMap[normalizedName] = boneName;
            }
            
            foreach (Transform child in current)
            {
                CollectBoneNames(child);
            }
        }
        
        /// <summary>
        /// Normalize bone name by removing common prefixes like "mixamorig:"
        /// </summary>
        private string NormalizeBoneName(string boneName)
        {
            if (string.IsNullOrEmpty(boneName))
                return boneName;
                
            // Remove common Mixamo prefixes
            string normalized = boneName
                .Replace("mixamorig:", "")
                .Replace("mixamorig_", "")
                .Replace("Mixamorig:", "")
                .Replace("Mixamorig_", "")
                .Replace("_", "")
                .Trim();
                
            return normalized;
        }

        private EditorCurveBinding MirrorBinding(EditorCurveBinding binding)
        {
            EditorCurveBinding newBinding = binding;

            // Swap Left/Right in path
            if (binding.path.Contains("Left"))
            {
                newBinding.path = binding.path.Replace("Left", "Right");
            }
            else if (binding.path.Contains("Right"))
            {
                newBinding.path = binding.path.Replace("Right", "Left");
            }

            return newBinding;
        }

        private bool ShouldMirrorValues(EditorCurveBinding binding)
        {
            // Mirror X position and Y/Z rotation for left/right swap
            string prop = binding.propertyName.ToLower();
            return prop.Contains("position.x") || 
                   prop.Contains("rotation.y") || 
                   prop.Contains("rotation.z") ||
                   prop.Contains("localeuler.y") ||
                   prop.Contains("localeuler.z");
        }

        private AnimationCurve MirrorCurveValues(AnimationCurve curve, EditorCurveBinding binding)
        {
            Keyframe[] keys = curve.keys;
            for (int i = 0; i < keys.Length; i++)
            {
                keys[i].value = -keys[i].value;
                keys[i].inTangent = -keys[i].inTangent;
                keys[i].outTangent = -keys[i].outTangent;
            }
            return new AnimationCurve(keys);
        }

        private AnimationCurve ScaleAnimationCurve(AnimationCurve curve, float scale)
        {
            Keyframe[] keys = curve.keys;
            for (int i = 0; i < keys.Length; i++)
            {
                keys[i].time /= scale;
                keys[i].inTangent *= scale;
                keys[i].outTangent *= scale;
            }
            return new AnimationCurve(keys);
        }

        private bool ValidateSetup()
        {
            // Check for target rig (Animator will be auto-added if needed)
            if (m_TargetRig == null)
            {
                SetStatus("Please assign a target rig (any GameObject).", MessageType.Error);
                return false;
            }

            if (m_SourceClips == null || m_SourceClips.Length == 0)
            {
                SetStatus("No source animation clips available.", MessageType.Error);
                return false;
            }

            if (!m_ClipSelection.Any(x => x))
            {
                SetStatus("Please select at least one animation clip to copy.", MessageType.Error);
                return false;
            }

            if (string.IsNullOrEmpty(m_OutputFolder))
            {
                SetStatus("Please specify an output folder.", MessageType.Error);
                return false;
            }

            return true;
        }

        private void CreateFolderRecursive(string path)
        {
            string[] folders = path.Split('/');
            string currentPath = folders[0];

            for (int i = 1; i < folders.Length; i++)
            {
                string nextPath = currentPath + "/" + folders[i];
                if (!AssetDatabase.IsValidFolder(nextPath))
                {
                    AssetDatabase.CreateFolder(currentPath, folders[i]);
                }
                currentPath = nextPath;
            }
        }

        private void AnalyzeSourceClips()
        {
            if (m_SourceClips == null || m_SourceClips.Length == 0)
            {
                SetStatus("No source clips to analyze.", MessageType.Warning);
                return;
            }

            Debug.Log("=== Animation Clip Analysis ===");
            
            HashSet<string> allPaths = new HashSet<string>();
            HashSet<string> allProperties = new HashSet<string>();

            foreach (var clip in m_SourceClips)
            {
                if (clip == null) continue;

                var bindings = AnimationUtility.GetCurveBindings(clip);
                Debug.Log($"\n{clip.name}: {bindings.Length} curves, {clip.length:F2}s, {(clip.isLooping ? "Looping" : "Once")}");

                foreach (var binding in bindings)
                {
                    allPaths.Add(binding.path);
                    allProperties.Add(binding.propertyName);
                }
            }

            Debug.Log($"\n=== Unique Bone Paths ({allPaths.Count}) ===");
            foreach (var path in allPaths.OrderBy(x => x))
            {
                Debug.Log($"  {path}");
            }

            Debug.Log($"\n=== Animated Properties ({allProperties.Count}) ===");
            foreach (var prop in allProperties.OrderBy(x => x))
            {
                Debug.Log($"  {prop}");
            }

            SetStatus($"Analysis complete. {allPaths.Count} unique paths, {allProperties.Count} properties. Check Console for details.", MessageType.Info);
        }

        private void PreviewMapping()
        {
            if (m_SourceClips == null || m_SourceClips.Length == 0 || m_SourceClips[0] == null)
            {
                SetStatus("No source clips to preview.", MessageType.Warning);
                return;
            }

            Debug.Log("=== Bone Mapping Preview ===");
            
            var clip = m_SourceClips[0];
            var bindings = AnimationUtility.GetCurveBindings(clip);

            foreach (var binding in bindings.Take(20)) // Show first 20
            {
                EditorCurveBinding newBinding = RemapBinding(binding);
                
                string status = binding.path == newBinding.path ? "✓ Unchanged" : "→ Remapped";
                Debug.Log($"{status}: {binding.path} → {newBinding.path}");
            }

            if (bindings.Length > 20)
            {
                Debug.Log($"... and {bindings.Length - 20} more bindings");
            }

            SetStatus("Mapping preview complete. Check Console for details.", MessageType.Info);
        }

        private void SetStatus(string message, MessageType type)
        {
            m_StatusMessage = message;
            m_StatusType = type;
        }
    }
}

