// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Utilities for importing and working with Mixamo rigs
    /// Mixamo uses standardized humanoid bone naming conventions
    /// </summary>
    public static class MixamoRigImporter
    {
        // Mixamo standard bone names (in Unity units - typical character is ~2 units tall)
        private static readonly Dictionary<string, float> s_MixamoBoneRadiusPresets = new Dictionary<string, float>
        {
            // Spine
            { "Hips", 0.25f },
            { "Spine", 0.20f },
            { "Spine1", 0.18f },
            { "Spine2", 0.16f },
            { "Neck", 0.12f },
            { "Head", 0.15f },
            
            // Left Arm
            { "LeftShoulder", 0.10f },
            { "LeftArm", 0.12f },
            { "LeftForeArm", 0.10f },
            { "LeftHand", 0.08f },
            { "LeftHandThumb1", 0.03f },
            { "LeftHandThumb2", 0.025f },
            { "LeftHandThumb3", 0.02f },
            { "LeftHandIndex1", 0.03f },
            { "LeftHandIndex2", 0.025f },
            { "LeftHandIndex3", 0.02f },
            { "LeftHandMiddle1", 0.03f },
            { "LeftHandMiddle2", 0.025f },
            { "LeftHandMiddle3", 0.02f },
            { "LeftHandRing1", 0.03f },
            { "LeftHandRing2", 0.025f },
            { "LeftHandRing3", 0.02f },
            { "LeftHandPinky1", 0.03f },
            { "LeftHandPinky2", 0.025f },
            { "LeftHandPinky3", 0.02f },
            
            // Right Arm
            { "RightShoulder", 0.10f },
            { "RightArm", 0.12f },
            { "RightForeArm", 0.10f },
            { "RightHand", 0.08f },
            { "RightHandThumb1", 0.03f },
            { "RightHandThumb2", 0.025f },
            { "RightHandThumb3", 0.02f },
            { "RightHandIndex1", 0.03f },
            { "RightHandIndex2", 0.025f },
            { "RightHandIndex3", 0.02f },
            { "RightHandMiddle1", 0.03f },
            { "RightHandMiddle2", 0.025f },
            { "RightHandMiddle3", 0.02f },
            { "RightHandRing1", 0.03f },
            { "RightHandRing2", 0.025f },
            { "RightHandRing3", 0.02f },
            { "RightHandPinky1", 0.03f },
            { "RightHandPinky2", 0.025f },
            { "RightHandPinky3", 0.02f },
            
            // Left Leg
            { "LeftUpLeg", 0.18f },
            { "LeftLeg", 0.14f },
            { "LeftFoot", 0.10f },
            { "LeftToeBase", 0.06f },
            
            // Right Leg
            { "RightUpLeg", 0.18f },
            { "RightLeg", 0.14f },
            { "RightFoot", 0.10f },
            { "RightToeBase", 0.06f }
        };

        /// <summary>
        /// Detect if a SkinnedMeshRenderer uses a Mixamo rig
        /// </summary>
        public static bool IsMixamoRig(SkinnedMeshRenderer skinnedMesh)
        {
            if (skinnedMesh == null || skinnedMesh.bones == null) return false;
            
            int mixamoBonesFound = 0;
            foreach (Transform bone in skinnedMesh.bones)
            {
                if (bone != null && s_MixamoBoneRadiusPresets.ContainsKey(bone.name))
                {
                    mixamoBonesFound++;
                }
            }
            
            // If we found at least 5 standard Mixamo bones, consider it a Mixamo rig
            return mixamoBonesFound >= 5;
        }

        /// <summary>
        /// Get optimal bone radius for a Mixamo bone
        /// </summary>
        public static float GetMixamoBoneRadius(string boneName, float multiplier = 1.0f)
        {
            // Mixamo FBXs commonly namespace names as "mixamorig:Hips".
            // Preset lookup previously missed every such bone and used the same
            // fallback radius across the whole skeleton.
            string normalizedName = boneName;
            int namespaceSeparator = normalizedName != null ? normalizedName.LastIndexOf(':') : -1;
            if (namespaceSeparator >= 0 && namespaceSeparator + 1 < normalizedName.Length)
                normalizedName = normalizedName.Substring(namespaceSeparator + 1);

            if (s_MixamoBoneRadiusPresets.TryGetValue(normalizedName, out float radius))
            {
                return radius * multiplier;
            }
            
            // Default radius for unknown bones
            return 0.10f * multiplier;
        }

        /// <summary>
        /// Apply Mixamo bone radius presets to a GaussianSplatRig
        /// </summary>
        public static void ApplyMixamoBoneRadii(GaussianSplatRig rig, float multiplier = 1.0f)
        {
            if (rig == null || rig.bones == null) return;
            
            foreach (GaussianSplatBone bone in rig.bones)
            {
                if (bone == null) continue;
                
                float radius = GetMixamoBoneRadius(bone.name, multiplier);
                bone.radius = radius;
                
                #if UNITY_EDITOR
                EditorUtility.SetDirty(bone);
                #endif
            }
        }

        /// <summary>
        /// Extract animations from Mixamo FBX file
        /// </summary>
        public static AnimationClip[] GetAnimationsFromMixamoFBX(string fbxPath)
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(fbxPath);
            List<AnimationClip> clips = new List<AnimationClip>();
            
            foreach (Object asset in assets)
            {
                if (asset is AnimationClip clip && !clip.name.Contains("__preview__"))
                {
                    clips.Add(clip);
                }
            }
            
            return clips.ToArray();
        }

        /// <summary>
        /// Get recommended settings for Mixamo character conversion
        /// </summary>
        public static MixamoConversionSettings GetRecommendedSettings(SkinnedMeshRenderer skinnedMesh)
        {
            if (skinnedMesh == null) return new MixamoConversionSettings();
            
            Mesh mesh = skinnedMesh.sharedMesh;
            if (mesh == null) return new MixamoConversionSettings();
            
            // Analyze mesh complexity
            int vertexCount = mesh.vertexCount;
            float meshBounds = mesh.bounds.size.magnitude;
            
            MixamoConversionSettings settings = new MixamoConversionSettings();
            
            // Adjust based on mesh complexity
            if (vertexCount < 5000)
            {
                // Low poly - use vertices
                settings.samplingMode = MixamoConversionSettings.SamplingMode.Vertices;
                settings.splatScale = 0.015f;
                settings.boneRadiusMultiplier = 1.2f;
            }
            else if (vertexCount < 15000)
            {
                // Medium poly - uniform surface with medium density
                settings.samplingMode = MixamoConversionSettings.SamplingMode.UniformSurface;
                settings.surfaceSampleDensity = 0.05f;
                settings.splatScale = 0.01f;
                settings.boneRadiusMultiplier = 1.0f;
            }
            else
            {
                // High poly - uniform surface with lower density
                settings.samplingMode = MixamoConversionSettings.SamplingMode.UniformSurface;
                settings.surfaceSampleDensity = 0.08f;
                settings.splatScale = 0.008f;
                settings.boneRadiusMultiplier = 0.8f;
            }
            
            // Adjust bone radius based on mesh scale
            if (meshBounds < 2f)
            {
                settings.boneRadiusMultiplier *= 1.2f; // Small character
            }
            else if (meshBounds > 10f)
            {
                settings.boneRadiusMultiplier *= 1.5f; // Large character
            }
            
            return settings;
        }

        /// <summary>
        /// Create a humanoid avatar from Mixamo rig for better animation compatibility
        /// </summary>
        public static Avatar CreateMixamoAvatar(GameObject rigRoot)
        {
            if (rigRoot == null) return null;
            
            // Try to find existing avatar in the source
            var skinnedMesh = rigRoot.GetComponentInChildren<SkinnedMeshRenderer>();
            if (skinnedMesh != null)
            {
                var animator = skinnedMesh.GetComponent<Animator>();
                if (animator != null && animator.avatar != null)
                {
                    return animator.avatar;
                }
            }
            
            return null;
        }

        /// <summary>
        /// Setup animator with Mixamo animations
        /// </summary>
        public static void SetupMixamoAnimator(GameObject target, RuntimeAnimatorController controller, Avatar avatar = null)
        {
            if (target == null) return;
            
            Animator animator = target.GetComponent<Animator>();
            if (animator == null)
            {
                animator = target.AddComponent<Animator>();
            }
            
            animator.runtimeAnimatorController = controller;
            
            if (avatar != null)
            {
                animator.avatar = avatar;
            }
            
            // Mixamo animations work best with these settings
            animator.applyRootMotion = true;
            animator.updateMode = AnimatorUpdateMode.Normal;
            animator.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
        }

        /// <summary>
        /// Get common Mixamo bone names for validation
        /// </summary>
        public static string[] GetMixamoCoreBonesNames()
        {
            return new string[]
            {
                "Hips", "Spine", "Spine1", "Spine2", "Neck", "Head",
                "LeftShoulder", "LeftArm", "LeftForeArm", "LeftHand",
                "RightShoulder", "RightArm", "RightForeArm", "RightHand",
                "LeftUpLeg", "LeftLeg", "LeftFoot",
                "RightUpLeg", "RightLeg", "RightFoot"
            };
        }

        /// <summary>
        /// Validate Mixamo rig has all core bones
        /// </summary>
        public static bool ValidateMixamoRig(SkinnedMeshRenderer skinnedMesh, out List<string> missingBones)
        {
            missingBones = new List<string>();
            if (skinnedMesh == null || skinnedMesh.bones == null) return false;
            
            HashSet<string> boneNames = new HashSet<string>();
            foreach (Transform bone in skinnedMesh.bones)
            {
                if (bone != null)
                {
                    boneNames.Add(bone.name);
                }
            }
            
            string[] coreNames = GetMixamoCoreBonesNames();
            foreach (string coreBone in coreNames)
            {
                if (!boneNames.Contains(coreBone))
                {
                    missingBones.Add(coreBone);
                }
            }
            
            return missingBones.Count == 0;
        }
    }

    /// <summary>
    /// Settings for converting Mixamo characters
    /// </summary>
    [System.Serializable]
    public class MixamoConversionSettings
    {
        public enum SamplingMode
        {
            Vertices,
            TriangleCenters,
            UniformSurface
        }
        
        public SamplingMode samplingMode = SamplingMode.UniformSurface;
        public float surfaceSampleDensity = 0.05f;
        public int triangleSamplesPerFace = 3;
        public float splatScale = 0.01f;
        public float splatOpacity = 1.0f;
        public float boneRadiusMultiplier = 1.0f;
        public float boneFalloff = 0.5f;
        public bool transferWeights = true;
        public bool setupAnimator = true;
        public bool optimizeForMixamo = true;
    }
}

