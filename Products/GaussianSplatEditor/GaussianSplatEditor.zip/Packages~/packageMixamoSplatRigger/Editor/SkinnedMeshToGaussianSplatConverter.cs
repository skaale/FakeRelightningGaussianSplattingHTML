// SPDX-License-Identifier: MIT

using System;
using System.IO;
using System.Collections.Generic;
using GaussianSplatting.Runtime;
using Unity.Burst;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;
using UnityEngine.Experimental.Rendering;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Editor
{
    public class SkinnedMeshToGaussianSplatConverter : EditorWindow
    {
        const string kProgressTitle = "Converting Skinned Mesh to Gaussian Splats";

        [SerializeField] SkinnedMeshRenderer m_SourceSkinnedMesh;
        [SerializeField] string m_OutputFolder = "Assets/GaussianAssets";
        
        [Header("Sampling Settings")]
        [SerializeField] SamplingMode m_SamplingMode = SamplingMode.Vertices;
        [SerializeField] int m_TriangleSamplesPerFace = 3;
        [SerializeField] float m_SurfaceSampleDensity = 0.05f;
        [SerializeField] bool m_UseTargetSplatCount = true;
        [SerializeField] int m_TargetSplatCount = 1000000;
        
        [Header("Splat Settings")]
        [SerializeField] float m_SplatScale = 0.01f;
        [SerializeField] bool m_AutoSurfaceScale = true;
        [SerializeField] [Range(0.5f, 2.5f)] float m_SurfaceScaleMultiplier = 1.25f;
        [SerializeField] [Range(0.02f, 0.5f)] float m_SurfaceThickness = 0.12f;
        [SerializeField] float m_SplatOpacity = 1.0f;
        [SerializeField] bool m_UseVertexColors = false;
        [SerializeField] bool m_SampleTexture = true;
        [SerializeField] int m_TextureSamplingResolution = 8192;
        [SerializeField] Color m_DefaultColor = Color.white;
        
        [Header("Bone/Rigging Settings")]
        [SerializeField] bool m_CreateRig = true;
        [SerializeField] bool m_AutoBoneSettings = true;
        [SerializeField] float m_BoneRadiusMultiplier = 1.0f;
        [SerializeField] float m_BoneFalloff = 0.5f;
        [SerializeField] bool m_TransferWeights = true;
        
        [Header("Mixamo Support")]
        [SerializeField] bool m_IsMixamoRig = false;
        [SerializeField] bool m_AutoDetectMixamo = true;
        [SerializeField] bool m_UseMixamoPresets = true;
        
        [Header("Animation Settings")]
        [SerializeField] bool m_SetupAnimator = true;
        [SerializeField] RuntimeAnimatorController m_AnimatorController;
        
        [Header("Quality")]
        [SerializeField] DataQuality m_Quality = DataQuality.VeryHigh;
        [SerializeField] GaussianSplatAsset.VectorFormat m_FormatPos = GaussianSplatAsset.VectorFormat.Float32;
        [SerializeField] GaussianSplatAsset.VectorFormat m_FormatScale = GaussianSplatAsset.VectorFormat.Float32;
        [SerializeField] GaussianSplatAsset.ColorFormat m_FormatColor = GaussianSplatAsset.ColorFormat.Float32x4;
        [SerializeField] GaussianSplatAsset.SHFormat m_FormatSH = GaussianSplatAsset.SHFormat.Float32;
        
        enum DataQuality
        {
            VeryHigh,
            High,
            Medium,
            Low,
            VeryLow,
            Custom,
        }
        
        [Header("Scene Placement")]
        [SerializeField] bool m_CreateInScene = true;
        [SerializeField] string m_GameObjectName = "Animated Gaussian Splat";
        
        enum SamplingMode
        {
            Vertices,
            TriangleCenters,
            UniformSurface
        }
        
        string m_ErrorMessage;
        int m_EstimatedSplatCount;
        Vector2 m_ScrollPosition;
        
        struct AutoBoneSettings
        {
            public float radiusMultiplier;
            public float falloff;
        }
        
        struct SplatBoneWeight
        {
            public Vector4 boneIndices;
            public Vector4 boneWeights;
        }
        
        Dictionary<int, SplatBoneWeight> m_SplatWeights;
        List<MixamoSplatUvData.SplatMeshUv> m_SplatUvs;
        Texture m_SourceAlbedoTexture;
        
        bool isUsingChunks =>
            m_FormatPos != GaussianSplatAsset.VectorFormat.Float32 ||
            m_FormatScale != GaussianSplatAsset.VectorFormat.Float32 ||
            m_FormatColor != GaussianSplatAsset.ColorFormat.Float32x4 ||
            m_FormatSH != GaussianSplatAsset.SHFormat.Float32;

        [MenuItem("Tools/Gaussian Splats/Convert Skinned Mesh to Animated Splats")]
        public static void ShowWindow()
        {
            var window = GetWindow<SkinnedMeshToGaussianSplatConverter>("Skinned Mesh to Splats");
            window.minSize = new Vector2(450, 700);
            window.Show();
        }

        void OnGUI()
        {
            m_ScrollPosition = EditorGUILayout.BeginScrollView(m_ScrollPosition);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Skinned Mesh to Animated Gaussian Splats", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Convert Unity SkinnedMeshRenderer with animations to animated Gaussian splats", MessageType.Info);
            EditorGUILayout.HelpBox("⚠ IMPORTANT: Source character MUST be in T-POSE (bind pose) before converting!\nAnimations are applied after conversion.", MessageType.Warning);
            EditorGUILayout.Space();
            
            EditorGUILayout.LabelField("Source", EditorStyles.boldLabel);
            m_SourceSkinnedMesh = (SkinnedMeshRenderer)EditorGUILayout.ObjectField("Skinned Mesh", m_SourceSkinnedMesh, typeof(SkinnedMeshRenderer), true);
            
            if (m_SourceSkinnedMesh != null && m_SourceSkinnedMesh.sharedMesh != null)
            {
                // Auto-detect Mixamo rig
                if (m_AutoDetectMixamo)
                {
                    bool isMixamo = MixamoRigImporter.IsMixamoRig(m_SourceSkinnedMesh);
                    if (isMixamo != m_IsMixamoRig)
                    {
                        m_IsMixamoRig = isMixamo;
                        if (isMixamo && m_UseMixamoPresets)
                        {
                            ApplyMixamoRecommendedSettings();
                        }
                    }
                }
                
                UpdateEstimatedSplatCount();
                EditorGUILayout.LabelField("Mesh Info", $"{m_SourceSkinnedMesh.sharedMesh.vertexCount:N0} vertices, {m_SourceSkinnedMesh.bones.Length} bones");
                EditorGUILayout.LabelField("Estimated Splats", $"{m_EstimatedSplatCount:N0}");
                
                // Show Mixamo detection
                if (m_IsMixamoRig)
                {
                    EditorGUILayout.HelpBox("✓ Mixamo rig detected! Using optimized settings.", MessageType.Info);
                }
                
                // Show bone info
                if (m_SourceSkinnedMesh.bones.Length > 0)
                {
                    EditorGUILayout.LabelField("Bones", $"{m_SourceSkinnedMesh.bones.Length} bones in hierarchy");
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Sampling", EditorStyles.boldLabel);
            m_SamplingMode = (SamplingMode)EditorGUILayout.EnumPopup("Sampling Mode", m_SamplingMode);
            
            if (m_SamplingMode == SamplingMode.TriangleCenters)
            {
                m_TriangleSamplesPerFace = EditorGUILayout.IntSlider("Samples Per Triangle", m_TriangleSamplesPerFace, 1, 10);
            }
            else if (m_SamplingMode == SamplingMode.UniformSurface)
            {
                m_UseTargetSplatCount = EditorGUILayout.Toggle("Target Texture Density", m_UseTargetSplatCount);
                if (m_UseTargetSplatCount)
                {
                    int[] splatTargets = { 250000, 500000, 1000000, 2000000 };
                    string[] splatTargetLabels = { "250K", "500K", "1 Million", "2 Million" };
                    int selectedTarget = System.Array.IndexOf(splatTargets, m_TargetSplatCount);
                    if (selectedTarget < 0) selectedTarget = 2;
                    selectedTarget = EditorGUILayout.Popup("Target Splats", selectedTarget, splatTargetLabels);
                    m_TargetSplatCount = splatTargets[selectedTarget];
                    if (m_TargetSplatCount >= 2000000)
                        EditorGUILayout.HelpBox(
                            "2 million splats provides higher texture density but requires substantially more conversion and runtime memory.",
                            MessageType.Warning);
                }
                else
                {
                    m_SurfaceSampleDensity = EditorGUILayout.Slider("Sample Spacing", m_SurfaceSampleDensity, 0.002f, 0.2f);
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Splat Properties", EditorStyles.boldLabel);
            m_AutoSurfaceScale = EditorGUILayout.Toggle(
                new GUIContent("Auto Surface Scale", "Derive each splat footprint from the mesh area it covers."),
                m_AutoSurfaceScale);
            if (m_AutoSurfaceScale)
            {
                m_SurfaceScaleMultiplier = EditorGUILayout.Slider("Coverage Multiplier", m_SurfaceScaleMultiplier, 0.5f, 2.5f);
                m_SurfaceThickness = EditorGUILayout.Slider("Surface Thickness", m_SurfaceThickness, 0.02f, 0.5f);
            }
            else
            {
                m_SplatScale = EditorGUILayout.Slider("Splat Scale", m_SplatScale, 0.001f, 0.1f);
            }
            m_SplatOpacity = EditorGUILayout.Slider("Opacity", m_SplatOpacity, 0f, 1f);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Color Source", EditorStyles.boldLabel);
            m_SampleTexture = EditorGUILayout.Toggle("Sample from Texture", m_SampleTexture);
            if (m_SampleTexture)
            {
                int[] textureSizes = { 1024, 2048, 4096, 8192 };
                string[] textureSizeLabels = { "1K", "2K", "4K", "8K" };
                int selectedSize = System.Array.IndexOf(textureSizes, m_TextureSamplingResolution);
                if (selectedSize < 0) selectedSize = textureSizes.Length - 1;
                selectedSize = EditorGUILayout.Popup("Texture Sampling", selectedSize, textureSizeLabels);
                m_TextureSamplingResolution = textureSizes[selectedSize];
                EditorGUILayout.HelpBox(
                    "8K is sampled live on each splat at render time. A baked splat color cannot hold 8K detail — reconvert to generate UVs.",
                    MessageType.Info);
            }
            m_UseVertexColors = EditorGUILayout.Toggle("Use Vertex Colors", m_UseVertexColors);
            
            if (!m_SampleTexture && !m_UseVertexColors)
            {
                m_DefaultColor = EditorGUILayout.ColorField("Default Color", m_DefaultColor);
            }
            
            if (m_SampleTexture && m_SourceSkinnedMesh != null)
            {
                Material mat = m_SourceSkinnedMesh.sharedMaterial;
                if (mat != null)
                {
                    Texture tex = mat.GetTexture("_MainTex") ?? mat.GetTexture("_BaseMap") ?? mat.GetTexture("_BaseColorMap");
                    if (tex != null)
                    {
                        EditorGUILayout.HelpBox($"✓ Will sample from texture: {tex.name}", MessageType.Info);
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("⚠ No texture found on material. Will use default color.", MessageType.Warning);
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("⚠ No material assigned to SkinnedMeshRenderer.", MessageType.Warning);
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Rigging & Animation", EditorStyles.boldLabel);
            
            // Mixamo options
            EditorGUILayout.BeginHorizontal();
            m_AutoDetectMixamo = EditorGUILayout.Toggle("Auto-Detect Mixamo", m_AutoDetectMixamo);
            if (!m_AutoDetectMixamo)
            {
                m_IsMixamoRig = EditorGUILayout.Toggle("Is Mixamo", m_IsMixamoRig);
            }
            EditorGUILayout.EndHorizontal();
            
            if (m_IsMixamoRig)
            {
                EditorGUI.indentLevel++;
                m_UseMixamoPresets = EditorGUILayout.Toggle("Use Mixamo Presets", m_UseMixamoPresets);
                if (GUILayout.Button("Apply Mixamo Recommended Settings"))
                {
                    ApplyMixamoRecommendedSettings();
                }
                EditorGUI.indentLevel--;
            }
            
            m_CreateRig = EditorGUILayout.Toggle("Create Rig", m_CreateRig);
            
            if (m_CreateRig)
            {
                EditorGUI.indentLevel++;
                m_AutoBoneSettings = EditorGUILayout.Toggle("Auto Bone Settings", m_AutoBoneSettings);
                
                if (m_AutoBoneSettings)
                {
                    EditorGUILayout.HelpBox("✓ Bone radius and falloff calculated automatically based on mesh size and sampling density", MessageType.Info);
                    
                    // Show calculated values (read-only)
                    if (m_SourceSkinnedMesh != null)
                    {
                        var autoSettings = CalculateAutoBoneSettings();
                        EditorGUI.BeginDisabledGroup(true);
                        EditorGUILayout.FloatField("Auto Radius Multiplier", autoSettings.radiusMultiplier);
                        EditorGUILayout.FloatField("Auto Falloff", autoSettings.falloff);
                        EditorGUI.EndDisabledGroup();
                    }
                }
                else
                {
                    m_BoneRadiusMultiplier = EditorGUILayout.Slider("Bone Radius Multiplier", m_BoneRadiusMultiplier, 0.5f, 20f);
                    EditorGUILayout.HelpBox("Larger radius = more splats influenced by each bone", MessageType.Info);
                    m_BoneFalloff = EditorGUILayout.Slider("Bone Falloff", m_BoneFalloff, 0f, 1f);
                }
                
                m_TransferWeights = EditorGUILayout.Toggle("Transfer Bone Weights", m_TransferWeights);
                EditorGUI.indentLevel--;
            }
            
            m_SetupAnimator = EditorGUILayout.Toggle("Setup Animator", m_SetupAnimator);
            if (m_SetupAnimator)
            {
                EditorGUI.indentLevel++;
                m_AnimatorController = (RuntimeAnimatorController)EditorGUILayout.ObjectField("Animator Controller", m_AnimatorController, typeof(RuntimeAnimatorController), false);
                if (m_AnimatorController == null && m_SourceSkinnedMesh != null)
                {
                    var animator = m_SourceSkinnedMesh.GetComponent<Animator>();
                    if (animator != null)
                    {
                        m_AnimatorController = animator.runtimeAnimatorController;
                        EditorGUILayout.HelpBox($"Auto-detected: {m_AnimatorController?.name}", MessageType.Info);
                    }
                }
                EditorGUI.indentLevel--;
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Output", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            m_OutputFolder = EditorGUILayout.TextField("Output Folder", m_OutputFolder);
            if (GUILayout.Button("Browse", GUILayout.Width(60)))
            {
                string path = EditorUtility.OpenFolderPanel("Select Output Folder", m_OutputFolder, "");
                if (!string.IsNullOrEmpty(path))
                {
                    if (path.StartsWith(Application.dataPath))
                    {
                        m_OutputFolder = "Assets" + path.Substring(Application.dataPath.Length);
                    }
                }
            }
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Data Quality", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("VeryHigh quality recommended for best visual fidelity (larger file size)", MessageType.Info);
            
            var newQuality = (DataQuality)EditorGUILayout.EnumPopup("Quality Preset", m_Quality);
            if (newQuality != m_Quality)
            {
                m_Quality = newQuality;
                ApplyQualityPreset();
            }
            
            EditorGUI.BeginDisabledGroup(m_Quality != DataQuality.Custom);
            EditorGUI.indentLevel++;
            m_FormatPos = (GaussianSplatAsset.VectorFormat)EditorGUILayout.EnumPopup("Position", m_FormatPos);
            m_FormatScale = (GaussianSplatAsset.VectorFormat)EditorGUILayout.EnumPopup("Scale", m_FormatScale);
            m_FormatColor = (GaussianSplatAsset.ColorFormat)EditorGUILayout.EnumPopup("Color", m_FormatColor);
            m_FormatSH = (GaussianSplatAsset.SHFormat)EditorGUILayout.EnumPopup("SH", m_FormatSH);
            EditorGUI.indentLevel--;
            EditorGUI.EndDisabledGroup();
            
            // Show quality impact
            if (m_EstimatedSplatCount > 0)
            {
                string qualityInfo = GetQualityInfo();
                EditorGUILayout.HelpBox(qualityInfo, MessageType.None);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Scene Placement", EditorStyles.boldLabel);
            m_CreateInScene = EditorGUILayout.Toggle("Create in Scene", m_CreateInScene);
            if (m_CreateInScene)
            {
                m_GameObjectName = EditorGUILayout.TextField("GameObject Name", m_GameObjectName);
            }
            
            EditorGUILayout.Space();
            if (!string.IsNullOrEmpty(m_ErrorMessage))
            {
                EditorGUILayout.HelpBox(m_ErrorMessage, MessageType.Error);
            }
            
            EditorGUI.BeginDisabledGroup(m_SourceSkinnedMesh == null || m_SourceSkinnedMesh.sharedMesh == null);
            if (GUILayout.Button("Convert to Animated Gaussian Splats", GUILayout.Height(40)))
            {
                ConvertSkinnedMesh();
            }
            EditorGUI.EndDisabledGroup();
            
            EditorGUILayout.EndScrollView();
        }

        void UpdateEstimatedSplatCount()
        {
            if (m_SourceSkinnedMesh == null || m_SourceSkinnedMesh.sharedMesh == null)
            {
                m_EstimatedSplatCount = 0;
                return;
            }
            
            var mesh = m_SourceSkinnedMesh.sharedMesh;
            
            switch (m_SamplingMode)
            {
                case SamplingMode.Vertices:
                    m_EstimatedSplatCount = mesh.vertexCount;
                    break;
                case SamplingMode.TriangleCenters:
                    m_EstimatedSplatCount = (mesh.triangles.Length / 3) * m_TriangleSamplesPerFace;
                    break;
                case SamplingMode.UniformSurface:
                    if (m_UseTargetSplatCount)
                    {
                        m_EstimatedSplatCount = m_TargetSplatCount;
                    }
                    else
                    {
                        float area = CalculateMeshSurfaceArea(mesh);
                        m_EstimatedSplatCount = Mathf.CeilToInt(area / (m_SurfaceSampleDensity * m_SurfaceSampleDensity));
                    }
                    break;
            }
        }

        float CalculateMeshSurfaceArea(Mesh mesh)
        {
            Vector3[] vertices = mesh.vertices;
            int[] triangles = mesh.triangles;
            float totalArea = 0f;
            
            for (int i = 0; i < triangles.Length; i += 3)
            {
                Vector3 a = vertices[triangles[i]];
                Vector3 b = vertices[triangles[i + 1]];
                Vector3 c = vertices[triangles[i + 2]];
                totalArea += Vector3.Cross(b - a, c - a).magnitude * 0.5f;
            }
            
            return totalArea;
        }

        void ConvertSkinnedMesh()
        {
            m_ErrorMessage = null;
            
            if (m_SourceSkinnedMesh == null || m_SourceSkinnedMesh.sharedMesh == null)
            {
                m_ErrorMessage = "Please select a skinned mesh renderer";
                return;
            }
            
            if (string.IsNullOrWhiteSpace(m_OutputFolder) || !m_OutputFolder.StartsWith("Assets/"))
            {
                m_ErrorMessage = $"Output folder must be within project, was '{m_OutputFolder}'";
                return;
            }
            
            Directory.CreateDirectory(m_OutputFolder);
            
            EditorUtility.DisplayProgressBar(kProgressTitle, "Sampling mesh...", 0.1f);
            
            m_SplatWeights = new Dictionary<int, SplatBoneWeight>();
            m_SplatUvs = new List<MixamoSplatUvData.SplatMeshUv>();
            m_SourceAlbedoTexture = null;
            NativeArray<GaussianSplatAssetCreator.InputSplatData> splatData = default;
            
            try
            {
                splatData = SampleSkinnedMesh();
                
                if (splatData.Length == 0)
                {
                    EditorUtility.ClearProgressBar();
                    m_ErrorMessage = "No splats generated from mesh";
                    return;
                }

                // Bake the FBX axis correction into the generated data so the
                // resulting character root can stay at rotation (0,0,0).
                Quaternion sourceRotation = m_SourceSkinnedMesh.transform.rotation;
                for (int i = 0; i < splatData.Length; i++)
                {
                    var splat = splatData[i];
                    splat.pos = sourceRotation * splat.pos;
                    splat.nor = sourceRotation * splat.nor;
                    splat.rot = sourceRotation * splat.rot;

                    // CreateOtherDataJob writes a packed 10:10:10:2 rotation. Its
                    // input must already be SplatBox's normalized smallest-three
                    // representation, not a signed Unity quaternion.
                    Quaternion q = splat.rot.normalized;
                    float4 packedRotation = GaussianUtils.PackSmallest3Rotation(
                        new float4(q.x, q.y, q.z, q.w));
                    splat.rot = new Quaternion(
                        packedRotation.x,
                        packedRotation.y,
                        packedRotation.z,
                        packedRotation.w);
                    splatData[i] = splat;
                }
            }
            catch (System.Exception e)
            {
                if (splatData.IsCreated)
                    splatData.Dispose();
                EditorUtility.ClearProgressBar();
                m_ErrorMessage = $"Error sampling mesh: {e.Message}";
                return;
            }
            
            EditorUtility.DisplayProgressBar(kProgressTitle, "Calculating bounds...", 0.3f);
            
            float3 boundsMin, boundsMax;
            unsafe
            {
                var boundsJob = new CalcBoundsJob
                {
                    m_BoundsMin = &boundsMin,
                    m_BoundsMax = &boundsMax,
                    m_SplatData = splatData
                };
                boundsJob.Schedule().Complete();
            }
            
            EditorUtility.DisplayProgressBar(kProgressTitle, "Creating asset...", 0.5f);
            
            string baseName = m_SourceSkinnedMesh.gameObject.name + "_splat";
            GaussianSplatAsset asset = null;
            
            try
            {
                asset = CreateAssetFromSplats(splatData, baseName, boundsMin, boundsMax);
            }
            finally
            {
                // Always dispose native array to prevent memory leak
                if (splatData.IsCreated)
                    splatData.Dispose();
                EditorUtility.ClearProgressBar();
            }
            
            if (asset != null)
            {
                Selection.activeObject = asset;
                
                if (m_CreateInScene)
                {
                    CreateAnimatedSplatInScene(asset);
                }
            }
            
            m_SplatWeights = null;
            m_SplatUvs = null;
        }

        NativeArray<GaussianSplatAssetCreator.InputSplatData> SampleSkinnedMesh()
        {
            // Get base mesh data
            Mesh mesh = m_SourceSkinnedMesh.sharedMesh;
            Vector2[] uvs = null;
            Texture2D mainTexture = null;
            int[] triangles = mesh.triangles;
            BoneWeight[] boneWeights = mesh.boneWeights;
            
            // Bake mesh in CURRENT state (should be T-pose) to get actual vertex positions
            Mesh bakedMesh = new Mesh();
            m_SourceSkinnedMesh.BakeMesh(bakedMesh);
            
            Vector3[] vertices = bakedMesh.vertices;
            Vector3[] normals = bakedMesh.normals;
            Color[] colors = m_UseVertexColors ? bakedMesh.colors : null;
            
            if (normals == null || normals.Length == 0)
            {
                bakedMesh.RecalculateNormals();
                normals = bakedMesh.normals;
            }
            
            // Get texture if sampling enabled
            if (m_SampleTexture && m_SourceSkinnedMesh.sharedMaterial != null)
            {
                Material mat = m_SourceSkinnedMesh.sharedMaterial;
                mainTexture = mat.GetTexture("_MainTex") as Texture2D;
                if (mainTexture == null)
                    mainTexture = mat.GetTexture("_BaseMap") as Texture2D;
                if (mainTexture == null)
                    mainTexture = mat.GetTexture("_BaseColor") as Texture2D;
                if (mainTexture == null)
                    mainTexture = mat.GetTexture("_BaseColorMap") as Texture2D;
                
                if (mainTexture != null)
                {
                    uvs = bakedMesh.uv;
                    if (uvs != null && uvs.Length > 0)
                    {
                        string texturePath = AssetDatabase.GetAssetPath(mainTexture);
                        if (!string.IsNullOrEmpty(texturePath))
                        {
                            TextureImporter importer = AssetImporter.GetAtPath(texturePath) as TextureImporter;
                            if (importer != null)
                            {
                                bool importChanged = false;
                                if (!importer.isReadable)
                                {
                                    importer.isReadable = true;
                                    importChanged = true;
                                }
                                if (importer.maxTextureSize < m_TextureSamplingResolution)
                                {
                                    importer.maxTextureSize = m_TextureSamplingResolution;
                                    importChanged = true;
                                }

                                if (importChanged)
                                {
                                    importer.SaveAndReimport();
                                    mainTexture = AssetDatabase.LoadAssetAtPath<Texture2D>(texturePath);
                                }
                            }
                        }

                        m_SourceAlbedoTexture = mainTexture;
                        if (mainTexture != null &&
                            mainTexture.width < m_TextureSamplingResolution &&
                            mainTexture.height < m_TextureSamplingResolution)
                        {
                            Debug.LogWarning(
                                $"[Skinned Mesh to Splats] Requested {m_TextureSamplingResolution}px texture sampling, " +
                                $"but '{mainTexture.name}' imported at {mainTexture.width}x{mainTexture.height}. " +
                                "The source image may be smaller or constrained by platform import settings.");
                        }
                    }
                    else
                    {
                        mainTexture = null;
                    }
                }
            }
            
            NativeArray<GaussianSplatAssetCreator.InputSplatData> splats;
            
            switch (m_SamplingMode)
            {
                case SamplingMode.Vertices:
                    splats = SampleVertices(vertices, normals, triangles, colors, uvs, mainTexture, boneWeights);
                    break;
                case SamplingMode.TriangleCenters:
                    splats = SampleTriangleCenters(vertices, normals, triangles, colors, uvs, mainTexture, boneWeights);
                    break;
                case SamplingMode.UniformSurface:
                    splats = SampleUniformSurface(vertices, normals, triangles, colors, uvs, mainTexture, boneWeights);
                    break;
                default:
                    splats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(0, Allocator.Temp);
                    break;
            }
            
            // Clean up baked mesh
            UnityEngine.Object.DestroyImmediate(bakedMesh);
            
            return splats;
        }

        NativeArray<GaussianSplatAssetCreator.InputSplatData> SampleVertices(Vector3[] vertices, Vector3[] normals, int[] triangles, Color[] colors, Vector2[] uvs, Texture2D texture, BoneWeight[] boneWeights)
        {
            var splats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(vertices.Length, Allocator.Persistent);
            float[] vertexAreas = null;
            int[] vertexTriangle = new int[vertices.Length];
            for (int i = 0; i < vertexTriangle.Length; i++)
                vertexTriangle[i] = -1;
            if (m_AutoSurfaceScale || (uvs != null && uvs.Length == vertices.Length))
            {
                vertexAreas = m_AutoSurfaceScale ? new float[vertices.Length] : null;
                for (int t = 0; t + 2 < triangles.Length; t += 3)
                {
                    int i0 = triangles[t];
                    int i1 = triangles[t + 1];
                    int i2 = triangles[t + 2];
                    if (vertexTriangle[i0] < 0) vertexTriangle[i0] = t;
                    if (vertexTriangle[i1] < 0) vertexTriangle[i1] = t;
                    if (vertexTriangle[i2] < 0) vertexTriangle[i2] = t;
                    if (vertexAreas == null)
                        continue;
                    float thirdArea = Vector3.Cross(
                        vertices[i1] - vertices[i0],
                        vertices[i2] - vertices[i0]).magnitude / 6f;
                    vertexAreas[i0] += thirdArea;
                    vertexAreas[i1] += thirdArea;
                    vertexAreas[i2] += thirdArea;
                }
            }
            
            for (int i = 0; i < vertices.Length; i++)
            {
                Color color = GetColorForVertex(i, colors, uvs, texture);
                float scale = m_AutoSurfaceScale
                    ? CalculateSurfaceScale(vertexAreas[i])
                    : m_SplatScale;
                splats[i] = CreateSplatFromPoint(vertices[i], normals[i], color, scale);

                if (uvs != null && i < uvs.Length && vertexTriangle[i] >= 0)
                {
                    int t = vertexTriangle[i];
                    int i0 = triangles[t];
                    int i1 = triangles[t + 1];
                    int i2 = triangles[t + 2];
                    StoreSplatUv(
                        i,
                        uvs[i],
                        vertices[i0], vertices[i1], vertices[i2],
                        uvs[i0], uvs[i1], uvs[i2],
                        splats[i].rot,
                        scale);
                }
                
                if (m_TransferWeights && boneWeights != null && i < boneWeights.Length)
                {
                    StoreBoneWeight(i, boneWeights[i]);
                }
            }
            
            return splats;
        }
        
        Color GetColorForVertex(int index, Color[] colors, Vector2[] uvs, Texture2D texture)
        {
            // Priority 1: Vertex colors (if enabled)
            if (m_UseVertexColors && colors != null && index < colors.Length)
                return colors[index];
            
            // Priority 2: Sample from texture (if enabled)
            if (m_SampleTexture && texture != null && uvs != null && index < uvs.Length)
            {
                try
                {
                    Vector2 uv = uvs[index];
                    // Bilinear sampling avoids nearest-texel noise and preserves
                    // gradients from high-resolution source textures.
                    return texture.GetPixelBilinear(uv.x, uv.y);
                }
                catch (System.Exception)
                {
                }
            }
            
            // Priority 3: Default color
            return m_DefaultColor;
        }
        
        NativeArray<GaussianSplatAssetCreator.InputSplatData> SampleTriangleCenters(Vector3[] vertices, Vector3[] normals, int[] triangles, Color[] colors, Vector2[] uvs, Texture2D texture, BoneWeight[] boneWeights)
        {
            int triangleCount = triangles.Length / 3;
            int totalSamples = triangleCount * m_TriangleSamplesPerFace;
            var splats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(totalSamples, Allocator.Persistent);
            
            int splatIndex = 0;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int i0 = triangles[i];
                int i1 = triangles[i + 1];
                int i2 = triangles[i + 2];
                
                Vector3 v0 = vertices[i0];
                Vector3 v1 = vertices[i1];
                Vector3 v2 = vertices[i2];
                
                Vector3 n0 = normals[i0];
                Vector3 n1 = normals[i1];
                Vector3 n2 = normals[i2];
                
                Color c0 = GetColorForVertex(i0, colors, uvs, texture);
                Color c1 = GetColorForVertex(i1, colors, uvs, texture);
                Color c2 = GetColorForVertex(i2, colors, uvs, texture);
                float triangleArea = Vector3.Cross(v1 - v0, v2 - v0).magnitude * 0.5f;
                float surfaceScale = m_AutoSurfaceScale
                    ? CalculateSurfaceScale(triangleArea / m_TriangleSamplesPerFace)
                    : m_SplatScale;
                
                for (int s = 0; s < m_TriangleSamplesPerFace; s++)
                {
                    GenerateBarycentricSample(
                        s,
                        m_TriangleSamplesPerFace,
                        i / 3,
                        out float r3,
                        out float r1,
                        out float r2);
                    
                    Vector3 pos = v0 * r3 + v1 * r1 + v2 * r2;
                    Vector3 normal = (n0 * r3 + n1 * r1 + n2 * r2).normalized;
                    Color color = c0 * r3 + c1 * r1 + c2 * r2;
                    
                    splats[splatIndex] = CreateSplatFromPoint(pos, normal, color, surfaceScale);
                    if (uvs != null && uvs.Length > Mathf.Max(i0, Mathf.Max(i1, i2)))
                    {
                        Vector2 uv = uvs[i0] * r3 + uvs[i1] * r1 + uvs[i2] * r2;
                        StoreSplatUv(
                            splatIndex,
                            uv,
                            v0, v1, v2,
                            uvs[i0], uvs[i1], uvs[i2],
                            splats[splatIndex].rot,
                            surfaceScale);
                    }
                    
                    if (m_TransferWeights && boneWeights != null)
                    {
                        BoneWeight blendedWeight = BlendBoneWeights(boneWeights[i0], boneWeights[i1], boneWeights[i2], r3, r1, r2);
                        StoreBoneWeight(splatIndex, blendedWeight);
                    }
                    
                    splatIndex++;
                }
            }
            
            return splats;
        }

        NativeArray<GaussianSplatAssetCreator.InputSplatData> SampleUniformSurface(Vector3[] vertices, Vector3[] normals, int[] triangles, Color[] colors, Vector2[] uvs, Texture2D texture, BoneWeight[] boneWeights)
        {
            var tempSplats = new System.Collections.Generic.List<GaussianSplatAssetCreator.InputSplatData>();
            float totalSurfaceArea = 0f;
            if (m_UseTargetSplatCount)
            {
                for (int t = 0; t + 2 < triangles.Length; t += 3)
                {
                    Vector3 a = vertices[triangles[t]];
                    Vector3 b = vertices[triangles[t + 1]];
                    Vector3 c = vertices[triangles[t + 2]];
                    totalSurfaceArea += Vector3.Cross(b - a, c - a).magnitude * 0.5f;
                }

                tempSplats.Capacity = Mathf.Max(
                    triangles.Length / 3,
                    m_TargetSplatCount);
            }
            
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int i0 = triangles[i];
                int i1 = triangles[i + 1];
                int i2 = triangles[i + 2];
                
                Vector3 v0 = vertices[i0];
                Vector3 v1 = vertices[i1];
                Vector3 v2 = vertices[i2];
                
                Vector3 n0 = normals[i0];
                Vector3 n1 = normals[i1];
                Vector3 n2 = normals[i2];
                
                Color c0 = GetColorForVertex(i0, colors, uvs, texture);
                Color c1 = GetColorForVertex(i1, colors, uvs, texture);
                Color c2 = GetColorForVertex(i2, colors, uvs, texture);
                
                float area = Vector3.Cross(v1 - v0, v2 - v0).magnitude * 0.5f;
                int samplesForTriangle = m_UseTargetSplatCount && totalSurfaceArea > 0.000001f
                    ? Mathf.Max(1, Mathf.RoundToInt(m_TargetSplatCount * area / totalSurfaceArea))
                    : Mathf.Max(1, Mathf.CeilToInt(area / (m_SurfaceSampleDensity * m_SurfaceSampleDensity)));
                float surfaceScale = m_AutoSurfaceScale
                    ? CalculateSurfaceScale(area / samplesForTriangle)
                    : m_SplatScale;
                
                for (int s = 0; s < samplesForTriangle; s++)
                {
                    GenerateBarycentricSample(
                        s,
                        samplesForTriangle,
                        i / 3,
                        out float r3,
                        out float r1,
                        out float r2);
                    
                    Vector3 pos = v0 * r3 + v1 * r1 + v2 * r2;
                    Vector3 normal = (n0 * r3 + n1 * r1 + n2 * r2).normalized;
                    Color color = c0 * r3 + c1 * r1 + c2 * r2;
                    
                    int splatIdx = tempSplats.Count;
                    var splat = CreateSplatFromPoint(pos, normal, color, surfaceScale);
                    tempSplats.Add(splat);
                    if (uvs != null && uvs.Length > Mathf.Max(i0, Mathf.Max(i1, i2)))
                    {
                        Vector2 uv = uvs[i0] * r3 + uvs[i1] * r1 + uvs[i2] * r2;
                        StoreSplatUv(
                            splatIdx,
                            uv,
                            v0, v1, v2,
                            uvs[i0], uvs[i1], uvs[i2],
                            splat.rot,
                            surfaceScale);
                    }
                    
                    if (m_TransferWeights && boneWeights != null)
                    {
                        BoneWeight blendedWeight = BlendBoneWeights(boneWeights[i0], boneWeights[i1], boneWeights[i2], r3, r1, r2);
                        StoreBoneWeight(splatIdx, blendedWeight);
                    }
                }
            }
            
            var splats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(tempSplats.Count, Allocator.Persistent);
            for (int i = 0; i < tempSplats.Count; i++)
            {
                splats[i] = tempSplats[i];
            }
            
            return splats;
        }

        static void GenerateBarycentricSample(
            int sampleIndex,
            int sampleCount,
            int triangleIndex,
            out float b0,
            out float b1,
            out float b2)
        {
            // Deterministic low-discrepancy sampling covers each triangle much more
            // evenly than independent random points, reducing holes and color noise.
            float u = (sampleIndex + 0.5f) / Mathf.Max(1, sampleCount);
            float v = Mathf.Repeat(
                (sampleIndex + 1) * 0.61803398875f + triangleIndex * 0.754877666f,
                1f);
            float sqrtU = Mathf.Sqrt(u);
            b0 = 1f - sqrtU;
            b1 = sqrtU * (1f - v);
            b2 = sqrtU * v;
        }

        float CalculateSurfaceScale(float coveredArea)
        {
            if (coveredArea <= 0.00000001f)
                return m_SplatScale;

            // Radius of an equivalent-area disc, enlarged slightly so neighboring
            // Gaussian footprints overlap rather than exposing pinholes.
            return Mathf.Max(
                0.0001f,
                Mathf.Sqrt(coveredArea / Mathf.PI) * m_SurfaceScaleMultiplier);
        }

        GaussianSplatAssetCreator.InputSplatData CreateSplatFromPoint(
            Vector3 position,
            Vector3 normal,
            Color color,
            float surfaceScale)
        {
            Vector3 safeNormal = normal.sqrMagnitude > 0.000001f
                ? normal.normalized
                : Vector3.forward;

            // Align the flattened local Z axis directly to the surface normal.
            // Unlike LookRotation(normal, up), FromToRotation has no singularity
            // when the normal is parallel or nearly parallel to world up.
            Quaternion rotation = Quaternion.FromToRotation(Vector3.forward, safeNormal);
            
            return new GaussianSplatAssetCreator.InputSplatData
            {
                pos = position,
                nor = safeNormal,
                dc0 = new Vector3(color.r, color.g, color.b),
                opacity = m_SplatOpacity,
                scale = new Vector3(
                    surfaceScale,
                    surfaceScale,
                    Mathf.Max(surfaceScale * m_SurfaceThickness, 0.00001f)),
                rot = rotation,
                sh1 = Vector3.zero,
                sh2 = Vector3.zero,
                sh3 = Vector3.zero,
                sh4 = Vector3.zero,
                sh5 = Vector3.zero,
                sh6 = Vector3.zero,
                sh7 = Vector3.zero,
                sh8 = Vector3.zero,
                sh9 = Vector3.zero,
                shA = Vector3.zero,
                shB = Vector3.zero,
                shC = Vector3.zero,
                shD = Vector3.zero,
                shE = Vector3.zero,
                shF = Vector3.zero
            };
        }

        BoneWeight BlendBoneWeights(BoneWeight w0, BoneWeight w1, BoneWeight w2, float b0, float b1, float b2)
        {
            // Collect all bone influences
            var weights = new Dictionary<int, float>();
            
            AddBoneWeight(weights, w0.boneIndex0, w0.weight0 * b0);
            AddBoneWeight(weights, w0.boneIndex1, w0.weight1 * b0);
            AddBoneWeight(weights, w0.boneIndex2, w0.weight2 * b0);
            AddBoneWeight(weights, w0.boneIndex3, w0.weight3 * b0);
            
            AddBoneWeight(weights, w1.boneIndex0, w1.weight0 * b1);
            AddBoneWeight(weights, w1.boneIndex1, w1.weight1 * b1);
            AddBoneWeight(weights, w1.boneIndex2, w1.weight2 * b1);
            AddBoneWeight(weights, w1.boneIndex3, w1.weight3 * b1);
            
            AddBoneWeight(weights, w2.boneIndex0, w2.weight0 * b2);
            AddBoneWeight(weights, w2.boneIndex1, w2.weight1 * b2);
            AddBoneWeight(weights, w2.boneIndex2, w2.weight2 * b2);
            AddBoneWeight(weights, w2.boneIndex3, w2.weight3 * b2);
            
            // Sort by weight and take top 4
            var sortedWeights = new List<KeyValuePair<int, float>>(weights);
            sortedWeights.Sort((a, b) => b.Value.CompareTo(a.Value));
            
            BoneWeight result = new BoneWeight();
            float totalWeight = 0f;
            
            for (int i = 0; i < Mathf.Min(4, sortedWeights.Count); i++)
                totalWeight += sortedWeights[i].Value;
            
            if (totalWeight > 0)
            {
                if (sortedWeights.Count > 0) { result.boneIndex0 = sortedWeights[0].Key; result.weight0 = sortedWeights[0].Value / totalWeight; }
                if (sortedWeights.Count > 1) { result.boneIndex1 = sortedWeights[1].Key; result.weight1 = sortedWeights[1].Value / totalWeight; }
                if (sortedWeights.Count > 2) { result.boneIndex2 = sortedWeights[2].Key; result.weight2 = sortedWeights[2].Value / totalWeight; }
                if (sortedWeights.Count > 3) { result.boneIndex3 = sortedWeights[3].Key; result.weight3 = sortedWeights[3].Value / totalWeight; }
            }
            
            return result;
        }
        
        void AddBoneWeight(Dictionary<int, float> weights, int boneIndex, float weight)
        {
            if (weight > 0.001f)
            {
                if (weights.ContainsKey(boneIndex))
                    weights[boneIndex] += weight;
                else
                    weights[boneIndex] = weight;
            }
        }
        
        void StoreBoneWeight(int splatIndex, BoneWeight weight)
        {
            SplatBoneWeight splatWeight = new SplatBoneWeight();
            splatWeight.boneIndices = new Vector4(weight.boneIndex0, weight.boneIndex1, weight.boneIndex2, weight.boneIndex3);
            splatWeight.boneWeights = new Vector4(weight.weight0, weight.weight1, weight.weight2, weight.weight3);
            
            // Ensure weights are normalized (Unity should do this, but let's be safe)
            float totalWeight = weight.weight0 + weight.weight1 + weight.weight2 + weight.weight3;
            if (totalWeight > 0.001f && Mathf.Abs(totalWeight - 1.0f) > 0.01f)
            {
                splatWeight.boneWeights = new Vector4(
                    weight.weight0 / totalWeight,
                    weight.weight1 / totalWeight,
                    weight.weight2 / totalWeight,
                    weight.weight3 / totalWeight
                );
            }
            
            m_SplatWeights[splatIndex] = splatWeight;
        }

        void StoreSplatUv(
            int splatIndex,
            Vector2 uv,
            Vector3 v0,
            Vector3 v1,
            Vector3 v2,
            Vector2 uv0,
            Vector2 uv1,
            Vector2 uv2,
            Quaternion splatRotation,
            float surfaceScale)
        {
            if (m_SplatUvs == null)
                m_SplatUvs = new List<MixamoSplatUvData.SplatMeshUv>();

            while (m_SplatUvs.Count <= splatIndex)
                m_SplatUvs.Add(default);

            ComputeUvSigmas(v0, v1, v2, uv0, uv1, uv2, splatRotation, surfaceScale, out Vector2 uvSigmaX, out Vector2 uvSigmaY);
            m_SplatUvs[splatIndex] = new MixamoSplatUvData.SplatMeshUv
            {
                uv = uv,
                uvSigmaX = uvSigmaX,
                uvSigmaY = uvSigmaY
            };
        }

        static void ComputeUvSigmas(
            Vector3 v0,
            Vector3 v1,
            Vector3 v2,
            Vector2 uv0,
            Vector2 uv1,
            Vector2 uv2,
            Quaternion splatRotation,
            float surfaceScale,
            out Vector2 uvSigmaX,
            out Vector2 uvSigmaY)
        {
            Vector3 e1 = v1 - v0;
            Vector3 e2 = v2 - v0;
            Vector2 d1 = uv1 - uv0;
            Vector2 d2 = uv2 - uv0;
            float det = d1.x * d2.y - d2.x * d1.y;
            if (Mathf.Abs(det) < 1e-12f)
            {
                uvSigmaX = Vector2.zero;
                uvSigmaY = Vector2.zero;
                return;
            }

            float invDet = 1f / det;
            Vector3 dpdu = (e1 * d2.y - e2 * d1.y) * invDet;
            Vector3 dpdv = (e2 * d1.x - e1 * d2.x) * invDet;
            Vector3 axisX = splatRotation * Vector3.right * surfaceScale;
            Vector3 axisY = splatRotation * Vector3.up * surfaceScale;
            uvSigmaX = WorldDeltaToUv(dpdu, dpdv, axisX);
            uvSigmaY = WorldDeltaToUv(dpdu, dpdv, axisY);
        }

        static Vector2 WorldDeltaToUv(Vector3 dpdu, Vector3 dpdv, Vector3 worldDelta)
        {
            float t2 = Vector3.Dot(dpdu, dpdu);
            float b2 = Vector3.Dot(dpdv, dpdv);
            float tb = Vector3.Dot(dpdu, dpdv);
            float det = t2 * b2 - tb * tb;
            if (Mathf.Abs(det) < 1e-20f)
                return Vector2.zero;

            float du = (b2 * Vector3.Dot(worldDelta, dpdu) - tb * Vector3.Dot(worldDelta, dpdv)) / det;
            float dv = (t2 * Vector3.Dot(worldDelta, dpdv) - tb * Vector3.Dot(worldDelta, dpdu)) / det;
            return new Vector2(du, dv);
        }

        void AttachLiveAlbedo(GameObject rendererObj, GaussianSplatAsset asset)
        {
            if (m_SourceAlbedoTexture == null || m_SplatUvs == null || m_SplatUvs.Count == 0)
                return;

            var uvData = ScriptableObject.CreateInstance<MixamoSplatUvData>();
            uvData.SetUvs(m_SplatUvs.ToArray());
            string assetPath = AssetDatabase.GetAssetPath(asset);
            string assetDirectory = Path.GetDirectoryName(assetPath)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(assetDirectory))
                assetDirectory = m_OutputFolder;
            string uvPath = AssetDatabase.GenerateUniqueAssetPath($"{assetDirectory}/{asset.name}_SplatUVs.asset");
            AssetDatabase.CreateAsset(uvData, uvPath);

            var overlay = rendererObj.AddComponent<MixamoSplatTextureOverlay>();
            overlay.SetData(m_SourceAlbedoTexture, uvData);
            EditorUtility.SetDirty(overlay);
        }

        GaussianSplatAsset CreateAssetFromSplats(NativeArray<GaussianSplatAssetCreator.InputSplatData> splatData, string baseName, float3 boundsMin, float3 boundsMax)
        {
            GaussianSplatAsset asset = ScriptableObject.CreateInstance<GaussianSplatAsset>();
            asset.Initialize(splatData.Length, m_FormatPos, m_FormatScale, m_FormatColor, m_FormatSH, boundsMin, boundsMax, null);
            asset.name = baseName;
            
            var dataHash = new Hash128((uint)asset.splatCount, (uint)asset.formatVersion, 0, 0);
            string pathChunk = $"{m_OutputFolder}/{baseName}_chk.bytes";
            string pathPos = $"{m_OutputFolder}/{baseName}_pos.bytes";
            string pathOther = $"{m_OutputFolder}/{baseName}_oth.bytes";
            string pathCol = $"{m_OutputFolder}/{baseName}_col.bytes";
            string pathSh = $"{m_OutputFolder}/{baseName}_shs.bytes";
            
            bool useChunks = isUsingChunks;
            if (useChunks)
                CreateChunkData(splatData, pathChunk, ref dataHash);
            CreatePositionsData(splatData, pathPos, ref dataHash);
            CreateOtherData(splatData, pathOther, ref dataHash);
            CreateColorData(splatData, pathCol, ref dataHash);
            CreateSHData(splatData, pathSh, ref dataHash);
            asset.SetDataHash(dataHash);
            
            EditorUtility.DisplayProgressBar(kProgressTitle, "Importing assets...", 0.85f);
            AssetDatabase.Refresh(ImportAssetOptions.ForceUncompressedImport);
            
            EditorUtility.DisplayProgressBar(kProgressTitle, "Finalizing asset...", 0.95f);
            asset.SetAssetFiles(
                useChunks ? AssetDatabase.LoadAssetAtPath<TextAsset>(pathChunk) : null,
                AssetDatabase.LoadAssetAtPath<TextAsset>(pathPos),
                AssetDatabase.LoadAssetAtPath<TextAsset>(pathOther),
                AssetDatabase.LoadAssetAtPath<TextAsset>(pathCol),
                AssetDatabase.LoadAssetAtPath<TextAsset>(pathSh));
            
            var assetPath = $"{m_OutputFolder}/{baseName}.asset";
            var savedAsset = CreateOrReplaceAsset(asset, assetPath);
            
            AssetDatabase.SaveAssets();
            
            return savedAsset;
        }

        static T CreateOrReplaceAsset<T>(T asset, string path) where T : UnityEngine.Object
        {
            T result = AssetDatabase.LoadAssetAtPath<T>(path);
            if (result == null)
            {
                AssetDatabase.CreateAsset(asset, path);
                result = asset;
            }
            else
            {
                EditorUtility.CopySerialized(asset, result);
            }
            return result;
        }

        void CreateAnimatedSplatInScene(GaussianSplatAsset asset)
        {
            GameObject go = new GameObject(m_GameObjectName);
            
            // CRITICAL FIX: Position root GameObject at source mesh position
            if (m_SourceSkinnedMesh != null)
            {
                go.transform.position = m_SourceSkinnedMesh.transform.position;
                go.transform.rotation = Quaternion.identity;
            }
            
            // Create rig hierarchy (as child, will inherit parent position)
            GameObject rigObj = null;
            GaussianSplatRig rig = null;
            
            if (m_CreateRig && m_SourceSkinnedMesh.bones.Length > 0)
            {
                rigObj = new GameObject("Rig");
                rigObj.transform.SetParent(go.transform, false);
                
                // CRITICAL: Position rig to match source mesh exactly
                rigObj.transform.localPosition = Vector3.zero; // Same as parent (splat renderer)
                rigObj.transform.localRotation = Quaternion.identity;
                rigObj.transform.localScale = Vector3.one;
                
                rig = rigObj.AddComponent<GaussianSplatRig>();
                
                CreateBoneHierarchy(rigObj.transform, m_SourceSkinnedMesh.bones, m_SourceSkinnedMesh.sharedMesh.bindposes);
                rig.RebuildRig();
            }
            
            // Create renderer (as child, will inherit parent position)
            GameObject rendererObj = new GameObject("Splats");
            rendererObj.transform.SetParent(go.transform, false);
            
            GaussianSplatRenderer renderer = rendererObj.AddComponent<GaussianSplatRenderer>();
            
            renderer.enabled = false;
            renderer.m_Asset = asset;

            // SplatBox resolves its current render and compute shaders in OnEnable.
            // The legacy renderer fields previously assigned here no longer exist.
            renderer.enabled = true;
            AttachLiveAlbedo(rendererObj, asset);
            
            // Add skin component if rig was created
            GaussianSplatSkin skin = null;
            if (rig != null && m_TransferWeights)
            {
                skin = rendererObj.AddComponent<GaussianSplatSkin>();
                skin.rig = rig;
                
                // Find and assign skinning compute shader
                ComputeShader skinningCS = FindSkinningComputeShader();
                if (skinningCS != null)
                {
                    var skinSO = new SerializedObject(skin);
                    skinSO.FindProperty("m_SkinningComputeShader").objectReferenceValue = skinningCS;
                    skinSO.FindProperty("m_EnableSkinning").boolValue = false; // Keep disabled until weights applied
                    skinSO.FindProperty("m_UseComputeShader").boolValue = true; // Use GPU skinning
                    skinSO.ApplyModifiedProperties();
                }
                
                // CRITICAL FIX: Transfer collected bone weights to the skin component
                if (m_SplatWeights != null && m_SplatWeights.Count > 0)
                {
                    // BakeMesh already produced splats in the generated renderer's
                    // coordinate system. Do not copy the FBX import scale (commonly
                    // 100 for Mixamo) onto the rig a second time.
                    skin.rig.transform.localScale = Vector3.one;

                    Matrix4x4 rigBindTransform = skin.rig.transform.localToWorldMatrix;
                    Matrix4x4 rigInvBindTransform = rigBindTransform.inverse;
                    
                    // Create bone mapping from source mesh to splat rig
                    Dictionary<int, int> boneMapping = CreateBoneMapping(m_SourceSkinnedMesh.bones, skin.rig);
                    if (boneMapping.Count == 0)
                    {
                        return;
                    }
                    
                    // Convert m_SplatWeights to the format needed by MixamoWeightInjector with bone mapping
                    var boneIndicesDict = new Dictionary<int, Vector4>();
                    var boneWeightsDict = new Dictionary<int, Vector4>();
                    
                    int mappingFailures = 0;
                    foreach (var kvp in m_SplatWeights)
                    {
                        var weight = kvp.Value;
                        
                        // Map bone indices from source mesh to splat rig
                        Vector4 mappedIndices = new Vector4(-1, -1, -1, -1);
                        Vector4 mappedWeights = new Vector4(0, 0, 0, 0);
                        
                        // Map each bone index and preserve weights
                        if (weight.boneIndices.x >= 0 && boneMapping.ContainsKey((int)weight.boneIndices.x))
                        {
                            mappedIndices.x = boneMapping[(int)weight.boneIndices.x];
                            mappedWeights.x = weight.boneWeights.x;
                        }
                        else if (weight.boneIndices.x >= 0) mappingFailures++;
                        
                        if (weight.boneIndices.y >= 0 && boneMapping.ContainsKey((int)weight.boneIndices.y))
                        {
                            mappedIndices.y = boneMapping[(int)weight.boneIndices.y];
                            mappedWeights.y = weight.boneWeights.y;
                        }
                        else if (weight.boneIndices.y >= 0) mappingFailures++;
                        
                        if (weight.boneIndices.z >= 0 && boneMapping.ContainsKey((int)weight.boneIndices.z))
                        {
                            mappedIndices.z = boneMapping[(int)weight.boneIndices.z];
                            mappedWeights.z = weight.boneWeights.z;
                        }
                        else if (weight.boneIndices.z >= 0) mappingFailures++;
                        
                        if (weight.boneIndices.w >= 0 && boneMapping.ContainsKey((int)weight.boneIndices.w))
                        {
                            mappedIndices.w = boneMapping[(int)weight.boneIndices.w];
                            mappedWeights.w = weight.boneWeights.w;
                        }
                        else if (weight.boneIndices.w >= 0) mappingFailures++;
                        
                        // Only store if we have valid weights
                        float weightSum = mappedWeights.x + mappedWeights.y + mappedWeights.z + mappedWeights.w;
                        if (weightSum > 0.001f)
                        {
                            boneIndicesDict[kvp.Key] = mappedIndices;
                            boneWeightsDict[kvp.Key] = mappedWeights;
                        }
                    }
                    
                    // Add the new MixamoWeightInjector component
                    var injector = rendererObj.AddComponent<MixamoWeightInjector>();
                    injector.SetMixamoWeights(skin, boneIndicesDict, boneWeightsDict, rigBindTransform, rigInvBindTransform, asset.splatCount);

                    // Keep the very large array out of the scene. Otherwise changing
                    // any component can make Unity serialize hundreds of thousands
                    // of weight records on the Editor update loop.
                    var weightData = CreateInstance<MixamoWeightData>();
                    injector.MoveEmbeddedWeightsTo(weightData);
                    string assetPath = AssetDatabase.GetAssetPath(asset);
                    string assetDirectory = Path.GetDirectoryName(assetPath)?.Replace('\\', '/');
                    if (string.IsNullOrEmpty(assetDirectory))
                        assetDirectory = m_OutputFolder;
                    string weightDataPath = AssetDatabase.GenerateUniqueAssetPath(
                        $"{assetDirectory}/{asset.name}_MixamoWeights.asset");
                    AssetDatabase.CreateAsset(weightData, weightDataPath);
                    EditorUtility.SetDirty(injector);
                    
                    // Enable skinning since weights are already applied
                    var skinSO2 = new SerializedObject(skin);
                    skinSO2.FindProperty("m_EnableSkinning").boolValue = true;
                    skinSO2.FindProperty("m_WeightsCalculated").boolValue = true; // Mark as calculated
                    // CRITICAL: Disable auto weight threshold to preserve transferred weights
                    skinSO2.FindProperty("m_AutoWeightThreshold").boolValue = false;
                    skinSO2.FindProperty("m_WeightThreshold").floatValue = 0.001f; // Very low threshold
                    skinSO2.ApplyModifiedProperties();
                }
            }
            
            // Setup animator if requested
            if (m_SetupAnimator && rigObj != null && m_AnimatorController != null)
            {
                Animator animator = rigObj.AddComponent<Animator>();
                animator.runtimeAnimatorController = m_AnimatorController;
                Animator sourceAnimator = m_SourceSkinnedMesh.GetComponentInParent<Animator>();
                if (sourceAnimator != null && sourceAnimator.avatar != null)
                    animator.avatar = sourceAnimator.avatar;
                animator.applyRootMotion = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            }

            // Transferred weights need the same bind-space initialization that
            // RecalculateWeights performs. Without this, the serialized matrices
            // remain zero until the user manually recalculates.
            if (rig != null && skin != null)
            {
                rig.CaptureBindPoses();
                skin.CaptureBindTransforms();
            }
            
            // Add Mixamo helper component if it's a Mixamo rig
            if (m_IsMixamoRig && rigObj != null)
            {
                MixamoSplatCharacter mixamoChar = go.AddComponent<MixamoSplatCharacter>();
                mixamoChar.AutoFindComponents();
            }
            
            Selection.activeGameObject = go;
            EditorGUIUtility.PingObject(go);
        }

        void CreateBoneHierarchy(Transform rigRoot, Transform[] srcBones, Matrix4x4[] bindPoses)
        {
            if (srcBones == null || srcBones.Length == 0) return;
            
            Dictionary<Transform, Transform> boneMap = new Dictionary<Transform, Transform>();
            
            // Get auto settings if enabled
            var autoSettings = m_AutoBoneSettings ? CalculateAutoBoneSettings() : new AutoBoneSettings 
            { 
                radiusMultiplier = m_BoneRadiusMultiplier, 
                falloff = m_BoneFalloff 
            };
            
            // SIMPLE APPROACH: Copy bone transforms exactly as they are
            // First pass: create all bones with exact world positions
            for (int i = 0; i < srcBones.Length; i++)
            {
                if (srcBones[i] == null) continue;
                
                GameObject boneObj = new GameObject(srcBones[i].name);
                Transform newBone = boneObj.transform;
                
                // Copy exact world transform from source
                newBone.position = srcBones[i].position;
                newBone.rotation = srcBones[i].rotation;
                newBone.localScale = srcBones[i].localScale;
                
                boneMap[srcBones[i]] = newBone;
            }
            
            // Second pass: rebuild hierarchy and add components
            for (int i = 0; i < srcBones.Length; i++)
            {
                if (srcBones[i] == null) continue;
                
                Transform newBone = boneMap[srcBones[i]];
                
                // Set correct parent in hierarchy
                if (srcBones[i].parent != null && boneMap.ContainsKey(srcBones[i].parent))
                {
                    newBone.SetParent(boneMap[srcBones[i].parent], true); // Keep world position
                }
                else
                {
                    newBone.SetParent(rigRoot, true); // Keep world position
                }
                
                // After parenting, ensure the transform is still correct
                newBone.position = srcBones[i].position;
                newBone.rotation = srcBones[i].rotation;
                
                GaussianSplatBone bone = newBone.gameObject.AddComponent<GaussianSplatBone>();
                
                // Calculate bone radius
                float radius;
                if (m_IsMixamoRig && m_UseMixamoPresets)
                {
                    radius = MixamoRigImporter.GetMixamoBoneRadius(srcBones[i].name, autoSettings.radiusMultiplier);
                }
                else
                {
                    radius = CalculateBoneRadius(srcBones[i], srcBones) * autoSettings.radiusMultiplier;
                }
                
                bone.radius = radius;
                bone.falloff = autoSettings.falloff;
                
                bone.CaptureBindPose();
            }
            
        }
        
        float CalculateBoneRadius(Transform bone, Transform[] allBones)
        {
            float minDist = 1.0f;
            
            foreach (Transform child in bone)
            {
                if (System.Array.IndexOf(allBones, child) >= 0)
                {
                    float dist = Vector3.Distance(bone.position, child.position);
                    if (dist > 0 && dist < minDist)
                        minDist = dist;
                }
            }
            
            return minDist * 0.5f;
        }

        AutoBoneSettings CalculateAutoBoneSettings()
        {
            AutoBoneSettings settings = new AutoBoneSettings();
            
            if (m_SourceSkinnedMesh == null || m_SourceSkinnedMesh.sharedMesh == null)
            {
                settings.radiusMultiplier = 5.0f;
                settings.falloff = 0.5f;
                return settings;
            }
            
            Mesh mesh = m_SourceSkinnedMesh.sharedMesh;
            
            // Calculate average splat spacing based on sampling mode
            float avgSplatSpacing = m_SplatScale;
            
            switch (m_SamplingMode)
            {
                case SamplingMode.Vertices:
                    // Vertices mode - spacing roughly equals splat scale
                    avgSplatSpacing = m_SplatScale * 2f;
                    break;
                    
                case SamplingMode.UniformSurface:
                    // Uniform surface - spacing based on density
                    avgSplatSpacing = m_SurfaceSampleDensity * 1.5f;
                    break;
                    
                case SamplingMode.TriangleCenters:
                    // Triangle centers - depends on mesh density
                    avgSplatSpacing = m_SplatScale * 1.5f;
                    break;
            }
            
            // Calculate multiplier to ensure bones catch enough splats
            // Use conservative multiplier for clean skinning
            float baseRadius = CalculateAverageBoneDistance();
            
            // Simple heuristic: smaller multiplier for denser splats
            if (m_EstimatedSplatCount > 30000)
                settings.radiusMultiplier = 0.8f; // Dense - bones don't need large radius
            else if (m_EstimatedSplatCount > 15000)
                settings.radiusMultiplier = 1.0f; // Medium
            else
                settings.radiusMultiplier = 1.5f; // Sparse - need larger radius
            
            // Clamp to reasonable range
            settings.radiusMultiplier = Mathf.Clamp(settings.radiusMultiplier, 0.5f, 3.0f);
            
            // Falloff: tighter for denser meshes, looser for sparse
            if (m_EstimatedSplatCount > 50000)
                settings.falloff = 0.6f; // Dense mesh - tighter falloff
            else if (m_EstimatedSplatCount > 20000)
                settings.falloff = 0.5f; // Medium
            else
                settings.falloff = 0.4f; // Sparse mesh - looser falloff
            
            return settings;
        }

        float CalculateAverageBoneDistance()
        {
            if (m_SourceSkinnedMesh == null || m_SourceSkinnedMesh.bones == null)
                return 0.1f;
            
            Transform[] bones = m_SourceSkinnedMesh.bones;
            if (bones.Length < 2)
                return 0.1f;
            
            float totalDist = 0f;
            int count = 0;
            
            foreach (Transform bone in bones)
            {
                if (bone == null) continue;
                
                foreach (Transform child in bone)
                {
                    if (System.Array.IndexOf(bones, child) >= 0)
                    {
                        float dist = Vector3.Distance(bone.position, child.position);
                        if (dist > 0)
                        {
                            totalDist += dist;
                            count++;
                        }
                    }
                }
            }
            
            return count > 0 ? totalDist / count : 0.1f;
        }

        [BurstCompile]
        unsafe struct CalcBoundsJob : IJob
        {
            [NativeDisableUnsafePtrRestriction] public float3* m_BoundsMin;
            [NativeDisableUnsafePtrRestriction] public float3* m_BoundsMax;
            [ReadOnly] public NativeArray<GaussianSplatAssetCreator.InputSplatData> m_SplatData;

            public void Execute()
            {
                float3 boundsMin = float.PositiveInfinity;
                float3 boundsMax = float.NegativeInfinity;

                for (int i = 0; i < m_SplatData.Length; ++i)
                {
                    float3 pos = m_SplatData[i].pos;
                    boundsMin = math.min(boundsMin, pos);
                    boundsMax = math.max(boundsMax, pos);
                }
                *m_BoundsMin = boundsMin;
                *m_BoundsMax = boundsMax;
            }
        }

        void CreateChunkData(NativeArray<GaussianSplatAssetCreator.InputSplatData> inputSplats, string filePath, ref Hash128 dataHash)
        {
            int chunkCount = (inputSplats.Length + GaussianSplatAsset.kChunkSize - 1) / GaussianSplatAsset.kChunkSize;
            NativeArray<GaussianSplatAsset.ChunkInfo> chunks = new(chunkCount, Allocator.TempJob);
            
            var job = new GaussianSplatAssetCreator.CalcChunkDataJob
            {
                splatData = inputSplats,
                chunks = chunks
            };
            job.Schedule(chunkCount, 1).Complete();
            
            dataHash.Append(chunks);
            
            using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            fs.Write(chunks.Reinterpret<byte>(UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()));
            
            chunks.Dispose();
        }

        void CreatePositionsData(NativeArray<GaussianSplatAssetCreator.InputSplatData> inputSplats, string filePath, ref Hash128 dataHash)
        {
            int dataLen = inputSplats.Length * GaussianSplatAsset.GetVectorSize(m_FormatPos);
            dataLen = NextMultipleOf(dataLen, 8);
            NativeArray<byte> data = new(dataLen, Allocator.TempJob);
            
            var job = new GaussianSplatAssetCreator.CreatePositionsDataJob
            {
                m_Input = inputSplats,
                m_Format = m_FormatPos,
                m_FormatSize = GaussianSplatAsset.GetVectorSize(m_FormatPos),
                m_Output = data
            };
            job.Schedule(inputSplats.Length, 8192).Complete();
            
            dataHash.Append(data);
            
            using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            fs.Write(data.AsReadOnlySpan());
            
            data.Dispose();
        }

        void CreateOtherData(NativeArray<GaussianSplatAssetCreator.InputSplatData> inputSplats, string filePath, ref Hash128 dataHash)
        {
            int formatSize = GaussianSplatAsset.GetOtherSizeNoSHIndex(m_FormatScale);
            int dataLen = inputSplats.Length * formatSize;
            dataLen = NextMultipleOf(dataLen, 8);
            NativeArray<byte> data = new(dataLen, Allocator.TempJob);
            
            var job = new GaussianSplatAssetCreator.CreateOtherDataJob
            {
                m_Input = inputSplats,
                m_ScaleFormat = m_FormatScale,
                m_FormatSize = formatSize,
                m_Output = data
            };
            job.Schedule(inputSplats.Length, 8192).Complete();
            
            dataHash.Append(data);
            
            using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            fs.Write(data.AsReadOnlySpan());
            
            data.Dispose();
        }

        void CreateColorData(NativeArray<GaussianSplatAssetCreator.InputSplatData> inputSplats, string filePath, ref Hash128 dataHash)
        {
            var (width, height) = GaussianSplatAsset.CalcTextureSize(inputSplats.Length);
            NativeArray<float4> data = new(width * height, Allocator.TempJob);
            
            var job = new GaussianSplatAssetCreator.CreateColorDataJob
            {
                m_Input = inputSplats,
                m_Output = data
            };
            job.Schedule(inputSplats.Length, 8192).Complete();
            
            dataHash.Append(data);
            dataHash.Append((int)m_FormatColor);
            
            GraphicsFormat gfxFormat = GaussianSplatAsset.ColorFormatToGraphics(m_FormatColor);
            
            Texture2D tex = new Texture2D(width, height, GraphicsFormat.R32G32B32A32_SFloat, 
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate);
            tex.SetPixelData(data, 0);
            
            if (GraphicsFormatUtility.IsCompressedFormat(gfxFormat))
            {
                EditorUtility.CompressTexture(tex, GraphicsFormatUtility.GetTextureFormat(gfxFormat), 100);
                NativeArray<byte> cmpData = tex.GetPixelData<byte>(0);
                using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                fs.Write(cmpData.AsReadOnlySpan());
            }
            else
            {
                int dstSize = (int)GraphicsFormatUtility.ComputeMipmapSize(width, height, gfxFormat);
                var convertJob = new GaussianSplatAssetCreator.ConvertColorJob
                {
                    width = width,
                    height = height,
                    inputData = data,
                    format = m_FormatColor,
                    outputData = new NativeArray<byte>(dstSize, Allocator.TempJob),
                    formatBytesPerPixel = dstSize / width / height
                };
                // ConvertColorJob.Execute receives a row index and converts all
                // pixels across that row. Scheduling one job per pixel made `y`
                // exceed the texture height, overflowing srcIdx into huge values.
                convertJob.Schedule(height, 1).Complete();
                
                using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
                fs.Write(convertJob.outputData.AsReadOnlySpan());
                
                convertJob.outputData.Dispose();
            }
            
            UnityEngine.Object.DestroyImmediate(tex);
            data.Dispose();
        }

        void CreateSHData(NativeArray<GaussianSplatAssetCreator.InputSplatData> inputSplats, string filePath, ref Hash128 dataHash)
        {
            long dataLen = GaussianSplatAsset.CalcSHDataSize(inputSplats.Length, m_FormatSH);
            NativeArray<byte> data = new((int)dataLen, Allocator.TempJob);
            
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = 0;
            }
            
            dataHash.Append(data);
            
            using var fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            fs.Write(data.AsReadOnlySpan());
            
            data.Dispose();
        }

        static int NextMultipleOf(int size, int multipleOf)
        {
            return (size + multipleOf - 1) / multipleOf * multipleOf;
        }

        ComputeShader FindSkinningComputeShader()
        {
            // Search for GaussianSplatSkinning compute shader
            string[] guids = AssetDatabase.FindAssets("GaussianSplatSkinning t:ComputeShader");
            if (guids.Length > 0)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[0]);
                return AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
            }
            
            // Fallback: search all compute shaders
            var allCompute = Resources.FindObjectsOfTypeAll<ComputeShader>();
            foreach (var cs in allCompute)
            {
                if (cs.name.Contains("Skinning") || cs.name.Contains("GaussianSplatSkinning"))
                {
                    return cs;
                }
            }
            
            return null;
        }


        /// <summary>
        /// Create mapping from source mesh bone indices to splat rig bone indices
        /// </summary>
        Dictionary<int, int> CreateBoneMapping(Transform[] sourceBones, GaussianSplatRig splatRig)
        {
            var mapping = new Dictionary<int, int>();
            
            if (sourceBones == null || splatRig == null || splatRig.bones == null)
                return mapping;
            
            // Map by bone name (most reliable for Mixamo rigs)
            for (int srcIdx = 0; srcIdx < sourceBones.Length; srcIdx++)
            {
                if (sourceBones[srcIdx] == null) continue;
                
                string srcBoneName = sourceBones[srcIdx].name;
                
                // Find matching bone in splat rig by name
                for (int rigIdx = 0; rigIdx < splatRig.bones.Length; rigIdx++)
                {
                    if (splatRig.bones[rigIdx] != null && 
                        splatRig.bones[rigIdx].transform.name == srcBoneName)
                    {
                        mapping[srcIdx] = rigIdx;
                        break;
                    }
                }
            }
            
            return mapping;
        }

        void ApplyMixamoRecommendedSettings()
        {
            if (m_SourceSkinnedMesh == null) return;
            
            MixamoConversionSettings settings = MixamoRigImporter.GetRecommendedSettings(m_SourceSkinnedMesh);
            
            // Apply recommended settings
            switch (settings.samplingMode)
            {
                case MixamoConversionSettings.SamplingMode.Vertices:
                    m_SamplingMode = SamplingMode.Vertices;
                    break;
                case MixamoConversionSettings.SamplingMode.TriangleCenters:
                    m_SamplingMode = SamplingMode.TriangleCenters;
                    m_TriangleSamplesPerFace = settings.triangleSamplesPerFace;
                    break;
                case MixamoConversionSettings.SamplingMode.UniformSurface:
                    m_SamplingMode = SamplingMode.UniformSurface;
                    m_SurfaceSampleDensity = settings.surfaceSampleDensity;
                    break;
            }
            
            m_SplatScale = settings.splatScale;
            m_SplatOpacity = settings.splatOpacity;
            m_TransferWeights = settings.transferWeights;
            m_SetupAnimator = settings.setupAnimator;
            m_UseTargetSplatCount = true;
            m_TargetSplatCount = 1000000;
            
            // Enable auto bone settings for Mixamo
            m_AutoBoneSettings = true;
            
            // Ensure VeryHigh quality for Mixamo characters
            m_Quality = DataQuality.VeryHigh;
            ApplyQualityPreset();
        }

        void ApplyQualityPreset()
        {
            switch (m_Quality)
            {
                case DataQuality.VeryLow:
                    m_FormatPos = GaussianSplatAsset.VectorFormat.Norm6;
                    m_FormatScale = GaussianSplatAsset.VectorFormat.Norm6;
                    m_FormatColor = GaussianSplatAsset.ColorFormat.BC7;
                    m_FormatSH = GaussianSplatAsset.SHFormat.Cluster4k;
                    break;
                case DataQuality.Low:
                    m_FormatPos = GaussianSplatAsset.VectorFormat.Norm11;
                    m_FormatScale = GaussianSplatAsset.VectorFormat.Norm6;
                    m_FormatColor = GaussianSplatAsset.ColorFormat.BC7;
                    m_FormatSH = GaussianSplatAsset.SHFormat.Cluster8k;
                    break;
                case DataQuality.Medium:
                    m_FormatPos = GaussianSplatAsset.VectorFormat.Norm11;
                    m_FormatScale = GaussianSplatAsset.VectorFormat.Norm11;
                    m_FormatColor = GaussianSplatAsset.ColorFormat.Norm8x4;
                    m_FormatSH = GaussianSplatAsset.SHFormat.Norm6;
                    break;
                case DataQuality.High:
                    m_FormatPos = GaussianSplatAsset.VectorFormat.Norm16;
                    m_FormatScale = GaussianSplatAsset.VectorFormat.Norm16;
                    m_FormatColor = GaussianSplatAsset.ColorFormat.Float16x4;
                    m_FormatSH = GaussianSplatAsset.SHFormat.Norm11;
                    break;
                case DataQuality.VeryHigh:
                    m_FormatPos = GaussianSplatAsset.VectorFormat.Float32;
                    m_FormatScale = GaussianSplatAsset.VectorFormat.Float32;
                    m_FormatColor = GaussianSplatAsset.ColorFormat.Float32x4;
                    m_FormatSH = GaussianSplatAsset.SHFormat.Float32;
                    break;
            }
        }

        string GetQualityInfo()
        {
            // Estimate bytes per splat based on current format settings
            int posBytes = GaussianSplatAsset.GetVectorSize(m_FormatPos);
            int scaleBytes = GaussianSplatAsset.GetVectorSize(m_FormatScale);
            int rotBytes = 4; // Quaternion packed to 4 bytes
            int colorBytes = m_FormatColor switch
            {
                GaussianSplatAsset.ColorFormat.Float32x4 => 16,
                GaussianSplatAsset.ColorFormat.Float16x4 => 8,
                GaussianSplatAsset.ColorFormat.Norm8x4 => 4,
                GaussianSplatAsset.ColorFormat.BC7 => 1, // Compressed
                _ => 4
            };
            
            int bytesPerSplat = posBytes + scaleBytes + rotBytes + colorBytes;
            long totalBytes = (long)m_EstimatedSplatCount * bytesPerSplat;
            
            string sizeStr;
            if (totalBytes < 1024)
                sizeStr = $"{totalBytes} B";
            else if (totalBytes < 1024 * 1024)
                sizeStr = $"{totalBytes / 1024f:F1} KB";
            else if (totalBytes < 1024 * 1024 * 1024)
                sizeStr = $"{totalBytes / (1024f * 1024f):F1} MB";
            else
                sizeStr = $"{totalBytes / (1024f * 1024f * 1024f):F2} GB";
            
            return $"Estimated size: ~{sizeStr} ({bytesPerSplat} bytes/splat × {m_EstimatedSplatCount:N0} splats)\n" +
                   $"Format: Pos={m_FormatPos}, Scale={m_FormatScale}, Color={m_FormatColor}";
        }
    }
}

