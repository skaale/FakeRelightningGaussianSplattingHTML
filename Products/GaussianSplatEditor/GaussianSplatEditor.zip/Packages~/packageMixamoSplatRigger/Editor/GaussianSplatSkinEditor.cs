// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatSkin))]
    public class GaussianSplatSkinEditor : UnityEditor.Editor
    {
        SerializedProperty m_RigProp;
        SerializedProperty m_MaxBonesPerSplatProp;
        SerializedProperty m_AutoWeightThresholdProp;
        SerializedProperty m_WeightThresholdProp;
        SerializedProperty m_WeightsCalculatedProp;
        SerializedProperty m_SkinModeProp;
        SerializedProperty m_SelectionBoundsProp;
        SerializedProperty m_EnableSkinningProp;
        SerializedProperty m_UseComputeShaderProp;
        SerializedProperty m_SkinningComputeShaderProp;
        SerializedProperty m_SmoothAnimationProp;
        SerializedProperty m_UpdateEveryNFramesProp;
        SerializedProperty m_AutoPartitionLargeRigsProp;
        SerializedProperty m_SkinningPartitionsProp;
        SerializedProperty m_TestModeProp;
        SerializedProperty m_TestBoneIndexProp;

        void OnEnable()
        {
            m_RigProp = serializedObject.FindProperty("m_Rig");
            m_MaxBonesPerSplatProp = serializedObject.FindProperty("m_MaxBonesPerSplat");
            m_AutoWeightThresholdProp = serializedObject.FindProperty("m_AutoWeightThreshold");
            m_WeightThresholdProp = serializedObject.FindProperty("m_WeightThreshold");
            m_WeightsCalculatedProp = serializedObject.FindProperty("m_WeightsCalculated");
            m_SkinModeProp = serializedObject.FindProperty("m_SkinMode");
            m_SelectionBoundsProp = serializedObject.FindProperty("m_SelectionBounds");
            m_EnableSkinningProp = serializedObject.FindProperty("m_EnableSkinning");
            m_UseComputeShaderProp = serializedObject.FindProperty("m_UseComputeShader");
            m_SkinningComputeShaderProp = serializedObject.FindProperty("m_SkinningComputeShader");
            m_SmoothAnimationProp = serializedObject.FindProperty("m_SmoothAnimation");
            m_UpdateEveryNFramesProp = serializedObject.FindProperty("m_UpdateEveryNFrames");
            m_AutoPartitionLargeRigsProp = serializedObject.FindProperty("m_AutoPartitionLargeRigs");
            m_SkinningPartitionsProp = serializedObject.FindProperty("m_SkinningPartitions");
            m_TestModeProp = serializedObject.FindProperty("m_TestMode");
            m_TestBoneIndexProp = serializedObject.FindProperty("m_TestBoneIndex");

            // Older converted characters embedded every splat weight in the scene.
            // Migrate once after the Inspector is ready, then future component
            // changes only serialize a small asset reference.
            EditorApplication.delayCall += MigrateEmbeddedWeights;
        }

        void OnDisable()
        {
            EditorApplication.delayCall -= MigrateEmbeddedWeights;
        }

        void MigrateEmbeddedWeights()
        {
            if (Application.isPlaying || target == null)
                return;

            var skin = (GaussianSplatSkin)target;
            var injector = skin.GetComponent<MixamoWeightInjector>();
            if (injector == null || !injector.hasEmbeddedWeights || injector.weightData != null)
                return;

            const string folder = "Assets/GaussianSplatWeightData";
            if (!AssetDatabase.IsValidFolder(folder))
                AssetDatabase.CreateFolder("Assets", "GaussianSplatWeightData");

            var data = CreateInstance<MixamoWeightData>();
            data.name = $"{skin.gameObject.name}_MixamoWeights";
            injector.MoveEmbeddedWeightsTo(data);

            string path = AssetDatabase.GenerateUniqueAssetPath($"{folder}/{data.name}.asset");
            AssetDatabase.CreateAsset(data, path);
            EditorUtility.SetDirty(data);
            EditorUtility.SetDirty(injector);
            Debug.Log($"[MixamoSplatRigger] Moved embedded splat weights to '{path}' to reduce Editor update stalls.", injector);
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.LabelField("Rig", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_RigProp);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Skinning", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_MaxBonesPerSplatProp);
            
            EditorGUILayout.PropertyField(m_AutoWeightThresholdProp, new GUIContent("Auto Weight Threshold"));
            if (!m_AutoWeightThresholdProp.boolValue)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(m_WeightThresholdProp, new GUIContent("Threshold"));
                EditorGUILayout.HelpBox("Lower = more splats influenced (0.01 recommended)", MessageType.Info);
                EditorGUI.indentLevel--;
            }
            else
            {
                EditorGUILayout.HelpBox("✓ Weight threshold set automatically to 0.01", MessageType.Info);
            }
            
            EditorGUI.BeginDisabledGroup(true);
            EditorGUILayout.PropertyField(m_WeightsCalculatedProp);
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Selection", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_SkinModeProp);
            if (m_SkinModeProp.enumValueIndex == 1) // BoundsVolume
            {
                EditorGUILayout.PropertyField(m_SelectionBoundsProp);
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Performance", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_EnableSkinningProp);
            EditorGUILayout.PropertyField(m_UseComputeShaderProp);
            EditorGUILayout.PropertyField(m_SkinningComputeShaderProp);
            
            // Add button to find compute shader if missing
            if (m_SkinningComputeShaderProp.objectReferenceValue == null)
            {
                EditorGUILayout.HelpBox("Skinning Compute Shader is missing! Click below to find it.", MessageType.Warning);
                if (GUILayout.Button("Find Skinning Compute Shader"))
                {
                    ComputeShader foundShader = FindSkinningComputeShader();
                    if (foundShader != null)
                    {
                        m_SkinningComputeShaderProp.objectReferenceValue = foundShader;
                        serializedObject.ApplyModifiedProperties();
                        Debug.Log($"✓ Found and assigned: {foundShader.name}");
                    }
                    else
                    {
                        EditorUtility.DisplayDialog("Not Found", 
                            "Could not find GaussianSplatSkinning.compute shader.\n\nMake sure it exists in the package Shaders folder.", 
                            "OK");
                    }
                }
            }
            
            EditorGUILayout.PropertyField(m_SmoothAnimationProp);
            if (m_SmoothAnimationProp.boolValue)
            {
                EditorGUILayout.HelpBox(
                    "Full coherent skinning runs every frame. Recommended for walk cycles.",
                    MessageType.Info);
            }
            else
            {
                EditorGUILayout.PropertyField(m_UpdateEveryNFramesProp);
                EditorGUILayout.PropertyField(m_AutoPartitionLargeRigsProp);
                if (!m_AutoPartitionLargeRigsProp.boolValue)
                    EditorGUILayout.PropertyField(m_SkinningPartitionsProp);
                else
                    EditorGUILayout.HelpBox(
                        "Performance mode updates subsets on different frames and can visibly step animation.",
                        MessageType.Warning);
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Debug", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_TestModeProp, new GUIContent("Test Mode (Single Bone)"));
            if (m_TestModeProp.boolValue)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(m_TestBoneIndexProp, new GUIContent("Test Bone Index"));
                EditorGUILayout.HelpBox("Test mode: Only selected bone influences splats. Use for debugging.", MessageType.Info);
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Actions", EditorStyles.boldLabel);
            
            GaussianSplatSkin skin = (GaussianSplatSkin)target;
            
            // Debug helper
            if (GUILayout.Button("🔍 Debug: Print Bone & Splat Info"))
            {
                PrintDebugInfo(skin);
            }
            
            EditorGUILayout.Space();
            
            // Bone radius adjustment helper
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Quick Fix - Increase All Bone Radii:", GUILayout.Width(200));
            if (GUILayout.Button("×2", GUILayout.Width(40)))
            {
                MultiplyAllBoneRadii(skin, 2f);
            }
            if (GUILayout.Button("×5", GUILayout.Width(40)))
            {
                MultiplyAllBoneRadii(skin, 5f);
            }
            if (GUILayout.Button("×10", GUILayout.Width(40)))
            {
                MultiplyAllBoneRadii(skin, 10f);
            }
            EditorGUILayout.EndHorizontal();
            
            // Check if weights were transferred from Mixamo
            var injector = skin.GetComponent<MixamoWeightInjector>();
            bool hasTransferredWeights = injector != null;
            
            if (hasTransferredWeights)
            {
                EditorGUILayout.HelpBox("✓ TRANSFERRED MIXAMO WEIGHTS DETECTED!\nThese are the original bone weights from your Mixamo character.", MessageType.Info);
                
                GUI.backgroundColor = new Color(0.3f, 0.8f, 0.3f); // Green
                if (GUILayout.Button("✓ Inject Mixamo Weights", GUILayout.Height(30)))
                {
                    injector.ForceInject();
                    Debug.Log("Mixamo weights injected from transferred data.");
                }
                
                GUI.backgroundColor = new Color(1f, 0.7f, 0.3f); // Orange warning color
                if (GUILayout.Button("⚠ Recalculate Weights (Will Overwrite Mixamo)", GUILayout.Height(30)))
                {
                    if (EditorUtility.DisplayDialog("Overwrite Mixamo Weights?", 
                        "This will use newly calculated capsule weights instead of the transferred Mixamo weights. You can restore the transferred weights later.\n\nContinue?", 
                        "Yes, Overwrite", "Cancel"))
                    {
                        injector.DisableTransferredWeights();
                        EditorUtility.SetDirty(injector);
                        skin.RecalculateWeights();
                        Debug.LogWarning("Mixamo weights overwritten with calculated weights. Use 'Inject Mixamo Weights' to restore.");
                    }
                }
            }
            else
            {
                GUI.backgroundColor = Color.green;
                if (GUILayout.Button("Recalculate Weights", GUILayout.Height(30)))
                {
                    skin.RecalculateWeights();
                }
            }
            GUI.backgroundColor = Color.white;
            
            GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
            if (GUILayout.Button("Clear Weights"))
            {
                if (EditorUtility.DisplayDialog("Clear Weights", 
                    "This will clear all calculated weights. You'll need to recalculate them.\n\nContinue?", 
                    "Yes", "Cancel"))
                {
                    skin.ClearWeights();
                }
            }
            GUI.backgroundColor = Color.white;

            // Check skinning state and show appropriate help
            bool enableSkinning = m_EnableSkinningProp.boolValue;
            bool weightsCalculated = m_WeightsCalculatedProp.boolValue;
            bool hasComputeShader = m_SkinningComputeShaderProp.objectReferenceValue != null;
            
            if (!weightsCalculated)
            {
                EditorGUILayout.HelpBox(
                    "⚠️ STEP 1: Click 'Recalculate Weights' to bind splats to bones.\n" +
                    "Weights auto-recalculate on Play if needed.",
                    MessageType.Warning
                );
            }
            else if (!enableSkinning)
            {
                EditorGUILayout.HelpBox(
                    "⚠️ STEP 2: Check 'Enable Skinning' to activate deformation.\n" +
                    "Then enter Play mode to see animation.",
                    MessageType.Warning
                );
            }
            else if (!hasComputeShader)
            {
                EditorGUILayout.HelpBox(
                    "⚠️ Missing compute shader! Click 'Find Skinning Compute Shader' above.",
                    MessageType.Error
                );
            }
            else if (!Application.isPlaying)
            {
                EditorGUILayout.HelpBox(
                    "✓ Ready! Enter PLAY MODE to see skinning in action.\n\n" +
                    "NOTE: Skinning only works at runtime.",
                    MessageType.Info
                );
            }
            else
            {
                EditorGUILayout.HelpBox(
                    "✓ Skinning active!\n\n" +
                    "NOTE: Weights not saved (too large for Unity serialization).",
                    MessageType.Info
                );
            }

            serializedObject.ApplyModifiedProperties();
        }

        ComputeShader FindSkinningComputeShader()
        {
            // Search for GaussianSplatSkinning compute shader
            string[] guids = AssetDatabase.FindAssets("GaussianSplatSkinning t:ComputeShader");
            if (guids.Length > 0)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[0]);
                ComputeShader cs = AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                Debug.Log($"Found shader at: {path}");
                return cs;
            }
            
            // Fallback: search all compute shaders
            var allCompute = Resources.FindObjectsOfTypeAll<ComputeShader>();
            foreach (var cs in allCompute)
            {
                if (cs.name.Contains("Skinning") || cs.name.Contains("GaussianSplatSkinning"))
                {
                    Debug.Log($"Found shader via Resources: {cs.name}");
                    return cs;
                }
            }
            
            Debug.LogWarning("GaussianSplatSkinning.compute not found in project!");
            return null;
        }

        void MultiplyAllBoneRadii(GaussianSplatSkin skin, float multiplier)
        {
            if (skin == null || skin.rig == null || skin.rig.bones == null)
            {
                Debug.LogWarning("No rig or bones found!");
                return;
            }

            int boneCount = 0;
            foreach (var bone in skin.rig.bones)
            {
                if (bone != null)
                {
                    bone.radius *= multiplier;
                    EditorUtility.SetDirty(bone);
                    boneCount++;
                }
            }

            Debug.Log($"Multiplied radius of {boneCount} bones by {multiplier}x. Now click 'Recalculate Weights'!");
        }

        void PrintDebugInfo(GaussianSplatSkin skin)
        {
            if (skin == null)
            {
                Debug.LogError("No skin component!");
                return;
            }

            Debug.Log("=== GAUSSIAN SPLAT SKINNING DEBUG INFO ===");
            
            var renderer = skin.GetComponent<GaussianSplatRenderer>();
            if (renderer != null)
            {
                Debug.Log($"Renderer: {renderer.splatCount} splats");
                Debug.Log($"Renderer Position: {renderer.transform.position}");
                Debug.Log($"Renderer Rotation: {renderer.transform.rotation.eulerAngles}");
                Debug.Log($"Renderer Scale: {renderer.transform.localScale}");
            }
            
            if (skin.rig != null)
            {
                Debug.Log($"\nRig: {skin.rig.boneCount} bones");
                Debug.Log($"Rig Position: {skin.rig.transform.position}");
                Debug.Log($"Rig Rotation: {skin.rig.transform.rotation.eulerAngles}");
                
                if (skin.rig.bones != null && skin.rig.bones.Length > 0)
                {
                    Debug.Log("\nFirst 5 bones:");
                    for (int i = 0; i < Mathf.Min(5, skin.rig.bones.Length); i++)
                    {
                        var bone = skin.rig.bones[i];
                        if (bone != null)
                        {
                            Debug.Log($"  [{i}] {bone.name}:");
                            Debug.Log($"      Position: {bone.transform.position}");
                            Debug.Log($"      Radius: {bone.radius}");
                            Debug.Log($"      Has Bind Pose: {bone.hasBindPose}");
                        }
                    }
                }
            }
            else
            {
                Debug.LogWarning("No rig assigned!");
            }
            
            Debug.Log($"\nSkin Mode: {skin.skinMode}");
            Debug.Log($"Weights Calculated: {m_WeightsCalculatedProp.boolValue}");
            Debug.Log("===========================================");
        }
    }
}
