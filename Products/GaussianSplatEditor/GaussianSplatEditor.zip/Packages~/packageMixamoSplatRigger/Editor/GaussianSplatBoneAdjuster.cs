// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Inspector and Scene-view handles for GaussianSplatRig.
    /// Extends GaussianSplatRigEditor with Mixamo bone-adjustment tools.
    /// </summary>
    [CustomEditor(typeof(GaussianSplatRig))]
    public class GaussianSplatBoneAdjuster : GaussianSplatRigEditor
    {
        private bool m_ShowBoneHandles = true;
        private float m_HandleSize = 0.1f;
        
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();
            
            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("Bone Adjustment Tools", EditorStyles.boldLabel);
            
            m_ShowBoneHandles = EditorGUILayout.Toggle("Show Bone Position Handles", m_ShowBoneHandles);
            m_HandleSize = EditorGUILayout.Slider("Handle Size", m_HandleSize, 0.01f, 0.5f);
            
            EditorGUILayout.HelpBox("Enable 'Show Bone Position Handles' to move bones directly in the Scene view.\n" +
                "Click and drag the sphere handles to reposition bones.", MessageType.Info);
            
            GaussianSplatRig rig = (GaussianSplatRig)target;
            
            if (rig.bones != null && rig.bones.Length > 0)
            {
                EditorGUILayout.Space(5);
                EditorGUILayout.LabelField($"Bones in rig: {rig.boneCount}");
                
                if (GUILayout.Button("Select All Bones"))
                {
                    Selection.objects = System.Array.ConvertAll(rig.bones, bone => bone.gameObject);
                }
                
                if (GUILayout.Button("Reset to Bind Pose"))
                {
                    if (EditorUtility.DisplayDialog("Reset to Bind Pose", 
                        "Reset all bones to their bind pose positions?", "Yes", "Cancel"))
                    {
                        rig.ResetToBindPose();
                    }
                }
                
                if (GUILayout.Button("Recapture Bind Poses"))
                {
                    if (EditorUtility.DisplayDialog("Recapture Bind Poses", 
                        "Capture current bone positions as new bind poses?\n\n" +
                        "WARNING: This will overwrite existing bind poses!", "Yes", "Cancel"))
                    {
                        Undo.RecordObject(rig, "Recapture Bind Poses");
                        rig.CaptureBindPoses();
                        EditorUtility.SetDirty(rig);
                        Debug.Log("[Bone Adjuster] Recaptured bind poses for all bones");
                    }
                }
            }
            
            EditorGUILayout.Space(5);
            
            if (GUILayout.Button("Rebuild Rig"))
            {
                Undo.RecordObject(rig, "Rebuild Rig");
                rig.RebuildRig();
                EditorUtility.SetDirty(rig);
            }
        }
        
        private void OnSceneGUI()
        {
            if (!m_ShowBoneHandles) return;
            
            GaussianSplatRig rig = (GaussianSplatRig)target;
            if (rig.bones == null) return;
            
            // Draw position handles for each bone
            foreach (var bone in rig.bones)
            {
                if (bone == null) continue;
                
                EditorGUI.BeginChangeCheck();
                
                // Draw position handle
                Vector3 newPosition = Handles.PositionHandle(bone.transform.position, bone.transform.rotation);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(bone.transform, "Move Bone");
                    bone.transform.position = newPosition;
                    EditorUtility.SetDirty(bone.transform);
                }
                
                // Draw label
                Handles.Label(bone.transform.position + Vector3.up * 0.05f, bone.name, 
                    new GUIStyle() 
                    { 
                        normal = new GUIStyleState() { textColor = Color.white },
                        fontSize = 11,
                        fontStyle = FontStyle.Bold
                    });
                
                // Draw sphere at bone position
                Handles.color = new Color(0, 1, 1, 0.3f);
                Handles.SphereHandleCap(0, bone.transform.position, Quaternion.identity, m_HandleSize, EventType.Repaint);
            }
            
            // Draw skeleton lines
            Handles.color = Color.yellow;
            foreach (var bone in rig.bones)
            {
                if (bone == null || bone.transform.parent == null) continue;
                
                var parentBone = bone.transform.parent.GetComponent<GaussianSplatBone>();
                if (parentBone != null && System.Array.IndexOf(rig.bones, parentBone) >= 0)
                {
                    Handles.DrawLine(bone.transform.position, parentBone.transform.position);
                }
            }
        }
    }
}

