// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(SkinnedMeshToSplatConverter))]
    public class SkinnedMeshToSplatConverterEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            
            EditorGUILayout.Space();
            
            SkinnedMeshToSplatConverter converter = (SkinnedMeshToSplatConverter)target;
            
            if (GUILayout.Button("Convert Skinned Mesh to Splats", GUILayout.Height(40)))
            {
                converter.ConvertSkinnedMesh();
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "This component converts a SkinnedMeshRenderer with bone weights into Gaussian splats. " +
                "It will create a bone hierarchy and transfer weights for animation. " +
                "For creating assets, use Tools > Gaussian Splats > Convert Skinned Mesh to Animated Splats.",
                MessageType.Info
            );
        }
    }
    
    public static class SkinnedMeshToSplatContextMenu
    {
        [MenuItem("GameObject/Gaussian Splats/Convert Skinned Mesh to Animated Splat Asset", false, 10)]
        static void ConvertSkinnedMeshToSplatAsset(MenuCommand menuCommand)
        {
            GameObject go = menuCommand.context as GameObject;
            if (go != null)
            {
                SkinnedMeshRenderer skinnedMesh = go.GetComponent<SkinnedMeshRenderer>();
                if (skinnedMesh != null && skinnedMesh.sharedMesh != null)
                {
                    var window = EditorWindow.GetWindow<SkinnedMeshToGaussianSplatConverter>("Skinned Mesh to Splats");
                    SerializedObject so = new SerializedObject(window);
                    so.FindProperty("m_SourceSkinnedMesh").objectReferenceValue = skinnedMesh;
                    so.FindProperty("m_GameObjectName").stringValue = go.name + "_AnimatedSplat";
                    
                    // Auto-detect animator controller
                    var animator = go.GetComponent<Animator>();
                    if (animator != null && animator.runtimeAnimatorController != null)
                    {
                        so.FindProperty("m_AnimatorController").objectReferenceValue = animator.runtimeAnimatorController;
                    }
                    
                    so.ApplyModifiedProperties();
                    window.Show();
                }
                else
                {
                    Debug.LogWarning("Selected GameObject has no SkinnedMeshRenderer or Mesh!");
                }
            }
        }
        
        [MenuItem("GameObject/Gaussian Splats/Convert Skinned Mesh to Animated Splat Asset", true)]
        static bool ValidateConvertSkinnedMeshToSplatAsset()
        {
            GameObject go = Selection.activeGameObject;
            return go != null && go.GetComponent<SkinnedMeshRenderer>() != null;
        }
    }
}

