// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;
using System.Collections.Generic;
using System.Linq;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Editor tool to help swap Gaussian splat characters and align rigs to new models
    /// </summary>
    public class GaussianSplatCharacterSwapper : EditorWindow
    {
        private GaussianSplatRenderer m_TargetRenderer;
        private GaussianSplatRig m_TargetRig;
        private GaussianSplatSkin m_TargetSkin;
        
        private GaussianSplatAsset m_NewCharacterAsset;
        private Vector3 m_CharacterRotation = new Vector3(-90, 0, 0);
        
        private bool m_ShowDebugInfo = false;
        private Vector2 m_ScrollPos;
        
        // Analyzed splat data
        private Vector3 m_SplatCenter;
        private Vector3 m_SplatMin;
        private Vector3 m_SplatMax;
        private Dictionary<string, Vector3> m_SuggestedBonePositions = new Dictionary<string, Vector3>();
        private bool m_AnalysisComplete = false;

        [MenuItem("Tools/Gaussian Splats/Character Swapper")]
        public static void ShowWindow()
        {
            var window = GetWindow<GaussianSplatCharacterSwapper>("Character Swapper");
            window.minSize = new Vector2(400, 600);
            window.Show();
        }

        private void OnEnable()
        {
            // Try to find selected character
            if (Selection.activeGameObject != null)
            {
                m_TargetRenderer = Selection.activeGameObject.GetComponentInChildren<GaussianSplatRenderer>();
                m_TargetRig = Selection.activeGameObject.GetComponentInChildren<GaussianSplatRig>();
                m_TargetSkin = Selection.activeGameObject.GetComponentInChildren<GaussianSplatSkin>();
            }
        }

        private void OnGUI()
        {
            m_ScrollPos = EditorGUILayout.BeginScrollView(m_ScrollPos);
            
            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("Gaussian Splat Character Swapper", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("This tool helps you swap a Gaussian splat character and align the rig to the new model.", MessageType.Info);
            
            EditorGUILayout.Space(10);
            DrawSetupSection();
            
            EditorGUILayout.Space(10);
            DrawSwapSection();
            
            EditorGUILayout.Space(10);
            DrawAlignmentSection();
            
            EditorGUILayout.Space(10);
            DrawWeightSection();
            
            if (m_ShowDebugInfo)
            {
                EditorGUILayout.Space(10);
                DrawDebugSection();
            }
            
            EditorGUILayout.EndScrollView();
        }

        private void DrawSetupSection()
        {
            EditorGUILayout.LabelField("1. Setup", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            m_TargetRenderer = (GaussianSplatRenderer)EditorGUILayout.ObjectField("Current Renderer", m_TargetRenderer, typeof(GaussianSplatRenderer), true);
            m_TargetRig = (GaussianSplatRig)EditorGUILayout.ObjectField("Current Rig", m_TargetRig, typeof(GaussianSplatRig), true);
            m_TargetSkin = (GaussianSplatSkin)EditorGUILayout.ObjectField("Current Skin", m_TargetSkin, typeof(GaussianSplatSkin), true);
            
            if (EditorGUI.EndChangeCheck())
            {
                m_AnalysisComplete = false;
            }
            
            if (GUILayout.Button("Auto-Find Components in Selection"))
            {
                AutoFindComponents();
            }
            
            if (m_TargetRenderer != null && m_TargetRenderer.asset != null)
            {
                EditorGUILayout.HelpBox($"Current Character: {m_TargetRenderer.asset.name}\nSplats: {m_TargetRenderer.splatCount:N0}", MessageType.None);
            }
        }

        private void DrawSwapSection()
        {
            EditorGUILayout.LabelField("2. Swap Character", EditorStyles.boldLabel);
            
            m_NewCharacterAsset = (GaussianSplatAsset)EditorGUILayout.ObjectField("New Character Asset", m_NewCharacterAsset, typeof(GaussianSplatAsset), false);
            
            EditorGUI.BeginDisabledGroup(m_TargetRenderer == null || m_NewCharacterAsset == null);
            
            if (GUILayout.Button("Swap Character Asset", GUILayout.Height(30)))
            {
                SwapCharacterAsset();
            }
            
            EditorGUI.EndDisabledGroup();
            
            if (m_NewCharacterAsset != null)
            {
                EditorGUILayout.HelpBox($"New Character: {m_NewCharacterAsset.name}\nSplats: {m_NewCharacterAsset.splatCount:N0}", MessageType.None);
            }
        }

        private void DrawAlignmentSection()
        {
            EditorGUILayout.LabelField("3. Align Rig", EditorStyles.boldLabel);
            
            m_CharacterRotation = EditorGUILayout.Vector3Field("Character Rotation", m_CharacterRotation);
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Rotate -90 X"))
            {
                m_CharacterRotation.x = -90;
            }
            if (GUILayout.Button("Rotate 90 Y"))
            {
                m_CharacterRotation.y = 90;
            }
            if (GUILayout.Button("Reset"))
            {
                m_CharacterRotation = Vector3.zero;
            }
            EditorGUILayout.EndHorizontal();
            
            EditorGUI.BeginDisabledGroup(m_TargetRenderer == null);
            
            if (GUILayout.Button("Apply Rotation to Renderer"))
            {
                ApplyRotation();
            }
            
            EditorGUI.EndDisabledGroup();
            
            EditorGUILayout.Space(5);
            
            EditorGUI.BeginDisabledGroup(m_TargetRenderer == null || m_TargetRig == null);
            
            if (GUILayout.Button("Analyze Splat Distribution", GUILayout.Height(30)))
            {
                AnalyzeSplatDistribution();
            }
            
            if (m_AnalysisComplete)
            {
                EditorGUILayout.HelpBox($"Analysis Complete!\n" +
                    $"Center: {m_SplatCenter}\n" +
                    $"Bounds: {m_SplatMax - m_SplatMin}\n" +
                    $"Suggested Bones: {m_SuggestedBonePositions.Count}", MessageType.None);
                
                if (GUILayout.Button("Auto-Position Bones to Match Splats", GUILayout.Height(30)))
                {
                    AutoPositionBones();
                }
                
                if (GUILayout.Button("Align Rig to Splat Center"))
                {
                    AlignRigToCenter();
                }
                
                EditorGUILayout.Space(5);
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Auto-Set Bone Radii"))
                {
                    AutoSetBoneRadii();
                }
                if (GUILayout.Button("Scale All Radii x2"))
                {
                    ScaleAllBoneRadii(2.0f);
                }
                if (GUILayout.Button("Scale All Radii ÷2"))
                {
                    ScaleAllBoneRadii(0.5f);
                }
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUI.EndDisabledGroup();
            
            EditorGUILayout.Space(5);
            
            if (GUILayout.Button("Visualize Bone Positions"))
            {
                VisualizeBones();
            }
        }

        private void DrawWeightSection()
        {
            EditorGUILayout.LabelField("4. Recalculate Weights", EditorStyles.boldLabel);
            
            EditorGUI.BeginDisabledGroup(m_TargetSkin == null);
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Clear Old Weights"))
            {
                ClearWeights();
            }
            if (GUILayout.Button("Recalculate Weights"))
            {
                RecalculateWeights();
            }
            EditorGUILayout.EndHorizontal();
            
            if (GUILayout.Button("Complete Swap & Setup", GUILayout.Height(40)))
            {
                CompleteSwapAndSetup();
            }
            
            EditorGUI.EndDisabledGroup();
        }

        private void DrawDebugSection()
        {
            EditorGUILayout.LabelField("Debug Info", EditorStyles.boldLabel);
            
            if (m_TargetRig != null && m_TargetRig.bones != null)
            {
                EditorGUILayout.LabelField($"Bones in Rig: {m_TargetRig.boneCount}");
                foreach (var bone in m_TargetRig.bones)
                {
                    if (bone != null)
                    {
                        EditorGUILayout.LabelField($"  - {bone.name}: {bone.transform.position}");
                    }
                }
            }
            
            if (m_SuggestedBonePositions.Count > 0)
            {
                EditorGUILayout.LabelField("Suggested Positions:");
                foreach (var kvp in m_SuggestedBonePositions)
                {
                    EditorGUILayout.LabelField($"  - {kvp.Key}: {kvp.Value}");
                }
            }
        }

        // ===== IMPLEMENTATION METHODS =====

        private void AutoFindComponents()
        {
            if (Selection.activeGameObject != null)
            {
                var go = Selection.activeGameObject;
                
                if (m_TargetRenderer == null)
                    m_TargetRenderer = go.GetComponentInChildren<GaussianSplatRenderer>();
                
                if (m_TargetRig == null)
                    m_TargetRig = go.GetComponentInChildren<GaussianSplatRig>();
                
                if (m_TargetSkin == null)
                    m_TargetSkin = go.GetComponentInChildren<GaussianSplatSkin>();
                
                if (m_TargetRenderer != null || m_TargetRig != null || m_TargetSkin != null)
                {
                    Debug.Log("[Character Swapper] Found components in selection");
                }
                else
                {
                    EditorUtility.DisplayDialog("Not Found", "Could not find Gaussian Splat components in selected GameObject.", "OK");
                }
            }
        }

        private void SwapCharacterAsset()
        {
            if (m_TargetRenderer == null || m_NewCharacterAsset == null) return;
            
            Undo.RecordObject(m_TargetRenderer, "Swap Character Asset");
            
            var oldAsset = m_TargetRenderer.asset;
            m_TargetRenderer.m_Asset = m_NewCharacterAsset;
            
            EditorUtility.SetDirty(m_TargetRenderer);
            
            Debug.Log($"[Character Swapper] Swapped asset from '{oldAsset?.name}' to '{m_NewCharacterAsset.name}'");
            
            m_AnalysisComplete = false;
            
            EditorUtility.DisplayDialog("Asset Swapped", 
                $"Character asset has been swapped to '{m_NewCharacterAsset.name}'.\n\n" +
                "Next steps:\n" +
                "1. Apply rotation if needed\n" +
                "2. Analyze splat distribution\n" +
                "3. Auto-position bones\n" +
                "4. Recalculate weights", "OK");
        }

        private void ApplyRotation()
        {
            if (m_TargetRenderer == null) return;
            
            Undo.RecordObject(m_TargetRenderer.transform, "Apply Character Rotation");
            
            m_TargetRenderer.transform.localEulerAngles = m_CharacterRotation;
            
            EditorUtility.SetDirty(m_TargetRenderer.transform);
            
            Debug.Log($"[Character Swapper] Applied rotation {m_CharacterRotation} to renderer");
        }

        private void AnalyzeSplatDistribution()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                EditorUtility.DisplayDialog("Error", "No valid renderer or asset found.", "OK");
                return;
            }
            
            EditorUtility.DisplayProgressBar("Analyzing", "Reading splat positions...", 0.1f);
            
            try
            {
                var positions = GetSplatPositions(m_TargetRenderer);
                if (positions == null || positions.Length == 0)
                {
                    EditorUtility.DisplayDialog("Error", "Could not read splat positions.", "OK");
                    return;
                }
                
                EditorUtility.DisplayProgressBar("Analyzing", "Computing bounds...", 0.3f);
                
                // Calculate bounds
                m_SplatMin = positions[0];
                m_SplatMax = positions[0];
                Vector3 sum = Vector3.zero;
                
                foreach (var pos in positions)
                {
                    m_SplatMin = Vector3.Min(m_SplatMin, pos);
                    m_SplatMax = Vector3.Max(m_SplatMax, pos);
                    sum += pos;
                }
                
                m_SplatCenter = sum / positions.Length;
                
                EditorUtility.DisplayProgressBar("Analyzing", "Computing bone positions...", 0.6f);
                
                // Compute suggested bone positions based on typical humanoid proportions
                ComputeHumanoidBonePositions(positions);
                
                EditorUtility.DisplayProgressBar("Analyzing", "Complete!", 1.0f);
                
                m_AnalysisComplete = true;
                
                Debug.Log($"[Character Swapper] Analysis complete:\n" +
                    $"  Splats: {positions.Length:N0}\n" +
                    $"  Center: {m_SplatCenter}\n" +
                    $"  Bounds: {m_SplatMax - m_SplatMin}\n" +
                    $"  Suggested bones: {m_SuggestedBonePositions.Count}");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private Vector3[] GetSplatPositions(GaussianSplatRenderer renderer)
        {
            var asset = renderer.asset;
            if (asset == null) return null;
            
            int splatCount = renderer.splatCount;
            Vector3[] positions = new Vector3[splatCount];
            
            var gpuPosData = renderer.GpuPosData;
            if (gpuPosData == null) return null;
            
            int posStride = (int)(asset.posData.dataSize / asset.splatCount);
            int posInts = posStride / 4;
            
            uint[] posData = new uint[splatCount * posInts];
            gpuPosData.GetData(posData);
            
            for (int i = 0; i < splatCount; i++)
            {
                Vector3 localPos = DecodeSplatPosition(posData, i, posInts, asset);
                positions[i] = renderer.transform.TransformPoint(localPos);
            }
            
            return positions;
        }

        private Vector3 DecodeSplatPosition(uint[] posData, int splatIndex, int posInts, GaussianSplatAsset asset)
        {
            int offset = splatIndex * posInts;
            
            switch (asset.posFormat)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    return new Vector3(
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 1]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 2]), 0)
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm16:
                    ushort x = (ushort)(posData[offset] & 0xFFFF);
                    ushort y = (ushort)((posData[offset] >> 16) & 0xFFFF);
                    ushort z = (ushort)(posData[offset + 1] & 0xFFFF);
                    
                    return new Vector3(
                        Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, x / 65535.0f),
                        Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, y / 65535.0f),
                        Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, z / 65535.0f)
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm11:
                    uint packed = posData[offset];
                    float nx = (packed & 0x7FF) / 2047.0f;
                    float ny = ((packed >> 11) & 0x3FF) / 1023.0f;
                    float nz = ((packed >> 21) & 0x7FF) / 2047.0f;
                    
                    return new Vector3(
                        Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, nx),
                        Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, ny),
                        Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, nz)
                    );
                    
                default:
                    return Vector3.zero;
            }
        }

        private void ComputeHumanoidBonePositions(Vector3[] positions)
        {
            m_SuggestedBonePositions.Clear();
            
            Vector3 size = m_SplatMax - m_SplatMin;
            Vector3 center = m_SplatCenter;
            
            // Analyze splat density to find actual body regions
            var densityCenters = AnalyzeSplatDensity(positions);
            
            // Use density-based positioning if available, otherwise fall back to proportions
            float bottom = m_SplatMin.y;
            float top = m_SplatMax.y;
            float height = size.y;
            
            // Analyze horizontal slices to find limb positions
            var leftArmCenter = FindDensityCenter(positions, new Bounds(
                new Vector3(m_SplatMin.x + size.x * 0.1f, center.y, center.z),
                new Vector3(size.x * 0.3f, size.y * 0.5f, size.z)
            ));
            
            var rightArmCenter = FindDensityCenter(positions, new Bounds(
                new Vector3(m_SplatMax.x - size.x * 0.1f, center.y, center.z),
                new Vector3(size.x * 0.3f, size.y * 0.5f, size.z)
            ));
            
            var leftLegCenter = FindDensityCenter(positions, new Bounds(
                new Vector3(center.x - size.x * 0.15f, bottom + size.y * 0.25f, center.z),
                new Vector3(size.x * 0.2f, size.y * 0.4f, size.z)
            ));
            
            var rightLegCenter = FindDensityCenter(positions, new Bounds(
                new Vector3(center.x + size.x * 0.15f, bottom + size.y * 0.25f, center.z),
                new Vector3(size.x * 0.2f, size.y * 0.4f, size.z)
            ));
            
            var torsoCenter = FindDensityCenter(positions, new Bounds(
                new Vector3(center.x, center.y, center.z),
                new Vector3(size.x * 0.3f, size.y * 0.5f, size.z)
            ));
            
            // SPINE - use torso density center
            Vector3 spineBase = new Vector3(torsoCenter.x, bottom + height * 0.52f, torsoCenter.z);
            m_SuggestedBonePositions["Hips"] = spineBase;
            m_SuggestedBonePositions["Spine"] = new Vector3(torsoCenter.x, bottom + height * 0.60f, torsoCenter.z);
            m_SuggestedBonePositions["Spine1"] = new Vector3(torsoCenter.x, bottom + height * 0.68f, torsoCenter.z);
            m_SuggestedBonePositions["Spine2"] = new Vector3(torsoCenter.x, bottom + height * 0.76f, torsoCenter.z);
            m_SuggestedBonePositions["Chest"] = new Vector3(torsoCenter.x, bottom + height * 0.76f, torsoCenter.z);
            m_SuggestedBonePositions["Neck"] = new Vector3(torsoCenter.x, bottom + height * 0.88f, torsoCenter.z);
            m_SuggestedBonePositions["Head"] = new Vector3(torsoCenter.x, bottom + height * 0.95f, torsoCenter.z);
            
            // ARMS - based on actual arm density
            float shoulderY = bottom + height * 0.78f;
            float elbowY = bottom + height * 0.65f;
            float wristY = bottom + height * 0.52f;
            
            // Use detected arm centers for X positioning
            float leftArmX = leftArmCenter.x;
            float rightArmX = rightArmCenter.x;
            
            // Shoulders (closer to center)
            m_SuggestedBonePositions["LeftShoulder"] = new Vector3(torsoCenter.x - size.x * 0.15f, shoulderY, torsoCenter.z);
            m_SuggestedBonePositions["RightShoulder"] = new Vector3(torsoCenter.x + size.x * 0.15f, shoulderY, torsoCenter.z);
            
            // Upper arms
            m_SuggestedBonePositions["LeftArm"] = new Vector3(leftArmX * 0.7f + torsoCenter.x * 0.3f, shoulderY - 0.05f, torsoCenter.z);
            m_SuggestedBonePositions["RightArm"] = new Vector3(rightArmX * 0.7f + torsoCenter.x * 0.3f, shoulderY - 0.05f, torsoCenter.z);
            
            // Forearms (mid-arm)
            m_SuggestedBonePositions["LeftForeArm"] = new Vector3(leftArmX, elbowY, torsoCenter.z);
            m_SuggestedBonePositions["RightForeArm"] = new Vector3(rightArmX, elbowY, torsoCenter.z);
            
            // Hands (outer edge)
            m_SuggestedBonePositions["LeftHand"] = new Vector3(leftArmX * 1.1f, wristY, torsoCenter.z);
            m_SuggestedBonePositions["RightHand"] = new Vector3(rightArmX * 1.1f, wristY, torsoCenter.z);
            
            // LEGS - based on actual leg density
            float hipY = bottom + height * 0.52f;
            float kneeY = bottom + height * 0.28f;
            float ankleY = bottom + height * 0.05f;
            
            float leftLegX = leftLegCenter.x;
            float rightLegX = rightLegCenter.x;
            
            // Hips
            m_SuggestedBonePositions["LeftUpLeg"] = new Vector3(leftLegX, hipY, torsoCenter.z);
            m_SuggestedBonePositions["RightUpLeg"] = new Vector3(rightLegX, hipY, torsoCenter.z);
            
            // Knees
            m_SuggestedBonePositions["LeftLeg"] = new Vector3(leftLegX, kneeY, torsoCenter.z);
            m_SuggestedBonePositions["RightLeg"] = new Vector3(rightLegX, kneeY, torsoCenter.z);
            
            // Feet
            m_SuggestedBonePositions["LeftFoot"] = new Vector3(leftLegX, ankleY, torsoCenter.z);
            m_SuggestedBonePositions["RightFoot"] = new Vector3(rightLegX, ankleY, torsoCenter.z);
            
            Debug.Log($"[Character Swapper] Density Analysis:\n" +
                $"  Left Arm Center: {leftArmCenter}\n" +
                $"  Right Arm Center: {rightArmCenter}\n" +
                $"  Left Leg Center: {leftLegCenter}\n" +
                $"  Right Leg Center: {rightLegCenter}\n" +
                $"  Torso Center: {torsoCenter}");
        }
        
        private Vector3 FindDensityCenter(Vector3[] positions, Bounds region)
        {
            Vector3 sum = Vector3.zero;
            int count = 0;
            
            foreach (var pos in positions)
            {
                if (region.Contains(pos))
                {
                    sum += pos;
                    count++;
                }
            }
            
            if (count > 0)
                return sum / count;
            
            // Fallback to region center if no splats found
            return region.center;
        }
        
        private Dictionary<string, Vector3> AnalyzeSplatDensity(Vector3[] positions)
        {
            // Future: Could do more sophisticated clustering here
            // For now, return empty and let the main function handle it
            return new Dictionary<string, Vector3>();
        }

        private void AutoPositionBones()
        {
            if (m_TargetRig == null || m_SuggestedBonePositions.Count == 0)
            {
                EditorUtility.DisplayDialog("Error", "No rig or analysis data available.", "OK");
                return;
            }
            
            Undo.SetCurrentGroupName("Auto-Position Bones");
            int undoGroup = Undo.GetCurrentGroup();
            
            int movedCount = 0;
            
            foreach (var bone in m_TargetRig.bones)
            {
                if (bone == null) continue;
                
                // Try to match bone name with suggested position
                foreach (var kvp in m_SuggestedBonePositions)
                {
                    if (bone.name.Contains(kvp.Key))
                    {
                        Undo.RecordObject(bone.transform, "Move Bone");
                        bone.transform.position = kvp.Value;
                        EditorUtility.SetDirty(bone.transform);
                        movedCount++;
                        break;
                    }
                }
            }
            
            Undo.CollapseUndoOperations(undoGroup);
            
            Debug.Log($"[Character Swapper] Auto-positioned {movedCount} bones");
            
            EditorUtility.DisplayDialog("Bones Positioned", 
                $"Moved {movedCount} bones to suggested positions.\n\n" +
                "Please review bone positions and adjust manually if needed.\n" +
                "Then recalculate weights.", "OK");
        }

        private void AlignRigToCenter()
        {
            if (m_TargetRig == null)
            {
                EditorUtility.DisplayDialog("Error", "No rig found.", "OK");
                return;
            }
            
            Undo.RecordObject(m_TargetRig.transform, "Align Rig to Center");
            
            m_TargetRig.transform.position = m_SplatCenter;
            
            EditorUtility.SetDirty(m_TargetRig.transform);
            
            Debug.Log($"[Character Swapper] Aligned rig to splat center: {m_SplatCenter}");
        }

        private void VisualizeBones()
        {
            if (m_TargetRig == null) return;
            
            Selection.activeGameObject = m_TargetRig.gameObject;
            SceneView.lastActiveSceneView.FrameSelected();
        }

        private void AutoSetBoneRadii()
        {
            if (m_TargetRig == null || m_TargetRenderer == null)
            {
                EditorUtility.DisplayDialog("Error", "No rig or renderer found.", "OK");
                return;
            }
            
            Undo.SetCurrentGroupName("Auto-Set Bone Radii");
            int undoGroup = Undo.GetCurrentGroup();
            
            Vector3 size = m_SplatMax - m_SplatMin;
            float avgSize = (size.x + size.y + size.z) / 3f;
            
            // Calculate appropriate radii based on character size
            float headRadius = avgSize * 0.15f;
            float torsoRadius = avgSize * 0.20f;
            float armRadius = avgSize * 0.08f;
            float legRadius = avgSize * 0.10f;
            float handFootRadius = avgSize * 0.06f;
            
            int updatedCount = 0;
            
            foreach (var bone in m_TargetRig.bones)
            {
                if (bone == null) continue;
                
                Undo.RecordObject(bone, "Set Bone Radius");
                
                string boneName = bone.name.ToLower();
                
                if (boneName.Contains("head"))
                    bone.radius = headRadius;
                else if (boneName.Contains("spine") || boneName.Contains("chest") || boneName.Contains("hips"))
                    bone.radius = torsoRadius;
                else if (boneName.Contains("hand") || boneName.Contains("foot"))
                    bone.radius = handFootRadius;
                else if (boneName.Contains("arm") || boneName.Contains("shoulder"))
                    bone.radius = armRadius;
                else if (boneName.Contains("leg") || boneName.Contains("thigh"))
                    bone.radius = legRadius;
                else
                    bone.radius = avgSize * 0.10f; // Default
                
                EditorUtility.SetDirty(bone);
                updatedCount++;
            }
            
            Undo.CollapseUndoOperations(undoGroup);
            
            Debug.Log($"[Character Swapper] Auto-set radii for {updatedCount} bones based on character size");
            EditorUtility.DisplayDialog("Radii Set", 
                $"Set bone radii for {updatedCount} bones.\n\n" +
                $"Character size: {avgSize:F2}\n" +
                "You can adjust individual bone radii in the Inspector.", "OK");
        }

        private void ScaleAllBoneRadii(float scale)
        {
            if (m_TargetRig == null)
            {
                EditorUtility.DisplayDialog("Error", "No rig found.", "OK");
                return;
            }
            
            Undo.SetCurrentGroupName($"Scale Bone Radii x{scale}");
            int undoGroup = Undo.GetCurrentGroup();
            
            int updatedCount = 0;
            
            foreach (var bone in m_TargetRig.bones)
            {
                if (bone == null) continue;
                
                Undo.RecordObject(bone, "Scale Bone Radius");
                bone.radius *= scale;
                EditorUtility.SetDirty(bone);
                updatedCount++;
            }
            
            Undo.CollapseUndoOperations(undoGroup);
            
            Debug.Log($"[Character Swapper] Scaled {updatedCount} bone radii by {scale}x");
        }

        private void ClearWeights()
        {
            if (m_TargetSkin == null) return;
            
            if (EditorUtility.DisplayDialog("Clear Weights", 
                "This will clear all calculated bone weights. Continue?", "Yes", "Cancel"))
            {
                m_TargetSkin.ClearWeights();
                Debug.Log("[Character Swapper] Cleared weights");
            }
        }

        private void RecalculateWeights()
        {
            if (m_TargetSkin == null) return;
            
            if (EditorUtility.DisplayDialog("Recalculate Weights", 
                "This will recalculate bone weights for all splats. This may take a moment. Continue?", "Yes", "Cancel"))
            {
                EditorUtility.DisplayProgressBar("Calculating", "Recalculating bone weights...", 0.5f);
                
                try
                {
                    m_TargetSkin.RecalculateWeights();
                    Debug.Log("[Character Swapper] Weights recalculated");
                    
                    EditorUtility.DisplayDialog("Complete", 
                        "Bone weights have been recalculated!\n\n" +
                        "Enable 'Enable Skinning' on the GaussianSplatSkin component and test in Play mode.", "OK");
                }
                finally
                {
                    EditorUtility.ClearProgressBar();
                }
            }
        }

        private void CompleteSwapAndSetup()
        {
            if (!EditorUtility.DisplayDialog("Complete Setup", 
                "This will perform all steps automatically:\n\n" +
                "1. Swap character asset\n" +
                "2. Apply rotation\n" +
                "3. Analyze splat distribution\n" +
                "4. Auto-position bones\n" +
                "5. Recalculate weights\n\n" +
                "Continue?", "Yes", "Cancel"))
            {
                return;
            }
            
            try
            {
                EditorUtility.DisplayProgressBar("Character Swap", "Step 1/5: Swapping asset...", 0.0f);
                if (m_NewCharacterAsset != null)
                    SwapCharacterAsset();
                
                EditorUtility.DisplayProgressBar("Character Swap", "Step 2/5: Applying rotation...", 0.2f);
                ApplyRotation();
                
                EditorUtility.DisplayProgressBar("Character Swap", "Step 3/5: Analyzing splat distribution...", 0.4f);
                AnalyzeSplatDistribution();
                
                EditorUtility.DisplayProgressBar("Character Swap", "Step 4/5: Positioning bones...", 0.6f);
                AutoPositionBones();
                
                EditorUtility.DisplayProgressBar("Character Swap", "Step 5/5: Recalculating weights...", 0.8f);
                if (m_TargetSkin != null)
                {
                    m_TargetSkin.RecalculateWeights();
                }
                
                EditorUtility.DisplayProgressBar("Character Swap", "Complete!", 1.0f);
                
                Debug.Log("[Character Swapper] Complete swap and setup finished!");
                
                EditorUtility.DisplayDialog("Complete!", 
                    "Character swap and rig setup complete!\n\n" +
                    "Next steps:\n" +
                    "1. Review bone positions in Scene view\n" +
                    "2. Adjust bone radii if needed\n" +
                    "3. Enable 'Enable Skinning' on GaussianSplatSkin\n" +
                    "4. Test in Play mode", "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
    }
}

