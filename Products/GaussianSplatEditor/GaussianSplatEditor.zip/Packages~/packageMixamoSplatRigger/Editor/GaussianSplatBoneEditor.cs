// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatBone))]
    public class GaussianSplatBoneEditor : UnityEditor.Editor
    {
        SerializedProperty m_RadiusProp;
        SerializedProperty m_FalloffProp;
        SerializedProperty m_ShowGizmoProp;
        SerializedProperty m_GizmoColorProp;

        void OnEnable()
        {
            m_RadiusProp = serializedObject.FindProperty("m_Radius");
            m_FalloffProp = serializedObject.FindProperty("m_Falloff");
            m_ShowGizmoProp = serializedObject.FindProperty("m_ShowGizmo");
            m_GizmoColorProp = serializedObject.FindProperty("m_GizmoColor");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            GaussianSplatBone bone = (GaussianSplatBone)target;

            EditorGUILayout.LabelField("Influence", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_RadiusProp);
            EditorGUILayout.HelpBox("Radius determines which splats are influenced by this bone", MessageType.Info);
            
            EditorGUILayout.PropertyField(m_FalloffProp);
            EditorGUILayout.HelpBox("Falloff creates smooth transition at edge of influence sphere", MessageType.Info);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Debug", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_ShowGizmoProp);
            EditorGUILayout.PropertyField(m_GizmoColorProp);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Info", EditorStyles.boldLabel);
            
            EditorGUI.BeginDisabledGroup(true);
            EditorGUILayout.Toggle("Has Bind Pose", bone.hasBindPose);
            if (bone.hasBindPose)
            {
                EditorGUILayout.Vector3Field("Bind Position", bone.bindPose.GetColumn(3));
            }
            EditorGUILayout.Vector3Field("Current Position", bone.transform.position);
            EditorGUILayout.Vector3Field("Current Rotation", bone.transform.rotation.eulerAngles);
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.Space();
            
            if (GUILayout.Button("Capture Bind Pose"))
            {
                bone.CaptureBindPose();
                Debug.Log($"Captured bind pose for bone '{bone.name}'");
            }

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "Gizmo Display:\n" +
                "• Yellow lines = Bone connections (always visible)\n" +
                "• Small cyan dot = Bone position\n" +
                "• Cyan/Yellow spheres = Influence radius (when bone selected)\n\n" +
                "Select this bone to see its influence radius.",
                MessageType.None
            );

            serializedObject.ApplyModifiedProperties();
        }
    }
}

