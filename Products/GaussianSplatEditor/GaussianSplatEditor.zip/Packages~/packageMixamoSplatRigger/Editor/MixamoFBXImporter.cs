// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Import Mixamo FBX files and convert to animated Gaussian splats
    /// </summary>
    public class MixamoFBXImporter : EditorWindow
    {
        [SerializeField] GameObject m_MixamoFBX;
        [SerializeField] bool m_AutoConvert = true;
        [SerializeField] bool m_UseRecommendedSettings = true;
        
        string m_ErrorMessage;
        Vector2 m_ScrollPosition;

        [MenuItem("Tools/Gaussian Splats/Import Mixamo FBX")]
        public static void ShowWindow()
        {
            var window = GetWindow<MixamoFBXImporter>("Mixamo FBX to Splats");
            window.minSize = new Vector2(400, 300);
            window.Show();
        }

        void OnGUI()
        {
            m_ScrollPosition = EditorGUILayout.BeginScrollView(m_ScrollPosition);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Import Mixamo FBX to Animated Splats", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Import Mixamo FBX characters with animations and convert to Gaussian splats", MessageType.Info);
            EditorGUILayout.Space();
            
            EditorGUILayout.LabelField("Mixamo FBX", EditorStyles.boldLabel);
            m_MixamoFBX = (GameObject)EditorGUILayout.ObjectField("FBX Prefab", m_MixamoFBX, typeof(GameObject), false);
            
            if (m_MixamoFBX != null)
            {
                // Show FBX info
                var skinnedMesh = m_MixamoFBX.GetComponentInChildren<SkinnedMeshRenderer>();
                if (skinnedMesh != null)
                {
                    bool isMixamo = MixamoRigImporter.IsMixamoRig(skinnedMesh);
                    
                    if (isMixamo)
                    {
                        EditorGUILayout.HelpBox("✓ Valid Mixamo rig detected", MessageType.Info);
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("⚠ Not a standard Mixamo rig", MessageType.Warning);
                    }
                    
                    EditorGUILayout.LabelField("Mesh", $"{skinnedMesh.sharedMesh.vertexCount:N0} vertices");
                    EditorGUILayout.LabelField("Bones", $"{skinnedMesh.bones.Length} bones");
                    
                    // Show animations
                    string fbxPath = AssetDatabase.GetAssetPath(m_MixamoFBX);
                    if (!string.IsNullOrEmpty(fbxPath))
                    {
                        AnimationClip[] clips = MixamoRigImporter.GetAnimationsFromMixamoFBX(fbxPath);
                        if (clips.Length > 0)
                        {
                            EditorGUILayout.LabelField("Animations", $"{clips.Length} clips found");
                            EditorGUI.indentLevel++;
                            foreach (var clip in clips)
                            {
                                EditorGUILayout.LabelField($"• {clip.name}", $"{clip.length:F2}s");
                            }
                            EditorGUI.indentLevel--;
                        }
                        else
                        {
                            EditorGUILayout.HelpBox("No animations found in FBX", MessageType.Warning);
                        }
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("No SkinnedMeshRenderer found in FBX", MessageType.Error);
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Import Options", EditorStyles.boldLabel);
            m_AutoConvert = EditorGUILayout.Toggle("Auto Convert", m_AutoConvert);
            m_UseRecommendedSettings = EditorGUILayout.Toggle("Use Recommended Settings", m_UseRecommendedSettings);
            
            EditorGUILayout.Space();
            if (!string.IsNullOrEmpty(m_ErrorMessage))
            {
                EditorGUILayout.HelpBox(m_ErrorMessage, MessageType.Error);
            }
            
            EditorGUI.BeginDisabledGroup(m_MixamoFBX == null);
            if (GUILayout.Button("Open Converter Window", GUILayout.Height(40)))
            {
                OpenConverterWindow();
            }
            EditorGUI.EndDisabledGroup();
            
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "Workflow:\n" +
                "1. Download character + animations from Mixamo.com\n" +
                "2. Import FBX to Unity\n" +
                "3. Select the FBX prefab here\n" +
                "4. Click 'Open Converter Window'\n" +
                "5. Adjust settings and convert",
                MessageType.Info
            );
            
            EditorGUILayout.EndScrollView();
        }

        void OpenConverterWindow()
        {
            if (m_MixamoFBX == null)
            {
                m_ErrorMessage = "Please select a Mixamo FBX prefab";
                return;
            }
            
            var skinnedMesh = m_MixamoFBX.GetComponentInChildren<SkinnedMeshRenderer>();
            if (skinnedMesh == null)
            {
                m_ErrorMessage = "No SkinnedMeshRenderer found in FBX";
                return;
            }
            
            // Open converter window with Mixamo FBX pre-loaded
            var window = GetWindow<SkinnedMeshToGaussianSplatConverter>("Skinned Mesh to Splats");
            SerializedObject so = new SerializedObject(window);
            so.FindProperty("m_SourceSkinnedMesh").objectReferenceValue = skinnedMesh;
            so.FindProperty("m_GameObjectName").stringValue = m_MixamoFBX.name + "_Splat";
            so.FindProperty("m_IsMixamoRig").boolValue = true;
            so.FindProperty("m_UseMixamoPresets").boolValue = m_UseRecommendedSettings;
            
            // Get animations from FBX
            string fbxPath = AssetDatabase.GetAssetPath(m_MixamoFBX);
            if (!string.IsNullOrEmpty(fbxPath))
            {
                AnimationClip[] clips = MixamoRigImporter.GetAnimationsFromMixamoFBX(fbxPath);
                if (clips.Length > 0)
                {
                    // Try to find or create animator controller
                    var animator = skinnedMesh.GetComponent<Animator>();
                    if (animator != null && animator.runtimeAnimatorController != null)
                    {
                        so.FindProperty("m_AnimatorController").objectReferenceValue = animator.runtimeAnimatorController;
                    }
                }
            }
            
            so.ApplyModifiedProperties();
            window.Show();
        }
    }
    
    /// <summary>
    /// Menu items for quick Mixamo workflow
    /// </summary>
    public static class MixamoQuickMenu
    {
        [MenuItem("Assets/Create/Gaussian Splats/Convert Mixamo FBX to Splats", false, 200)]
        static void ConvertMixamoFBXToSplat()
        {
            GameObject selectedFBX = Selection.activeObject as GameObject;
            if (selectedFBX != null)
            {
                var skinnedMesh = selectedFBX.GetComponentInChildren<SkinnedMeshRenderer>();
                if (skinnedMesh != null && MixamoRigImporter.IsMixamoRig(skinnedMesh))
                {
                    var window = EditorWindow.GetWindow<SkinnedMeshToGaussianSplatConverter>("Skinned Mesh to Splats");
                    SerializedObject so = new SerializedObject(window);
                    so.FindProperty("m_SourceSkinnedMesh").objectReferenceValue = skinnedMesh;
                    so.FindProperty("m_GameObjectName").stringValue = selectedFBX.name + "_Splat";
                    so.FindProperty("m_IsMixamoRig").boolValue = true;
                    so.FindProperty("m_UseMixamoPresets").boolValue = true;
                    so.ApplyModifiedProperties();
                    window.Show();
                }
            }
        }
        
        [MenuItem("Assets/Create/Gaussian Splats/Convert Mixamo FBX to Splats", true)]
        static bool ValidateConvertMixamoFBXToSplat()
        {
            GameObject selectedFBX = Selection.activeObject as GameObject;
            if (selectedFBX != null)
            {
                var skinnedMesh = selectedFBX.GetComponentInChildren<SkinnedMeshRenderer>();
                return skinnedMesh != null && MixamoRigImporter.IsMixamoRig(skinnedMesh);
            }
            return false;
        }
    }
}

