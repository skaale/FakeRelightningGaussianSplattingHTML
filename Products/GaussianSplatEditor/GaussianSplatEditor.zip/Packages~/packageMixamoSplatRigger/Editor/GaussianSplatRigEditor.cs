// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    public class GaussianSplatRigEditor : UnityEditor.Editor
    {
        SerializedProperty m_MaxBonesProp;
        SerializedProperty m_AutoCaptureProp;
        SerializedProperty m_ShowHierarchyProp;

        void OnEnable()
        {
            m_MaxBonesProp = serializedObject.FindProperty("m_MaxBones");
            m_AutoCaptureProp = serializedObject.FindProperty("m_AutoCapture");
            m_ShowHierarchyProp = serializedObject.FindProperty("m_ShowHierarchy");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.LabelField("Settings", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_MaxBonesProp);
            EditorGUILayout.PropertyField(m_AutoCaptureProp);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Debug", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_ShowHierarchyProp);

            GaussianSplatRig rig = (GaussianSplatRig)target;

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Info", EditorStyles.boldLabel);
            EditorGUI.BeginDisabledGroup(true);
            EditorGUILayout.IntField("Bone Count", rig.boneCount);
            EditorGUI.EndDisabledGroup();

            if (rig.bones != null && rig.bones.Length > 0)
            {
                EditorGUILayout.LabelField($"Bones: {rig.boneCount} in hierarchy");
                
                EditorGUI.indentLevel++;
                bool showAll = EditorGUILayout.Foldout(false, "Show All Bones");
                if (showAll)
                {
                    for (int i = 0; i < Mathf.Min(10, rig.bones.Length); i++)
                    {
                        if (rig.bones[i] != null)
                        {
                            EditorGUILayout.LabelField($"[{i}] {rig.bones[i].name}", $"Radius: {rig.bones[i].radius:F1}");
                        }
                    }
                    if (rig.bones.Length > 10)
                    {
                        EditorGUILayout.LabelField($"... and {rig.bones.Length - 10} more bones");
                    }
                }
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Actions", EditorStyles.boldLabel);

            if (GUILayout.Button("Rebuild Rig"))
            {
                rig.RebuildRig();
                Debug.Log($"Rebuilt rig with {rig.boneCount} bones");
            }

            if (GUILayout.Button("Capture Bind Poses"))
            {
                rig.CaptureBindPoses();
                Debug.Log("Captured bind poses for all bones");
            }
            
            if (GUILayout.Button("Toggle All Bone Gizmos"))
            {
                ToggleAllBoneGizmos(rig);
            }

            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "Bone Hierarchy Visualization:\n\n" +
                "• Yellow lines = Bone skeleton structure\n" +
                "• Small cyan dots = Bone positions\n" +
                "• Green dot = Root bone (Hips)\n" +
                "• Select bones individually to see influence radius\n\n" +
                "Use GaussianSplatSkin to bind splats to these bones.",
                MessageType.Info
            );

            serializedObject.ApplyModifiedProperties();
        }

        void ToggleAllBoneGizmos(GaussianSplatRig rig)
        {
            if (rig.bones == null) return;

            bool anyVisible = false;
            foreach (var bone in rig.bones)
            {
                if (bone != null)
                {
                    SerializedObject boneSO = new SerializedObject(bone);
                    bool isVisible = boneSO.FindProperty("m_ShowGizmo").boolValue;
                    if (isVisible)
                    {
                        anyVisible = true;
                        break;
                    }
                }
            }

            bool newState = !anyVisible;
            foreach (var bone in rig.bones)
            {
                if (bone != null)
                {
                    SerializedObject boneSO = new SerializedObject(bone);
                    boneSO.FindProperty("m_ShowGizmo").boolValue = newState;
                    boneSO.ApplyModifiedProperties();
                }
            }

            Debug.Log($"{(newState ? "Enabled" : "Disabled")} gizmos for {rig.boneCount} bones");
        }
    }
}
