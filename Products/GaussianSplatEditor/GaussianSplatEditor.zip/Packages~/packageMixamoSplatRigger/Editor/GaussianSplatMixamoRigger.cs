// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;
using System.Collections.Generic;
using System.Linq;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Mixamo-style visual rigging tool for Gaussian Splat characters
    /// Place markers on 2D views to automatically generate and skin a rig
    /// </summary>
    public class GaussianSplatMixamoRigger : EditorWindow
    {
        // Joint marker definitions matching Mixamo's structure
        [System.Serializable]
        private class JointMarker
        {
            public string name;
            public Vector2 frontViewPos;  // Position on front view (XY plane)
            public Vector2 sideViewPos;   // Position on side view (ZY plane)
            public bool isRequired = true;
            public bool isPlaced = false;
            public Color gizmoColor = Color.cyan;
            
            public JointMarker(string name, bool required = true)
            {
                this.name = name;
                this.isRequired = required;
                this.gizmoColor = Color.cyan;
            }
            
            public Vector3 Get3DPosition(Bounds bounds)
            {
                // Combine front view (XY) and side view (Z) to get 3D position
                return new Vector3(
                    frontViewPos.x,
                    (frontViewPos.y + sideViewPos.y) / 2f, // Average Y from both views
                    sideViewPos.x
                );
            }
        }
        
        private enum ViewMode
        {
            FrontView,
            SideView,
            Both
        }
        
        // Target objects
        private GaussianSplatRenderer m_TargetRenderer;
        private Transform m_RigParent;
        
        // View settings
        private ViewMode m_ViewMode = ViewMode.Both;
        private Texture2D m_FrontViewTexture;
        private Texture2D m_SideViewTexture;
        private Rect m_FrontViewRect;
        private Rect m_SideViewRect;
        
        // Joint markers (following Mixamo's standard skeleton)
        private Dictionary<string, JointMarker> m_Markers = new Dictionary<string, JointMarker>();
        private string m_SelectedMarker = null;
        
        // Splat data
        private Vector3[] m_SplatPositions;
        private Bounds m_SplatBounds;
        private bool m_DataLoaded = false;
        
        // Settings
        private bool m_ShowLabels = true;
        private float m_MarkerSize = 10f;
        private float m_AutoBoneRadius = 0.15f;
        private bool m_UseAutoRadius = true;
        private bool m_UseSymmetry = true;
        private bool m_AutoEstimateDepth = true; // NEW: Auto-estimate side view from front view
        private Vector2 m_ScrollPos;
        
        // Generation settings
        private string m_RigName = "MixamoRig";
        private bool m_GenerateColliders = false;
        private bool m_ShowBoneGizmos = false;
        private bool m_AddAnimator = true;
        private RuntimeAnimatorController m_AnimatorController = null;
        
        [MenuItem("Tools/Gaussian Splats/Mixamo-Style Rigger")]
        public static void ShowWindow()
        {
            var window = GetWindow<GaussianSplatMixamoRigger>("Mixamo Rigger");
            window.minSize = new Vector2(1000, 700);
            window.Show();
        }
        
        private void OnEnable()
        {
            InitializeMarkers();
            
            if (Selection.activeGameObject != null)
            {
                m_TargetRenderer = Selection.activeGameObject.GetComponentInChildren<GaussianSplatRenderer>();
            }
        }
        
        private void InitializeMarkers()
        {
            m_Markers.Clear();
            
            // Essential markers only (Mixamo-style simplified)
            // Center markers (no symmetry needed)
            m_Markers["Chin"] = new JointMarker("Chin", true) { gizmoColor = Color.cyan };
            m_Markers["Groin"] = new JointMarker("Groin", true) { gizmoColor = Color.green };
            
            // Left side markers (will be mirrored if symmetry is on)
            m_Markers["LeftWrist"] = new JointMarker("LeftWrist", true) { gizmoColor = Color.yellow };
            m_Markers["LeftElbow"] = new JointMarker("LeftElbow", true) { gizmoColor = Color.yellow };
            m_Markers["LeftKnee"] = new JointMarker("LeftKnee", true) { gizmoColor = Color.magenta };
            
            // Right side markers (auto-filled with symmetry)
            m_Markers["RightWrist"] = new JointMarker("RightWrist", true) { gizmoColor = new Color(1f, 0.5f, 0f) };
            m_Markers["RightElbow"] = new JointMarker("RightElbow", true) { gizmoColor = new Color(1f, 0.5f, 0f) };
            m_Markers["RightKnee"] = new JointMarker("RightKnee", true) { gizmoColor = new Color(1f, 0.5f, 0f) };
        }
        
        private void OnGUI()
        {
            m_ScrollPos = EditorGUILayout.BeginScrollView(m_ScrollPos);
            
            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("Mixamo-Style Visual Rigger", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Place joint markers on the 2D views of your character to automatically generate a rigged skeleton.\nThis mimics Mixamo's auto-rigging workflow.", MessageType.Info);
            
            EditorGUILayout.Space(10);
            DrawSetupSection();
            
            if (m_DataLoaded)
            {
                EditorGUILayout.Space(10);
                DrawViewSection();
                
                EditorGUILayout.Space(10);
                DrawMarkerListSection();
                
                EditorGUILayout.Space(10);
                DrawGenerationSection();
            }
            
            EditorGUILayout.EndScrollView();
        }
        
        private void DrawSetupSection()
        {
            EditorGUILayout.LabelField("1. Setup", EditorStyles.boldLabel);
            
            m_TargetRenderer = (GaussianSplatRenderer)EditorGUILayout.ObjectField(
                "Splat Character", m_TargetRenderer, typeof(GaussianSplatRenderer), true);
            
            m_RigParent = (Transform)EditorGUILayout.ObjectField(
                "Rig Parent (optional)", m_RigParent, typeof(Transform), true);
            
            EditorGUI.BeginDisabledGroup(m_TargetRenderer == null);
            
            if (GUILayout.Button("Load Character & Generate Views", GUILayout.Height(30)))
            {
                LoadCharacterData();
            }
            
            EditorGUI.EndDisabledGroup();
            
            if (m_DataLoaded)
            {
                EditorGUILayout.HelpBox($"Character loaded: {m_TargetRenderer.splatCount:N0} splats\n" +
                    $"Bounds: {m_SplatBounds.size}", MessageType.None);
            }
        }
        
        private void DrawViewSection()
        {
            EditorGUILayout.LabelField("2. Place Joint Markers", EditorStyles.boldLabel);
            
            EditorGUILayout.HelpBox("SIMPLIFIED: Only click in FRONT view! Depth is auto-estimated.\nWith symmetry enabled, left side automatically mirrors to right.", MessageType.Info);
            
            m_ViewMode = (ViewMode)EditorGUILayout.EnumPopup("View Mode", m_ViewMode);
            m_UseSymmetry = EditorGUILayout.Toggle("Use Symmetry", m_UseSymmetry);
            m_AutoEstimateDepth = EditorGUILayout.Toggle("Auto-Estimate Depth (Side View)", m_AutoEstimateDepth);
            m_ShowLabels = EditorGUILayout.Toggle("Show Joint Labels", m_ShowLabels);
            m_MarkerSize = EditorGUILayout.Slider("Marker Size", m_MarkerSize, 5f, 20f);
            
            if (m_AutoEstimateDepth)
            {
                EditorGUILayout.HelpBox("✓ Depth estimation enabled: Only click in FRONT view, side view is calculated automatically!", MessageType.Info);
            }
            
            EditorGUILayout.Space(5);
            
            EditorGUILayout.BeginHorizontal();
            
            if (m_ViewMode == ViewMode.FrontView || m_ViewMode == ViewMode.Both)
            {
                DrawFrontView();
            }
            
            if (m_ViewMode == ViewMode.SideView || m_ViewMode == ViewMode.Both)
            {
                DrawSideView();
            }
            
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(5);
            EditorGUILayout.HelpBox("IMPORTANT: For best results, MANUALLY place markers on actual joints:\n" +
                "1. Select a joint (e.g., 'Chin')\n" +
                "2. Click on BOTH views where that joint is on the character\n" +
                "3. Repeat for all 5 essential markers (Chin, Groin, LeftWrist, LeftElbow, LeftKnee)\n" +
                "Auto-placement uses generic proportions and may not match your character!", MessageType.Warning);
            
            if (GUILayout.Button("Reset & Start Manual Placement"))
            {
                ClearAllMarkers();
                m_SelectedMarker = "Chin";
            }
        }
        
        private void DrawFrontView()
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(position.width / 2 - 20));
            EditorGUILayout.LabelField("Front View (XY Plane)", EditorStyles.boldLabel);
            
            Rect viewRect = GUILayoutUtility.GetRect(400, 400);
            m_FrontViewRect = viewRect;
            
            // Draw background
            EditorGUI.DrawRect(viewRect, new Color(0.2f, 0.2f, 0.2f, 1));
            
            // Draw splat preview if texture exists
            if (m_FrontViewTexture != null)
            {
                GUI.DrawTexture(viewRect, m_FrontViewTexture, ScaleMode.ScaleToFit);
            }
            
            // Draw markers
            DrawMarkersOnView(viewRect, true);
            
            // Handle click events - MUST be called every frame for all event types
            if (Event.current != null)
            {
                HandleViewClick(viewRect, true);
            }
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawSideView()
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(position.width / 2 - 20));
            EditorGUILayout.LabelField("Side View (ZY Plane)", EditorStyles.boldLabel);
            
            Rect viewRect = GUILayoutUtility.GetRect(400, 400);
            m_SideViewRect = viewRect;
            
            // Draw background
            EditorGUI.DrawRect(viewRect, new Color(0.2f, 0.2f, 0.2f, 1));
            
            // Draw splat preview if texture exists
            if (m_SideViewTexture != null)
            {
                GUI.DrawTexture(viewRect, m_SideViewTexture, ScaleMode.ScaleToFit);
            }
            
            // Draw markers
            DrawMarkersOnView(viewRect, false);
            
            // Handle click events - MUST be called every frame for all event types
            if (Event.current != null)
            {
                HandleViewClick(viewRect, false);
            }
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawMarkersOnView(Rect viewRect, bool isFrontView)
        {
            // Draw center line for reference
            Handles.BeginGUI();
            Handles.color = new Color(1, 1, 1, 0.2f);
            float centerX = viewRect.x + viewRect.width / 2;
            Handles.DrawLine(new Vector2(centerX, viewRect.y), new Vector2(centerX, viewRect.y + viewRect.height));
            Handles.EndGUI();
            
            foreach (var kvp in m_Markers)
            {
                var marker = kvp.Value;
                if (!marker.isPlaced) continue;
                
                Vector2 markerPos = isFrontView ? marker.frontViewPos : marker.sideViewPos;
                Vector2 screenPos = WorldToViewPos(markerPos, viewRect);
                
                Rect markerRect = new Rect(screenPos.x - m_MarkerSize / 2, screenPos.y - m_MarkerSize / 2, 
                    m_MarkerSize, m_MarkerSize);
                
                // Draw crosshair for precision
                Handles.BeginGUI();
                Color markerColor = marker.gizmoColor;
                if (m_SelectedMarker == kvp.Key)
                    markerColor = Color.white;
                
                Handles.color = markerColor;
                float crossSize = m_MarkerSize + 5;
                Handles.DrawLine(new Vector2(screenPos.x - crossSize, screenPos.y), new Vector2(screenPos.x + crossSize, screenPos.y));
                Handles.DrawLine(new Vector2(screenPos.x, screenPos.y - crossSize), new Vector2(screenPos.x, screenPos.y + crossSize));
                Handles.EndGUI();
                
                // Draw marker circle
                EditorGUI.DrawRect(markerRect, markerColor);
                
                // Draw label
                if (m_ShowLabels)
                {
                    GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
                    labelStyle.normal.textColor = Color.white;
                    labelStyle.fontSize = 10;
                    labelStyle.fontStyle = FontStyle.Bold;
                    
                    Vector2 labelSize = labelStyle.CalcSize(new GUIContent(kvp.Key));
                    Rect labelRect = new Rect(screenPos.x + m_MarkerSize / 2 + 2, screenPos.y - labelSize.y / 2, 
                        labelSize.x, labelSize.y);
                    
                    GUI.Label(labelRect, kvp.Key, labelStyle);
                }
            }
            
            // Draw instruction for selected marker
            if (!string.IsNullOrEmpty(m_SelectedMarker))
            {
                GUIStyle instructionStyle = new GUIStyle(GUI.skin.box);
                instructionStyle.normal.textColor = Color.yellow;
                instructionStyle.fontSize = 12;
                instructionStyle.fontStyle = FontStyle.Bold;
                instructionStyle.alignment = TextAnchor.MiddleCenter;
                
                string viewName = isFrontView ? "FRONT" : "SIDE";
                string instruction = $"Click to place: {m_SelectedMarker} ({viewName} VIEW)";
                Vector2 instructionSize = instructionStyle.CalcSize(new GUIContent(instruction));
                Rect instructionRect = new Rect(viewRect.x + (viewRect.width - instructionSize.x) / 2, 
                    viewRect.y + 5, instructionSize.x + 10, 25);
                
                GUI.Box(instructionRect, instruction, instructionStyle);
            }
        }
        
        private void HandleViewClick(Rect viewRect, bool isFrontView)
        {
            Event e = Event.current;
            
            // Handle mouse down event
            if (e.type == EventType.MouseDown && e.button == 0)
            {
                if (viewRect.Contains(e.mousePosition))
                {
                    if (!string.IsNullOrEmpty(m_SelectedMarker) && m_Markers.ContainsKey(m_SelectedMarker))
                    {
                        Vector2 viewPos = ViewToWorldPos(e.mousePosition, viewRect);
                        
                        var marker = m_Markers[m_SelectedMarker];
                        if (isFrontView)
                        {
                            marker.frontViewPos = viewPos;
                            Debug.Log($"[Mixamo Rigger] Placed {m_SelectedMarker} in front view at {viewPos}");
                            
                            // Auto-estimate side view if enabled
                            if (m_AutoEstimateDepth)
                            {
                                marker.sideViewPos = EstimateSideViewPosition(m_SelectedMarker, viewPos);
                                Debug.Log($"[Mixamo Rigger] Auto-estimated {m_SelectedMarker} side view at {marker.sideViewPos}");
                            }
                        }
                        else
                        {
                            marker.sideViewPos = viewPos;
                            Debug.Log($"[Mixamo Rigger] Placed {m_SelectedMarker} in side view at {viewPos}");
                        }
                        
                        // Check if marker is now fully placed
                        bool wasPlaced = marker.isPlaced;
                        bool isNowPlaced = marker.frontViewPos != Vector2.zero && marker.sideViewPos != Vector2.zero;
                        
                        if (isNowPlaced && !wasPlaced)
                        {
                            marker.isPlaced = true;
                            Debug.Log($"[Mixamo Rigger] ✓ {m_SelectedMarker} PLACED! Front:{marker.frontViewPos} Side:{marker.sideViewPos}");
                            
                            // Auto-select next unplaced marker
                            AutoSelectNextMarker();
                        }
                        else if (!isNowPlaced && !m_AutoEstimateDepth)
                        {
                            string missingView = marker.frontViewPos == Vector2.zero ? "FRONT" : "SIDE";
                            Debug.Log($"[Mixamo Rigger] {m_SelectedMarker} needs placement in {missingView} view");
                        }
                        
                        // Apply symmetry if enabled
                        if (m_UseSymmetry)
                        {
                            ApplySymmetry(m_SelectedMarker, isFrontView);
                        }
                        
                        e.Use();
                        Repaint();
                    }
                    else
                    {
                        Debug.LogWarning("[Mixamo Rigger] No marker selected! Click a marker button from the list first.");
                    }
                }
            }
            
            // Visual feedback on hover
            if (e.type == EventType.Repaint && viewRect.Contains(e.mousePosition))
            {
                if (!string.IsNullOrEmpty(m_SelectedMarker))
                {
                    Handles.BeginGUI();
                    Handles.color = Color.yellow;
                    Handles.DrawWireDisc(e.mousePosition, Vector3.forward, 5f);
                    Handles.EndGUI();
                }
            }
        }
        
        private void AutoSelectNextMarker()
        {
            // Auto-select next unplaced essential marker
            // When symmetry is on, skip right-side markers as they're auto-mirrored
            string[] order;
            if (m_UseSymmetry)
            {
                order = new[] { "Chin", "Groin", "LeftWrist", "LeftElbow", "LeftKnee" };
            }
            else
            {
                order = new[] { "Chin", "Groin", "LeftWrist", "LeftElbow", "LeftKnee", "RightWrist", "RightElbow", "RightKnee" };
            }
            
            foreach (var name in order)
            {
                if (m_Markers.ContainsKey(name) && !m_Markers[name].isPlaced)
                {
                    m_SelectedMarker = name;
                    Debug.Log($"[Mixamo Rigger] Auto-selected next marker: {name}");
                    return;
                }
            }
            m_SelectedMarker = null; // All placed
            Debug.Log("[Mixamo Rigger] ✓ All markers placed! Ready to generate rig.");
        }
        
        private Vector2 EstimateSideViewPosition(string markerName, Vector2 frontViewPos)
        {
            // Estimate depth (Z position) based on anatomical knowledge
            float centerZ = (m_SplatBounds.min.z + m_SplatBounds.max.z) / 2f;
            float depthRange = m_SplatBounds.size.z;
            
            // Different body parts have different typical depths
            float zOffset = 0f;
            
            if (markerName.Contains("Chin") || markerName.Contains("Head"))
            {
                zOffset = depthRange * 0.1f; // Face slightly forward
            }
            else if (markerName.Contains("Wrist") || markerName.Contains("Hand"))
            {
                zOffset = depthRange * 0.0f; // Hands at center in T-pose
            }
            else if (markerName.Contains("Elbow"))
            {
                zOffset = -depthRange * 0.05f; // Elbows slightly back
            }
            else if (markerName.Contains("Knee") || markerName.Contains("Foot"))
            {
                zOffset = depthRange * 0.0f; // Legs center
            }
            else if (markerName.Contains("Groin") || markerName.Contains("Hips"))
            {
                zOffset = -depthRange * 0.05f; // Hips slightly back
            }
            
            float estimatedZ = centerZ + zOffset;
            
            // Side view uses Z for X and Y stays the same
            return new Vector2(estimatedZ, frontViewPos.y);
        }
        
        private void ApplySymmetry(string markerName, bool isFrontView)
        {
            // Safety check
            if (string.IsNullOrEmpty(markerName))
                return;
                
            // Mirror left to right or vice versa
            string mirroredName = null;
            
            if (markerName.StartsWith("Left"))
            {
                mirroredName = markerName.Replace("Left", "Right");
            }
            else if (markerName.StartsWith("Right"))
            {
                mirroredName = markerName.Replace("Right", "Left");
            }
            else
            {
                // Center markers don't need symmetry
                return;
            }
            
            if (string.IsNullOrEmpty(mirroredName) || !m_Markers.ContainsKey(mirroredName))
                return;
            
            var sourceMarker = m_Markers[markerName];
            var targetMarker = m_Markers[mirroredName];
            
            if (isFrontView)
            {
                // Mirror X coordinate (flip horizontally around center)
                float centerX = (m_SplatBounds.min.x + m_SplatBounds.max.x) / 2f;
                float offset = sourceMarker.frontViewPos.x - centerX;
                targetMarker.frontViewPos = new Vector2(centerX - offset, sourceMarker.frontViewPos.y);
            }
            else
            {
                // Side view stays the same (same depth)
                targetMarker.sideViewPos = sourceMarker.sideViewPos;
            }
            
            // Mark mirrored marker as placed if source is placed
            if (sourceMarker.isPlaced && targetMarker.frontViewPos != Vector2.zero && targetMarker.sideViewPos != Vector2.zero)
            {
                targetMarker.isPlaced = true;
                Debug.Log($"[Mixamo Rigger] 🔄 Symmetry: {mirroredName} automatically mirrored from {markerName}");
            }
        }
        
        private Vector2 WorldToViewPos(Vector2 worldPos, Rect viewRect)
        {
            // Convert normalized position to screen position
            float x = (worldPos.x - m_SplatBounds.min.x) / m_SplatBounds.size.x;
            float y = (worldPos.y - m_SplatBounds.min.y) / m_SplatBounds.size.y;
            
            return new Vector2(
                viewRect.x + x * viewRect.width,
                viewRect.y + (1 - y) * viewRect.height // Flip Y
            );
        }
        
        private Vector2 ViewToWorldPos(Vector2 screenPos, Rect viewRect)
        {
            // Convert screen position to normalized position
            float x = (screenPos.x - viewRect.x) / viewRect.width;
            float y = 1 - (screenPos.y - viewRect.y) / viewRect.height; // Flip Y
            
            return new Vector2(
                m_SplatBounds.min.x + x * m_SplatBounds.size.x,
                m_SplatBounds.min.y + y * m_SplatBounds.size.y
            );
        }
        
        private void DrawMarkerListSection()
        {
            EditorGUILayout.LabelField("Essential Markers", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Auto-Place (Generic)", GUILayout.Height(30)))
            {
                if (EditorUtility.DisplayDialog("Auto-Place Markers", 
                    "Auto-placement uses generic humanoid proportions and may not match your character accurately.\n\n" +
                    "For best results, manually place markers on the actual joints in both views.\n\n" +
                    "Continue with auto-placement?", "Yes", "Cancel"))
                {
                    AutoPlaceAllMarkers();
                }
            }
            if (GUILayout.Button("Clear All", GUILayout.Height(30)))
            {
                ClearAllMarkers();
            }
            EditorGUILayout.EndHorizontal();
            
            if (m_UseSymmetry)
            {
                EditorGUILayout.HelpBox("✓ SYMMETRY ON: Only place CENTER + LEFT side markers (5 total). Right side auto-mirrors!", MessageType.Info);
            }
            else
            {
                EditorGUILayout.HelpBox("TIP: Enable symmetry to only place left side markers. Zoom in on views for precision.", MessageType.Info);
            }
            
            EditorGUILayout.Space(5);
            
            // Simplified marker groups
            DrawMarkerGroup("Center", new[] { "Chin", "Groin" });
            DrawMarkerGroup("Left Side", new[] { "LeftWrist", "LeftElbow", "LeftKnee" });
            
            // Only show right side markers if symmetry is OFF
            if (!m_UseSymmetry)
            {
                DrawMarkerGroup("Right Side", new[] { "RightWrist", "RightElbow", "RightKnee" });
            }
        }
        
        private void DrawMarkerGroup(string groupName, string[] markerNames)
        {
            EditorGUILayout.LabelField(groupName, EditorStyles.boldLabel);
            
            foreach (var name in markerNames)
            {
                if (!m_Markers.ContainsKey(name)) continue;
                
                var marker = m_Markers[name];
                
                EditorGUILayout.BeginHorizontal();
                
                bool isSelected = m_SelectedMarker == name;
                Color oldBg = GUI.backgroundColor;
                if (isSelected)
                    GUI.backgroundColor = Color.yellow;
                
                if (GUILayout.Button(name, GUILayout.Width(150)))
                {
                    m_SelectedMarker = name;
                }
                
                GUI.backgroundColor = oldBg;
                
                EditorGUI.BeginDisabledGroup(true);
                EditorGUILayout.Toggle("Placed", marker.isPlaced, GUILayout.Width(60));
                EditorGUI.EndDisabledGroup();
                
                if (marker.isRequired)
                {
                    EditorGUILayout.LabelField("Required", GUILayout.Width(60));
                }
                
                if (marker.isPlaced && GUILayout.Button("Clear", GUILayout.Width(50)))
                {
                    marker.isPlaced = false;
                    marker.frontViewPos = Vector2.zero;
                    marker.sideViewPos = Vector2.zero;
                    
                    // If symmetry is on and this is a left marker, also clear the mirrored right marker
                    if (m_UseSymmetry && name.StartsWith("Left"))
                    {
                        string mirroredName = name.Replace("Left", "Right");
                        if (m_Markers.ContainsKey(mirroredName))
                        {
                            var mirroredMarker = m_Markers[mirroredName];
                            mirroredMarker.isPlaced = false;
                            mirroredMarker.frontViewPos = Vector2.zero;
                            mirroredMarker.sideViewPos = Vector2.zero;
                            Debug.Log($"[Mixamo Rigger] Cleared {name} and mirrored {mirroredName}");
                        }
                    }
                }
                
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.Space(3);
        }
        
        private void DrawGenerationSection()
        {
            EditorGUILayout.LabelField("3. Generate Rig", EditorStyles.boldLabel);
            
            m_RigName = EditorGUILayout.TextField("Rig Name", m_RigName);
            m_UseAutoRadius = EditorGUILayout.Toggle("Auto-Calculate Bone Radius", m_UseAutoRadius);
            
            if (!m_UseAutoRadius)
            {
                m_AutoBoneRadius = EditorGUILayout.Slider("Bone Radius", m_AutoBoneRadius, 0.05f, 0.5f);
            }
            
            m_ShowBoneGizmos = EditorGUILayout.Toggle("Show Bone Gizmos", m_ShowBoneGizmos);
            m_GenerateColliders = EditorGUILayout.Toggle("Generate Colliders", m_GenerateColliders);
            
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Animation Setup", EditorStyles.boldLabel);
            m_AddAnimator = EditorGUILayout.Toggle("Add Animator Component", m_AddAnimator);
            
            if (m_AddAnimator)
            {
                EditorGUI.indentLevel++;
                m_AnimatorController = (RuntimeAnimatorController)EditorGUILayout.ObjectField(
                    "Animator Controller", m_AnimatorController, typeof(RuntimeAnimatorController), false);
                EditorGUILayout.HelpBox("Optional: Assign an AnimatorController. You can also add it later.", MessageType.Info);
                EditorGUI.indentLevel--;
            }
            
            EditorGUILayout.Space(5);
            
            // Count essential markers (8 total)
            string[] essentialMarkers = new[] { "Chin", "Groin", "LeftWrist", "LeftElbow", "LeftKnee", "RightWrist", "RightElbow", "RightKnee" };
            int essentialCount = essentialMarkers.Length;
            int placedEssentialCount = essentialMarkers.Count(name => m_Markers.ContainsKey(name) && m_Markers[name].isPlaced);
            
            // Minimum required: Chin, Groin, and at least one side (5 markers)
            int minimumRequired = 5;
            bool hasMinimum = placedEssentialCount >= minimumRequired && 
                              m_Markers["Chin"].isPlaced && 
                              m_Markers["Groin"].isPlaced;
            
            EditorGUILayout.HelpBox($"Essential markers placed: {placedEssentialCount}/{essentialCount}\n" +
                $"Minimum required: {minimumRequired} (Chin, Groin + one side)", 
                hasMinimum ? MessageType.Info : MessageType.Warning);
            
            if (m_UseSymmetry && placedEssentialCount >= minimumRequired)
            {
                EditorGUILayout.HelpBox("Symmetry is enabled. Complete skeleton will be generated from your markers.", MessageType.Info);
            }
            
            EditorGUI.BeginDisabledGroup(!hasMinimum);
            
            if (GUILayout.Button("Generate Mixamo-Compatible Rig", GUILayout.Height(40)))
            {
                GenerateRig();
            }
            
            EditorGUI.EndDisabledGroup();
        }
        
        private void LoadCharacterData()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                EditorUtility.DisplayDialog("Error", "No valid renderer or asset found.", "OK");
                return;
            }
            
            EditorUtility.DisplayProgressBar("Loading", "Reading splat positions...", 0.3f);
            
            try
            {
                m_SplatPositions = GetSplatPositions();
                if (m_SplatPositions == null || m_SplatPositions.Length == 0)
                {
                    EditorUtility.DisplayDialog("Error", "Could not read splat positions.", "OK");
                    return;
                }
                
                // Calculate bounds
                m_SplatBounds = new Bounds(m_SplatPositions[0], Vector3.zero);
                foreach (var pos in m_SplatPositions)
                {
                    m_SplatBounds.Encapsulate(pos);
                }
                
                EditorUtility.DisplayProgressBar("Loading", "Generating preview views...", 0.7f);
                
                // Generate preview textures
                GeneratePreviewTextures();
                
                m_DataLoaded = true;
                
                Debug.Log($"[Mixamo Rigger] Character loaded: {m_SplatPositions.Length:N0} splats, bounds: {m_SplatBounds.size}");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
        
        private Vector3[] GetSplatPositions()
        {
            var asset = m_TargetRenderer.asset;
            if (asset == null) return null;
            
            int splatCount = m_TargetRenderer.splatCount;
            Vector3[] positions = new Vector3[splatCount];
            
            var gpuPosData = m_TargetRenderer.GpuPosData;
            if (gpuPosData == null) return null;
            
            int posStride = (int)(asset.posData.dataSize / asset.splatCount);
            int posInts = posStride / 4;
            
            uint[] posData = new uint[splatCount * posInts];
            gpuPosData.GetData(posData);
            
            for (int i = 0; i < splatCount; i++)
            {
                Vector3 localPos = DecodeSplatPosition(posData, i, posInts, asset);
                positions[i] = m_TargetRenderer.transform.TransformPoint(localPos);
            }
            
            return positions;
        }
        
        private Vector3 DecodeSplatPosition(uint[] posData, int splatIndex, int posInts, GaussianSplatAsset asset)
        {
            int offset = splatIndex * posInts;
            
            switch (asset.posFormat)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    return new Vector3(
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 1]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 2]), 0)
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm16:
                    ushort x = (ushort)(posData[offset] & 0xFFFF);
                    ushort y = (ushort)((posData[offset] >> 16) & 0xFFFF);
                    ushort z = (ushort)(posData[offset + 1] & 0xFFFF);
                    
                    return new Vector3(
                        Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, x / 65535.0f),
                        Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, y / 65535.0f),
                        Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, z / 65535.0f)
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm11:
                    uint packed = posData[offset];
                    float nx = (packed & 0x7FF) / 2047.0f;
                    float ny = ((packed >> 11) & 0x3FF) / 1023.0f;
                    float nz = ((packed >> 21) & 0x7FF) / 2047.0f;
                    
                    return new Vector3(
                        Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, nx),
                        Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, ny),
                        Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, nz)
                    );
                    
                default:
                    return Vector3.zero;
            }
        }
        
        private void GeneratePreviewTextures()
        {
            // Generate simple density-based preview textures
            int resolution = 512;
            
            m_FrontViewTexture = new Texture2D(resolution, resolution);
            m_SideViewTexture = new Texture2D(resolution, resolution);
            
            // Initialize to dark gray
            Color darkGray = new Color(0.15f, 0.15f, 0.15f, 1);
            for (int y = 0; y < resolution; y++)
            {
                for (int x = 0; x < resolution; x++)
                {
                    m_FrontViewTexture.SetPixel(x, y, darkGray);
                    m_SideViewTexture.SetPixel(x, y, darkGray);
                }
            }
            
            // Draw splats as points
            foreach (var pos in m_SplatPositions)
            {
                // Front view (XY)
                float fx = (pos.x - m_SplatBounds.min.x) / m_SplatBounds.size.x;
                float fy = (pos.y - m_SplatBounds.min.y) / m_SplatBounds.size.y;
                int frontX = Mathf.Clamp((int)(fx * resolution), 0, resolution - 1);
                int frontY = Mathf.Clamp((int)(fy * resolution), 0, resolution - 1);
                
                Color current = m_FrontViewTexture.GetPixel(frontX, frontY);
                m_FrontViewTexture.SetPixel(frontX, frontY, Color.Lerp(current, Color.white, 0.3f));
                
                // Side view (ZY)
                float sx = (pos.z - m_SplatBounds.min.z) / m_SplatBounds.size.z;
                float sy = (pos.y - m_SplatBounds.min.y) / m_SplatBounds.size.y;
                int sideX = Mathf.Clamp((int)(sx * resolution), 0, resolution - 1);
                int sideY = Mathf.Clamp((int)(sy * resolution), 0, resolution - 1);
                
                current = m_SideViewTexture.GetPixel(sideX, sideY);
                m_SideViewTexture.SetPixel(sideX, sideY, Color.Lerp(current, Color.white, 0.3f));
            }
            
            m_FrontViewTexture.Apply();
            m_SideViewTexture.Apply();
        }
        
        private void AutoPlaceAllMarkers()
        {
            // Use density analysis for the simplified marker set
            Vector3 size = m_SplatBounds.size;
            Vector3 center = m_SplatBounds.center;
            float bottom = m_SplatBounds.min.y;
            float height = size.y;
            
            // Center markers
            PlaceMarkerAuto("Chin", center.x, bottom + height * 0.88f, center.z);
            PlaceMarkerAuto("Groin", center.x, bottom + height * 0.52f, center.z);
            
            // Left side markers
            float armX = size.x * 0.42f;
            PlaceMarkerAuto("LeftWrist", center.x - armX * 1.05f, bottom + height * 0.50f, center.z);
            PlaceMarkerAuto("LeftElbow", center.x - armX * 0.95f, bottom + height * 0.62f, center.z);
            
            float legX = size.x * 0.12f;
            PlaceMarkerAuto("LeftKnee", center.x - legX, bottom + height * 0.28f, center.z);
            
            // Right side markers - apply symmetry from left side
            if (m_UseSymmetry)
            {
                // Mirror left side to right side
                ApplySymmetry("LeftWrist", true);
                ApplySymmetry("LeftElbow", true);
                ApplySymmetry("LeftKnee", true);
            }
            else
            {
                // Place right side markers manually
                PlaceMarkerAuto("RightWrist", center.x + armX * 1.05f, bottom + height * 0.50f, center.z);
                PlaceMarkerAuto("RightElbow", center.x + armX * 0.95f, bottom + height * 0.62f, center.z);
                PlaceMarkerAuto("RightKnee", center.x + legX, bottom + height * 0.28f, center.z);
            }
            
            string symmetryNote = m_UseSymmetry ? " (right side auto-mirrored)" : "";
            Debug.Log($"[Mixamo Rigger] Auto-placed essential markers based on character proportions{symmetryNote}");
            Repaint();
        }
        
        private void PlaceMarkerAuto(string markerName, float x, float y, float z)
        {
            if (!m_Markers.ContainsKey(markerName)) return;
            
            var marker = m_Markers[markerName];
            marker.frontViewPos = new Vector2(x, y);
            
            // Use depth estimation if enabled, otherwise use provided Z
            if (m_AutoEstimateDepth)
            {
                marker.sideViewPos = EstimateSideViewPosition(markerName, new Vector2(x, y));
            }
            else
            {
                marker.sideViewPos = new Vector2(z, y);
            }
            
            marker.isPlaced = true;
        }
        
        private void ClearAllMarkers()
        {
            foreach (var marker in m_Markers.Values)
            {
                marker.isPlaced = false;
                marker.frontViewPos = Vector2.zero;
                marker.sideViewPos = Vector2.zero;
            }
            Repaint();
        }
        
        private void GenerateRig()
        {
            if (!EditorUtility.DisplayDialog("Generate Rig", 
                "This will create a new Mixamo-compatible rig based on your placed markers.\n\n" +
                "The full skeleton will be interpolated from your essential markers:\n" +
                "- Chin, Groin, Wrists, Elbows, Knees\n\nContinue?", 
                "Yes", "Cancel"))
            {
                return;
            }
            
            EditorUtility.DisplayProgressBar("Generating Rig", "Inferring full skeleton from markers...", 0.2f);
            
            try
            {
                // Infer complete skeleton from essential markers
                InferFullSkeletonFromEssentialMarkers();
                
                // Create rig root
                GameObject rigRoot = new GameObject(m_RigName);
                if (m_RigParent != null)
                    rigRoot.transform.SetParent(m_RigParent);
                else
                    rigRoot.transform.SetParent(m_TargetRenderer.transform.parent);
                
                rigRoot.transform.position = m_TargetRenderer.transform.position;
                rigRoot.transform.rotation = m_TargetRenderer.transform.rotation;
                
                // Move splat renderer to be child of rig root
                m_TargetRenderer.transform.SetParent(rigRoot.transform);
                m_TargetRenderer.transform.localPosition = Vector3.zero;
                m_TargetRenderer.transform.localRotation = Quaternion.identity;
                
                var rigComponent = rigRoot.AddComponent<GaussianSplatRig>();
                
                // Disable rig gizmos by default
                rigComponent.GetType().GetField("m_ShowHierarchy", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)?.SetValue(rigComponent, m_ShowBoneGizmos);
                rigComponent.GetType().GetField("m_ShowBoneNames", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)?.SetValue(rigComponent, false);
                
                // Create bones in hierarchy
                Dictionary<string, GameObject> boneObjects = new Dictionary<string, GameObject>();
                
                EditorUtility.DisplayProgressBar("Generating Rig", "Creating spine bones...", 0.4f);
                CreateBoneChain(rigRoot.transform, boneObjects, "Hips", "Spine", "Spine1", "Spine2", "Neck", "Head");
                
                EditorUtility.DisplayProgressBar("Generating Rig", "Creating arm bones...", 0.6f);
                Transform spine2 = boneObjects.ContainsKey("Spine2") ? boneObjects["Spine2"].transform : boneObjects["Spine1"].transform;
                CreateBoneChain(spine2, boneObjects, "LeftShoulder", "LeftArm", "LeftForeArm", "LeftHand");
                CreateBoneChain(spine2, boneObjects, "RightShoulder", "RightArm", "RightForeArm", "RightHand");
                
                EditorUtility.DisplayProgressBar("Generating Rig", "Creating leg bones...", 0.8f);
                CreateBoneChain(boneObjects["Hips"].transform, boneObjects, "LeftUpLeg", "LeftLeg", "LeftFoot");
                CreateBoneChain(boneObjects["Hips"].transform, boneObjects, "RightUpLeg", "RightLeg", "RightFoot");
                
                // Add skin component to renderer if not already present
                var skinComponent = m_TargetRenderer.gameObject.GetComponent<GaussianSplatSkin>();
                if (skinComponent == null)
                {
                    skinComponent = m_TargetRenderer.gameObject.AddComponent<GaussianSplatSkin>();
                }
                
                EditorUtility.DisplayProgressBar("Generating Rig", "Configuring skin component...", 0.85f);
                
                // Configure skin component
                var skinType = typeof(GaussianSplatSkin);
                
                // Set the rig reference
                var rigField = skinType.GetField("m_Rig", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (rigField != null)
                {
                    rigField.SetValue(skinComponent, rigComponent);
                }
                
                // Find and assign the compute shader
                #if UNITY_EDITOR
                string[] guids = UnityEditor.AssetDatabase.FindAssets("GaussianSplatSkinning t:ComputeShader");
                if (guids.Length > 0)
                {
                    string path = UnityEditor.AssetDatabase.GUIDToAssetPath(guids[0]);
                    ComputeShader skinningCS = UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                    
                    var csField = skinType.GetField("m_SkinningComputeShader", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    if (csField != null && skinningCS != null)
                    {
                        csField.SetValue(skinComponent, skinningCS);
                        Debug.Log($"[Mixamo Rigger] Assigned compute shader: {skinningCS.name}");
                    }
                }
                else
                {
                    Debug.LogWarning("[Mixamo Rigger] Could not find GaussianSplatSkinning compute shader. Please assign it manually.");
                }
                #endif
                
                // Enable skinning (but don't calculate weights yet - user needs to do that)
                var enableField = skinType.GetField("m_EnableSkinning", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (enableField != null)
                {
                    enableField.SetValue(skinComponent, false); // Keep disabled until weights are calculated
                }
                
                // Set use compute shader
                var useCSField = skinType.GetField("m_UseComputeShader", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (useCSField != null)
                {
                    useCSField.SetValue(skinComponent, true);
                }
                
                EditorUtility.SetDirty(skinComponent);
                
                EditorUtility.DisplayProgressBar("Generating Rig", "Finalizing...", 0.9f);
                
                // Rebuild rig to initialize
                rigComponent.RebuildRig();
                
                EditorUtility.SetDirty(rigComponent);
                
                // Add Animator component if requested
                if (m_AddAnimator)
                {
                    EditorUtility.DisplayProgressBar("Generating Rig", "Setting up Animator...", 0.95f);
                    
                    var animator = rigRoot.GetComponent<Animator>();
                    if (animator == null)
                    {
                        animator = rigRoot.AddComponent<Animator>();
                    }
                    
                    // Configure animator for humanoid animation
                    animator.applyRootMotion = true;
                    animator.updateMode = AnimatorUpdateMode.Normal;
                    animator.cullingMode = AnimatorCullingMode.CullUpdateTransforms;
                    
                    // Assign controller if provided
                    if (m_AnimatorController != null)
                    {
                        animator.runtimeAnimatorController = m_AnimatorController;
                        Debug.Log($"[Mixamo Rigger] Assigned AnimatorController: {m_AnimatorController.name}");
                    }
                    
                    // Create and configure Humanoid Avatar
                    EditorUtility.DisplayProgressBar("Generating Rig", "Creating Humanoid Avatar...", 0.97f);
                    Avatar avatar = CreateHumanoidAvatar(rigRoot, boneObjects);
                    if (avatar != null)
                    {
                        animator.avatar = avatar;
                        Debug.Log("[Mixamo Rigger] ✅ Created and assigned Humanoid Avatar for Mixamo animations!");
                    }
                    else
                    {
                        Debug.LogWarning("[Mixamo Rigger] ⚠️ Could not create Avatar automatically. Please configure manually in Inspector.");
                    }
                    
                    EditorUtility.SetDirty(animator);
                }
                
                EditorUtility.DisplayProgressBar("Generating Rig", "Complete!", 1.0f);
                
                Selection.activeGameObject = rigRoot;
                
                // Log bone radius info for joints
                string jointInfo = "";
                if (boneObjects.ContainsKey("LeftElbow"))
                    jointInfo += $" Elbow={boneObjects["LeftElbow"].GetComponent<GaussianSplatBone>().radius:F3}";
                if (boneObjects.ContainsKey("LeftKnee"))
                    jointInfo += $" Knee={boneObjects["LeftKnee"].GetComponent<GaussianSplatBone>().radius:F3}";
                
                Debug.Log($"[Mixamo Rigger] Generated rig with {boneObjects.Count} bones from {GetPlacedEssentialCount()} essential markers\n" +
                    $"Character bounds: {m_SplatBounds.size}\n" +
                    $"Rig position: {rigRoot.transform.position}\n" +
                    $"Bone radii (joints):{jointInfo}\n" +
                    $"✅ Joint bones have increased radii for proper skinning overlap");
                
                string animatorInfo = "";
                string animatorStep = "4. ";
                
                if (m_AddAnimator)
                {
                    animatorInfo = "✅ Animator: Added with Humanoid Avatar\n";
                    if (m_AnimatorController != null)
                    {
                        animatorInfo += "✅ Controller: Assigned - Ready to play!\n";
                    }
                    else
                    {
                        animatorStep = "4. Assign AnimatorController to play animations\n5. ";
                    }
                }
                
                EditorUtility.DisplayDialog("Rig Generated!", 
                    $"Created Mixamo-compatible rig '{m_RigName}' with {boneObjects.Count} bones.\n\n" +
                    $"Inferred from {GetPlacedEssentialCount()} essential markers.\n\n" +
                    "✅ Hierarchy: Splat is now child of rig\n" +
                    "✅ Compute shader: Assigned automatically\n" +
                    "✅ Skin component: Added and configured\n" +
                    "✅ Bone radii: Optimized for joint skinning (larger radii at joints)\n" +
                    animatorInfo + "\n" +
                    "Next steps:\n" +
                    "1. Select the Splat object\n" +
                    "2. Right-click GaussianSplatSkin → Recalculate Weights\n" +
                    "3. Check 'Enable Skinning' checkbox\n" +
                    animatorStep + "Press Play to see your character animate!\n\n" +
                    "💡 TIP: If joints still fragment, select bones and increase their Radius in Inspector.", "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
        
        private int GetPlacedEssentialCount()
        {
            return new[] { "Chin", "Groin", "LeftWrist", "LeftElbow", "LeftKnee", "RightWrist", "RightElbow", "RightKnee" }
                .Count(name => m_Markers.ContainsKey(name) && m_Markers[name].isPlaced);
        }
        
        private void InferFullSkeletonFromEssentialMarkers()
        {
            // Infer complete skeleton positions from essential markers
            // This creates all the intermediate bones automatically
            
            Vector3 size = m_SplatBounds.size;
            Vector3 center = m_SplatBounds.center;
            float bottom = m_SplatBounds.min.y;
            float height = size.y;
            
            // Get essential marker positions
            Vector3 chinPos = m_Markers["Chin"].isPlaced ? m_Markers["Chin"].Get3DPosition(m_SplatBounds) : Vector3.zero;
            Vector3 groinPos = m_Markers["Groin"].isPlaced ? m_Markers["Groin"].Get3DPosition(m_SplatBounds) : Vector3.zero;
            Vector3 leftWrist = m_Markers["LeftWrist"].isPlaced ? m_Markers["LeftWrist"].Get3DPosition(m_SplatBounds) : Vector3.zero;
            Vector3 leftElbow = m_Markers["LeftElbow"].isPlaced ? m_Markers["LeftElbow"].Get3DPosition(m_SplatBounds) : Vector3.zero;
            Vector3 leftKnee = m_Markers["LeftKnee"].isPlaced ? m_Markers["LeftKnee"].Get3DPosition(m_SplatBounds) : Vector3.zero;
            
            // Get right side markers - if not placed, mirror from left side
            Vector3 rightWrist, rightElbow, rightKnee;
            float centerX = (m_SplatBounds.min.x + m_SplatBounds.max.x) / 2f;
            
            if (m_Markers["RightWrist"].isPlaced)
            {
                rightWrist = m_Markers["RightWrist"].Get3DPosition(m_SplatBounds);
            }
            else if (leftWrist != Vector3.zero)
            {
                // Mirror from left
                float offsetX = leftWrist.x - centerX;
                rightWrist = new Vector3(centerX - offsetX, leftWrist.y, leftWrist.z);
                Debug.Log($"[Mixamo Rigger] Auto-mirrored RightWrist from LeftWrist");
            }
            else
            {
                rightWrist = Vector3.zero;
            }
            
            if (m_Markers["RightElbow"].isPlaced)
            {
                rightElbow = m_Markers["RightElbow"].Get3DPosition(m_SplatBounds);
            }
            else if (leftElbow != Vector3.zero)
            {
                // Mirror from left
                float offsetX = leftElbow.x - centerX;
                rightElbow = new Vector3(centerX - offsetX, leftElbow.y, leftElbow.z);
                Debug.Log($"[Mixamo Rigger] Auto-mirrored RightElbow from LeftElbow");
            }
            else
            {
                rightElbow = Vector3.zero;
            }
            
            if (m_Markers["RightKnee"].isPlaced)
            {
                rightKnee = m_Markers["RightKnee"].Get3DPosition(m_SplatBounds);
            }
            else if (leftKnee != Vector3.zero)
            {
                // Mirror from left
                float offsetX = leftKnee.x - centerX;
                rightKnee = new Vector3(centerX - offsetX, leftKnee.y, leftKnee.z);
                Debug.Log($"[Mixamo Rigger] Auto-mirrored RightKnee from LeftKnee");
            }
            else
            {
                rightKnee = Vector3.zero;
            }
            
            // Infer spine chain (from groin to chin)
            InferMarker("Hips", groinPos.x, groinPos.y, groinPos.z);
            InferMarker("Spine", groinPos.x, Mathf.Lerp(groinPos.y, chinPos.y, 0.15f), groinPos.z);
            InferMarker("Spine1", groinPos.x, Mathf.Lerp(groinPos.y, chinPos.y, 0.35f), groinPos.z);
            InferMarker("Spine2", groinPos.x, Mathf.Lerp(groinPos.y, chinPos.y, 0.55f), groinPos.z);
            InferMarker("Neck", groinPos.x, Mathf.Lerp(groinPos.y, chinPos.y, 0.85f), groinPos.z);
            InferMarker("Head", chinPos.x, chinPos.y, chinPos.z);
            
            // Infer left arm chain (shoulder at chest level, then elbow to wrist)
            float chestY = Mathf.Lerp(groinPos.y, chinPos.y, 0.55f);
            float shoulderY = Mathf.Lerp(groinPos.y, chinPos.y, 0.75f); // Higher up for shoulders
            
            // Left arm: Place shoulder near center, upper arm between shoulder and elbow
            InferMarker("LeftShoulder", Mathf.Lerp(groinPos.x, leftElbow.x, 0.15f), shoulderY, Mathf.Lerp(groinPos.z, leftElbow.z, 0.2f));
            InferMarker("LeftArm", Mathf.Lerp(groinPos.x, leftElbow.x, 0.4f), Mathf.Lerp(shoulderY, leftElbow.y, 0.25f), Mathf.Lerp(groinPos.z, leftElbow.z, 0.5f));
            // Forearm positioned midway between elbow and wrist for better bone representation
            Vector3 leftForearmPos = Vector3.Lerp(leftElbow, leftWrist, 0.5f);
            InferMarker("LeftForeArm", leftForearmPos.x, leftForearmPos.y, leftForearmPos.z);
            
            // Hand should be at palm center, not wrist - extend from wrist toward hand center
            // Calculate direction from elbow to wrist, then extend further
            Vector3 leftElbowToWrist = leftWrist - leftElbow;
            float forearmLength = leftElbowToWrist.magnitude;
            Vector3 leftHandDirection = leftElbowToWrist.normalized;
            // Hand extends about 30% of forearm length from wrist toward palm
            float handLength = forearmLength * 0.3f;
            Vector3 leftHandPos = leftWrist + leftHandDirection * handLength;
            // Also adjust downward slightly (hand hangs lower than wrist)
            leftHandPos.y -= height * 0.02f;
            InferMarker("LeftHand", leftHandPos.x, leftHandPos.y, leftHandPos.z);
            Debug.Log($"[Mixamo Rigger] LeftHand positioned: Wrist={leftWrist}, Hand={leftHandPos} (extended {handLength:F3} from wrist)");
            
            // Right arm chain (mirror of left)
            InferMarker("RightShoulder", Mathf.Lerp(groinPos.x, rightElbow.x, 0.15f), shoulderY, Mathf.Lerp(groinPos.z, rightElbow.z, 0.2f));
            InferMarker("RightArm", Mathf.Lerp(groinPos.x, rightElbow.x, 0.4f), Mathf.Lerp(shoulderY, rightElbow.y, 0.25f), Mathf.Lerp(groinPos.z, rightElbow.z, 0.5f));
            // Forearm positioned midway between elbow and wrist for better bone representation
            Vector3 rightForearmPos = Vector3.Lerp(rightElbow, rightWrist, 0.5f);
            InferMarker("RightForeArm", rightForearmPos.x, rightForearmPos.y, rightForearmPos.z);
            
            // Right hand - same logic as left
            Vector3 rightElbowToWrist = rightWrist - rightElbow;
            float rightForearmLength = rightElbowToWrist.magnitude;
            Vector3 rightHandDirection = rightElbowToWrist.normalized;
            float rightHandLength = rightForearmLength * 0.3f;
            Vector3 rightHandPos = rightWrist + rightHandDirection * rightHandLength;
            rightHandPos.y -= height * 0.02f;
            InferMarker("RightHand", rightHandPos.x, rightHandPos.y, rightHandPos.z);
            Debug.Log($"[Mixamo Rigger] RightHand positioned: Wrist={rightWrist}, Hand={rightHandPos} (extended {rightHandLength:F3} from wrist)");
            
            // Infer left leg chain (hip at groin, knee from marker, foot below knee)
            float hipY = groinPos.y - height * 0.03f; // Slightly below groin for hip joint
            float footY = bottom + height * 0.04f; // Near ground
            
            InferMarker("LeftUpLeg", leftKnee.x, hipY, Mathf.Lerp(groinPos.z, leftKnee.z, 0.5f));
            InferMarker("LeftLeg", leftKnee.x, leftKnee.y, leftKnee.z);
            InferMarker("LeftFoot", leftKnee.x, footY, leftKnee.z + size.z * 0.08f);
            
            // Infer right leg chain (mirror of left)
            InferMarker("RightUpLeg", rightKnee.x, hipY, Mathf.Lerp(groinPos.z, rightKnee.z, 0.5f));
            InferMarker("RightLeg", rightKnee.x, rightKnee.y, rightKnee.z);
            InferMarker("RightFoot", rightKnee.x, footY, rightKnee.z + size.z * 0.08f);
            
            Debug.Log($"[Mixamo Rigger] Inferred full skeleton from essential markers\n" +
                $"Left side: Wrist={leftWrist}, Elbow={leftElbow}, Knee={leftKnee}\n" +
                $"Right side: Wrist={rightWrist}, Elbow={rightElbow}, Knee={rightKnee}");
        }
        
        private void InferMarker(string markerName, float x, float y, float z)
        {
            // Create or update inferred marker
            if (!m_Markers.ContainsKey(markerName))
            {
                m_Markers[markerName] = new JointMarker(markerName, false) { gizmoColor = new Color(0.5f, 0.5f, 0.5f, 0.5f) };
            }
            
            var marker = m_Markers[markerName];
            marker.frontViewPos = new Vector2(x, y);
            marker.sideViewPos = new Vector2(z, y);
            marker.isPlaced = true;
        }
        
        private void CreateBoneChain(Transform parent, Dictionary<string, GameObject> boneObjects, params string[] boneNames)
        {
            Transform currentParent = parent;
            
            foreach (var boneName in boneNames)
            {
                if (!m_Markers.ContainsKey(boneName)) continue;
                var marker = m_Markers[boneName];
                if (!marker.isPlaced && !marker.isRequired) continue;
                
                GameObject boneObj = new GameObject(boneName);
                boneObj.transform.SetParent(currentParent);
                
                if (marker.isPlaced)
                {
                    Vector3 worldPos = marker.Get3DPosition(m_SplatBounds);
                    boneObj.transform.position = worldPos;
                }
                else
                {
                    // Use parent position if not placed
                    boneObj.transform.position = currentParent.position;
                }
                
                var boneComponent = boneObj.AddComponent<GaussianSplatBone>();
                
                // Set gizmo visibility based on user preference
                boneComponent.GetType().GetField("m_ShowGizmo", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)?.SetValue(boneComponent, m_ShowBoneGizmos);
                boneComponent.GetType().GetField("m_ShowBoneName", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)?.SetValue(boneComponent, false);
                boneComponent.GetType().GetField("m_GizmoSize", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)?.SetValue(boneComponent, 0.01f);
                
                // Set bone radius based on size (use character height for better scaling)
                // IMPORTANT: Joint bones need larger radii for proper overlap and blending
                float boneRadius = m_AutoBoneRadius;
                float falloff = 0.3f; // Default falloff for smooth blending
                
                if (m_UseAutoRadius)
                {
                    float characterHeight = m_SplatBounds.size.y; // Use height as primary measure
                    
                    // Joint bones need larger radii to ensure overlap and prevent gaps
                    if (boneName.Contains("Elbow"))
                    {
                        boneRadius = characterHeight * 0.15f; // Larger for elbow joint
                        falloff = 0.4f; // More gradual falloff at joints
                    }
                    else if (boneName.Contains("Knee"))
                    {
                        boneRadius = characterHeight * 0.16f; // Larger for knee joint
                        falloff = 0.4f;
                    }
                    else if (boneName.Contains("Shoulder"))
                    {
                        boneRadius = characterHeight * 0.18f; // Larger for shoulder joint
                        falloff = 0.35f;
                    }
                    else if (boneName.Contains("Wrist") || boneName.Contains("Hand"))
                    {
                        boneRadius = characterHeight * 0.12f; // Larger for wrist/hand
                        falloff = 0.3f;
                    }
                    else if (boneName.Contains("Ankle") || boneName.Contains("Foot"))
                    {
                        boneRadius = characterHeight * 0.13f; // Larger for ankle/foot
                        falloff = 0.3f;
                    }
                    else if (boneName.Contains("Head"))
                    {
                        boneRadius = characterHeight * 0.15f;
                        falloff = 0.3f;
                    }
                    else if (boneName.Contains("Neck"))
                    {
                        boneRadius = characterHeight * 0.12f; // Increased for neck
                        falloff = 0.35f;
                    }
                    else if (boneName.Contains("Spine") || boneName.Contains("Chest") || boneName.Contains("Hips"))
                    {
                        boneRadius = characterHeight * 0.20f; // Increased for torso
                        falloff = 0.3f;
                    }
                    else if (boneName.Contains("Arm") || boneName.Contains("ForeArm"))
                    {
                        boneRadius = characterHeight * 0.12f; // Increased for arms
                        falloff = 0.3f;
                    }
                    else if (boneName.Contains("UpLeg") || boneName.Contains("Leg"))
                    {
                        boneRadius = characterHeight * 0.14f; // Increased for legs
                        falloff = 0.3f;
                    }
                    else
                    {
                        boneRadius = characterHeight * 0.12f; // Increased default
                        falloff = 0.3f;
                    }
                }
                
                boneComponent.radius = boneRadius;
                boneComponent.falloff = falloff;
                
                boneObjects[boneName] = boneObj;
                currentParent = boneObj.transform;
            }
        }
        
        private Avatar CreateHumanoidAvatar(GameObject rigRoot, Dictionary<string, GameObject> boneObjects)
        {
            try
            {
                // Create HumanDescription for the avatar
                HumanDescription humanDesc = new HumanDescription();
                
                // Map bones to HumanBone structure (required bones for Mixamo)
                List<HumanBone> humanBones = new List<HumanBone>();
                
                // Required bones mapping (Mixamo naming to Unity HumanBodyBones)
                var boneMapping = new Dictionary<string, string>
                {
                    // Spine
                    { "Hips", "Hips" },
                    { "Spine", "Spine" },
                    { "Spine1", "Chest" },
                    { "Spine2", "UpperChest" },
                    { "Neck", "Neck" },
                    { "Head", "Head" },
                    
                    // Left Arm
                    { "LeftShoulder", "LeftShoulder" },
                    { "LeftArm", "LeftUpperArm" },
                    { "LeftForeArm", "LeftLowerArm" },
                    { "LeftHand", "LeftHand" },
                    
                    // Right Arm
                    { "RightShoulder", "RightShoulder" },
                    { "RightArm", "RightUpperArm" },
                    { "RightForeArm", "RightLowerArm" },
                    { "RightHand", "RightHand" },
                    
                    // Left Leg
                    { "LeftUpLeg", "LeftUpperLeg" },
                    { "LeftLeg", "LeftLowerLeg" },
                    { "LeftFoot", "LeftFoot" },
                    
                    // Right Leg
                    { "RightUpLeg", "RightUpperLeg" },
                    { "RightLeg", "RightLowerLeg" },
                    { "RightFoot", "RightFoot" }
                };
                
                // Create HumanBone entries for each mapped bone
                foreach (var mapping in boneMapping)
                {
                    string mixamoName = mapping.Key;
                    string humanName = mapping.Value;
                    
                    if (boneObjects.ContainsKey(mixamoName))
                    {
                        HumanBone humanBone = new HumanBone
                        {
                            boneName = mixamoName,
                            humanName = humanName,
                            limit = new HumanLimit { useDefaultValues = true }
                        };
                        humanBones.Add(humanBone);
                    }
                }
                
                humanDesc.human = humanBones.ToArray();
                
                // Create skeleton description (all transforms in the hierarchy)
                List<SkeletonBone> skeletonBones = new List<SkeletonBone>();
                
                // Add root
                skeletonBones.Add(new SkeletonBone
                {
                    name = rigRoot.name,
                    position = rigRoot.transform.localPosition,
                    rotation = rigRoot.transform.localRotation,
                    scale = rigRoot.transform.localScale
                });
                
                // Add all bone transforms
                foreach (var kvp in boneObjects)
                {
                    Transform boneTransform = kvp.Value.transform;
                    skeletonBones.Add(new SkeletonBone
                    {
                        name = kvp.Key,
                        position = boneTransform.localPosition,
                        rotation = boneTransform.localRotation,
                        scale = boneTransform.localScale
                    });
                }
                
                humanDesc.skeleton = skeletonBones.ToArray();
                
                // Set avatar properties
                humanDesc.upperArmTwist = 0.5f;
                humanDesc.lowerArmTwist = 0.5f;
                humanDesc.upperLegTwist = 0.5f;
                humanDesc.lowerLegTwist = 0.5f;
                humanDesc.armStretch = 0.05f;
                humanDesc.legStretch = 0.05f;
                humanDesc.feetSpacing = 0.0f;
                humanDesc.hasTranslationDoF = false;
                
                // Create the avatar
                Avatar avatar = AvatarBuilder.BuildHumanAvatar(rigRoot, humanDesc);
                
                if (avatar != null && avatar.isValid)
                {
                    avatar.name = rigRoot.name + "Avatar";
                    
                    // Save avatar as an asset
                    string assetPath = "Assets/" + avatar.name + ".asset";
                    assetPath = AssetDatabase.GenerateUniqueAssetPath(assetPath);
                    AssetDatabase.CreateAsset(avatar, assetPath);
                    AssetDatabase.SaveAssets();
                    
                    Debug.Log($"[Mixamo Rigger] Created Humanoid Avatar at: {assetPath}");
                    return avatar;
                }
                else
                {
                    Debug.LogError("[Mixamo Rigger] Avatar creation failed - avatar is invalid");
                    return null;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[Mixamo Rigger] Error creating avatar: {e.Message}\n{e.StackTrace}");
                return null;
            }
        }
    }
}

