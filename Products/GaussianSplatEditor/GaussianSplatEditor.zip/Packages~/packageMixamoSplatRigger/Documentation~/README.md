# Mixamo Splat Rigger

Package id: `com.splatworld.mixamo-splat-rigger`

Turn Mixamo skeletons into animated Gaussian splat rigs, skin splat points to bones, and copy motion from one Mixamo rig to another.

Requires a Gaussian Splat renderer already in the project:

- `org.nesnausk.gaussian-splatting` (`GaussianSplatRenderer`), or
- `com.gaussiansplatting.splatbox` (`SplatBoxRenderer`)

## Install

**This project** — already registered in `Packages/manifest.json`:

```json
"com.splatworld.mixamo-splat-rigger": "file:packageMixamoSplatRigger"
```

**Another Unity project** — Package Manager → **+** → **Add package from disk…** and select this folder’s `package.json`.

## Tools

| Menu | What it does |
|---|---|
| **Tools → Gaussian Splats → Mixamo-Style Rigger** | Place Mixamo joints on front/side views and generate a splat rig + skin |
| **Tools → Gaussian Splats → Mixamo Animation Copier** | Copy / retarget animation clips from one Mixamo rig to another |
| **Tools → Gaussian Splats → Import Mixamo FBX** | Import a Mixamo FBX and convert the skinned mesh to animated splats |
| **Tools → Gaussian Splats → Character Swapper** | Align an existing splat rig to a new character |

## Typical workflow

1. Open **Mixamo-Style Rigger**, assign the splat renderer, place joints, click **Generate Mixamo-Compatible Rig**
2. On `GaussianSplatSkin`, assign `GaussianSplatSkinning.compute` if needed, then **Recalculate Weights**
3. Enable **Enable Skinning** and play a Mixamo Animator clip
4. To reuse motion on another character, open **Mixamo Animation Copier**, pick source + target animators, copy clips

# Gaussian Splat Skinning System


A comprehensive bone-based skinning system for Gaussian Splatting that allows you to create animated, deformable splat clouds using a traditional bone hierarchy approach.

## Features

- **Bone-based deformation**: Use transform hierarchies to influence nearby splats
- **GPU-accelerated skinning**: Compute shader-based deformation for high performance
- **Distance-based weighting**: Automatic bone weight calculation based on proximity
- **Multiple bones per splat**: Support for up to 4 bones influencing each splat
- **Flexible bone hierarchy**: Automatic bone discovery and hierarchy management
- **Real-time animation**: Smooth deformation with minimal performance impact
- **Partial skinning**: Apply skinning to only selected splats or regions
- **Selection modes**: All splats, selected splats only, or bounds-based selection
- **Visual feedback**: Gizmo visualization of skinned regions and bone influence

## Components

### 1. GaussianSplatBone
Individual bone component that represents a single transformation point in the hierarchy.

**Properties:**
- **Influence Radius**: Maximum distance at which this bone affects splats
- **Falloff Distance**: Distance at which bone influence begins to fade
- **Max Weight**: Maximum influence weight for this bone
- **Parent Bone**: Reference to parent bone in hierarchy

**Usage:**
```csharp
var bone = gameObject.AddComponent<GaussianSplatBone>();
bone.influenceRadius = 2.0f;
bone.falloffDistance = 1.0f;
bone.maxWeight = 1.0f;
```

### 2. GaussianSplatRig
Manages the entire bone hierarchy and coordinates GPU resources for skinning.

**Properties:**
- **Max Bone Count**: Maximum number of bones supported (default: 64)
- **Auto Capture Bind Poses**: Automatically capture bone transforms on enable
- **Validate Bone Hierarchy**: Check for common bone setup issues

**Methods:**
```csharp
// Gather all bones in the hierarchy
rig.GatherBones();

// Capture bind poses for all bones
rig.CaptureAllBindPoses();

// Validate bone hierarchy for issues
rig.ValidateHierarchy();
```

### 3. GaussianSplatSkin
Main skinning component that applies bone transformations to splats.

**Properties:**
- **Rig**: Reference to the GaussianSplatRig managing the bones
- **Max Bones Per Splat**: Maximum bones that can influence each splat (1-8)
- **Weight Threshold**: Minimum weight required for bone influence
- **Use Distance Based Weights**: Enable distance-based weight calculation
- **Use GPU Acceleration**: Enable GPU-based weight computation
- **Selection Mode**: Choose which splats to skin (All, Selected, or Bounds-based)
- **Auto Select On Bounds**: Automatically update bounds-based selection
- **Selection Center/Size**: Define bounds volume for partial skinning

**Methods:**
```csharp
// Force recalculation of all bone weights
skin.RecalculateWeights();

// Apply skinning transformation
skin.ApplySkinning();

// Selection management
skin.SelectAllSplats();           // Skin all splats
skin.DeselectAllSplats();         // Disable skinning for all splats
skin.SelectSplats(int[] indices); // Skin specific splat indices
skin.SetSelectionBounds(Vector3 center, Vector3 size); // Skin splats in bounds
skin.GetSelectedSplatCount();     // Get number of selected splats

// Advanced selection
skin.AddSplatToSelection(int index);    // Add individual splat
skin.RemoveSplatFromSelection(int index); // Remove individual splat
skin.UseRendererSelection();            // Use current renderer selection
```

### 4. GaussianSplatSkinDemo
Demo component showing various animation presets and automatic setup.

**Features:**
- Automatic bone chain creation
- Multiple animation presets (Wave, Shake, Sway, Twist)
- Real-time bone animation with sine waves
- Gizmo visualization of bone influence

## Setup Guide

### 1. Basic Setup

1. **Add a GaussianSplatRenderer** to your GameObject (if not already present)
2. **Create a bone hierarchy** by adding `GaussianSplatBone` components to transforms
3. **Add a GaussianSplatRig** to manage the bone hierarchy
4. **Add a GaussianSplatSkin** component to apply skinning
5. **Configure selection mode** (All splats, Selected only, or Bounds-based)

### 2. Partial Skinning Setup

For skinning only part of your splat scene:

```csharp
// Method 1: Select specific splat indices
int[] splatIndices = { 0, 1, 2, 100, 101 }; // Skin these specific splats
skin.SelectSplats(splatIndices);

// Method 2: Use bounds-based selection
skin.SetSelectionBounds(new Vector3(0, 1, 0), new Vector3(2, 2, 2));

// Method 3: Use renderer selection (requires manual selection in editor)
skin.UseRendererSelection();
```

### 3. Manual Bone Setup

```csharp
// Create root bone
GameObject rootBoneObj = new GameObject("BoneRoot");
var rootBone = rootBoneObj.AddComponent<GaussianSplatBone>();
rootBone.influenceRadius = 2.0f;

// Create child bones
for (int i = 0; i < boneCount; i++)
{
    GameObject boneObj = new GameObject($"Bone_{i}");
    boneObj.transform.SetParent(rootBoneObj.transform);
    boneObj.transform.localPosition = new Vector3(0, spacing * i, 0);

    var bone = boneObj.AddComponent<GaussianSplatBone>();
    bone.influenceRadius = spacing * 1.5f;
}

// Add rig component
var rig = rootBoneObj.AddComponent<GaussianSplatRig>();
rig.GatherBones();
```

### 4. Automatic Setup with Demo Component

```csharp
// Add demo component for easy setup
var demo = gameObject.AddComponent<GaussianSplatSkinDemo>();
demo.autoCreateBones = true;
demo.bonesPerChain = 4;
demo.boneSpacing = 1.0f;

// Apply animation preset
demo.ApplyPresetAnimation(GaussianSplatSkinDemo.BoneAnimationPreset.Wave);
```

## Animation

### Keyframe Animation

You can animate bones using Unity's standard animation system:

1. Select bones in the hierarchy
2. Open Window > Animation > Animation
3. Create animation clips for bone transforms
4. Use Animation Controller for complex behaviors

### Procedural Animation

```csharp
// Animate bones procedurally
foreach (var bone in rig.allBones)
{
    float time = Time.time * speed;
    float phase = boneIndex * phaseOffset;

    // Apply rotation
    bone.transform.localRotation = Quaternion.Euler(
        Mathf.Sin(time + phase) * amplitude,
        0f,
        0f
    );

    boneIndex++;
}
```

## Performance Considerations

### GPU Acceleration
- Enable `Use GPU Acceleration` for large splat counts (>1000)
- GPU skinning is significantly faster for complex hierarchies

### Weight Calculation
- Adjust `Weight Threshold` to reduce computation for distant bones
- Lower `Max Bones Per Splat` for better performance
- Use `Update Frequency` to control calculation rate

### Bone Count
- Limit bone count to essential bones only
- Use hierarchy depth to your advantage (child bones inherit parent transformations)
- Consider bone influence radii carefully to avoid overlap

## Shader Integration

The system includes two shaders:

1. **GaussianSplatSkinning.compute**: GPU compute shader for weight calculation
2. **RenderSkinnedGaussianSplats.shader**: Modified splat shader with skinning support

The shaders automatically detect and apply bone transformations when:
- Bone matrices are available
- Weight data is computed
- Skinning is enabled

## Troubleshooting

### Common Issues

1. **No deformation visible**
   - Check that bones have valid influence radii
   - Verify bone weights are being calculated
   - Ensure GPU buffers are properly allocated

2. **Performance issues**
   - Reduce `Max Bones Per Splat`
   - Increase `Weight Threshold`
   - Enable `Use GPU Acceleration`

3. **Incorrect bone hierarchy**
   - Use `Validate Hierarchy` in the rig component
   - Check bone bind poses are captured
   - Verify bone indices are assigned correctly

### Debug Visualization

Enable debug options in components:
- `Show Gizmos` in bone components
- `Show Bone Weights` in skin component
- `Draw Bone Connections` in rig component

## Examples

### Simple Swaying Grass

```csharp
// Create vertical bone chain
var boneCount = 5;
var spacing = 0.5f;

for (int i = 0; i < boneCount; i++)
{
    var bone = CreateBone($"GrassBone_{i}", i * spacing);
    bone.influenceRadius = spacing * 2.0f;
}

// Animate with wind effect
void Update()
{
    foreach (var bone in bones)
    {
        float wind = Mathf.Sin(Time.time + boneIndex * 0.5f) * 0.3f;
        bone.transform.localRotation = Quaternion.Euler(wind * 20f, 0f, 0f);
        boneIndex++;
    }
}
```

### Character Animation

```csharp
// Create skeletal structure
var spine = CreateBone("Spine", Vector3.up * 1.0f);
var leftArm = CreateBone("LeftArm", Vector3.up * 1.5f);
var rightArm = CreateBone("RightArm", Vector3.up * 1.5f);

// Apply character animation
void AnimateCharacter()
{
// Walking cycle
    float cycle = Mathf.Sin(Time.time * 2.0f);

    spine.transform.localRotation = Quaternion.Euler(cycle * 5f, 0f, 0f);
    leftArm.transform.localRotation = Quaternion.Euler(cycle * 30f, 0f, 0f);
    rightArm.transform.localRotation = Quaternion.Euler(-cycle * 30f, 0f, 0f);
}
```

### Partial Scene Skinning

```csharp
// Skin only the upper portion of a splat scene
var skin = GetComponent<GaussianSplatSkin>();

// Method 1: Bounds-based selection
Vector3 boundsCenter = new Vector3(0, 2, 0); // Center at Y=2
Vector3 boundsSize = new Vector3(4, 2, 4);   // 4x2x4 bounds
skin.SetSelectionBounds(boundsCenter, boundsSize);

// Method 2: Select specific splat ranges
int[] upperSplats = Enumerable.Range(1000, 500).ToArray(); // Splats 1000-1499
skin.SelectSplats(upperSplats);

// Animate only the selected portion
void AnimateUpperSection()
{
    foreach (var bone in rig.allBones)
    {
        float wave = Mathf.Sin(Time.time * 2.0f + boneIndex * 0.5f) * 0.3f;
        bone.transform.localRotation = Quaternion.Euler(wave * 20f, 0f, 0f);
        boneIndex++;
    }
}
```

### Interactive Selection

```csharp
// Allow user to paint selection with mouse/cursor
public class InteractiveSplatSelector : MonoBehaviour
{
    private GaussianSplatSkin m_Skin;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                // Convert world position to splat index (simplified)
                int splatIndex = GetSplatIndexAtPosition(hit.point);
                if (splatIndex >= 0)
                {
                    m_Skin.AddSplatToSelection(splatIndex);
                }
            }
        }
    }
}
```

## Technical Details

### Weight Calculation Algorithm

1. **Distance Weight**: `1.0 - (distance - falloffDistance) / (influenceRadius - falloffDistance)`
2. **Bone Selection**: Select bones with highest weights up to `Max Bones Per Splat`
3. **Normalization**: Weights are normalized to sum to 1.0
4. **Thresholding**: Bones with weight < `Weight Threshold` are ignored

### GPU Data Flow

1. **Bone Data**: Transformation matrices uploaded to GPU buffers
2. **Weight Calculation**: Distance-based weights computed per splat
3. **Skinning**: Bone transformations applied using weighted sum
4. **Rendering**: Modified vertex shader applies transformations

### Memory Usage

- **Bone Buffer**: `boneCount * 16 * sizeof(float)` bytes
- **Weight Buffer**: `splatCount * 8 * sizeof(float)` bytes (for 4 bones per splat)
- **Bone Data Buffer**: `boneCount * 4 * sizeof(float)` bytes

## Future Enhancements

- **Orientation-based weighting**: Consider splat orientation for more realistic deformation
- **Physics integration**: Combine with existing physics colliders
- **Animation retargeting**: Transfer animations between different rig structures
- **Multi-resolution skinning**: Different detail levels for LOD
- **Paint weights tool**: Visual editor for manual weight painting

---

For questions or issues, please refer to the component documentation or create an issue in the project repository.
