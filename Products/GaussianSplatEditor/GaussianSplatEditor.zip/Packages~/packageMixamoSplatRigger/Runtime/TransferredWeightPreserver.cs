// SPDX-License-Identifier: MIT

using UnityEngine;
using System.Collections.Generic;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Preserves transferred bone weights from Mixamo rigs after scene reload.
    /// This component stores the transferred weights in a serialized format and restores them
    /// to the GaussianSplatSkin component, preventing recalculation that would overwrite Mixamo weights.
    /// </summary>
    [DefaultExecutionOrder(-100)] // Execute before GaussianSplatSkin
    [System.Serializable]
    public class SerializedSplatWeight
    {
        public Vector4 boneIndices;
        public Vector4 boneWeights;
    }
    
    [System.Serializable]
    public class SerializedBindTransform
    {
        public Matrix4x4 rigBindTransform;
        public Matrix4x4 rigInvBindTransform;
    }
    
    public class TransferredWeightPreserver : MonoBehaviour
    {
        [SerializeField] private GaussianSplatSkin m_TargetSkin;
        [SerializeField] private SerializedSplatWeight[] m_TransferredWeights;
        [SerializeField] private SerializedBindTransform m_BindTransform;
        [SerializeField] private bool m_WeightsRestored = false;
        
        private void Awake()
        {
            if (!m_WeightsRestored && m_TargetSkin != null && m_TransferredWeights != null && m_TransferredWeights.Length > 0)
            {
                RestoreTransferredWeights();
            }
        }
        
        public void SetTransferredWeights(GaussianSplatSkin targetSkin, GaussianSplatSkin.SplatSkin[] weights, Matrix4x4 rigBindTransform, Matrix4x4 rigInvBindTransform)
        {
            m_TargetSkin = targetSkin;
            m_TransferredWeights = new SerializedSplatWeight[weights.Length];
            
            for (int i = 0; i < weights.Length; i++)
            {
                m_TransferredWeights[i] = new SerializedSplatWeight
                {
                    boneIndices = weights[i].boneIndices,
                    boneWeights = weights[i].boneWeights
                };
            }
            
            // Store bind transform
            m_BindTransform = new SerializedBindTransform
            {
                rigBindTransform = rigBindTransform,
                rigInvBindTransform = rigInvBindTransform
            };
        }
        
        private void RestoreTransferredWeights()
        {
            if (m_TargetSkin == null || m_TransferredWeights == null) return;
            
            // Prevent multiple restoration attempts
            if (m_WeightsRestored) return;
            
            // Convert back to SplatSkin format
            var splatSkins = new GaussianSplatSkin.SplatSkin[m_TransferredWeights.Length];
            for (int i = 0; i < m_TransferredWeights.Length; i++)
            {
                splatSkins[i].boneIndices = m_TransferredWeights[i].boneIndices;
                splatSkins[i].boneWeights = m_TransferredWeights[i].boneWeights;
            }
            
            // Use reflection to set the weights directly
            var skinType = typeof(GaussianSplatSkin);
            var splatSkinsField = skinType.GetField("m_SplatSkins", 
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            
            if (splatSkinsField != null)
            {
                splatSkinsField.SetValue(m_TargetSkin, splatSkins);
                
                // Set weights as calculated and cached splat count to prevent recalculation
                var weightsCalculatedField = skinType.GetField("m_WeightsCalculated", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                var cachedSplatCountField = skinType.GetField("m_CachedSplatCount", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                
                if (weightsCalculatedField != null)
                {
                    weightsCalculatedField.SetValue(m_TargetSkin, true);
                }
                
                if (cachedSplatCountField != null)
                {
                    cachedSplatCountField.SetValue(m_TargetSkin, splatSkins.Length);
                }
                
                // CRITICAL: Restore bind transform
                if (m_BindTransform != null)
                {
                    var rigBindTransformField = skinType.GetField("m_RigBindTransform", 
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    var rigInvBindTransformField = skinType.GetField("m_RigInvBindTransform", 
                        System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                    
                    if (rigBindTransformField != null && rigInvBindTransformField != null)
                    {
                        rigBindTransformField.SetValue(m_TargetSkin, m_BindTransform.rigBindTransform);
                        rigInvBindTransformField.SetValue(m_TargetSkin, m_BindTransform.rigInvBindTransform);
                    }
                }
                
                // Upload to GPU
                var uploadMethod = skinType.GetMethod("UploadWeightsToGPU", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                if (uploadMethod != null)
                {
                    uploadMethod.Invoke(m_TargetSkin, null);
                }
                
                m_WeightsRestored = true;
            }
        }
        
        [ContextMenu("Force Restore Weights")]
        public void ForceRestoreWeights()
        {
            m_WeightsRestored = false;
            RestoreTransferredWeights();
        }
    }
}
