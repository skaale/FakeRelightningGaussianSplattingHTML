// SPDX-License-Identifier: MIT

using UnityEngine;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Helper component for Mixamo-based Gaussian splat characters
    /// Provides easy access to standard Mixamo bones
    /// </summary>
    public class MixamoSplatCharacter : MonoBehaviour
    {
        [Header("Components")]
        [SerializeField] private GaussianSplatRenderer m_Renderer;
        [SerializeField] private GaussianSplatRig m_Rig;
        [SerializeField] private GaussianSplatSkin m_Skin;
        [SerializeField] private Animator m_Animator;
        
        [Header("Root Bones")]
        [SerializeField] private Transform m_Hips;
        [SerializeField] private Transform m_Spine;
        [SerializeField] private Transform m_Head;
        
        [Header("Arm Bones")]
        [SerializeField] private Transform m_LeftShoulder;
        [SerializeField] private Transform m_LeftArm;
        [SerializeField] private Transform m_LeftForeArm;
        [SerializeField] private Transform m_LeftHand;
        [SerializeField] private Transform m_RightShoulder;
        [SerializeField] private Transform m_RightArm;
        [SerializeField] private Transform m_RightForeArm;
        [SerializeField] private Transform m_RightHand;
        
        [Header("Leg Bones")]
        [SerializeField] private Transform m_LeftUpLeg;
        [SerializeField] private Transform m_LeftLeg;
        [SerializeField] private Transform m_LeftFoot;
        [SerializeField] private Transform m_RightUpLeg;
        [SerializeField] private Transform m_RightLeg;
        [SerializeField] private Transform m_RightFoot;

        // Public accessors
        public GaussianSplatRenderer renderer => m_Renderer;
        public GaussianSplatRig rig => m_Rig;
        public GaussianSplatSkin skin => m_Skin;
        public Animator animator => m_Animator;
        
        public Transform hips => m_Hips;
        public Transform spine => m_Spine;
        public Transform head => m_Head;
        
        public Transform leftShoulder => m_LeftShoulder;
        public Transform leftArm => m_LeftArm;
        public Transform leftForeArm => m_LeftForeArm;
        public Transform leftHand => m_LeftHand;
        
        public Transform rightShoulder => m_RightShoulder;
        public Transform rightArm => m_RightArm;
        public Transform rightForeArm => m_RightForeArm;
        public Transform rightHand => m_RightHand;
        
        public Transform leftUpLeg => m_LeftUpLeg;
        public Transform leftLeg => m_LeftLeg;
        public Transform leftFoot => m_LeftFoot;
        
        public Transform rightUpLeg => m_RightUpLeg;
        public Transform rightLeg => m_RightLeg;
        public Transform rightFoot => m_RightFoot;

        private void Reset()
        {
            AutoFindComponents();
        }

        private void OnValidate()
        {
            if (m_Rig == null || m_Hips == null)
            {
                AutoFindComponents();
            }
        }

        [ContextMenu("Auto-Find Components")]
        public void AutoFindComponents()
        {
            // Find main components
            if (m_Renderer == null)
                m_Renderer = GetComponentInChildren<GaussianSplatRenderer>();
            
            if (m_Rig == null)
                m_Rig = GetComponentInChildren<GaussianSplatRig>();
            
            if (m_Skin == null)
                m_Skin = GetComponentInChildren<GaussianSplatSkin>();
            
            if (m_Animator == null)
                m_Animator = GetComponentInChildren<Animator>();
            
            // Find Mixamo bones
            if (m_Rig != null && m_Rig.bones != null)
            {
                foreach (GaussianSplatBone bone in m_Rig.bones)
                {
                    if (bone == null) continue;
                    
                    switch (bone.name)
                    {
                        case "Hips": m_Hips = bone.transform; break;
                        case "Spine": m_Spine = bone.transform; break;
                        case "Head": m_Head = bone.transform; break;
                        
                        case "LeftShoulder": m_LeftShoulder = bone.transform; break;
                        case "LeftArm": m_LeftArm = bone.transform; break;
                        case "LeftForeArm": m_LeftForeArm = bone.transform; break;
                        case "LeftHand": m_LeftHand = bone.transform; break;
                        
                        case "RightShoulder": m_RightShoulder = bone.transform; break;
                        case "RightArm": m_RightArm = bone.transform; break;
                        case "RightForeArm": m_RightForeArm = bone.transform; break;
                        case "RightHand": m_RightHand = bone.transform; break;
                        
                        case "LeftUpLeg": m_LeftUpLeg = bone.transform; break;
                        case "LeftLeg": m_LeftLeg = bone.transform; break;
                        case "LeftFoot": m_LeftFoot = bone.transform; break;
                        
                        case "RightUpLeg": m_RightUpLeg = bone.transform; break;
                        case "RightLeg": m_RightLeg = bone.transform; break;
                        case "RightFoot": m_RightFoot = bone.transform; break;
                    }
                }
            }
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            #endif
        }

        /// <summary>
        /// Play animation by name
        /// </summary>
        public void PlayAnimation(string animationName)
        {
            if (m_Animator != null && m_Animator.runtimeAnimatorController != null)
            {
                m_Animator.Play(animationName);
            }
        }

        /// <summary>
        /// Set animation speed
        /// </summary>
        public void SetAnimationSpeed(float speed)
        {
            if (m_Animator != null)
            {
                m_Animator.speed = speed;
            }
        }

        /// <summary>
        /// Enable/disable skinning
        /// </summary>
        public void SetSkinningEnabled(bool enabled)
        {
            if (m_Skin != null)
            {
            }
        }

        /// <summary>
        /// Get bone by Mixamo name
        /// </summary>
        public Transform GetBone(string mixamoBoneName)
        {
            if (m_Rig == null || m_Rig.bones == null) return null;
            
            foreach (GaussianSplatBone bone in m_Rig.bones)
            {
                if (bone != null && bone.name == mixamoBoneName)
                {
                    return bone.transform;
                }
            }
            
            return null;
        }

        /// <summary>
        /// Recalculate skin weights
        /// </summary>
        [ContextMenu("Recalculate Weights")]
        public void RecalculateWeights()
        {
            if (m_Skin != null)
            {
                m_Skin.RecalculateWeights();
            }
        }

        /// <summary>
        /// Print character info
        /// </summary>
        [ContextMenu("Print Info")]
        public void PrintInfo()
        {
        }
    }
}

