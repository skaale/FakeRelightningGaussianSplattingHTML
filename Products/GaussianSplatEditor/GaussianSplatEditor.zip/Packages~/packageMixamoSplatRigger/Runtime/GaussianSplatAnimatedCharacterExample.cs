// SPDX-License-Identifier: MIT

using UnityEngine;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Example script showing how to use animated Gaussian splat characters
    /// This demonstrates the complete workflow for working with converted SkinnedMesh splats
    /// </summary>
    public class GaussianSplatAnimatedCharacterExample : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private GaussianSplatRenderer m_Renderer;
        [SerializeField] private GaussianSplatRig m_Rig;
        [SerializeField] private GaussianSplatSkin m_Skin;
        [SerializeField] private GaussianSplatAnimationPlayer m_AnimationPlayer;
        
        [Header("Example Actions")]
        [SerializeField] private bool m_AutoFindComponents = true;
        [SerializeField] private KeyCode m_PlayKey = KeyCode.Space;
        [SerializeField] private KeyCode m_StopKey = KeyCode.Escape;
        [SerializeField] private KeyCode m_NextClipKey = KeyCode.N;
        
        [Header("Info")]
        [SerializeField] private int m_CurrentClipIndex = 0;
        [SerializeField] private string m_CurrentClipName = "";

        private void Awake()
        {
            if (m_AutoFindComponents)
            {
                FindComponents();
            }
        }

        private void Start()
        {
            ValidateSetup();
        }

        private void Update()
        {
            HandleInput();
            UpdateInfo();
        }

        private void FindComponents()
        {
            if (m_Renderer == null)
                m_Renderer = GetComponentInChildren<GaussianSplatRenderer>();
            
            if (m_Rig == null)
                m_Rig = GetComponentInChildren<GaussianSplatRig>();
            
            if (m_Skin == null)
                m_Skin = GetComponentInChildren<GaussianSplatSkin>();
            
            if (m_AnimationPlayer == null)
                m_AnimationPlayer = GetComponentInChildren<GaussianSplatAnimationPlayer>();
        }

        private void ValidateSetup()
        {
        }

        private void HandleInput()
        {
            if (m_AnimationPlayer == null) return;
            
            if (Input.GetKeyDown(m_PlayKey))
            {
                PlayCurrentClip();
            }
            
            if (Input.GetKeyDown(m_StopKey))
            {
                StopAnimation();
            }
            
            if (Input.GetKeyDown(m_NextClipKey))
            {
                NextClip();
            }
        }

        private void UpdateInfo()
        {
            if (m_AnimationPlayer != null)
            {
                m_CurrentClipName = m_AnimationPlayer.isPlaying ? "Playing" : "Stopped";
            }
        }

        public void PlayCurrentClip()
        {
            if (m_AnimationPlayer == null) return;
            
            m_AnimationPlayer.Play();
        }

        public void StopAnimation()
        {
            if (m_AnimationPlayer == null) return;
            
            m_AnimationPlayer.Stop();
        }

        public void NextClip()
        {
            if (m_AnimationPlayer == null) return;
            
            m_CurrentClipIndex++;
            m_AnimationPlayer.PlayClip(m_CurrentClipIndex);
        }

        public void SetAnimationSpeed(float speed)
        {
            if (m_AnimationPlayer == null) return;
            
            m_AnimationPlayer.SetSpeed(speed);
        }

        [ContextMenu("Recalculate Skin Weights")]
        public void RecalculateSkinWeights()
        {
            if (m_Skin == null)
            {
                return;
            }
            
            m_Skin.RecalculateWeights();
        }

        [ContextMenu("Rebuild Rig")]
        public void RebuildRig()
        {
            if (m_Rig == null)
            {
                return;
            }
            
            m_Rig.RebuildRig();
        }

        [ContextMenu("Print Debug Info")]
        public void PrintDebugInfo()
        {
        }
    }
}

