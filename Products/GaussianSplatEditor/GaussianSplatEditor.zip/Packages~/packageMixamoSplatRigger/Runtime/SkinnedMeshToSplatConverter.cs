// SPDX-License-Identifier: MIT

using UnityEngine;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Converts a SkinnedMeshRenderer to Gaussian splats with bone weights
    /// </summary>
    [ExecuteInEditMode]
    public class SkinnedMeshToSplatConverter : MonoBehaviour
    {
        [Header("Source")]
        [SerializeField] SkinnedMeshRenderer m_SkinnedMeshRenderer;
        [SerializeField] bool m_AutoDetectSkinnedMesh = true;
        
        [Header("Target")]
        [SerializeField] GaussianSplatRenderer m_TargetRenderer;
        [SerializeField] GaussianSplatRig m_TargetRig;
        [SerializeField] GaussianSplatSkin m_TargetSkin;
        
        [Header("Settings")]
        [SerializeField] float m_SplatScale = 0.01f;
        [SerializeField] float m_SplatOpacity = 1.0f;
        [SerializeField] bool m_UseVertexColors = true;
        [SerializeField] Color m_DefaultColor = Color.white;
        [SerializeField] bool m_ConvertOnStart = false;
        
        [Header("Bone Settings")]
        [SerializeField] float m_BoneRadiusMultiplier = 2.0f;
        [SerializeField] float m_BoneFalloff = 0.5f;
        [SerializeField] bool m_CreateBoneHierarchy = true;
        
        void Start()
        {
            if (m_ConvertOnStart)
            {
                ConvertSkinnedMesh();
            }
        }
        
        void OnValidate()
        {
            if (m_AutoDetectSkinnedMesh && m_SkinnedMeshRenderer == null)
            {
                m_SkinnedMeshRenderer = GetComponent<SkinnedMeshRenderer>();
            }
        }
        
        public void ConvertSkinnedMesh()
        {
            if (m_SkinnedMeshRenderer == null || m_SkinnedMeshRenderer.sharedMesh == null)
            {
                Debug.LogError("No skinned mesh found to convert!");
                return;
            }
            
            if (m_TargetRenderer == null)
            {
                Debug.LogError("No target GaussianSplatRenderer assigned!");
                return;
            }
            
            Mesh mesh = m_SkinnedMeshRenderer.sharedMesh;
            Vector3[] vertices = mesh.vertices;
            Vector3[] normals = mesh.normals;
            Color[] colors = m_UseVertexColors ? mesh.colors : null;
            BoneWeight[] boneWeights = mesh.boneWeights;
            Transform[] bones = m_SkinnedMeshRenderer.bones;
            Matrix4x4[] bindPoses = mesh.bindposes;
            
            if (normals == null || normals.Length == 0)
            {
                mesh.RecalculateNormals();
                normals = mesh.normals;
            }
            
            // Create rig if needed
            if (m_CreateBoneHierarchy && m_TargetRig != null)
            {
                CreateBoneHierarchy(bones, bindPoses);
            }
            
            Transform meshTransform = m_SkinnedMeshRenderer.transform;
            
            // Convert vertices to splats
            for (int i = 0; i < vertices.Length; i++)
            {
                Vector3 worldPos = meshTransform.TransformPoint(vertices[i]);
                Vector3 worldNormal = meshTransform.TransformDirection(normals[i]).normalized;
                
                Quaternion rotation = worldNormal != Vector3.zero 
                    ? Quaternion.LookRotation(worldNormal, Vector3.up)
                    : Quaternion.identity;
                
                Color color = colors != null && i < colors.Length ? colors[i] : m_DefaultColor;
                
                m_TargetRenderer.PaintSplats(
                    worldPos,
                    rotation,
                    m_SplatScale,
                    m_SplatOpacity,
                    1,
                    color
                );
            }
            
            Debug.Log($"Converted {vertices.Length} vertices to splats with {bones.Length} bones!");
            
            // After converting, calculate skin weights if skin component exists
            if (m_TargetSkin != null && m_TargetRig != null)
            {
                m_TargetSkin.RecalculateWeights();
            }
        }
        
        void CreateBoneHierarchy(Transform[] srcBones, Matrix4x4[] bindPoses)
        {
            if (srcBones == null || srcBones.Length == 0) return;
            
            Transform rigRoot = m_TargetRig.transform;
            
            // Create bone GameObjects
            for (int i = 0; i < srcBones.Length; i++)
            {
                if (srcBones[i] == null) continue;
                
                // Create bone object
                GameObject boneObj = new GameObject(srcBones[i].name);
                
                // Set parent
                if (srcBones[i].parent != null)
                {
                    int parentIdx = System.Array.IndexOf(srcBones, srcBones[i].parent);
                    if (parentIdx >= 0)
                    {
                        Transform parentBone = rigRoot.Find(srcBones[parentIdx].name);
                        if (parentBone != null)
                            boneObj.transform.SetParent(parentBone, false);
                        else
                            boneObj.transform.SetParent(rigRoot, false);
                    }
                    else
                    {
                        boneObj.transform.SetParent(rigRoot, false);
                    }
                }
                else
                {
                    boneObj.transform.SetParent(rigRoot, false);
                }
                
                // Set transform from bind pose
                Matrix4x4 bindPose = bindPoses[i].inverse;
                boneObj.transform.position = bindPose.GetColumn(3);
                boneObj.transform.rotation = bindPose.rotation;
                
                // Add bone component
                GaussianSplatBone bone = boneObj.AddComponent<GaussianSplatBone>();
                bone.radius = CalculateBoneRadius(srcBones[i], srcBones) * m_BoneRadiusMultiplier;
                bone.falloff = m_BoneFalloff;
            }
            
            // Rebuild rig
            m_TargetRig.RebuildRig();
        }
        
        float CalculateBoneRadius(Transform bone, Transform[] allBones)
        {
            // Find closest child bone or use default radius
            float minDist = 1.0f;
            
            foreach (Transform child in bone)
            {
                if (System.Array.IndexOf(allBones, child) >= 0)
                {
                    float dist = Vector3.Distance(bone.position, child.position);
                    if (dist > 0 && dist < minDist)
                        minDist = dist;
                }
            }
            
            return minDist * 0.5f;
        }
    }
}

