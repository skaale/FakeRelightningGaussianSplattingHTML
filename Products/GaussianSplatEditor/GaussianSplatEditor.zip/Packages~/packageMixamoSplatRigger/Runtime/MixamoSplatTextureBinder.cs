// SPDX-License-Identifier: MIT

#if SPLATBOX
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Binds mesh albedo + splat UVs immediately before the target renderer draws.
    /// </summary>
    public static class MixamoSplatTextureBinder
    {
        static readonly int Enabled = Shader.PropertyToID("_MeshTexEnabled");
        static readonly int Texture = Shader.PropertyToID("_MeshTex");
        static readonly int Uvs = Shader.PropertyToID("_SplatMeshUvs");
        static readonly Dictionary<SplatBoxRenderer, MixamoSplatTextureOverlay> Overlays = new();

        static MixamoSplatTextureBinder()
        {
            GaussianSplatRenderSystem.OnBeforeDrawSplatsForRenderer += Bind;
        }

        public static void Register(MixamoSplatTextureOverlay overlay)
        {
            if (overlay == null)
                return;

            Unregister(overlay);
            SplatBoxRenderer renderer = overlay.targetRenderer;
            if (renderer != null)
                Overlays[renderer] = overlay;
        }

        public static void Unregister(MixamoSplatTextureOverlay overlay)
        {
            if (overlay == null)
                return;

            SplatBoxRenderer matched = null;
            foreach (var pair in Overlays)
            {
                if (pair.Value == overlay)
                {
                    matched = pair.Key;
                    break;
                }
            }

            if (matched != null)
                Overlays.Remove(matched);
        }

        static void Bind(
            SplatBoxRenderer renderer,
            CommandBuffer commandBuffer,
            MaterialPropertyBlock properties)
        {
            if (!Overlays.TryGetValue(renderer, out var overlay) ||
                overlay == null || !overlay.isReady)
            {
                Disable(properties);
                return;
            }

            properties.SetInt(Enabled, 1);
            properties.SetTexture(Texture, overlay.albedoTexture);
            properties.SetBuffer(Uvs, overlay.uvBuffer);
        }

        static void Disable(MaterialPropertyBlock properties)
        {
            properties.SetInt(Enabled, 0);
            properties.SetTexture(Texture, Texture2D.blackTexture);
        }
    }
}
#endif
