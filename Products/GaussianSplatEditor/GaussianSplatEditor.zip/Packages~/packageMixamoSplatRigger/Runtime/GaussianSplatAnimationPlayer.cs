// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Plays Unity AnimationClips on Gaussian Splat rigs
    /// Works with Animator or can play clips directly
    /// </summary>
    [RequireComponent(typeof(GaussianSplatRig))]
    public class GaussianSplatAnimationPlayer : MonoBehaviour
    {
        [Header("Animation")]
        [SerializeField] private AnimationClip[] m_Clips;
        [SerializeField] private int m_CurrentClipIndex = 0;
        [SerializeField] private bool m_PlayOnStart = true;
        [SerializeField] private bool m_Loop = true;
        [SerializeField] private float m_Speed = 1.0f;
        
        [Header("Playback")]
        [SerializeField] private bool m_IsPlaying = false;
        [SerializeField] private float m_Time = 0f;
        
        [Header("Blend")]
        [SerializeField] private float m_BlendTime = 0.3f;
        
        private GaussianSplatRig m_Rig;
        private Animator m_Animator;
        private Animation m_LegacyAnimation;
        private AnimationState m_CurrentState;
        
        // For direct animation playback (without Animator)
        private AnimationClip m_CurrentClip;
        private float m_ClipLength;
        
        public bool isPlaying
        {
            get => m_IsPlaying;
            set => m_IsPlaying = value;
        }
        
        public float time
        {
            get => m_Time;
            set => m_Time = Mathf.Clamp(value, 0, m_ClipLength);
        }
        
        public float normalizedTime
        {
            get => m_ClipLength > 0 ? m_Time / m_ClipLength : 0;
            set => m_Time = Mathf.Clamp01(value) * m_ClipLength;
        }

        private void Awake()
        {
            m_Rig = GetComponent<GaussianSplatRig>();
            m_Animator = GetComponent<Animator>();
            m_LegacyAnimation = GetComponent<Animation>();
            
            // Try to use Animator if available
            if (m_Animator == null && m_LegacyAnimation == null && m_Clips != null && m_Clips.Length > 0)
            {
                SetupLegacyAnimation();
            }
        }

        private void Start()
        {
            if (m_PlayOnStart)
            {
                Play();
            }
        }

        private void Update()
        {
            if (!m_IsPlaying) return;
            
            // If using Animator, it handles playback automatically
            if (m_Animator != null && m_Animator.enabled) return;
            
            // Manual playback for legacy animation or direct clip playback
            if (m_LegacyAnimation != null && m_LegacyAnimation.enabled)
            {
                // Legacy animation handles itself
                return;
            }
            
            // Direct clip playback
            if (m_CurrentClip != null)
            {
                m_Time += Time.deltaTime * m_Speed;
                
                if (m_Time >= m_ClipLength)
                {
                    if (m_Loop)
                    {
                        m_Time = m_Time % m_ClipLength;
                    }
                    else
                    {
                        m_Time = m_ClipLength;
                        m_IsPlaying = false;
                    }
                }
                
                SampleClip(m_CurrentClip, m_Time);
            }
        }

        public void Play()
        {
            m_IsPlaying = true;
            m_Time = 0f;
            
            if (m_Animator != null)
            {
                m_Animator.enabled = true;
                m_Animator.Play(0, 0, 0);
            }
            else if (m_LegacyAnimation != null)
            {
                m_LegacyAnimation.Play();
            }
            else if (m_Clips != null && m_Clips.Length > 0)
            {
                PlayClip(m_CurrentClipIndex);
            }
        }

        public void Stop()
        {
            m_IsPlaying = false;
            m_Time = 0f;
            
            if (m_Animator != null)
            {
                m_Animator.enabled = false;
            }
            else if (m_LegacyAnimation != null)
            {
                m_LegacyAnimation.Stop();
            }
        }

        public void Pause()
        {
            m_IsPlaying = false;
            
            if (m_LegacyAnimation != null)
            {
                m_LegacyAnimation[m_LegacyAnimation.clip.name].speed = 0;
            }
        }

        public void Resume()
        {
            m_IsPlaying = true;
            
            if (m_LegacyAnimation != null)
            {
                m_LegacyAnimation[m_LegacyAnimation.clip.name].speed = m_Speed;
            }
        }

        public void PlayClip(int index)
        {
            if (m_Clips == null || index < 0 || index >= m_Clips.Length)
            {
                return;
            }
            
            m_CurrentClipIndex = index;
            m_CurrentClip = m_Clips[index];
            m_ClipLength = m_CurrentClip.length;
            m_Time = 0f;
            m_IsPlaying = true;
            
            if (m_LegacyAnimation != null)
            {
                m_LegacyAnimation.clip = m_CurrentClip;
                m_LegacyAnimation.Play();
            }
        }

        public void PlayClip(string name)
        {
            if (m_Clips == null) return;
            
            for (int i = 0; i < m_Clips.Length; i++)
            {
                if (m_Clips[i] != null && m_Clips[i].name == name)
                {
                    PlayClip(i);
                    return;
                }
            }
        }

        public void SetSpeed(float speed)
        {
            m_Speed = speed;
            
            if (m_Animator != null)
            {
                m_Animator.speed = speed;
            }
            else if (m_LegacyAnimation != null && m_LegacyAnimation.clip != null)
            {
                m_LegacyAnimation[m_LegacyAnimation.clip.name].speed = speed;
            }
        }

        private void SetupLegacyAnimation()
        {
            m_LegacyAnimation = gameObject.AddComponent<Animation>();
            
            if (m_Clips != null && m_Clips.Length > 0)
            {
                foreach (var clip in m_Clips)
                {
                    if (clip != null)
                    {
                        m_LegacyAnimation.AddClip(clip, clip.name);
                    }
                }
                
                if (m_Clips[0] != null)
                {
                    m_LegacyAnimation.clip = m_Clips[0];
                    m_CurrentClip = m_Clips[0];
                    m_ClipLength = m_CurrentClip.length;
                }
            }
        }

        private void SampleClip(AnimationClip clip, float time)
        {
            if (clip == null || m_Rig == null || m_Rig.bones == null) return;
            
            // Sample animation at current time
            clip.SampleAnimation(gameObject, time);
        }

        public void AddClip(AnimationClip clip)
        {
            if (clip == null) return;
            
            if (m_Clips == null)
            {
                m_Clips = new AnimationClip[] { clip };
            }
            else
            {
                var newClips = new AnimationClip[m_Clips.Length + 1];
                m_Clips.CopyTo(newClips, 0);
                newClips[m_Clips.Length] = clip;
                m_Clips = newClips;
            }
            
            if (m_LegacyAnimation != null)
            {
                m_LegacyAnimation.AddClip(clip, clip.name);
            }
        }

        public void RemoveClip(int index)
        {
            if (m_Clips == null || index < 0 || index >= m_Clips.Length) return;
            
            var clipToRemove = m_Clips[index];
            var newClips = new AnimationClip[m_Clips.Length - 1];
            
            for (int i = 0, j = 0; i < m_Clips.Length; i++)
            {
                if (i != index)
                {
                    newClips[j++] = m_Clips[i];
                }
            }
            
            m_Clips = newClips;
            
            if (m_LegacyAnimation != null && clipToRemove != null)
            {
                m_LegacyAnimation.RemoveClip(clipToRemove.name);
            }
        }

        private void OnValidate()
        {
            m_Speed = Mathf.Max(0, m_Speed);
            m_BlendTime = Mathf.Max(0, m_BlendTime);
            
            if (m_Clips != null && m_CurrentClipIndex >= m_Clips.Length)
            {
                m_CurrentClipIndex = Mathf.Max(0, m_Clips.Length - 1);
            }
        }
    }
}

