// SPDX-License-Identifier: MIT

using UnityEngine;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Samples the original mesh albedo across each Gaussian at render time so
    /// 8K (or any high-res) texture detail is not collapsed to one color per splat.
    /// </summary>
    [RequireComponent(typeof(GaussianSplatRenderer))]
    public class MixamoSplatTextureOverlay : MonoBehaviour
    {
        [SerializeField] Texture m_AlbedoTexture;
        [SerializeField] MixamoSplatUvData m_UvData;

        GraphicsBuffer m_UvBuffer;
        GaussianSplatRenderer m_Renderer;

        public Texture albedoTexture => m_AlbedoTexture;
        public GraphicsBuffer uvBuffer => m_UvBuffer;
        public GaussianSplatRenderer targetRenderer => m_Renderer;

        public bool isReady =>
            isActiveAndEnabled &&
            m_AlbedoTexture != null &&
            m_UvBuffer != null &&
            m_UvBuffer.IsValid();

        public void SetData(Texture albedo, MixamoSplatUvData uvData)
        {
            m_AlbedoTexture = albedo;
            m_UvData = uvData;
            Upload();
        }

        void OnEnable()
        {
            m_Renderer = GetComponent<GaussianSplatRenderer>();
            Upload();
#if SPLATBOX
            MixamoSplatTextureBinder.Register(this);
#endif
        }

        void OnDisable()
        {
#if SPLATBOX
            MixamoSplatTextureBinder.Unregister(this);
#endif
            Release();
        }

        void Upload()
        {
            Release();
            if (m_UvData == null || m_UvData.count == 0)
                return;

            m_UvBuffer = new GraphicsBuffer(
                GraphicsBuffer.Target.Structured,
                m_UvData.count,
                sizeof(float) * 8);
            m_UvBuffer.SetData(m_UvData.uvs);
        }

        void Release()
        {
            m_UvBuffer?.Release();
            m_UvBuffer = null;
        }
    }
}
