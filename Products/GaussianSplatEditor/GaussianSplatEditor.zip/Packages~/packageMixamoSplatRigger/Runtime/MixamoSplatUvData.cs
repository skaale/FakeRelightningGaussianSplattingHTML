// SPDX-License-Identifier: MIT

using System;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Per-splat mesh UVs stored outside the scene so Inspector edits stay cheap.
    /// uvSigmaX/Y are UV deltas along one Gaussian sigma of the splat's local X/Y axes.
    /// </summary>
    public sealed class MixamoSplatUvData : ScriptableObject
    {
        [Serializable]
        public struct SplatMeshUv
        {
            public Vector2 uv;
            public Vector2 uvSigmaX;
            public Vector2 uvSigmaY;
            public Vector2 pad;
        }

        [SerializeField, HideInInspector]
        SplatMeshUv[] m_Uvs;

        public SplatMeshUv[] uvs => m_Uvs;
        public int count => m_Uvs != null ? m_Uvs.Length : 0;

        public void SetUvs(SplatMeshUv[] uvs)
        {
            m_Uvs = uvs;
        }
    }
}
