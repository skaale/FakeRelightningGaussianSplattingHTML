// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Demo: Animate bones to see splats deform.
    /// Assign existing rig from scene (don't auto-create).
    /// </summary>
    public class GaussianSplatSkinDemo : MonoBehaviour
    {
        [Header("Setup - Assign from Scene")]
        [SerializeField] private GaussianSplatRig m_Rig;

        [Header("Animation")]
        [SerializeField] private AnimMode m_AnimMode = AnimMode.Wave;
        [SerializeField] private float m_Speed = 2f;
        [SerializeField] private float m_Amplitude = 0.5f;

        public enum AnimMode { Wave, Sway, Twist, Rotate }

        private GaussianSplatBone[] m_Bones;
        private float m_Time;

        private void Start()
        {
            if (m_Rig == null)
            {
                Debug.LogError("GaussianSplatSkinDemo: No rig assigned! Assign a rig from the scene.");
                enabled = false;
                return;
            }

            m_Bones = m_Rig.bones;
            if (m_Bones == null || m_Bones.Length == 0)
            {
                Debug.LogError("GaussianSplatSkinDemo: Rig has no bones!");
                enabled = false;
            }
        }

        private void Update()
        {
            if (m_Bones == null || m_Bones.Length == 0) return;
            if (!enabled) return; // Don't animate if disabled
            
            m_Time += Time.deltaTime * m_Speed;

            switch (m_AnimMode)
            {
                case AnimMode.Wave:
                    AnimateWave();
                    break;
                case AnimMode.Sway:
                    AnimateSway();
                    break;
                case AnimMode.Twist:
                    AnimateTwist();
                    break;
                case AnimMode.Rotate:
                    AnimateRotate();
                    break;
            }
            
            // Debug only once
            if (Time.frameCount == 60 && m_Bones[0] != null)
            {
                Debug.Log($"✅ Demo animating: {m_AnimMode}, Amplitude={m_Amplitude}");
            }
        }

        private void AnimateWave()
        {
            for (int i = 0; i < m_Bones.Length; i++)
            {
                if (m_Bones[i] == null) continue;
                float phase = i * 0.5f;
                float wave = Mathf.Sin(m_Time + phase) * m_Amplitude;
                m_Bones[i].transform.localRotation = Quaternion.Euler(wave * 30f, 0, 0);
            }
        }

        private void AnimateSway()
        {
            for (int i = 0; i < m_Bones.Length; i++)
            {
                if (m_Bones[i] == null) continue;
                float phase = i * 0.3f;
                float sway = Mathf.Sin(m_Time + phase) * m_Amplitude;
                m_Bones[i].transform.localRotation = Quaternion.Euler(0, 0, sway * 20f);
            }
        }

        private void AnimateTwist()
        {
            for (int i = 0; i < m_Bones.Length; i++)
            {
                if (m_Bones[i] == null) continue;
                float twist = (m_Time + i * 0.2f) * m_Amplitude;
                m_Bones[i].transform.localRotation = Quaternion.Euler(0, twist * 50f, 0);
            }
        }

        private void AnimateRotate()
        {
            for (int i = 0; i < m_Bones.Length; i++)
            {
                if (m_Bones[i] == null) continue;
                float rot = m_Time * m_Amplitude * (i + 1);
                m_Bones[i].transform.localRotation = Quaternion.Euler(rot * 20f, rot * 30f, 0);
            }
        }
    }
}
