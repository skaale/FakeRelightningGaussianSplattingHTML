// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Manages bone hierarchy for Gaussian splat skinning.
    /// Build bone hierarchy in scene, then use GaussianSplatSkin to apply skinning.
    /// IMPORTANT: Updates bone matrices in LateUpdate before GaussianSplatSkin applies them
    /// </summary>
    [DefaultExecutionOrder(-10)] // Run before GaussianSplatSkin (order 0) and GaussianSplatPhysicsCollider (order 100)
    public class GaussianSplatRig : MonoBehaviour
    {
        [Header("Settings")]
        [SerializeField] private int m_MaxBones = 128;
        [SerializeField] private bool m_AutoCapture = true;

        [Header("Debug")]
        [SerializeField] private bool m_ShowHierarchy = true;
        [SerializeField] private bool m_ShowBoneNames = false;

        // Bones
        private GaussianSplatBone[] m_Bones;
        private Dictionary<GaussianSplatBone, int> m_BoneToIndex;
        
        // GPU data
        private GraphicsBuffer m_BoneMatricesBuffer;
        private Matrix4x4[] m_BoneMatrices;

        public int boneCount => m_Bones != null ? m_Bones.Length : 0;
        public GaussianSplatBone[] bones => m_Bones;
        public GraphicsBuffer boneMatricesBuffer => m_BoneMatricesBuffer;

        private void OnEnable()
        {
            // Mixamo clips often contain a -90 degree root-orientation track.
            // The generated splat root already carries the FBX coordinate-system
            // correction, so applying root motion rotates it a second time.
            Animator animator = GetComponent<Animator>();
            if (animator == null && Application.isPlaying)
            {
                Animator parentAnimator = transform.parent != null
                    ? transform.parent.GetComponentInParent<Animator>()
                    : null;

                // Older converted characters placed Animator on the outer splat
                // root. Humanoid evaluation can then rewrite that root rotation.
                // Run the same controller directly on the normalized rig instead.
                if (parentAnimator != null)
                {
                    animator = gameObject.AddComponent<Animator>();
                    animator.avatar = parentAnimator.avatar;
                    animator.runtimeAnimatorController = parentAnimator.runtimeAnimatorController;
                    animator.updateMode = parentAnimator.updateMode;
                    animator.speed = parentAnimator.speed;
                    parentAnimator.enabled = false;
                }
            }
            else if (animator == null)
            {
                animator = GetComponentInParent<Animator>();
            }

            if (animator != null)
            {
                animator.applyRootMotion = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
            }

            RebuildRig();
        }

        private void OnDisable()
        {
            ReleaseGPU();
        }

        private void OnValidate()
        {
            // Full Mixamo hierarchies commonly exceed 64 transforms.
            m_MaxBones = Mathf.Clamp(m_MaxBones, 128, 256);
        }

        private void LateUpdate()
        {
            // Skinning does not run in edit mode, so continuously uploading bone
            // matrices there only forces unnecessary editor/player-loop updates.
            if (!Application.isPlaying)
                return;

            UpdateBoneMatrices();
        }

        public void RebuildRig(bool captureBindPoses = true)
        {
            m_MaxBones = Mathf.Clamp(m_MaxBones, 128, 256);
            var boneList = new List<GaussianSplatBone>();
            GetComponentsInChildren(true, boneList);

            if (boneList.Count > m_MaxBones)
            {
                Debug.LogWarning(
                    $"[GaussianSplatRig] Found {boneList.Count} bones but only {m_MaxBones} are supported. " +
                    "Increase Max Bones to avoid partial animation.",
                    this);
                boneList.RemoveRange(m_MaxBones, boneList.Count - m_MaxBones);
            }

            m_Bones = boneList.ToArray();
            m_BoneToIndex = new Dictionary<GaussianSplatBone, int>();
            for (int i = 0; i < m_Bones.Length; i++)
                m_BoneToIndex[m_Bones[i]] = i;

            if (m_AutoCapture && captureBindPoses)
                CaptureMissingBindPoses();

            AllocateGPU();
        }

    public void CaptureBindPoses()
    {
        if (m_Bones == null) return;
        foreach (var bone in m_Bones)
            bone?.CaptureBindPose();
    }

    private void CaptureMissingBindPoses()
    {
        if (m_Bones == null) return;
        foreach (var bone in m_Bones)
        {
            // With Enter Play Mode scene/domain reload disabled, these runtime
            // values survive. Recapturing here can use the final animated frame as
            // a new rest pose and corrupt otherwise correct transferred weights.
            if (bone != null && !bone.hasBindPose)
                bone.CaptureBindPose();
        }
    }
    
    /// <summary>
    /// Reset all bones to their bind pose
    /// </summary>
    public void ResetToBindPose()
    {
        if (m_Bones == null) return;
        foreach (var bone in m_Bones)
        {
            if (bone != null && bone.hasBindPose)
            {
                bone.transform.position = bone.bindPose.GetColumn(3);
                bone.transform.rotation = bone.bindPose.rotation;
            }
        }
    }
    
    /// <summary>
    /// Call this after duplicating a rigged character to rebuild bone references
    /// </summary>
    [ContextMenu("Rebuild Rig After Duplication")]
    public void RebuildRigAfterDuplication()
    {
        RebuildRig();
        Debug.Log($"[GaussianSplatRig] Rig rebuilt with {boneCount} bones from new hierarchy");
    }

        public int GetBoneIndex(GaussianSplatBone bone)
        {
            return m_BoneToIndex != null && bone != null && m_BoneToIndex.TryGetValue(bone, out int idx) ? idx : -1;
        }

        /// <summary>
        /// Removes FBX import scale from the rig root while preserving the complete
        /// bone hierarchy in world space.
        /// </summary>
        [ContextMenu("Normalize Rig Scale")]
        public void NormalizeScale()
        {
            if (transform.localScale == Vector3.one)
                return;

            var directChildren = new List<Transform>(transform.childCount);
            for (int i = 0; i < transform.childCount; i++)
                directChildren.Add(transform.GetChild(i));

            // Detaching only root children preserves all descendant local bone
            // relationships while SetParent keeps their current world transforms.
            foreach (Transform child in directChildren)
                child.SetParent(null, true);

            transform.localScale = Vector3.one;

            foreach (Transform child in directChildren)
                child.SetParent(transform, true);
        }

        private void UpdateBoneMatrices()
        {
            if (m_Bones == null || m_Bones.Length == 0) return;
            if (m_BoneMatrices == null || m_BoneMatrices.Length != m_Bones.Length)
                m_BoneMatrices = new Matrix4x4[m_Bones.Length];

            for (int i = 0; i < m_Bones.Length; i++)
            {
                if (m_Bones[i] != null)
                    m_BoneMatrices[i] = m_Bones[i].GetSkinMatrix();
                else
                    m_BoneMatrices[i] = Matrix4x4.identity;
            }

            if (m_BoneMatricesBuffer != null && m_BoneMatricesBuffer.IsValid())
                m_BoneMatricesBuffer.SetData(m_BoneMatrices);
        }

        private void AllocateGPU()
        {
            ReleaseGPU();
            if (m_Bones == null || m_Bones.Length == 0) return;

            m_BoneMatrices = new Matrix4x4[m_Bones.Length];
            m_BoneMatricesBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_Bones.Length, sizeof(float) * 16);
        }

        private void ReleaseGPU()
        {
            m_BoneMatricesBuffer?.Release();
            m_BoneMatricesBuffer = null;
        }

        private void OnDrawGizmos()
        {
            if (!m_ShowHierarchy || m_Bones == null) return;

            // Simple: just draw skeleton lines
            Gizmos.color = Color.yellow;
            foreach (var bone in m_Bones)
            {
                if (bone == null || bone.transform.parent == null) continue;
                var parentBone = bone.transform.parent.GetComponentInParent<GaussianSplatBone>();
                if (parentBone != null && System.Array.IndexOf(m_Bones, parentBone) >= 0)
                {
                    Gizmos.DrawLine(bone.transform.position, parentBone.transform.position);
                }
            }
            
            // Larger sphere at root bone
            if (m_Bones.Length > 0 && m_Bones[0] != null)
            {
                Gizmos.color = Color.green;
                Gizmos.DrawSphere(m_Bones[0].transform.position, 0.08f);
            }
        }
        
        private void OnDrawGizmosSelected()
        {
            if (m_Bones == null) return;
            
            // When rig selected, show bone names if enabled
            #if UNITY_EDITOR
            if (m_ShowBoneNames)
            {
                UnityEditor.Handles.color = Color.white;
                foreach (var bone in m_Bones)
                {
                    if (bone != null)
                    {
                        UnityEditor.Handles.Label(bone.transform.position, bone.name);
                    }
                }
            }
            #endif
        }
    }
}
