// SPDX-License-Identifier: MIT

using UnityEngine;
using System.Collections.Generic;
using System.Reflection;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Directly injects Mixamo bone weights into GaussianSplatSkin, bypassing all timing and serialization issues.
    /// This component immediately overwrites any calculated weights with the original Mixamo weights.
    /// </summary>
    [DefaultExecutionOrder(-5)]
    public class MixamoWeightInjector : MonoBehaviour
    {
        [System.Serializable]
        public struct MixamoWeight
        {
            public int splatIndex;
            public Vector4 boneIndices;
            public Vector4 boneWeights;
        }
        
        [SerializeField] private GaussianSplatSkin m_TargetSkin;
        [SerializeField] private MixamoWeight[] m_MixamoWeights;
        [SerializeField] private Matrix4x4 m_RigBindTransform;
        [SerializeField] private Matrix4x4 m_RigInvBindTransform;
        [SerializeField] private int m_TotalSplatCount;
        [SerializeField] private bool m_UseTransferredWeights = true;
        [SerializeField] private MixamoWeightData m_WeightData;
        
        private bool m_WeightsInjected = false;

        public bool hasEmbeddedWeights =>
            m_MixamoWeights != null && m_MixamoWeights.Length > 0;
        public MixamoWeightData weightData => m_WeightData;
        
        public void SetMixamoWeights(GaussianSplatSkin targetSkin, Dictionary<int, Vector4> boneIndices, Dictionary<int, Vector4> boneWeights, Matrix4x4 rigBindTransform, Matrix4x4 rigInvBindTransform, int totalSplatCount)
        {
            m_TargetSkin = targetSkin;
            m_RigBindTransform = rigBindTransform;
            m_RigInvBindTransform = rigInvBindTransform;
            m_TotalSplatCount = totalSplatCount;
            
            // Convert dictionaries to serializable array
            var weightList = new List<MixamoWeight>();
            foreach (var kvp in boneIndices)
            {
                int splatIndex = kvp.Key;
                if (boneWeights.ContainsKey(splatIndex))
                {
                    weightList.Add(new MixamoWeight
                    {
                        splatIndex = splatIndex,
                        boneIndices = kvp.Value,
                        boneWeights = boneWeights[splatIndex]
                    });
                }
            }
            
            m_MixamoWeights = weightList.ToArray();
        }

        public void MoveEmbeddedWeightsTo(MixamoWeightData data)
        {
            if (data == null || !hasEmbeddedWeights)
                return;

            data.SetWeights(m_MixamoWeights);
            m_WeightData = data;
            m_MixamoWeights = null;
        }

        private MixamoWeight[] GetWeights()
        {
            if (m_WeightData != null && m_WeightData.count > 0)
                return m_WeightData.weights;
            return m_MixamoWeights;
        }
        
        private void Start()
        {
            MixamoWeight[] weights = GetWeights();
            if (m_UseTransferredWeights &&
                m_TargetSkin != null && weights != null && weights.Length > 0)
            {
                // Force injection immediately
                InjectMixamoWeights();
            }
        }
        
        private void LateUpdate()
        {
            // Continuously inject weights to override any recalculation
            MixamoWeight[] weights = GetWeights();
            if (m_UseTransferredWeights && !m_WeightsInjected &&
                m_TargetSkin != null && weights != null && weights.Length > 0)
            {
                InjectMixamoWeights();
            }
        }
        
        public void InjectMixamoWeights()
        {
            MixamoWeight[] weights = GetWeights();
            if (m_TargetSkin == null || weights == null || weights.Length == 0)
            {
                return;
            }
            
            // Create full splat skin array
            var splatSkins = new GaussianSplatSkin.SplatSkin[m_TotalSplatCount];
            
            // Initialize all splats with no weights
            for (int i = 0; i < m_TotalSplatCount; i++)
            {
                splatSkins[i].boneIndices = new Vector4(-1, -1, -1, -1);
                splatSkins[i].boneWeights = new Vector4(0, 0, 0, 0);
            }
            
            // Apply Mixamo weights
            foreach (var weight in weights)
            {
                if (weight.splatIndex >= 0 && weight.splatIndex < m_TotalSplatCount)
                {
                    splatSkins[weight.splatIndex].boneIndices = weight.boneIndices;
                    splatSkins[weight.splatIndex].boneWeights = weight.boneWeights;
                }
            }
            
            // Use reflection to directly set all fields
            var skinType = typeof(GaussianSplatSkin);
            
            // Set the splat skins array
            var splatSkinsField = skinType.GetField("m_SplatSkins", BindingFlags.NonPublic | BindingFlags.Instance);
            if (splatSkinsField != null)
            {
                splatSkinsField.SetValue(m_TargetSkin, splatSkins);
            }
            
            // Set weights as calculated
            var weightsCalculatedField = skinType.GetField("m_WeightsCalculated", BindingFlags.NonPublic | BindingFlags.Instance);
            if (weightsCalculatedField != null)
            {
                weightsCalculatedField.SetValue(m_TargetSkin, true);
            }
            
            // Set cached splat count
            var cachedSplatCountField = skinType.GetField("m_CachedSplatCount", BindingFlags.NonPublic | BindingFlags.Instance);
            if (cachedSplatCountField != null)
            {
                cachedSplatCountField.SetValue(m_TargetSkin, m_TotalSplatCount);
            }
            
            // Initialize all rig and renderer bind-space matrices. Older versions
            // only replaced two runtime fields, leaving renderer matrices at zero
            // until RecalculateWeights happened to initialize them.
            m_TargetSkin.CaptureBindTransforms();
            
            // Force upload to GPU
            var uploadMethod = skinType.GetMethod("UploadWeightsToGPU", BindingFlags.NonPublic | BindingFlags.Instance);
            if (uploadMethod != null)
            {
                uploadMethod.Invoke(m_TargetSkin, null);
            }
            
            m_WeightsInjected = true;
        }
        
        [ContextMenu("Force Inject Mixamo Weights")]
        public void ForceInject()
        {
            m_UseTransferredWeights = true;
            m_WeightsInjected = false;
            InjectMixamoWeights();
#if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
#endif
        }

        public void DisableTransferredWeights()
        {
            m_UseTransferredWeights = false;
            m_WeightsInjected = false;
        }
        
        [ContextMenu("Debug Bone Transforms")]
        public void DebugBoneTransforms()
        {
            if (m_TargetSkin == null || m_TargetSkin.rig == null)
            {
                return;
            }
        }
        
        [ContextMenu("Fix Transform Mismatch")]
        public void FixTransformMismatch()
        {
            if (m_TargetSkin == null || m_TargetSkin.rig == null)
            {
                return;
            }
            
            // CRITICAL FIX: Align rig transform to match renderer transform
            var renderer = m_TargetSkin.GetComponent<GaussianSplatRenderer>();
            if (renderer != null)
            {
                // Copy renderer transform to rig
                m_TargetSkin.rig.transform.position = renderer.transform.position;
                m_TargetSkin.rig.transform.rotation = renderer.transform.rotation;
                m_TargetSkin.rig.transform.localScale = renderer.transform.localScale;
            }
            else
            {
                return;
            }
            
            // Re-inject weights with corrected transform
            m_WeightsInjected = false;
            InjectMixamoWeights();
        }
        
        [ContextMenu("Align Bones to Splats")]
        public void AlignBonesToSplats()
        {
            if (m_TargetSkin == null || m_TargetSkin.rig == null)
            {
                return;
            }
            
            var renderer = m_TargetSkin.GetComponent<GaussianSplatRenderer>();
            if (renderer == null)
            {
                return;
            }
            
            // Move rig to exactly match renderer position
            m_TargetSkin.rig.transform.position = renderer.transform.position;
            m_TargetSkin.rig.transform.rotation = renderer.transform.rotation;
            m_TargetSkin.rig.transform.localScale = renderer.transform.localScale;
            
            // Update bind transform to current state
            m_RigBindTransform = renderer.transform.localToWorldMatrix;
            m_RigInvBindTransform = m_RigBindTransform.inverse;
            
            // Re-inject with new alignment
            m_WeightsInjected = false;
            InjectMixamoWeights();
        }
        
        private void OnValidate()
        {
            if (Application.isPlaying && m_TargetSkin != null)
            {
                m_WeightsInjected = false; // Force re-injection on inspector changes
            }
        }
    }
}
