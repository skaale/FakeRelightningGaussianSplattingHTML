// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Bone for Gaussian splat skinning. Build bone hierarchy in scene, then skin splats to bones.
    /// Splats will bend/sway/move/scale/rotate with bones.
    /// </summary>
    public class GaussianSplatBone : MonoBehaviour
    {
        [Header("Influence")]
        [SerializeField] private float m_Radius = 1.0f;
        [SerializeField] [Range(0f, 1f)] private float m_Falloff = 0.5f;
        
        [Header("Debug")]
        [SerializeField] private bool m_ShowGizmo = true;
        [SerializeField] private bool m_ShowBoneName = false;
        [SerializeField] private float m_GizmoSize = 0.01f;
        [SerializeField] private Color m_GizmoColor = Color.cyan;

        // Bind pose (captured when skinning starts)
        private Matrix4x4 m_BindPose;
        private Matrix4x4 m_InvBindPose;
        private bool m_HasBindPose;

        public float radius
        {
            get => m_Radius;
            set => m_Radius = Mathf.Max(0.01f, value);
        }

        public float falloff
        {
            get => m_Falloff;
            set => m_Falloff = Mathf.Clamp01(value);
        }

        public Matrix4x4 bindPose => m_BindPose;
        public Matrix4x4 invBindPose => m_InvBindPose;
        public bool hasBindPose => m_HasBindPose;

        public void CaptureBindPose()
        {
            m_BindPose = transform.localToWorldMatrix;
            m_InvBindPose = m_BindPose.inverse;
            m_HasBindPose = true;
        }

        /// <summary>
        /// Gets bone matrix: current transform relative to bind pose
        /// </summary>
        public Matrix4x4 GetSkinMatrix()
        {
            if (!m_HasBindPose) return Matrix4x4.identity;
            return transform.localToWorldMatrix * m_InvBindPose;
        }

        /// <summary>
        /// Calculates bone weight for splat at position (in world space)
        /// </summary>
        public float CalculateWeight(Vector3 splatWorldPos)
        {
            // Use bind pose position for weight calculation
            Vector3 bonePos = m_HasBindPose ? m_BindPose.GetColumn(3) : transform.position;
            float dist = Vector3.Distance(splatWorldPos, bonePos);
            
            if (dist > m_Radius) return 0f;
            
            // Smooth falloff
            float falloffDist = m_Radius * m_Falloff;
            if (dist <= falloffDist) return 1f;
            
            float t = (dist - falloffDist) / (m_Radius - falloffDist);
            return 1f - (t * t * (3f - 2f * t)); // Smoothstep
        }

        private void OnDrawGizmos()
        {
            if (!m_ShowGizmo) return;

            Vector3 pos = transform.position;
            
            // Draw connection to parent bone (thicker line)
            if (transform.parent != null)
            {
                GaussianSplatBone parentBone = transform.parent.GetComponent<GaussianSplatBone>();
                if (parentBone != null)
                {
                    Gizmos.color = Color.yellow;
                    Gizmos.DrawLine(pos, parentBone.transform.position);
                }
            }
            
            // Visible sphere at bone position
            Gizmos.color = m_GizmoColor;
            Gizmos.DrawSphere(pos, m_GizmoSize);
            
            // Draw bone name if enabled
            #if UNITY_EDITOR
            if (m_ShowBoneName)
            {
              //  UnityEditor.Handles.Label(pos + Vector3.up * (m_GizmoSize + 0.05f), name);
            }
            #endif
        }
        
        private void OnDrawGizmosSelected()
        {
            // When bone is selected, show influence radius
            Vector3 pos = transform.position;
            
            // Draw larger sphere when selected
            Gizmos.color = m_GizmoColor;
            Gizmos.DrawSphere(pos, m_GizmoSize * 2f);
            
            // Draw influence radius
            Gizmos.color = new Color(0f, 1f, 1f, 0.2f);
            Gizmos.DrawWireSphere(pos, m_Radius);
            
            Gizmos.color = new Color(1f, 1f, 0f, 0.3f);
            Gizmos.DrawWireSphere(pos, m_Radius * m_Falloff);
            
            // Always show bone name when selected
            #if UNITY_EDITOR
            UnityEditor.Handles.color = Color.white;
            UnityEditor.Handles.Label(pos + Vector3.up * (m_Radius + 0.1f), name, new GUIStyle() 
            { 
                normal = new GUIStyleState() { textColor = Color.white },
                fontSize = 12,
                fontStyle = FontStyle.Bold
            });
            #endif
        }
    }
}
