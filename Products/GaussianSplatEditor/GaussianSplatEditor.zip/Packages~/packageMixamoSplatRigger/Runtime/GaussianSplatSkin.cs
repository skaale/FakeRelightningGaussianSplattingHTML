// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEngine.Rendering;

#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif
namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Applies bone-based skinning to Gaussian splats.
    /// Skinned splats bend/sway/move/scale/rotate with bones.
    /// IMPORTANT: Runs in LateUpdate with execution order 0 (before GaussianSplatPhysicsCollider)
    /// This ensures splats are transformed before collision/deletion checks
    /// </summary>
    [RequireComponent(typeof(GaussianSplatRenderer))]
    [DefaultExecutionOrder(0)] // Run before GaussianSplatPhysicsCollider (order 100)
    public class GaussianSplatSkin : MonoBehaviour
    {
        [Header("Rig")]
        [SerializeField] private GaussianSplatRig m_Rig;

        [Header("Skinning")]
        [SerializeField] [Range(1, 4)] private int m_MaxBonesPerSplat = 4;
        [SerializeField] private bool m_AutoWeightThreshold = true;
        [SerializeField] [Range(0.001f, 0.1f)] private float m_WeightThreshold = 0.01f;
        [SerializeField] private bool m_WeightsCalculated = false;

        [Header("Selection")]
        [SerializeField] private SkinMode m_SkinMode = SkinMode.AllSplats;
        [SerializeField] private Bounds m_SelectionBounds = new Bounds(Vector3.zero, Vector3.one * 100f);

        [Header("Performance")]
        [SerializeField] private bool m_EnableSkinning = false;
        [SerializeField] private bool m_UseComputeShader = true;
        [SerializeField] private ComputeShader m_SkinningComputeShader;
        [SerializeField] [Tooltip("Updates every splat each frame for coherent walk-cycle animation")]
        private bool m_SmoothAnimation = true;
        [SerializeField] [Range(1, 10)] private int m_UpdateEveryNFrames = 1;
        [SerializeField] [Tooltip("Automatically distributes rigs larger than 250k splats across multiple frames")]
        private bool m_AutoPartitionLargeRigs = true;
        [SerializeField] [Range(1, 8)] [Tooltip("Number of frame partitions used when automatic partitioning is disabled")]
        private int m_SkinningPartitions = 1;
        
        [Header("Debug")]
        [SerializeField] private bool m_TestMode = false;
        [SerializeField] private int m_TestBoneIndex = 0;

        // Components
        private GaussianSplatRenderer m_Renderer;
        
        // Rig transform at bind time (serialize as float arrays since Unity doesn't serialize Matrix4x4)
        [SerializeField] private float[] m_RigBindTransformData = new float[16];
        [SerializeField] private float[] m_RigInvBindTransformData = new float[16];
        
        // Renderer transform at bind time (serialize as float arrays since Unity doesn't serialize Matrix4x4)
        [SerializeField] private float[] m_RendererBindTransformData = new float[16];
        [SerializeField] private float[] m_RendererInvBindTransformData = new float[16];
        
        // Runtime Matrix4x4 versions (reconstructed from serialized data)
        private Matrix4x4 m_RigBindTransform;
        private Matrix4x4 m_RigInvBindTransform;
        private Matrix4x4 m_RendererBindTransform;
        private Matrix4x4 m_RendererInvBindTransform;
        
        // Skinning data (CPU) - NOT serialized to avoid editor slowdown with 2M elements
        [System.Serializable]
        public struct SplatSkin
        {
            public Vector4 boneIndices; // 4 bone indices
            public Vector4 boneWeights; // 4 bone weights
        }
        
        [System.NonSerialized] private SplatSkin[] m_SplatSkins; // NOT serialized - too large!
        
        // GPU buffers
        private GraphicsBuffer m_SkinBuffer; // SplatSkin structs
        private ComputeShader m_SkinningCS;
        private int m_KernelSkinSplats;
        
        // Bind pose buffers (original splat data)
        private GraphicsBuffer m_BindPosePosBuffer;
        private GraphicsBuffer m_BindPoseOtherBuffer;
        private bool m_BindPoseCaptured = false;

        // State
        private bool m_WeightsNeedUpdate = true;
        private int m_CachedSplatCount;

        public enum SkinMode
        {
            AllSplats,
            BoundsVolume,
            Manual
        }

        public GaussianSplatRig rig
        {
            get => m_Rig;
            set { m_Rig = value; m_WeightsNeedUpdate = true; }
        }

        public SkinMode skinMode
        {
            get => m_SkinMode;
            set { m_SkinMode = value; m_WeightsNeedUpdate = true; }
        }

        public Bounds selectionBounds
        {
            get => m_SelectionBounds;
            set { m_SelectionBounds = value; m_WeightsNeedUpdate = true; }
        }

        private void OnEnable()
        {
            m_Renderer = GetComponent<GaussianSplatRenderer>();
            if (m_Renderer == null)
            {
                enabled = false;
                return;
            }

            if (m_Rig == null)
                m_Rig = FindRig();

            // Restore matrices from serialized data
            RestoreMatricesFromSerializedData();

            LoadComputeShader();
        }
        
        private void RestoreMatricesFromSerializedData()
        {
            // Reconstruct matrices from serialized float arrays
            if (m_RigBindTransformData != null && m_RigBindTransformData.Length == 16)
            {
                m_RigBindTransform = ArrayToMatrix(m_RigBindTransformData);
            }
            if (m_RigInvBindTransformData != null && m_RigInvBindTransformData.Length == 16)
            {
                m_RigInvBindTransform = ArrayToMatrix(m_RigInvBindTransformData);
            }
            if (m_RendererBindTransformData != null && m_RendererBindTransformData.Length == 16)
            {
                m_RendererBindTransform = ArrayToMatrix(m_RendererBindTransformData);
            }
            if (m_RendererInvBindTransformData != null && m_RendererInvBindTransformData.Length == 16)
            {
                m_RendererInvBindTransform = ArrayToMatrix(m_RendererInvBindTransformData);
            }
        }
        
        private static Matrix4x4 ArrayToMatrix(float[] data)
        {
            if (data == null || data.Length != 16) return Matrix4x4.identity;
            
            Matrix4x4 m = new Matrix4x4();
            m.m00 = data[0]; m.m01 = data[1]; m.m02 = data[2]; m.m03 = data[3];
            m.m10 = data[4]; m.m11 = data[5]; m.m12 = data[6]; m.m13 = data[7];
            m.m20 = data[8]; m.m21 = data[9]; m.m22 = data[10]; m.m23 = data[11];
            m.m30 = data[12]; m.m31 = data[13]; m.m32 = data[14]; m.m33 = data[15];
            return m;
        }
        
        private static float[] MatrixToArray(Matrix4x4 m)
        {
            return new float[]
            {
                m.m00, m.m01, m.m02, m.m03,
                m.m10, m.m11, m.m12, m.m13,
                m.m20, m.m21, m.m22, m.m23,
                m.m30, m.m31, m.m32, m.m33
            };
        }
        
        private void Start()
        {
            // Only run if skinning is enabled
            if (!m_EnableSkinning) return;
            
            // Validate rig
            if (m_Rig != null && m_Rig.boneCount == 0)
            {
                m_Rig.RebuildRig();
            }
            
            // CRITICAL FIX: In play mode, always recapture bind transforms to ensure they match current state
            // This fixes the issue where bind transforms captured in editor mode don't match play mode transforms
            if (Application.isPlaying)
            {
                RestoreMatricesFromSerializedData();
                
                // Check if bind transforms are valid (not zero/identity)
                bool hasValidBindTransforms = m_RigBindTransformData != null && m_RigBindTransformData.Length == 16 &&
                                             (m_RigBindTransformData[0] != 0 || m_RigBindTransformData[5] != 0 || m_RigBindTransformData[10] != 0);
                
                if (!hasValidBindTransforms)
                {
                    Debug.LogWarning("[GaussianSplatSkin] Bind transforms are invalid! Recapturing in play mode.");
                    // Invalidate bind pose buffers so they get recaptured
                    m_BindPoseCaptured = false;
                    // Force recalculation which will recapture bind transforms
                    m_WeightsCalculated = false;
                }
                else
                {
                    // Check if current transforms differ significantly from bind transforms
                    // Extract scale separately to detect scale changes
                    Vector3 rigBindScale = ExtractScale(m_RigBindTransform);
                    Vector3 rendererBindScale = ExtractScale(m_RendererBindTransform);
                    
                    Matrix4x4 currentRigTransform = m_Rig.transform.localToWorldMatrix;
                    Matrix4x4 currentRendererTransform = m_Renderer.transform.localToWorldMatrix;
                    
                    Vector3 rigCurrentScale = ExtractScale(currentRigTransform);
                    Vector3 rendererCurrentScale = ExtractScale(currentRendererTransform);
                    
                    // Check scale changes (more sensitive detection)
                    bool rigScaleChanged = !Vector3ApproximatelyEqual(rigCurrentScale, rigBindScale, 0.01f);
                    bool rendererScaleChanged = !Vector3ApproximatelyEqual(rendererCurrentScale, rendererBindScale, 0.01f);
                    
                    // Check position/rotation changes (ignore scale for this comparison)
                    bool rigTransformChanged = !MatricesApproximatelyEqualIgnoreScale(currentRigTransform, m_RigBindTransform);
                    bool rendererTransformChanged = !MatricesApproximatelyEqualIgnoreScale(currentRendererTransform, m_RendererBindTransform);
                    
                    // CRITICAL: Only recapture bind transforms if position/rotation changed
                    // DO NOT recapture if ONLY scale changed - this prevents scale from being applied incorrectly
                    // Scale changes should be handled separately and don't require bind transform recalculation
                    if (rigScaleChanged || rendererScaleChanged)
                    {
                        Debug.LogWarning($"[GaussianSplatSkin] SCALE CHANGE DETECTED in play mode!\n" +
                                       $"Rig scale: Bind={rigBindScale}, Current={rigCurrentScale}\n" +
                                       $"Renderer scale: Bind={rendererBindScale}, Current={rendererCurrentScale}\n" +
                                       $"WARNING: Scale changes can cause incorrect skinning!\n" +
                                       $"Ensure rig/renderer scale is (1,1,1) or consistent between editor and play mode.\n" +
                                       $"Bind transforms will NOT be recaptured for scale-only changes to preserve original scale.");
                    }
                    
                    // Only recapture if position/rotation changed (not just scale)
                    if (rigTransformChanged || rendererTransformChanged)
                    {
                        Debug.LogWarning($"[GaussianSplatSkin] Rig/Renderer position/rotation changed in play mode! " +
                                       $"Recapturing bind transforms and recalculating weights.\n" +
                                       $"Rig changed: {rigTransformChanged}, Renderer changed: {rendererTransformChanged}");
                        
                        // Recapture bind transforms (preserving original scale by using normalized matrices)
                        // Extract position and rotation, but keep original scale
                        Vector3 rigPos = currentRigTransform.GetColumn(3);
                        Quaternion rigRot = ExtractRotation(currentRigTransform);
                        Vector3 rigScale = rigBindScale; // Use original bind scale, not current scale
                        
                        Vector3 rendererPos = currentRendererTransform.GetColumn(3);
                        Quaternion rendererRot = ExtractRotation(currentRendererTransform);
                        Vector3 rendererScale = rendererBindScale; // Use original bind scale, not current scale
                        
                        // Reconstruct matrices with original scale
                        m_RigBindTransform = Matrix4x4.TRS(rigPos, rigRot, rigScale);
                        m_RigInvBindTransform = m_RigBindTransform.inverse;
                        m_RendererBindTransform = Matrix4x4.TRS(rendererPos, rendererRot, rendererScale);
                        m_RendererInvBindTransform = m_RendererBindTransform.inverse;
                        
                        // Save to serialized arrays
                        m_RigBindTransformData = MatrixToArray(m_RigBindTransform);
                        m_RigInvBindTransformData = MatrixToArray(m_RigInvBindTransform);
                        m_RendererBindTransformData = MatrixToArray(m_RendererBindTransform);
                        m_RendererInvBindTransformData = MatrixToArray(m_RendererInvBindTransform);
                        
                        // Invalidate bind pose buffers so they get recaptured with new transforms
                        m_BindPoseCaptured = false;
                        
                        // Force recalculation of weights with new bind transforms
                        m_WeightsCalculated = false;
                    }
                }
            }
            
            // Weights are NOT serialized, must recalculate on play
            if (!m_WeightsCalculated || (m_SplatSkins == null || m_SplatSkins.Length == 0))
            {
                RecalculateWeights();
            }
            else if (m_WeightsCalculated && m_SplatSkins != null && m_SplatSkins.Length > 0)
            {
                UploadWeightsToGPU();
            }
        }
        
        /// <summary>
        /// Check if two matrices are approximately equal (within tolerance)
        /// </summary>
        private static bool MatricesApproximatelyEqual(Matrix4x4 a, Matrix4x4 b, float tolerance = 0.001f)
        {
            for (int i = 0; i < 16; i++)
            {
                if (Mathf.Abs(a[i] - b[i]) > tolerance)
                    return false;
            }
            return true;
        }
        
        /// <summary>
        /// Check if two matrices are approximately equal ignoring scale
        /// </summary>
        private static bool MatricesApproximatelyEqualIgnoreScale(Matrix4x4 a, Matrix4x4 b, float tolerance = 0.001f)
        {
            // Compare position (translation)
            Vector3 posA = a.GetColumn(3);
            Vector3 posB = b.GetColumn(3);
            if (!Vector3ApproximatelyEqual(posA, posB, tolerance))
                return false;
            
            // Compare rotation (normalize scale out)
            Matrix4x4 aNoScale = Matrix4x4.TRS(posA, ExtractRotation(a), Vector3.one);
            Matrix4x4 bNoScale = Matrix4x4.TRS(posB, ExtractRotation(b), Vector3.one);
            
            // Compare rotation matrices (3x3 upper left)
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (Mathf.Abs(aNoScale[row, col] - bNoScale[row, col]) > tolerance)
                        return false;
                }
            }
            
            return true;
        }
        
        /// <summary>
        /// Extract scale from a matrix
        /// </summary>
        private static Vector3 ExtractScale(Matrix4x4 m)
        {
            Vector3 scale;
            scale.x = new Vector4(m.m00, m.m10, m.m20, m.m30).magnitude;
            scale.y = new Vector4(m.m01, m.m11, m.m21, m.m31).magnitude;
            scale.z = new Vector4(m.m02, m.m12, m.m22, m.m32).magnitude;
            
            // Handle negative scale
            if (Vector3.Dot(Vector3.Cross(m.GetColumn(0), m.GetColumn(1)), m.GetColumn(2)) < 0)
                scale.x = -scale.x;
            
            return scale;
        }
        
        /// <summary>
        /// Extract rotation from a matrix
        /// </summary>
        private static Quaternion ExtractRotation(Matrix4x4 m)
        {
            Vector3 scale = ExtractScale(m);
            if (scale.x == 0 || scale.y == 0 || scale.z == 0)
                return Quaternion.identity;
            
            // Normalize columns to remove scale
            Matrix4x4 normalized = m;
            normalized.m00 /= scale.x; normalized.m10 /= scale.x; normalized.m20 /= scale.x;
            normalized.m01 /= scale.y; normalized.m11 /= scale.y; normalized.m21 /= scale.y;
            normalized.m02 /= scale.z; normalized.m12 /= scale.z; normalized.m22 /= scale.z;
            
            return normalized.rotation;
        }
        
        /// <summary>
        /// Check if two vectors are approximately equal
        /// </summary>
        private static bool Vector3ApproximatelyEqual(Vector3 a, Vector3 b, float tolerance = 0.001f)
        {
            return Mathf.Abs(a.x - b.x) <= tolerance &&
                   Mathf.Abs(a.y - b.y) <= tolerance &&
                   Mathf.Abs(a.z - b.z) <= tolerance;
        }

        private void OnDisable()
        {
            ReleaseGPU();
        }

        private void OnValidate()
        {
            m_MaxBonesPerSplat = Mathf.Clamp(m_MaxBonesPerSplat, 1, 4);
            m_WeightThreshold = Mathf.Clamp01(m_WeightThreshold);
            m_SkinningPartitions = Mathf.Clamp(m_SkinningPartitions, 1, 8);
            m_WeightsNeedUpdate = true;
        }

        // No Update needed - weight calculation happens via editor button only

        private void LateUpdate()
        {
            if (!m_EnableSkinning) return; // Master enable/disable

            // Start() does not run again when skinning is enabled during play.
            // Initialize lazily so the Inspector toggle works at runtime too.
            if (Application.isPlaying && m_SkinBuffer == null)
            {
                if (m_SplatSkins == null || m_SplatSkins.Length == 0)
                    RecalculateWeights();
                else
                    UploadWeightsToGPU();
            }

            if (!IsValid() || !m_WeightsCalculated) return;
            
            // Check if bind transforms are valid (warn on first frame only)
            if (Time.frameCount == 1)
            {
                bool rigBindZero = m_RigBindTransformData == null || (m_RigBindTransformData[0] == 0 && m_RigBindTransformData[5] == 0 && m_RigBindTransformData[10] == 0);
                bool rendererBindZero = m_RendererBindTransformData == null || (m_RendererBindTransformData[0] == 0 && m_RendererBindTransformData[5] == 0 && m_RendererBindTransformData[10] == 0);
                
                if (rigBindZero || rendererBindZero)
                {
                    Debug.LogError($"[GaussianSplatSkin] ERROR: Bind transform data is ZERO! Skinning will NOT work correctly!\n" +
                                   $"FIX: In Editor mode, right-click this component and select 'Recalculate Weights' to capture bind transforms.", this);
                }
            }
            
            // Capture bind pose if not done yet
            if (!m_BindPoseCaptured && m_UseComputeShader && m_SkinningCS != null)
            {
                CaptureBindPose();
            }
            
            // Apply GPU skinning if everything is ready
            if (m_UseComputeShader && m_BindPoseCaptured && m_SkinningCS != null && m_SkinBuffer != null)
            {
                // The former physics-collider integration referenced a type that is
                // not part of SplatBox. Keep the configured skinning update cadence.
                int updateInterval = m_SmoothAnimation ? 1 : Mathf.Max(1, m_UpdateEveryNFrames);
                if (Time.frameCount % updateInterval == 0)
                    ApplyGPUSkinning();
            }
        }

        private bool IsValid()
        {
            return m_Renderer != null && m_Renderer.HasValidAsset && 
                   m_Rig != null && m_Rig.boneCount > 0;
        }

        private void LoadComputeShader()
        {
            // First try to use manually assigned shader
            if (m_SkinningComputeShader != null)
            {
                m_SkinningCS = m_SkinningComputeShader;
            }
            else
            {
                // Try to find the compute shader in the package
                #if UNITY_EDITOR
                string[] guids = UnityEditor.AssetDatabase.FindAssets("GaussianSplatSkinning t:ComputeShader");
                if (guids.Length > 0)
                {
                    string path = UnityEditor.AssetDatabase.GUIDToAssetPath(guids[0]);
                    m_SkinningCS = UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                    m_SkinningComputeShader = m_SkinningCS; // Cache it
                    
                    UnityEditor.EditorUtility.SetDirty(this);
                }
                #endif
            }
            
            if (m_SkinningCS == null)
            {
                m_KernelSkinSplats = -1;
                return;
            }
            
            try
            {
                m_KernelSkinSplats = m_SkinningCS.FindKernel("SkinSplats");
            }
            catch (System.Exception)
            {
                m_KernelSkinSplats = -1;
            }
        }

        /// <summary>
        /// Calculate bone weights for all splats
        /// </summary>
        public void CalculateWeights()
        {
            if (!IsValid()) return;

            // Auto-adjust weight threshold if enabled
            if (m_AutoWeightThreshold)
            {
                m_WeightThreshold = 0.01f; // Standard threshold for most cases
            }

            // CRITICAL FIX: Always recapture bind transforms when recalculating weights
            // This ensures bind transforms match the current rig/renderer state, especially important
            // when entering play mode where transforms might differ from editor mode
            
            // Check scale - warn if not (1,1,1) as this can cause issues
            Vector3 rigScale = m_Rig.transform.lossyScale;
            Vector3 rendererScale = m_Renderer.transform.lossyScale;
            
            if (!Vector3ApproximatelyEqual(rigScale, Vector3.one, 0.01f))
            {
                Debug.LogWarning($"[GaussianSplatSkin] Rig scale is not (1,1,1): {rigScale}. " +
                               $"Non-uniform scale can cause incorrect skinning. Consider normalizing scale.");
            }
            
            if (!Vector3ApproximatelyEqual(rendererScale, Vector3.one, 0.01f))
            {
                Debug.LogWarning($"[GaussianSplatSkin] Renderer scale is not (1,1,1): {rendererScale}. " +
                               $"Non-uniform scale can cause incorrect skinning. Consider normalizing scale.");
            }
            
            CaptureBindTransforms();

            int splatCount = m_Renderer.splatCount;
            if (m_SplatSkins == null || m_SplatSkins.Length != splatCount)
                m_SplatSkins = new SplatSkin[splatCount];

            // Get splat positions from renderer (need to read from GPU)
            Vector3[] splatPositions = GetSplatPositions();
            if (splatPositions == null) return;

            var bones = m_Rig.bones;
            
            // Debug: Show bone info (minimal)
            for (int b = 0; b < bones.Length && b < 1; b++) // Only first bone
            {
                if (bones[b] != null)
                {
                    Vector3 boneWorldPos = bones[b].hasBindPose ? 
                        bones[b].bindPose.GetColumn(3) : bones[b].transform.position;
                    Debug.Log($"Bone {b}: Radius={bones[b].radius}");
                }
            }
            
            // Calculate weights for each splat
            Vector3[] boneStarts = new Vector3[bones.Length];
            Vector3[] boneEnds = new Vector3[bones.Length];
            float[] boneRadii = new float[bones.Length];
            for (int b = 0; b < bones.Length; b++)
            {
                if (bones[b] == null)
                    continue;

                boneStarts[b] = bones[b].hasBindPose
                    ? bones[b].bindPose.GetColumn(3)
                    : bones[b].transform.position;
                boneEnds[b] = boneStarts[b];

                // A bone influences the body volume along its length, not only a
                // sphere around its pivot. Use a capsule for single-child chains.
                int childCount = 0;
                Vector3 childPosition = boneStarts[b];
                for (int c = 0; c < bones.Length; c++)
                {
                    if (bones[c] == null || bones[c].transform.parent != bones[b].transform)
                        continue;

                    childPosition = bones[c].hasBindPose
                        ? bones[c].bindPose.GetColumn(3)
                        : bones[c].transform.position;
                    childCount++;
                }

                if (childCount == 1)
                    boneEnds[b] = childPosition;

                float segmentLength = Vector3.Distance(boneStarts[b], boneEnds[b]);
                boneRadii[b] = Mathf.Max(bones[b].radius, segmentLength * 0.35f);
            }

            for (int i = 0; i < splatCount; i++)
            {
                Vector3 splatWorldPos = m_Renderer.transform.TransformPoint(splatPositions[i]);
                
                if (!IsSplatSelected(i, splatWorldPos))
                {
                    // No skinning
                    m_SplatSkins[i].boneIndices = new Vector4(-1, -1, -1, -1);
                    m_SplatSkins[i].boneWeights = new Vector4(0, 0, 0, 0);
                    continue;
                }

                // Keep only the four strongest influences while scanning bones.
                // The old List + Sort path allocated one managed object per splat,
                // causing multi-gigabyte GC pressure on large rigs.
                Vector4 topIndices = new Vector4(-1, -1, -1, -1);
                Vector4 topWeights = Vector4.zero;
                for (int b = 0; b < bones.Length; b++)
                {
                    if (bones[b] == null) continue;
                    
                    float w = CalculateBoneWeight(
                        bones[b],
                        splatWorldPos,
                        boneStarts[b],
                        boneEnds[b],
                        boneRadii[b]);
                    if (w <= m_WeightThreshold)
                        continue;

                    if (w > topWeights.x)
                    {
                        topWeights.w = topWeights.z; topIndices.w = topIndices.z;
                        topWeights.z = topWeights.y; topIndices.z = topIndices.y;
                        topWeights.y = topWeights.x; topIndices.y = topIndices.x;
                        topWeights.x = w; topIndices.x = b;
                    }
                    else if (w > topWeights.y)
                    {
                        topWeights.w = topWeights.z; topIndices.w = topIndices.z;
                        topWeights.z = topWeights.y; topIndices.z = topIndices.y;
                        topWeights.y = w; topIndices.y = b;
                    }
                    else if (w > topWeights.z)
                    {
                        topWeights.w = topWeights.z; topIndices.w = topIndices.z;
                        topWeights.z = w; topIndices.z = b;
                    }
                    else if (w > topWeights.w)
                    {
                        topWeights.w = w; topIndices.w = b;
                    }
                }
                
                // If no weights, skip this splat
                if (topWeights.x <= 0f)
                {
                    m_SplatSkins[i].boneIndices = new Vector4(-1, -1, -1, -1);
                    m_SplatSkins[i].boneWeights = new Vector4(0, 0, 0, 0);
                    continue;
                }
                
                int boneCount = m_MaxBonesPerSplat;
                float totalWeight = 0f;
                if (boneCount >= 1) totalWeight += topWeights.x;
                if (boneCount >= 2) totalWeight += topWeights.y;
                if (boneCount >= 3) totalWeight += topWeights.z;
                if (boneCount >= 4) totalWeight += topWeights.w;

                // Normalize and store
                var skin = new SplatSkin
                {
                    boneIndices = topIndices,
                    boneWeights = totalWeight > 0f ? topWeights / totalWeight : Vector4.zero
                };
                if (boneCount < 4) { skin.boneIndices.w = -1; skin.boneWeights.w = 0; }
                if (boneCount < 3) { skin.boneIndices.z = -1; skin.boneWeights.z = 0; }
                if (boneCount < 2) { skin.boneIndices.y = -1; skin.boneWeights.y = 0; }

                m_SplatSkins[i] = skin;
            }
            
            UploadWeightsToGPU();
        }

        /// <summary>
        /// Captures the coordinate-space transforms required by GPU skinning
        /// without replacing transferred bone weights.
        /// </summary>
        public void CaptureBindTransforms()
        {
            if (m_Renderer == null)
                m_Renderer = GetComponent<GaussianSplatRenderer>();
            if (m_Rig == null)
                m_Rig = FindRig();
            if (m_Renderer == null || m_Rig == null)
                return;

            m_RigBindTransform = m_Rig.transform.localToWorldMatrix;
            m_RigInvBindTransform = m_RigBindTransform.inverse;
            m_RendererBindTransform = m_Renderer.transform.localToWorldMatrix;
            m_RendererInvBindTransform = m_RendererBindTransform.inverse;

            m_RigBindTransformData = MatrixToArray(m_RigBindTransform);
            m_RigInvBindTransformData = MatrixToArray(m_RigInvBindTransform);
            m_RendererBindTransformData = MatrixToArray(m_RendererBindTransform);
            m_RendererInvBindTransformData = MatrixToArray(m_RendererInvBindTransform);

#if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
#endif
        }

        /// <summary>
        /// Calculate weight for a bone and splat (both in world space).
        /// GaussianSplatBone.radius is also defined in world units.
        /// </summary>
        private float CalculateBoneWeight(
            GaussianSplatBone bone,
            Vector3 splatWorldPos,
            Vector3 boneStartWorld,
            Vector3 boneEndWorld,
            float influenceRadius)
        {
            Vector3 segment = boneEndWorld - boneStartWorld;
            float segmentLengthSq = segment.sqrMagnitude;
            float t = segmentLengthSq > 0.000001f
                ? Mathf.Clamp01(Vector3.Dot(splatWorldPos - boneStartWorld, segment) / segmentLengthSq)
                : 0f;
            float dist = Vector3.Distance(splatWorldPos, boneStartWorld + segment * t);
            
            if (dist > influenceRadius) return 0f;
            
            float falloffDist = influenceRadius * bone.falloff;
            if (dist <= falloffDist) return 1f;
            
            float falloff = (dist - falloffDist) / Mathf.Max(influenceRadius - falloffDist, 0.000001f);
            return 1f - (falloff * falloff * (3f - 2f * falloff)); // Smoothstep
        }

        private bool IsSplatSelected(int index, Vector3 worldPos)
        {
            switch (m_SkinMode)
            {
                case SkinMode.AllSplats:
                    return true;

                case SkinMode.BoundsVolume:
                    // Transform to rig's local space (not renderer's local space)
                    Vector3 rigLocalPos = m_Rig.transform.InverseTransformPoint(worldPos);
                    bool inBounds = m_SelectionBounds.Contains(rigLocalPos);
                    
                    // Debug first few checks
                    if (index < 5)
                    {
                        Debug.Log($"Splat {index}: World={worldPos}, RigLocal={rigLocalPos}, InBounds={inBounds}, BoundsCenter={m_SelectionBounds.center}, BoundsSize={m_SelectionBounds.size}");
                    }
                    
                    return inBounds;
                    
                case SkinMode.Manual:
                    // Would check manual selection here
                    return false;

                default:
                    return false;
            }
        }

        /// <summary>
        /// Get REAL splat positions from renderer GPU buffer
        /// </summary>
        private Vector3[] GetSplatPositions()
        {
            var asset = m_Renderer.asset;
            if (asset == null) return null;

            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogError(
                    "[GaussianSplatSkin] Animated splats require Float32 position data. " +
                    "Compressed positions use fixed chunk bounds and cannot represent bone movement. " +
                    "Reconvert with the Very High quality preset.",
                    this);
                return null;
            }
            
            int splatCount = m_Renderer.splatCount;
            Vector3[] positions = new Vector3[splatCount];
            
            // Read position data from GPU
            var gpuPosData = m_Renderer.GpuPosData;
            if (gpuPosData == null) return null;

            // Weight calculation must use the undeformed rest positions.
            gpuPosData.SetData(asset.posData.GetData<uint>());
            
            // Calculate stride
            int posStride = (int)(asset.posData.dataSize / asset.splatCount);
            int posInts = posStride / 4; // Convert bytes to uint count
            
            // Read all position data from GPU
            uint[] posData = new uint[splatCount * posInts];
            gpuPosData.GetData(posData);
            
            // Decode positions
            for (int i = 0; i < splatCount; i++)
            {
                positions[i] = DecodeSplatPosition(posData, i, posInts, asset);
            }
            
            return positions;
        }

        /// <summary>
        /// Decode splat position from GPU data based on format
        /// </summary>
        private Vector3 DecodeSplatPosition(uint[] posData, int splatIndex, int posInts, GaussianSplatAsset asset)
        {
            int offset = splatIndex * posInts;
            
            switch (asset.posFormat)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    // 3 floats (12 bytes)
                    return new Vector3(
                        System.BitConverter.Int32BitsToSingle((int)posData[offset]),
                        System.BitConverter.Int32BitsToSingle((int)posData[offset + 1]),
                        System.BitConverter.Int32BitsToSingle((int)posData[offset + 2])
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm16:
                    // Packed 16-bit normalized values
                    ushort x = (ushort)(posData[offset] & 0xFFFF);
                    ushort y = (ushort)((posData[offset] >> 16) & 0xFFFF);
                    ushort z = (ushort)(posData[offset + 1] & 0xFFFF);
                    
                    Vector3 boundsMin = asset.boundsMin;
                    Vector3 boundsMax = asset.boundsMax;
                    
                    return new Vector3(
                        Mathf.Lerp(boundsMin.x, boundsMax.x, x / 65535.0f),
                        Mathf.Lerp(boundsMin.y, boundsMax.y, y / 65535.0f),
                        Mathf.Lerp(boundsMin.z, boundsMax.z, z / 65535.0f)
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm11:
                    // 11/10/11 bit packed format
                    uint packed = posData[offset];
                    float nx = (packed & 0x7FF) / 2047.0f;
                    float ny = ((packed >> 11) & 0x3FF) / 1023.0f;
                    float nz = ((packed >> 21) & 0x7FF) / 2047.0f;
                    
                    return new Vector3(
                        Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, nx),
                        Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, ny),
                        Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, nz)
                    );
                    
                default:
                    return Vector3.zero;
            }
        }

        private void UploadWeightsToGPU()
        {
            if (m_SplatSkins == null || m_SplatSkins.Length == 0) return;

            if (m_SkinBuffer == null || m_SkinBuffer.count != m_SplatSkins.Length)
            {
                m_SkinBuffer?.Release();
                m_SkinBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 
                    m_SplatSkins.Length, sizeof(float) * 8);
            }

            m_SkinBuffer.SetData(m_SplatSkins);
        }

        /// <summary>
        /// Capture bind pose (original splat data before skinning)
        /// </summary>
        private void CaptureBindPose()
        {
            var gpuPosData = m_Renderer.GpuPosData;
            var gpuOtherData = m_Renderer.GpuOtherData;
            
            if (gpuPosData == null || gpuOtherData == null)
            {
                Debug.LogWarning("Cannot capture bind pose: GPU buffers not available");
                return;
            }
            
            // CRITICAL: Raw buffers have stride=4 but actual data stride is different
            // We need to use the REAL data stride for ByteAddressBuffer access
            int realPosStride = (int)(m_Renderer.asset.posData.dataSize / m_Renderer.asset.splatCount);
            int realBufferSize = (int)(m_Renderer.asset.posData.dataSize / 4); // Size in uint (4 bytes each)
            
            // Create copies of original buffers
            m_BindPosePosBuffer?.Release();
            m_BindPoseOtherBuffer?.Release();
            
            // Create as Raw buffer to match source (ByteAddressBuffer in shader)
            m_BindPosePosBuffer = new GraphicsBuffer(
                GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopyDestination | GraphicsBuffer.Target.CopySource,
                realBufferSize,
                4 // Raw buffers always use 4-byte stride
            );
            
            m_BindPoseOtherBuffer = new GraphicsBuffer(
                gpuOtherData.target | GraphicsBuffer.Target.CopyDestination | GraphicsBuffer.Target.CopySource,
                gpuOtherData.count,
                gpuOtherData.stride
            );
            
            // Always build the bind pose from the immutable asset data. Copying the
            // renderer buffer here can capture positions already deformed by a
            // previous animation frame.
            m_BindPosePosBuffer.SetData(m_Renderer.asset.posData.GetData<uint>());
            Graphics.CopyBuffer(gpuOtherData, m_BindPoseOtherBuffer);
            
            m_BindPoseCaptured = true;
        }

        /// <summary>
        /// Apply GPU skinning to weighted splats (with proper format handling)
        /// Uses CommandBuffer for proper GPU synchronization with deletion operations
        /// </summary>
        private void ApplyGPUSkinning()
        {
            if (m_Rig == null || m_Rig.boneMatricesBuffer == null) return;
            if (m_SkinBuffer == null || !m_BindPoseCaptured) return;
            
            // Check if kernel is valid
            if (m_KernelSkinSplats < 0)
            {
                m_UseComputeShader = false;
                return;
            }
            
            var gpuPosData = m_Renderer.GpuPosData;
            if (gpuPosData == null) return;
            
            var asset = m_Renderer.asset;
            if (asset == null) return;
            
            // Use CommandBuffer to ensure proper GPU synchronization with deletion operations
            using var cmb = new UnityEngine.Rendering.CommandBuffer { name = "ApplySkinning" };
            
            // Set transforms
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RigBindTransform", m_RigBindTransform);
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RigInvBindTransform", m_RigInvBindTransform);
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RigCurrentTransform", m_Rig.transform.localToWorldMatrix);
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RendererBindTransform", m_RendererBindTransform);
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RendererInvBindTransform", m_RendererInvBindTransform);
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RendererTransform", m_Renderer.transform.localToWorldMatrix);
            cmb.SetComputeMatrixParam(m_SkinningCS, "_RendererInvTransform", m_Renderer.transform.worldToLocalMatrix);
            
            // Set bone data
            cmb.SetComputeBufferParam(m_SkinningCS, m_KernelSkinSplats, "_BoneMatrices", m_Rig.boneMatricesBuffer);
            cmb.SetComputeIntParam(m_SkinningCS, "_BoneCount", m_Rig.boneCount);
            
            // Set skin weights
            cmb.SetComputeBufferParam(m_SkinningCS, m_KernelSkinSplats, "_SplatSkins", m_SkinBuffer);
            cmb.SetComputeIntParam(m_SkinningCS, "_SplatCount", m_Renderer.splatCount);

            int partitionCount = m_SmoothAnimation
                ? 1
                : m_AutoPartitionLargeRigs
                ? Mathf.Clamp(Mathf.CeilToInt(m_Renderer.splatCount / 250000f), 1, 4)
                : Mathf.Clamp(m_SkinningPartitions, 1, 8);
            int updateInterval = m_SmoothAnimation ? 1 : Mathf.Max(1, m_UpdateEveryNFrames);
            int partitionIndex = (Time.frameCount / updateInterval) % partitionCount;
            cmb.SetComputeIntParam(m_SkinningCS, "_PartitionCount", partitionCount);
            cmb.SetComputeIntParam(m_SkinningCS, "_PartitionIndex", partitionIndex);
            
            // Set buffers
            cmb.SetComputeBufferParam(m_SkinningCS, m_KernelSkinSplats, "_SplatPosOriginal", m_BindPosePosBuffer);
            cmb.SetComputeBufferParam(m_SkinningCS, m_KernelSkinSplats, "_SplatPos", gpuPosData);
            
            // Set format
            int posStrideBytes = (int)(asset.posData.dataSize / asset.splatCount);
            cmb.SetComputeIntParam(m_SkinningCS, "_PosStride", posStrideBytes);
            cmb.SetComputeIntParam(m_SkinningCS, "_PosFormat", (int)asset.posFormat);
            cmb.SetComputeVectorParam(m_SkinningCS, "_BoundsMin", asset.boundsMin);
            cmb.SetComputeVectorParam(m_SkinningCS, "_BoundsMax", asset.boundsMax);
            
            // Debug first frame only
            if (Time.frameCount == 1)
            {
                int weightedCount = System.Linq.Enumerable.Count(m_SplatSkins, s => s.boneIndices.x >= 0);
            }
            
            // Dispatch compute shader (only transform weighted splats)
            int partitionSplatCount =
                (m_Renderer.splatCount - partitionIndex + partitionCount - 1) / partitionCount;
            int threadGroups = (partitionSplatCount + 255) / 256;
            
            try
            {
                cmb.DispatchCompute(m_SkinningCS, m_KernelSkinSplats, threadGroups, 1, 1);
                
                // Command-buffer ordering keeps skinning ahead of subsequent rendering.
                // Do not GL.Flush here: it forces a full CPU/GPU synchronization every
                // frame and is especially expensive for large rigs.
                UnityEngine.Graphics.ExecuteCommandBuffer(cmb);
            }
            catch (System.Exception)
            {
                m_UseComputeShader = false;
            }
        }

        /// <summary>
        /// Old implementation notes - kept for reference
        /// </summary>
        private void ApplyGPUSkinningOld()
        {
            /* Old planning code:
            
            // Create bind pose copy (once)
            if (m_BindPoseBuffers == null)
                CreateBindPoseBuffers();
            
            // Set up compute shader
            m_SkinningCS.SetMatrix("_RigBindTransform", m_RigBindTransform);
            m_SkinningCS.SetMatrix("_RigInvBindTransform", m_RigInvBindTransform);
            m_SkinningCS.SetMatrix("_RigCurrentTransform", m_Rig.transform.localToWorldMatrix);
            m_SkinningCS.SetBuffer(m_KernelSkinSplats, "_BoneMatrices", m_Rig.boneMatricesBuffer);
            m_SkinningCS.SetBuffer(m_KernelSkinSplats, "_SplatSkins", m_SkinBuffer);
            
            // Bind input (original) and output (modified) buffers
            m_SkinningCS.SetBuffer(m_KernelSkinSplats, "_SplatPosOriginal", m_BindPosePosBuffer);
            m_SkinningCS.SetBuffer(m_KernelSkinSplats, "_SplatPos", m_SkinnedPosBuffer);
            // ... same for rotation and scale buffers
            
            // Dispatch
            int threadGroups = (m_Renderer.splatCount + 255) / 256;
            m_SkinningCS.Dispatch(m_KernelSkinSplats, threadGroups, 1, 1);
            
            // Make renderer use skinned buffers instead of original
            // This requires modification to GaussianSplatRenderer
            */
        }

        private void ReleaseGPU()
        {
            m_SkinBuffer?.Release();
            m_SkinBuffer = null;
            
            m_BindPosePosBuffer?.Release();
            m_BindPosePosBuffer = null;
            
            m_BindPoseOtherBuffer?.Release();
            m_BindPoseOtherBuffer = null;
            
            m_BindPoseCaptured = false;
        }

        /// <summary>
        /// Calculate bone weights (editor only - expensive operation)
        /// </summary>
        [ContextMenu("Recalculate Weights")]
        public void RecalculateWeights()
        {
            // Ensure components are found
            if (m_Renderer == null)
                m_Renderer = GetComponent<GaussianSplatRenderer>();
            
            if (m_Rig == null)
                m_Rig = FindRig();

            // Older converter versions copied Mixamo's 100x FBX import scale onto
            // the generated rig. Normalize it without moving the visible skeleton.
            if (m_Rig != null && !Vector3ApproximatelyEqual(m_Rig.transform.localScale, Vector3.one))
                m_Rig.NormalizeScale();
            
            // Refresh the complete hierarchy; Mixamo rigs often exceed the old
            // 64-bone limit and stale arrays produce incorrect bone indices.
            if (m_Rig != null)
                m_Rig.RebuildRig(!Application.isPlaying);
            
            if (!IsValid())
            {
                return;
            }

            // Recalculation defines a new coherent rest pose for both the bones and
            // splats. Invalidate any GPU snapshot captured by an earlier animation.
            // Never redefine the skeleton's rest pose from a frame in the middle
            // of a running animation. OnEnable already captured the true rest pose.
            if (!Application.isPlaying)
                m_Rig.CaptureBindPoses();
            m_BindPosePosBuffer?.Release();
            m_BindPosePosBuffer = null;
            m_BindPoseOtherBuffer?.Release();
            m_BindPoseOtherBuffer = null;
            m_BindPoseCaptured = false;

            CalculateWeights();
            if (m_SplatSkins == null || m_SplatSkins.Length == 0)
                return;

            m_WeightsCalculated = true;
            m_EnableSkinning = true;

            if (m_UseComputeShader && m_SkinningCS != null)
                CaptureBindPose();
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            #endif
        }

        private GaussianSplatRig FindRig()
        {
            GaussianSplatRig found = GetComponentInParent<GaussianSplatRig>();
            if (found != null)
                return found;

            Transform searchRoot = transform.parent != null ? transform.parent : transform.root;
            return searchRoot != null ? searchRoot.GetComponentInChildren<GaussianSplatRig>(true) : null;
        }

        /// <summary>
        /// Clear calculated weights
        /// NOTE: Cannot restore corrupted splat data - reload scene if splats disappeared
        /// </summary>
        [ContextMenu("Clear Weights")]
        public void ClearWeights()
        {
            m_SplatSkins = null;
            m_WeightsCalculated = false;
            m_BindPoseCaptured = false;
            m_EnableSkinning = false;
            ReleaseGPU();
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            #endif
        }

        /// <summary>
        /// Paint weight for a specific bone onto splats
        /// </summary>
        public void PaintWeight(GaussianSplatBone bone, Vector3 worldPos, float radius, float strength)
        {
            if (!IsValid()) return;
            
            int boneIdx = m_Rig.GetBoneIndex(bone);
            if (boneIdx < 0) return;

            // Implementation would modify weights for splats near worldPos
            // This is for manual weight painting workflow
        }
        
        /// <summary>
        /// Fixes references after duplication - call this after duplicating a rigged character
        /// </summary>
        [ContextMenu("Fix References After Duplication")]
        public void FixReferencesAfterDuplication()
        {
            // Find components in this hierarchy
            if (m_Renderer == null)
                m_Renderer = GetComponent<GaussianSplatRenderer>();
            
            if (m_Rig == null)
                m_Rig = GetComponentInParent<GaussianSplatRig>();
            
            // Rebuild rig to find bones in new hierarchy
            if (m_Rig != null)
            {
                m_Rig.RebuildRig();
                Debug.Log($"[GaussianSplatSkin] Fixed references - Found rig with {m_Rig.boneCount} bones");
            }
            
            // Clear bind transforms so they get recaptured
            m_RigBindTransformData = new float[16];
            m_RigInvBindTransformData = new float[16];
            m_RendererBindTransformData = new float[16];
            m_RendererInvBindTransformData = new float[16];
            
            // Mark that weights need to be recalculated
            m_WeightsCalculated = false;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            Debug.Log("[GaussianSplatSkin] References fixed! You need to recalculate weights for this duplicate.");
            #endif
        }

        // private void OnDrawGizmos()
        // {
        //     if (m_SkinMode == SkinMode.BoundsVolume)
        //     {
        //         Gizmos.matrix = transform.localToWorldMatrix;
        //         Gizmos.color = new Color(0f, 1f, 0.5f, 0.3f);
        //         Gizmos.DrawWireCube(m_SelectionBounds.center, m_SelectionBounds.size);
        //         Gizmos.color = new Color(0f, 1f, 0.5f, 0.1f);
        //         Gizmos.DrawCube(m_SelectionBounds.center, m_SelectionBounds.size);
        //     }
        // }
    }
}
