// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Stores large transferred-weight arrays outside scenes and prefabs.
    /// Components retain only a reference, avoiding expensive scene serialization
    /// whenever an unrelated Inspector value changes.
    /// </summary>
    public sealed class MixamoWeightData : ScriptableObject
    {
        [SerializeField, HideInInspector]
        private MixamoWeightInjector.MixamoWeight[] m_Weights;

        public MixamoWeightInjector.MixamoWeight[] weights => m_Weights;
        public int count => m_Weights != null ? m_Weights.Length : 0;

        public void SetWeights(MixamoWeightInjector.MixamoWeight[] weights)
        {
            m_Weights = weights;
        }
    }
}
