// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Experimental.Rendering;
using Unity.Mathematics;
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Runtime
{
    [ExecuteInEditMode]
    public class GaussianSplatVoxelizerGPU : MonoBehaviour
    {
        [Header("Source")]
        [SerializeField] private GaussianSplatRenderer m_SplatRenderer;
        
        [Header("Voxel Settings")]
        [SerializeField] private float m_VoxelSize = 0.05f;
        [SerializeField] private int m_SampleEveryNthSplat = 10;
        
        [Header("Activation")]
        [SerializeField] private float m_ActivationRadius = 30.0f;
        [SerializeField] private int m_UpdateEveryNthFrame = 5;
        
        [Header("Rendering")]
        [SerializeField] private Material m_VoxelMaterial;
        [SerializeField] private ComputeShader m_VoxelCompute;
        [SerializeField] private bool m_CastShadows = true;
        [SerializeField] private bool m_ReceiveShadows = true;
        [SerializeField, Tooltip("Hide voxel color rendering but keep voxels in Unity shadow maps.")]
        private bool m_ShadowsOnly = false;
        [Min(0.01f)]
        [SerializeField, Tooltip("Shadow-proxy voxel size. Values above 1 overlap adjacent cube shadows into a more continuous silhouette.")]
        private float m_ShadowSizeMultiplier = 1.25f;
        [Min(0f)]
        [SerializeField, Tooltip("Brightness multiplier for voxel lighting. Values above 1 can also increase bloom.")]
        private float m_LightMultiplier = 1.0f;
        
        [Header("Progressive Build")]
        [SerializeField] private bool m_HideSplatsWhenDone = true;
        
        [Header("Debug")]
        [SerializeField, Tooltip("Allow GPU dispatch and indirect rendering while not in Play Mode.")]
        private bool m_PreviewInEditor = false;
        [SerializeField] private bool m_ShowGizmos = false;
        [SerializeField] private bool m_DebugLog = false;
        
        private ComputeBuffer m_VoxelBuffer;
        private ComputeBuffer m_ArgsBuffer;
        private Mesh m_CubeMesh;
        private int m_TotalVoxels;
        private int m_FrameCounter;
        private Camera m_MainCamera;
        private bool m_InUpdate;
        
        private int m_KernelActivate = -1;
        
        private MaterialPropertyBlock m_PropertyBlock;
        
        struct VoxelData
        {
            public Vector3 position;
            public Vector4 color;
            public float size;
            public uint active;
            public Vector3 velocity;
            public uint dynamic;
        }
        
        void OnEnable()
        {
            m_MainCamera = Camera.main;
            m_PropertyBlock = new MaterialPropertyBlock();
            
            if (m_VoxelCompute != null)
            {
                try
                {
                    m_KernelActivate = m_VoxelCompute.FindKernel("CSActivateVoxels");
                }
                catch (System.Exception exception)
                {
                    m_KernelActivate = -1;
                    Debug.LogError($"Voxel activation kernel is unavailable: {exception.Message}", this);
                }
            }
            
            CreateCubeMesh();
        }
        
        void OnDisable()
        {
            DisposeBuffers();

            if (m_CubeMesh == null)
                return;

            if (Application.isPlaying)
                Destroy(m_CubeMesh);
            else
                DestroyImmediate(m_CubeMesh);

            m_CubeMesh = null;
        }
        
        void Update()
        {
            if (m_InUpdate)
                return;
            
            if (m_VoxelBuffer == null)
                return;
            
#if UNITY_EDITOR
            if (!Application.isPlaying &&
                (!m_PreviewInEditor ||
                 UnityEditor.EditorApplication.isCompiling ||
                 UnityEditor.EditorApplication.isUpdating))
                return;
#endif
            
            m_InUpdate = true;
            try
            {
                if (m_MainCamera == null)
                    m_MainCamera = Camera.main;
                
                m_FrameCounter++;
                
                int updateInterval = Mathf.Max(1, m_UpdateEveryNthFrame);
                if (m_FrameCounter % updateInterval == 0)
                {
                    UpdateVoxelActivation();
                }
                
                if (m_VoxelMaterial != null)
                {
                    RenderVoxels();
                }
            }
            finally
            {
                m_InUpdate = false;
            }
        }
        
        public void VoxelizeWorld()
        {
            if (m_SplatRenderer == null || !m_SplatRenderer.HasValidAsset)
            {
                Debug.LogError("Invalid splat renderer");
                return;
            }

            m_VoxelSize = Mathf.Max(0.001f, m_VoxelSize);

            if (m_CubeMesh == null)
                CreateCubeMesh();
            if (m_PropertyBlock == null)
                m_PropertyBlock = new MaterialPropertyBlock();
            
            DisposeBuffers();
            
            var asset = m_SplatRenderer.asset;
            var splatCount = m_SplatRenderer.splatCount;
            var splatTransform = m_SplatRenderer.transform;
            
            int sampleStep = Mathf.Max(1, m_SampleEveryNthSplat);
            int totalSplatsToSample = (splatCount + sampleStep - 1) / sampleStep;
            
            if (m_DebugLog)
                Debug.Log($"Sampling {totalSplatsToSample} splats (every {sampleStep}th from {splatCount} total), voxel size: {m_VoxelSize}m");
            
            // Read splat data
            var posBuffer = m_SplatRenderer.GpuPosData;
            int posStride = (int)(asset.posData.dataSize / asset.splatCount);
            int posInts = posStride / 4;
            uint[] posData = new uint[splatCount * posInts];
            posBuffer.GetData(posData);
            GaussianSplatAsset.ChunkInfo[] chunks = asset.chunkData != null
                ? asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>().ToArray()
                : null;
            
            // Read colors
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(splatCount);
            Color[] colors = ReadColorData(texWidth, texHeight);
            
            // Create voxel grid by quantizing splats
            Dictionary<int3, VoxelData> voxelGrid = new Dictionary<int3, VoxelData>();
            
            for (int i = 0; i < splatCount; i += sampleStep)
            {
                Vector3 localPos = DecodeSplatPosition(posData, i, posInts, asset.posFormat, asset, chunks);
                Vector3 worldPos = splatTransform.TransformPoint(localPos);
                
                int3 gridPos = WorldToGrid(worldPos);
                Color splatColor = GetColorForSplat(i, colors, texWidth);
                
                if (!voxelGrid.ContainsKey(gridPos))
                {
                    VoxelData voxel = new VoxelData
                    {
                        position = GridToWorld(gridPos),
                        color = new Vector4(splatColor.r, splatColor.g, splatColor.b, splatColor.a),
                        size = m_VoxelSize,
                        active = 1,
                        velocity = Vector3.zero,
                        dynamic = 0
                    };
                    voxelGrid[gridPos] = voxel;
                }
                else
                {
                    var existing = voxelGrid[gridPos];
                    Color existingColor = new Color(existing.color.x, existing.color.y, existing.color.z, existing.color.w);
                    Color avgColor = Color.Lerp(existingColor, splatColor, 0.5f);
                    existing.color = new Vector4(avgColor.r, avgColor.g, avgColor.b, avgColor.a);
                    voxelGrid[gridPos] = existing;
                }
            }
            
            m_TotalVoxels = voxelGrid.Count;
            
            if (m_DebugLog)
                Debug.Log($"Created {m_TotalVoxels} unique voxels from {totalSplatsToSample} sampled splats");

            if (m_TotalVoxels == 0)
            {
                Debug.LogWarning("Voxelization produced no voxels.", this);
                return;
            }
            
            // Create GPU buffer
            int voxelStride = sizeof(float) * 3 + sizeof(float) * 4 + sizeof(float) +
                              sizeof(uint) + sizeof(float) * 3 + sizeof(uint);
            m_VoxelBuffer = new ComputeBuffer(m_TotalVoxels, voxelStride);
            
            VoxelData[] voxelArray = new VoxelData[m_TotalVoxels];
            int idx = 0;
            foreach (var kvp in voxelGrid)
            {
                voxelArray[idx] = kvp.Value;
                idx++;
            }
            
            m_VoxelBuffer.SetData(voxelArray);
            
            // Create indirect args buffer
            uint[] args = new uint[5] { 0, 0, 0, 0, 0 };
            args[0] = m_CubeMesh.GetIndexCount(0);
            args[1] = (uint)m_TotalVoxels;
            args[2] = m_CubeMesh.GetIndexStart(0);
            args[3] = m_CubeMesh.GetBaseVertex(0);
            args[4] = 0;
            
            m_ArgsBuffer = new ComputeBuffer(1, args.Length * sizeof(uint), ComputeBufferType.IndirectArguments);
            m_ArgsBuffer.SetData(args);
            
            if (m_DebugLog)
                Debug.Log($"GPU voxelization complete: {m_TotalVoxels} voxels ready for rendering");
            
            UpdateVoxelActivation();
            
            if (m_HideSplatsWhenDone && m_SplatRenderer != null)
            {
                m_SplatRenderer.gameObject.SetActive(false);
                if (m_DebugLog)
                    Debug.Log("Gaussian Splat renderer hidden");
            }
        }
        
        int3 WorldToGrid(Vector3 worldPos)
        {
            return new int3(
                Mathf.FloorToInt(worldPos.x / m_VoxelSize),
                Mathf.FloorToInt(worldPos.y / m_VoxelSize),
                Mathf.FloorToInt(worldPos.z / m_VoxelSize)
            );
        }
        
        Vector3 GridToWorld(int3 gridPos)
        {
            return new Vector3(
                gridPos.x * m_VoxelSize + m_VoxelSize * 0.5f,
                gridPos.y * m_VoxelSize + m_VoxelSize * 0.5f,
                gridPos.z * m_VoxelSize + m_VoxelSize * 0.5f
            );
        }
        
        Color GetColorForSplat(int splatIndex, Color[] colors, int texWidth)
        {
            if (colors == null) return Color.white;
            
            // The color texture uses 16x16 blocks with Morton encoding within each block
            int blockSize = 16;
            int splatsPerBlock = blockSize * blockSize; // 256
            int blocksPerRow = texWidth / blockSize;
            
            int blockIndex = splatIndex / splatsPerBlock;
            int localIndex = splatIndex % splatsPerBlock;
            
            int blockX = blockIndex % blocksPerRow;
            int blockY = blockIndex / blocksPerRow;
            
            // Morton decode the local index within the 16x16 block
            var localCoords = GaussianUtils.DecodeMorton2D_16x16((uint)localIndex);
            
            int x = blockX * blockSize + (int)localCoords.x;
            int y = blockY * blockSize + (int)localCoords.y;
            
            int index = y * texWidth + x;
            
            return (index >= 0 && index < colors.Length) ? colors[index] : Color.white;
        }
        
        Color[] ReadColorData(int texWidth, int texHeight)
        {
            var colorTex = m_SplatRenderer.GpuColorData;
            
            if (colorTex is Texture2D tex2D)
            {
                try { return tex2D.GetPixels(); }
                catch { return null; }
            }
            else if (colorTex is RenderTexture rt)
            {
                RenderTexture.active = rt;
                var tempTex = new Texture2D(texWidth, texHeight, rt.graphicsFormat, UnityEngine.Experimental.Rendering.TextureCreationFlags.None);
                tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
                tempTex.Apply();
                RenderTexture.active = null;
                var pixels = tempTex.GetPixels();
                DestroyImmediate(tempTex);
                return pixels;
            }
            
            return null;
        }
        
        Vector3 DecodeSplatPosition(uint[] posData, int splatIndex, int posInts, 
            GaussianSplatAsset.VectorFormat format, GaussianSplatAsset asset,
            GaussianSplatAsset.ChunkInfo[] chunks)
        {
            int offset = splatIndex * posInts;
            Vector3 decoded;

            switch (format)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    decoded = new Vector3(
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 1]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 2]), 0)
                    );
                    break;
                    
                case GaussianSplatAsset.VectorFormat.Norm16:
                    ushort x = (ushort)(posData[offset] & 0xFFFF);
                    ushort y = (ushort)((posData[offset] >> 16) & 0xFFFF);
                    ushort z = (ushort)(posData[offset + 1] & 0xFFFF);
                    
                    decoded = new Vector3(
                        x / 65535.0f,
                        y / 65535.0f,
                        z / 65535.0f
                    );
                    break;

                case GaussianSplatAsset.VectorFormat.Norm11:
                    uint packed = posData[offset];
                    uint packedX = packed & 0x7FFu;
                    uint packedY = (packed >> 11) & 0x3FFu;
                    uint packedZ = (packed >> 21) & 0x7FFu;

                    decoded = new Vector3(
                        packedX / 2047.0f,
                        packedY / 1023.0f,
                        packedZ / 2047.0f
                    );
                    break;
                    
                default:
                    return Vector3.zero;
            }

            int chunkIndex = splatIndex / GaussianSplatAsset.kChunkSize;
            if (chunks != null && chunkIndex < chunks.Length)
            {
                var chunk = chunks[chunkIndex];
                return new Vector3(
                    Mathf.Lerp(chunk.posX.x, chunk.posX.y, decoded.x),
                    Mathf.Lerp(chunk.posY.x, chunk.posY.y, decoded.y),
                    Mathf.Lerp(chunk.posZ.x, chunk.posZ.y, decoded.z)
                );
            }

            if (format == GaussianSplatAsset.VectorFormat.Float32)
                return decoded;

            return new Vector3(
                Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, decoded.x),
                Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, decoded.y),
                Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, decoded.z)
            );
        }
        
        void UpdateVoxelActivation()
        {
            if (m_MainCamera == null || m_VoxelBuffer == null || m_VoxelCompute == null ||
                m_KernelActivate < 0 || m_TotalVoxels <= 0)
                return;
            
            Vector3 camPos = m_MainCamera.transform.position;
            
            m_VoxelCompute.SetBuffer(m_KernelActivate, "_VoxelBuffer", m_VoxelBuffer);
            m_VoxelCompute.SetInt("_VoxelCount", m_TotalVoxels);
            m_VoxelCompute.SetVector("_CameraPosition", camPos);
            m_VoxelCompute.SetFloat("_ActivationRadius", m_ActivationRadius);
            
            int threadGroups = (m_TotalVoxels + 255) / 256;
            m_VoxelCompute.Dispatch(m_KernelActivate, threadGroups, 1, 1);
        }
        
        void RenderVoxels()
        {
            if (m_VoxelBuffer == null || m_VoxelMaterial == null || m_CubeMesh == null || m_ArgsBuffer == null)
                return;
            
            m_PropertyBlock.SetBuffer("_VoxelBuffer", m_VoxelBuffer);
            m_PropertyBlock.SetFloat("_LightMultiplier", Mathf.Max(0f, m_LightMultiplier));
            m_PropertyBlock.SetFloat("_ShadowSizeMultiplier", Mathf.Max(0.01f, m_ShadowSizeMultiplier));
            
            ShadowCastingMode shadowMode = m_ShadowsOnly
                ? ShadowCastingMode.ShadowsOnly
                : (m_CastShadows ? ShadowCastingMode.On : ShadowCastingMode.Off);
            
            Graphics.DrawMeshInstancedIndirect(
                m_CubeMesh,
                0,
                m_VoxelMaterial,
                new Bounds(Vector3.zero, Vector3.one * 10000),
                m_ArgsBuffer,
                0,
                m_PropertyBlock,
                shadowMode,
                m_ReceiveShadows
            );
        }
        
        void CreateCubeMesh()
        {
            if (m_CubeMesh != null)
                return;

            m_CubeMesh = Resources.GetBuiltinResource<Mesh>("Cube.fbx");
            if (m_CubeMesh != null)
                return;

            m_CubeMesh = new Mesh();
            
            Vector3[] vertices = new Vector3[]
            {
                new Vector3(-0.5f, -0.5f, -0.5f),
                new Vector3( 0.5f, -0.5f, -0.5f),
                new Vector3( 0.5f,  0.5f, -0.5f),
                new Vector3(-0.5f,  0.5f, -0.5f),
                new Vector3(-0.5f, -0.5f,  0.5f),
                new Vector3( 0.5f, -0.5f,  0.5f),
                new Vector3( 0.5f,  0.5f,  0.5f),
                new Vector3(-0.5f,  0.5f,  0.5f)
            };
            
            int[] triangles = new int[]
            {
                0,2,1, 0,3,2,
                1,2,6, 1,6,5,
                5,6,7, 5,7,4,
                4,7,3, 4,3,0,
                3,7,6, 3,6,2,
                4,0,1, 4,1,5
            };
            
            Vector3[] normals = new Vector3[8];
            for (int i = 0; i < 8; i++)
                normals[i] = vertices[i].normalized;
            
            m_CubeMesh.vertices = vertices;
            m_CubeMesh.triangles = triangles;
            m_CubeMesh.normals = normals;
            m_CubeMesh.RecalculateBounds();
        }
        
        void DisposeBuffers()
        {
            m_VoxelBuffer?.Dispose();
            m_VoxelBuffer = null;
            
            m_ArgsBuffer?.Dispose();
            m_ArgsBuffer = null;
        }
        
        public void DeleteVoxelWorld()
        {
            if (m_DebugLog)
                Debug.Log("Deleting GPU voxel world...");
            
            DisposeBuffers();
            m_TotalVoxels = 0;
            
            System.GC.Collect();
            
            if (m_DebugLog)
                Debug.Log("GPU voxel world deleted and memory freed");
        }
        
        public int GetTotalVoxels() => m_TotalVoxels;
        
        void OnDrawGizmos()
        {
            if (!m_ShowGizmos) return;
            
            if (m_MainCamera != null)
            {
                Gizmos.color = Color.green;
                Gizmos.DrawWireSphere(m_MainCamera.transform.position, m_ActivationRadius);
            }
        }
    }
}
