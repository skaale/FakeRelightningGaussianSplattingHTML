// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using Unity.Mathematics;
#if UNITY_EDITOR
using UnityEditor;
#endif
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Runtime
{
    [ExecuteInEditMode]
    public class GaussianSplatVoxelizerSimple : MonoBehaviour
    {
        public enum VoxelMode
        {
            CPUGameObjects,
            GPUInstanced
        }
        
        [Header("Source")]
        [SerializeField] private GaussianSplatRenderer m_SplatRenderer;
        
        [Header("Voxel Mode")]
        [SerializeField] private VoxelMode m_VoxelMode = VoxelMode.CPUGameObjects;
        [SerializeField] private ComputeShader m_VoxelCompute;
        [SerializeField] private ComputeShader m_PhysicsCompute;
        
        [Header("Voxel Settings")]
        [SerializeField] private float m_VoxelSize = 0.05f;
        [SerializeField] private int m_SampleEveryNthSplat = 1;
        
        [Header("Physics Settings")]
        [SerializeField] private float m_CubeMass = 1.0f;
        [SerializeField] private PhysicsMaterial m_PhysicsMaterial;
        [SerializeField, Tooltip("Allow VoxelPhysicsTrigger objects to activate voxel physics.")]
        private bool m_EnablePhysics = false;
        [SerializeField, Tooltip("Layer to assign voxels (0=Default). Setup: Create 'Voxels' layer, disable collision with camera layer in Physics Matrix")]
        private int m_VoxelLayer = 0;
        [SerializeField, Tooltip("Allow voxels to collide with one another. GPU mode uses an approximate local-neighbor solver.")]
        private bool m_EnableSelfCollision = true;
        [SerializeField, Tooltip("Optional solid BoxCollider used as the GPU voxel ground. CPU voxels use it through normal Unity physics.")]
        private BoxCollider m_CollisionBox;
        
        [Header("Activation")]
        [SerializeField] private float m_ActivationRadius = 20.0f;
        [SerializeField] private int m_CheckEveryNthFrame = 10;
        
        [Header("Visual")]
        [SerializeField] private bool m_UseColorFromSplats = true;
        [SerializeField, Tooltip("Material for all voxel rendering (GameObjects). GPU mode uses matching shader automatically.")]
        private Material m_VoxelMaterial;
        [SerializeField] private bool m_CastShadows = true;
        [SerializeField] private bool m_ReceiveShadows = true;
        [SerializeField, Tooltip("Hide voxel color rendering but keep voxels in Unity shadow maps.")]
        private bool m_ShadowsOnly = false;
        [Min(0.01f)]
        [SerializeField, Tooltip("GPU shadow-proxy voxel size. Values above 1 overlap adjacent cube shadows into a more continuous silhouette.")]
        private float m_ShadowSizeMultiplier = 1.25f;
        [Min(0f)]
        [SerializeField, Tooltip("Brightness multiplier for GPU voxel lighting. Values above 1 can also increase bloom.")]
        private float m_LightMultiplier = 1.0f;
        
        // Runtime GPU material (created automatically to match m_VoxelMaterial lighting)
        private Material m_GPUVoxelMaterial;
        
        [Header("Progressive Build")]
        [Tooltip("Splats processed per frame. Lower values produce a slower, more visible CPU/GPU build animation.")]
        [SerializeField] private int m_VoxelsPerFrame = 500;
        [Min(0.01f)]
        [Tooltip("GPU progressive-build speed multiplier. For example: 0.5 is half speed, 1 is normal, and 2 is double speed.")]
        [SerializeField] private float m_GPUBuildSpeed = 1.0f;
        [SerializeField] private bool m_ActivateNearCameraOnly = false;
        [SerializeField] private bool m_HideSplatsWhenDone = true;
        
        [Header("Debug")]
        [SerializeField, Tooltip("Allow camera activation and GPU rendering while not in Play Mode.")]
        private bool m_PreviewInEditor = false;
        [SerializeField] private bool m_DebugLog = false;
        
        private Dictionary<int3, VoxelCube> m_VoxelGrid = new Dictionary<int3, VoxelCube>();
        private List<GameObject> m_ActiveCubes = new List<GameObject>();
        private int m_FrameCounter;
        private Camera m_MainCamera;
        private bool m_IsBuilding;
        private int m_BuildProgress;
        private int m_TotalSplatsToSample;
        
        private uint[] m_CachedPosData;
        private Color[] m_CachedColors;
        private GaussianSplatAsset.ChunkInfo[] m_CachedChunks;
        private int m_CachedPosInts;
        private GameObject m_VoxelContainer;
        private bool m_RegisterUndo = false;
        private Material m_DefaultVoxelMaterial;
        private bool m_InUpdate;
        private Quaternion m_VoxelRotation = Quaternion.identity;
        private Vector3 m_VoxelScale = Vector3.one;
        
        // GPU Instancing fields
        private ComputeBuffer m_GPUVoxelBuffer;
        private ComputeBuffer m_ArgsBuffer;
        private Mesh m_CubeMesh;
        private MaterialPropertyBlock m_PropertyBlock;
        private int m_GPUVoxelCount;
        private int m_GPUVoxelCapacity;
        private int m_GPUUploadedCount;
        private GPUVoxelData[] m_GPUVoxelArray;
        private int m_KernelActivate = -1;
        private int m_KernelApplyGPUForce = -1;
        private int m_KernelApplyGPUVortex = -1;
        private int m_KernelSimulateGPU = -1;
        private int m_KernelResolveGPUCollisions = -1;
        
        // GPU Voxel data structure (must match compute shader)
        private struct GPUVoxelData
        {
            public Vector3 position;
            public Vector4 color;
            public float size;
            public uint active;
            public Vector3 velocity;
            public uint dynamic;
        }
        
        private class VoxelCube
        {
            public int3 gridPos;
            public Vector3 worldPos;
            public Color color;
            public GameObject cubeObject;
            public bool hasPhysics;
            public int splatCount;
            public Color accumulatedColor;
            public int gpuIndex = -1;
        }
        
        void OnEnable()
        {
            m_MainCamera = Camera.main;
            m_PropertyBlock = new MaterialPropertyBlock();
            m_InUpdate = false;
            m_IsBuilding = false;
            
            // Initialize GPU resources
            InitializeGPU();
            CreateCubeMesh();
            
            // Clean up any existing physics on voxels if physics is disabled
            if (!m_EnablePhysics)
            {
                CleanupAllPhysics();
            }
            
            #if UNITY_EDITOR
            // Never subscribe here — EditorApplication.update + SceneView.RepaintAll
            // was a feedback loop that crashed Unity on project/scene open.
            UnityEditor.EditorApplication.update -= EditorUpdate;
            
            // Warn about layer collision setup
            if (m_VoxelLayer > 0 && m_DebugLog)
            {
                Debug.Log($"Voxels are on layer {m_VoxelLayer} ({LayerMask.LayerToName(m_VoxelLayer)}). " +
                         $"Ensure Physics Matrix allows collision between this layer and your trigger objects.");
            }
            #endif
        }
        
        void OnDisable()
        {
            #if UNITY_EDITOR
            UnityEditor.EditorApplication.update -= EditorUpdate;
            #endif

            DisposeGPUBuffers();
        }
        
        void OnDestroy()
        {
            #if UNITY_EDITOR
            UnityEditor.EditorApplication.update -= EditorUpdate;
            #endif
            
            DisposeGPUBuffers();
            if (Application.isPlaying)
            {
                ClearAll();
            }
        }
        
        #if UNITY_EDITOR
        void EditorUpdate()
        {
            if (Application.isPlaying || !m_IsBuilding)
            {
                UnityEditor.EditorApplication.update -= EditorUpdate;
                return;
            }
            
            if (UnityEditor.EditorApplication.isCompiling || UnityEditor.EditorApplication.isUpdating)
                return;
            
            TickUpdate();
            if (m_IsBuilding && m_VoxelMode == VoxelMode.GPUInstanced)
                UnityEditor.SceneView.lastActiveSceneView?.Repaint();
        }
        
        static bool IsEditorSafeToTick()
        {
            return !UnityEditor.EditorApplication.isCompiling
                && !UnityEditor.EditorApplication.isUpdating;
        }
        #endif
        
        void InitializeGPU()
        {
            if (m_VoxelCompute != null)
            {
                try
                {
                    m_KernelActivate = m_VoxelCompute.FindKernel("CSActivateVoxels");
                }
                catch { m_KernelActivate = -1; }
            }
            
            if (m_PhysicsCompute != null)
            {
                try
                {
                    m_KernelApplyGPUForce = m_PhysicsCompute.FindKernel("CSApplySphere");
                    m_KernelApplyGPUVortex = m_PhysicsCompute.FindKernel("CSApplyVortex");
                    m_KernelSimulateGPU = m_PhysicsCompute.FindKernel("CSSimulate");
                    m_KernelResolveGPUCollisions = m_PhysicsCompute.FindKernel("CSResolveSelfCollisions");
                }
                catch 
                { 
                    m_KernelApplyGPUForce = -1;
                    m_KernelApplyGPUVortex = -1;
                    m_KernelSimulateGPU = -1;
                    m_KernelResolveGPUCollisions = -1;
                }
            }
        }
        
        void CreateCubeMesh()
        {
            if (m_CubeMesh != null) return;

            // Use Unity's cube so GPU voxels have the same face winding and normals
            // as the primitive cubes used by CPU mode.
            m_CubeMesh = Resources.GetBuiltinResource<Mesh>("Cube.fbx");
            if (m_CubeMesh != null)
                return;
            
            m_CubeMesh = new Mesh();
            m_CubeMesh.name = "VoxelCube";
            
            // 24 vertices (4 per face) with proper face normals - matches Unity's primitive cube
            Vector3[] vertices = new Vector3[24]
            {
                // Front face (Z+)
                new Vector3(-0.5f, -0.5f,  0.5f), new Vector3( 0.5f, -0.5f,  0.5f),
                new Vector3( 0.5f,  0.5f,  0.5f), new Vector3(-0.5f,  0.5f,  0.5f),
                // Back face (Z-)
                new Vector3( 0.5f, -0.5f, -0.5f), new Vector3(-0.5f, -0.5f, -0.5f),
                new Vector3(-0.5f,  0.5f, -0.5f), new Vector3( 0.5f,  0.5f, -0.5f),
                // Top face (Y+)
                new Vector3(-0.5f,  0.5f,  0.5f), new Vector3( 0.5f,  0.5f,  0.5f),
                new Vector3( 0.5f,  0.5f, -0.5f), new Vector3(-0.5f,  0.5f, -0.5f),
                // Bottom face (Y-)
                new Vector3(-0.5f, -0.5f, -0.5f), new Vector3( 0.5f, -0.5f, -0.5f),
                new Vector3( 0.5f, -0.5f,  0.5f), new Vector3(-0.5f, -0.5f,  0.5f),
                // Right face (X+)
                new Vector3( 0.5f, -0.5f,  0.5f), new Vector3( 0.5f, -0.5f, -0.5f),
                new Vector3( 0.5f,  0.5f, -0.5f), new Vector3( 0.5f,  0.5f,  0.5f),
                // Left face (X-)
                new Vector3(-0.5f, -0.5f, -0.5f), new Vector3(-0.5f, -0.5f,  0.5f),
                new Vector3(-0.5f,  0.5f,  0.5f), new Vector3(-0.5f,  0.5f, -0.5f)
            };
            
            Vector3[] normals = new Vector3[24]
            {
                // Front face normals
                Vector3.forward, Vector3.forward, Vector3.forward, Vector3.forward,
                // Back face normals
                Vector3.back, Vector3.back, Vector3.back, Vector3.back,
                // Top face normals
                Vector3.up, Vector3.up, Vector3.up, Vector3.up,
                // Bottom face normals
                Vector3.down, Vector3.down, Vector3.down, Vector3.down,
                // Right face normals
                Vector3.right, Vector3.right, Vector3.right, Vector3.right,
                // Left face normals
                Vector3.left, Vector3.left, Vector3.left, Vector3.left
            };
            
            int[] triangles = new int[36]
            {
                // Front
                0, 2, 1, 0, 3, 2,
                // Back
                4, 6, 5, 4, 7, 6,
                // Top
                8, 10, 9, 8, 11, 10,
                // Bottom
                12, 14, 13, 12, 15, 14,
                // Right
                16, 18, 17, 16, 19, 18,
                // Left
                20, 22, 21, 20, 23, 22
            };
            
            m_CubeMesh.vertices = vertices;
            m_CubeMesh.normals = normals;
            m_CubeMesh.triangles = triangles;
            m_CubeMesh.RecalculateBounds();
        }
        
        void DisposeGPUBuffers()
        {
            m_GPUVoxelBuffer?.Dispose();
            m_GPUVoxelBuffer = null;
            
            m_ArgsBuffer?.Dispose();
            m_ArgsBuffer = null;
            
            m_GPUVoxelCount = 0;
            m_GPUVoxelCapacity = 0;
            m_GPUUploadedCount = 0;
            m_GPUVoxelArray = null;
            
            // Clean up runtime GPU material
            if (m_GPUVoxelMaterial != null)
            {
                if (Application.isPlaying)
                    Destroy(m_GPUVoxelMaterial);
                else
                    DestroyImmediate(m_GPUVoxelMaterial);
                m_GPUVoxelMaterial = null;
            }
        }
        
        void CleanupAllPhysics()
        {
            // Freeze all rigidbodies (set them to kinematic)
            foreach (var kvp in m_VoxelGrid)
            {
                if (kvp.Value.hasPhysics)
                {
                    DisableVoxelPhysics(kvp.Value);
                }
            }
            
            if (m_DebugLog)
                Debug.Log("All voxel physics frozen (rigidbodies set to kinematic)");
        }
        
        void Update()
        {
            #if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                bool hasGPUPreview = m_VoxelMode == VoxelMode.GPUInstanced &&
                                     m_GPUVoxelBuffer != null;
                if ((!m_PreviewInEditor && !hasGPUPreview) || !IsEditorSafeToTick())
                    return;
            }
            #endif
            
            TickUpdate();
        }
        
        void TickUpdate()
        {
            if (m_InUpdate)
                return;
            
            bool hasWork = m_IsBuilding || m_VoxelGrid.Count > 0 || m_GPUVoxelBuffer != null;
            if (!hasWork)
                return;
            
            m_InUpdate = true;
            try
            {
                bool allowLiveUpdate = Application.isPlaying;
#if UNITY_EDITOR
                allowLiveUpdate |= m_PreviewInEditor ||
                                   (m_VoxelMode == VoxelMode.GPUInstanced &&
                                    m_GPUVoxelBuffer != null);
#endif

                if (allowLiveUpdate)
                    EnsureCamera();
                
                m_FrameCounter++;
                
                // If physics is disabled, ensure no voxels have Rigidbodies
                if (allowLiveUpdate && !m_EnablePhysics && m_FrameCounter % 60 == 0)
                {
                    CleanupAllPhysics();
                }
                
                if (m_IsBuilding)
                {
                    BuildVoxelsProgressively();
                }
                
                int checkInterval = Mathf.Max(1, m_CheckEveryNthFrame);
                if (allowLiveUpdate && m_FrameCounter % checkInterval == 0)
                {
                    UpdateVoxelActivation();
                    
                    // Update GPU voxel activation
                    if (m_VoxelMode == VoxelMode.GPUInstanced && m_ActivateNearCameraOnly)
                    {
                        UpdateGPUVoxelActivation();
                    }
                }
                
                // GPU Instanced rendering
                if (allowLiveUpdate &&
                    m_VoxelMode == VoxelMode.GPUInstanced &&
                    m_GPUVoxelBuffer != null)
                {
                    if (Application.isPlaying && m_EnablePhysics)
                        SimulateGPUPhysics(Time.deltaTime);
                    RenderGPUVoxels();
                }
            }
            finally
            {
                m_InUpdate = false;
            }
        }
        
        void EnsureCamera()
        {
            if (m_MainCamera == null)
                m_MainCamera = Camera.main;
            
            #if UNITY_EDITOR
            if (m_MainCamera == null && !Application.isPlaying)
            {
                var sceneView = UnityEditor.SceneView.lastActiveSceneView;
                if (sceneView != null && sceneView.camera != null)
                    m_MainCamera = sceneView.camera;
            }
            #endif
        }
        
        public void VoxelizeWorld()
        {
            if (m_SplatRenderer == null || !m_SplatRenderer.HasValidAsset)
            {
                Debug.LogError("Invalid splat renderer");
                return;
            }

            m_VoxelSize = Mathf.Max(0.001f, m_VoxelSize);
            ApplyCPUSelfCollisionSetting();

            if (m_CubeMesh == null)
                CreateCubeMesh();
            if (m_PropertyBlock == null)
                m_PropertyBlock = new MaterialPropertyBlock();
            InitializeGPU();
            
            ClearAll();
            
            // Only register the container for undo, not individual voxels (causes stack overflow)
            m_RegisterUndo = false;
            CreateVoxelContainer();
            
#if UNITY_EDITOR
            // Register container for undo - deleting container removes all child voxels
            if (!Application.isPlaying && m_VoxelContainer != null)
            {
                UnityEditor.Undo.RegisterCreatedObjectUndo(m_VoxelContainer, "Create Voxel Container");
            }
#endif
            
            var splatCount = m_SplatRenderer.splatCount;
            int sampleStep = Mathf.Max(1, m_SampleEveryNthSplat);
            m_TotalSplatsToSample = (splatCount + sampleStep - 1) / sampleStep;
            
            if (m_DebugLog)
            {
                Debug.Log($"Sampling {m_TotalSplatsToSample} splats (every {sampleStep}th from {splatCount} total), voxel size: {m_VoxelSize}m");
                Debug.Log($"Asset info - PosFormat: {m_SplatRenderer.asset.posFormat}, ColorFormat: {m_SplatRenderer.asset.colorFormat}, Bounds: {m_SplatRenderer.asset.boundsMin} to {m_SplatRenderer.asset.boundsMax}");
            }
            
            CacheSplatData();

            var sourceTransform = m_SplatRenderer.transform;
            m_VoxelRotation = sourceTransform.rotation;
            Vector3 sourceScale = sourceTransform.lossyScale;
            m_VoxelScale = new Vector3(
                Mathf.Abs(sourceScale.x),
                Mathf.Abs(sourceScale.y),
                Mathf.Abs(sourceScale.z)
            );

            if (m_VoxelMode == VoxelMode.GPUInstanced)
                CreateProgressiveGPUBuffers(m_TotalSplatsToSample);
            
            m_IsBuilding = true;
            m_BuildProgress = 0;
            
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                UnityEditor.EditorApplication.update -= EditorUpdate;
                UnityEditor.EditorApplication.update += EditorUpdate;
            }
#endif
        }
        
        void CreateVoxelContainer()
        {
            if (m_VoxelContainer != null)
                return;
            
            m_VoxelContainer = new GameObject("VoxelizedWorld");
        }
        
        void CacheSplatData()
        {
            var asset = m_SplatRenderer.asset;
            var splatCount = m_SplatRenderer.splatCount;
            
            var posBuffer = m_SplatRenderer.GpuPosData;
            int posStride = (int)(asset.posData.dataSize / asset.splatCount);
            m_CachedPosInts = posStride / 4;
            m_CachedPosData = new uint[splatCount * m_CachedPosInts];
            posBuffer.GetData(m_CachedPosData);

            m_CachedChunks = asset.chunkData != null
                ? asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>().ToArray()
                : null;
            
            if (m_UseColorFromSplats)
            {
                var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(splatCount);
                m_CachedColors = ReadColorData(texWidth, texHeight);
                
                if (m_DebugLog)
                {
                    if (m_CachedColors != null)
                        Debug.Log($"Cached {m_CachedColors.Length} colors from splats");
                    else
                        Debug.LogWarning("Failed to read color data from splats");
                }
            }
        }
        
        void BuildVoxelsProgressively()
        {
            int voxelsBuilt = 0;
            var splatTransform = m_SplatRenderer.transform;
            
            int sampleStep = Mathf.Max(1, m_SampleEveryNthSplat);
            float buildSpeed = m_VoxelMode == VoxelMode.GPUInstanced
                ? Mathf.Max(0.01f, m_GPUBuildSpeed)
                : 1.0f;
            int voxelsThisFrame = Mathf.Max(1, Mathf.RoundToInt(m_VoxelsPerFrame * buildSpeed));
            
            while (m_BuildProgress < m_TotalSplatsToSample && voxelsBuilt < voxelsThisFrame)
            {
                int splatIdx = m_BuildProgress * sampleStep;
                if (splatIdx >= m_SplatRenderer.splatCount)
                    break;
                
                Vector3 localPos = GetSplatPositionAt(splatIdx);
                Vector3 worldPos = splatTransform.TransformPoint(localPos);
                Color splatColor = GetSplatColorAt(splatIdx);
                
                // Quantize in the splat model's local space so the voxel grid follows
                // the model's orientation instead of the world axes.
                int3 gridPos = PositionToGrid(localPos);
                Vector3 voxelWorldPos = splatTransform.TransformPoint(GridToPosition(gridPos));
                
                // Debug position alignment for vibrant colors
                if (m_DebugLog && GetColorStrength(splatColor) > 0.6f && m_BuildProgress % 100 == 0)
                {
                    Debug.Log($"Splat {splatIdx}: LocalPos={localPos}, WorldPos={worldPos}, GridPos=({gridPos.x},{gridPos.y},{gridPos.z}), VoxelWorldPos={voxelWorldPos}, Color RGB({splatColor.r:F2}, {splatColor.g:F2}, {splatColor.b:F2})");
                }
                
                if (!m_VoxelGrid.ContainsKey(gridPos))
                {
                    var voxel = new VoxelCube
                    {
                        gridPos = gridPos,
                        worldPos = voxelWorldPos,
                        color = splatColor,
                        cubeObject = null,
                        splatCount = 1,
                        accumulatedColor = splatColor
                    };
                    m_VoxelGrid[gridPos] = voxel;
                    
                    // Debug vibrant voxel creation
                    if (m_DebugLog && GetColorStrength(splatColor) > 0.6f && m_VoxelGrid.Count % 500 == 0)
                        Debug.Log($"Created vibrant voxel at {worldPos}, color RGB({splatColor.r:F3}, {splatColor.g:F3}, {splatColor.b:F3})");
                    
                    if (m_VoxelMode == VoxelMode.GPUInstanced)
                    {
                        AppendGPUVoxel(voxel);
                    }
                    else if (!m_ActivateNearCameraOnly)
                    {
                        ActivateVoxel(voxel);
                    }
                }
                else
                {
                    var existing = m_VoxelGrid[gridPos];
                    existing.splatCount++;
                    
                    // Keep track of accumulated color for potential averaging
                    existing.accumulatedColor += splatColor;
                    
                    // Strategy: Use most vibrant color, but if similar strength, average them
                    float existingStrength = GetColorStrength(existing.color);
                    float newStrength = GetColorStrength(splatColor);
                    
                    bool shouldUpdate = false;
                    Color newColor = existing.color;
                    
                    if (newStrength > existingStrength * 1.2f)
                    {
                        // New color significantly more vibrant - replace
                        newColor = splatColor;
                        shouldUpdate = true;
                    }
                    else if (newStrength > existingStrength * 0.8f)
                    {
                        // Similar vibrancy - take average of accumulated colors weighted by strength
                        newColor = existing.accumulatedColor / existing.splatCount;
                        shouldUpdate = true;
                    }
                    
                    if (shouldUpdate)
                    {
                        existing.color = newColor;
                        
                        // Update visual immediately if already active
                        if (existing.cubeObject != null)
                        {
                            var renderer = existing.cubeObject.GetComponent<Renderer>();
                            if (renderer != null)
                                ApplyVoxelMaterial(renderer, newColor);
                        }
                        else if (existing.gpuIndex >= 0 && existing.gpuIndex < m_GPUVoxelCount)
                        {
                            m_GPUVoxelArray[existing.gpuIndex].color =
                                new Vector4(newColor.r, newColor.g, newColor.b, newColor.a);
                        }
                    }
                }
                
                m_BuildProgress++;
                voxelsBuilt++;
            }

            if (m_VoxelMode == VoxelMode.GPUInstanced)
                FlushProgressiveGPUVoxels();
            
            if (m_BuildProgress >= m_TotalSplatsToSample)
            {
                m_IsBuilding = false;
                m_RegisterUndo = false;
#if UNITY_EDITOR
                UnityEditor.EditorApplication.update -= EditorUpdate;
#endif
                
                if (m_DebugLog)
                {
                    Debug.Log($"Voxelization complete! {m_VoxelGrid.Count} voxels from {m_TotalSplatsToSample} splats");
                    
                    // Count colored voxels by type
                    int vibrantVoxels = 0;
                    int coloredVoxels = 0;
                    int whiteVoxels = 0;
                    int redVoxels = 0;
                    int greenVoxels = 0;
                    int blueVoxels = 0;
                    
                    foreach (var kvp in m_VoxelGrid)
                    {
                        Color c = kvp.Value.color;
                        float strength = GetColorStrength(c);
                        
                        if (strength > 0.6f)
                            vibrantVoxels++;
                        if (strength > 0.3f)
                            coloredVoxels++;
                        else if (c.r > 0.9f && c.g > 0.9f && c.b > 0.9f)
                            whiteVoxels++;
                            
                        // Count by dominant color
                        if (c.r > 0.5f && c.r > c.g * 1.5f && c.r > c.b * 1.5f)
                            redVoxels++;
                        if (c.g > 0.5f && c.g > c.r * 1.5f && c.g > c.b * 1.5f)
                            greenVoxels++;
                        if (c.b > 0.5f && c.b > c.r * 1.5f && c.b > c.g * 1.5f)
                            blueVoxels++;
                    }
                    Debug.Log($"Voxel colors - Vibrant: {vibrantVoxels}, Colored: {coloredVoxels}, White/gray: {whiteVoxels}");
                    Debug.Log($"Color breakdown - Red: {redVoxels}, Green: {greenVoxels}, Blue: {blueVoxels}");
                }
                
                if (m_HideSplatsWhenDone && m_SplatRenderer != null)
                {
                    m_SplatRenderer.gameObject.SetActive(false);
                }
                
                if (m_VoxelMode == VoxelMode.GPUInstanced)
                    FinalizeProgressiveGPUVoxels();
            }
            else if (m_DebugLog && m_BuildProgress % 5000 == 0)
            {
                float progress = GetBuildProgress();
                Debug.Log($"Progress: {progress:F1}% ({m_VoxelGrid.Count} voxels)");
            }
        }
        
        Vector3 GetSplatPositionAt(int splatIdx)
        {
            if (m_CachedPosData == null) return Vector3.zero;
            
            var asset = m_SplatRenderer.asset;
            return DecodeSplatPosition(m_CachedPosData, splatIdx, m_CachedPosInts, asset.posFormat, asset);
        }
        
        Color GetSplatColorAt(int splatIdx)
        {
            if (m_CachedColors == null)
            {
                if (m_DebugLog && splatIdx == 0)
                    Debug.LogWarning("m_CachedColors is null, returning white");
                return Color.white;
            }
            
            // The color texture uses 16x16 blocks with Morton encoding within each block
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatRenderer.splatCount);
            
            // Calculate block position (each block is 16x16 = 256 splats)
            int blockSize = 16;
            int splatsPerBlock = blockSize * blockSize; // 256
            int blocksPerRow = texWidth / blockSize;
            
            int blockIndex = splatIdx / splatsPerBlock;
            int localIndex = splatIdx % splatsPerBlock;
            
            int blockX = blockIndex % blocksPerRow;
            int blockY = blockIndex / blocksPerRow;
            
            // Morton decode the local index within the 16x16 block
            var localCoords = GaussianUtils.DecodeMorton2D_16x16((uint)localIndex);
            
            int x = blockX * blockSize + (int)localCoords.x;
            int y = blockY * blockSize + (int)localCoords.y;
            
            // Convert texture coordinates to array index
            int index = y * texWidth + x;
            
            if (index < 0 || index >= m_CachedColors.Length)
            {
                if (m_DebugLog && splatIdx % 1000 == 0)
                    Debug.LogWarning($"Color index {index} out of bounds for splat {splatIdx}, coords ({x},{y}), texSize ({texWidth},{texHeight}), arrayLen {m_CachedColors.Length}");
                return Color.white;
            }
            
            Color color = m_CachedColors[index];
            
            // Log vibrant colors for debugging
            if (m_DebugLog && splatIdx < 5)
                Debug.Log($"Splat {splatIdx}: block({blockX},{blockY}), local({localCoords.x},{localCoords.y}), final({x},{y}), index={index}, color RGB({color.r:F3}, {color.g:F3}, {color.b:F3})");
            
            return color;
        }

        float GetColorStrength(Color color)
        {
            // Calculate color strength based on saturation and brightness
            float max = Mathf.Max(color.r, Mathf.Max(color.g, color.b));
            float min = Mathf.Min(color.r, Mathf.Min(color.g, color.b));
            float saturation = (max > 0) ? (max - min) / max : 0f;
            float brightness = max;
            
            // Prioritize saturation heavily to preserve vibrant colors
            return saturation * 0.85f + brightness * 0.15f;
        }
        
        Material GetOrCreateDefaultMaterial()
        {
            // Validate existing material has a valid shader (not error shader)
            if (m_DefaultVoxelMaterial != null)
            {
                if (m_DefaultVoxelMaterial.shader != null && 
                    !m_DefaultVoxelMaterial.shader.name.Contains("Error") &&
                    !m_DefaultVoxelMaterial.shader.name.Contains("Hidden"))
                {
                    return m_DefaultVoxelMaterial;
                }
                // Invalid shader, destroy and recreate
                DestroyImmediate(m_DefaultVoxelMaterial);
                m_DefaultVoxelMaterial = null;
            }
            
            // Use VoxelColor shader - matches GPU shader lighting exactly
            var shader = Shader.Find("GaussianSplatting/VoxelColor");
            if (shader != null)
            {
                m_DefaultVoxelMaterial = new Material(shader);
                m_DefaultVoxelMaterial.name = "VoxelRuntimeMaterial";
                m_DefaultVoxelMaterial.enableInstancing = true;
                m_DefaultVoxelMaterial.SetColor("_Color", Color.white);
                m_DefaultVoxelMaterial.SetColor("_BaseColor", Color.white);
                
                if (m_DebugLog)
                    Debug.Log("Created VoxelRuntimeMaterial with VoxelColor shader");
                return m_DefaultVoxelMaterial;
            }
            
            // Fallback to URP shaders
            string[] fallbackShaders = new string[]
            {
                "Universal Render Pipeline/Lit",
                "Universal Render Pipeline/Simple Lit",
                "Standard"
            };
            
            foreach (var name in fallbackShaders)
            {
                shader = Shader.Find(name);
                if (shader != null)
                {
                    m_DefaultVoxelMaterial = new Material(shader);
                    m_DefaultVoxelMaterial.name = "VoxelRuntimeMaterial";
                    m_DefaultVoxelMaterial.enableInstancing = true;
                    if (m_DefaultVoxelMaterial.HasProperty("_Color"))
                        m_DefaultVoxelMaterial.SetColor("_Color", Color.white);
                    if (m_DefaultVoxelMaterial.HasProperty("_BaseColor"))
                        m_DefaultVoxelMaterial.SetColor("_BaseColor", Color.white);
                    
                    if (m_DebugLog)
                        Debug.Log($"Created VoxelRuntimeMaterial with fallback shader: {name}");
                    return m_DefaultVoxelMaterial;
                }
            }
            
            Debug.LogError("No compatible shader found! Please assign a Voxel Material in the inspector.");
            return null;
        }
        
        /// <summary>
        /// Gets the base material for creating voxel instances.
        /// Uses assigned material or creates default VoxelRuntimeMaterial.
        /// </summary>
        Material GetVoxelBaseMaterial()
        {
            if (m_VoxelMaterial != null && m_VoxelMaterial.shader != null)
                return m_VoxelMaterial;
            return GetOrCreateDefaultMaterial();
        }
        
        void ApplyVoxelMaterial(Renderer renderer, Color color)
        {
            Material baseMat = GetVoxelBaseMaterial();
            if (renderer == null || baseMat == null)
                return;

            renderer.enabled = true;
            renderer.forceRenderingOff = false;
            renderer.renderingLayerMask = uint.MaxValue;
            renderer.sharedMaterial = baseMat;
            renderer.shadowCastingMode = m_ShadowsOnly
                ? ShadowCastingMode.ShadowsOnly
                : (m_CastShadows ? ShadowCastingMode.On : ShadowCastingMode.Off);
            renderer.receiveShadows = m_ReceiveShadows && !m_ShadowsOnly;

            if (m_PropertyBlock == null)
                m_PropertyBlock = new MaterialPropertyBlock();

            m_PropertyBlock.Clear();
            m_PropertyBlock.SetColor("_Color", color);
            m_PropertyBlock.SetColor("_BaseColor", color);
            renderer.SetPropertyBlock(m_PropertyBlock);
        }
        
        int3 PositionToGrid(Vector3 position)
        {
            // Round to nearest grid cell instead of floor for better alignment
            return new int3(
                Mathf.RoundToInt(position.x / m_VoxelSize),
                Mathf.RoundToInt(position.y / m_VoxelSize),
                Mathf.RoundToInt(position.z / m_VoxelSize)
            );
        }
        
        Vector3 GridToPosition(int3 gridPos)
        {
            // Place voxel at grid cell center
            return new Vector3(
                gridPos.x * m_VoxelSize,
                gridPos.y * m_VoxelSize,
                gridPos.z * m_VoxelSize
            );
        }
        
        void UpdateVoxelActivation()
        {
            if (m_VoxelGrid.Count == 0)
                return;
            
            Camera cam = m_MainCamera;
            
            #if UNITY_EDITOR
            // Use scene view camera in editor
            if (cam == null && !Application.isPlaying)
            {
                var sceneView = UnityEditor.SceneView.lastActiveSceneView;
                if (sceneView != null && sceneView.camera != null)
                    cam = sceneView.camera;
            }
            #endif
            
            if (cam == null)
                return;
            
            Vector3 camPos = cam.transform.position;
            
            foreach (var kvp in m_VoxelGrid)
            {
                var voxel = kvp.Value;
                float distance = Vector3.Distance(camPos, voxel.worldPos);
                
                if (m_VoxelMode == VoxelMode.CPUGameObjects && m_ActivateNearCameraOnly)
                {
                    bool shouldBeActive = distance < m_ActivationRadius;
                    
                    if (shouldBeActive && voxel.cubeObject == null)
                    {
                        ActivateVoxel(voxel);
                    }
                    else if (!shouldBeActive && voxel.cubeObject != null)
                    {
                        DeactivateVoxel(voxel);
                    }
                }
                
            }
        }
        
        void ActivateVoxel(VoxelCube voxel)
        {
            if (voxel.cubeObject != null) return;
            
            // In GPUInstanced mode, don't create GameObjects at all
            if (m_VoxelMode == VoxelMode.GPUInstanced)
                return;
            
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.transform.position = voxel.worldPos;
            cube.transform.rotation = m_VoxelRotation;
            cube.transform.localScale = Vector3.Scale(Vector3.one * m_VoxelSize, m_VoxelScale);
            
            // Only set layer if not default (0)
            if (m_VoxelLayer > 0)
            {
                cube.layer = m_VoxelLayer;
                
                if (m_DebugLog && m_ActiveCubes.Count == 0)
                    Debug.Log($"Voxels assigned to layer {m_VoxelLayer} ({LayerMask.LayerToName(m_VoxelLayer)})");
            }
            
            if (m_VoxelContainer != null)
                cube.transform.SetParent(m_VoxelContainer.transform, true);
            
#if UNITY_EDITOR
            if (m_RegisterUndo)
            {
                Undo.RegisterCreatedObjectUndo(cube, "Create Voxel");
            }
#endif
            
            // Colliders are ALWAYS enabled for physical interaction
            var collider = cube.GetComponent<BoxCollider>();
            if (m_PhysicsMaterial != null)
                collider.material = m_PhysicsMaterial;
            
            collider.enabled = true;
            
            // Add Rigidbody immediately but keep it KINEMATIC (frozen) until triggered
            // This prevents the overhead of adding components at runtime
            var rb = cube.AddComponent<Rigidbody>();
            rb.mass = m_CubeMass;
            rb.isKinematic = true;  // FROZEN - won't fall or move
            rb.useGravity = false;
            rb.collisionDetectionMode = CollisionDetectionMode.Discrete;
            rb.interpolation = RigidbodyInterpolation.None;
            
            if (m_DebugLog && m_ActiveCubes.Count < 3)
                Debug.Log($"Voxel {m_ActiveCubes.Count}: Created with kinematic Rigidbody (frozen until triggered)");
            
            var renderer = cube.GetComponent<Renderer>();
            
            // Share one material and provide the splat color per renderer.
            ApplyVoxelMaterial(renderer, voxel.color);
            if (renderer.sharedMaterial != null)
            {
                float colorStrength = GetColorStrength(voxel.color);
                if (m_DebugLog && (m_ActiveCubes.Count < 3 || colorStrength > 0.6f))
                    Debug.Log($"Voxel {m_ActiveCubes.Count}: Applied color RGB({voxel.color.r:F3}, {voxel.color.g:F3}, {voxel.color.b:F3}), strength={colorStrength:F2}");
            }
            
            voxel.cubeObject = cube;
            voxel.hasPhysics = false;
            m_ActiveCubes.Add(cube);
        }
        
        void EnableVoxelPhysics(VoxelCube voxel)
        {
            if (voxel.cubeObject == null || voxel.hasPhysics) return;
            
            // Rigidbody already exists (added at creation), just unfreeze it
            var rb = voxel.cubeObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.isKinematic = false;  // UNFREEZE - now affected by physics
                rb.useGravity = true;
                rb.collisionDetectionMode = CollisionDetectionMode.Discrete;
                rb.interpolation = RigidbodyInterpolation.None;
                
                if (m_DebugLog)
                    Debug.Log($"Activated physics on voxel at {voxel.worldPos} - unfrozen and now dynamic");
            }
            else
            {
                // Fallback: Add rigidbody if it doesn't exist (shouldn't happen)
                rb = voxel.cubeObject.AddComponent<Rigidbody>();
                rb.mass = m_CubeMass;
                rb.useGravity = true;
                rb.isKinematic = false;
                rb.collisionDetectionMode = CollisionDetectionMode.Discrete;
                rb.interpolation = RigidbodyInterpolation.None;
                
                if (m_DebugLog)
                    Debug.LogWarning($"Had to add Rigidbody at runtime for voxel at {voxel.worldPos} - this shouldn't happen");
            }
            
            voxel.hasPhysics = true;
        }
        
        void DisableVoxelPhysics(VoxelCube voxel)
        {
            if (voxel.cubeObject == null) return;
            
            var rb = voxel.cubeObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                // Stop all motion immediately and freeze
                rb.isKinematic = true;  // FREEZE - stop physics simulation
                rb.useGravity = false;
                
                // Use velocity instead of linearVelocity for compatibility
                #if UNITY_2023_3_OR_NEWER
                rb.linearVelocity = Vector3.zero;
                #else
                rb.velocity = Vector3.zero;
                #endif
                
                rb.angularVelocity = Vector3.zero;
                
                // Keep the Rigidbody component but frozen (more efficient than destroying/recreating)
                if (m_DebugLog)
                    Debug.Log($"Froze Rigidbody on voxel at {voxel.worldPos} - now kinematic (frozen)");
            }
            
            // Collider stays enabled for physical interaction
            voxel.hasPhysics = false;
        }
        
        void DeactivateVoxel(VoxelCube voxel)
        {
            if (voxel.cubeObject != null)
            {
                m_ActiveCubes.Remove(voxel.cubeObject);
                DestroyObject(voxel.cubeObject);
                voxel.cubeObject = null;
                voxel.hasPhysics = false;
            }
        }
        
        void DestroyObject(GameObject obj)
        {
            if (Application.isPlaying)
            {
                Destroy(obj);
            }
            else
            {
#if UNITY_EDITOR
                Undo.DestroyObjectImmediate(obj);
#else
                DestroyImmediate(obj);
#endif
            }
        }
        
        Color[] ReadColorData(int texWidth, int texHeight)
        {
            var colorTex = m_SplatRenderer.GpuColorData;
            
            if (colorTex == null)
            {
                if (m_DebugLog)
                    Debug.LogWarning("GpuColorData is null");
                return null;
            }
            
            if (m_DebugLog)
                Debug.Log($"Reading color data from {colorTex.GetType().Name}, size: {texWidth}x{texHeight}, format: {colorTex.graphicsFormat}");
            
            if (colorTex is Texture2D tex2D)
            {
                try 
                {
                    if (!tex2D.isReadable)
                    {
                        if (m_DebugLog)
                            Debug.LogWarning("Texture2D is not readable, trying RenderTexture approach");
                        
                        // Use ARGBHalf or DefaultHDR to preserve color precision
                        RenderTexture rt = RenderTexture.GetTemporary(tex2D.width, tex2D.height, 0, RenderTextureFormat.ARGBHalf, RenderTextureReadWrite.Linear);
                        Graphics.Blit(tex2D, rt);
                        RenderTexture.active = rt;
                        var tempTex = new Texture2D(tex2D.width, tex2D.height, TextureFormat.RGBAFloat, false, true);
                        tempTex.ReadPixels(new Rect(0, 0, tex2D.width, tex2D.height), 0, 0);
                        tempTex.Apply();
                        RenderTexture.active = null;
                        RenderTexture.ReleaseTemporary(rt);
                        var pixels = tempTex.GetPixels();
                        
                        // Debug first few colors
                        if (m_DebugLog && pixels != null && pixels.Length > 0)
                        {
                            Debug.Log($"First 10 colors from texture: {pixels[0]}, {pixels[1]}, {pixels[2]}, {pixels[3]}, {pixels[4]}, {pixels[5]}, {pixels[6]}, {pixels[7]}, {pixels[8]}, {pixels[9]}");
                        }
                        
                        DestroyImmediate(tempTex);
                        return pixels;
                    }
                    var result = tex2D.GetPixels();
                    
                    // Debug first few colors
                    if (m_DebugLog && result != null && result.Length > 0)
                    {
                        Debug.Log($"First 10 colors from readable texture: {result[0]}, {result[1]}, {result[2]}, {result[3]}, {result[4]}");
                    }
                    
                    return result; 
                }
                catch (System.Exception e)
                {
                    if (m_DebugLog)
                        Debug.LogWarning($"Failed to read Texture2D: {e.Message}");
                    return null;
                }
            }
            else if (colorTex is RenderTexture rt)
            {
                try
                {
                    RenderTexture.active = rt;
                    var tempTex = new Texture2D(texWidth, texHeight, TextureFormat.RGBAFloat, false, true);
                    tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
                    tempTex.Apply();
                    RenderTexture.active = null;
                    var pixels = tempTex.GetPixels();
                    
                    // Debug first few colors
                    if (m_DebugLog && pixels != null && pixels.Length > 0)
                    {
                        Debug.Log($"First 10 colors from RenderTexture: {pixels[0]}, {pixels[1]}, {pixels[2]}, {pixels[3]}, {pixels[4]}");
                    }
                    
                    DestroyImmediate(tempTex);
                    return pixels;
                }
                catch (System.Exception e)
                {
                    if (m_DebugLog)
                        Debug.LogWarning($"Failed to read RenderTexture: {e.Message}");
                    return null;
                }
            }
            
            if (m_DebugLog)
                Debug.LogWarning($"Unknown texture type: {colorTex.GetType()}");
            
            return null;
        }
        
        Vector3 DecodeSplatPosition(uint[] posData, int splatIndex, int posInts, 
            GaussianSplatAsset.VectorFormat format, GaussianSplatAsset asset)
        {
            int offset = splatIndex * posInts;
            Vector3 decoded;

            switch (format)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    decoded = new Vector3(
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 1]), 0),
                        System.BitConverter.ToSingle(System.BitConverter.GetBytes(posData[offset + 2]), 0)
                    );
                    break;
                    
                case GaussianSplatAsset.VectorFormat.Norm16:
                    ushort x = (ushort)(posData[offset] & 0xFFFF);
                    ushort y = (ushort)((posData[offset] >> 16) & 0xFFFF);
                    ushort z = (ushort)(posData[offset + 1] & 0xFFFF);
                    
                    decoded = new Vector3(
                        x / 65535.0f,
                        y / 65535.0f,
                        z / 65535.0f
                    );
                    break;

                case GaussianSplatAsset.VectorFormat.Norm11:
                    uint packed = posData[offset];
                    uint packedX = packed & 0x7FFu;
                    uint packedY = (packed >> 11) & 0x3FFu;
                    uint packedZ = (packed >> 21) & 0x7FFu;

                    decoded = new Vector3(
                        packedX / 2047.0f,
                        packedY / 1023.0f,
                        packedZ / 2047.0f
                    );
                    break;
                    
                default:
                    return Vector3.zero;
            }

            int chunkIndex = splatIndex / GaussianSplatAsset.kChunkSize;
            if (m_CachedChunks != null && chunkIndex < m_CachedChunks.Length)
            {
                var chunk = m_CachedChunks[chunkIndex];
                return new Vector3(
                    Mathf.Lerp(chunk.posX.x, chunk.posX.y, decoded.x),
                    Mathf.Lerp(chunk.posY.x, chunk.posY.y, decoded.y),
                    Mathf.Lerp(chunk.posZ.x, chunk.posZ.y, decoded.z)
                );
            }

            // Unchunked Float32 positions are already in local model space.
            if (format == GaussianSplatAsset.VectorFormat.Float32)
                return decoded;

            // Compatibility fallback for older globally-normalized assets.
            return new Vector3(
                Mathf.Lerp(asset.boundsMin.x, asset.boundsMax.x, decoded.x),
                Mathf.Lerp(asset.boundsMin.y, asset.boundsMax.y, decoded.y),
                Mathf.Lerp(asset.boundsMin.z, asset.boundsMax.z, decoded.z)
            );
        }
        
        void ClearAll()
        {
            DisposeGPUBuffers();

            if (m_VoxelContainer != null)
            {
                if (Application.isPlaying)
                {
                    Destroy(m_VoxelContainer);
                }
                else
                {
#if UNITY_EDITOR
                    Undo.DestroyObjectImmediate(m_VoxelContainer);
#else
                    DestroyImmediate(m_VoxelContainer);
#endif
                }
                    
                m_VoxelContainer = null;
            }
            
            m_VoxelGrid.Clear();
            m_ActiveCubes.Clear();
            
            m_CachedPosData = null;
            m_CachedColors = null;
            m_CachedChunks = null;
        }
        
        public void DeleteVoxelWorld()
        {
            if (m_DebugLog)
                Debug.Log("Deleting voxel world...");
            
            m_IsBuilding = false;
            m_BuildProgress = 0;
            m_TotalSplatsToSample = 0;
            m_RegisterUndo = false;
#if UNITY_EDITOR
            UnityEditor.EditorApplication.update -= EditorUpdate;
#endif
            
            // Find container if reference is lost
            if (m_VoxelContainer == null)
            {
                var foundContainer = GameObject.Find("VoxelizedWorld");
                if (foundContainer != null)
                {
                    m_VoxelContainer = foundContainer;
                }
            }
            
            // Delete container and all its children
            if (m_VoxelContainer != null)
            {
                // Get all children before deletion
                Transform containerTransform = m_VoxelContainer.transform;
                var children = new List<GameObject>();
                for (int i = 0; i < containerTransform.childCount; i++)
                {
                    children.Add(containerTransform.GetChild(i).gameObject);
                }
                
                // Delete all children using DestroyImmediate to avoid undo stack overflow
                // The undo group is already set up in the editor, so we use DestroyImmediate
                // directly for bulk operations
                foreach (var child in children)
                {
                    if (child != null)
                    {
#if UNITY_EDITOR
                        if (Application.isPlaying)
                        {
                            Destroy(child);
                        }
                        else
                        {
                            DestroyImmediate(child);
                        }
#else
                        DestroyImmediate(child);
#endif
                    }
                }
                
                // Delete container itself
                if (Application.isPlaying)
                {
                    Destroy(m_VoxelContainer);
                }
                else
                {
#if UNITY_EDITOR
                    Undo.DestroyObjectImmediate(m_VoxelContainer);
#else
                    DestroyImmediate(m_VoxelContainer);
#endif
                }
                m_VoxelContainer = null;
                
                if (m_DebugLog)
                    Debug.Log("VoxelizedWorld container deleted");
            }
            else
            {
                if (m_DebugLog)
                    Debug.LogWarning("No VoxelizedWorld container found to delete");
            }
            
            // Clear voxel data
            m_VoxelGrid.Clear();
            m_ActiveCubes.Clear();
            
            // Clear cached data
            m_CachedPosData = null;
            m_CachedColors = null;
            m_CachedChunks = null;
            
            // Dispose GPU buffers
            DisposeGPUBuffers();
            
            System.GC.Collect();
            
            if (m_DebugLog)
                Debug.Log("Voxel world deleted and memory freed");
        }
        
        public void SetPhysicsEnabled(bool enabled)
        {
            m_EnablePhysics = enabled;
            ApplyCPUSelfCollisionSetting();

            if (!enabled)
            {
                CleanupAllPhysics();
                
                if (m_DebugLog)
                    Debug.Log("Voxel physics disabled");
            }
        }
        
        public void EnablePhysicsInRadius(Vector3 worldPosition, float radius)
        {
            if (!m_EnablePhysics)
                return;
            
            int enabledCount = 0;
            foreach (var kvp in m_VoxelGrid)
            {
                var voxel = kvp.Value;
                if (voxel.cubeObject != null)
                {
                    float distance = Vector3.Distance(worldPosition, voxel.worldPos);
                    if (distance < radius && !voxel.hasPhysics)
                    {
                        EnableVoxelPhysics(voxel);
                        enabledCount++;
                    }
                }
            }
            
            if (m_DebugLog && enabledCount > 0)
                Debug.Log($"Enabled physics for {enabledCount} voxels at position {worldPosition} with radius {radius}");
        }
        
        public void ApplyForceInRadius(Vector3 worldPosition, float radius, Vector3 force, ForceMode forceMode = ForceMode.Impulse)
        {
            if (!m_EnablePhysics)
                return;
            
            int affectedCount = 0;
            foreach (var kvp in m_VoxelGrid)
            {
                var voxel = kvp.Value;
                if (voxel.cubeObject != null)
                {
                    float distance = Vector3.Distance(worldPosition, voxel.worldPos);
                    if (distance < radius)
                    {
                        if (!voxel.hasPhysics)
                            EnableVoxelPhysics(voxel);
                        
                        var rb = voxel.cubeObject.GetComponent<Rigidbody>();
                        if (rb != null)
                        {
                            Vector3 direction = (voxel.worldPos - worldPosition).normalized;
                            float falloff = 1.0f - (distance / radius);
                            rb.AddForce(direction * force.magnitude * falloff, forceMode);
                            affectedCount++;
                        }
                    }
                }
            }
            
            if (m_DebugLog && affectedCount > 0)
                Debug.Log($"Applied force to {affectedCount} voxels");
        }

        public void ApplyVortexInCylinder(
            Vector3 center,
            Vector3 axis,
            float radius,
            float attractionRadius,
            float height,
            float strength,
            float driftSpeed,
            float liftSpeed,
            float floatiness)
        {
            if (!m_EnablePhysics || radius <= 0f || height <= 0f || strength <= 0f)
                return;

            axis = axis.sqrMagnitude > 0.0001f ? axis.normalized : Vector3.up;
            attractionRadius = Mathf.Max(radius, attractionRadius);

            if (m_VoxelMode == VoxelMode.GPUInstanced)
            {
                GPUVortexCylinder(
                    center,
                    axis,
                    radius,
                    attractionRadius,
                    height,
                    strength * Time.fixedDeltaTime,
                    driftSpeed,
                    liftSpeed,
                    floatiness);
                return;
            }

            float halfHeight = height * 0.5f;
            foreach (var pair in m_VoxelGrid)
            {
                var voxel = pair.Value;
                if (voxel.cubeObject == null)
                    continue;

                var rb = voxel.cubeObject.GetComponent<Rigidbody>();
                Vector3 position = rb != null ? rb.position : voxel.cubeObject.transform.position;
                Vector3 offset = position - center;
                float axialDistance = Vector3.Dot(offset, axis);
                Vector3 radialOffset = offset - axis * axialDistance;
                float radialDistance = radialOffset.magnitude;
                if (Mathf.Abs(axialDistance) > halfHeight || radialDistance > attractionRadius)
                    continue;

                if (!voxel.hasPhysics)
                    EnableVoxelPhysics(voxel);

                rb = voxel.cubeObject.GetComponent<Rigidbody>();
                if (rb == null)
                    continue;

                Vector3 radialDirection = radialDistance > 0.0001f
                    ? radialOffset / radialDistance
                    : Vector3.Cross(
                        axis,
                        Mathf.Abs(Vector3.Dot(axis, Vector3.up)) < 0.9f
                            ? Vector3.up
                            : Vector3.right).normalized;
                Vector3 tangent = Vector3.Cross(axis, radialDirection).normalized;
                float outsideDistance = Mathf.Max(0f, radialDistance - radius);
                float attractionWidth = Mathf.Max(0.001f, attractionRadius - radius);
                float falloff = 1f - Mathf.Clamp01(outsideDistance / attractionWidth);
                #if UNITY_2023_3_OR_NEWER
                Vector3 currentVelocity = rb.linearVelocity;
                #else
                Vector3 currentVelocity = rb.velocity;
                #endif
                float tangentialSpeed = Vector3.Dot(currentVelocity, tangent);
                float orbitAcceleration = (driftSpeed - tangentialSpeed) * strength;
                float orbitRadius = radius * 0.65f;
                float radialError = Mathf.Max(0f, radialDistance - orbitRadius);
                float inwardAcceleration = strength *
                                            (1f + radialError / Mathf.Max(radius, 0.001f)) *
                                            Mathf.Max(1f, Mathf.Abs(driftSpeed) * 0.25f);
                float axialSpeed = Vector3.Dot(currentVelocity, axis);
                float liftAcceleration = (liftSpeed - axialSpeed) * strength;
                Vector3 vortexAcceleration =
                    (tangent * orbitAcceleration -
                     radialDirection * inwardAcceleration +
                     axis * liftAcceleration) * falloff -
                    Physics.gravity * Mathf.Clamp01(floatiness) * falloff;
                rb.AddForce(vortexAcceleration, ForceMode.Acceleration);
            }
        }
        
        public int GetTotalVoxels() => m_VoxelGrid.Count;
        public int GetActiveVoxels() => m_ActiveCubes.Count;
        public int GetTotalChunks() => GetTotalVoxels();
        public int GetActiveChunks() => GetActiveVoxels();
        public int GetTotalCubes() => GetTotalVoxels();
        public int GetActiveCubes() => GetActiveVoxels();
        public int GetPhysicsVoxelCount()
        {
            int count = 0;
            foreach (var kvp in m_VoxelGrid)
            {
                if (kvp.Value.hasPhysics) count++;
            }
            return count;
        }
        
        public int GetVoxelLayer() => m_VoxelLayer;
        public void SetVoxelLayer(int layer)
        {
            m_VoxelLayer = layer;
            ApplyCPUSelfCollisionSetting();
            
            // Update existing voxels
            foreach (var kvp in m_VoxelGrid)
            {
                if (kvp.Value.cubeObject != null)
                {
                    kvp.Value.cubeObject.layer = layer;
                }
            }
        }

        void ApplyCPUSelfCollisionSetting()
        {
            if (m_VoxelMode != VoxelMode.CPUGameObjects)
                return;

            if (m_VoxelLayer <= 0)
            {
                if (!m_EnableSelfCollision && m_DebugLog)
                    Debug.LogWarning("Disabling CPU voxel self-collision requires a dedicated non-Default Voxel Layer.");
                return;
            }

            Physics.IgnoreLayerCollision(m_VoxelLayer, m_VoxelLayer, !m_EnableSelfCollision);
        }
        
        public bool IsBuilding() => m_IsBuilding;
        public float GetBuildProgress()
        {
            if (m_TotalSplatsToSample == 0) return 100f;
            return (float)m_BuildProgress / (float)m_TotalSplatsToSample * 100f;
        }
        
        public void ActivateAllChunks()
        {
            bool wasRegisteringUndo = m_RegisterUndo;
            
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                m_RegisterUndo = true;
                Undo.IncrementCurrentGroup();
                Undo.SetCurrentGroupName("Activate All Voxels");
            }
#endif
            
            foreach (var kvp in m_VoxelGrid)
            {
                ActivateVoxel(kvp.Value);
            }
            
            m_RegisterUndo = wasRegisteringUndo;
            
            if (m_DebugLog)
                Debug.Log($"Activated all {m_VoxelGrid.Count} voxels");
        }
        
        public void DeactivateAllChunks()
        {
            foreach (var kvp in m_VoxelGrid)
            {
                DeactivateVoxel(kvp.Value);
            }
            
            if (m_DebugLog)
                Debug.Log("Deactivated all voxels");
        }
        
        // void OnDrawGizmos()
        // {
        //     if (!m_ShowGizmos) return;
            
        //     foreach (var kvp in m_VoxelGrid)
        //     {
        //         var voxel = kvp.Value;
        //         if (voxel.cubeObject != null)
        //         {
        //             if (voxel.hasPhysics)
        //             {
        //                 Gizmos.color = Color.red;
        //                 Gizmos.DrawWireCube(voxel.worldPos, Vector3.one * m_VoxelSize);
        //             }
        //             else
        //             {
        //                 Gizmos.color = Color.green;
        //                 Gizmos.DrawWireCube(voxel.worldPos, Vector3.one * m_VoxelSize * 0.8f);
        //             }
        //         }
        //     }
            
        //     if (m_MainCamera != null)
        //     {
        //         Gizmos.color = Color.yellow;
        //         Gizmos.DrawWireSphere(m_MainCamera.transform.position, m_ActivationRadius);
                
        //     }
        // }
        
        #region GPU Methods
        
        void UpdateGPUVoxelActivation()
        {
            if (m_GPUVoxelBuffer == null || m_GPUVoxelCount <= 0 ||
                m_VoxelCompute == null || m_KernelActivate < 0)
                return;
            
            Camera cam = m_MainCamera;
            
            #if UNITY_EDITOR
            // Use scene view camera in editor
            if (cam == null && !Application.isPlaying)
            {
                var sceneView = UnityEditor.SceneView.lastActiveSceneView;
                if (sceneView != null && sceneView.camera != null)
                    cam = sceneView.camera;
            }
            #endif
            
            if (cam == null)
                return;
            
            Vector3 camPos = cam.transform.position;
            
            m_VoxelCompute.SetBuffer(m_KernelActivate, "_VoxelBuffer", m_GPUVoxelBuffer);
            m_VoxelCompute.SetInt("_VoxelCount", m_GPUVoxelCount);
            m_VoxelCompute.SetVector("_CameraPosition", camPos);
            m_VoxelCompute.SetFloat("_ActivationRadius", m_ActivationRadius);
            
            int threadGroups = (m_GPUVoxelCount + 255) / 256;
            m_VoxelCompute.Dispatch(m_KernelActivate, threadGroups, 1, 1);
        }
        
        void RenderGPUVoxels()
        {
            if (m_GPUVoxelBuffer == null || m_CubeMesh == null || m_ArgsBuffer == null)
                return;
            
            // Ensure we have a valid GPU material
            Material gpuMat = GetOrCreateGPUMaterial();
            if (gpuMat == null)
                return;
            
            m_PropertyBlock.SetBuffer("_VoxelBuffer", m_GPUVoxelBuffer);
            m_PropertyBlock.SetFloat("_LightMultiplier", Mathf.Max(0f, m_LightMultiplier));
            m_PropertyBlock.SetFloat("_ShadowSizeMultiplier", Mathf.Max(0.01f, m_ShadowSizeMultiplier));
            
            ShadowCastingMode shadowMode = m_ShadowsOnly
                ? ShadowCastingMode.ShadowsOnly
                : (m_CastShadows ? ShadowCastingMode.On : ShadowCastingMode.Off);
            
            Graphics.DrawMeshInstancedIndirect(
                m_CubeMesh,
                0,
                gpuMat,
                new Bounds(Vector3.zero, Vector3.one * 10000),
                m_ArgsBuffer,
                0,
                m_PropertyBlock,
                shadowMode,
                m_ReceiveShadows
            );
        }
        
        Material GetOrCreateGPUMaterial()
        {
            // Return cached GPU material if valid
            if (m_GPUVoxelMaterial != null && m_GPUVoxelMaterial.shader != null &&
                m_GPUVoxelMaterial.shader.name.Contains("Voxel GPU Instanced"))
            {
                return m_GPUVoxelMaterial;
            }
            
            // Create GPU shader material (matches lighting of VoxelColor shader)
            var shader = Shader.Find("GaussianSplatting/Voxel GPU Instanced");
            if (shader != null)
            {
                m_GPUVoxelMaterial = new Material(shader);
                m_GPUVoxelMaterial.name = "VoxelGPUMaterial_Runtime";
                
                // Copy properties from voxel material if available
                if (m_VoxelMaterial != null)
                {
                    if (m_VoxelMaterial.HasProperty("_Color"))
                        m_GPUVoxelMaterial.SetColor("_Color", m_VoxelMaterial.GetColor("_Color"));
                }
                
                if (m_DebugLog)
                    Debug.Log("Created GPU voxel material (lighting matches GameObject material)");
                return m_GPUVoxelMaterial;
            }
            
            if (m_DebugLog)
                Debug.LogWarning("Cannot find 'GaussianSplatting/Voxel GPU Instanced' shader for GPU rendering");
            
            return null;
        }
        
        int GPUVoxelStride =>
            sizeof(float) * 3 + sizeof(float) * 4 + sizeof(float) +
            sizeof(uint) + sizeof(float) * 3 + sizeof(uint);

        void CreateProgressiveGPUBuffers(int capacity)
        {
            DisposeGPUBuffers();

            m_GPUVoxelCapacity = Mathf.Max(1, capacity);
            m_GPUVoxelCount = 0;
            m_GPUUploadedCount = 0;
            m_GPUVoxelArray = new GPUVoxelData[m_GPUVoxelCapacity];
            m_GPUVoxelBuffer = new ComputeBuffer(m_GPUVoxelCapacity, GPUVoxelStride);

            uint[] args =
            {
                m_CubeMesh.GetIndexCount(0),
                0,
                m_CubeMesh.GetIndexStart(0),
                m_CubeMesh.GetBaseVertex(0),
                0
            };
            m_ArgsBuffer = new ComputeBuffer(1, args.Length * sizeof(uint), ComputeBufferType.IndirectArguments);
            m_ArgsBuffer.SetData(args);
        }

        void AppendGPUVoxel(VoxelCube voxel)
        {
            if (m_GPUVoxelArray == null || m_GPUVoxelCount >= m_GPUVoxelCapacity)
                return;

            voxel.gpuIndex = m_GPUVoxelCount;
            m_GPUVoxelArray[m_GPUVoxelCount] = new GPUVoxelData
            {
                position = voxel.worldPos,
                color = new Vector4(voxel.color.r, voxel.color.g, voxel.color.b, voxel.color.a),
                size = m_VoxelSize,
                active = 1,
                velocity = Vector3.zero,
                dynamic = 0
            };
            m_GPUVoxelCount++;
        }

        void FlushProgressiveGPUVoxels()
        {
            if (m_GPUVoxelBuffer == null || m_ArgsBuffer == null ||
                m_GPUUploadedCount >= m_GPUVoxelCount)
                return;

            int uploadCount = m_GPUVoxelCount - m_GPUUploadedCount;
            m_GPUVoxelBuffer.SetData(
                m_GPUVoxelArray,
                m_GPUUploadedCount,
                m_GPUUploadedCount,
                uploadCount);
            m_GPUUploadedCount = m_GPUVoxelCount;
            UpdateGPUArgsCount();
        }

        void FinalizeProgressiveGPUVoxels()
        {
            if (m_GPUVoxelBuffer == null || m_GPUVoxelCount == 0)
                return;

            // Upload all entries once so color changes to previously-created voxels are included.
            m_GPUVoxelBuffer.SetData(m_GPUVoxelArray, 0, 0, m_GPUVoxelCount);
            m_GPUUploadedCount = m_GPUVoxelCount;
            UpdateGPUArgsCount();
            
            if (m_DebugLog)
                Debug.Log($"GPU buffers created for {m_GPUVoxelCount} voxels");
        }

        void UpdateGPUArgsCount()
        {
            uint[] args =
            {
                m_CubeMesh.GetIndexCount(0),
                (uint)m_GPUVoxelCount,
                m_CubeMesh.GetIndexStart(0),
                m_CubeMesh.GetBaseVertex(0),
                0
            };
            m_ArgsBuffer.SetData(args);
        }

        void CreateGPUBuffers()
        {
            if (m_VoxelGrid.Count == 0)
                return;

            CreateProgressiveGPUBuffers(m_VoxelGrid.Count);
            foreach (var pair in m_VoxelGrid)
                AppendGPUVoxel(pair.Value);
            FinalizeProgressiveGPUVoxels();
        }
        
        public void GPUCollisionSphere(Vector3 center, float radius, Vector3 velocity, float forceMagnitude, ForceMode forceMode)
        {
            if (!m_EnablePhysics || m_VoxelMode != VoxelMode.GPUInstanced || m_PhysicsCompute == null ||
                m_GPUVoxelBuffer == null || m_GPUVoxelCount <= 0 || m_KernelApplyGPUForce < 0)
                return;

            int threadGroups = (m_GPUVoxelCount + 255) / 256;
            m_PhysicsCompute.SetBuffer(m_KernelApplyGPUForce, "_VoxelBuffer", m_GPUVoxelBuffer);
            m_PhysicsCompute.SetInt("_VoxelCount", m_GPUVoxelCount);
            m_PhysicsCompute.SetVector("_CollisionCenter", center);
            m_PhysicsCompute.SetFloat("_CollisionRadius", Mathf.Max(0.001f, radius));
            m_PhysicsCompute.SetVector("_ForceDirection", velocity);
            m_PhysicsCompute.SetFloat("_ForceMultiplier", forceMagnitude);
            m_PhysicsCompute.Dispatch(m_KernelApplyGPUForce, threadGroups, 1, 1);
        }

        void GPUVortexCylinder(
            Vector3 center,
            Vector3 axis,
            float radius,
            float attractionRadius,
            float height,
            float strength,
            float driftSpeed,
            float liftSpeed,
            float floatiness)
        {
            if (m_PhysicsCompute == null || m_GPUVoxelBuffer == null ||
                m_GPUVoxelCount <= 0 || m_KernelApplyGPUVortex < 0)
                return;

            int threadGroups = (m_GPUVoxelCount + 255) / 256;
            m_PhysicsCompute.SetBuffer(m_KernelApplyGPUVortex, "_VoxelBuffer", m_GPUVoxelBuffer);
            m_PhysicsCompute.SetInt("_VoxelCount", m_GPUVoxelCount);
            m_PhysicsCompute.SetVector("_VortexCenter", center);
            m_PhysicsCompute.SetVector("_VortexAxis", axis);
            m_PhysicsCompute.SetFloat("_VortexRadius", Mathf.Max(0.001f, radius));
            m_PhysicsCompute.SetFloat("_VortexAttractionRadius", Mathf.Max(radius, attractionRadius));
            m_PhysicsCompute.SetFloat("_VortexHeight", Mathf.Max(0.001f, height));
            m_PhysicsCompute.SetFloat("_VortexStrength", strength);
            m_PhysicsCompute.SetFloat("_VortexDriftSpeed", driftSpeed);
            m_PhysicsCompute.SetFloat("_VortexLiftSpeed", liftSpeed);
            m_PhysicsCompute.SetVector(
                "_VortexGravityCompensation",
                -Physics.gravity * Mathf.Clamp01(floatiness) * Time.fixedDeltaTime);
            m_PhysicsCompute.Dispatch(m_KernelApplyGPUVortex, threadGroups, 1, 1);
        }

        void SimulateGPUPhysics(float deltaTime)
        {
            if (m_PhysicsCompute == null || m_GPUVoxelBuffer == null ||
                m_GPUVoxelCount <= 0 || m_KernelSimulateGPU < 0 || deltaTime <= 0f)
                return;

            m_PhysicsCompute.SetBuffer(m_KernelSimulateGPU, "_VoxelBuffer", m_GPUVoxelBuffer);
            m_PhysicsCompute.SetInt("_VoxelCount", m_GPUVoxelCount);
            m_PhysicsCompute.SetFloat("_DeltaTime", Mathf.Min(deltaTime, 0.05f));
            m_PhysicsCompute.SetVector("_Gravity", Physics.gravity);
            m_PhysicsCompute.SetFloat("_Damping", 0.995f);

            bool useCollisionBox = m_CollisionBox != null &&
                                   m_CollisionBox.enabled &&
                                   m_CollisionBox.gameObject.activeInHierarchy;
            m_PhysicsCompute.SetInt("_UseCollisionBox", useCollisionBox ? 1 : 0);
            if (useCollisionBox)
            {
                Bounds bounds = m_CollisionBox.bounds;
                m_PhysicsCompute.SetVector("_CollisionBoxMin", bounds.min);
                m_PhysicsCompute.SetVector("_CollisionBoxMax", bounds.max);
            }

            m_PhysicsCompute.Dispatch(m_KernelSimulateGPU, (m_GPUVoxelCount + 255) / 256, 1, 1);

            if (m_EnableSelfCollision && m_KernelResolveGPUCollisions >= 0)
            {
                m_PhysicsCompute.SetBuffer(m_KernelResolveGPUCollisions, "_VoxelBuffer", m_GPUVoxelBuffer);
                m_PhysicsCompute.SetInt("_VoxelCount", m_GPUVoxelCount);
                m_PhysicsCompute.SetInt("_SelfCollisionNeighborRange", 12);
                m_PhysicsCompute.SetFloat("_SelfCollisionStrength", 0.65f);
                m_PhysicsCompute.Dispatch(
                    m_KernelResolveGPUCollisions,
                    (m_GPUVoxelCount + 255) / 256,
                    1,
                    1);
            }
        }

        public void InteractWithVoxels(Vector3 center, float radius, Vector3 direction, float forceMagnitude, ForceMode forceMode)
        {
            if (!m_EnablePhysics)
                return;

            if (m_VoxelMode == VoxelMode.GPUInstanced)
            {
                GPUCollisionSphere(center, radius, direction, forceMagnitude, forceMode);
                return;
            }

            if (forceMagnitude > 0f)
                ApplyForceInRadius(center, radius, direction.normalized * forceMagnitude, forceMode);
            else
                EnablePhysicsInRadius(center, radius);
        }
        
        public int GetGPUVoxelCount() => m_GPUVoxelCount;
        public VoxelMode GetVoxelMode() => m_VoxelMode;
        public void SetVoxelMode(VoxelMode mode)
        {
            m_VoxelMode = mode;
            if (mode == VoxelMode.GPUInstanced && m_GPUVoxelBuffer == null && m_VoxelGrid.Count > 0)
            {
                CreateGPUBuffers();
            }
        }
        
        #endregion
    }
}
