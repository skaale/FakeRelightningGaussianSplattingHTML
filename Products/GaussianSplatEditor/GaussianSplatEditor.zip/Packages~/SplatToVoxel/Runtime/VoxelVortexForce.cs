// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    [AddComponentMenu("Gaussian Splatting/Voxel Vortex Force")]
    public class VoxelVortexForce : MonoBehaviour
    {
        [SerializeField] private GaussianSplatVoxelizerSimple m_Voxelizer;
        [SerializeField, Min(0.01f)] private float m_Radius = 2f;
        [SerializeField, Min(0.01f), Tooltip("Outer radius that attracts nearby voxels into the vortex.")]
        private float m_AttractionRadius = 5f;
        [SerializeField, Min(0.01f)] private float m_Height = 4f;
        [SerializeField, Min(0f), Tooltip("Target tangential velocity around the cylinder in metres per second.")]
        private float m_DriftSpeed = 3f;
        [SerializeField, Tooltip("Target upward velocity while inside the vortex. Set to 0 to orbit at the current height.")]
        private float m_LiftSpeed = 0.75f;
        [SerializeField, Range(0f, 1f), Tooltip("Gravity reduction inside the vortex. 1 makes voxels nearly weightless; 0 uses full gravity.")]
        private float m_Floatiness = 0.9f;
        [SerializeField, Min(0f), Tooltip("How quickly voxels accelerate toward the drift speed and cylinder flow.")]
        private float m_Strength = 10f;
        [SerializeField] private bool m_Clockwise;

        public float Radius => m_Radius;
        public float Height => m_Height;

        void Reset()
        {
            m_Voxelizer = FindAnyObjectByType<GaussianSplatVoxelizerSimple>();

            Vector3 scale = transform.lossyScale;
            m_Radius = Mathf.Max(0.01f, Mathf.Max(Mathf.Abs(scale.x), Mathf.Abs(scale.z)) * 0.5f);
            m_Height = Mathf.Max(0.01f, Mathf.Abs(scale.y) * 2f);
        }

        void FixedUpdate()
        {
            if (m_Voxelizer == null)
                m_Voxelizer = FindAnyObjectByType<GaussianSplatVoxelizerSimple>();

            if (m_Voxelizer == null)
                return;

            float signedDriftSpeed = m_Clockwise ? -m_DriftSpeed : m_DriftSpeed;
            m_Voxelizer.ApplyVortexInCylinder(
                transform.position,
                transform.up,
                m_Radius,
                Mathf.Max(m_Radius, m_AttractionRadius),
                m_Height,
                m_Strength,
                signedDriftSpeed,
                m_LiftSpeed,
                m_Floatiness);
        }

        void OnDrawGizmosSelected()
        {
            const int segments = 32;
            Vector3 axis = transform.up.normalized;
            Vector3 right = transform.right.normalized;
            Vector3 forward = transform.forward.normalized;
            Vector3 topCenter = transform.position + axis * (m_Height * 0.5f);
            Vector3 bottomCenter = transform.position - axis * (m_Height * 0.5f);

            Gizmos.color = new Color(0.2f, 0.75f, 1f, 0.9f);
            for (int i = 0; i < segments; i++)
            {
                float angleA = i * Mathf.PI * 2f / segments;
                float angleB = (i + 1) * Mathf.PI * 2f / segments;
                Vector3 radialA = (right * Mathf.Cos(angleA) + forward * Mathf.Sin(angleA)) * m_Radius;
                Vector3 radialB = (right * Mathf.Cos(angleB) + forward * Mathf.Sin(angleB)) * m_Radius;
                Gizmos.DrawLine(topCenter + radialA, topCenter + radialB);
                Gizmos.DrawLine(bottomCenter + radialA, bottomCenter + radialB);

                if (i % 8 == 0)
                    Gizmos.DrawLine(bottomCenter + radialA, topCenter + radialA);
            }

            Gizmos.color = new Color(0.2f, 0.75f, 1f, 0.35f);
            for (int i = 0; i < segments; i++)
            {
                float angleA = i * Mathf.PI * 2f / segments;
                float angleB = (i + 1) * Mathf.PI * 2f / segments;
                Vector3 pointA = transform.position +
                                 (right * Mathf.Cos(angleA) + forward * Mathf.Sin(angleA)) * m_AttractionRadius;
                Vector3 pointB = transform.position +
                                 (right * Mathf.Cos(angleB) + forward * Mathf.Sin(angleB)) * m_AttractionRadius;
                Gizmos.DrawLine(pointA, pointB);
            }
        }
    }
}
