// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public enum DetectionMode
    {
        Trigger,
        Collision
    }

    [DisallowMultipleComponent]
    public class VoxelPhysicsTrigger : MonoBehaviour
    {
        [Header("Target")]
        [SerializeField] private GaussianSplatVoxelizerSimple m_Voxelizer;

        [Header("Detection")]
        [SerializeField] private DetectionMode m_DetectionMode = DetectionMode.Collision;
        [SerializeField] private LayerMask m_AcceptLayers = ~0;
        [SerializeField] private float m_ActivationRadius = 1.0f;
        [SerializeField] private bool m_ContinuousActivation = true;
        [SerializeField, Min(0)] private int m_ActivationCheckInterval;

        [Header("Force")]
        [SerializeField] private bool m_ApplyPushForce = true;
        [SerializeField, Min(0f)] private float m_PushForce = 5.0f;
        [SerializeField] private ForceMode m_ForceMode = ForceMode.Impulse;

        [Header("Debug")]
        [SerializeField] private bool m_DebugLog;

        private Collider m_Collider;
        private Rigidbody m_Rigidbody;
        private Vector3 m_LastPosition;
        private int m_FrameCounter;

        void Awake()
        {
            Initialize();
        }

        void OnEnable()
        {
            Initialize();
            m_LastPosition = transform.position;
        }

        void Initialize()
        {
            if (m_Voxelizer == null)
                m_Voxelizer = FindAnyObjectByType<GaussianSplatVoxelizerSimple>();

            m_Collider = GetComponent<Collider>();
            if (m_Collider == null)
                m_Collider = gameObject.AddComponent<SphereCollider>();

            m_Collider.isTrigger = m_DetectionMode == DetectionMode.Trigger;
            m_Rigidbody = GetComponent<Rigidbody>();
        }

        void Update()
        {
            if (!m_ContinuousActivation || m_Voxelizer == null)
                return;

            m_FrameCounter++;
            if (m_ActivationCheckInterval > 0 &&
                m_FrameCounter % (m_ActivationCheckInterval + 1) != 0)
                return;

            Vector3 delta = transform.position - m_LastPosition;
            m_LastPosition = transform.position;
            if (delta.sqrMagnitude <= 0.000001f)
                return;

            Interact(transform.position, delta / Mathf.Max(Time.deltaTime, 0.0001f));
        }

        void OnTriggerEnter(Collider other)
        {
            if (m_DetectionMode == DetectionMode.Trigger && Accepts(other.gameObject.layer))
                Interact(other.ClosestPoint(transform.position), GetVelocity());
        }

        void OnTriggerStay(Collider other)
        {
            if (m_DetectionMode == DetectionMode.Trigger && m_ContinuousActivation &&
                Accepts(other.gameObject.layer))
                Interact(other.ClosestPoint(transform.position), GetVelocity());
        }

        void OnCollisionEnter(Collision collision)
        {
            if (m_DetectionMode != DetectionMode.Collision ||
                !Accepts(collision.gameObject.layer))
                return;

            Vector3 point = collision.contactCount > 0
                ? collision.GetContact(0).point
                : transform.position;
            Interact(point, GetVelocity());
        }

        void OnCollisionStay(Collision collision)
        {
            if (!m_ContinuousActivation || m_DetectionMode != DetectionMode.Collision ||
                !Accepts(collision.gameObject.layer))
                return;

            Vector3 point = collision.contactCount > 0
                ? collision.GetContact(0).point
                : transform.position;
            Interact(point, GetVelocity());
        }

        bool Accepts(int layer)
        {
            return (m_AcceptLayers.value & (1 << layer)) != 0;
        }

        Vector3 GetVelocity()
        {
            if (m_Rigidbody == null)
                return transform.forward;
#if UNITY_6000_0_OR_NEWER || UNITY_2023_3_OR_NEWER
            return m_Rigidbody.linearVelocity;
#else
            return m_Rigidbody.velocity;
#endif
        }

        void Interact(Vector3 center, Vector3 velocity)
        {
            if (m_Voxelizer == null)
                return;

            float force = m_ApplyPushForce ? m_PushForce : 0f;
            m_Voxelizer.InteractWithVoxels(
                center,
                Mathf.Max(0.01f, m_ActivationRadius),
                velocity,
                force,
                m_ForceMode);

            if (m_DebugLog)
                Debug.Log($"Voxel interaction ({m_Voxelizer.GetVoxelMode()}) at {center}", this);
        }

        public void SetVoxelizer(GaussianSplatVoxelizerSimple voxelizer)
        {
            m_Voxelizer = voxelizer;
        }

        public void SetActivationRadius(float radius)
        {
            m_ActivationRadius = Mathf.Max(0.01f, radius);
        }
    }
}
