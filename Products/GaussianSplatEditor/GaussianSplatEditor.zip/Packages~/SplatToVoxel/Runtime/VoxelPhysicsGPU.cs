// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Optional scripting adapter for GPU voxel interactions.
    /// VoxelPhysicsTrigger talks directly to the voxelizer and does not require this component.
    /// </summary>
    [DisallowMultipleComponent]
    public class VoxelPhysicsGPU : MonoBehaviour
    {
        [SerializeField] private GaussianSplatVoxelizerSimple m_Voxelizer;
        [SerializeField] private bool m_DebugLog;

        public bool IsInitialized =>
            m_Voxelizer != null &&
            m_Voxelizer.GetVoxelMode() == GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced &&
            m_Voxelizer.GetGPUVoxelCount() > 0;

        void Awake()
        {
            if (m_Voxelizer == null)
                m_Voxelizer = FindAnyObjectByType<GaussianSplatVoxelizerSimple>();
        }

        public void InitializeFromVoxelizer(GaussianSplatVoxelizerSimple voxelizer)
        {
            m_Voxelizer = voxelizer;
        }

        public void Reinitialize()
        {
            if (m_Voxelizer == null)
                m_Voxelizer = FindAnyObjectByType<GaussianSplatVoxelizerSimple>();
        }

        public void DetectCollisionSphere(
            Vector3 center,
            float radius,
            Vector3 velocity,
            float forceMagnitude,
            ForceMode forceMode,
            bool enablePhysicsOnly = false)
        {
            if (!IsInitialized)
                return;

            m_Voxelizer.InteractWithVoxels(
                center,
                radius,
                velocity,
                enablePhysicsOnly ? 0f : forceMagnitude,
                forceMode);

            if (m_DebugLog)
                Debug.Log($"GPU voxel interaction at {center}, radius {radius}", this);
        }

        public void DetectCollisionBox(
            Vector3 center,
            Vector3 extents,
            Quaternion rotation,
            Vector3 velocity,
            float forceMagnitude,
            ForceMode forceMode,
            bool enablePhysicsOnly = false)
        {
            DetectCollisionSphere(
                center,
                extents.magnitude,
                velocity,
                forceMagnitude,
                forceMode,
                enablePhysicsOnly);
        }

        public void DetectCollisionCapsule(
            Vector3 center,
            float height,
            float radius,
            Vector3 velocity,
            float forceMagnitude,
            ForceMode forceMode,
            bool enablePhysicsOnly = false)
        {
            DetectCollisionSphere(
                center,
                radius + height * 0.5f,
                velocity,
                forceMagnitude,
                forceMode,
                enablePhysicsOnly);
        }

        public void UpdatePhysicsStates()
        {
            // GPU state lives entirely in the voxel compute buffer.
        }

        public void SetVoxelizer(GaussianSplatVoxelizerSimple voxelizer) => m_Voxelizer = voxelizer;
        public void SetDebugLog(bool debug) => m_DebugLog = debug;
    }
}
