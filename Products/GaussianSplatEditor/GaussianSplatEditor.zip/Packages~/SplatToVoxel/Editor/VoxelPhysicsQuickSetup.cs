// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    public static class VoxelPhysicsQuickSetup
    {
        [MenuItem("GameObject/Gaussian Splatting/Setup Voxel Physics Trigger", false, 0)]
        static void Setup()
        {
            GameObject target = Selection.activeGameObject;
            if (target == null)
                return;

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Setup Voxel Physics Trigger");

            var trigger = target.GetComponent<VoxelPhysicsTrigger>();
            if (trigger == null)
                trigger = Undo.AddComponent<VoxelPhysicsTrigger>(target);

            var voxelizer = Object.FindAnyObjectByType<GaussianSplatVoxelizerSimple>();
            if (voxelizer != null)
            {
                var serializedTrigger = new SerializedObject(trigger);
                serializedTrigger.FindProperty("m_Voxelizer").objectReferenceValue = voxelizer;
                serializedTrigger.ApplyModifiedProperties();

                var serializedVoxelizer = new SerializedObject(voxelizer);
                serializedVoxelizer.FindProperty("m_EnablePhysics").boolValue = true;
                serializedVoxelizer.ApplyModifiedProperties();
            }

            if (target.GetComponent<Collider>() == null)
                Undo.AddComponent<SphereCollider>(target);

            if (target.GetComponent<Rigidbody>() == null)
            {
                var body = Undo.AddComponent<Rigidbody>(target);
                body.mass = 1f;
                body.collisionDetectionMode = CollisionDetectionMode.Continuous;
            }

            EditorUtility.SetDirty(target);
            Selection.activeGameObject = target;
        }

        [MenuItem("GameObject/Gaussian Splatting/Setup Voxel Physics Trigger", true)]
        static bool ValidateSetup()
        {
            return Selection.activeGameObject != null;
        }
    }
}
#endif
