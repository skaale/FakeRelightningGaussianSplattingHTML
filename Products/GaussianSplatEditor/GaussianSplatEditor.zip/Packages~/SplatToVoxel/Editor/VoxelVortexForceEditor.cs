// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(VoxelVortexForce))]
    public class VoxelVortexForceEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            var vortex = (VoxelVortexForce)target;
            if (GUILayout.Button("Fit Cylinder Primitive To Vortex"))
            {
                Undo.RecordObject(vortex.transform, "Fit Vortex Cylinder");
                vortex.transform.localScale = new Vector3(
                    vortex.Radius * 2f,
                    vortex.Height * 0.5f,
                    vortex.Radius * 2f);
                EditorUtility.SetDirty(vortex.transform);
            }
        }

        [MenuItem("GameObject/Gaussian Splatting/Voxel Vortex Cylinder", false, 10)]
        static void CreateVortexCylinder(MenuCommand command)
        {
            GameObject cylinder = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            cylinder.name = "Voxel Vortex";
            GameObjectUtility.SetParentAndAlign(cylinder, command.context as GameObject);
            Undo.RegisterCreatedObjectUndo(cylinder, "Create Voxel Vortex");

            var collider = cylinder.GetComponent<CapsuleCollider>();
            if (collider != null)
                collider.isTrigger = true;

            cylinder.AddComponent<VoxelVortexForce>();
            Selection.activeGameObject = cylinder;
        }
    }
}
#endif
