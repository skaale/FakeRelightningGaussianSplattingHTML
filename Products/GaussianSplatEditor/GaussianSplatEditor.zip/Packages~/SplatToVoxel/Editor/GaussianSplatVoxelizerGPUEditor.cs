// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatVoxelizerGPU))]
    public class GaussianSplatVoxelizerGPUEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            
            GaussianSplatVoxelizerGPU voxelizer = (GaussianSplatVoxelizerGPU)target;
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("GPU Voxelization", EditorStyles.boldLabel);
            
            if (GUILayout.Button("Voxelize World (GPU)", GUILayout.Height(40)))
            {
                voxelizer.VoxelizeWorld();
            }
            
            GUI.backgroundColor = Color.red;
            if (GUILayout.Button("Delete Voxel World", GUILayout.Height(30)))
            {
                if (EditorUtility.DisplayDialog("Delete Voxel World", 
                    "Are you sure you want to delete all voxels?\nThis will free GPU memory and buffers.", 
                    "Delete", "Cancel"))
                {
                    voxelizer.DeleteVoxelWorld();
                }
            }
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Statistics", EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"Total Voxels: {voxelizer.GetTotalVoxels()}");
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Controls", EditorStyles.boldLabel);
            
            var splatRenderer = serializedObject.FindProperty("m_SplatRenderer").objectReferenceValue as GaussianSplatRenderer;
            if (splatRenderer != null)
            {
                bool splatActive = splatRenderer.gameObject.activeSelf;
                string buttonText = splatActive ? "Hide Splat Renderer" : "Show Splat Renderer";
                if (GUILayout.Button(buttonText))
                {
                    splatRenderer.gameObject.SetActive(!splatActive);
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "GPU Voxelizer Workflow:\n\n" +
                "1. Set 'Voxel Size' (0.05m = fine, 0.1m = coarse)\n" +
                "2. Set 'Sample Every Nth Splat' (10-20 recommended for 2M splats)\n" +
                "3. Click 'Voxelize World (GPU)'\n" +
                "4. Wait a moment for processing\n" +
                "5. Click 'Hide Splat Renderer' to see voxels\n\n" +
                "GPU rendering via DrawMeshInstancedIndirect - super fast!\n" +
                "All voxels render in single draw call with proper colors.",
                MessageType.Info
            );
            
            if (Application.isPlaying)
            {
                Repaint();
            }
        }
    }
}
#endif

