// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatVoxelizerSimple))]
    public class GaussianSplatVoxelizerSimpleEditor : UnityEditor.Editor
    {
        private double m_LastRepaintTime;

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            DrawPropertiesExcluding(serializedObject, "m_Script", "m_GPUBuildSpeed");

            var voxelizer = (GaussianSplatVoxelizerSimple)target;
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Voxelization", EditorStyles.boldLabel);

            if (voxelizer.GetVoxelMode() == GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced)
            {
                EditorGUILayout.PropertyField(
                    serializedObject.FindProperty("m_GPUBuildSpeed"),
                    new GUIContent(
                        "GPU Build Speed",
                        "Progressive-build multiplier: 0.5 is half speed, 1 is normal, and 2 is double speed."));
            }

            serializedObject.ApplyModifiedProperties();

            if (GUILayout.Button("Voxelize World", GUILayout.Height(36)))
                voxelizer.VoxelizeWorld();

            GUI.backgroundColor = new Color(0.8f, 0.2f, 0.2f);
            if (GUILayout.Button("Delete Voxel World", GUILayout.Height(28)) &&
                EditorUtility.DisplayDialog("Delete Voxel World", "Delete all generated voxels?", "Delete", "Cancel"))
                voxelizer.DeleteVoxelWorld();
            GUI.backgroundColor = Color.white;

            if (voxelizer.IsBuilding())
            {
                float progress = voxelizer.GetBuildProgress();
                EditorGUI.ProgressBar(
                    EditorGUILayout.GetControlRect(),
                    progress / 100f,
                    $"Building {progress:F1}%");

                if (EditorApplication.timeSinceStartup - m_LastRepaintTime > 0.1)
                {
                    m_LastRepaintTime = EditorApplication.timeSinceStartup;
                    Repaint();
                }
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Status", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Mode", voxelizer.GetVoxelMode().ToString());
            EditorGUILayout.LabelField("Voxels", voxelizer.GetTotalVoxels().ToString("N0"));
            EditorGUILayout.LabelField("Dynamic CPU Voxels", voxelizer.GetPhysicsVoxelCount().ToString("N0"));

            bool physicsEnabled = serializedObject.FindProperty("m_EnablePhysics").boolValue;
            EditorGUILayout.HelpBox(
                physicsEnabled
                    ? "Physics is trigger-based. Add VoxelPhysicsTrigger to an interacting object."
                    : "Enable Physics to allow VoxelPhysicsTrigger interactions.",
                physicsEnabled ? MessageType.Info : MessageType.Warning);
        }
    }
}
#endif
