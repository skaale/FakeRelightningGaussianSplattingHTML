// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(VoxelPhysicsTrigger))]
    public class VoxelPhysicsTriggerEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.LabelField("Voxel Physics Trigger", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Voxelizer"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_DetectionMode"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_AcceptLayers"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ActivationRadius"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ContinuousActivation"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ActivationCheckInterval"));

            EditorGUILayout.Space();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ApplyPushForce"));
            if (serializedObject.FindProperty("m_ApplyPushForce").boolValue)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("m_PushForce"));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ForceMode"));
            }

            EditorGUILayout.Space();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_DebugLog"));
            serializedObject.ApplyModifiedProperties();

            var trigger = (VoxelPhysicsTrigger)target;
            var collider = trigger.GetComponent<Collider>();
            if (collider == null)
                EditorGUILayout.HelpBox("A collider will be added automatically at runtime.", MessageType.Info);

            var mode = serializedObject.FindProperty("m_DetectionMode").enumValueIndex;
            if (mode == (int)DetectionMode.Collision && trigger.GetComponent<Rigidbody>() == null)
                EditorGUILayout.HelpBox("Collision mode requires a Rigidbody on this object.", MessageType.Warning);

            EditorGUILayout.HelpBox(
                "The trigger automatically uses Rigidbody physics for CPU voxels and compute physics for GPU voxels.",
                MessageType.Info);
        }
    }
}
#endif
