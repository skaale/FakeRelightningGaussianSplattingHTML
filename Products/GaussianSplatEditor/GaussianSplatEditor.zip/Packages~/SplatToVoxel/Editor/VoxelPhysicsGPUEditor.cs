// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using GaussianSplatting.Runtime;
using UnityEditor;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(VoxelPhysicsGPU))]
    public class VoxelPhysicsGPUEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.LabelField("GPU Voxel Physics Adapter", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Voxelizer"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_DebugLog"));
            serializedObject.ApplyModifiedProperties();

            var adapter = (VoxelPhysicsGPU)target;
            EditorGUILayout.HelpBox(
                "Optional scripting adapter. Normal collision setup only needs VoxelPhysicsTrigger.",
                MessageType.Info);

            if (UnityEngine.Application.isPlaying)
                EditorGUILayout.LabelField("Ready", adapter.IsInitialized ? "Yes" : "No");
        }
    }
}
#endif
