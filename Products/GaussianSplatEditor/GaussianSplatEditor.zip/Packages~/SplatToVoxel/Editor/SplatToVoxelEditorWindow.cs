// SPDX-License-Identifier: MIT

#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;
#if SPLATBOX
using GaussianSplatRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;
#endif

namespace GaussianSplatting.Editor
{
    public class SplatToVoxelEditorWindow : EditorWindow
    {
        private GaussianSplatRenderer m_SelectedSplatRenderer;
        private GaussianSplatVoxelizerSimple m_Voxelizer;
        
        // Settings
        private GaussianSplatVoxelizerSimple.VoxelMode m_VoxelMode = GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects;
        private float m_VoxelSize = 0.05f;
        private int m_SampleEveryNth = 10;
        private float m_ActivationRadius = 20f;
        private float m_GPUBuildSpeed = 1.0f;
        private float m_LightMultiplier = 1.0f;
        private bool m_HideSplatsWhenDone = true;
        private bool m_UseColorFromSplats = true;
        private bool m_CastShadows = true;
        private bool m_ReceiveShadows = true;
        private bool m_ShadowsOnly;
        private float m_ShadowSizeMultiplier = 1.25f;
        
        // Physics
        private bool m_EnablePhysics = true;
        private float m_CubeMass = 1f;
        private bool m_EnableSelfCollision = true;
        private int m_VoxelLayer;
        private BoxCollider m_CollisionBox;
        
        // Materials
        private Material m_VoxelMaterial;
        // GPU material is auto-created at runtime to match voxel material lighting
        private ComputeShader m_VoxelCompute;
        private ComputeShader m_PhysicsCompute;
        
        // UI State
        private Vector2 m_ScrollPosition;
        private bool m_ShowAdvancedSettings = false;
        private bool m_ShowPhysicsSettings = true;
        private bool m_ShowGPUSettings = false;
        
        [MenuItem("Tools/Gaussian Splatting/Splat To Voxel", false, 200)]
        public static void ShowWindow()
        {
            var window = GetWindow<SplatToVoxelEditorWindow>("Splat To Voxel");
            window.minSize = new Vector2(350, 500);
            window.Show();
        }
        
        void OnEnable()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
                return;
            
            EditorApplication.delayCall += InitializeWindow;
        }
        
        void OnFocus()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
                return;
            
            FindExistingVoxelizer();
        }
        
        void InitializeWindow()
        {
            if (this == null)
                return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
                return;
            
            FindExistingVoxelizer();
            LoadDefaultAssets();
        }
        
        void FindExistingVoxelizer()
        {
            if (m_Voxelizer == null)
            {
                m_Voxelizer = FindAnyObjectByType<GaussianSplatVoxelizerSimple>();
            }
            
            if (m_SelectedSplatRenderer == null)
            {
                m_SelectedSplatRenderer = FindAnyObjectByType<GaussianSplatRenderer>();
            }
        }
        
        void LoadDefaultAssets()
        {
            if (m_VoxelMaterial == null)
            {
                // Always create fresh URP Lit material to avoid shader reference issues
                var shader = Shader.Find("Universal Render Pipeline/Lit");
                if (shader == null)
                    shader = Shader.Find("Standard");
                
                if (shader != null)
                {
                    m_VoxelMaterial = new Material(shader);
                    m_VoxelMaterial.name = "VoxelRuntimeMaterial";
                    m_VoxelMaterial.enableInstancing = true;
                    m_VoxelMaterial.SetFloat("_Smoothness", 0.5f);
                    m_VoxelMaterial.SetFloat("_Metallic", 0f);
                }
            }
            
            if (m_VoxelCompute == null)
            {
                var guids = AssetDatabase.FindAssets("VoxelGeneration t:ComputeShader");
                foreach (var guid in guids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    m_VoxelCompute = AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                    break;
                }
            }
            
            if (m_PhysicsCompute == null)
            {
                var guids = AssetDatabase.FindAssets("VoxelPhysicsCollision t:ComputeShader");
                foreach (var guid in guids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    m_PhysicsCompute = AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                    break;
                }
            }
            
            // GPU voxel material is auto-created at runtime by the voxelizer
        }
        
        void OnGUI()
        {
            m_ScrollPosition = EditorGUILayout.BeginScrollView(m_ScrollPosition);
            
            DrawHeader();
            EditorGUILayout.Space(10);
            
            DrawSourceSection();
            EditorGUILayout.Space(10);
            
            DrawModeSection();
            EditorGUILayout.Space(10);
            
            DrawSettingsSection();
            EditorGUILayout.Space(10);
            
            DrawPhysicsSection();
            EditorGUILayout.Space(10);
            
            if (m_VoxelMode != GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects)
            {
                DrawGPUSection();
                EditorGUILayout.Space(10);
            }
            
            DrawActionButtons();
            EditorGUILayout.Space(10);
            
            if (m_Voxelizer != null)
            {
                DrawStatistics();
            }
            
            EditorGUILayout.EndScrollView();
            
            // Repaint during building
            if (m_Voxelizer != null && m_Voxelizer.IsBuilding())
            {
                Repaint();
            }
        }
        
        void DrawHeader()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 18,
                alignment = TextAnchor.MiddleCenter
            };
            
            EditorGUILayout.LabelField("Splat To Voxel", titleStyle);
            EditorGUILayout.LabelField("Convert Gaussian Splats to Interactive Voxels", EditorStyles.centeredGreyMiniLabel);
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawSourceSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Source", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            m_SelectedSplatRenderer = (GaussianSplatRenderer)EditorGUILayout.ObjectField(
                "Splat Renderer", m_SelectedSplatRenderer, typeof(GaussianSplatRenderer), true);
            
            if (m_SelectedSplatRenderer == null)
            {
                EditorGUILayout.HelpBox("Select a Gaussian Splat Renderer to voxelize", MessageType.Warning);
                
                if (GUILayout.Button("Find in Scene"))
                {
                    m_SelectedSplatRenderer = FindAnyObjectByType<GaussianSplatRenderer>();
                }
            }
            else
            {
                int splatCount = m_SelectedSplatRenderer.splatCount;
                int estimatedVoxels = splatCount / m_SampleEveryNth;
                EditorGUILayout.LabelField($"Splat Count: {splatCount:N0}");
                EditorGUILayout.LabelField($"Estimated Voxels: ~{estimatedVoxels:N0}");
            }
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawModeSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Voxel Mode", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            
            GUI.backgroundColor = m_VoxelMode == GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects ? Color.green : Color.gray;
            if (GUILayout.Button("CPU\nGameObjects", GUILayout.Height(50)))
            {
                m_VoxelMode = GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects;
            }
            
            GUI.backgroundColor = m_VoxelMode == GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced ? Color.green : Color.gray;
            if (GUILayout.Button("GPU\nInstanced", GUILayout.Height(50)))
            {
                m_VoxelMode = GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced;
            }
            
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            string modeDescription = m_VoxelMode switch
            {
                GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects => 
                    "GameObject voxels with Rigidbody and Collider physics.",
                GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced => 
                    "GPU-instanced voxels with compute-based movement.",
                _ => ""
            };
            
            EditorGUILayout.HelpBox(modeDescription, MessageType.Info);
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawSettingsSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Voxel Settings", EditorStyles.boldLabel);
            
            m_VoxelSize = EditorGUILayout.Slider("Voxel Size (m)", m_VoxelSize, 0.01f, 0.5f);
            
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Quality Preset:", GUILayout.Width(100));
            
            if (GUILayout.Button("High", GUILayout.Width(60)))
            {
                m_VoxelSize = 0.02f;
                m_SampleEveryNth = 1;
            }
            if (GUILayout.Button("Medium", GUILayout.Width(60)))
            {
                m_VoxelSize = 0.05f;
                m_SampleEveryNth = 5;
            }
            if (GUILayout.Button("Low", GUILayout.Width(60)))
            {
                m_VoxelSize = 0.1f;
                m_SampleEveryNth = 20;
            }
            if (GUILayout.Button("Fast", GUILayout.Width(60)))
            {
                m_VoxelSize = 0.15f;
                m_SampleEveryNth = 50;
            }
            
            EditorGUILayout.EndHorizontal();
            
            m_SampleEveryNth = EditorGUILayout.IntSlider("Sample Every Nth", m_SampleEveryNth, 1, 100);
            m_ActivationRadius = EditorGUILayout.Slider("Activation Radius", m_ActivationRadius, 5f, 100f);
            
            m_ShowAdvancedSettings = EditorGUILayout.Foldout(m_ShowAdvancedSettings, "Advanced Settings");
            if (m_ShowAdvancedSettings)
            {
                EditorGUI.indentLevel++;
                m_UseColorFromSplats = EditorGUILayout.Toggle("Use Splat Colors", m_UseColorFromSplats);
                m_HideSplatsWhenDone = EditorGUILayout.Toggle("Hide Splats When Done", m_HideSplatsWhenDone);
                m_CastShadows = EditorGUILayout.Toggle("Cast Shadows", m_CastShadows);
                m_ReceiveShadows = EditorGUILayout.Toggle("Receive Shadows", m_ReceiveShadows);
                m_ShadowsOnly = EditorGUILayout.Toggle(
                    new GUIContent("Shadows Only", "Hide voxels while retaining them as Unity shadow casters."),
                    m_ShadowsOnly);
                if (m_VoxelMode == GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced)
                {
                    m_ShadowSizeMultiplier = Mathf.Max(
                        0.01f,
                        EditorGUILayout.FloatField(
                            new GUIContent(
                                "Shadow Size Multiplier",
                                "Enlarge only the GPU shadow proxy so neighboring voxel shadows overlap."),
                            m_ShadowSizeMultiplier));
                }
                m_VoxelMaterial = (Material)EditorGUILayout.ObjectField("Voxel Material", m_VoxelMaterial, typeof(Material), false);
                EditorGUI.indentLevel--;
            }
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawPhysicsSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            m_ShowPhysicsSettings = EditorGUILayout.Foldout(m_ShowPhysicsSettings, "Physics Settings", true);
            
            if (m_ShowPhysicsSettings)
            {
                m_EnablePhysics = EditorGUILayout.Toggle("Enable Physics", m_EnablePhysics);
                
                if (m_EnablePhysics)
                {
                    EditorGUI.indentLevel++;
                    m_CubeMass = EditorGUILayout.Slider("Voxel Mass", m_CubeMass, 0.1f, 10f);
                    m_EnableSelfCollision = EditorGUILayout.Toggle(
                        new GUIContent("Self Collision", "CPU uses Unity collision; GPU uses approximate local-neighbor collision."),
                        m_EnableSelfCollision);
                    if (m_VoxelMode == GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects)
                        m_VoxelLayer = EditorGUILayout.LayerField("Voxel Layer", m_VoxelLayer);
                    m_CollisionBox = (BoxCollider)EditorGUILayout.ObjectField(
                        new GUIContent("Ground Collision Box", "Top surface stops falling GPU voxels. CPU voxels collide normally."),
                        m_CollisionBox,
                        typeof(BoxCollider),
                        true);
                    EditorGUI.indentLevel--;
                    EditorGUILayout.HelpBox(
                        "Add VoxelPhysicsTrigger to an interacting object. Create a vortex from GameObject > Gaussian Splatting > Voxel Vortex Cylinder.",
                        MessageType.Info);
                }
            }
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawGPUSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            m_ShowGPUSettings = EditorGUILayout.Foldout(m_ShowGPUSettings, "GPU Settings", true);
            
            if (m_ShowGPUSettings)
            {
                // GPU material is now auto-created at runtime
                EditorGUILayout.LabelField("GPU Material", "Auto-created (matches Voxel Material)");
                m_LightMultiplier = Mathf.Max(
                    0f,
                    EditorGUILayout.FloatField(
                        new GUIContent("Light Multiplier", "GPU voxel brightness. Values above 1 can increase bloom."),
                        m_LightMultiplier));
                m_VoxelCompute = (ComputeShader)EditorGUILayout.ObjectField("Voxel Compute", m_VoxelCompute, typeof(ComputeShader), false);
                m_PhysicsCompute = (ComputeShader)EditorGUILayout.ObjectField("Physics Compute", m_PhysicsCompute, typeof(ComputeShader), false);
                
                bool missingAssets = m_VoxelCompute == null || m_PhysicsCompute == null;
                
                if (missingAssets)
                {
                    EditorGUILayout.HelpBox("Compute shaders are required for GPU mode", MessageType.Warning);
                    
                    if (GUILayout.Button("Find GPU Assets"))
                    {
                        LoadDefaultAssets();
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox("GPU assets loaded. Voxels will render via GPU instancing.", MessageType.Info);
                }
            }
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawActionButtons()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            bool canVoxelize = m_SelectedSplatRenderer != null;
            
            GUI.enabled = canVoxelize;

            if (m_VoxelMode == GaussianSplatVoxelizerSimple.VoxelMode.GPUInstanced)
            {
                m_GPUBuildSpeed = Mathf.Max(
                    0.01f,
                    EditorGUILayout.FloatField(
                        new GUIContent(
                            "GPU Build Speed",
                            "Progressive-build multiplier: 0.5 is half speed, 1 is normal, and 2 is double speed."),
                        m_GPUBuildSpeed));
                EditorGUILayout.Space(4);
            }

            GUI.backgroundColor = new Color(0.4f, 0.8f, 0.4f);
            
            if (GUILayout.Button("Voxelize World", GUILayout.Height(50)))
            {
                CreateOrUpdateVoxelizer();
                m_Voxelizer.VoxelizeWorld();
            }
            
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;
            
            if (m_Voxelizer != null && m_Voxelizer.IsBuilding())
            {
                float progress = m_Voxelizer.GetBuildProgress();
                EditorGUI.ProgressBar(EditorGUILayout.GetControlRect(GUILayout.Height(20)), progress / 100f, $"Building: {progress:F1}%");
            }
            
            EditorGUILayout.BeginHorizontal();
            
            GUI.enabled = m_Voxelizer != null && m_Voxelizer.GetTotalVoxels() > 0;
            
            if (GUILayout.Button("Activate All", GUILayout.Height(30)))
            {
                m_Voxelizer.ActivateAllChunks();
            }
            
            if (GUILayout.Button("Deactivate All", GUILayout.Height(30)))
            {
                m_Voxelizer.DeactivateAllChunks();
            }
            
            GUI.enabled = true;
            EditorGUILayout.EndHorizontal();
            
            GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
            GUI.enabled = m_Voxelizer != null;
            
            if (GUILayout.Button("Delete Voxel World", GUILayout.Height(30)))
            {
                if (EditorUtility.DisplayDialog("Delete Voxel World", 
                    "Delete all voxels and free memory?", "Delete", "Cancel"))
                {
                    m_Voxelizer.DeleteVoxelWorld();
                }
            }
            
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;
            
            EditorGUILayout.EndVertical();
        }
        
        void DrawStatistics()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Statistics", EditorStyles.boldLabel);
            
            var mode = m_Voxelizer.GetVoxelMode();
            int total = m_Voxelizer.GetTotalVoxels();
            int active = m_Voxelizer.GetActiveVoxels();
            int gpu = m_Voxelizer.GetGPUVoxelCount();
            int physics = m_Voxelizer.GetPhysicsVoxelCount();
            
            EditorGUILayout.LabelField($"Mode: {mode}");
            EditorGUILayout.LabelField($"Total Voxels: {total:N0}");
            EditorGUILayout.LabelField($"Active GameObjects: {active:N0}");
            
            if (mode != GaussianSplatVoxelizerSimple.VoxelMode.CPUGameObjects)
            {
                EditorGUILayout.LabelField($"GPU Voxels: {gpu:N0}");
            }
            
            EditorGUILayout.LabelField($"Dynamic Physics: {physics:N0}");
            
            // Visual status
            EditorGUILayout.Space(5);
            EditorGUILayout.BeginHorizontal();
            
            GUI.color = total > 0 ? Color.green : Color.gray;
            GUILayout.Label("●", GUILayout.Width(15));
            EditorGUILayout.LabelField(total > 0 ? "Voxels Created" : "No Voxels", GUILayout.Width(100));
            
            GUI.color = physics > 0 ? Color.yellow : Color.gray;
            GUILayout.Label("●", GUILayout.Width(15));
            EditorGUILayout.LabelField(physics > 0 ? "Physics Active" : "Physics Frozen", GUILayout.Width(100));
            
            GUI.color = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.EndVertical();
        }
        
        void CreateOrUpdateVoxelizer()
        {
            if (m_Voxelizer == null)
            {
                var go = new GameObject("SplatToVoxel");
                m_Voxelizer = go.AddComponent<GaussianSplatVoxelizerSimple>();
                Undo.RegisterCreatedObjectUndo(go, "Create Voxelizer");
            }
            
            // Apply settings via serialized object
            var so = new SerializedObject(m_Voxelizer);
            
            so.FindProperty("m_SplatRenderer").objectReferenceValue = m_SelectedSplatRenderer;
            so.FindProperty("m_VoxelMode").enumValueIndex = (int)m_VoxelMode;
            so.FindProperty("m_VoxelSize").floatValue = m_VoxelSize;
            so.FindProperty("m_SampleEveryNthSplat").intValue = m_SampleEveryNth;
            so.FindProperty("m_ActivationRadius").floatValue = m_ActivationRadius;
            so.FindProperty("m_GPUBuildSpeed").floatValue = m_GPUBuildSpeed;
            so.FindProperty("m_LightMultiplier").floatValue = m_LightMultiplier;
            so.FindProperty("m_HideSplatsWhenDone").boolValue = m_HideSplatsWhenDone;
            so.FindProperty("m_UseColorFromSplats").boolValue = m_UseColorFromSplats;
            so.FindProperty("m_CastShadows").boolValue = m_CastShadows;
            so.FindProperty("m_ReceiveShadows").boolValue = m_ReceiveShadows;
            so.FindProperty("m_ShadowsOnly").boolValue = m_ShadowsOnly;
            so.FindProperty("m_ShadowSizeMultiplier").floatValue = m_ShadowSizeMultiplier;
            so.FindProperty("m_EnablePhysics").boolValue = m_EnablePhysics;
            so.FindProperty("m_CubeMass").floatValue = m_CubeMass;
            so.FindProperty("m_EnableSelfCollision").boolValue = m_EnableSelfCollision;
            so.FindProperty("m_VoxelLayer").intValue = m_VoxelLayer;
            so.FindProperty("m_CollisionBox").objectReferenceValue = m_CollisionBox;
            
            if (m_VoxelMaterial != null)
                so.FindProperty("m_VoxelMaterial").objectReferenceValue = m_VoxelMaterial;
            // GPU material is now auto-created at runtime to match voxel material lighting
            if (m_VoxelCompute != null)
                so.FindProperty("m_VoxelCompute").objectReferenceValue = m_VoxelCompute;
            if (m_PhysicsCompute != null)
                so.FindProperty("m_PhysicsCompute").objectReferenceValue = m_PhysicsCompute;
            
            so.ApplyModifiedProperties();
            
            Selection.activeGameObject = m_Voxelizer.gameObject;
        }
    }
}
#endif
