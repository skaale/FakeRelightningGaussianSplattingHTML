# Splat To Voxel

Unity package that converts Gaussian Splats into voxels with optional physics.

Requires a Gaussian Splat renderer already in the project:

- `org.nesnausk.gaussian-splatting` (`GaussianSplatRenderer`), or
- `com.gaussiansplatting.splatbox` (`SplatBoxRenderer`)

## Install

**From this project** — already registered in `Packages/manifest.json`:

```json
"com.splatworld.splat-to-voxel": "file:packageSplatToVoxel"
```

**In another Unity project** — Package Manager → **+** → **Add package from disk…** and select this folder’s `package.json`, or add:

```json
"com.splatworld.splat-to-voxel": "file:C:/path/to/packageSplatToVoxel"
```

Also add the Gaussian Splatting package you use (SplatBox or UnityGaussianSplatting).

## Convert a splat

1. Open **Tools → Gaussian Splatting → Splat To Voxel**
2. Assign the splat renderer
3. Pick a mode:
   - **CPU GameObjects** — one cube per voxel, full physics
   - **GPU Instanced** — compute-rendered voxels with lightweight GPU movement
4. Click **Voxelize World**

## Physics

Voxels start as kinematic colliders. Make them dynamic on contact:

1. Select a moving object (ball, player, tool)
2. **GameObject → Gaussian Splatting → Setup Voxel Physics Trigger**
3. The trigger automatically selects CPU or GPU behavior from the voxelizer mode

CPU mode enables Rigidbody physics. GPU mode applies force and gravity in the compute buffer.

## Components

| Component | Role |
|---|---|
| `GaussianSplatVoxelizerSimple` | CPU or GPU voxelization and physics |
| `GaussianSplatVoxelizerGPU` | GPU-only instanced voxels |
| `VoxelPhysicsTrigger` | Enable physics on collision / trigger |
| `VoxelPhysicsGPU` | Optional scripting adapter for GPU interactions |
