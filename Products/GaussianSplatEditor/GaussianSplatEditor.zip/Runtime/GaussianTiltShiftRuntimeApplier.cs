// SPDX-License-Identifier: MIT
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Legacy runtime driver for camera rigs without a SplatBox-authored camera effect.
    /// Saved Camera-panel settings take precedence and survive applier disable/camera swaps.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [AddComponentMenu("SplatBox/Tilt-Shift Runtime Applier")]
    public class GaussianTiltShiftRuntimeApplier : MonoBehaviour
    {
        [Tooltip("Camera to drive. Leave empty to auto-resolve Camera.main (then the first enabled camera).")]
        public Camera targetCamera;

        [Tooltip("Re-sync every frame so the effect follows camera swaps / XR rigs and reflects live editor tuning.")]
        public bool continuousSync = true;

        [Tooltip("While the Splat Editor Window is open and tuning, copy its live values into these settings " +
                 "so what you see in the editor is what ships. Turn off to keep these serialized values fixed.")]
        public bool followEditorWindow = true;

        [Tooltip("Serialized tilt-shift settings. These ship in the player/Android build and are the source of " +
                 "truth on device (the editor-only global settings reset to disabled in a build).")]
        public GaussianTiltShiftRendererFeature.TiltShiftSettings settings = new GaussianTiltShiftRendererFeature.TiltShiftSettings();

        Camera m_AppliedCamera;
        GaussianSplatTiltShiftEffect m_OwnedEffect;

        void OnEnable() => Apply();

        void OnDisable()
        {
            ReleaseOwnedEffect();
            m_AppliedCamera = null;
        }

        void ReleaseOwnedEffect()
        {
            if (m_OwnedEffect != null && !m_OwnedEffect.authoredInSplatBoxEditor)
                DestroyEffect(m_OwnedEffect);
            m_OwnedEffect = null;
        }

        void Update()
        {
            if (continuousSync)
                Apply();
        }

        void Apply()
        {
            // Let the live editor preview drive the serialized snapshot so authoring stays WYSIWYG.
            if (followEditorWindow && GaussianTiltShiftGlobalSettings.Active)
                settings.CopyFromGlobal();

            var cam = ResolveCamera();
            if (cam == null)
                return;

            // If the active camera changed, clear the override off the previous one.
            if (m_AppliedCamera != null && m_AppliedCamera != cam)
            {
                ReleaseOwnedEffect();
            }
            m_AppliedCamera = cam;

            var effect = cam.GetComponent<GaussianSplatTiltShiftEffect>();
            if (effect != null && effect.authoredInSplatBoxEditor)
                return;
            if (effect == null)
            {
                effect = cam.gameObject.AddComponent<GaussianSplatTiltShiftEffect>();
                // Transient: this component is regenerated from the (serialized) applier each session, so it
                // should not dirty the scene or persist as a stray override.
                effect.hideFlags = HideFlags.HideAndDontSave;
                m_OwnedEffect = effect;
            }

            CopyInto(effect);
        }

        Camera ResolveCamera()
        {
            if (targetCamera != null)
                return targetCamera;
            if (Camera.main != null)
                return Camera.main;

            var all = Camera.allCameras;
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].isActiveAndEnabled && all[i].cameraType == CameraType.Game)
                    return all[i];
            }
            return null;
        }

        void CopyInto(GaussianSplatTiltShiftEffect effect)
        {
            effect.blurMode = (GaussianSplatTiltShiftEffect.BlurMode)settings.blurMode;
            effect.focusPosition = settings.focusPosition;
            effect.focusWidth = settings.focusWidth;
            effect.tiltAngle = settings.tiltAngle;
            effect.focusDistance = settings.focusDistance;
            effect.focusRange = settings.focusRange;
            effect.nearBlurStrength = settings.nearBlurStrength;
            effect.farBlurStrength = settings.farBlurStrength;
            effect.blurStrength = settings.blurStrength;
            effect.topBlurStrength = settings.topBlurStrength;
            effect.bottomBlurStrength = settings.bottomBlurStrength;
            effect.topBlurOffset = settings.topBlurOffset;
            effect.bottomBlurOffset = settings.bottomBlurOffset;
            effect.blurSamples = settings.blurSamples;
            effect.bokehShape = settings.bokehShape;
            effect.saturationBoost = settings.saturationBoost;
            effect.contrastBoost = settings.contrastBoost;
            effect.vignetteStrength = settings.vignetteStrength;
            effect.highQualityBlur = settings.highQualityBlur;
            effect.effectEnabled = settings.enabled;
        }

        void DestroyEffect(GaussianSplatTiltShiftEffect effect)
        {
            if (Application.isPlaying)
                Destroy(effect);
            else
                DestroyImmediate(effect);
        }
    }
}
