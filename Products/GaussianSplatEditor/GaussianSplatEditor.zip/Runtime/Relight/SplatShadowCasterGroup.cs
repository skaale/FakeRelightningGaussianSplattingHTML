using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Relight
{
    /// <summary>
    /// Treat this object and its mesh children as a single shadow caster.
    /// Children keep their materials; only the combined parent mesh writes the shadow map,
    /// so rotating the light does not offset Cube/Cylinder (etc.) relative to each other.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public class SplatShadowCasterGroup : MonoBehaviour
    {
        const string kShaderName = "Universal Render Pipeline/Shadow Receiver Only";

        [SerializeField] bool m_IncludeInactiveChildren;

        readonly List<MeshFilter> m_Filters = new List<MeshFilter>(8);
        readonly List<MeshRenderer> m_ChildRenderers = new List<MeshRenderer>(8);
        readonly List<ShadowCastingMode> m_SavedModes = new List<ShadowCastingMode>(8);
        readonly List<CombineInstance> m_Combines = new List<CombineInstance>(8);

        Mesh m_Combined;
        MeshFilter m_Filter;
        MeshRenderer m_Renderer;
        int m_LastHash;
        bool m_StoredChildModes;

        public MeshRenderer groupRenderer => m_Renderer;

        void OnEnable()
        {
            EnsureParentRenderer();
            Rebuild(force: true);
        }

        void OnDisable()
        {
            RestoreChildShadows();
        }

        void OnDestroy()
        {
            RestoreChildShadows();
            if (m_Combined != null)
            {
                if (Application.isPlaying)
                    Destroy(m_Combined);
                else
                    DestroyImmediate(m_Combined);
                m_Combined = null;
            }
        }

        void LateUpdate()
        {
            Rebuild(force: false);
        }

        void EnsureParentRenderer()
        {
            m_Filter = GetComponent<MeshFilter>();
            if (m_Filter == null)
                m_Filter = gameObject.AddComponent<MeshFilter>();

            m_Renderer = GetComponent<MeshRenderer>();
            if (m_Renderer == null)
                m_Renderer = gameObject.AddComponent<MeshRenderer>();

            if (m_Renderer.sharedMaterial == null ||
                m_Renderer.sharedMaterial.shader == null ||
                m_Renderer.sharedMaterial.shader.name != kShaderName)
            {
                var childMat = FindChildMaterial();
                if (childMat != null)
                    m_Renderer.sharedMaterial = childMat;
            }

            m_Renderer.shadowCastingMode = ShadowCastingMode.On;
            m_Renderer.receiveShadows = false;
        }

        Material FindChildMaterial()
        {
            var renderers = GetComponentsInChildren<MeshRenderer>(m_IncludeInactiveChildren);
            for (int i = 0; i < renderers.Length; i++)
            {
                var r = renderers[i];
                if (r == null || r == m_Renderer)
                    continue;
                var mat = r.sharedMaterial;
                if (mat != null && mat.shader != null && mat.shader.name == kShaderName)
                    return mat;
            }
            return null;
        }

        void Rebuild(bool force)
        {
            EnsureParentRenderer();
            CollectChildren();
            int hash = ComputeHash();
            if (!force && hash == m_LastHash)
                return;
            m_LastHash = hash;

            if (m_Combined == null)
            {
                m_Combined = new Mesh { name = "SplatShadowCasterGroup" };
                m_Combined.MarkDynamic();
            }

            m_Combines.Clear();
            Matrix4x4 worldToLocal = transform.worldToLocalMatrix;
            for (int i = 0; i < m_Filters.Count; i++)
            {
                var filter = m_Filters[i];
                if (filter == null || filter.sharedMesh == null)
                    continue;
                m_Combines.Add(new CombineInstance
                {
                    mesh = filter.sharedMesh,
                    transform = worldToLocal * filter.transform.localToWorldMatrix
                });
            }

            m_Combined.Clear();
            if (m_Combines.Count > 0)
            {
                m_Combined.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                m_Combined.CombineMeshes(m_Combines.ToArray(), true, true);
            }

            m_Filter.sharedMesh = m_Combined;
            SuppressChildShadows();
        }

        void CollectChildren()
        {
            m_Filters.Clear();
            m_ChildRenderers.Clear();
            var filters = GetComponentsInChildren<MeshFilter>(m_IncludeInactiveChildren);
            for (int i = 0; i < filters.Length; i++)
            {
                var filter = filters[i];
                if (filter == null || filter == m_Filter || filter.sharedMesh == null)
                    continue;
                if (filter.GetComponent<SplatShadowCasterGroup>() != null && filter.transform != transform)
                    continue;
                m_Filters.Add(filter);
                var renderer = filter.GetComponent<MeshRenderer>();
                if (renderer != null && renderer != m_Renderer)
                    m_ChildRenderers.Add(renderer);
            }
        }

        int ComputeHash()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 31 + m_Filters.Count;
                for (int i = 0; i < m_Filters.Count; i++)
                {
                    var filter = m_Filters[i];
                    if (filter == null)
                        continue;
                    var t = filter.transform;
                    hash = hash * 31 + t.position.GetHashCode();
                    hash = hash * 31 + t.rotation.GetHashCode();
                    hash = hash * 31 + t.lossyScale.GetHashCode();
                    hash = hash * 31 + filter.sharedMesh.GetEntityId().GetHashCode();
                }
                return hash;
            }
        }

        void SuppressChildShadows()
        {
            if (!m_StoredChildModes)
            {
                m_SavedModes.Clear();
                for (int i = 0; i < m_ChildRenderers.Count; i++)
                    m_SavedModes.Add(m_ChildRenderers[i] != null
                        ? m_ChildRenderers[i].shadowCastingMode
                        : ShadowCastingMode.On);
                m_StoredChildModes = true;
            }

            for (int i = 0; i < m_ChildRenderers.Count; i++)
            {
                if (m_ChildRenderers[i] != null)
                    m_ChildRenderers[i].shadowCastingMode = ShadowCastingMode.Off;
            }
        }

        void RestoreChildShadows()
        {
            if (!m_StoredChildModes)
                return;
            for (int i = 0; i < m_ChildRenderers.Count && i < m_SavedModes.Count; i++)
            {
                if (m_ChildRenderers[i] != null)
                    m_ChildRenderers[i].shadowCastingMode = m_SavedModes[i];
            }
            m_StoredChildModes = false;
            m_SavedModes.Clear();
        }
    }
}
