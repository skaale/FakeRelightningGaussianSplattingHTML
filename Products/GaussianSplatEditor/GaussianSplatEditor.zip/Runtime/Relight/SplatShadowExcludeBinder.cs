using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Relight
{
    /// <summary>
    /// Collects Shadow Receiver Only casters and binds their volumes so splat lighting can
    /// skip main-light shadows inside the primitive (the shadow still lands on the floor beyond it).
    /// Parent hierarchies are collapsed to one volume so Cube+Cylinder (etc.) act as a single caster.
    /// </summary>
    public static class SplatShadowExcludeBinder
    {
        const string kShaderName = "Universal Render Pipeline/Shadow Receiver Only";
        const int kMaxVolumes = 16;
        const int kStride = 96;

        static readonly int s_BufferId = Shader.PropertyToID("_SplatShadowExcludeVolumes");
        static readonly int s_CountId = Shader.PropertyToID("_SplatShadowExcludeCount");
        static readonly int s_PreventId = Shader.PropertyToID("_PreventInteriorShadow");
        static readonly int s_TypeId = Shader.PropertyToID("_ShadowPrimitiveType");
        static readonly int s_PaddingId = Shader.PropertyToID("_InteriorPadding");
        static readonly int s_OriginId = Shader.PropertyToID("_ShadowOriginOffset");
        static readonly int s_HeightId = Shader.PropertyToID("_ShadowCastHeight");
        static readonly int s_GroupId = Shader.PropertyToID("_CastChildrenAsOne");

        [StructLayout(LayoutKind.Sequential)]
        struct VolumeData
        {
            public Matrix4x4 worldToLocal;
            public Vector4 centerPad;
            public Vector4 extentsType;
        }

        static readonly VolumeData[] s_Data = new VolumeData[kMaxVolumes];
        static readonly List<MeshRenderer> s_Casters = new List<MeshRenderer>(16);
        static readonly List<MeshRenderer> s_Members = new List<MeshRenderer>(8);
        static readonly HashSet<MeshRenderer> s_Consumed = new HashSet<MeshRenderer>();
        static readonly Vector3[] s_Corners = new Vector3[8];
        static ComputeBuffer s_Buffer;
        static ComputeBuffer s_Dummy;
        static bool s_CleanupHooked;

        public static void Bind(CommandBuffer cmd, MaterialPropertyBlock mpb)
        {
            int count = Gather();
            ComputeBuffer bound = count > 0 ? LiveBuffer(count) : Dummy();
            if (cmd != null)
            {
                cmd.SetGlobalBuffer(s_BufferId, bound);
                cmd.SetGlobalInt(s_CountId, count);
            }
            if (mpb != null)
            {
                mpb.SetBuffer(s_BufferId, bound);
                mpb.SetInt(s_CountId, count);
            }
        }

        static int Gather()
        {
            s_Casters.Clear();
            s_Consumed.Clear();
#if UNITY_2022_2_OR_NEWER
            var found = Object.FindObjectsByType<MeshRenderer>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
#else
            var found = Object.FindObjectsOfType<MeshRenderer>();
#endif
            for (int i = 0; i < found.Length; i++)
            {
                var renderer = found[i];
                if (!IsCaster(renderer))
                    continue;
                s_Casters.Add(renderer);
            }

            int count = 0;
            for (int i = 0; i < s_Casters.Count && count < kMaxVolumes; i++)
            {
                var renderer = s_Casters[i];
                if (!s_Consumed.Add(renderer))
                    continue;

                Transform root = FindGroupRoot(renderer);
                CollectMembers(root);
                WriteVolume(root, count);
                count++;
            }
            return count;
        }

        static bool IsCaster(MeshRenderer renderer)
        {
            if (renderer == null || !renderer.enabled || !renderer.gameObject.activeInHierarchy)
                return false;
            var mat = renderer.sharedMaterial;
            if (mat == null || mat.shader == null || mat.shader.name != kShaderName)
                return false;
            if (mat.HasProperty(s_PreventId) && mat.GetFloat(s_PreventId) < 0.5f)
                return false;
            var filter = renderer.GetComponent<MeshFilter>();
            return filter != null && filter.sharedMesh != null;
        }

        static bool CastChildrenAsOne(Material mat)
        {
            return mat == null || !mat.HasProperty(s_GroupId) || mat.GetFloat(s_GroupId) > 0.5f;
        }

        static Transform FindGroupRoot(MeshRenderer renderer)
        {
            var group = renderer.GetComponentInParent<SplatShadowCasterGroup>();
            if (group != null)
                return group.transform;

            Transform t = renderer.transform;
            if (!CastChildrenAsOne(renderer.sharedMaterial) || t.parent == null)
                return t;

            Transform parent = t.parent;
            for (int i = 0; i < s_Casters.Count; i++)
            {
                var other = s_Casters[i];
                if (other == renderer || other == null)
                    continue;
                if (other.transform == parent || other.transform.IsChildOf(parent))
                    return parent;
            }
            return t;
        }

        static void CollectMembers(Transform root)
        {
            s_Members.Clear();
            for (int i = 0; i < s_Casters.Count; i++)
            {
                var renderer = s_Casters[i];
                if (renderer == null)
                    continue;
                if (renderer.transform == root || renderer.transform.IsChildOf(root))
                {
                    s_Consumed.Add(renderer);
                    s_Members.Add(renderer);
                }
            }
        }

        static void WriteVolume(Transform root, int index)
        {
            Material mat = null;
            for (int i = 0; i < s_Members.Count; i++)
            {
                if (s_Members[i] != null && s_Members[i].sharedMaterial != null)
                {
                    mat = s_Members[i].sharedMaterial;
                    break;
                }
            }

            Vector3 origin = mat != null && mat.HasProperty(s_OriginId) ? (Vector3)mat.GetVector(s_OriginId) : Vector3.zero;
            float height = mat != null && mat.HasProperty(s_HeightId) ? mat.GetFloat(s_HeightId) : 0f;
            float padding = mat != null && mat.HasProperty(s_PaddingId) ? mat.GetFloat(s_PaddingId) : 0.05f;

            bool started = false;
            Bounds localBounds = default;
            for (int i = 0; i < s_Members.Count; i++)
            {
                var renderer = s_Members[i];
                var filter = renderer.GetComponent<MeshFilter>();
                if (filter == null || filter.sharedMesh == null)
                    continue;

                FillCorners(filter.sharedMesh.bounds);
                Matrix4x4 childToRoot = root.worldToLocalMatrix
                    * renderer.localToWorldMatrix
                    * Matrix4x4.Translate(origin);
                for (int c = 0; c < 8; c++)
                {
                    Vector3 p = childToRoot.MultiplyPoint3x4(s_Corners[c]);
                    if (!started)
                    {
                        localBounds = new Bounds(p, Vector3.zero);
                        started = true;
                    }
                    else
                    {
                        localBounds.Encapsulate(p);
                    }
                }
            }

            if (!started)
                localBounds = new Bounds(Vector3.zero, Vector3.one * 0.01f);

            Vector3 extents = localBounds.extents * Mathf.Max(0.01f, 1f + padding);
            int type = s_Members.Count > 1 ? 0 : ResolveType(mat, s_Members[0]);

            Matrix4x4 localToWorld = Matrix4x4.Translate(new Vector3(0f, height, 0f)) * root.localToWorldMatrix;
            s_Data[index] = new VolumeData
            {
                worldToLocal = localToWorld.inverse,
                centerPad = new Vector4(localBounds.center.x, localBounds.center.y, localBounds.center.z, padding),
                extentsType = new Vector4(extents.x, extents.y, extents.z, type)
            };
        }

        static void FillCorners(Bounds b)
        {
            Vector3 min = b.min;
            Vector3 max = b.max;
            s_Corners[0] = new Vector3(min.x, min.y, min.z);
            s_Corners[1] = new Vector3(min.x, min.y, max.z);
            s_Corners[2] = new Vector3(min.x, max.y, min.z);
            s_Corners[3] = new Vector3(min.x, max.y, max.z);
            s_Corners[4] = new Vector3(max.x, min.y, min.z);
            s_Corners[5] = new Vector3(max.x, min.y, max.z);
            s_Corners[6] = new Vector3(max.x, max.y, min.z);
            s_Corners[7] = new Vector3(max.x, max.y, max.z);
        }

        static int ResolveType(Material mat, MeshRenderer renderer)
        {
            if (mat != null && mat.HasProperty(s_TypeId))
            {
                int declared = Mathf.RoundToInt(mat.GetFloat(s_TypeId));
                if (declared > 0)
                    return declared - 1;
            }

            var filter = renderer != null ? renderer.GetComponent<MeshFilter>() : null;
            string name = filter != null && filter.sharedMesh != null ? filter.sharedMesh.name.ToLowerInvariant() : string.Empty;
            if (name.Contains("cylinder") || name.Contains("capsule"))
                return 2;
            if (name.Contains("sphere"))
                return 1;
            return 0;
        }

        static ComputeBuffer LiveBuffer(int count)
        {
            EnsureCleanup();
            if (s_Buffer == null || s_Buffer.count < kMaxVolumes)
            {
                s_Buffer?.Release();
                s_Buffer = new ComputeBuffer(kMaxVolumes, kStride, ComputeBufferType.Structured);
            }
            s_Buffer.SetData(s_Data, 0, 0, count);
            return s_Buffer;
        }

        static ComputeBuffer Dummy()
        {
            EnsureCleanup();
            if (s_Dummy == null)
                s_Dummy = new ComputeBuffer(1, kStride, ComputeBufferType.Structured);
            return s_Dummy;
        }

        static void EnsureCleanup()
        {
            if (s_CleanupHooked)
                return;
            s_CleanupHooked = true;
            Application.quitting += Release;
        }

        static void Release()
        {
            s_Buffer?.Release();
            s_Buffer = null;
            s_Dummy?.Release();
            s_Dummy = null;
        }
    }
}
