// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianPolyMask : GaussianCutout
    {
        public enum ShapeType
        {
            Custom,
            Box,
            Circle,
            Hexagon,
            Star
        }

        public ShapeType m_ShapeType = ShapeType.Custom;
        public bool m_IsDrawing = false;
        public List<Vector3> m_Vertices = new List<Vector3>();
        
        [SerializeField] private bool m_IsClosed = false;
        [System.NonSerialized] private Plane m_DrawPlane;
        [SerializeField] private Vector3 m_PlaneNormal = Vector3.up;
        // m_ExtrusionDepth removed - reserved field was never used
        [SerializeField] private float m_ShapeSize = 1.0f;
        [SerializeField] private int m_CircleSegments = 16;
        [SerializeField] private int m_StarPoints = 5;
        [SerializeField] private float m_StarInnerRadius = 0.5f;
        
        public enum ExtrusionAxis { Auto, X, Y, Z }
        
        [Header("Cutout Area Expansion")]
        [SerializeField] [Range(0.01f, 3.0f)] private float m_ExpansionX = 1.0f;
        [SerializeField] [Range(0.01f, 3.0f)] private float m_ExpansionY = 1.0f;
        [Tooltip("Expand cutout area beyond visual bounds. Increase if edges don't delete enough splats.")]
        
        [Header("Cutout Area Offset")]
        [SerializeField] [Range(-2.0f, 2.0f)] private float m_OffsetX = 0.0f;
        [SerializeField] [Range(-2.0f, 2.0f)] private float m_OffsetY = 0.0f;
        [Tooltip("Shift cutout area position in local space. Use to fine-tune coverage without redrawing.")]
        
        [Header("Extrusion Settings")]
        [SerializeField] private ExtrusionAxis m_ExtrusionAxis = ExtrusionAxis.Auto;
        [SerializeField] [Range(0.1f, 100.0f)] private float m_CutDepth = 100.0f;
        [Tooltip("Auto = detect from polygon orientation | X/Y/Z = force specific extrusion axis")]

        public bool IsClosed => m_IsClosed && m_Vertices.Count >= 3;
        public override IReadOnlyList<Vector3> polygonVertices => isActiveAndEnabled && IsClosed ? m_Vertices : null;
        public override ShaderData BuildShaderData(Matrix4x4 rendererMatrix) => GetShaderData(this, rendererMatrix);
        
        /// <summary>Effective extrusion axis (for Editor gizmo: 0=Z, 1=X, 2=Y).</summary>
        public uint EffectiveExtrusionAxis => m_ExtrusionAxis == ExtrusionAxis.Auto ? DetectExtrusionAxis() : (uint)m_ExtrusionAxis;

        // Derive from serialized geometry, so old masks whose cached axis was not serialized
        // keep the same plane after a domain reload or reopening their scene.
        uint DetectExtrusionAxis()
        {
            Vector3 normal = Vector3.zero;
            for (int i = 0; i < m_Vertices.Count; i++)
                normal += Vector3.Cross(m_Vertices[i], m_Vertices[(i + 1) % m_Vertices.Count]);
            normal = new Vector3(Mathf.Abs(normal.x), Mathf.Abs(normal.y), Mathf.Abs(normal.z));
            if (normal.x > normal.y && normal.x > normal.z) return 1;
            if (normal.y > normal.z) return 2;
            return 0;
        }
        
        /// <summary>Cut depth for extrusion (for Editor gizmo).</summary>
        public float CutDepth => Mathf.Max(0.001f, m_CutDepth);
        public float ShapeSize => Mathf.Max(0.001f, m_ShapeSize);
        
        // Keep gizmos and shader geometry on the same serialized vertices, including after Undo.
        public List<Vector3> GetDisplayVertices() => m_Vertices;
        
        // Bounds properties for editor display
        public Vector3 BoundsCenter => transform.position;
        public Vector3 BoundsSize => transform.localScale * 2f;

        public void StartDrawing(Vector3 startPoint, Vector3 planeNormal)
        {
            m_IsDrawing = true;
            m_IsClosed = false;
            m_Vertices.Clear();
            m_PlaneNormal = planeNormal.sqrMagnitude > 1e-12f ? planeNormal.normalized : Vector3.forward;
            m_DrawPlane = new Plane(m_PlaneNormal, startPoint);
            AddVertex3D(startPoint);
        }

        public void AddVertex(Vector3 worldPos)
        {
            if (!m_IsDrawing) return;
            
            // The Plane itself is transient; reconstruct it from serialized drawing data.
            if (m_Vertices.Count > 0)
                m_DrawPlane = new Plane(m_PlaneNormal, transform.TransformPoint(m_Vertices[0]));
            Vector3 projectedPos = m_DrawPlane.ClosestPointOnPlane(worldPos);
            Vector3 localPos = transform.InverseTransformPoint(projectedPos);
            m_Vertices.Add(localPos);
        }

        public void AddVertex3D(Vector3 worldPos)
        {
            if (!m_IsDrawing) return;
            
            Vector3 localPos = transform.InverseTransformPoint(worldPos);
            m_Vertices.Add(localPos);
        }

        public void ClosePath()
        {
            if (m_Vertices.Count >= 3)
            {
                m_IsClosed = true;
                m_IsDrawing = false;
                
                // Auto-scale to fit bounds
                NormalizeToBounds();
            }
        }
        
        private void NormalizeToBounds()
        {
            if (m_Vertices.Count < 3) return;

            // Build the frame in parent space. This preserves the polygon under rotated and
            // non-uniformly scaled parents, unlike independently normalizing world XYZ bounds.
            var parent = transform.parent;
            var points = new Vector3[m_Vertices.Count];
            Vector3 origin = Vector3.zero;
            for (int i = 0; i < points.Length; ++i)
            {
                Vector3 world = transform.TransformPoint(m_Vertices[i]);
                points[i] = parent != null ? parent.InverseTransformPoint(world) : world;
                origin += points[i];
            }
            origin /= points.Length;
            Vector3 normal = Vector3.zero;
            for (int i = 0; i < points.Length; ++i)
                normal += Vector3.Cross(points[i] - origin, points[(i + 1) % points.Length] - origin);
            if (normal.sqrMagnitude < 1e-12f)
            {
                m_IsClosed = false;
                m_IsDrawing = true;
                return;
            }
            normal.Normalize();
            Vector3 tangent = Vector3.zero;
            for (int i = 1; i < points.Length && tangent.sqrMagnitude < 1e-12f; ++i)
                tangent = Vector3.ProjectOnPlane(points[i] - points[0], normal);
            if (tangent.sqrMagnitude < 1e-12f) return;
            tangent.Normalize();
            Vector3 bitangent = Vector3.Cross(normal, tangent).normalized;
            uint axis = m_ExtrusionAxis == ExtrusionAxis.Auto ? 0u : (uint)m_ExtrusionAxis;
            Quaternion rotation = axis == 1 ? Quaternion.LookRotation(bitangent, tangent) :
                axis == 2 ? Quaternion.LookRotation(-bitangent, normal) : Quaternion.LookRotation(normal, bitangent);
            Quaternion inverse = Quaternion.Inverse(rotation);
            Vector3 min = Vector3.one * float.MaxValue;
            Vector3 max = Vector3.one * float.MinValue;
            for (int i = 0; i < points.Length; ++i)
            {
                points[i] = inverse * (points[i] - origin);
                min = Vector3.Min(min, points[i]);
                max = Vector3.Max(max, points[i]);
            }
            Vector3 center = (min + max) * 0.5f;
            Vector3 scale = (max - min) * 0.5f;
            Vector3 depthAxis = axis == 1 ? Vector3.right : axis == 2 ? Vector3.up : Vector3.forward;
            Vector3 depthVector = rotation * depthAxis;
            float worldDepthScale = parent != null ? parent.TransformVector(depthVector).magnitude : 1f;
            float unitDepth = 1f / Mathf.Max(0.000001f, worldDepthScale);
            if (axis == 1) { scale.x = unitDepth; center.x = 0; }
            else if (axis == 2) { scale.y = unitDepth; center.y = 0; }
            else { scale.z = unitDepth; center.z = 0; }
            scale.x = Mathf.Max(0.000001f, scale.x);
            scale.y = Mathf.Max(0.000001f, scale.y);
            scale.z = Mathf.Max(0.000001f, scale.z);
            transform.localPosition = origin + rotation * center;
            transform.localRotation = rotation;
            transform.localScale = scale;
            for (int i = 0; i < points.Length; ++i)
            {
                Vector3 value = points[i] - center;
                value = new Vector3(value.x / scale.x, value.y / scale.y, value.z / scale.z);
                // A mask is a planar footprint extruded through its thickness. Slightly
                // non-planar picked vertices are projected onto the fitted plane.
                if (axis == 1) value.x = 0;
                else if (axis == 2) value.y = 0;
                else value.z = 0;
                m_Vertices[i] = value;
            }
        }

        public void Clear()
        {
            m_Vertices.Clear();
            m_IsClosed = false;
            m_IsDrawing = false;
        }
        

        public void GenerateShape(Vector3 center, Vector3 planeNormal, float size)
        {
            Clear();
            m_PlaneNormal = planeNormal.sqrMagnitude > 1e-12f ? planeNormal.normalized : Vector3.forward;
            m_DrawPlane = new Plane(m_PlaneNormal, center);
            size = Mathf.Max(0.001f, size);
            m_ShapeSize = size;
            m_CircleSegments = Mathf.Clamp(m_CircleSegments, 3, 128);
            m_StarPoints = Mathf.Clamp(m_StarPoints, 3, 64);
            m_StarInnerRadius = Mathf.Clamp(m_StarInnerRadius, 0.01f, 1f);

            Vector3 right = Vector3.Cross(m_PlaneNormal, Vector3.up);
            if (right.sqrMagnitude < 0.001f)
                right = Vector3.Cross(m_PlaneNormal, Vector3.forward);
            right.Normalize();
            
            Vector3 up = Vector3.Cross(right, m_PlaneNormal).normalized;

            switch (m_ShapeType)
            {
                case ShapeType.Box:
                    GenerateBox(center, right, up, size);
                    break;
                case ShapeType.Circle:
                    GenerateCircle(center, right, up, size);
                    break;
                case ShapeType.Hexagon:
                    GenerateHexagon(center, right, up, size);
                    break;
                case ShapeType.Star:
                    GenerateStar(center, right, up, size);
                    break;
            }

            if (m_Vertices.Count >= 3)
            {
                m_IsClosed = true;
                
                // Auto-scale for predefined shapes too
                NormalizeToBounds();
            }
        }

        private void GenerateBox(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float halfSize = size * 0.5f;
            Vector3[] corners = new Vector3[]
            {
                center + right * halfSize + up * halfSize,
                center - right * halfSize + up * halfSize,
                center - right * halfSize - up * halfSize,
                center + right * halfSize - up * halfSize
            };

            foreach (var corner in corners)
            {
                Vector3 localPos = transform.InverseTransformPoint(corner);
                m_Vertices.Add(localPos);
            }
        }

        private void GenerateCircle(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float radius = size * 0.5f;
            for (int i = 0; i < m_CircleSegments; i++)
            {
                float angle = (i / (float)m_CircleSegments) * Mathf.PI * 2f;
                Vector3 point = center + (Mathf.Cos(angle) * right + Mathf.Sin(angle) * up) * radius;
                Vector3 localPos = transform.InverseTransformPoint(point);
                m_Vertices.Add(localPos);
            }
        }

        private void GenerateHexagon(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float radius = size * 0.5f;
            for (int i = 0; i < 6; i++)
            {
                float angle = (i / 6f) * Mathf.PI * 2f;
                Vector3 point = center + (Mathf.Cos(angle) * right + Mathf.Sin(angle) * up) * radius;
                Vector3 localPos = transform.InverseTransformPoint(point);
                m_Vertices.Add(localPos);
            }
        }

        private void GenerateStar(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float outerRadius = size * 0.5f;
            float innerRadius = outerRadius * m_StarInnerRadius;
            
            for (int i = 0; i < m_StarPoints * 2; i++)
            {
                float angle = (i / (float)(m_StarPoints * 2)) * Mathf.PI * 2f;
                float radius = (i % 2 == 0) ? outerRadius : innerRadius;
                Vector3 point = center + (Mathf.Cos(angle) * right + Mathf.Sin(angle) * up) * radius;
                Vector3 localPos = transform.InverseTransformPoint(point);
                m_Vertices.Add(localPos);
            }
        }

        public static Vector2 ProjectToPolygonPlane(Vector3 point, uint axis) => axis == 1
            ? new Vector2(point.y, point.z) : axis == 2 ? new Vector2(point.x, point.z) : new Vector2(point.x, point.y);

        // Returns raw volume containment. Invert is applied by the caller when deciding what
        // to hide, just as it is in the GPU cutout path.
        public bool IsPointInside(Vector3 worldPoint)
        {
            if (!IsClosed) return false;
            Vector3 localPoint = transform.InverseTransformPoint(worldPoint);
            uint axis = EffectiveExtrusionAxis;
            float depth = axis == 1 ? localPoint.x : axis == 2 ? localPoint.y : localPoint.z;
            if (Mathf.Abs(depth) > CutDepth) return false;
            Vector2 point = ProjectToPolygonPlane(localPoint, axis);
            point.x = (point.x - m_OffsetX) / Mathf.Max(0.001f, m_ExpansionX);
            point.y = (point.y - m_OffsetY) / Mathf.Max(0.001f, m_ExpansionY);
            bool inside = false;
            Vector2 previous = ProjectToPolygonPlane(m_Vertices[m_Vertices.Count - 1], axis);
            for (int i = 0; i < m_Vertices.Count; ++i)
            {
                Vector2 current = ProjectToPolygonPlane(m_Vertices[i], axis);
                Vector2 edge = current - previous;
                float edgeLength = edge.sqrMagnitude;
                if (edgeLength > 1e-12f)
                {
                    float t = Mathf.Clamp01(Vector2.Dot(point - previous, edge) / edgeLength);
                    if ((point - (previous + edge * t)).sqrMagnitude <= 1e-12f) return true;
                }
                if ((current.y > point.y) != (previous.y > point.y) &&
                    point.x < (previous.x - current.x) * (point.y - current.y) / (previous.y - current.y) + current.x)
                    inside = !inside;
                previous = current;
            }
            return inside;
        }

        public Vector3 GetExpandedVertex(int index)
        {
            Vector3 vertex = m_Vertices[index];
            uint axis = EffectiveExtrusionAxis;
            Vector2 point = ProjectToPolygonPlane(vertex, axis);
            point = new Vector2(point.x * Mathf.Max(0.001f, m_ExpansionX) + m_OffsetX,
                point.y * Mathf.Max(0.001f, m_ExpansionY) + m_OffsetY);
            return axis == 1 ? new Vector3(0, point.x, point.y) :
                axis == 2 ? new Vector3(point.x, 0, point.y) : new Vector3(point.x, point.y, 0);
        }

        public static ShaderData GetShaderData(GaussianPolyMask self, Matrix4x4 rendererMatrix)
        {
            ShaderData sd = default;
            if (self && self.isActiveAndEnabled && self.IsClosed)
            {
                var tr = self.transform;
                
                // Use worldToLocalMatrix WITH rendererMatrix (standard cutout behavior)
                sd.matrix = tr.worldToLocalMatrix * rendererMatrix;
                
                sd.typeAndFlags = 2u | (self.m_Invert ? 0x100u : 0u);
                
                // Pass expansion, offset, and depth values to shader (real-time control)
                sd.expansionX = Mathf.Max(0.001f, self.m_ExpansionX);
                sd.expansionY = Mathf.Max(0.001f, self.m_ExpansionY);
                sd.cutDepth = self.CutDepth;
                sd.offsetX = self.m_OffsetX;
                sd.offsetY = self.m_OffsetY;
                
                sd.extrusionAxis = self.EffectiveExtrusionAxis;
            }
            else
            {
                sd.typeAndFlags = ~0u;
                sd.expansionX = 1.0f;
                sd.expansionY = 1.0f;
                sd.cutDepth = 100.0f;
                sd.extrusionAxis = 0;
                sd.offsetX = 0.0f;
                sd.offsetY = 0.0f;
                //Debug.LogWarning($"Polygon NOT active: enabled={self?.isActiveAndEnabled}, closed={self?.IsClosed}");
            }
            return sd;
        }

    }
}

