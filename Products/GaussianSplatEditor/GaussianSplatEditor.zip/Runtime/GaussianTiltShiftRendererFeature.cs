// SPDX-License-Identifier: MIT
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.RenderGraphModule.Util;

namespace GaussianSplatting.Runtime
{
    // RenderGraph context is reset between cameras/frames, so a disabled effect can never reuse
    // another camera's request or texture. The marker runs before the splat color pass is recorded.
    sealed class GaussianSplatDofFrameData : ContextItem
    {
        public bool requested;
        public TextureHandle depth;
        public override void Reset() { requested = false; depth = default; }
    }

    /// <summary>
    /// URP Renderer Feature for Tilt-Shift miniature effect on Gaussian Splats.
    /// Installed by the SplatBox Camera panel. Reads scene-saved GaussianSplatTiltShiftEffect settings.
    /// </summary>
    public class GaussianTiltShiftRendererFeature : ScriptableRendererFeature
    {
        public enum BlurMode
        {
            TiltShift = 0,
            DepthOfField = 1,
            Combined = 2
        }

        [System.Serializable]
        public class TiltShiftSettings
        {
            [Header("Blur Mode")]
            [Tooltip("TiltShift = horizontal band blur, DepthOfField = distance-based blur using scene and Gaussian splat depth, Combined = both")]
            public BlurMode blurMode = BlurMode.TiltShift;
            
            [Header("Tilt-Shift Focus")]
            [Range(0f, 1f)] public float focusPosition = 0.58f;
            [Range(0.001f, 0.8f)] public float focusWidth = 0.05f;
            [Range(-45f, 45f)] public float tiltAngle = 0f;
            
            [Header("Depth of Field")]
            [Tooltip("Distance from camera to focus point")]
            public float focusDistance = 10f;
            [Range(0.1f, 50f)] 
            [Tooltip("Range around focus distance that stays sharp")]
            public float focusRange = 5f;
            [Range(0f, 1f)] 
            [Tooltip("Blur intensity for objects closer than focus")]
            public float nearBlurStrength = 0.5f;
            [Range(0f, 1f)] 
            [Tooltip("Blur intensity for objects farther than focus")]
            public float farBlurStrength = 0.8f;
            
            [Header("Blur")]
            [Range(0f, 25f)] public float blurStrength = 10f;
            [Range(0f, 2f)] public float topBlurStrength = 1f;
            [Range(0f, 2f)] public float bottomBlurStrength = 1f;
            [Range(-0.5f, 0.5f)]
            [Tooltip("Moves the top blur edge up (+) or down (-) to align the focus band in VR.")]
            public float topBlurOffset = 0f;
            [Range(-0.5f, 0.5f)]
            [Tooltip("Moves the bottom blur edge down (+) or up (-) to align the focus band in VR.")]
            public float bottomBlurOffset = 0f;
            [Range(3, 16)] public int blurSamples = 8;
            [Range(0f, 1f)] public float bokehShape = 0.5f;
            
            [Header("Color Enhancement")]
            [Range(0.5f, 2f)] public float saturationBoost = 1f;
            [Range(0.5f, 2f)] public float contrastBoost = 1f;
            [Range(0f, 1f)] public float vignetteStrength = 0.58f;
            
            [Header("Rendering")]
            public RenderPassEvent renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
            public bool highQualityBlur = true;
            public bool enabled = true;
            
            [Header("Override")]
            [Tooltip("If true, settings from GaussianSplatTiltShiftEffect on camera will override these")]
            public bool allowCameraOverride = true;
            
            /// <summary>
            /// Copy settings from a GaussianSplatTiltShiftEffect component
            /// </summary>
            public void CopyFrom(GaussianSplatTiltShiftEffect effect)
            {
                if (effect == null) return;
                
                blurMode = (BlurMode)effect.blurMode;
                focusPosition = effect.focusPosition;
                focusWidth = effect.focusWidth;
                tiltAngle = effect.tiltAngle;
                focusDistance = effect.focusDistance;
                focusRange = effect.focusRange;
                nearBlurStrength = effect.nearBlurStrength;
                farBlurStrength = effect.farBlurStrength;
                blurStrength = effect.blurStrength;
                topBlurStrength = effect.topBlurStrength;
                bottomBlurStrength = effect.bottomBlurStrength;
                topBlurOffset = effect.topBlurOffset;
                bottomBlurOffset = effect.bottomBlurOffset;
                blurSamples = effect.blurSamples;
                bokehShape = effect.bokehShape;
                saturationBoost = effect.saturationBoost;
                contrastBoost = effect.contrastBoost;
                vignetteStrength = effect.vignetteStrength;
                highQualityBlur = effect.highQualityBlur;
                enabled = effect.effectEnabled;
            }
            
            /// <summary>
            /// Copy settings from global static settings (set by Editor Window)
            /// </summary>
            public void CopyFromGlobal()
            {
                blurMode = (BlurMode)GaussianTiltShiftGlobalSettings.BlurMode;
                focusPosition = GaussianTiltShiftGlobalSettings.FocusPosition;
                focusWidth = GaussianTiltShiftGlobalSettings.FocusWidth;
                tiltAngle = GaussianTiltShiftGlobalSettings.TiltAngle;
                focusDistance = GaussianTiltShiftGlobalSettings.FocusDistance;
                focusRange = GaussianTiltShiftGlobalSettings.FocusRange;
                nearBlurStrength = GaussianTiltShiftGlobalSettings.NearBlurStrength;
                farBlurStrength = GaussianTiltShiftGlobalSettings.FarBlurStrength;
                blurStrength = GaussianTiltShiftGlobalSettings.BlurStrength;
                topBlurStrength = GaussianTiltShiftGlobalSettings.TopBlurStrength;
                bottomBlurStrength = GaussianTiltShiftGlobalSettings.BottomBlurStrength;
                topBlurOffset = GaussianTiltShiftGlobalSettings.TopBlurOffset;
                bottomBlurOffset = GaussianTiltShiftGlobalSettings.BottomBlurOffset;
                blurSamples = GaussianTiltShiftGlobalSettings.BlurSamples;
                bokehShape = GaussianTiltShiftGlobalSettings.BokehShape;
                saturationBoost = GaussianTiltShiftGlobalSettings.SaturationBoost;
                contrastBoost = GaussianTiltShiftGlobalSettings.ContrastBoost;
                vignetteStrength = GaussianTiltShiftGlobalSettings.VignetteStrength;
                highQualityBlur = GaussianTiltShiftGlobalSettings.HighQualityBlur;
                enabled = GaussianTiltShiftGlobalSettings.Enabled;
            }
        }

        // Retain serialized defaults for legacy scenes. New looks are authored on cameras in
        // SplatBox, so the render-pass inspector no longer exposes a competing set of controls.
        [HideInInspector] public TiltShiftSettings settings = new TiltShiftSettings();
        private TiltShiftRenderPass m_RenderPass;
        private SplatDepthRequestPass m_DepthRequestPass;
        [SerializeField, HideInInspector] internal Shader m_Shader;
        private TiltShiftSettings m_RuntimeSettings;

        sealed class SplatDepthRequestPass : ScriptableRenderPass
        {
            public SplatDepthRequestPass() { renderPassEvent = RenderPassEvent.BeforeRendering; }
            public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData) =>
                frameData.GetOrCreate<GaussianSplatDofFrameData>().requested = true;
        }

#if UNITY_EDITOR
        internal static Shader FindTiltShiftShaderEditor()
        {
            var shader = Shader.Find("Hidden/Gaussian Splatting/TiltShift");
            if (shader != null)
                return shader;

            var guids = UnityEditor.AssetDatabase.FindAssets("GaussianTiltShift t:Shader");
            foreach (var guid in guids)
            {
                var path = UnityEditor.AssetDatabase.GUIDToAssetPath(guid);
                shader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>(path);
                if (shader != null && shader.name == "Hidden/Gaussian Splatting/TiltShift")
                    return shader;
            }

            return null;
        }

        internal void EnsureShaderReferenceEditor()
        {
            if (m_Shader != null)
                return;

            m_Shader = FindTiltShiftShaderEditor();
            if (m_Shader != null)
                UnityEditor.EditorUtility.SetDirty(this);
        }

        /// <summary>
        /// Auto-find and serialize the shader reference so it is available in builds.
        /// Called when the feature is created, modified, or scripts reload.
        /// </summary>
        private void OnValidate()
        {
            EnsureShaderReferenceEditor();
        }

        private void Reset()
        {
            EnsureShaderReferenceEditor();
        }
#endif

        public override void Create()
        {
            // URP may create a newly added feature once in OnEnable and again when its
            // renderer data rebuilds. Release the previous pass before replacing it.
            m_RenderPass?.Cleanup();
            m_RenderPass = null;
            m_DepthRequestPass = null;
            m_RuntimeSettings = null;
#if UNITY_EDITOR
            EnsureShaderReferenceEditor();
#endif
            // Use the serialized reference first; fall back to Shader.Find for editor/first-run
            if (m_Shader == null)
                m_Shader = Shader.Find("Hidden/Gaussian Splatting/TiltShift");
            if (m_Shader == null)
            {
                Debug.LogWarning("GaussianTiltShiftRendererFeature: Shader not found! Make sure 'Hidden/Gaussian Splatting/TiltShift' is included in the build.");
                return;
            }
            
            m_RuntimeSettings = new TiltShiftSettings();
            m_DepthRequestPass = new SplatDepthRequestPass();
            m_RenderPass = new TiltShiftRenderPass(settings, m_Shader);
            m_RenderPass.renderPassEvent = settings.renderPassEvent;
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (m_RenderPass == null)
                return;
            
            // Don't apply to preview cameras
            if (renderingData.cameraData.cameraType == CameraType.Preview)
                return;
            
            // SplatBox saves the authored look on the camera. Feature values are only a legacy
            // fallback for cameras that have not been configured in the editor window.
            var effectSettings = settings;
            var camera = renderingData.cameraData.camera;

            // Camera-component override (opt-in). Used by the VR settings menu (GaussianTiltShiftGlobalSettings
            // .SyncToCamera) so slider changes apply live in a build without touching the serialized asset.
            if (camera != null)
            {
                var cameraEffect = ResolveCameraEffect(camera);
                if (cameraEffect != null && (cameraEffect.authoredInSplatBoxEditor || settings.allowCameraOverride))
                {
                    m_RuntimeSettings.CopyFrom(cameraEffect);
                    m_RuntimeSettings.renderPassEvent = settings.renderPassEvent;
                    effectSettings = m_RuntimeSettings;
                }
            }

            // Check if effect should be disabled
            if (!effectSettings.enabled || effectSettings.blurStrength < 0.01f)
                return;
            
            // DoF mode requires depth texture
            if (effectSettings.blurMode != BlurMode.TiltShift)
            {
                if (!renderingData.cameraData.requiresDepthTexture)
                    renderingData.cameraData.requiresDepthTexture = true;
                renderer.EnqueuePass(m_DepthRequestPass);
            }
                
            m_RenderPass.Setup(effectSettings);
            renderer.EnqueuePass(m_RenderPass);
        }

        internal static GaussianSplatTiltShiftEffect ResolveCameraEffect(Camera camera)
        {
            if (camera == null) return null;
#if UNITY_EDITOR
            // SceneView.SetupCamera replaces/removes ImageEffectAllowedInSceneView components
            // before rendering. A component installed by the tool window is not a reliable
            // settings source here. Read the scene-saved look directly, including explicit Off.
            if (camera.cameraType == CameraType.SceneView)
            {
                var main = Camera.main;
                var authored = main != null ? main.GetComponent<GaussianSplatTiltShiftEffect>() : null;
                if (authored != null && authored.authoredInSplatBoxEditor)
                    return authored;
            }
#endif
            return camera.GetComponent<GaussianSplatTiltShiftEffect>();
        }

        protected override void Dispose(bool disposing)
        {
            m_RenderPass?.Cleanup();
            m_RenderPass = null;
            m_DepthRequestPass = null;
            m_RuntimeSettings = null;
        }
    }

    /// <summary>
    /// Bridge so the (URP-free) Editor Window can install the camera blur pass without referencing
    /// URP types itself. This class deliberately does NOT
    /// derive from any URP type, so the Editor assembly can call it even though it doesn't reference URP.
    /// </summary>
    public static class GaussianTiltShiftBuildSync
    {
        /// <summary>
        /// Installs the camera-override pass only on the current pipeline's Scene View renderer
        /// and the requested camera's renderer. Existing authored defaults are left intact.
        /// </summary>
        public static bool EnsureActiveRendererFeature(Camera camera, out string error)
        {
            error = null;
#if UNITY_EDITOR
            var activePipeline = QualitySettings.renderPipeline ?? GraphicsSettings.defaultRenderPipeline;
            if (activePipeline == null) return true; // Built-in uses the camera component directly.
            if (!(activePipeline is UniversalRenderPipelineAsset pipeline))
            {
                error = "Camera Blur supports the Built-in and Universal Render Pipelines. The active pipeline is not URP.";
                return false;
            }
            var pipelineSO = new UnityEditor.SerializedObject(pipeline);
            var renderers = pipelineSO.FindProperty("m_RendererDataList");
            var defaultIndex = pipelineSO.FindProperty("m_DefaultRendererIndex");
            int index = defaultIndex?.intValue ?? 0;
            if (renderers == null || !renderers.isArray || index < 0 || index >= renderers.arraySize ||
                !(renderers.GetArrayElementAtIndex(index).objectReferenceValue is ScriptableRendererData defaultRenderer))
            {
                error = "Camera Blur cannot find the default renderer in the active URP asset.";
                return false;
            }
            // URP always uses its default renderer for Scene View, even if that camera has
            // additional camera data. Game cameras may explicitly select another renderer.
            var targets = new System.Collections.Generic.List<ScriptableRendererData> { defaultRenderer };
            if (camera != null && camera.cameraType != CameraType.SceneView &&
                camera.TryGetComponent<UniversalAdditionalCameraData>(out var cameraData))
            {
                var cameraSO = new UnityEditor.SerializedObject(cameraData);
                int cameraIndex = cameraSO.FindProperty("m_RendererIndex")?.intValue ?? -1;
                if (cameraIndex >= 0 && cameraIndex < renderers.arraySize &&
                    renderers.GetArrayElementAtIndex(cameraIndex).objectReferenceValue is ScriptableRendererData cameraRenderer &&
                    cameraRenderer != defaultRenderer) targets.Add(cameraRenderer);
            }
            // Slider changes reuse the installed pass. Avoid shader searches, Undo groups and
            // asset writes once both Scene View and the selected camera are ready.
            bool allReady = true;
            foreach (var renderer in targets)
            {
                bool ready = false;
                foreach (var item in renderer.rendererFeatures)
                    if (item is GaussianTiltShiftRendererFeature blur && blur.isActive &&
                        blur.settings != null && blur.settings.allowCameraOverride && blur.m_Shader != null)
                    { ready = true; break; }
                allReady &= ready;
            }
            if (allReady) return true;

            Shader shader = GaussianTiltShiftRendererFeature.FindTiltShiftShaderEditor();
            if (shader == null)
            {
                error = "Camera Blur could not find the Gaussian Tilt-Shift shader. Check that the SplatBox shaders are imported.";
                return false;
            }
            foreach (var renderer in targets)
            {
                bool ready = false;
                foreach (var item in renderer.rendererFeatures)
                    if (item is GaussianTiltShiftRendererFeature blur && blur.isActive &&
                        blur.settings != null && blur.settings.allowCameraOverride && blur.m_Shader != null)
                    { ready = true; break; }
                if (ready) continue; // Already installed passes also work in read-only renderer assets.
                string path = UnityEditor.AssetDatabase.GetAssetPath(renderer);
                var rendererSO = new UnityEditor.SerializedObject(renderer);
                if (string.IsNullOrEmpty(path) || !UnityEditor.AssetDatabase.IsOpenForEdit(path) ||
                    rendererSO.FindProperty("m_RendererFeatures") == null ||
                    rendererSO.FindProperty("m_RendererFeatureMap") == null)
                {
                    error = $"Camera Blur cannot update renderer '{renderer.name}'. Its renderer asset must be saved and writable.";
                    return false;
                }
            }

            UnityEditor.Undo.IncrementCurrentGroup();
            int undoGroup = UnityEditor.Undo.GetCurrentGroup();
            const string undoName = "Enable Camera Blur Render Pass";
            UnityEditor.Undo.SetCurrentGroupName(undoName);
            try
            {
                foreach (var renderer in targets) EnsureCameraBlurFeature(renderer, shader, undoName);
                UnityEditor.Undo.CollapseUndoOperations(undoGroup);
                return true;
            }
            catch (System.Exception ex)
            {
                UnityEditor.Undo.FlushUndoRecordObjects();
                UnityEditor.Undo.RevertAllDownToGroup(undoGroup);
                foreach (var renderer in targets) UnityEditor.AssetDatabase.SaveAssetIfDirty(renderer);
                error = "Camera Blur could not enable its render pass: " + ex.Message;
                return false;
            }
#else
            error = "Automatic Camera Blur render-pass setup is available in the editor.";
            return false;
#endif
        }

#if UNITY_EDITOR
        static void EnsureCameraBlurFeature(ScriptableRendererData renderer, Shader shader, string undoName)
        {
            GaussianTiltShiftRendererFeature feature = null;
            foreach (var item in renderer.rendererFeatures)
                if (item is GaussianTiltShiftRendererFeature blur)
                {
                    feature ??= blur;
                    if (blur.isActive && blur.settings != null && blur.settings.allowCameraOverride && blur.m_Shader != null)
                    { feature = blur; break; }
                }
            bool append = feature == null;
            if (feature == null)
                foreach (var item in UnityEditor.AssetDatabase.LoadAllAssetsAtPath(UnityEditor.AssetDatabase.GetAssetPath(renderer)))
                    if (item is GaussianTiltShiftRendererFeature blur) { feature = blur; break; }

            if (!append && feature.isActive && feature.settings != null &&
                feature.settings.allowCameraOverride && feature.m_Shader != null) return;

            if (feature == null)
            {
                feature = ScriptableObject.CreateInstance<GaussianTiltShiftRendererFeature>();
                feature.name = "Gaussian Camera Blur";
                feature.hideFlags |= HideFlags.HideInHierarchy;
                // The Scene View toggle controls its camera override. Merely installing the pass
                // must not blur unrelated Game cameras sharing the same renderer asset.
                feature.settings.enabled = false;
                // Undo removes the renderer's list/map entry, retaining this hidden subasset.
                // Unity cannot reliably restore saved subasset membership/local IDs on creation
                // Redo; retaining it keeps Redo and the orphan-reuse path above persistent.
                UnityEditor.AssetDatabase.AddObjectToAsset(feature, renderer);
            }
            else UnityEditor.Undo.RecordObject(feature, undoName);
            feature.settings ??= new GaussianTiltShiftRendererFeature.TiltShiftSettings { enabled = false };
            feature.settings.allowCameraOverride = true;
            feature.SetActive(true);
            if (feature.m_Shader == null) feature.m_Shader = shader;

            // The persistent subasset exists before recording the renderer reference/map change.
            UnityEditor.Undo.RegisterCompleteObjectUndo(renderer, undoName);
            var rendererSO = new UnityEditor.SerializedObject(renderer);
            var features = rendererSO.FindProperty("m_RendererFeatures");
            if (append)
            {
                features.arraySize++;
                features.GetArrayElementAtIndex(features.arraySize - 1).objectReferenceValue = feature;
            }
            // URP serializes subasset local file IDs here, not instance IDs. Rebuild the map
            // alongside the references so the pass survives reimport, Undo and editor restart.
            var map = rendererSO.FindProperty("m_RendererFeatureMap");
            map.arraySize = features.arraySize;
            for (int i = 0; i < features.arraySize; i++)
            {
                var item = features.GetArrayElementAtIndex(i).objectReferenceValue;
                long localId = 0;
                if (item != null) UnityEditor.AssetDatabase.TryGetGUIDAndLocalFileIdentifier(item, out string _, out localId);
                map.GetArrayElementAtIndex(i).longValue = localId;
            }
            rendererSO.ApplyModifiedPropertiesWithoutUndo();
            renderer.SetDirty();
            UnityEditor.EditorUtility.SetDirty(feature);
            UnityEditor.EditorUtility.SetDirty(renderer);
            UnityEditor.AssetDatabase.SaveAssetIfDirty(renderer);
        }
#endif

        public static void EnsureShaderReferencesOnRenderers()
        {
#if UNITY_EDITOR
            var pipelineGuids = UnityEditor.AssetDatabase.FindAssets("t:UniversalRenderPipelineAsset");
            var visited = new System.Collections.Generic.HashSet<ScriptableRendererData>();
            bool anyChanged = false;

            foreach (var pg in pipelineGuids)
            {
                var path = UnityEditor.AssetDatabase.GUIDToAssetPath(pg);
                var pipeline = UnityEditor.AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);
                if (pipeline == null)
                    continue;

                var pipelineSO = new UnityEditor.SerializedObject(pipeline);
                var rendererDataList = pipelineSO.FindProperty("m_RendererDataList");
                if (rendererDataList == null || !rendererDataList.isArray)
                    continue;

                for (int i = 0; i < rendererDataList.arraySize; i++)
                {
                    var rd = rendererDataList.GetArrayElementAtIndex(i).objectReferenceValue as ScriptableRendererData;
                    if (rd == null || !visited.Add(rd))
                        continue;

                    foreach (var f in rd.rendererFeatures)
                    {
                        var ts = f as GaussianTiltShiftRendererFeature;
                        if (ts == null)
                            continue;

                        var before = ts.m_Shader;
                        ts.EnsureShaderReferenceEditor();
                        if (before != ts.m_Shader)
                            anyChanged = true;
                    }
                }
            }

            if (anyChanged)
                UnityEditor.AssetDatabase.SaveAssets();
#endif
        }

        /// <summary>
        /// Copies the current GaussianTiltShiftGlobalSettings into the serialized settings of every
        /// GaussianTiltShiftRendererFeature on every URP renderer asset, then saves — so the values ship in
        /// player/Android builds (where the runtime globals reset to disabled defaults).
        /// </summary>
        public static void PersistGlobalsToRenderers()
        {
#if UNITY_EDITOR
            var pipelineGuids = UnityEditor.AssetDatabase.FindAssets("t:UniversalRenderPipelineAsset");
            var visited = new System.Collections.Generic.HashSet<ScriptableRendererData>();
            bool anyChanged = false;

            foreach (var pg in pipelineGuids)
            {
                var path = UnityEditor.AssetDatabase.GUIDToAssetPath(pg);
                var pipeline = UnityEditor.AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);
                if (pipeline == null)
                    continue;

                var pipelineSO = new UnityEditor.SerializedObject(pipeline);
                var rendererDataList = pipelineSO.FindProperty("m_RendererDataList");
                if (rendererDataList == null || !rendererDataList.isArray)
                    continue;

                for (int i = 0; i < rendererDataList.arraySize; i++)
                {
                    var rd = rendererDataList.GetArrayElementAtIndex(i).objectReferenceValue as ScriptableRendererData;
                    if (rd == null || !visited.Add(rd))
                        continue;

                    foreach (var f in rd.rendererFeatures)
                    {
                        var ts = f as GaussianTiltShiftRendererFeature;
                        if (ts == null || ts.settings == null)
                            continue;

                        ts.EnsureShaderReferenceEditor();
                        ts.settings.CopyFromGlobal();
                        UnityEditor.EditorUtility.SetDirty(ts);
                        anyChanged = true;
                    }
                }
            }

            if (anyChanged)
                UnityEditor.AssetDatabase.SaveAssets();
#endif
        }
    }

#if UNITY_EDITOR
    [UnityEditor.CustomEditor(typeof(GaussianTiltShiftRendererFeature))]
    sealed class GaussianTiltShiftFeatureEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            UnityEditor.EditorGUILayout.HelpBox(
                "Tilt-Shift and Depth of Field are controlled in SplatBox > Camera. " +
                "The Main Camera is detected automatically and settings save with the scene.", UnityEditor.MessageType.Info);
            if (GUILayout.Button("Open SplatBox Camera Settings"))
                UnityEditor.EditorApplication.ExecuteMenuItem("SplatToolbox/Editor/Camera Effects");
        }
    }

    /// <summary>
    /// Hidden shaders are stripped from Android players unless a serialized asset reference keeps them alive.
    /// This hook does NOT touch values; it only makes sure the tilt-shift shader is referenced before builds.
    /// </summary>
    class GaussianTiltShiftBuildPreprocessor : UnityEditor.Build.IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(UnityEditor.Build.Reporting.BuildReport report)
        {
            GaussianTiltShiftBuildSync.EnsureShaderReferencesOnRenderers();
        }
    }
#endif

    public class TiltShiftRenderPass : ScriptableRenderPass
    {
        private GaussianTiltShiftRendererFeature.TiltShiftSettings m_Settings;
        private Material m_Material;
        
        private static readonly int PropFocusPosition = Shader.PropertyToID("_FocusPosition");
        private static readonly int PropFocusWidth = Shader.PropertyToID("_FocusWidth");
        private static readonly int PropBlurStrength = Shader.PropertyToID("_BlurStrength");
        private static readonly int PropTopBlurStrength = Shader.PropertyToID("_TopBlurStrength");
        private static readonly int PropBottomBlurStrength = Shader.PropertyToID("_BottomBlurStrength");
        private static readonly int PropTopBlurOffset = Shader.PropertyToID("_TopBlurOffset");
        private static readonly int PropBottomBlurOffset = Shader.PropertyToID("_BottomBlurOffset");
        private static readonly int PropBlurSamples = Shader.PropertyToID("_BlurSamples");
        private static readonly int PropTiltAngle = Shader.PropertyToID("_TiltAngle");
        private static readonly int PropSaturationBoost = Shader.PropertyToID("_SaturationBoost");
        private static readonly int PropContrastBoost = Shader.PropertyToID("_ContrastBoost");
        private static readonly int PropVignetteStrength = Shader.PropertyToID("_VignetteStrength");
        private static readonly int PropBokehShape = Shader.PropertyToID("_BokehShape");
        private static readonly int PropBlurMode = Shader.PropertyToID("_BlurMode");
        private static readonly int PropFocusDistance = Shader.PropertyToID("_FocusDistance");
        private static readonly int PropFocusRange = Shader.PropertyToID("_FocusRange");
        private static readonly int PropNearBlurStrength = Shader.PropertyToID("_NearBlurStrength");
        private static readonly int PropFarBlurStrength = Shader.PropertyToID("_FarBlurStrength");
        private static readonly int PropSplatDofDepth = Shader.PropertyToID("_GaussianSplatDofDepth");
        private static readonly int PropSplatDofDepthValid = Shader.PropertyToID("_GaussianSplatDofDepthValid");
        private static readonly int PropSplatDofDepthFlipY = Shader.PropertyToID("_GaussianSplatDofDepthFlipY");
        private static readonly int PropCameraDepth = Shader.PropertyToID("_CameraDepthTexture");

        sealed class DepthBindingPassData
        {
            public TextureHandle source, cameraDepth, splatDepth;
            public UniversalCameraData cameraData;
            public MaterialPropertyBlock properties;
            public bool hasSplatDepth;
        }

        public TiltShiftRenderPass(GaussianTiltShiftRendererFeature.TiltShiftSettings settings, Shader shader)
        {
            m_Settings = settings;
            
            if (shader != null)
                m_Material = CoreUtils.CreateEngineMaterial(shader);
        }

        public void Setup(GaussianTiltShiftRendererFeature.TiltShiftSettings settings)
        {
            m_Settings = settings;
            renderPassEvent = settings.renderPassEvent;
            if (settings.blurMode != GaussianTiltShiftRendererFeature.BlurMode.TiltShift &&
                (int)renderPassEvent < (int)RenderPassEvent.BeforeRenderingPostProcessing)
                renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;

            // A fullscreen effect must never sample the XR backbuffer directly. This makes URP allocate
            // a sampleable camera color texture on Quest as well as in the Editor.
            requiresIntermediateTexture = true;

            // Only DoF/Combined need a depth copy. Camera color is represented by the intermediate
            // requirement above; requesting Color here would create an unnecessary opaque-texture copy.
            if (settings.blurMode != GaussianTiltShiftRendererFeature.BlurMode.TiltShift)
                ConfigureInput(ScriptableRenderPassInput.Depth);
            else
                ConfigureInput(ScriptableRenderPassInput.None);
        }

        private void UpdateMaterialProperties(MaterialPropertyBlock properties)
        {
            if (m_Material == null) return;
            
            properties.SetFloat(PropBlurMode, (float)m_Settings.blurMode);
            properties.SetFloat(PropFocusPosition, m_Settings.focusPosition);
            properties.SetFloat(PropFocusWidth, m_Settings.focusWidth);
            properties.SetFloat(PropTiltAngle, m_Settings.tiltAngle);
            properties.SetFloat(PropFocusDistance, m_Settings.focusDistance);
            properties.SetFloat(PropFocusRange, m_Settings.focusRange);
            properties.SetFloat(PropNearBlurStrength, m_Settings.nearBlurStrength);
            properties.SetFloat(PropFarBlurStrength, m_Settings.farBlurStrength);
            properties.SetFloat(PropBlurStrength, m_Settings.blurStrength);
            properties.SetFloat(PropTopBlurStrength, m_Settings.topBlurStrength);
            properties.SetFloat(PropBottomBlurStrength, m_Settings.bottomBlurStrength);
            properties.SetFloat(PropTopBlurOffset, m_Settings.topBlurOffset);
            properties.SetFloat(PropBottomBlurOffset, m_Settings.bottomBlurOffset);
            properties.SetFloat(PropBlurSamples, m_Settings.blurSamples);
            properties.SetFloat(PropBokehShape, m_Settings.bokehShape);
            properties.SetFloat(PropSaturationBoost, m_Settings.saturationBoost);
            properties.SetFloat(PropContrastBoost, m_Settings.contrastBoost);
            properties.SetFloat(PropVignetteStrength, m_Settings.vignetteStrength);
        }

        private static TextureHandle CreateFullscreenTexture(
            RenderGraph renderGraph,
            TextureDesc sourceDesc,
            string name)
        {
            sourceDesc.name = name;
            sourceDesc.clearBuffer = false;
            sourceDesc.msaaSamples = MSAASamples.None;
            sourceDesc.depthBufferBits = DepthBits.None;
            return renderGraph.CreateTexture(sourceDesc);
        }

        private static void AddFullscreenBlit(
            RenderGraph renderGraph,
            TextureHandle source,
            TextureHandle destination,
            Material material,
            int shaderPass,
            string passName,
            MaterialPropertyBlock properties,
            TextureHandle cameraDepth,
            TextureHandle splatDepth)
        {
            var parameters = new RenderGraphUtils.BlitMaterialParameters(
                source, destination, material, shaderPass);
            parameters.propertyBlock = properties;

            // AddBlitPass handles XR texture slices (including Single Pass Instanced) correctly.
            // Fullscreen image processing must not inherit Quest's non-uniform foveated rasterization.
            using var builder = renderGraph.AddBlitPass(parameters, passName, true);
            if (cameraDepth.IsValid()) builder.UseTexture(cameraDepth, AccessFlags.Read);
            if (splatDepth.IsValid()) builder.UseTexture(splatDepth, AccessFlags.Read);
            builder.EnableFoveatedRasterization(false);
        }

        static void BindDepthTextures(RenderGraph renderGraph, TextureHandle source, TextureHandle cameraDepth,
            TextureHandle splatDepth, bool hasSplatDepth, UniversalCameraData cameraData, MaterialPropertyBlock properties)
        {
            using var builder = renderGraph.AddUnsafePass<DepthBindingPassData>("Camera Blur Depth Inputs", out var pass);
            pass.cameraDepth = cameraDepth;
            pass.splatDepth = splatDepth;
            pass.source = source;
            pass.cameraData = cameraData;
            pass.properties = properties;
            pass.hasSplatDepth = hasSplatDepth;
            builder.UseTexture(source, AccessFlags.Read);
            if (cameraDepth.IsValid()) builder.UseTexture(cameraDepth, AccessFlags.Read);
            if (splatDepth.IsValid()) builder.UseTexture(splatDepth, AccessFlags.Read);
            builder.AllowGlobalStateModification(true);
            builder.AllowPassCulling(false);
            builder.SetRenderFunc(static (DepthBindingPassData data, UnsafeGraphContext context) =>
            {
                var cmd = CommandBufferHelpers.GetNativeCommandBuffer(context.cmd);
                if (data.cameraDepth.IsValid()) cmd.SetGlobalTexture(PropCameraDepth, data.cameraDepth);
                if (data.splatDepth.IsValid()) cmd.SetGlobalTexture(PropSplatDofDepth, data.splatDepth);
                float flipY = 0f;
                if (data.hasSplatDepth)
                {
                    // Resolve RenderGraph handles only during execution, after allocation.
                    RTHandle sourceHandle = data.source, depthHandle = data.splatDepth;
                    flipY = data.cameraData.IsHandleYFlipped(sourceHandle) !=
                        data.cameraData.IsHandleYFlipped(depthHandle) ? 1f : 0f;
                }
                data.properties.SetFloat(PropSplatDofDepthFlipY, flipY);
            });
        }

        // URP 17.3+ removed OnCameraSetup/Execute. RecordRenderGraph is the only path.
        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            if (m_Material == null)
                return;

            var resourceData = frameData.Get<UniversalResourceData>();

            // Setup requires an intermediate texture. If URP still exposes the backbuffer, sampling it is
            // unsupported; skipping is safer than an undefined read/write feedback loop.
            if (resourceData.isActiveTargetBackBuffer || !resourceData.activeColorTexture.IsValid())
                return;

            TextureHandle source = resourceData.activeColorTexture;
            TextureDesc desc = renderGraph.GetTextureDesc(source);
            TextureHandle cameraDepth = default, splatDepth = default;
            bool depthMode = m_Settings.blurMode != GaussianTiltShiftRendererFeature.BlurMode.TiltShift;
            if (depthMode)
            {
                cameraDepth = resourceData.cameraDepthTexture;
                if (frameData.Contains<GaussianSplatDofFrameData>())
                    splatDepth = frameData.Get<GaussianSplatDofFrameData>().depth;
            }
            bool hasSplatDepth = splatDepth.IsValid();
            // Always provide valid, XR-shaped descriptors. A second camera with no splats must
            // never sample an expired texture from the previous camera, even in a branched shader.
            if (!splatDepth.IsValid()) splatDepth = renderGraph.defaultResources.blackTextureXR;
            if (!cameraDepth.IsValid()) cameraDepth = SystemInfo.usesReversedZBuffer
                ? renderGraph.defaultResources.blackTextureXR : renderGraph.defaultResources.whiteTextureXR;
            var properties = new MaterialPropertyBlock();
            UpdateMaterialProperties(properties);
            properties.SetInt(PropSplatDofDepthValid, hasSplatDepth ? 1 : 0);
            BindDepthTextures(renderGraph, source, cameraDepth, splatDepth, hasSplatDepth,
                frameData.Get<UniversalCameraData>(), properties);

            TextureHandle output;
            if (m_Settings.highQualityBlur)
            {
                TextureHandle tempH = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftHorizontal");
                TextureHandle tempV = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftVertical");
                output = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftOutput");

                AddFullscreenBlit(renderGraph, source, tempH, m_Material, 0, "TiltShift Horizontal", properties, cameraDepth, splatDepth);
                AddFullscreenBlit(renderGraph, tempH, tempV, m_Material, 1, "TiltShift Vertical", properties, cameraDepth, splatDepth);
                AddFullscreenBlit(renderGraph, tempV, output, m_Material, 2, "TiltShift Enhance", properties, cameraDepth, splatDepth);
            }
            else
            {
                output = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftOutput");
                AddFullscreenBlit(renderGraph, source, output, m_Material, 3, "TiltShift Combined", properties, cameraDepth, splatDepth);
            }

            // Make every later URP pass (post-processing/final XR blit) consume the processed texture.
            // Swapping the graph resource is XR-safe and avoids writing back into the sampled camera color.
            resourceData.cameraColor = output;
        }

        public void Cleanup()
        {
            if (m_Material != null)
            {
                CoreUtils.Destroy(m_Material);
                m_Material = null;
            }
        }
    }
}
