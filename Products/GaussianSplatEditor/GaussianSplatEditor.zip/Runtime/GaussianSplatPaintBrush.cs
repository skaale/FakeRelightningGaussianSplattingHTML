// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatPaintBrush : MonoBehaviour
    {
        public static bool IsBrushModeActive = false;
        public static bool HasValidBrushPosition = false;
        public static Vector3 LastBrushPosition;
        public static Vector3 CurrentViewDirection;
        public static float CurrentWorldRadius;
        public static bool IsPainting = false;
        public static bool IsSampling = false;
        
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] private float m_ScreenRadius = 1.5f;
        [SerializeField] private float m_PaintDensity = 1f;
        [SerializeField] private float m_SplatSizeMultiplier = 0.1f; // Multiplier of worldRadius
        [SerializeField] private int m_SplatsPerStroke = 5;
        [SerializeField] private int m_SamplePixelRadius = 25;
        
        [Header("Custom Color")]
        [SerializeField] private bool m_UseCustomColor = false;
        [SerializeField] private Color m_CustomColor = Color.white;
        [SerializeField] private float m_ColorVariation = 0f; // 0-1, adds random variation to custom color
        
        [Header("Performance")]
        [SerializeField] private bool m_FastPaintMode = true; // Skip surface detection during drag
        [SerializeField] private bool m_UseGPUPaint = true; // Use fully GPU-based painting (zero CPU allocation)
        [SerializeField] private int m_BatchSize = 100; // Pre-allocate batch buffer
        
        [Header("Layering")]
        [SerializeField] private float m_LayerSpacing = 0.002f; // Distance between stroke layers
        [SerializeField] private bool m_EnableLayering = true; // Stack strokes on top of each other
        
        [Header("Texture Paint")]
        [SerializeField] private bool m_UseTexturePaint = false;
        [SerializeField] private int m_ActiveTextureSlot = 0; // 0-2
        [SerializeField] private float m_TextureTileScale = 1f;
        [SerializeField] private float m_TextureRotation = 0f;
        
        // 3 texture slots for captured textures
        private Texture2D[] m_TextureSlots = new Texture2D[3];
        private Color[][] m_TextureColorCache = new Color[3][];
        
        private List<Color> m_SampledColors = new List<Color>();
        private Vector3 m_SamplePosition;
        private bool m_HasSampledColors = false;
        
        // Track buffer state to avoid constant reallocation
        private SplatBoxRenderer m_PaintOutputRenderer;
        private int m_AllocatedCapacity = 0;
        private int m_NextWriteIndex = 0;
        private readonly Color[] m_ColorSampleBuffer = new Color[500];
        
        // Fast paint caching
        private Vector3 m_CachedSurfacePos;
        private float m_CachedSurfaceDepth;
        private bool m_HasCachedSurface = false;
        private float m_LastSurfaceUpdateTime;
        private const float SURFACE_UPDATE_INTERVAL = 0.2f; // Update surface every 200ms (less frequent = smoother)
        private Camera m_SurfaceCamera;
        private Matrix4x4 m_SurfaceViewMatrix;
        private Matrix4x4 m_SurfaceProjectionMatrix;
        private Matrix4x4 m_SurfaceSourceMatrix;
        private bool m_HasSurfaceQuery;
        private float m_SurfaceSearchRadius;
        
        // Layering state
        private int m_CurrentStrokeLayer = 0;
        private Vector3 m_LastLayerViewDir;
        
        // Batch paint buffers (reused to avoid allocation)
        private Vector3[] m_BatchPositions;
        private Color[] m_BatchColors;
        private float[] m_BatchSizes;
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set
            {
                if (m_TargetRenderer == value) return;
                m_TargetRenderer = value;
                m_PaintOutputRenderer = null;
                ResetBufferState();
            }
        }

        // Paged and compressed sources are sampled in place while new splats are written
        // to an editable stroke object. This transient reference is managed by the editor.
        public SplatBoxRenderer PaintOutputRenderer
        {
            get => m_PaintOutputRenderer;
            set
            {
                if (m_PaintOutputRenderer == value) return;
                m_PaintOutputRenderer = value;
                m_AllocatedCapacity = 0;
                m_NextWriteIndex = 0;
            }
        }

        public int PaintedSplatEndIndex => m_NextWriteIndex;
        SplatBoxRenderer WriteRenderer => m_PaintOutputRenderer != null ? m_PaintOutputRenderer : m_TargetRenderer;
        
        public float ScreenRadius
        {
            get => m_ScreenRadius;
            set => m_ScreenRadius = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public float PaintDensity
        {
            get => m_PaintDensity;
            set => m_PaintDensity = Mathf.Clamp(value, 0.1f, 2f);
        }
        
        public float SplatSizeMultiplier
        {
            get => m_SplatSizeMultiplier;
            set => m_SplatSizeMultiplier = Mathf.Clamp(value, 0.01f, 1f);
        }
        
        public int SplatsPerStroke
        {
            get => m_SplatsPerStroke;
            set => m_SplatsPerStroke = Mathf.Clamp(value, 1, 50);
        }
        
        public int SamplePixelRadius
        {
            get => m_SamplePixelRadius;
            set => m_SamplePixelRadius = Mathf.Clamp(value, 5, 100);
        }
        
        public bool UseCustomColor
        {
            get => m_UseCustomColor;
            set => m_UseCustomColor = value;
        }
        
        public Color CustomColor
        {
            get => m_CustomColor;
            set => m_CustomColor = value;
        }
        
        public float ColorVariation
        {
            get => m_ColorVariation;
            set => m_ColorVariation = Mathf.Clamp01(value);
        }
        
        public bool FastPaintMode
        {
            get => m_FastPaintMode;
            set => m_FastPaintMode = value;
        }
        
        public bool UseGPUPaint
        {
            get => m_UseGPUPaint;
            set => m_UseGPUPaint = value;
        }
        
        public int BatchSize
        {
            get => m_BatchSize;
            set => m_BatchSize = Mathf.Clamp(value, 10, 500);
        }
        
        public float LayerSpacing
        {
            get => m_LayerSpacing;
            set => m_LayerSpacing = Mathf.Clamp(value, 0.0001f, 0.1f);
        }
        
        public bool EnableLayering
        {
            get => m_EnableLayering;
            set => m_EnableLayering = value;
        }
        
        public int CurrentStrokeLayer => m_CurrentStrokeLayer;
        
        public bool UseTexturePaint
        {
            get => m_UseTexturePaint;
            set => m_UseTexturePaint = value;
        }
        
        public int ActiveTextureSlot
        {
            get => m_ActiveTextureSlot;
            set => m_ActiveTextureSlot = Mathf.Clamp(value, 0, 2);
        }
        
        public float TextureTileScale
        {
            get => m_TextureTileScale;
            set => m_TextureTileScale = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public float TextureRotation
        {
            get => m_TextureRotation;
            set => m_TextureRotation = value;
        }
        
        public Texture2D GetTextureSlot(int slot) => slot >= 0 && slot < 3 ? m_TextureSlots[slot] : null;
        public bool HasTextureInSlot(int slot) => slot >= 0 && slot < 3 && m_TextureSlots[slot] != null;
        public bool HasActiveTexture => m_UseTexturePaint && HasTextureInSlot(m_ActiveTextureSlot);
        
        public bool HasSampledColors => m_HasSampledColors && m_SampledColors.Count > 0;
        public int SampledColorCount => m_SampledColors.Count;
        public Vector3 SamplePosition => m_SamplePosition;
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset;
        
        /// <summary>
        /// Sample colors from splats directly under the cursor ray
        /// </summary>
        public void SampleColorsAtRay(Ray ray, Camera cam, float referenceDepth, float screenRadius = 300f)
        {
            ClearSampledColors();
            if (!IsValid || !m_TargetRenderer.HasValidRenderSetup || cam == null ||
                !TryGetRayScreenPoint(ray, cam, referenceDepth, out Vector2 screenPoint)) return;
            // Decode through LoadSplatData on the GPU: paged remaps, packed/chunked positions
            // and compressed color textures cannot be interpreted as a Float32 CPU array.
            if (!m_TargetRenderer.TryGetPaintSurfaceDepth(cam, screenPoint, screenRadius, out float depth)) return;
            float depthTolerance = Mathf.Max(0.05f, depth * 0.02f);
            if (!m_TargetRenderer.SamplePaintColors(cam, screenPoint, screenRadius, depth,
                depthTolerance, m_ColorSampleBuffer, out int count)) return;
            for (int i = 0; i < Mathf.Min(count, m_ColorSampleBuffer.Length); ++i)
                m_SampledColors.Add(m_ColorSampleBuffer[i]);
            m_HasSampledColors = m_SampledColors.Count > 0;
            var plane = new Plane(-cam.transform.forward, cam.transform.position + cam.transform.forward * depth);
            if (plane.Raycast(ray, out float distance)) m_SamplePosition = ray.GetPoint(distance);
        }

        /// <summary>Pre-allocate only the editable output; the sampled source is never resized.</summary>
        public void EnsureCapacity(int neededSlots = 500)
        {
            var output = WriteRenderer;
            if (!IsValid || output == null || !output.SupportsInPlacePaint || !output.HasValidRenderSetup || neededSlots <= 0) return;
            int currentCapacity = output.splatCount;
            if (m_AllocatedCapacity == 0 || m_NextWriteIndex == 0 || currentCapacity < m_NextWriteIndex)
            {
                m_AllocatedCapacity = currentCapacity;
                m_NextWriteIndex = currentCapacity;
            }
            else
                m_AllocatedCapacity = currentCapacity;
            if (m_AllocatedCapacity - m_NextWriteIndex >= neededSlots) return;
            long requested = (long)m_AllocatedCapacity + Mathf.Max(neededSlots, 2000);
            requested = (requested / 1000 + 1) * 1000;
            if (requested > GaussianSplatAsset.kMaxSplats) return;
            try
            {
                output.EditSetSplatCount((int)requested);
                // EditSetSplatCount can reject without throwing. Never assume its request
                // succeeded or advance past the actual buffer when that happens.
                m_AllocatedCapacity = output.splatCount;
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Could not expand paint output: {e.Message}");
            }
        }

        static bool TryGetRayScreenPoint(Ray ray, Camera cam, float referenceDepth, out Vector2 point)
        {
            point = Vector2.zero;
            if (cam == null) return false;
            Vector3 viewport = cam.WorldToViewportPoint(ray.GetPoint(Mathf.Max(cam.nearClipPlane + 1f, referenceDepth)));
            if (viewport.z <= 0 || float.IsNaN(viewport.x) || float.IsInfinity(viewport.x) ||
                float.IsNaN(viewport.y) || float.IsInfinity(viewport.y)) return false;
            // Viewport coordinates avoid pixelRect offsets and remain correct for Scene
            // view HiDPI cameras, render textures, and orthographic cameras.
            point = new Vector2(viewport.x * cam.pixelWidth, viewport.y * cam.pixelHeight);
            return true;
        }

        /// <summary>Finds the visible source surface without reading its packed position buffer.</summary>
        public Vector3? FindSplatSurfaceFromRay(Ray ray, Camera cam, float referenceDepth, float screenSearchRadius = 300f) =>
            FindSplatSurfaceFromRay(ray, cam, referenceDepth, screenSearchRadius, false);

        /// <summary>Force refresh when starting a new placement after editing.</summary>
        public Vector3? FindSplatSurfaceFromRay(Ray ray, Camera cam, float referenceDepth,
            float screenSearchRadius, bool forceRefresh)
        {
            var renderer = m_TargetRenderer;
            if (renderer == null || !renderer.HasValidAsset || !renderer.HasValidRenderSetup || cam == null ||
                !TryGetRayScreenPoint(ray, cam, referenceDepth, out Vector2 screenPoint)) return null;
            float now = Time.realtimeSinceStartup;
            bool sameView = m_SurfaceCamera == cam && m_SurfaceViewMatrix == cam.worldToCameraMatrix &&
                m_SurfaceProjectionMatrix == cam.projectionMatrix && m_SurfaceSourceMatrix == renderer.transform.localToWorldMatrix &&
                Mathf.Approximately(m_SurfaceSearchRadius, screenSearchRadius);
            float interval = IsPainting ? (m_FastPaintMode ? SURFACE_UPDATE_INTERVAL : 0f) : 0.1f;
            if (forceRefresh || !m_HasSurfaceQuery || !sameView || now - m_LastSurfaceUpdateTime >= interval)
            {
                m_SurfaceCamera = cam;
                m_SurfaceViewMatrix = cam.worldToCameraMatrix;
                m_SurfaceProjectionMatrix = cam.projectionMatrix;
                m_SurfaceSourceMatrix = renderer.transform.localToWorldMatrix;
                m_SurfaceSearchRadius = screenSearchRadius;
                m_HasCachedSurface = renderer.TryGetPaintSurfaceDepth(cam, screenPoint, screenSearchRadius, out m_CachedSurfaceDepth);
                m_LastSurfaceUpdateTime = now;
                m_HasSurfaceQuery = true;
            }
            if (!m_HasCachedSurface) return null;
            var plane = new Plane(-cam.transform.forward, cam.transform.position + cam.transform.forward * m_CachedSurfaceDepth);
            if (!plane.Raycast(ray, out float distance) || distance < 0) return null;
            m_CachedSurfacePos = ray.GetPoint(distance);
            return m_CachedSurfacePos;
        }

        bool PreparePaint(Ray ray, Camera cam, float worldRadius, Vector3 viewDir, float referenceDepth,
            out SplatBoxRenderer output, out Vector3 localCenter, out Vector3 right, out Vector3 up,
            out float localScatterRadius, out float splatSize)
        {
            output = WriteRenderer;
            localCenter = right = up = Vector3.zero;
            localScatterRadius = splatSize = 0;
            if (!IsValid || cam == null || output == null || !output.SupportsInPlacePaint ||
                !output.HasValidRenderSetup || worldRadius <= 0 || float.IsNaN(worldRadius) || float.IsInfinity(worldRadius)) return false;
            EnsureCapacity(m_SplatsPerStroke + m_BatchSize);
            if (m_NextWriteIndex < 0 || (long)m_NextWriteIndex + m_SplatsPerStroke > output.splatCount) return false;

            Vector3 paintWorldPos = FindSplatSurfaceFromRay(ray, cam, referenceDepth, 300f) ?? ray.GetPoint(referenceDepth);
            viewDir.Normalize();
            if (m_EnableLayering && m_CurrentStrokeLayer > 0)
                paintWorldPos -= viewDir * (m_CurrentStrokeLayer * m_LayerSpacing);
            m_LastLayerViewDir = viewDir;
            Transform target = output.transform;
            float rendererScale = target.lossyScale.magnitude / Mathf.Sqrt(3f);
            localScatterRadius = worldRadius;
            splatSize = worldRadius * m_SplatSizeMultiplier / Mathf.Max(rendererScale, 0.001f);
            localCenter = target.InverseTransformPoint(paintWorldPos);
            BuildPaintScatterBasis(target.worldToLocalMatrix, viewDir, out right, out up);
            return true;
        }

        static void BuildPaintScatterBasis(Matrix4x4 worldToLocal, Vector3 viewDir, out Vector3 right, out Vector3 up)
        {
            viewDir.Normalize();
            Vector3 worldRight = Vector3.Cross(Vector3.up, viewDir);
            if (worldRight.sqrMagnitude < 0.001f) worldRight = Vector3.Cross(Vector3.forward, viewDir);
            worldRight.Normalize();
            Vector3 worldUp = Vector3.Cross(viewDir, worldRight).normalized;
            // Preserve lengths under nonuniform source/output scale. Normalizing these
            // local vectors would turn a circular world brush into a stretched ellipse.
            right = worldToLocal.MultiplyVector(worldRight);
            up = worldToLocal.MultiplyVector(worldUp);
        }

        void EnsureBatchBuffers()
        {
            if (m_BatchPositions != null && m_BatchPositions.Length >= m_SplatsPerStroke) return;
            int capacity = Mathf.Max(m_SplatsPerStroke, 50);
            m_BatchPositions = new Vector3[capacity];
            m_BatchColors = new Color[capacity];
            m_BatchSizes = new float[capacity];
        }

        /// <summary>Appends splats to the editable output, sampling placement from the source.</summary>
        public void PaintAtRay(Ray ray, Camera cam, float worldRadius, Vector3 viewDir, float referenceDepth)
        {
            if (!PreparePaint(ray, cam, worldRadius, viewDir, referenceDepth, out var output,
                out var localCenter, out var right, out var up, out float scatterRadius, out float size)) return;
            if (m_UseGPUPaint)
            {
                output.PaintSplatsGPU(m_NextWriteIndex, localCenter, scatterRadius, size, GetBasePaintColor(),
                    m_UseCustomColor ? m_ColorVariation : 0f, right, up, m_SplatsPerStroke, m_PaintDensity);
            }
            else
            {
                EnsureBatchBuffers();
                for (int i = 0; i < m_SplatsPerStroke; ++i)
                {
                    float angle = Random.Range(0f, Mathf.PI * 2f);
                    float distance = Mathf.Sqrt(Random.value) * scatterRadius;
                    m_BatchPositions[i] = localCenter + right * (Mathf.Cos(angle) * distance) + up * (Mathf.Sin(angle) * distance);
                    m_BatchColors[i] = GetNextPaintColor();
                    m_BatchSizes[i] = size;
                }
                if (!output.PaintSplatsBatch(m_NextWriteIndex, m_BatchPositions, m_BatchSizes, m_BatchColors, m_SplatsPerStroke, m_PaintDensity))
                    return;
            }
            m_NextWriteIndex += m_SplatsPerStroke;
        }

        /// <summary>
        /// Get base paint color for GPU path (no variation, that's done on GPU)
        /// </summary>
        private Color GetBasePaintColor()
        {
            if (m_UseCustomColor)
                return m_CustomColor;
            if (m_HasSampledColors && m_SampledColors.Count > 0)
                return GetAverageColor();
            return new Color(0.5f, 0.5f, 0.5f, 1f);
        }
        
        /// <summary>
        /// Get next paint color (fast path, pre-calculated variation)
        /// </summary>
        private Color GetNextPaintColor()
        {
            if (m_UseCustomColor)
                return VaryPaintColor(m_CustomColor);
            
            if (m_HasSampledColors && m_SampledColors.Count > 0)
                return m_SampledColors[Random.Range(0, m_SampledColors.Count)];
            
            return new Color(0.5f, 0.5f, 0.5f, 1f);
        }

        Color VaryPaintColor(Color color)
        {
            if (m_ColorVariation <= 0) return color;
            Color.RGBToHSV(color, out float hue, out float saturation, out float value);
            hue = Mathf.Repeat(hue + Random.Range(-m_ColorVariation,m_ColorVariation)*0.1f,1f);
            saturation = Mathf.Clamp01(saturation + Random.Range(-m_ColorVariation,m_ColorVariation)*0.2f);
            value = Mathf.Clamp01(value + Random.Range(-m_ColorVariation,m_ColorVariation)*0.15f);
            Color result = Color.HSVToRGB(hue,saturation,value);
            result.a = color.a;
            return result;
        }
        
        /// <summary>
        /// Clear cached surface on paint start, increment layer for stacking
        /// </summary>
        public void BeginPaintStroke()
        {
            m_HasCachedSurface = false;
            m_HasSurfaceQuery = false;
            m_LastSurfaceUpdateTime = 0;
            
            // Increment layer for each new stroke (strokes stack on top of each other)
            if (m_EnableLayering)
                m_CurrentStrokeLayer++;
        }
        
        /// <summary>
        /// Reset layer counter (call when switching tools or clearing)
        /// </summary>
        public void ResetLayers()
        {
            m_CurrentStrokeLayer = 0;
        }
        
        /// <summary>
        /// Get the surface position for brush preview display
        /// </summary>
        public Vector3? GetSurfacePositionForPreview(Ray ray, Camera cam, float referenceDepth)
        {
            return FindSplatSurfaceFromRay(ray, cam, referenceDepth, 300f);
        }
        
        public void ClearSampledColors()
        {
            m_SampledColors.Clear();
            m_HasSampledColors = false;
        }
        
        public void ResetBufferState()
        {
            m_AllocatedCapacity = 0;
            m_NextWriteIndex = 0;
            m_CurrentStrokeLayer = 0;
            m_HasCachedSurface = false;
            m_HasSurfaceQuery = false;
            m_SurfaceCamera = null;
            m_LastSurfaceUpdateTime = 0;
        }
        
        public Color GetAverageColor()
        {
            if (!m_HasSampledColors) return Color.gray;
            
            Vector4 sum = Vector4.zero;
            foreach (var c in m_SampledColors)
                sum += new Vector4(c.r, c.g, c.b, c.a);
            
            sum /= m_SampledColors.Count;
            return new Color(sum.x, sum.y, sum.z, sum.w);
        }
        
        public Color GetRandomSampledColor()
        {
            if (!m_HasSampledColors) return Color.gray;
            return m_SampledColors[Random.Range(0, m_SampledColors.Count)];
        }
        
        /// <summary>
        /// Set custom color from a sampled/picked color
        /// </summary>
        public void SetCustomColorFromSample(Color color)
        {
            m_CustomColor = color;
            m_UseCustomColor = true;
        }
        
        /// <summary>
        /// Add a sampled color to the palette (for eyedropper)
        /// </summary>
        public void AddSampledColor(Color color)
        {
            m_SampledColors.Add(color);
            m_HasSampledColors = true;
        }
        
        /// <summary>
        /// Get the current paint color (for preview)
        /// </summary>
        public Color GetCurrentPaintColor()
        {
            if (m_UseTexturePaint && HasTextureInSlot(m_ActiveTextureSlot))
                return GetTextureCenterColor(m_ActiveTextureSlot);
            if (m_UseCustomColor)
                return m_CustomColor;
            if (m_HasSampledColors && m_SampledColors.Count > 0)
                return GetAverageColor();
            return Color.gray;
        }
        
        /// <summary>
        /// Get center color from texture slot for preview
        /// </summary>
        private Color GetTextureCenterColor(int slot)
        {
            var tex = m_TextureSlots[slot];
            if (tex == null) return Color.gray;
            return tex.GetPixelBilinear(0.5f, 0.5f);
        }
        
        /// <summary>
        /// Capture screen rect to texture slot
        /// </summary>
        public void CaptureTextureFromScreen(Rect screenRect, int slot, Camera cam)
        {
            if (slot < 0 || slot > 2 || cam == null) return;
            
            int x = Mathf.Max(0, (int)screenRect.x);
            int y = Mathf.Max(0, (int)screenRect.y);
            int w = Mathf.Min((int)screenRect.width, Screen.width - x);
            int h = Mathf.Min((int)screenRect.height, Screen.height - y);
            
            if (w <= 0 || h <= 0) return;
            
            // Cleanup old texture
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.ReadPixels(new Rect(x, y, w, h), 0, 0);
            tex.Apply();
            
            m_TextureSlots[slot] = tex;
            m_TextureColorCache[slot] = tex.GetPixels();
            
            Debug.Log($"Captured {w}x{h} texture to slot {slot + 1}");
        }
        
        /// <summary>
        /// Capture from RenderTexture to slot
        /// </summary>
        public void CaptureTextureFromRT(RenderTexture rt, Rect captureRect, int slot)
        {
            if (slot < 0 || slot > 2 || rt == null) return;
            
            var prevActive = RenderTexture.active;
            RenderTexture.active = rt;
            
            int x = Mathf.Max(0, (int)captureRect.x);
            int y = Mathf.Max(0, (int)captureRect.y);
            int w = Mathf.Min((int)captureRect.width, rt.width - x);
            int h = Mathf.Min((int)captureRect.height, rt.height - y);
            
            if (w <= 0 || h <= 0)
            {
                RenderTexture.active = prevActive;
                return;
            }
            
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.ReadPixels(new Rect(x, y, w, h), 0, 0);
            tex.Apply();
            
            RenderTexture.active = prevActive;
            
            m_TextureSlots[slot] = tex;
            m_TextureColorCache[slot] = tex.GetPixels();
            
            Debug.Log($"Captured {w}x{h} texture to slot {slot + 1}");
        }
        
        /// <summary>
        /// Load texture from file to slot
        /// </summary>
        public void LoadTextureToSlot(Texture2D source, int slot)
        {
            if (slot < 0 || slot > 2 || source == null) return;
            
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            // Make readable copy
            var tex = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false);
            
            var prevRT = RenderTexture.active;
            var tmpRT = RenderTexture.GetTemporary(source.width, source.height, 0, RenderTextureFormat.ARGB32);
            Graphics.Blit(source, tmpRT);
            RenderTexture.active = tmpRT;
            tex.ReadPixels(new Rect(0, 0, source.width, source.height), 0, 0);
            tex.Apply();
            RenderTexture.active = prevRT;
            RenderTexture.ReleaseTemporary(tmpRT);
            
            m_TextureSlots[slot] = tex;
            m_TextureColorCache[slot] = tex.GetPixels();
            
            Debug.Log($"Loaded {tex.width}x{tex.height} texture to slot {slot + 1}");
        }
        
        /// <summary>
        /// Clear texture from slot
        /// </summary>
        public void ClearTextureSlot(int slot)
        {
            if (slot < 0 || slot > 2) return;
            
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            m_TextureSlots[slot] = null;
            m_TextureColorCache[slot] = null;
        }
        
        /// <summary>
        /// Save texture slot to PNG file
        /// </summary>
        public byte[] GetTextureSlotAsPNG(int slot)
        {
            if (slot < 0 || slot > 2 || m_TextureSlots[slot] == null) return null;
            return m_TextureSlots[slot].EncodeToPNG();
        }
        
        /// <summary>
        /// Get color from active texture at UV coordinate
        /// </summary>
        public Color SampleTextureColor(float u, float v)
        {
            if (!HasActiveTexture) return GetNextPaintColor();
            
            var tex = m_TextureSlots[m_ActiveTextureSlot];
            var cache = m_TextureColorCache[m_ActiveTextureSlot];
            if (tex == null || cache == null) return GetNextPaintColor();
            
            // Apply tiling and rotation
            float cu = u * m_TextureTileScale;
            float cv = v * m_TextureTileScale;
            
            if (m_TextureRotation != 0f)
            {
                float rad = m_TextureRotation * Mathf.Deg2Rad;
                float cos = Mathf.Cos(rad);
                float sin = Mathf.Sin(rad);
                float nu = (cu - 0.5f) * cos - (cv - 0.5f) * sin + 0.5f;
                float nv = (cu - 0.5f) * sin + (cv - 0.5f) * cos + 0.5f;
                cu = nu;
                cv = nv;
            }
            
            // Repeat wrap
            cu = cu - Mathf.Floor(cu);
            cv = cv - Mathf.Floor(cv);
            
            int x = Mathf.Clamp((int)(cu * tex.width), 0, tex.width - 1);
            int y = Mathf.Clamp((int)(cv * tex.height), 0, tex.height - 1);
            
            return cache[y * tex.width + x];
        }
        
        /// <summary>
        /// Get color from texture based on splat position within brush area
        /// </summary>
        public Color GetTextureColorForPosition(Vector3 localPos, Vector3 brushCenter, float brushRadius, Vector3 right, Vector3 up)
        {
            if (!HasActiveTexture) return GetNextPaintColor();
            
            Vector3 offset = localPos - brushCenter;
            // Solve the scatter basis instead of assuming unit orthogonal local axes;
            // source transforms can have nonuniform scale.
            float rr = Vector3.Dot(right,right), uu = Vector3.Dot(up,up), ru = Vector3.Dot(right,up);
            float determinant = rr*uu-ru*ru;
            if (determinant <= 1e-12f || brushRadius <= 0) return SampleTextureColor(0.5f,0.5f);
            float dr = Vector3.Dot(offset,right), du = Vector3.Dot(offset,up);
            float u = (dr*uu-du*ru) / determinant / (brushRadius*2f) + 0.5f;
            float v = (du*rr-dr*ru) / determinant / (brushRadius*2f) + 0.5f;
            
            return SampleTextureColor(u, v);
        }
        
        /// <summary>
        /// Paint using active texture - GPU path with texture
        /// </summary>
        public void PaintWithTextureAtRay(Ray ray, Camera cam, float worldRadius, Vector3 viewDir, float referenceDepth)
        {
            if (!HasActiveTexture) { PaintAtRay(ray, cam, worldRadius, viewDir, referenceDepth); return; }
            if (!PreparePaint(ray, cam, worldRadius, viewDir, referenceDepth, out var output,
                out var localCenter, out var right, out var up, out float scatterRadius, out float size)) return;
            var texture = m_TextureSlots[m_ActiveTextureSlot];
            if (m_UseGPUPaint)
            {
                output.PaintSplatsFromTextureGPU(m_NextWriteIndex, localCenter, scatterRadius, size, texture,
                    m_TextureTileScale, m_TextureRotation, m_ColorVariation, right, up, m_SplatsPerStroke, m_PaintDensity);
            }
            else
            {
                EnsureBatchBuffers();
                for (int i = 0; i < m_SplatsPerStroke; ++i)
                {
                    float angle = Random.Range(0f, Mathf.PI * 2f);
                    float distance = Mathf.Sqrt(Random.value) * scatterRadius;
                    Vector3 position = localCenter + right * (Mathf.Cos(angle) * distance) + up * (Mathf.Sin(angle) * distance);
                    m_BatchPositions[i] = position;
                    m_BatchColors[i] = VaryPaintColor(GetTextureColorForPosition(position, localCenter, scatterRadius, right, up));
                    m_BatchSizes[i] = size;
                }
                if (!output.PaintSplatsBatch(m_NextWriteIndex, m_BatchPositions, m_BatchSizes, m_BatchColors, m_SplatsPerStroke, m_PaintDensity))
                    return;
            }
            m_NextWriteIndex += m_SplatsPerStroke;
        }

        private void OnDestroy()
        {
            for (int i = 0; i < 3; i++)
            {
                if (m_TextureSlots[i] != null)
                    DestroyImmediate(m_TextureSlots[i]);
            }
        }
    }
}

