// SPDX-License-Identifier: MIT
#ifndef SPLAT_DOF_DEPTH_INCLUDED
#define SPLAT_DOF_DEPTH_INCLUDED

struct SplatFragmentOutput
{
    half4 color : SV_Target0;
#if defined(SPLAT_DOF_DEPTH)
    float4 depth : SV_Target1;
#endif
};

SplatFragmentOutput MakeSplatFragmentOutput(half4 color, float eyeDepth)
{
    SplatFragmentOutput output;
    output.color = color;
#if defined(SPLAT_DOF_DEPTH)
    // The second target uses the same front-to-back alpha blend as color. Its red/alpha
    // ratio therefore describes the visible splat surface, including transparent layers.
    // Normalize by far clip so RGBA16F remains finite even in very large scenes.
    float normalizedDepth = saturate(eyeDepth / max(_ProjectionParams.z, 1e-4));
    output.depth = float4(normalizedDepth * color.a, 0, 0, color.a);
#endif
    return output;
}

#endif
