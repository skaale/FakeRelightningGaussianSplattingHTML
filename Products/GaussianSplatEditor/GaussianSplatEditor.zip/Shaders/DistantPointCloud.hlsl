// Shared distance test for covariance compute and the standard/relight draw shaders.
#ifndef SPLATBOX_DISTANT_POINT_CLOUD_INCLUDED
#define SPLATBOX_DISTANT_POINT_CLOUD_INCLUDED

int _LodDistantPointCloud;
float _LodDetailDistance;
float4 _LodCameraWorldPos;

bool IsDistantPointCloud(float3 worldPos)
{
    bool distant = false;
    if (_LodDistantPointCloud != 0)
    {
        float3 toCamera = worldPos - _LodCameraWorldPos.xyz;
        distant = dot(toCamera, toCamera) > _LodDetailDistance * _LodDetailDistance;
    }
    return distant;
}

#endif // SPLATBOX_DISTANT_POINT_CLOUD_INCLUDED
