// SPDX-License-Identifier: MIT
 
// For compute shader code, see BoxUtil.compute
#ifndef SPLATBOX_HLSL
#define SPLATBOX_HLSL

uint _SplatTightQuads;

// The fragment shaders discard alpha below 1/255. Solve opacity * exp(-r*r)
// for that boundary so faint splats do not rasterize an entire [-2,2] quad.
// A slightly lower cutoff covers half-precision rounding at the visible edge.
// Negative opacity encodes editor selection, whose outline needs the full quad.
float SplatQuadExtent(float opacity)
{
    if (_SplatTightQuads == 0 || opacity < 0)
        return 2.0;
    const float conservativeCutoff = 0.0038;
    return sqrt(clamp(log(max(opacity, conservativeCutoff) / conservativeCutoff), 0.0, 4.0));
}

// View data structure for rendering splats
struct SplatViewData
{
    float4 pos;
    uint axis1, axis2; // screen-space conic axes, each packed as half2 (f16 x in high 16 bits, y in low)
    uint2 color; // 4xFP16
    // Keep the trailing pair 16 bytes (float3 + uint) so the StructuredBuffer stride stays 48 bytes /
    // 16-byte aligned on Vulkan/Adreno. A 44-byte stride caused unstable reads / flickering on Quest.
    float3 worldPos; // stable world-space splat center (from compute)
    uint splatIdx;   // splat index this slot was written from (the view buffer is in draw/slot order)
};

#endif // SPLATBOX_HLSL
