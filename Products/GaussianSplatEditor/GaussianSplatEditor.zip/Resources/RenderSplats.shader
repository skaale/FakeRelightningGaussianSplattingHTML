// Player/build copy loaded via Resources.Load("RenderSplats").
// Unique name (vs Shaders/RenderGaussianSplats.shader) avoids duplicate-shader-name
// dedupe in player builds, which silently drops one shader and breaks rendering.
Shader "Gaussian Splatting/Render Splats (Player)"
{
    Properties
    {
        _ColorExposure ("Exposure", Float) = 0.0
        _ColorContrast ("Contrast", Float) = 1.0
        _ColorFilter ("Color Filter", Color) = (1,1,1,1)
        _ColorHueShift ("Hue Shift", Float) = 0.0
        _ColorSaturation ("Saturation", Float) = 1.0
        _SelectionColor ("Selection Color", Color) = (1,0,1,1)
        _TargetSelectionColor ("Target Selection Color", Color) = (0,1,1,1)
    }
    SubShader
    {
        Tags { "RenderType"="Transparent" "Queue"="Transparent" }

        Pass
        {
            ZWrite Off
            // ZTest Always: splats render into their own offscreen RT without a bound depth attachment;
            // the default LEqual test discards every fragment on Vulkan (PICO/Quest). Matches RenderSplatsRelight.
            ZTest Always
            Blend OneMinusDstAlpha One
            Cull Off
            
CGPROGRAM
#pragma vertex vert
#pragma fragment frag
#pragma multi_compile _ SPLAT_DOF_DEPTH
// No #pragma use_dxc: nothing here needs SM6, and DXC's auto-binding collides on Vulkan
// ("resource '_OrderBuffer' shares binding N with another resource"), which leaves the splat
// buffers unbound and the draw skipped.
#pragma require compute
#pragma multi_compile _ STEREO_INSTANCING_ON STEREO_MULTIVIEW_ON

#include "UnityCG.cginc"
#include "../Shaders/SplatBox.hlsl"
#include "../Shaders/EquirectangularProjection.hlsl"
#include "../Shaders/MeshSplatTexture.hlsl"
#include "../Shaders/DistantPointCloud.hlsl"
#include "../Shaders/SplatDofDepth.hlsl"

// _OrderBuffer is no longer read here: CSCalcViewData consumes it and emits _SplatViewData in draw order.
uint _SplatCount; // valid splat count; guards against out-of-range slots / hidden slots
// Single Pass (Instanced / Multiview): per-eye VP matrices set by GaussianSplatURPFeature with the
// same renderIntoTexture=true convention as CalcViewData (compute only bakes view.pos for eye 0).
float4x4 _SplatStereoMatrixVP[2];
// Scene-depth occlusion (see RenderSplatsRelight.shader): the splat RT has no depth attachment, so opaque
// geometry is hidden by comparing against the camera depth texture in the fragment instead.
UNITY_DECLARE_DEPTH_TEXTURE(_CameraDepthTexture);
uint _SceneDepthOcclusion;  // 1 = fade out splats that lie behind opaque scene geometry
float _SceneDepthFade;      // metres over which a splat fades as it passes behind geometry
uint _SceneDepthTextureValid;
float4 _SplatRenderTargetSize; // xy = splat RT size, zw = reciprocal size
float _SplatSize; // distant point diameter in splat render-target pixels

// Color adjustments
float _ColorExposure;
float _ColorContrast;
float4 _ColorFilter;
float _ColorHueShift;
float _ColorSaturation;

// Selection colors
float4 _SelectionColor;
float4 _TargetSelectionColor;

struct v2f
{
    half4 col : COLOR0;
    float2 pos : TEXCOORD0;
    float eyeDepth : TEXCOORD1;
    float3 projectionPositionWS : TEXCOORD2;
    float2 meshUv : TEXCOORD3;
    nointerpolation float pointCloud : TEXCOORD4;
    float4 vertex : SV_POSITION;
    UNITY_VERTEX_OUTPUT_STEREO
};

StructuredBuffer<SplatViewData> _SplatViewData;
ByteAddressBuffer _SplatSelectedBits;
ByteAddressBuffer _SplatTargetSelectedBits;
uint _SplatBitsValid;

// Convert RGB to HSV
float3 RGBToHSV(float3 c)
{
    float4 K = float4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    float4 p = lerp(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
    float4 q = lerp(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));
    
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}

// Convert HSV to RGB
float3 HSVToRGB(float3 c)
{
    float4 K = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
    float3 p = abs(frac(c.xxx + K.xyz) * 6.0 - K.www);
    return c.z * lerp(K.xxx, saturate(p - K.xxx), c.y);
}

// Apply color adjustments to a color
float3 ApplyColorAdjustments(float3 color)
{
    // Apply exposure (brightness) - 0 is neutral
    if (abs(_ColorExposure) > 0.001)
        color *= exp2(_ColorExposure);
    
    // Apply contrast - 1.0 is neutral
    if (abs(_ColorContrast - 1.0) > 0.001)
        color = lerp(0.5, color, _ColorContrast);
    
    // Apply hue shift and saturation - only if needed
    if (abs(_ColorHueShift) > 0.001 || abs(_ColorSaturation - 1.0) > 0.001)
    {
        float3 hsv = RGBToHSV(color);
        hsv.x = frac(hsv.x + _ColorHueShift / 360.0);
        hsv.y *= _ColorSaturation;
        color = HSVToRGB(hsv);
    }
    
    // Apply color filter only if not white (1,1,1)
    bool filterIsNeutral = _ColorFilter.r > 0.99 && _ColorFilter.g > 0.99 && _ColorFilter.b > 0.99;
    if (!filterIsNeutral)
        color *= _ColorFilter.rgb;
    
    return color;
}

v2f vert (uint vtxID : SV_VertexID, uint instID : SV_InstanceID)
{
    v2f o = (v2f)0;
#if defined(UNITY_STEREO_INSTANCING_ENABLED)
    // Single Pass Instanced: Unity doubles the instance count (SetInstanceMultiplier), even = left eye,
    // odd = right eye. Under Multiview unity_StereoEyeIndex is a #define of gl_ViewID (not assignable),
    // so this block is Instancing-only. Must run before UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO.
    unity_StereoEyeIndex = instID & 1;
    instID >>= 1;
#endif
    UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
    // instID is the draw slot: CSCalcViewData writes _SplatViewData in sorted (slot) order, so the read is
    // sequential and needs no _OrderBuffer indirection. view.splatIdx carries the splat index.
    if (instID >= _SplatCount)
    {
        o.vertex = asfloat(0x7fc00000); // NaN discards the primitive
        return o;
    }
    SplatViewData view = _SplatViewData[instID];
    if (view.splatIdx >= _SplatCount)
    {
        o.vertex = asfloat(0x7fc00000); // slot hidden by compute (garbage sort payload)
        return o;
    }
    float4 centerClipPos = view.pos;
    bool behindCam = centerClipPos.w <= 0;
#if defined(USING_STEREO_MATRICES)
    // Single Pass: compute bakes view.pos with the eye-0 VP only, so re-project the world position with
    // this eye's VP. Compute-side culling (w <= 0: deleted / cutout / distance / near plane) is kept.
    if (!behindCam)
    {
        centerClipPos = mul(_SplatStereoMatrixVP[unity_StereoEyeIndex], float4(view.worldPos.xyz, 1.0));
        behindCam = centerClipPos.w <= 0;
    }
#endif
    if (behindCam)
    {
        o.vertex = asfloat(0x7fc00000); // NaN discards the primitive
    }
    else
    {
        o.col.r = f16tof32(view.color.x >> 16);
        o.col.g = f16tof32(view.color.x);
        o.col.b = f16tof32(view.color.y >> 16);
        o.col.a = f16tof32(view.color.y);

        // Preserve the full footprint for selection outlines.
        if (_SplatBitsValid)
        {
            uint wordIdx = view.splatIdx / 32;
            uint bitIdx = view.splatIdx & 31;
            uint selVal = _SplatSelectedBits.Load(wordIdx * 4);
            uint targetSelVal = _SplatTargetSelectedBits.Load(wordIdx * 4);
            bool isSourceSelected = (selVal & (1 << bitIdx)) != 0;
            bool isTargetSelected = (targetSelVal & (1 << bitIdx)) != 0;

            // Encode selection state in alpha:
            // -1 = source selected only
            // -2 = target selected only
            // -3 = both selected
            if (isSourceSelected && isTargetSelected)
                o.col.a = -3;
            else if (isTargetSelected)
                o.col.a = -2;
            else if (isSourceSelected)
                o.col.a = -1;
        }

        // Ordinary splats have one colour across the whole quad. Grade it here so
        // overlapping Gaussian fragments do not repeat the HSV conversion.
        // Selection tint and mesh albedo are fragment-dependent and retain their
        // existing order below in frag.
        if (o.col.a >= 0 && _MeshTexEnabled == 0)
            o.col.rgb = ApplyColorAdjustments(o.col.rgb);

        bool pointCloud = IsDistantPointCloud(view.worldPos.xyz);
        o.pointCloud = pointCloud ? 1.0 : 0.0;
        uint idx = vtxID;
        float2 quadPos = float2(idx&1, (idx>>1)&1) * 2.0 - 1.0;
        if (!pointCloud)
            quadPos *= SplatQuadExtent(o.col.a);

        o.pos = quadPos;
        o.meshUv = ComputeSplatMeshUv(view.splatIdx, quadPos);

        float2 axis1 = float2(f16tof32(view.axis1 >> 16), f16tof32(view.axis1));
        float2 axis2 = float2(f16tof32(view.axis2 >> 16), f16tof32(view.axis2));
        // _ScreenParams describes the camera target, which can be larger than the
        // low-resolution splat target. Keep quad expansion aligned with CalcViewData.
        float2 splatTargetSize = _SplatRenderTargetSize.x > 0
            ? _SplatRenderTargetSize.xy
            : _ScreenParams.xy;
        float2 deltaScreenPos = (quadPos.x * axis1 + quadPos.y * axis2) * 2 / splatTargetSize;
        if (pointCloud)
            deltaScreenPos = quadPos * max(_SplatSize, 1.0) / splatTargetSize;
        o.vertex = centerClipPos;
        o.vertex.xy += deltaScreenPos * centerClipPos.w;

        if (_EquirectEnabled != 0 && _EquirectOpacity > 0)
        {
            float2 viewOffset = float2(
                deltaScreenPos.x * centerClipPos.w / UNITY_MATRIX_P._m00,
                deltaScreenPos.y * centerClipPos.w / UNITY_MATRIX_P._m11);
            o.projectionPositionWS = view.worldPos.xyz +
                mul((float3x3)UNITY_MATRIX_I_V, float3(viewOffset, 0.0));
        }

        // Perspective clip.w is eye depth; orthographic projections need view-space z.
        float eyeDepth = unity_OrthoParams.w > 0.5
            ? -mul(UNITY_MATRIX_V, float4(view.worldPos.xyz, 1.0)).z
            : centerClipPos.w;
        o.eyeDepth = eyeDepth;


    }
    return o;
}

SplatFragmentOutput frag (v2f i)
{
    UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
    half alpha;
    if (i.pointCloud > 0.5)
    {
        // Fixed-size circular points retain source opacity without Gaussian tails.
        if (dot(i.pos, i.pos) > 1.0)
            discard;
        alpha = 1.0;
    }
    else
    {
        float power = -dot(i.pos, i.pos);
        alpha = exp(power);
    }
    
    if (i.col.a >= 0)
    {
        alpha = saturate(alpha * i.col.a);
    }
    else
    {
        // Selection state encoded in negative alpha:
        // -1 = source selected, -2 = target selected, -3 = both
        half3 selColor = _SelectionColor.rgb;
        if (i.col.a < -2.5) // Both selected (-3)
        {
            selColor = lerp(_SelectionColor.rgb, _TargetSelectionColor.rgb, 0.5);
        }
        else if (i.col.a < -1.5) // Target selected (-2)
        {
            selColor = _TargetSelectionColor.rgb;
        }
        
        if (alpha > 7.0/255.0)
        {
            if (alpha < 10.0/255.0)
            {
                alpha = 1;
                i.col.rgb = selColor;
            }
            alpha = saturate(alpha + 0.3);
        }
        i.col.rgb = lerp(i.col.rgb, selColor, 0.5);
    }

    // Reject Gaussian tails before depth or projection texture work.
    if (alpha < 1.0/255.0)
        discard;

    // Scene-depth occlusion: fade the splat out where opaque geometry is nearer than its centre.
    if (_SceneDepthOcclusion != 0 && _SceneDepthTextureValid != 0)
    {
        // SV_POSITION is a pixel coordinate in the actual splat RT. Normalizing that
        // coordinate avoids API-dependent clip-space Y orientation.
        float2 depthUv = i.vertex.xy * _SplatRenderTargetSize.zw;
        float rawDepth = SAMPLE_DEPTH_TEXTURE(_CameraDepthTexture, depthUv);
        float sceneEyeDepth;
        if (unity_OrthoParams.w > 0.5)
        {
            #if UNITY_REVERSED_Z
            rawDepth = 1.0 - rawDepth;
            #endif
            sceneEyeDepth = lerp(_ProjectionParams.y, _ProjectionParams.z, rawDepth);
        }
        else
        {
            sceneEyeDepth = LinearEyeDepth(rawDepth);
        }
        // Keep the splat fully visible when it is on or in front of the opaque surface,
        // then soften only the portion that moves behind it. The previous fade window was
        // reversed: equal depth produced zero alpha, which cut a hard primitive-shaped hole.
        float depthGap = sceneEyeDepth - i.eyeDepth;
        alpha *= saturate(1.0 + depthGap / max(_SceneDepthFade, 1e-4));
    }
    
    if (alpha < 1.0/255.0)
        discard;

    // Apply color adjustments
    half3 finalColor = i.col.rgb;
    if (i.col.a < 0 || _MeshTexEnabled != 0)
        finalColor = ApplyColorAdjustments(ApplyMeshSplatAlbedo(finalColor, i.meshUv));
    
    half4 res = half4(finalColor * alpha, alpha);
    res = ApplyEquirectangularProjection(i.projectionPositionWS, res);
    return MakeSplatFragmentOutput(res, i.eyeDepth);
}
ENDCG
        }

        Pass
        {
            Name "BlitToScreen"
            ZWrite Off
            ZTest Always
            Cull Off
            Blend SrcAlpha OneMinusSrcAlpha

CGPROGRAM
#pragma vertex vertComposite
#pragma fragment fragComposite
// No #pragma use_dxc: nothing here needs SM6, and DXC's auto-binding collides on Vulkan
// ("resource '_OrderBuffer' shares binding N with another resource"), which leaves the splat
// buffers unbound and the draw skipped.
#pragma require compute
#pragma multi_compile _ STEREO_INSTANCING_ON STEREO_MULTIVIEW_ON
#include "UnityCG.cginc"

struct v2fComposite
{
    float4 vertex : SV_POSITION;
    UNITY_VERTEX_OUTPUT_STEREO
};

v2fComposite vertComposite(uint vtxID : SV_VertexID, uint instID : SV_InstanceID)
{
    v2fComposite o;
#if defined(UNITY_STEREO_INSTANCING_ENABLED)
    // Single Pass Instanced: Blitter draws 3 verts x 2 instances; the instance parity is the eye.
    unity_StereoEyeIndex = instID & 1;
#endif
    UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
    float2 quadPos = float2(vtxID&1, (vtxID>>1)&1) * 4.0 - 1.0;
    o.vertex = float4(quadPos, 1, 1);
    return o;
}

#if defined(UNITY_STEREO_INSTANCING_ENABLED) || defined(UNITY_STEREO_MULTIVIEW_ENABLED)
// Single Pass: the splat RT is created from cameraTargetDescriptor, i.e. a Tex2DArray (one slice per eye).
Texture2DArray _GaussianSplatRT;
#else
Texture2D _GaussianSplatRT;
#endif
SamplerState sampler_GaussianSplatRT;
// 1 when the splat RT (intermediate, flipped on Vulkan/D3D) and the camera target (e.g. XR eye texture,
// not flipped) have different UV origins; set by GaussianSplatURPFeature via IsHandleYFlipped.
float _SplatCompositeFlipY;

half4 fragComposite(v2fComposite i) : SV_Target
{
    UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
    // Sample (not Load) so the splat RT can be rendered below screen resolution
    // using the shared Render Scale and bilinearly upscaled here.
    float2 uv = i.vertex.xy / _ScreenParams.xy;
    if (_SplatCompositeFlipY > 0.5)
        uv.y = 1.0 - uv.y;
#if defined(UNITY_STEREO_INSTANCING_ENABLED) || defined(UNITY_STEREO_MULTIVIEW_ENABLED)
    half4 col = _GaussianSplatRT.Sample(sampler_GaussianSplatRT, float3(uv, (float)unity_StereoEyeIndex));
#else
    half4 col = _GaussianSplatRT.Sample(sampler_GaussianSplatRT, uv);
#endif
    return col;
}
ENDCG
        }
    }
}
