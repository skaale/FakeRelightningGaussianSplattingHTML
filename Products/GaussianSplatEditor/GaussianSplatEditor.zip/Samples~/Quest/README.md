# Quest demo settings

Import **Quest FPS HUD** from this package's Samples panel to add `QuestSplatFpsCounter`. It automatically creates a headset-relative readout in scenes whose name contains `Splat`, and displays the rounded smoothed frame rate without an offset. Unity UI is required.

The theater demo was tested on Quest 3S with these settings:

| Setting | Value |
| --- | --- |
| LoD mode / Quality | Simple / 0.5 |
| Detail Distance | 8 m |
| Splat render scale | 0.329 |
| Android atlas ceiling | 256 MB |
| Fixed foveation strength | 0.5 |
| Sort interval | 1 |
| Fast 16-bit sorting | Enabled |
| GPU frustum culling / compact sorting | Enabled |
| Reuse sort across eyes | Enabled |
| Relighting | Disabled |

Render scale is a quality/performance tradeoff, not a universal recommendation. Frame rate depends on the scene, visible splat count and motion. The theater data and scene-specific GUID references remain in the demo project; this repository contains the reusable package code.
