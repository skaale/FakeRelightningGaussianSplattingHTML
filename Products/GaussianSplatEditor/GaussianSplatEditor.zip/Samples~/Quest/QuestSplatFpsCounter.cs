using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// World-space FPS readout parented to the headset camera so it is visible in VR.
/// Appears automatically in scenes whose name contains "Splat".
/// </summary>
[DisallowMultipleComponent]
[DefaultExecutionOrder(10000)]
public class QuestSplatFpsCounter : MonoBehaviour
{
    [SerializeField] float distance = 0.8f;
    [SerializeField] Vector2 viewOffset = new Vector2(-0.22f, -0.14f);
    [SerializeField] float panelScale = 0.001f;
    [SerializeField] float smoothSeconds = 0.3f;

    Text label;
    RectTransform panel;
    Camera boundCamera;
    float smoothedFps;
    int shownFps = -1;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Bootstrap()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
        SceneManager.sceneLoaded += OnSceneLoaded;
        TrySpawn(SceneManager.GetActiveScene());
    }

    static void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        TrySpawn(scene);
    }

    static void TrySpawn(Scene scene)
    {
        if (!scene.IsValid() || !scene.isLoaded)
            return;
        if (scene.name.IndexOf("Splat", StringComparison.OrdinalIgnoreCase) < 0)
            return;
        if (FindAnyObjectByType<QuestSplatFpsCounter>(FindObjectsInactive.Include) != null)
            return;

        var go = new GameObject("VR FPS Counter");
        SceneManager.MoveGameObjectToScene(go, scene);
        go.AddComponent<QuestSplatFpsCounter>();
    }

    void Awake()
    {
        panel = BuildPanel();
    }

    void LateUpdate()
    {
        BindCamera();
        UpdateReadout();
    }

    void BindCamera()
    {
        var camera = ActiveCamera();
        if (camera == null)
            return;

        if (camera != boundCamera)
        {
            boundCamera = camera;
            panel.SetParent(camera.transform, false);
        }

        panel.localPosition = new Vector3(viewOffset.x, viewOffset.y, distance);
        panel.localRotation = Quaternion.identity;
        panel.localScale = Vector3.one * panelScale;
    }

    void UpdateReadout()
    {
        float dt = Time.unscaledDeltaTime;
        if (dt > 1e-6f)
        {
            float fps = 1f / dt;
            float blend = 1f - Mathf.Exp(-dt / Mathf.Max(0.01f, smoothSeconds));
            smoothedFps = smoothedFps <= 0f ? fps : Mathf.Lerp(smoothedFps, fps, blend);
        }

        int fpsInt = Mathf.RoundToInt(smoothedFps);
        if (fpsInt == shownFps)
            return;

        shownFps = fpsInt;
        label.text = fpsInt + " FPS";
        label.color = fpsInt >= 72
            ? new Color(0.45f, 1f, 0.5f)
            : fpsInt >= 45
                ? new Color(1f, 0.86f, 0.25f)
                : new Color(1f, 0.4f, 0.35f);
    }

    static Camera ActiveCamera()
    {
        var main = Camera.main;
        if (main != null && main.isActiveAndEnabled)
            return main;

        var cameras = Camera.allCameras;
        for (int i = 0; i < cameras.Length; i++)
        {
            var camera = cameras[i];
            if (camera != null && camera.isActiveAndEnabled && camera.stereoTargetEye != StereoTargetEyeMask.None)
                return camera;
        }

        for (int i = 0; i < cameras.Length; i++)
        {
            var camera = cameras[i];
            if (camera != null && camera.isActiveAndEnabled)
                return camera;
        }

        return null;
    }

    RectTransform BuildPanel()
    {
        var root = new GameObject("FPS Panel");
        var rect = root.AddComponent<RectTransform>();
        rect.sizeDelta = new Vector2(320f, 90f);

        var canvas = root.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;

        var background = root.AddComponent<Image>();
        background.color = new Color(0f, 0f, 0f, 0.65f);
        background.raycastTarget = false;

        var textObject = new GameObject("FPS Text");
        var textRect = textObject.AddComponent<RectTransform>();
        textRect.SetParent(rect, false);
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = new Vector2(18f, 8f);
        textRect.offsetMax = new Vector2(-18f, -8f);

        label = textObject.AddComponent<Text>();
        label.font = BuiltinFont();
        label.fontSize = 56;
        label.fontStyle = FontStyle.Bold;
        label.alignment = TextAnchor.MiddleLeft;
        label.color = Color.white;
        label.raycastTarget = false;
        label.horizontalOverflow = HorizontalWrapMode.Overflow;
        label.verticalOverflow = VerticalWrapMode.Overflow;
        label.text = "-- FPS";

        var outline = textObject.AddComponent<Outline>();
        outline.effectColor = new Color(0f, 0f, 0f, 0.9f);
        outline.effectDistance = new Vector2(2f, -2f);

        return rect;
    }

    static Font BuiltinFont()
    {
        var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        if (font == null)
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        return font;
    }
}
