using UnityEngine;
using UnityEditor;
using UnityEditor.Build.Reporting;
using System;
using System.IO;
using System.Linq;

namespace GaussianSplatting.Editor
{
    public static class SplatBoxPluginBuilder
    {
        private static string PluginOutputPath
        {
            get
            {
                // Use cross-platform path: place plugin folder next to the Unity project
                string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                return Path.Combine(projectPath, "SplatBoxPlugin");
            }
        }
        
        [MenuItem("SplatBox/Build Plugin Package")]
        public static void BuildPluginPackage()
        {
            // Check for URP - important for GaussianSplatURPFeature to be included in DLL
#if !GS_ENABLE_URP
            bool proceed = EditorUtility.DisplayDialog("SplatBox Plugin Builder - Warning",
                "URP (Universal Render Pipeline) is not detected!\n\n" +
                "The GaussianSplatURPFeature class will NOT be included in the Runtime DLL.\n" +
                "Users won't be able to add the Gaussian Splat renderer feature to URP.\n\n" +
                "For full functionality, build from a project with URP installed.\n\n" +
                "Continue anyway?",
                "Continue", "Cancel");
            if (!proceed) return;
#endif
            
            // Ensure output directory exists
            if (!Directory.Exists(PluginOutputPath))
            {
                Directory.CreateDirectory(PluginOutputPath);
            }
            
            // Create folder structure
            // All assemblies shipped as precompiled DLLs (targeting same Unity version)
            string pluginsFolder = Path.Combine(PluginOutputPath, "Plugins");
            string pluginsEditorFolder = Path.Combine(pluginsFolder, "Editor");
            string editorIconsFolder = Path.Combine(PluginOutputPath, "Editor", "Icons");
            string shadersFolder = Path.Combine(PluginOutputPath, "Shaders");
            string resourcesFolder = Path.Combine(PluginOutputPath, "Resources");
            
            CreateDirectoryIfNotExists(pluginsFolder);
            CreateDirectoryIfNotExists(pluginsEditorFolder);
            CreateDirectoryIfNotExists(editorIconsFolder);
            CreateDirectoryIfNotExists(shadersFolder);
            CreateDirectoryIfNotExists(resourcesFolder);
            
            // Get the source paths
            string packageRoot = GetPackageRoot();
            if (string.IsNullOrEmpty(packageRoot))
            {
                EditorUtility.DisplayDialog("SplatBox Plugin Builder - Error",
                    "Could not determine package root directory.\n\n" +
                    "Please ensure the SplatBox package is properly installed in your Unity project.",
                    "OK");
                return;
            }
            
            string unityLibraryPath = Path.Combine(Application.dataPath, "..", "Library", "ScriptAssemblies");
            
            Debug.Log($"[SplatBox Plugin Builder] Package root: {packageRoot}");
            Debug.Log($"[SplatBox Plugin Builder] Unity version: {Application.unityVersion}");
            
            int copiedFiles = 0;
            
            // ── 1a. Build minimal player to get Runtime/Core DLLs without UnityEditor reference ──
            string runtimeManagedPath = BuildRuntimeAndCoreDllsNoEditor();
            if (string.IsNullOrEmpty(runtimeManagedPath))
            {
                EditorUtility.DisplayDialog("SplatBox Plugin Builder - Error",
                    "Minimal player build failed. Runtime/Core DLLs must be built without UNITY_EDITOR so customer builds succeed.\n\n" +
                    "Ensure Build Settings has at least one scene and the build completes without errors.",
                    "OK");
                return;
            }
            
            // ── 1b. Copy Runtime/Core DLLs from player build (no UnityEditor ref); Editor DLL from current session ──
            copiedFiles += CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Core.dll");
            copiedFiles += CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Runtime.dll");
            CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Core.pdb");
            CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Runtime.pdb");
            
            copiedFiles += CopyDll(unityLibraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Editor.dll");
            CopyDll(unityLibraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Editor.pdb");
            
            CleanupTempBuildFolder();
            
            // Generate .meta files for DLLs with validateReferences disabled
            CreateDllMeta(pluginsFolder, "GaussianSplatting.SplatBox.Core.dll", isEditorOnly: false);
            CreateDllMeta(pluginsFolder, "GaussianSplatting.SplatBox.Runtime.dll", isEditorOnly: false);
            CreateDllMeta(pluginsEditorFolder, "GaussianSplatting.SplatBox.Editor.dll", isEditorOnly: true);
            copiedFiles += 3; // meta files
            
            // ── 2. Copy Editor Icons (assets needed by the Editor DLL at runtime) ──
            string sourceIcons = Path.Combine(packageRoot, "Editor", "Icons");
            if (Directory.Exists(sourceIcons))
            {
                string[] iconExtensions = { "*.png", "*.png.meta" };
                foreach (var ext in iconExtensions)
                {
                    foreach (var file in Directory.GetFiles(sourceIcons, ext))
                    {
                        string destFile = Path.Combine(editorIconsFolder, Path.GetFileName(file));
                        File.Copy(file, destFile, true);
                        copiedFiles++;
                    }
                }
                Debug.Log($"[SplatBox Plugin Builder] Copied editor icons");
            }
            
            // ── 3. Copy shaders ──
            string sourceShaders = Path.Combine(packageRoot, "Shaders");
            if (Directory.Exists(sourceShaders))
            {
                string[] shaderExtensions = { "*.shader", "*.hlsl", "*.compute", "*.cginc" };
                foreach (var ext in shaderExtensions)
                {
                    foreach (var file in Directory.GetFiles(sourceShaders, ext))
                    {
                        string destFile = Path.Combine(shadersFolder, Path.GetFileName(file));
                        File.Copy(file, destFile, true);
                        copiedFiles++;
                        Debug.Log($"[SplatBox Plugin Builder] Copied shader: {Path.GetFileName(file)}");
                    }
                }
            }
            
            // ── 4. Copy Resources folder (runtime fallback for compute shaders in builds) ──
            string sourceResources = Path.Combine(packageRoot, "Resources");
            if (Directory.Exists(sourceResources))
            {
                string[] resourceExtensions = { "*.compute", "*.hlsl", "*.shader" };
                foreach (var ext in resourceExtensions)
                {
                    foreach (var file in Directory.GetFiles(sourceResources, ext))
                    {
                        string destFile = Path.Combine(resourcesFolder, Path.GetFileName(file));
                        File.Copy(file, destFile, true);
                        copiedFiles++;
                        Debug.Log($"[SplatBox Plugin Builder] Copied resource: {Path.GetFileName(file)}");
                    }
                }
            }
            else
            {
                Debug.LogWarning("[SplatBox Plugin Builder] Resources folder not found. Windows standalone builds may fail to load compute shaders at runtime.");
            }
            
            // ── 5. Create package metadata ──
            CreatePackageJson(PluginOutputPath);
            copiedFiles++;
            
            // Create assembly definition files for the DLLs
            CreatePluginAssemblyDefinitions(pluginsFolder, pluginsEditorFolder);
            copiedFiles += 2;
            
            // Create README
            CreateReadme(PluginOutputPath);
            copiedFiles++;
            
            Debug.Log($"[SplatBox Plugin Builder] Plugin package built successfully!");
            Debug.Log($"[SplatBox Plugin Builder] Output: {PluginOutputPath}");
            Debug.Log($"[SplatBox Plugin Builder] Total files: {copiedFiles}");
            Debug.Log($"[SplatBox Plugin Builder] All assemblies shipped as precompiled DLLs (Unity {Application.unityVersion}).");
            
            EditorUtility.DisplayDialog("SplatBox Plugin Builder", 
                $"Plugin package built successfully!\n\n" +
                $"Output: {PluginOutputPath}\n" +
                $"Total files: {copiedFiles}\n" +
                $"Built with: Unity {Application.unityVersion}\n\n" +
                "All assemblies (Core, Runtime, Editor) shipped as precompiled DLLs.\n\n" +
                "IMPORTANT: This plugin must be used with the same major Unity\n" +
                "version it was built with to avoid Burst compatibility issues.", 
                "OK");
            
            // Open the folder
            EditorUtility.RevealInFinder(PluginOutputPath);
        }
        
        [MenuItem("SplatBox/Open Plugin Folder")]
        public static void OpenPluginFolder()
        {
            if (Directory.Exists(PluginOutputPath))
            {
                EditorUtility.RevealInFinder(PluginOutputPath);
            }
            else
            {
                EditorUtility.DisplayDialog("SplatBox Plugin Builder", 
                    "Plugin folder does not exist. Build the plugin first.", 
                    "OK");
            }
        }
        
        private static string GetPackageRoot()
        {
            // Find the package root by looking for package.json
            string[] guids = AssetDatabase.FindAssets("package t:TextAsset", new[] { "Packages/com.gaussiansplatting.splatbox" });
            if (guids.Length > 0)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[0]);
                return Path.GetDirectoryName(Path.GetFullPath(path));
            }
            
            // Fallback: assume we're in Assets or Packages
            string scriptPath = GetScriptPath();
            if (!string.IsNullOrEmpty(scriptPath))
            {
                // Go up from Editor folder to package root
                return Path.GetDirectoryName(Path.GetDirectoryName(scriptPath));
            }
            
            // Last resort: use Application.dataPath and try to find package root
            string dataPath = Application.dataPath;
            if (Directory.Exists(Path.Combine(dataPath, "..", "package.json")))
            {
                return Path.GetFullPath(Path.Combine(dataPath, ".."));
            }
            
            Debug.LogError("[SplatBox Plugin Builder] Could not determine package root. Please ensure the package is properly installed.");
            return null;
        }
        
        private static string GetScriptPath()
        {
            string[] guids = AssetDatabase.FindAssets("SplatBoxPluginBuilder t:MonoScript");
            if (guids.Length > 0)
            {
                return Path.GetFullPath(AssetDatabase.GUIDToAssetPath(guids[0]));
            }
            return null;
        }
        
        private static void CreateDirectoryIfNotExists(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }
        
        /// <summary>
        /// Runs a minimal player build so Runtime/Core are compiled without UNITY_EDITOR.
        /// Returns the path to the build's Data/Managed folder, or null on failure.
        /// </summary>
        private static string BuildRuntimeAndCoreDllsNoEditor()
        {
            var scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0)
            {
                Debug.LogError("[SplatBox Plugin Builder] No enabled scenes in Build Settings. Add at least one scene to build Runtime/Core DLLs.");
                return null;
            }
            
            string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string tempBuildDir = Path.Combine(projectPath, "SplatBoxPluginBuildTemp");
            if (Directory.Exists(tempBuildDir))
            {
                try { Directory.Delete(tempBuildDir, true); } catch { /* ignore */ }
            }
            Directory.CreateDirectory(tempBuildDir);
            
            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            string exeName = "SplatBoxMinimal";
            string locationPathName;
            if (target == BuildTarget.StandaloneWindows || target == BuildTarget.StandaloneWindows64)
                locationPathName = Path.Combine(tempBuildDir, exeName + ".exe");
            else if (target == BuildTarget.StandaloneOSX)
                locationPathName = Path.Combine(tempBuildDir, exeName + ".app");
            else
                locationPathName = Path.Combine(tempBuildDir, exeName);
            
            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = locationPathName,
                target = target,
                options = BuildOptions.None
            };
            
            Debug.Log($"[SplatBox Plugin Builder] Building minimal player for {target} (Runtime/Core without UNITY_EDITOR)...");
            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != BuildResult.Succeeded)
            {
                Debug.LogError($"[SplatBox Plugin Builder] Build failed: {report.summary.result}, {report.summary.totalErrors} error(s).");
                return null;
            }
            
            string managedPath = GetManagedPathFromBuildOutput(report.summary.outputPath, target);
            if (string.IsNullOrEmpty(managedPath) || !Directory.Exists(managedPath))
            {
                Debug.LogError("[SplatBox Plugin Builder] Could not find Managed folder in build output.");
                return null;
            }
            
            Debug.Log($"[SplatBox Plugin Builder] Runtime/Core DLLs built without UnityEditor reference.");
            return managedPath;
        }
        
        private static void CleanupTempBuildFolder()
        {
            string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string tempBuildDir = Path.Combine(projectPath, "SplatBoxPluginBuildTemp");
            if (Directory.Exists(tempBuildDir))
            {
                try { Directory.Delete(tempBuildDir, true); } catch { /* ignore */ }
            }
        }
        
        private static string GetManagedPathFromBuildOutput(string outputPath, BuildTarget target)
        {
            if (string.IsNullOrEmpty(outputPath)) return null;
            if (target == BuildTarget.StandaloneOSX && outputPath.EndsWith(".app"))
                return Path.Combine(outputPath, "Contents", "Data", "Managed");
            string dir = Path.GetDirectoryName(outputPath);
            string name = Path.GetFileNameWithoutExtension(outputPath);
            return Path.Combine(dir, name + "_Data", "Managed");
        }
        
        private static int CopyDll(string sourcePath, string destFolder, string fileName)
        {
            string sourceFile = Path.Combine(sourcePath, fileName);
            if (File.Exists(sourceFile))
            {
                string destFile = Path.Combine(destFolder, fileName);
                File.Copy(sourceFile, destFile, true);
                Debug.Log($"[SplatBox Plugin Builder] Copied: {fileName}");
                return 1;
            }
            else
            {
                if (fileName.EndsWith(".dll"))
                {
                    Debug.LogWarning($"[SplatBox Plugin Builder] DLL not found: {sourceFile}");
                }
                return 0;
            }
        }
        
        private static void CreatePackageJson(string outputPath)
        {
            // Unity 6 uses version format "6000.x"
            string packageJson = @"{
    ""name"": ""com.gaussiansplatting.splatbox.plugin"",
    ""version"": ""1.0.0"",
    ""displayName"": ""SplatBox Plugin (Precompiled)"",
    ""description"": ""Precompiled Gaussian Splat editing toolbox with brush tools, clone, paint, sculpt, and more."",
    ""unity"": ""6000.0"",
    ""dependencies"": {
        ""com.unity.mathematics"": ""1.2.6"",
        ""com.unity.collections"": ""2.2.1"",
        ""com.unity.burst"": ""1.8.18""
    },
    ""keywords"": [
        ""gaussian"",
        ""splatting"",
        ""3dgs"",
        ""editor"",
        ""brush"",
        ""tools"",
        ""vr"",
        ""plugin""
    ],
    ""author"": {
        ""name"": ""SplatBox""
    }
}";
            File.WriteAllText(Path.Combine(outputPath, "package.json"), packageJson);
            Debug.Log("[SplatBox Plugin Builder] Created package.json");
        }
        
        private static void CreatePluginAssemblyDefinitions(string pluginsFolder, string editorFolder)
        {
            // Runtime/Core plugins asmdef - wraps precompiled Core + Runtime DLLs
            string runtimeAsmdef = @"{
    ""name"": ""GaussianSplatting.SplatBox.Plugin"",
    ""rootNamespace"": ""GaussianSplatting.Runtime"",
    ""references"": [
        ""Unity.Mathematics"",
        ""Unity.Collections"",
        ""Unity.RenderPipelines.Core.Runtime"",
        ""Unity.RenderPipelines.Universal.Runtime""
    ],
    ""includePlatforms"": [],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": true,
    ""overrideReferences"": true,
    ""precompiledReferences"": [
        ""GaussianSplatting.SplatBox.Core.dll"",
        ""GaussianSplatting.SplatBox.Runtime.dll""
    ],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""versionDefines"": [
        {
            ""name"": ""com.unity.render-pipelines.universal"",
            ""expression"": """",
            ""define"": ""GS_ENABLE_URP""
        }
    ],
    ""noEngineReferences"": false
}";
            File.WriteAllText(Path.Combine(pluginsFolder, "GaussianSplatting.SplatBox.Plugin.asmdef"), runtimeAsmdef);
            
            // Editor plugins asmdef - wraps precompiled Editor DLL
            string editorAsmdef = @"{
    ""name"": ""GaussianSplatting.SplatBox.Plugin.Editor"",
    ""rootNamespace"": ""GaussianSplatting.Editor"",
    ""references"": [
        ""GaussianSplatting.SplatBox.Plugin"",
        ""Unity.Mathematics"",
        ""Unity.Collections"",
        ""Unity.Burst""
    ],
    ""includePlatforms"": [
        ""Editor""
    ],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": true,
    ""overrideReferences"": true,
    ""precompiledReferences"": [
        ""GaussianSplatting.SplatBox.Editor.dll""
    ],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""versionDefines"": [],
    ""noEngineReferences"": false
}";
            File.WriteAllText(Path.Combine(editorFolder, "GaussianSplatting.SplatBox.Plugin.Editor.asmdef"), editorAsmdef);
            
            Debug.Log("[SplatBox Plugin Builder] Created assembly definition files");
        }
        
        private static void CreateDllMeta(string folder, string dllFileName, bool isEditorOnly)
        {
            // Generate a stable GUID from the DLL name
            string guid = ComputeStableGuid(dllFileName);
            
            string platformSection;
            if (isEditorOnly)
            {
                platformSection = @"  platformData:
  - first:
      Any: 
    second:
      enabled: 0
      settings: {}
  - first:
      Editor: Editor
    second:
      enabled: 1
      settings:
        DefaultValueInitialized: true";
            }
            else
            {
                platformSection = @"  platformData:
  - first:
      Any: 
    second:
      enabled: 1
      settings: {}
  - first:
      Editor: Editor
    second:
      enabled: 1
      settings:
        DefaultValueInitialized: true";
            }
            
            string meta = $@"fileFormatVersion: 2
guid: {guid}
PluginImporter:
  externalObjects: {{}}
  serializedVersion: 2
  iconMap: {{}}
  executionOrder: {{}}
  defineConstraints: []
  isPreloaded: 0
  isOverridable: 0
  isExplicitlyReferenced: 0
  validateReferences: 0
{platformSection}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
";
            string metaPath = Path.Combine(folder, dllFileName + ".meta");
            File.WriteAllText(metaPath, meta);
            Debug.Log($"[SplatBox Plugin Builder] Created .meta for {dllFileName} (validateReferences: 0)");
        }
        
        private static string ComputeStableGuid(string input)
        {
            // Create a deterministic GUID from the input string so it stays consistent across builds
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] hash = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes("SplatBox_" + input));
                return new Guid(hash).ToString("N");
            }
        }
        
        private static void CreateReadme(string outputPath)
        {
#if GS_ENABLE_URP
            string urpStatus = "YES - GaussianSplatURPFeature included";
#else
            string urpStatus = "NO - GaussianSplatURPFeature NOT included (rebuild with URP for full support)";
#endif
            string readme = $@"# SplatBox Plugin (Precompiled)

Precompiled DLL version of SplatBox - Gaussian Splat editing tools for Unity.

**Build Info:**
- Unity Version: {Application.unityVersion}
- URP Support: {urpStatus}
- Build Date: {System.DateTime.Now:yyyy-MM-dd HH:mm}

## Installation

### Option 1: Unity Package Manager
1. Open Unity Package Manager (Window > Package Manager)
2. Click '+' and select 'Add package from disk...'
3. Navigate to this folder and select `package.json`

### Option 2: Manual Installation
1. Copy this entire folder to your Unity project's `Packages/` folder
2. Rename the folder to `com.gaussiansplatting.splatbox.plugin`

## Requirements

- **Unity 6** (6000.0+) - this plugin was compiled with Unity {Application.unityVersion}
- Universal Render Pipeline (URP) required for splat rendering
- Required packages (auto-installed via dependencies):
  - com.unity.mathematics
  - com.unity.collections
  - com.unity.burst
  - com.unity.render-pipelines.universal

**IMPORTANT:** Use this plugin with the same major Unity version it was built with.
Mixing Unity versions may cause Burst/TypeCache compatibility errors.

## URP Setup

The **Gaussian Splat URP Feature** is automatically added to all URP renderers when the editor loads.
If needed, you can re-run it manually via **SplatBox > Setup URP Renderer Features**.

(Optional) Add **Gaussian Tilt Shift Renderer Feature** manually to your URP Renderer Asset for tilt-shift effects.

## PC VR (Stereo Rendering)

PCVR stereo rendering is supported via **Multi-Pass** mode:

1. In **Project Settings > XR Plug-in Management**, enable your headset plug-in (OpenXR, Oculus, etc.)
2. In your **URP Renderer Asset**, set **Rendering Path** to **Multi-Pass**
3. Splats will render correctly to both eyes automatically

> **Note:** Single Pass Instanced is not currently supported for Gaussian Splats. Use Multi-Pass.

## Contents

- `Plugins/` - Precompiled DLL files
  - `GaussianSplatting.SplatBox.Core.dll` - Core rendering and data structures
  - `GaussianSplatting.SplatBox.Runtime.dll` - Runtime components, brushes, and URP features
  - `Editor/GaussianSplatting.SplatBox.Editor.dll` - Editor tools and inspectors
- `Editor/Icons/` - Editor icon assets
- `Shaders/` - Shader and compute shader files (required for rendering)
- `Resources/` - Runtime-loadable assets (required for Windows standalone builds)

## Usage

After installation, the SplatBox tools will be available in the Unity Editor.
Look for 'SplatBox' in the menu bar and component menus.
";
            File.WriteAllText(Path.Combine(outputPath, "README.md"), readme);
            Debug.Log("[SplatBox Plugin Builder] Created README.md");
        }
    }
}
