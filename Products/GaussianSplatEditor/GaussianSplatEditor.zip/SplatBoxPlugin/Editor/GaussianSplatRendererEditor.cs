// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using GaussianSplatting.Runtime;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Mathematics;
using UnityEditor;
using UnityEditor.EditorTools;
using UnityEngine;
using SplatBoxRenderer = GaussianSplatting.Runtime.SplatBoxRenderer;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(SplatBoxRenderer))]
    [CanEditMultipleObjects]
    public class GaussianSplatRendererEditor : UnityEditor.Editor
    {
        SerializedProperty m_PropAsset;
        SerializedProperty m_PropSplatScale;
        SerializedProperty m_PropRenderScale;
        SerializedProperty m_PropOpacityScale;
        SerializedProperty m_PropRenderOrder;
        SerializedProperty m_PropSortNthFrame;
        SerializedProperty m_PropReuseSortAcrossEyes;
        SerializedProperty m_PropSortByCameraDistanceOnMobile;
        SerializedProperty m_PropStableDeterministicSortOnMobile;
        SerializedProperty m_PropStableSortMaxDistance;
        SerializedProperty m_PropAutoStableSortDepth;
        SerializedProperty m_PropStableSortWhileRotatingOnMobile;
        SerializedProperty m_PropMobileSortMoveThreshold;
        SerializedProperty m_PropMobileSortMovingThreshold;
        SerializedProperty m_PropFastSort16BitOnMobile;
        SerializedProperty m_PropDisableGpuRadixSortOnMobile;
        SerializedProperty m_PropPagedScene;
        SerializedProperty m_PropLodSimpleMode;
        SerializedProperty m_PropLodQuality;
        SerializedProperty m_PropLodSplatBudget;
        SerializedProperty m_PropLodFastEditorPreview;
        SerializedProperty m_PropLodPixelScaleLimit;
        SerializedProperty m_PropLodDetailScale;
        SerializedProperty m_PropLodFrustumCull;
        SerializedProperty m_PropLodDrawCoarseStandIns;
        SerializedProperty m_PropLodMaxStandInPixels;
        SerializedProperty m_PropLodCullPadding;
        SerializedProperty m_PropLodAtlasBudget;
        SerializedProperty m_PropOutsideFoveate;
        SerializedProperty m_PropBehindFoveate;
        SerializedProperty m_PropCutouts;
        
        // Physics properties
        SerializedProperty m_PropEnablePhysics;
        SerializedProperty m_PropGravity;
        SerializedProperty m_PropDamping;
        SerializedProperty m_PropSplatMass;
        SerializedProperty m_PropMinVelocity;
        SerializedProperty m_PropDebugPhysics;

        // Distance culling properties
        SerializedProperty m_PropEnableDistanceCulling;
        SerializedProperty m_PropKillRadius;
        SerializedProperty m_PropCullOrigin;
        SerializedProperty m_PropAutoDistanceCull;
        SerializedProperty m_PropCullEveryNthFrame;

        // Wind system properties
        SerializedProperty m_PropEnableWind;
        SerializedProperty m_PropWindUpdateEveryNthFrame;
        SerializedProperty m_PropWindGravity;
        SerializedProperty m_PropWindDamping;
        SerializedProperty m_PropWindMinVelocity;

        // Color adjustment properties
        SerializedProperty m_PropExposure;
        SerializedProperty m_PropContrast;
        SerializedProperty m_PropColorFilter;
        SerializedProperty m_PropHueShift;
        SerializedProperty m_PropSaturation;

        int m_CameraIndex = 0;

        static readonly GUIContent[] s_LodModeLabels =
        {
            new GUIContent("Simple", "One Quality slider drives the whole LoD system; everything " +
                                     "else uses tuned defaults."),
            new GUIContent("Advanced", "Hand-tune every LoD setting. The current Quality is baked " +
                                       "into the fields as a starting point."),
        };

        static int s_EditStatsUpdateCounter = 0;

        static HashSet<GaussianSplatRendererEditor> s_AllEditors = new();

        public static void BumpGUICounter()
        {
            ++s_EditStatsUpdateCounter;
        }

        public static void RepaintAll()
        {
            foreach (var e in s_AllEditors)
                e.Repaint();
        }

        public void OnEnable()
        {
            // ToolManager.RegisterTool<GaussianSplatPaintTool>();
            m_PropAsset = serializedObject.FindProperty("m_Asset");
            m_PropSplatScale = serializedObject.FindProperty("m_SplatScale");
            m_PropRenderScale = serializedObject.FindProperty("m_RenderScale");
            m_PropOpacityScale = serializedObject.FindProperty("m_OpacityScale");
            m_PropRenderOrder = serializedObject.FindProperty("m_RenderOrder");
            m_PropSortNthFrame = serializedObject.FindProperty("m_SortNthFrame");
            m_PropReuseSortAcrossEyes = serializedObject.FindProperty("m_ReuseSortAcrossEyes");
            m_PropSortByCameraDistanceOnMobile = serializedObject.FindProperty("m_SortByCameraDistanceOnMobile");
            m_PropStableDeterministicSortOnMobile = serializedObject.FindProperty("m_StableDeterministicSortOnMobile");
            m_PropStableSortMaxDistance = serializedObject.FindProperty("m_StableSortMaxDistance");
            m_PropAutoStableSortDepth = serializedObject.FindProperty("m_AutoStableSortDepth");
            m_PropStableSortWhileRotatingOnMobile = serializedObject.FindProperty("m_StableSortWhileRotatingOnMobile");
            m_PropMobileSortMoveThreshold = serializedObject.FindProperty("m_MobileSortMoveThreshold");
            m_PropMobileSortMovingThreshold = serializedObject.FindProperty("m_MobileSortMovingThreshold");
            m_PropFastSort16BitOnMobile = serializedObject.FindProperty("m_FastSort16BitOnMobile");
            m_PropDisableGpuRadixSortOnMobile = serializedObject.FindProperty("m_DisableGpuRadixSortOnMobile");
            m_PropPagedScene = serializedObject.FindProperty("m_PagedScene");
            m_PropLodSimpleMode = serializedObject.FindProperty(SplatBoxRenderer.kPropLodSimpleMode);
            m_PropLodQuality = serializedObject.FindProperty(SplatBoxRenderer.kPropLodQuality);
            m_PropLodSplatBudget = serializedObject.FindProperty("m_LodSplatBudget");
            m_PropLodFastEditorPreview = serializedObject.FindProperty("m_LodFastEditorPreview");
            m_PropLodPixelScaleLimit = serializedObject.FindProperty("m_LodPixelScaleLimit");
            m_PropLodDetailScale = serializedObject.FindProperty("m_LodDetailScale");
            m_PropLodFrustumCull = serializedObject.FindProperty("m_LodFrustumCull");
            m_PropLodDrawCoarseStandIns = serializedObject.FindProperty("m_LodDrawCoarseStandIns");
            m_PropLodMaxStandInPixels = serializedObject.FindProperty("m_LodMaxStandInPixels");
            m_PropLodCullPadding = serializedObject.FindProperty("m_LodCullPaddingDeg");
            m_PropLodAtlasBudget = serializedObject.FindProperty("m_LodAtlasBudgetMB");
            m_PropOutsideFoveate = serializedObject.FindProperty("m_OutsideFoveate");
            m_PropBehindFoveate = serializedObject.FindProperty("m_BehindFoveate");
            m_PropCutouts = serializedObject.FindProperty("m_Cutouts");
            
            // Physics properties
            m_PropEnablePhysics = serializedObject.FindProperty("m_EnablePhysics");
            m_PropGravity = serializedObject.FindProperty("m_Gravity");
            m_PropDamping = serializedObject.FindProperty("m_Damping");
            m_PropSplatMass = serializedObject.FindProperty("m_SplatMass");
            m_PropMinVelocity = serializedObject.FindProperty("m_MinVelocity");
            m_PropDebugPhysics = serializedObject.FindProperty("m_DebugPhysics");

            // Distance culling properties
            m_PropEnableDistanceCulling = serializedObject.FindProperty("m_EnableDistanceCulling");
            m_PropKillRadius = serializedObject.FindProperty("m_KillRadius");
            m_PropCullOrigin = serializedObject.FindProperty("m_CullOrigin");
            m_PropAutoDistanceCull = serializedObject.FindProperty("m_AutoDistanceCull");
            m_PropCullEveryNthFrame = serializedObject.FindProperty("m_CullEveryNthFrame");

            // Wind system properties
            m_PropEnableWind = serializedObject.FindProperty("m_EnableWind");
            m_PropWindUpdateEveryNthFrame = serializedObject.FindProperty("m_WindUpdateEveryNthFrame");
            m_PropWindGravity = serializedObject.FindProperty("m_WindGravity");
            m_PropWindDamping = serializedObject.FindProperty("m_WindDamping");
            m_PropWindMinVelocity = serializedObject.FindProperty("m_WindMinVelocity");

            // Color adjustment properties
            m_PropExposure = serializedObject.FindProperty("m_Exposure");
            m_PropContrast = serializedObject.FindProperty("m_Contrast");
            m_PropColorFilter = serializedObject.FindProperty("m_ColorFilter");
            m_PropHueShift = serializedObject.FindProperty("m_HueShift");
            m_PropSaturation = serializedObject.FindProperty("m_Saturation");

            s_AllEditors.Add(this);
        }

        public void OnDisable()
        {
            s_AllEditors.Remove(this);
            // ToolManager.UnregisterTool<GaussianSplatPaintTool>();
        }

        public override void OnInspectorGUI()
        {
            var gs = target as SplatBoxRenderer;
            if (!gs)
                return;

            serializedObject.Update();

            // Asset Section — monolithic OR paged streaming (mutually exclusive)
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Asset Source", EditorStyles.boldLabel);

            bool hasPagedScene = m_PropPagedScene.objectReferenceValue != null;
            bool hasMonolithicAsset = m_PropAsset.objectReferenceValue != null;

            EditorGUILayout.HelpBox(
                "Experimental: Paged LoD Streaming for Quest is under development and is not intended for production use.",
                MessageType.Warning);

            EditorGUI.BeginChangeCheck();
            EditorGUILayout.PropertyField(m_PropPagedScene, new GUIContent("Paged Scene (Streaming LoD)",
                "Experimental Quest/large-scene mode: spatial pages + offline LoD trees. Not intended for production use. When set, the monolithic Asset field is unused."));
            if (EditorGUI.EndChangeCheck() && m_PropPagedScene.objectReferenceValue != null)
                m_PropAsset.objectReferenceValue = null;

            EditorGUI.BeginChangeCheck();
            using (new EditorGUI.DisabledScope(hasPagedScene))
            {
                EditorGUILayout.PropertyField(m_PropAsset, new GUIContent("Asset (Monolithic)",
                    "Single GaussianSplatAsset loaded entirely into GPU memory. Clear Paged Scene to use this."));
            }
            if (EditorGUI.EndChangeCheck() && m_PropAsset.objectReferenceValue != null)
                m_PropPagedScene.objectReferenceValue = null;

            if (hasPagedScene)
            {
                EditorGUILayout.HelpBox(
                    "Streaming LoD mode: pages load/unload by distance from the Main Camera " +
                    "(fallback: Scene view if none). Detail follows the Quality slider (Simple) or the " +
                    "individual LoD settings (Advanced). Leave Asset empty. Press F to frame.",
                    MessageType.Info);

                if (gs.hasLegacyLodPages)
                {
                    EditorGUILayout.HelpBox(
                        "These pages were built with the old depth-first LoD layout, so distant pages can only " +
                        "show a single splat each and large parts of the model stay invisible. Rebuild the scene " +
                        "with Tools > Gaussian Splatting > Create Paged LoD Scene to get proper coarse LoD levels.",
                        MessageType.Warning);
                }
            }
            else if (hasMonolithicAsset)
            {
                EditorGUILayout.HelpBox("Monolithic mode: the full asset is loaded at once. Clear Asset to use Paged Scene streaming.", MessageType.Info);
            }

            if (!gs.HasValidAsset)
            {
                var msg = hasPagedScene
                    ? "Paged scene is not assigned or has no pages."
                    : gs.asset != null && gs.asset.formatVersion != GaussianSplatAsset.kCurrentVersion
                        ? "Gaussian Splat asset version is not compatible, please recreate the asset"
                        : "Assign a monolithic Asset or a Paged Scene.";
                EditorGUILayout.HelpBox(msg, MessageType.Error);
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            // Rendering Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Rendering", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(m_PropRenderOrder, new GUIContent("Layer", "Rendering order compared to other splats. Higher values render on top."));
            EditorGUILayout.PropertyField(m_PropSplatScale, new GUIContent("Size", "Scale factor for splat size."));
            EditorGUILayout.Slider(m_PropRenderScale, 0.1f, 1f, new GUIContent(
                "Render Scale",
                "Resolution of the offscreen splat image per eye. Lower values reduce splat rasterization and " +
                "bandwidth, then bilinearly upscale to the eye target. Does not reduce splat count or sorting. " +
                "Try 0.6-0.75 on Quest."));
            EditorGUILayout.PropertyField(m_PropOpacityScale, new GUIContent("Opacity", "Additional scaling factor for opacity."));
            EditorGUILayout.PropertyField(m_PropSortNthFrame, new GUIContent("Sort Interval", "Sort splats only every N frames (1 = every frame, higher = less frequent)."));
            EditorGUILayout.PropertyField(m_PropReuseSortAcrossEyes, new GUIContent("Reuse Sort Across Eyes", "VR only: reuse one sort for both eyes. Faster, but can shimmer/flicker in VR."));
            EditorGUILayout.PropertyField(m_PropSortByCameraDistanceOnMobile, new GUIContent("Quest Camera Distance Sort", "Android/Quest only: sort by distance from the camera instead of view-space Z. More stable during head rotation, slightly less exact transparency."));
            EditorGUILayout.PropertyField(m_PropStableDeterministicSortOnMobile, new GUIContent("Quest Deterministic Sort", "Android/Quest only: pack quantized depth + splat index into a unique sort key so equal-depth splats never swap order frame to frame. Removes the flickering 'extra layer' from an unstable mobile radix sort."));
            if (m_PropStableDeterministicSortOnMobile.boolValue)
            {
                EditorGUILayout.PropertyField(m_PropAutoStableSortDepth, new GUIContent("Auto Sort Depth", "Auto-fit the deterministic sort depth to this asset's world-space size every frame for best precision. Turn off to set the depth manually."));
                using (new EditorGUI.DisabledScope(m_PropAutoStableSortDepth.boolValue))
                {
                    EditorGUILayout.PropertyField(m_PropStableSortMaxDistance, new GUIContent("Deterministic Sort Depth", "Meters of depth the deterministic sort spans. Set just above your scene's front-to-back depth for best precision; splats beyond it share the farthest bucket. Ignored while Auto Sort Depth is on."));
                }
            }
            EditorGUILayout.PropertyField(m_PropStableSortWhileRotatingOnMobile, new GUIContent("Quest Stable Rotation Sort", "Android/Quest only: keep sort order while the headset only rotates. Projection still updates every frame; sorting refreshes when position moves."));
            if (m_PropStableSortWhileRotatingOnMobile.boolValue)
            {
                EditorGUILayout.PropertyField(m_PropMobileSortMoveThreshold, new GUIContent("Stable Sort Move Threshold", "Meters the headset must move before the sort order refreshes."));
                EditorGUILayout.PropertyField(m_PropMobileSortMovingThreshold, new GUIContent("Walking Sort Threshold", "Meters of headset movement between frames that counts as walking. While walking, sorting refreshes every frame."));
            }
            EditorGUILayout.PropertyField(m_PropFastSort16BitOnMobile, new GUIContent("Quest Fast 16-bit Sort", "Android/Quest only: use a 16-bit quantized depth key so the GPU radix sort runs 2 passes instead of 4 (~2x faster sort). 65536 depth buckets is finer than any visible transparency error. Ignored while Quest Deterministic Sort is on (that needs a full 32-bit key)."));
            EditorGUILayout.PropertyField(m_PropDisableGpuRadixSortOnMobile, new GUIContent("Disable Mobile GPU Radix Sort", "Diagnostic only: bypass wave-intrinsic GPU radix sort on Android/Vulkan and draw stable identity order. This can render incorrectly and reduce performance."));

            if (hasPagedScene)
            {
                EditorGUILayout.Space(4);
                EditorGUILayout.LabelField("Paged LoD Settings", EditorStyles.boldLabel);

                int lodMode = m_PropLodSimpleMode.boolValue ? 0 : 1;
                int newLodMode = GUILayout.Toolbar(lodMode, s_LodModeLabels);
                if (newLodMode != lodMode)
                {
                    // Bake values across the switch so the picture on screen does not change:
                    // Advanced starts from what Simple was showing, and Simple picks the quality
                    // closest to the hand-tuned budget.
                    if (newLodMode == 1)
                        BakeSimpleQualityIntoAdvancedFields();
                    else
                        AdoptQualityFromAdvancedFields();
                    m_PropLodSimpleMode.boolValue = newLodMode == 0;
                }
                EditorGUILayout.Space(2);

                if (m_PropLodSimpleMode.boolValue)
                {
                    EditorGUILayout.Slider(m_PropLodQuality, 0f, 1f, SplatBoxLodQualityGUI.qualitySliderLabel);
                    EditorGUILayout.LabelField(" ",
                        SplatBoxLodQualityGUI.QualitySummary(m_PropLodQuality.floatValue),
                        EditorStyles.miniLabel);
                    EditorGUILayout.PropertyField(m_PropLodFastEditorPreview, new GUIContent(
                        "Fast Editor Preview",
                        "Use the standard Gaussian shader for paged LoD in edit mode. Relight evaluates " +
                        "lighting six times per splat and is substantially slower. Play mode and builds " +
                        "still use the configured relight shader."));
                }
                else
                {
                    EditorGUILayout.PropertyField(m_PropLodSplatBudget, new GUIContent("LoD Splat Budget", "Max splats rendered after LoD traversal (~500K Quest default)."));
                    EditorGUILayout.PropertyField(m_PropLodFastEditorPreview, new GUIContent(
                        "Fast Editor Preview",
                        "Use the standard Gaussian shader for paged LoD in edit mode. Relight evaluates " +
                        "lighting six times per splat and is substantially slower. Play mode and builds " +
                        "still use the configured relight shader."));
                    EditorGUILayout.PropertyField(m_PropLodDetailScale, new GUIContent("LoD Detail Scale", "Quality multiplier. Below 1 the scene refines as if it were smaller on screen. Does not change the splat budget."));
                    EditorGUILayout.PropertyField(m_PropLodPixelScaleLimit, new GUIContent("Pixel Scale Limit", "Stop refining LoD nodes once they cover fewer than this many screen pixels. Leave at 0 to tune it automatically to fit the budget."));
                    EditorGUILayout.PropertyField(m_PropLodFrustumCull, new GUIContent("Frustum Cull LoD", "Skip LoD nodes outside the camera view so the whole splat budget is spent on visible detail."));
                    EditorGUILayout.PropertyField(m_PropLodDrawCoarseStandIns, new GUIContent("Draw Coarse Stand-ins", "Draw the merged splats that stand in for pages held at coarse detail. Turn this off to draw only real splats: the scene gets holes where detail is missing, but nothing is approximated."));
                    if (!m_PropLodDrawCoarseStandIns.boolValue)
                    {
                        EditorGUILayout.HelpBox(
                            "Coarse stand-ins are hidden, so pages outside the detail radius draw nothing. " +
                            "Rebuild the paged scene and turn this back on for a complete view.",
                            MessageType.Info);
                    }
                    using (new EditorGUI.DisabledScope(!m_PropLodDrawCoarseStandIns.boolValue))
                    {
                        EditorGUILayout.PropertyField(m_PropLodMaxStandInPixels, new GUIContent("Max Stand-in Size (px)", "Drop a coarse stand-in once it would cover more than this many screen pixels. Blend cost grows with area while the splat budget only counts splats, so one huge stand-in costs thousands of refined splats and represents almost nothing. Lower is faster and leaves holes until detail streams in. 0 disables the limit."));
                    }
                    EditorGUILayout.PropertyField(m_PropLodCullPadding, new GUIContent("Cull Padding", "Extra degrees of field of view used when culling, so splats do not pop in at the edge of the view. Stereo cameras get an extra margin automatically."));
                    EditorGUILayout.PropertyField(m_PropLodAtlasBudget, new GUIContent("LoD Atlas Budget (MB)", "GPU memory ceiling for the resident page atlas. Fewer pages are kept at full detail when the budget is tight. Keep well below total VRAM (256 MB or less on Quest)."));
                    EditorGUILayout.PropertyField(m_PropOutsideFoveate, new GUIContent("Outside Foveate", "Reduce LoD resolution outside the view frustum."));
                    EditorGUILayout.PropertyField(m_PropBehindFoveate, new GUIContent("Behind Foveate", "Reduce LoD resolution behind the camera."));
                }

                EditorGUILayout.Space(4);
                if (GUILayout.Button(new GUIContent("Reset LoD Settings",
                        "Restore Simple mode at Quality 0.5 and every Advanced knob to its field default."),
                    GUILayout.Height(22)))
                {
                    Undo.RecordObject(gs, "Reset LoD Settings");
                    SplatBoxLodQualityGUI.ApplyLodSettingDefaults(serializedObject);
                }
            }
            EditorGUI.indentLevel--;
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            // Color Adjustments Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Color Adjustments", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            EditorGUILayout.Slider(m_PropExposure, -2f, 5f, new GUIContent("Exposure", "Brightness adjustment (-2 to +5). Positive values brighten, negative values darken."));
            EditorGUILayout.PropertyField(m_PropContrast, new GUIContent("Contrast", "Contrast adjustment. 1.0 is neutral, higher values increase contrast."));
            EditorGUILayout.PropertyField(m_PropSaturation, new GUIContent("Saturation", "Saturation adjustment. 1.0 is neutral, 0.0 is grayscale, higher values increase saturation."));
            EditorGUILayout.PropertyField(m_PropHueShift, new GUIContent("Hue Shift", "Hue shift in degrees. Rotates the color wheel."));
            EditorGUILayout.PropertyField(m_PropColorFilter, new GUIContent("Color Filter", "Color tint/filter applied to splats."));
            EditorGUI.indentLevel--;
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            // Physics Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Physics", EditorStyles.boldLabel);
            
            if (m_PropEnablePhysics == null)
            {
                EditorGUILayout.HelpBox("Physics properties not found! Try recompiling scripts.", MessageType.Error);
                if (GUILayout.Button("Force Enable Physics via Code"))
                {
                    gs.enablePhysics = true;
                    EditorUtility.SetDirty(gs);
                }
            }
            else
            {
                EditorGUILayout.PropertyField(m_PropEnablePhysics, new GUIContent("Enable Physics"));
                
                if (m_PropEnablePhysics.boolValue)
                {
                    EditorGUI.indentLevel++;
                    EditorGUILayout.PropertyField(m_PropGravity, new GUIContent("Gravity"));
                    EditorGUILayout.PropertyField(m_PropDamping, new GUIContent("Damping"));
                    EditorGUILayout.PropertyField(m_PropSplatMass, new GUIContent("Splat Mass"));
                    EditorGUILayout.PropertyField(m_PropMinVelocity, new GUIContent("Min Velocity"));
                    EditorGUILayout.PropertyField(m_PropDebugPhysics, new GUIContent("Debug Physics"));
                    EditorGUI.indentLevel--;
                    
                    EditorGUILayout.Space(3);
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button("Reset Physics", GUILayout.Height(22)))
                    {
                        gs.ResetPhysics();
                    }
                    if (GUILayout.Button("Debug Coordinates", GUILayout.Height(22)))
                    {
                        gs.DebugPhysicsCoordinates();
                    }
                    GUILayout.EndHorizontal();
                }
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            // Distance Culling Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Distance Culling", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(m_PropEnableDistanceCulling, new GUIContent("Enable Distance Culling"));
            
            if (m_PropEnableDistanceCulling.boolValue)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(m_PropKillRadius, new GUIContent("Kill Radius (m)", "Distance in meters beyond which splats are deleted"));
                EditorGUILayout.PropertyField(m_PropCullOrigin, new GUIContent("Cull Origin", "Origin point for distance calculation (uses camera if null)"));
                EditorGUILayout.PropertyField(m_PropAutoDistanceCull, new GUIContent("Auto Distance Cull", "Automatically perform distance culling"));
                
                if (m_PropAutoDistanceCull.boolValue)
                {
                    EditorGUILayout.PropertyField(m_PropCullEveryNthFrame, new GUIContent("Cull Every N Frames", "Perform culling every N frames for performance"));
                }
                
                EditorGUI.indentLevel--;
                
                EditorGUILayout.Space(3);
                EditorGUILayout.HelpBox("Distance culling removes splats beyond the kill radius to improve performance.", MessageType.Info);
                
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Perform Distance Cull Now", GUILayout.Height(22)))
                {
                    gs.PerformDistanceCulling();
                }
                if (GUILayout.Button("Show Culled Count", GUILayout.Height(22)))
                {
                    uint culledCount = gs.GetCulledSplatsCount();
                    Debug.Log($"Currently culled splats: {culledCount:N0}");
                }
                GUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            // Wind System Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Wind System", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            bool windEnabled = EditorGUILayout.Toggle(new GUIContent("Enable Wind Effects"), m_PropEnableWind?.boolValue ?? false);
            if (EditorGUI.EndChangeCheck())
            {
                if (m_PropEnableWind != null)
                    m_PropEnableWind.boolValue = windEnabled;
                    
                if (windEnabled)
                {
                    gs.enablePhysics = true;
                    if (m_PropEnablePhysics != null)
                        m_PropEnablePhysics.boolValue = true;
                    Debug.Log("Auto-enabled physics for wind system");
                }
            }
            
            if (windEnabled)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(m_PropWindUpdateEveryNthFrame, new GUIContent("Update Every N Frames", "Update wind forces every N frames for performance"));
                
                EditorGUILayout.Space(3);
                EditorGUILayout.LabelField("Wind Physics Settings", EditorStyles.miniBoldLabel);
                EditorGUILayout.PropertyField(m_PropWindGravity, new GUIContent("Wind Gravity", "Gravity applied to wind-affected splats"));
                EditorGUILayout.PropertyField(m_PropWindDamping, new GUIContent("Wind Damping", "Damping applied to wind movement (0=no damping, 1=full damping)"));
                EditorGUILayout.PropertyField(m_PropWindMinVelocity, new GUIContent("Wind Min Velocity", "Minimum velocity threshold for wind effects"));
                
                EditorGUILayout.Space(3);
                EditorGUILayout.HelpBox("Wind physics settings are separate from sphere collider physics. Adjust these to control how wind-affected splats behave.", MessageType.Info);
                
                bool physicsEnabled = gs.enablePhysics;
                EditorGUILayout.LabelField($"Physics Status: {(physicsEnabled ? "Enabled" : "DISABLED")}");
                if (!physicsEnabled)
                {
                    EditorGUILayout.HelpBox("Physics is not enabled! Wind effects won't work.", MessageType.Error);
                    if (GUILayout.Button("Enable Physics Now", GUILayout.Height(22)))
                    {
                        gs.enablePhysics = true;
                        EditorUtility.SetDirty(gs);
                        Debug.Log("Physics enabled for wind system");
                    }
                }
                
                EditorGUI.indentLevel--;
                
                EditorGUILayout.Space(3);
                GUILayout.BeginHorizontal();
                if (GUILayout.Button("Reset Physics", GUILayout.Height(22)))
                {
                    gs.ResetPhysics();
                }
                if (GUILayout.Button("Debug Wind System", GUILayout.Height(22)))
                {
                    gs.DebugWindSystem();
                }
                GUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();

            bool validAndEnabled = gs && gs.enabled && gs.gameObject.activeInHierarchy && gs.HasValidAsset;
            if (validAndEnabled && !gs.HasValidRenderSetup)
            {
                EditorGUILayout.HelpBox("Shader resources are not set up", MessageType.Error);
                validAndEnabled = false;
            }

            if (validAndEnabled && targets.Length == 1)
            {
                EditCameras(gs);
                EditGUI(gs);
            }
            if (validAndEnabled && targets.Length > 1)
            {
                MultiEditGUI();
            }

            serializedObject.ApplyModifiedProperties();
        }

        /// <summary>
        /// Switching Simple -> Advanced: write the values the Quality slider was producing into the
        /// detailed fields, so Advanced starts from the picture currently on screen instead of
        /// whatever was left behind by earlier experiments.
        /// </summary>
        void BakeSimpleQualityIntoAdvancedFields()
        {
            float q = m_PropLodQuality.floatValue;
            m_PropLodSplatBudget.intValue = SplatBoxRenderer.LodQualityToBudget(q);
            m_PropLodPixelScaleLimit.floatValue = q >= 0.999f ? 0f : SplatBoxRenderer.LodQualityToPixelCutoff(q);
            m_PropLodDetailScale.floatValue = 1f;
            m_PropOutsideFoveate.floatValue = SplatBoxRenderer.LodQualityToOutsideFoveate(q);
            m_PropBehindFoveate.floatValue = SplatBoxRenderer.LodQualityToBehindFoveate(q);
            m_PropLodFrustumCull.boolValue = true;
            m_PropLodDrawCoarseStandIns.boolValue = true;
            m_PropLodMaxStandInPixels.floatValue = SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels;
            m_PropLodCullPadding.floatValue = 10f;
        }

        /// <summary>
        /// Switching Advanced -> Simple: pick the Quality whose budget is closest to the hand-tuned
        /// one. Detail Scale goes back to 1 because Simple mode keeps it as a runtime-only
        /// multiplier, where a stale tuned value would silently degrade quality under the slider.
        /// </summary>
        void AdoptQualityFromAdvancedFields()
        {
            m_PropLodQuality.floatValue = SplatBoxRenderer.LodQualityFromBudget(m_PropLodSplatBudget.intValue);
            m_PropLodDetailScale.floatValue = 1f;
        }

        void EditCameras(SplatBoxRenderer gs)
        {
            var asset = gs.asset;
            var cameras = asset.cameras;
            if (cameras != null && cameras.Length != 0)
            {
                EditorGUILayout.Space(5);
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.LabelField("Cameras", EditorStyles.boldLabel);
                var camIndex = EditorGUILayout.IntSlider("Camera", m_CameraIndex, 0, cameras.Length - 1);
                camIndex = math.clamp(camIndex, 0, cameras.Length - 1);
                if (camIndex != m_CameraIndex)
                {
                    m_CameraIndex = camIndex;
                    gs.ActivateCamera(camIndex);
                }
                EditorGUILayout.EndVertical();
            }
        }

        void MultiEditGUI()
        {
            DrawSeparator();
            
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Multi-Object Merge", EditorStyles.boldLabel);
            
            CountTargetSplats(out var totalSplats, out var totalObjects);
            EditorGUILayout.LabelField("Total Objects", $"{totalObjects}");
            EditorGUILayout.LabelField("Total Splats", $"{totalSplats:N0}");
            
            if (totalSplats > GaussianSplatAsset.kMaxSplats)
            {
                EditorGUILayout.HelpBox($"Can't merge, too many splats (max. supported {GaussianSplatAsset.kMaxSplats:N0})", MessageType.Warning);
                EditorGUILayout.EndVertical();
                return;
            }

            var targetGs = (SplatBoxRenderer) target;
            if (!targetGs || !targetGs.HasValidAsset || !targetGs.isActiveAndEnabled)
            {
                EditorGUILayout.HelpBox($"Can't merge into {target.name} (no asset or disable)", MessageType.Warning);
                EditorGUILayout.EndVertical();
                return;
            }

            if (targetGs.asset.chunkData != null)
            {
                EditorGUILayout.HelpBox($"Can't merge into {target.name} (needs to use Very High quality preset)", MessageType.Warning);
                EditorGUILayout.EndVertical();
                return;
            }
            
            EditorGUILayout.Space(3);
            if (GUILayout.Button($"Merge into {target.name}", GUILayout.Height(24)))
            {
                MergeSplatObjects();
            }
            EditorGUILayout.EndVertical();
        }

        void CountTargetSplats(out int totalSplats, out int totalObjects)
        {
            totalObjects = 0;
            totalSplats = 0;
            foreach (var obj in targets)
            {
                var gs = obj as SplatBoxRenderer;
                if (!gs || !gs.HasValidAsset || !gs.isActiveAndEnabled)
                    continue;
                ++totalObjects;
                totalSplats += gs.splatCount;
            }
        }

        void MergeSplatObjects()
        {
            CountTargetSplats(out var totalSplats, out _);
            if (totalSplats > GaussianSplatAsset.kMaxSplats)
                return;
            var targetGs = (SplatBoxRenderer) target;

            int copyDstOffset = targetGs.splatCount;
            targetGs.EditSetSplatCount(totalSplats);
            foreach (var obj in targets)
            {
                var gs = obj as SplatBoxRenderer;
                if (!gs || !gs.HasValidAsset || !gs.isActiveAndEnabled)
                    continue;
                if (gs == targetGs)
                    continue;
                gs.EditCopySplatsInto(targetGs, 0, copyDstOffset, gs.splatCount);
                copyDstOffset += gs.splatCount;
                gs.gameObject.SetActive(false);
            }
            Debug.Assert(copyDstOffset == totalSplats, $"Merge count mismatch, {copyDstOffset} vs {totalSplats}");
            Selection.activeObject = targetGs;
        }

        void EditGUI(SplatBoxRenderer gs)
        {
            ++s_EditStatsUpdateCounter;

            DrawSeparator();
            
            // Statistics Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Statistics", EditorStyles.boldLabel);
            
            bool hasCutouts = gs.m_Cutouts != null && gs.m_Cutouts.Length != 0;
            bool modifiedOrHasCutouts = gs.editModified || hasCutouts;

            var asset = gs.asset;
            if (asset.posFormat > GaussianSplatAsset.VectorFormat.Norm16 ||
                asset.scaleFormat > GaussianSplatAsset.VectorFormat.Norm16 ||
                asset.colorFormat > GaussianSplatAsset.ColorFormat.Float16x4 ||
                asset.shFormat > GaussianSplatAsset.SHFormat.Float16)
            {
                EditorGUILayout.HelpBox(
                    "It is recommended to use High or VeryHigh quality preset for editing splats, lower levels are lossy",
                    MessageType.Warning);
            }

            if (gs.UsesPagedLod)
            {
                SplatBoxLodQualityGUI.DrawStats(gs);
                bool restore = SplatBoxLodQualityGUI.DrawDiagnosis(
                    gs, gs.lodPixelScaleLimit, gs.lodDetailScale, gs.lodSimpleMode);
                if (restore)
                {
                    if (gs.lodSimpleMode)
                    {
                        m_PropLodQuality.floatValue = 1f;
                    }
                    else
                    {
                        m_PropLodPixelScaleLimit.floatValue = 0f;
                        m_PropLodDetailScale.floatValue = 1f;
                    }
                    serializedObject.ApplyModifiedProperties();
                    SceneView.RepaintAll();
                }
            }
            else
            {
                EditorGUILayout.LabelField("Total Splats", $"{gs.splatCount:N0}");
            }
            if (modifiedOrHasCutouts)
            {
                EditorGUILayout.Space(3);
                EditorGUILayout.LabelField("Cut", $"{gs.editCutSplats:N0}");
                EditorGUILayout.LabelField("Deleted", $"{gs.editDeletedSplats:N0}");
                EditorGUILayout.LabelField("Selected", $"{gs.editSelectedSplats:N0}");
                if (hasCutouts)
                {
                    if (s_EditStatsUpdateCounter > 10)
                    {
                        gs.UpdateEditCountsAndBounds();
                        s_EditStatsUpdateCounter = 0;
                    }
                }
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            // Actions Section
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Actions", EditorStyles.boldLabel);
            using (new EditorGUI.DisabledScope(!gs.editModified))
            {
                if (GUILayout.Button("Reset All Modifications", GUILayout.Height(24)))
                {
                    if (EditorUtility.DisplayDialog("Reset Splat Modifications?",
                            $"This will reset edits of {gs.name} to match the {gs.asset.name} asset. Continue?",
                            "Yes, reset", "Cancel"))
                    {
                        gs.enabled = false;
                        gs.enabled = true;
                    }
                }
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("VR Erase Brush", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Attach SplatBoxVREraseBrush to your XR camera for in-headset editing. Right trigger deletes splats; thumbstick up/down adjusts brush size.",
                MessageType.Info);
            if (GUILayout.Button("Add VR Erase Brush To Main Camera", GUILayout.Height(24)))
            {
                var cam = Camera.main ?? UnityEngine.Object.FindAnyObjectByType<Camera>();
                if (cam == null)
                    EditorUtility.DisplayDialog("No Camera", "No camera found in the scene.", "OK");
                else if (cam.GetComponent<SplatBoxVREraseBrush>() != null)
                    EditorUtility.DisplayDialog("VR Erase", "SplatBoxVREraseBrush is already on " + cam.name, "OK");
                else
                {
                    Undo.AddComponent<SplatBoxVREraseBrush>(cam.gameObject);
                    var vrBrush = cam.GetComponent<SplatBoxVREraseBrush>();
                    if (vrBrush != null)
                        vrBrush.m_TargetRenderer = gs;
                }
            }
            EditorGUILayout.EndVertical();

            //EditorGUILayout.Space();
            //GUILayout.BeginHorizontal();
            //if (GUILayout.Button("Edit", GUILayout.Width(60)))
            //{
            //    Tools.current = Tool.Move;
            //}
            //if (GUILayout.Button("Paint", GUILayout.Width(60)))
            //{
            //    Debug.Log("Paint button clicked");
            //    // First activate the tool context
            //    ToolManager.SetActiveTool<GaussianToolContext>();
                
            //    // Force the tool to Custom instead of None to prevent automatic switching
            //    Tools.current = Tool.Custom;
                
            //    // Directly activate the paint tool
            //    EditorApplication.delayCall += () =>
            //    {
            //        Debug.Log("Delayed activation of Paint Tool");
            //        ToolManager.SetActiveTool<GaussianSplatPaintTool>();
            //    };
            //}
            //GUILayout.EndHorizontal();
        }

        static void DrawSeparator()
        {
            EditorGUILayout.Space(12f, true);
            GUILayout.Box(GUIContent.none, "sv_iconselector_sep", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            EditorGUILayout.Space();
        }

        bool HasFrameBounds()
        {
            return true;
        }

        Bounds OnGetFrameBounds()
        {
            var gs = target as SplatBoxRenderer;
            if (!gs || !gs.HasValidRenderSetup)
                return new Bounds(Vector3.zero, Vector3.one);
            Bounds bounds = default;
            bounds.SetMinMax(gs.asset.boundsMin, gs.asset.boundsMax);
            if (gs.editSelectedSplats > 0)
            {
                bounds = gs.editSelectedBounds;
            }
            bounds.extents *= 0.7f;
            return TransformBounds(gs.transform, bounds);
        }

        public static Bounds TransformBounds(Transform tr, Bounds bounds )
        {
            var center = tr.TransformPoint(bounds.center);

            var ext = bounds.extents;
            var axisX = tr.TransformVector(ext.x, 0, 0);
            var axisY = tr.TransformVector(0, ext.y, 0);
            var axisZ = tr.TransformVector(0, 0, ext.z);

            // sum their absolute value to get the world extents
            ext.x = Mathf.Abs(axisX.x) + Mathf.Abs(axisY.x) + Mathf.Abs(axisZ.x);
            ext.y = Mathf.Abs(axisX.y) + Mathf.Abs(axisY.y) + Mathf.Abs(axisZ.y);
            ext.z = Mathf.Abs(axisX.z) + Mathf.Abs(axisY.z) + Mathf.Abs(axisZ.z);

            return new Bounds { center = center, extents = ext };
        }


    }
}