// SPDX-License-Identifier: MIT
// Temporary diagnostic: reports which GPU buffers are actually bound for each SplatBoxRenderer.
// Vulkan skips draw calls when a shader declares a StructuredBuffer/ByteAddressBuffer that nothing
// is bound to ("Shader requires a compute buffer X, but none provided"), while D3D11 silently
// tolerates it. This dumps the state behind those bindings so the null one can be identified.

using System.Reflection;
using System.Text;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    static class SplatBoxBindingDiagnosticsMenu
    {
        const BindingFlags kAll = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        [MenuItem("Tools/Splat Box/Log Shader Bindings")]
        static void LogBindings()
        {
            var renderers = Object.FindObjectsByType<SplatBoxRenderer>(
                FindObjectsInactive.Include, FindObjectsSortMode.None);

            if (renderers == null || renderers.Length == 0)
            {
                Debug.LogWarning("[SplatBox] No SplatBoxRenderer found in the open scene(s).");
                return;
            }

            var sb = new StringBuilder();
            sb.Append("[SplatBox] Shader binding report — graphics device: ")
                .Append(SystemInfo.graphicsDeviceType)
                .Append(", renderers in scene: ").Append(renderers.Length)
                .Append(", gathered for last camera: ").Append(GaussianSplatRenderSystem.LastGatheredSplatCount)
                .Append('\n');

            foreach (var r in renderers)
            {
                sb.Append("\n=== ").Append(r.name).Append(" ===\n");
                sb.Append("  activeAndEnabled : ").Append(r.isActiveAndEnabled).Append('\n');
                AppendMember(sb, r, "HasValidAsset");
                AppendMember(sb, r, "HasValidRenderSetup");
                AppendMember(sb, r, "UsesPagedLod");
                AppendMember(sb, r, "splatCount");
                AppendMember(sb, r, "activeSplatCount");

                var mat = GetMember(r, "m_MatSplats") as Material;
                sb.Append("  m_MatSplats      : ")
                    .Append(mat == null ? "NULL" : mat.shader == null ? "material, NULL shader" : mat.shader.name)
                    .Append('\n');

                sb.Append("  --- buffers behind the four bindings Vulkan reports ---\n");
                AppendBuffer(sb, r, "m_GpuSortKeys", "_OrderBuffer");
                AppendBuffer(sb, r, "m_GpuView", "_SplatViewData");
                AppendBuffer(sb, r, "m_GpuEditSelected", "_SplatSelectedBits (falls back to m_GpuPosData)");
                AppendBuffer(sb, r, "m_GpuEditTargetSelected", "_SplatTargetSelectedBits (falls back to m_GpuPosData)");
                AppendBuffer(sb, r, "m_GpuEditDeleted", "_SplatDeletedBits (falls back to m_GpuPosData)");

                sb.Append("  --- fallback + remaining buffers ---\n");
                AppendBuffer(sb, r, "m_GpuPosData", "_SplatPos / selected-bits fallback");
                AppendBuffer(sb, r, "m_GpuOtherData", "_SplatOther");
                AppendBuffer(sb, r, "m_GpuSHData", "_SplatSH");
                AppendBuffer(sb, r, "m_GpuChunks", "_SplatChunks");
                AppendBuffer(sb, r, "m_GpuSortDistances", "sort distances");
            }

            Debug.Log(sb.ToString());
        }

        static void AppendBuffer(StringBuilder sb, object target, string field, string boundTo)
        {
            var buf = GetMember(target, field) as GraphicsBuffer;
            sb.Append("  ").Append(field.PadRight(24)).Append(" : ");
            if (buf == null)
                sb.Append("NULL  <-- unbound");
            else if (!buf.IsValid())
                sb.Append("DISPOSED/INVALID  <-- unbound");
            else
                sb.Append("ok, count=").Append(buf.count).Append(" stride=").Append(buf.stride);
            sb.Append("   [").Append(boundTo).Append("]\n");
        }

        static void AppendMember(StringBuilder sb, object target, string name)
        {
            sb.Append("  ").Append(name.PadRight(17)).Append(": ").Append(GetMember(target, name) ?? "<not found>").Append('\n');
        }

        static object GetMember(object target, string name)
        {
            var t = target.GetType();
            for (var cur = t; cur != null; cur = cur.BaseType)
            {
                var f = cur.GetField(name, kAll);
                if (f != null)
                    return f.GetValue(target);
                var p = cur.GetProperty(name, kAll);
                if (p != null && p.CanRead)
                    return p.GetValue(target);
            }
            return null;
        }
    }
}
