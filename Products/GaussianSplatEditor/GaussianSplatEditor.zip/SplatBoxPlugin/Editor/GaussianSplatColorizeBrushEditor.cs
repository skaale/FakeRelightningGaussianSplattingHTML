// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatColorizeBrush))]
    public class GaussianSplatColorizeBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatColorizeBrush m_Target;
        private bool m_BrushMode = false;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatColorizeBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUI.BeginChangeCheck();
            float newScreenRadius = EditorGUILayout.Slider("Brush Size", m_Target.ScreenRadius, 0.1f, 10f);
            float newBlendStrength = EditorGUILayout.Slider("Blend Strength", m_Target.BlendStrength, 0.01f, 1f);
            float newFalloff = EditorGUILayout.Slider("Falloff", m_Target.Falloff, 0f, 1f);
            Color newColor = EditorGUILayout.ColorField("Target Color", m_Target.TargetColor);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Colorize Brush Settings");
                m_Target.ScreenRadius = newScreenRadius;
                m_Target.BlendStrength = newBlendStrength;
                m_Target.Falloff = newFalloff;
                m_Target.TargetColor = newColor;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox("Left-Click: Colorize\nRight-Click: Sample Color\nScroll: Resize Brush", MessageType.Info);
            
            GUI.backgroundColor = m_BrushMode ? new Color(0.3f, 0.9f, 0.5f) : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Colorize Mode" : "Start Colorize Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            GaussianSplatColorizeBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            GaussianSplatColorizeBrush.IsBrushModeActive = false;
            GaussianSplatColorizeBrush.HasValidBrushPosition = false;
            GaussianSplatColorizeBrush.IsColorizing = false;
            GaussianSplatColorizeBrush.IsSampling = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatColorizeBrush.IsBrushModeActive = false;
                GaussianSplatColorizeBrush.HasValidBrushPosition = false;
                GaussianSplatColorizeBrush.IsColorizing = false;
                GaussianSplatColorizeBrush.IsSampling = false;
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            // Middle mouse stops brush mode
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                StopBrushMode();
                e.Use();
                sceneView.Repaint();
                Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetBrushHitPoint(ray, sceneView);
            float worldRadius = CalculateWorldRadius(hitPoint, sceneView);

            GaussianSplatColorizeBrush.LastBrushPosition = hitPoint;
            GaussianSplatColorizeBrush.HasValidBrushPosition = true;
            GaussianSplatColorizeBrush.CurrentWorldRadius = worldRadius;
            GaussianSplatColorizeBrush.CurrentViewDirection = ray.direction;
            
            // Left-click: Colorize
            if ((e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 0 && !e.alt)
            {
                m_Target.ColorizeAtPosition(hitPoint, worldRadius);
                GaussianSplatColorizeBrush.IsColorizing = true;
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0)
            {
                GaussianSplatColorizeBrush.IsColorizing = false;
            }
            
            // Right-click: Sample color
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
            {
                Color sampledColor = m_Target.SampleColorAtPosition(hitPoint, worldRadius, sceneView.camera);
                if (sampledColor != Color.gray)
                {
                    Undo.RecordObject(m_Target, "Sample Color");
                    m_Target.SetTargetColorFromSample(sampledColor);
                    EditorUtility.SetDirty(m_Target);
                }
                GaussianSplatColorizeBrush.IsSampling = true;
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 1)
            {
                GaussianSplatColorizeBrush.IsSampling = false;
            }
            
            // Scroll wheel: Resize brush
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_Target, "Resize Colorize Brush");
                m_Target.ScreenRadius = Mathf.Clamp(m_Target.ScreenRadius - e.delta.y * 0.1f, 0.1f, 10f);
                EditorUtility.SetDirty(m_Target);
                e.Use();
                Repaint();
            }
            
            // Escape to stop
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopBrushMode();
                Repaint();
                e.Use();
            }
            
            DrawBrushPreview(hitPoint, worldRadius, sceneView);

            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private Vector3 GetBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }

        private float CalculateWorldRadius(Vector3 worldPos, SceneView sceneView)
        {
            Camera cam = sceneView.camera;
            float distance = Vector3.Distance(cam.transform.position, worldPos);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * distance * Mathf.Tan(fov * 0.5f)) / screenHeight;
            return m_Target.ScreenRadius * worldPerPixel * 50f;
        }

        private void DrawBrushPreview(Vector3 position, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Color targetColor = m_Target.TargetColor;
            
            Color mainColor = GaussianSplatColorizeBrush.IsSampling 
                ? new Color(1f, 1f, 0f, 0.9f)
                : new Color(targetColor.r, targetColor.g, targetColor.b, 0.9f);
            
            Color fillColor = GaussianSplatColorizeBrush.IsSampling 
                ? new Color(1f, 1f, 0f, 0.15f)
                : new Color(targetColor.r, targetColor.g, targetColor.b, 0.2f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(position, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(position, -camForward, radius, 2f);
            
            // Falloff ring
            if (m_Target.Falloff > 0)
            {
                float innerRadius = radius * (1f - m_Target.Falloff);
                Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.5f);
                Handles.DrawWireDisc(position, -camForward, innerRadius, 1f);
            }
            
            // Center dot with target color
            Handles.color = targetColor;
            Handles.DrawSolidDisc(position, -camForward, radius * 0.08f);
            
            // Show current color in label
            GUIStyle labelStyle = new GUIStyle();
            labelStyle.normal.textColor = Color.white;
            labelStyle.fontSize = 11;
            string info = GaussianSplatColorizeBrush.IsSampling ? "SAMPLING..." : "LMB=Color | RMB=Sample";
            Handles.Label(position + Vector3.up * radius * 1.2f, info, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
    
    [EditorTool("Splat Colorize Brush", typeof(GaussianSplatColorizeBrush))]
    public class GaussianSplatColorizeBrushTool : EditorTool
    {
        private GaussianSplatColorizeBrush m_Brush;

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("d_eyeDropper.Large").image,
            "Splat Colorize Brush Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatColorizeBrush;
            GaussianSplatColorizeBrush.IsBrushModeActive = true;
        }
        
        private void OnDisable()
        {
            GaussianSplatColorizeBrush.IsBrushModeActive = false;
            GaussianSplatColorizeBrush.HasValidBrushPosition = false;
            GaussianSplatColorizeBrush.IsColorizing = false;
            GaussianSplatColorizeBrush.IsSampling = false;
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                GaussianSplatColorizeBrush.IsBrushModeActive = false;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatColorizeBrush.IsBrushModeActive = true;

            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetToolBrushHitPoint(ray, sceneView);
            float worldRadius = CalculateToolWorldRadius(hitPoint, sceneView);

            GaussianSplatColorizeBrush.LastBrushPosition = hitPoint;
            GaussianSplatColorizeBrush.HasValidBrushPosition = true;
            GaussianSplatColorizeBrush.CurrentWorldRadius = worldRadius;
            GaussianSplatColorizeBrush.CurrentViewDirection = ray.direction;
            
            // Left-click: Colorize
            if ((e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 0 && !e.alt)
            {
                m_Brush.ColorizeAtPosition(hitPoint, worldRadius);
                GaussianSplatColorizeBrush.IsColorizing = true;
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0)
            {
                GaussianSplatColorizeBrush.IsColorizing = false;
            }
            
            // Right-click: Sample color
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
            {
                Color sampledColor = m_Brush.SampleColorAtPosition(hitPoint, worldRadius, sceneView.camera);
                if (sampledColor != Color.gray)
                {
                    Undo.RecordObject(m_Brush, "Sample Color");
                    m_Brush.SetTargetColorFromSample(sampledColor);
                    EditorUtility.SetDirty(m_Brush);
                }
                GaussianSplatColorizeBrush.IsSampling = true;
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 1)
            {
                GaussianSplatColorizeBrush.IsSampling = false;
            }
            
            // Scroll wheel: Resize brush
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_Brush, "Resize Colorize Brush");
                m_Brush.ScreenRadius = Mathf.Clamp(m_Brush.ScreenRadius - e.delta.y * 0.1f, 0.1f, 10f);
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }
            
            DrawToolBrushPreview(hitPoint, worldRadius, sceneView);

            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            sceneView.Repaint();
        }
        
        private Vector3 GetToolBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private float CalculateToolWorldRadius(Vector3 worldPos, SceneView sceneView)
        {
            Camera cam = sceneView.camera;
            float distance = Vector3.Distance(cam.transform.position, worldPos);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * distance * Mathf.Tan(fov * 0.5f)) / screenHeight;
            return m_Brush.ScreenRadius * worldPerPixel * 50f;
        }

        private void DrawToolBrushPreview(Vector3 position, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Color targetColor = m_Brush.TargetColor;
            
            Color mainColor = GaussianSplatColorizeBrush.IsSampling 
                ? new Color(1f, 1f, 0f, 0.9f)
                : new Color(targetColor.r, targetColor.g, targetColor.b, 0.9f);
            
            Color fillColor = GaussianSplatColorizeBrush.IsSampling 
                ? new Color(1f, 1f, 0f, 0.15f)
                : new Color(targetColor.r, targetColor.g, targetColor.b, 0.2f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(position, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(position, -camForward, radius, 2f);
            
            if (m_Brush.Falloff > 0)
            {
                float innerRadius = radius * (1f - m_Brush.Falloff);
                Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.5f);
                Handles.DrawWireDisc(position, -camForward, innerRadius, 1f);
            }
            
            Handles.color = targetColor;
            Handles.DrawSolidDisc(position, -camForward, radius * 0.08f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
}
