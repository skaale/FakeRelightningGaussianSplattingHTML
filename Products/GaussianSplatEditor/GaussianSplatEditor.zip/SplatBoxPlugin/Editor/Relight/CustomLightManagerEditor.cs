using UnityEditor;
using UnityEngine;
using GaussianSplatting.Relight;

namespace GaussianSplatting.Relight.Editor
{
    [CustomEditor(typeof(CustomLightManager))]
    public class CustomLightManagerEditor : UnityEditor.Editor
    {
        static readonly Color kDarkBg = new Color(0.18f, 0.18f, 0.2f);
        static readonly Color kDarkHeader = new Color(0.12f, 0.12f, 0.14f);
        static readonly Color kSeparator = new Color(0.28f, 0.28f, 0.3f);
        static readonly Color kPointTint = new Color(1f, 0.85f, 0.4f);
        static readonly Color kSpotTint = new Color(0.5f, 0.85f, 1f);
        static readonly Color kDirTint = new Color(0.6f, 1f, 0.7f);
        static readonly Color kPlanarTint = new Color(0.9f, 0.65f, 1f);
        static readonly Color kTextShadow = new Color(0f, 0f, 0f, 0.7f);
        static GUIStyle s_HeaderStyle;
        static GUIStyle s_LabelShadowStyle;
        static GUIStyle s_ButtonStyle;
        static bool s_StylesInit;

        static void InitStyles()
        {
            if (s_StylesInit) return;
            s_StylesInit = true;
            s_HeaderStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 16,
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold
            };
            s_LabelShadowStyle = new GUIStyle(EditorStyles.label)
            {
                contentOffset = new Vector2(1, 1),
                alignment = TextAnchor.MiddleCenter,
                normal = { textColor = kTextShadow }
            };
            s_ButtonStyle = new GUIStyle(GUI.skin.button)
            {
                alignment = TextAnchor.MiddleCenter,
                fontStyle = FontStyle.Bold,
                padding = new RectOffset(12, 12, 8, 8),
                fixedHeight = 36
            };
        }

        static void DrawLineSeparator(Color color, float height = 1f)
        {
            var r = GUILayoutUtility.GetRect(1f, height);
            r.xMin += 4; r.xMax -= 4;
            EditorGUI.DrawRect(r, color);
        }

        static void DrawRelightHeader()
        {
            InitStyles();
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = kDarkHeader;
            var headerRect = GUILayoutUtility.GetRect(1f, 52f);
            headerRect.xMin = 0; headerRect.xMax = EditorGUIUtility.currentViewWidth;
            EditorGUI.DrawRect(headerRect, kDarkHeader);
            GUI.backgroundColor = prevBg;
            var labelRect = new Rect(headerRect.x, headerRect.y + 6, headerRect.width, 22);
            var shadowRect = labelRect; shadowRect.x += 1; shadowRect.y += 1;
            GUI.Label(shadowRect, "RELIGHT", s_LabelShadowStyle);
            var labelStyle = new GUIStyle(s_HeaderStyle) { normal = { textColor = new Color(0.9f, 0.9f, 0.95f) } };
            GUI.Label(labelRect, "RELIGHT", labelStyle);
            var subRect = new Rect(headerRect.x, headerRect.y + 28, headerRect.width, 16);
            var subStyle = new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter, normal = { textColor = new Color(0.6f, 0.6f, 0.65f) } };
            GUI.Label(subRect, "Custom Light Manager", subStyle);
        }

        static GUIContent LightButtonContent(string label)
        {
            return new GUIContent("  " + label);
        }

        public override void OnInspectorGUI()
        {
            InitStyles();
            serializedObject.Update();
            var showGizmos = serializedObject.FindProperty("m_ShowGizmos");
            if (showGizmos != null)
                EditorGUILayout.PropertyField(showGizmos);
            serializedObject.ApplyModifiedProperties();
            GUILayout.Space(6);
            DrawLineSeparator(kSeparator, 2f);
            GUILayout.Space(8);
            DrawRelightHeader();
            GUILayout.Space(8);
            DrawLineSeparator(kSeparator);
            GUILayout.Space(10);

            var mgr = (CustomLightManager)target;

            var darkBox = GUILayoutUtility.GetRect(1f, 1f);
            darkBox.xMin = 4; darkBox.xMax = EditorGUIUtility.currentViewWidth - 4;
            var boxHeight = 2 + 44 * 2 + 12 * 3;
            darkBox.height = boxHeight;
            EditorGUI.DrawRect(darkBox, kDarkBg);

            GUILayout.Space(6);
            var sectionStyle = new GUIStyle(EditorStyles.label) { fontStyle = FontStyle.Bold, normal = { textColor = new Color(0.85f, 0.85f, 0.9f) } };
            var sectionShadow = new GUIStyle(sectionStyle) { contentOffset = new Vector2(1, 1), normal = { textColor = kTextShadow } };
            GUILayout.Space(4);
            var labelRect = GUILayoutUtility.GetRect(120, 20);
            GUI.Label(new Rect(labelRect.x + 1, labelRect.y + 1, labelRect.width, labelRect.height), "Add lights", sectionShadow);
            GUI.Label(labelRect, "Add lights", sectionStyle);
            GUILayout.Space(6);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Space(8);
            var prevBg = GUI.backgroundColor;

            GUI.backgroundColor = kPointTint;
            if (GUILayout.Button(LightButtonContent("Point Light"), s_ButtonStyle, GUILayout.ExpandWidth(true)))
                mgr.AddPointLight();
            GUILayout.Space(6);
            GUI.backgroundColor = kSpotTint;
            if (GUILayout.Button(LightButtonContent("Spot Light"), s_ButtonStyle, GUILayout.ExpandWidth(true)))
                mgr.AddSpotLight();
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(8);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Space(8);
            GUI.backgroundColor = kDirTint;
            if (GUILayout.Button(LightButtonContent("Directional Light"), s_ButtonStyle, GUILayout.ExpandWidth(true)))
                mgr.AddDirectionalLight();
            GUILayout.Space(6);
            GUI.backgroundColor = kPlanarTint;
            if (GUILayout.Button(LightButtonContent("Planar Light"), s_ButtonStyle, GUILayout.ExpandWidth(true)))
                mgr.AddPlanarLight();
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
            GUI.backgroundColor = prevBg;
            GUILayout.Space(10);

            DrawLineSeparator(kSeparator);
            GUILayout.Space(6);
            var hintStyle = new GUIStyle(EditorStyles.miniLabel) { wordWrap = true, normal = { textColor = new Color(0.55f, 0.55f, 0.6f) } };
            EditorGUILayout.LabelField("Move light objects in the scene; edit color, intensity and range on each light's component.", hintStyle);
            GUILayout.Space(4);
        }
    }
}
