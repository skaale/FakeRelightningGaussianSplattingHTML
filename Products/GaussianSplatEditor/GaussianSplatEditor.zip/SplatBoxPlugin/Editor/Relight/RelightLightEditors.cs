using UnityEditor;
using UnityEngine;
using GaussianSplatting.Relight;

namespace GaussianSplatting.Relight.Editor
{
    static class RelightLightEditorStyles
    {
        public static readonly Color kDarkBg = new Color(0.16f, 0.16f, 0.18f);
        public static readonly Color kDarkSection = new Color(0.2f, 0.2f, 0.22f);
        public static readonly Color kSeparator = new Color(0.32f, 0.32f, 0.35f);
        public static readonly Color kLabelIntensity = new Color(1f, 0.88f, 0.45f);
        public static readonly Color kLabelRange = new Color(1f, 0.65f, 0.35f);
        public static readonly Color kLabelMuted = new Color(0.72f, 0.75f, 0.82f);

        public static void DrawSeparator(float height = 1f)
        {
            GUILayout.Space(4);
            var r = GUILayoutUtility.GetRect(1f, height);
            r.xMin += 8; r.xMax -= 8;
            EditorGUI.DrawRect(r, kSeparator);
            GUILayout.Space(4);
        }

        public static GUIStyle LabelStyle(Color c)
        {
            return new GUIStyle(EditorStyles.label) { normal = { textColor = c } };
        }

        public static GUIStyle SectionHeaderStyle()
        {
            return new GUIStyle(EditorStyles.miniLabel)
            {
                fontStyle = FontStyle.Bold,
                normal = { textColor = kLabelMuted },
                padding = new RectOffset(0, 0, 2, 4)
            };
        }

        public static void DrawSectionHeader(string title)
        {
            GUILayout.Label(title, SectionHeaderStyle());
        }

        public static void DrawLightIcon(Rect r, Color c, float size)
        {
            float cx = r.x + r.width * 0.5f;
            float cy = r.y + r.height * 0.5f;
            float rad = size * 0.5f;
            var glow = new Color(c.r, c.g, c.b, 0.4f);
            for (int i = 3; i >= 0; i--)
            {
                float s = (i + 1) * 0.25f;
                var box = new Rect(cx - rad * s, cy - rad * s, rad * 2 * s, rad * 2 * s);
                EditorGUI.DrawRect(box, i == 0 ? c : glow);
            }
            var border = new Color(0.45f, 0.45f, 0.5f);
            DrawRectOutline(new Rect(cx - rad, cy - rad, rad * 2, rad * 2), border);
        }

        static void DrawRectOutline(Rect r, Color c)
        {
            EditorGUI.DrawRect(new Rect(r.x, r.y, r.width, 1), c);
            EditorGUI.DrawRect(new Rect(r.x, r.yMax - 1, r.width, 1), c);
            EditorGUI.DrawRect(new Rect(r.x, r.y, 1, r.height), c);
            EditorGUI.DrawRect(new Rect(r.xMax - 1, r.y, 1, r.height), c);
        }

        public static void SliderRow(SerializedProperty prop, string label, string tooltip, float min, float max, Color labelColor, Color iconColor)
        {
            if (prop.floatValue < 0) prop.floatValue = min;
            EditorGUILayout.BeginHorizontal(GUILayout.Height(22));
            GUILayout.Space(8);
            var iconRect = GUILayoutUtility.GetRect(22, 22);
            DrawLightIcon(iconRect, iconColor, 18);
            GUILayout.Space(6);
            var content = new GUIContent(label, tooltip);
            GUILayout.Label(content, LabelStyle(labelColor), GUILayout.Width(EditorGUIUtility.labelWidth - 40));
            prop.floatValue = Mathf.Clamp(EditorGUILayout.Slider(prop.floatValue, min, max, GUILayout.ExpandWidth(true)), min, max);
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
        }
    }

    [CustomEditor(typeof(RelightPointLight))]
    public class RelightPointLightEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var t = (RelightPointLight)target;
            var colorProp = serializedObject.FindProperty("color");
            var intensityProp = serializedObject.FindProperty("intensity");
            var rangeProp = serializedObject.FindProperty("range");
            var attenuationProp = serializedObject.FindProperty("attenuationMode");
            var isActiveProp = serializedObject.FindProperty("isActive");
            var showGizmoProp = serializedObject.FindProperty("showGizmo");

            var boxRect = GUILayoutUtility.GetRect(1f, 1f);
            boxRect.xMin = 6; boxRect.xMax = EditorGUIUtility.currentViewWidth - 6;
            boxRect.height = 248;
            EditorGUI.DrawRect(boxRect, RelightLightEditorStyles.kDarkBg);
            GUILayout.Space(10);

            RelightLightEditorStyles.DrawSectionHeader("APPEARANCE");
            EditorGUILayout.BeginHorizontal(GUILayout.Height(24));
            GUILayout.Space(8);
            var iconRect = GUILayoutUtility.GetRect(24, 24);
            RelightLightEditorStyles.DrawLightIcon(iconRect, t.color, 20);
            GUILayout.Space(8);
            EditorGUILayout.PropertyField(colorProp, new GUIContent("Light color", "RGB color of the light. Affects how surfaces are tinted."), GUILayout.ExpandWidth(true));
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(6);
            RelightLightEditorStyles.DrawSeparator();

            RelightLightEditorStyles.DrawSectionHeader("LIGHT");
            RelightLightEditorStyles.SliderRow(intensityProp, "Intensity", "Brightness multiplier. Higher values produce stronger illumination.", 0f, 20f, RelightLightEditorStyles.kLabelIntensity, t.color);
            RelightLightEditorStyles.SliderRow(rangeProp, "Range", "Distance at which light influence reaches zero. Move the light in the scene to change position.", 0f, 5f, RelightLightEditorStyles.kLabelRange, t.color);
            GUILayout.Space(2);
            RelightLightEditorStyles.DrawSeparator();

            RelightLightEditorStyles.DrawSectionHeader("FALLOFF & STATE");
            EditorGUILayout.PropertyField(attenuationProp, new GUIContent("Attenuation", "Default: quadratic falloff. Linear: even falloff. Inverse Square: physically accurate."));
            EditorGUILayout.PropertyField(isActiveProp, new GUIContent("Is active", "When unchecked, this light is disabled and does not affect the scene."));
            EditorGUILayout.PropertyField(showGizmoProp, new GUIContent("Show gizmo", "Draw range sphere in Scene view. Also respect CustomLightManager Show Gizmos."));
            GUILayout.Space(6);
            if (GUILayout.Button("Reset to default")) { Undo.RecordObject(t, "Reset Point Light"); t.color = Color.white; t.intensity = 1f; t.range = 1f; t.attenuationMode = RelightAttenuationMode.Default; t.isActive = true; t.showGizmo = true; }
            GUILayout.Space(10);
            serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomEditor(typeof(RelightSpotLight))]
    public class RelightSpotLightEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var t = (RelightSpotLight)target;
            var colorProp = serializedObject.FindProperty("color");
            var intensityProp = serializedObject.FindProperty("intensity");
            var rangeProp = serializedObject.FindProperty("range");
            var spotAngleProp = serializedObject.FindProperty("spotAngle");
            var innerConeProp = serializedObject.FindProperty("innerConeAngle");
            var attenuationProp = serializedObject.FindProperty("attenuationMode");
            var isActiveProp = serializedObject.FindProperty("isActive");
            var showGizmoProp = serializedObject.FindProperty("showGizmo");

            EditorGUILayout.HelpBox("Relight only affects Gaussian splats (not scene geometry). Ensure SplatBoxRenderer uses the Relight shader and rotate this GameObject so the blue axis points at your splats.", MessageType.Info);
            GUILayout.Space(4);

            var boxRect = GUILayoutUtility.GetRect(1f, 1f);
            boxRect.xMin = 4; boxRect.xMax = EditorGUIUtility.currentViewWidth - 4;
            boxRect.height = 308;
            EditorGUI.DrawRect(boxRect, RelightLightEditorStyles.kDarkBg);
            GUILayout.Space(10);

            RelightLightEditorStyles.DrawSectionHeader("APPEARANCE");
            EditorGUILayout.BeginHorizontal(GUILayout.Height(24));
            GUILayout.Space(8);
            var colorRect = GUILayoutUtility.GetRect(24, 24);
            RelightLightEditorStyles.DrawLightIcon(colorRect, t.color, 20);
            GUILayout.Space(8);
            EditorGUILayout.PropertyField(colorProp, new GUIContent("Light color", "RGB color of the light."), GUILayout.ExpandWidth(true));
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(6);
            RelightLightEditorStyles.DrawSeparator();

            RelightLightEditorStyles.DrawSectionHeader("LIGHT");
            RelightLightEditorStyles.SliderRow(intensityProp, "Intensity", "Brightness multiplier.", 0f, 20f, RelightLightEditorStyles.kLabelIntensity, t.color);
            RelightLightEditorStyles.SliderRow(rangeProp, "Range", "Distance of light reach. Rotate the spotlight (blue axis) toward your splats.", 0f, 50f, RelightLightEditorStyles.kLabelRange, t.color);
            spotAngleProp.floatValue = Mathf.Clamp(spotAngleProp.floatValue, 1f, 179f);
            EditorGUILayout.PropertyField(spotAngleProp, new GUIContent("Spot angle", "Outer cone angle in degrees. Splats inside this cone are lit."));
            innerConeProp.floatValue = Mathf.Clamp(innerConeProp.floatValue, 0f, 179f);
            EditorGUILayout.PropertyField(innerConeProp, new GUIContent("Inner cone", "Inner cone angle for soft edge. Keep inner < spot angle."));
            GUILayout.Space(2);
            RelightLightEditorStyles.DrawSeparator();
            RelightLightEditorStyles.DrawSectionHeader("FALLOFF & STATE");
            EditorGUILayout.PropertyField(attenuationProp, new GUIContent("Attenuation", "Default, Linear, or Inverse Square falloff."));
            EditorGUILayout.PropertyField(isActiveProp, new GUIContent("Is active", "Enable or disable this light."));
            EditorGUILayout.PropertyField(showGizmoProp, new GUIContent("Show gizmo", "Draw cone in Scene view. Also respect CustomLightManager Show Gizmos."));
            GUILayout.Space(6);
            if (GUILayout.Button("Reset to default")) { Undo.RecordObject(t, "Reset Spot Light"); t.color = Color.white; t.intensity = 1f; t.range = 1f; t.spotAngle = 30f; t.innerConeAngle = 21.8f; t.attenuationMode = RelightAttenuationMode.Default; t.isActive = true; t.showGizmo = true; }
            GUILayout.Space(10);
            serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomEditor(typeof(RelightDirectionalLight))]
    public class RelightDirectionalLightEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var t = (RelightDirectionalLight)target;
            var presetProp = serializedObject.FindProperty("preset");
            var colorProp = serializedObject.FindProperty("color");
            var intensityProp = serializedObject.FindProperty("intensity");
            var effectRangeProp = serializedObject.FindProperty("effectRange");
            var rangeSoftnessProp = serializedObject.FindProperty("rangeSoftness");
            var shadowStrengthProp = serializedObject.FindProperty("shadowStrength");
            var useDistProp = serializedObject.FindProperty("useDistanceAttenuation");
            var distFactorProp = serializedObject.FindProperty("distanceAttenuationFactor");
            var useAngleProp = serializedObject.FindProperty("useAngleAttenuation");
            var angleBiasProp = serializedObject.FindProperty("angleAttenuationBias");
            var isActiveProp = serializedObject.FindProperty("isActive");
            var showGizmoProp = serializedObject.FindProperty("showGizmo");

            EditorGUILayout.HelpBox("Relight only affects Gaussian splats. Light direction is always from this transform (rotate the GameObject). Preset applies rotation when changed.", MessageType.Info);
            GUILayout.Space(4);

            var boxRect = GUILayoutUtility.GetRect(1f, 1f);
            boxRect.xMin = 6; boxRect.xMax = EditorGUIUtility.currentViewWidth - 6;
            boxRect.height = 368;
            EditorGUI.DrawRect(boxRect, RelightLightEditorStyles.kDarkBg);
            GUILayout.Space(10);

            RelightLightEditorStyles.DrawSectionHeader("APPEARANCE");
            EditorGUILayout.BeginHorizontal(GUILayout.Height(24));
            GUILayout.Space(8);
            var colorRect = GUILayoutUtility.GetRect(24, 24);
            RelightLightEditorStyles.DrawLightIcon(colorRect, t.color, 20);
            GUILayout.Space(8);
            EditorGUILayout.PropertyField(colorProp, new GUIContent("Light color", "RGB color of the directional light."), GUILayout.ExpandWidth(true));
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(6);
            RelightLightEditorStyles.DrawSeparator();
            RelightLightEditorStyles.DrawSectionHeader("LIGHT");
            RelightLightEditorStyles.SliderRow(intensityProp, "Intensity", "Brightness multiplier (sun).", 0f, 150f, RelightLightEditorStyles.kLabelIntensity, t.color);
            effectRangeProp.floatValue = Mathf.Clamp(effectRangeProp.floatValue, 1f, 50f);
            RelightLightEditorStyles.SliderRow(effectRangeProp, "Effect range (m)", "Range in meters from origin (1–50 m). Lit inside, dark outside.", 1f, 50f, RelightLightEditorStyles.kLabelRange, t.color);
            rangeSoftnessProp.floatValue = Mathf.Clamp(rangeSoftnessProp.floatValue, 0f, 100f);
            EditorGUILayout.PropertyField(rangeSoftnessProp, new GUIContent("Shadow softness (m)", "Width in meters of the soft falloff at the edge. 0 = hard edge, higher = softer transition."));
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PropertyField(presetProp, new GUIContent("Direction preset", "Apply to copy this direction to the transform. Light direction always uses the transform (rotate in Scene)."));
            if (GUILayout.Button("Apply", GUILayout.Width(50)))
            {
                Undo.RecordObject(t.transform, "Direction Preset");
                t.transform.rotation = Quaternion.LookRotation(t.GetPresetDirection());
            }
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(2);
            RelightLightEditorStyles.DrawSeparator();
            RelightLightEditorStyles.DrawSectionHeader("ATTENUATION & STATE");
            shadowStrengthProp.floatValue = Mathf.Max(0f, shadowStrengthProp.floatValue);
            EditorGUILayout.PropertyField(shadowStrengthProp, new GUIContent("Shadow strength", "Blend between ignoring normals (0) and full Lambert (1). No upper clamp to avoid artifacts."));
            EditorGUILayout.PropertyField(useDistProp, new GUIContent("Distance attenuation", "Fade by distance."));
            distFactorProp.floatValue = Mathf.Clamp(distFactorProp.floatValue, 0f, 1f);
            EditorGUILayout.PropertyField(distFactorProp, new GUIContent("Distance factor", "Distance falloff factor (0-1). Clamped to avoid artifacts."));
            EditorGUILayout.PropertyField(useAngleProp, new GUIContent("Angle attenuation", "Reduces contribution when light is from below. Disable for Bottom/Bottom Front if light is invisible."));
            angleBiasProp.floatValue = Mathf.Max(0f, angleBiasProp.floatValue);
            EditorGUILayout.PropertyField(angleBiasProp, new GUIContent("Angle bias", "Higher values keep downward lights visible (≥0)."));
            EditorGUILayout.PropertyField(isActiveProp, new GUIContent("Is active", "Enable or disable this light."));
            EditorGUILayout.PropertyField(showGizmoProp, new GUIContent("Show gizmo", "Draw direction ray in Scene view. Also respect CustomLightManager Show Gizmos."));
            GUILayout.Space(6);
            if (GUILayout.Button("Reset to default")) { Undo.RecordObject(t, "Reset Directional Light"); t.preset = RelightDirectionalPreset.TopFront; t.color = Color.white; t.intensity = 100f; t.effectRange = 25f; t.rangeSoftness = 1f; t.shadowStrength = 0.5f; t.useDistanceAttenuation = true; t.distanceAttenuationFactor = 0.5f; t.useAngleAttenuation = true; t.angleAttenuationBias = 0.5f; t.isActive = true; t.showGizmo = true; }
            GUILayout.Space(10);
            serializedObject.ApplyModifiedProperties();
        }
    }

    [CustomEditor(typeof(RelightPlanarLight))]
    public class RelightPlanarLightEditor : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            var t = (RelightPlanarLight)target;
            var sizeProp = serializedObject.FindProperty("size");
            var colorProp = serializedObject.FindProperty("color");
            var intensityProp = serializedObject.FindProperty("intensity");
            var rangeProp = serializedObject.FindProperty("range");
            var twoSidedProp = serializedObject.FindProperty("twoSided");
            var attenuationProp = serializedObject.FindProperty("attenuationMode");
            var isActiveProp = serializedObject.FindProperty("isActive");
            var showGizmoProp = serializedObject.FindProperty("showGizmo");

            EditorGUILayout.HelpBox("Relight only affects Gaussian splats. Use the Relight shader on SplatBoxRenderer. Orient the plane so the blue axis (normal) points at your splats. Splats must be within the Size rectangle and within Range. Enable Two sided if splats are on both sides.", MessageType.Info);
            GUILayout.Space(4);

            var boxRect = GUILayoutUtility.GetRect(1f, 1f);
            boxRect.xMin = 6; boxRect.xMax = EditorGUIUtility.currentViewWidth - 6;
            boxRect.height = 288;
            EditorGUI.DrawRect(boxRect, RelightLightEditorStyles.kDarkBg);
            GUILayout.Space(10);

            RelightLightEditorStyles.DrawSectionHeader("APPEARANCE");
            EditorGUILayout.BeginHorizontal(GUILayout.Height(24));
            GUILayout.Space(8);
            var colorRect = GUILayoutUtility.GetRect(24, 24);
            RelightLightEditorStyles.DrawLightIcon(colorRect, t.color, 20);
            GUILayout.Space(8);
            EditorGUILayout.PropertyField(colorProp, new GUIContent("Light color", "RGB color of the planar light."), GUILayout.ExpandWidth(true));
            GUILayout.Space(8);
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(6);
            RelightLightEditorStyles.DrawSeparator();
            RelightLightEditorStyles.DrawSectionHeader("LIGHT");
            RelightLightEditorStyles.SliderRow(intensityProp, "Intensity", "Brightness multiplier.", 0f, 20f, RelightLightEditorStyles.kLabelIntensity, t.color);
            RelightLightEditorStyles.SliderRow(rangeProp, "Range", "Max distance (m). Splats beyond this get no light.", 0f, 50f, RelightLightEditorStyles.kLabelRange, t.color);
            EditorGUILayout.PropertyField(sizeProp, new GUIContent("Size", "Width and height of the light rectangle. Only splats projecting inside this are lit."));
            EditorGUILayout.PropertyField(twoSidedProp, new GUIContent("Two sided", "If off, only splats in front of the plane (blue axis) are lit. Enable for both sides."));
            GUILayout.Space(2);
            RelightLightEditorStyles.DrawSeparator();
            RelightLightEditorStyles.DrawSectionHeader("FALLOFF & STATE");
            EditorGUILayout.PropertyField(attenuationProp, new GUIContent("Attenuation", "Default, Linear, or Inverse Square falloff."));
            EditorGUILayout.PropertyField(isActiveProp, new GUIContent("Is active", "Enable or disable this light."));
            EditorGUILayout.PropertyField(showGizmoProp, new GUIContent("Show gizmo", "Draw plane rectangle in Scene view. Also respect CustomLightManager Show Gizmos."));
            GUILayout.Space(6);
            if (GUILayout.Button("Reset to default")) { Undo.RecordObject(t, "Reset Planar Light"); t.size = new Vector2(5f, 5f); t.color = Color.white; t.intensity = 1f; t.range = 1f; t.twoSided = false; t.attenuationMode = RelightAttenuationMode.Default; t.isActive = true; t.showGizmo = true; }
            GUILayout.Space(10);
            serializedObject.ApplyModifiedProperties();
        }
    }
}
