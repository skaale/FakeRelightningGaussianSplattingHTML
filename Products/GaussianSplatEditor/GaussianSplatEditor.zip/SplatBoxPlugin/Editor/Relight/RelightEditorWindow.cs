// SPDX-License-Identifier: MIT
// Relight Editor – separate plugin for SplatBox; requires SplatBox to be installed.
// Works on .spz and .ply assets for relighting of Gaussian splats.

using System;
using UnityEditor;
using UnityEngine;
using GaussianSplatting.Relight;

namespace GaussianSplatting.Relight.Editor
{
    public class RelightEditorWindow : EditorWindow
    {
        const int kMenuPriority = 120;

        [MenuItem("SplatToolbox/Relight/Relight Editor", false, kMenuPriority)]
        public static void ShowWindow()
        {
            var w = GetWindow<RelightEditorWindow>(false, "Relight Editor", true);
            w.minSize = new Vector2(360, 320);
        }

        void OnGUI()
        {
            EditorGUILayout.Space(8);
            var titleStyle = new GUIStyle(EditorStyles.boldLabel) { fontSize = 14, alignment = TextAnchor.MiddleCenter };
            EditorGUILayout.LabelField("Relight Editor", titleStyle);
            var activeStyle = new GUIStyle(EditorStyles.centeredGreyMiniLabel) { fontStyle = FontStyle.Bold };
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(0.2f, 0.55f, 0.35f);
            EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
            GUILayout.FlexibleSpace();
            GUILayout.Label(" Plugin installed & active ", activeStyle);
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            GUI.backgroundColor = prevBg;
            EditorGUILayout.Space(6);
            EditorGUILayout.HelpBox("Relight splats from .spz and .ply assets. Requires SplatBox. Add CustomLightManager to your scene; Splat Editor will use the Relight shader when this plugin is installed.", MessageType.Info);
            EditorGUILayout.Space(12);

            EditorGUILayout.LabelField("Quick actions", EditorStyles.boldLabel);
            EditorGUILayout.Space(4);

            if (GUILayout.Button("Open Splat Importer (PLY / SPZ)", GUILayout.Height(28)))
                GaussianSplatting.Editor.GaussianPlyImporterWindow.ShowImporter();

            if (GUILayout.Button("Open Splat Editor", GUILayout.Height(28)))
                GaussianSplatting.Editor.GaussianSplatEditorWindow.ShowWindow();

            EditorGUILayout.Space(16);
            EditorGUILayout.LabelField("Relighting setup", EditorStyles.boldLabel);
            EditorGUILayout.Space(4);
            EditorGUILayout.HelpBox("1. Import .ply or .spz via Splat Importer.\n2. Add a SplatBoxRenderer with the asset.\n3. Add CustomLightManager (Relight) to the scene and configure lights.\n4. Splat Editor uses \"Gaussian Splatting/Render Splats Relight\" when this plugin is installed.", MessageType.None);
            EditorGUILayout.Space(8);

            if (GUILayout.Button("Add CustomLightManager to scene", GUILayout.Height(24)))
            {
                var existing = FindAnyObjectByType<CustomLightManager>();
                if (existing != null)
                {
                    Selection.activeGameObject = existing.gameObject;
                    EditorGUIUtility.PingObject(existing.gameObject);
                }
                else
                {
                    var go = new GameObject("Relight CustomLightManager");
                    go.AddComponent<CustomLightManager>();
                    Undo.RegisterCreatedObjectUndo(go, "Add CustomLightManager");
                    Selection.activeGameObject = go;
                }
            }

            EditorGUILayout.Space(8);
            if (GUILayout.Button("Select Relight shader (RenderGaussianSplats)", GUILayout.Height(22)))
            {
                var guids = AssetDatabase.FindAssets("RenderGaussianSplats t:Shader");
                foreach (var g in guids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(g);
                    if (path != null && path.IndexOf("Relight", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        var shader = AssetDatabase.LoadAssetAtPath<Shader>(path);
                        if (shader != null) { Selection.activeObject = shader; EditorGUIUtility.PingObject(shader); break; }
                    }
                }
            }
        }
    }
}
