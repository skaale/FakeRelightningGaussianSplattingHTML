#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Relight.Editor
{
    /// <summary>
    /// Re-binds relight GPU buffers after domain reload so splats are not black on editor restart.
    /// </summary>
    [InitializeOnLoad]
    static class RelightStartup
    {
        static RelightStartup()
        {
            GaussianSplatRenderSystem.OnRelightRendererReady += CustomLightManager.RefreshAllInScene;
            GaussianSplatRenderSystem.OnBeforeDrawSplats += CustomLightManager.BindAllToDrawContext;
            EditorApplication.delayCall += RefreshAllLightManagers;
        }

        internal static void RefreshAllLightManagers()
        {
            CustomLightManager.RefreshAllInScene();
        }
    }
}
#endif
