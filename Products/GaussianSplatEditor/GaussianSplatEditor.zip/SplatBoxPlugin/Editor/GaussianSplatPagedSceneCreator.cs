// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.IO;
using GaussianSplatting.Editor.Utils;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Mathematics;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    public class GaussianSplatPagedSceneCreator : EditorWindow
    {
        const string kProgressTitle = "Building Paged LoD Scene";
        const string kPrefOutputFolder = "nesnausk.GaussianSplatting.PagedOutputFolder";

        readonly FilePickerControl m_FilePicker = new();

        [SerializeField] string m_InputFile;
        [SerializeField] string m_OutputFolder = "Assets/GaussianAssets/Paged";
        [SerializeField] bool m_AutoPageCellSize = true;
        [SerializeField] float m_PageCellSize = 64f;
        [Tooltip("When Auto is on, grow the grid cell until occupied cells are near this count. " +
                 "Then Max Splats Per Page may still split dense cells.")]
        [SerializeField] int m_TargetPageCount = 128;
        [SerializeField] int m_MaxSplatsPerPage = 250_000;
        [SerializeField] GaussianSplatAssetCreator.DataQuality m_Quality = GaussianSplatAssetCreator.DataQuality.VeryHigh;
        [SerializeField] int m_DefaultLodBudget = 500_000;

        string m_ErrorMessage;

        [MenuItem("Tools/Gaussian Splatting/Create Paged LoD Scene...")]
        public static void Init()
        {
            var window = GetWindow<GaussianSplatPagedSceneCreator>(false, "Paged LoD Scene", true);
            window.minSize = new Vector2(360, 220);
            window.Show();
        }

        void Awake()
        {
            m_OutputFolder = EditorPrefs.GetString(kPrefOutputFolder, m_OutputFolder);
        }

        void OnGUI()
        {
            EditorGUILayout.LabelField("Paged LoD Scene Builder", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Partitions a PLY/SPZ into spatial pages, builds a Spark-style Quick LoD tree per page, " +
                "and writes a GaussianSplatPagedScene manifest for Quest streaming. " +
                "Use Quality = Very High unless you need smaller page assets.",
                MessageType.Info);

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PrefixLabel("Input File (PLY/SPZ)");
            m_InputFile = EditorGUILayout.TextField(m_InputFile ?? "");
            if (GUILayout.Button("...", GUILayout.Width(30)))
            {
                string selected = EditorUtility.OpenFilePanelWithFilters(
                    "Select Gaussian Splat File",
                    string.IsNullOrEmpty(m_InputFile) ? "" : Path.GetDirectoryName(m_InputFile),
                    new[] { "Gaussian Splat Files", "ply,spz", "PLY Files", "ply", "SPZ Files", "spz" });
                if (!string.IsNullOrEmpty(selected))
                    m_InputFile = selected;
            }
            EditorGUILayout.EndHorizontal();

            var outputRect = EditorGUILayout.GetControlRect(true);
            string newOutputFolder = m_FilePicker.PathFieldGUI(outputRect, new GUIContent("Output Folder"), m_OutputFolder, null, "GaussianPagedOutputFolder");
            if (newOutputFolder != m_OutputFolder)
                m_OutputFolder = newOutputFolder;

            m_AutoPageCellSize = EditorGUILayout.Toggle(
                new GUIContent("Auto Page Cell Size",
                    "Pick a cell size from the model bounds so you get roughly Target Page Count " +
                    "occupied cells. A small fixed cell (e.g. 28 m) on a large or cm-scaled capture " +
                    "creates thousands of tiny pages."),
                m_AutoPageCellSize);
            using (new EditorGUI.DisabledScope(m_AutoPageCellSize))
            {
                m_PageCellSize = EditorGUILayout.FloatField(
                    new GUIContent("Page Cell Size (m)",
                        "Spatial grid size. Each occupied cell becomes at least one page. " +
                        "Larger = fewer pages, coarser streaming chunks."),
                    m_PageCellSize);
            }
            if (m_AutoPageCellSize)
            {
                m_TargetPageCount = EditorGUILayout.IntSlider(
                    new GUIContent("Target Page Count",
                        "Desired number of occupied grid cells before dense-cell splits. " +
                        "64–192 is typical for Quest streaming."),
                    m_TargetPageCount, 32, 512);
            }
            m_MaxSplatsPerPage = EditorGUILayout.IntField(
                new GUIContent("Max Splats Per Page",
                    "Cells holding more splats than this are split in half until every page fits. " +
                    "Keeps dense models from collapsing into one giant page that cannot be streamed."),
                m_MaxSplatsPerPage);
            m_Quality = (GaussianSplatAssetCreator.DataQuality)EditorGUILayout.EnumPopup("Quality", m_Quality);
            m_DefaultLodBudget = EditorGUILayout.IntField("Default LoD Budget", m_DefaultLodBudget);

            if (!string.IsNullOrEmpty(m_ErrorMessage))
                EditorGUILayout.HelpBox(m_ErrorMessage, MessageType.Error);

            GUI.enabled = !string.IsNullOrWhiteSpace(m_InputFile);
            if (GUILayout.Button("Build Paged Scene", GUILayout.Height(32)))
                BuildPagedScene();
            GUI.enabled = true;
        }

        /// <summary>
        /// Removes page files left by earlier builds of the same input. Page counts change between
        /// builds, so stale files would otherwise accumulate forever and quietly eat the disk.
        /// </summary>
        void DeletePreviousBuild(string sceneBase)
        {
            if (!Directory.Exists(m_OutputFolder))
                return;

            string prefix = sceneBase + "_page_";
            var stale = Directory.GetFiles(m_OutputFolder);
            AssetDatabase.StartAssetEditing();
            try
            {
                foreach (var file in stale)
                {
                    string name = Path.GetFileName(file);
                    if (!name.StartsWith(prefix, StringComparison.Ordinal) || name.EndsWith(".meta"))
                        continue;
                    AssetDatabase.DeleteAsset(file.Replace('\\', '/'));
                }
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }
        }

        void BuildPagedScene()
        {
            m_ErrorMessage = null;
            if (string.IsNullOrWhiteSpace(m_InputFile) || !File.Exists(m_InputFile))
            {
                m_ErrorMessage = "Select a valid PLY or SPZ file.";
                return;
            }
            if (string.IsNullOrWhiteSpace(m_OutputFolder) || !m_OutputFolder.StartsWith("Assets/"))
            {
                m_ErrorMessage = "Output folder must be inside Assets/.";
                return;
            }

            Directory.CreateDirectory(m_OutputFolder);
            EditorPrefs.SetString(kPrefOutputFolder, m_OutputFolder);

            var creator = CreateInstance<GaussianSplatAssetCreator>();
            creator.m_OutputFolder = m_OutputFolder;
            creator.m_Quality = m_Quality;
            creator.ApplyQualityLevel();

            EditorUtility.DisplayProgressBar(kProgressTitle, "Loading splats", 0.05f);
            using NativeArray<GaussianSplatAssetCreator.InputSplatData> allSplats = creator.LoadSplatFile(m_InputFile);
            if (!allSplats.IsCreated || allSplats.Length == 0)
            {
                m_ErrorMessage = creator.m_ErrorMessage ?? "Failed to load splats.";
                EditorUtility.ClearProgressBar();
                return;
            }

            string sceneBase = Path.GetFileNameWithoutExtension(m_InputFile);

            // The LoD tree roughly doubles the splat count, Very High quality stores ~240 bytes per
            // splat, and Unity's Library keeps a second copy of every imported artifact. Running out
            // of disk mid-build corrupts the output, so refuse up front instead.
            long estimatedBytes = (long)(allSplats.Length * 2.2 * 240) * 2;
            var drive = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(m_OutputFolder)));
            if (drive.AvailableFreeSpace < estimatedBytes)
            {
                m_ErrorMessage =
                    $"Not enough disk space on {drive.Name}: this build needs roughly " +
                    $"{estimatedBytes / (1024.0 * 1024 * 1024):0.0} GB (page data plus Unity import " +
                    $"artifacts) but only {drive.AvailableFreeSpace / (1024.0 * 1024 * 1024):0.0} GB is free.";
                EditorUtility.ClearProgressBar();
                return;
            }

            DeletePreviousBuild(sceneBase);

            float3 worldMin = new float3(float.MaxValue);
            float3 worldMax = new float3(float.MinValue);
            for (int i = 0; i < allSplats.Length; i++)
            {
                worldMin = math.min(worldMin, allSplats[i].pos);
                worldMax = math.max(worldMax, allSplats[i].pos);
            }

            float3 extent = worldMax - worldMin;
            float cellSize = Mathf.Max(0.5f, m_PageCellSize);
            if (m_AutoPageCellSize)
            {
                cellSize = GaussianSplatLodBuilder.ChoosePageCellSize(
                    allSplats, worldMin, worldMax, m_TargetPageCount);
                Debug.Log(
                    $"[Paged LoD] Auto page cell size = {cellSize:0.##} " +
                    $"(target ~{m_TargetPageCount} occupied cells). " +
                    $"World extent = ({extent.x:0.#}, {extent.y:0.#}, {extent.z:0.#}).");
            }

            var pageBuckets = GaussianSplatLodBuilder.PartitionToPages(
                allSplats, cellSize, worldMin, m_MaxSplatsPerPage);
            int avgPerPage = pageBuckets.Count > 0 ? allSplats.Length / pageBuckets.Count : 0;
            Debug.Log(
                $"[Paged LoD] {allSplats.Length:N0} splats -> {pageBuckets.Count} pages " +
                $"(cell={cellSize:0.##}, avg ~{avgPerPage:N0} splats/page, " +
                $"max/page={m_MaxSplatsPerPage:N0}). " +
                "Page count is driven by the spatial grid (occupied cells), not by LoD tree depth. " +
                "Raise Page Cell Size or enable Auto if this is too high.");
            if (pageBuckets.Count > 512)
            {
                Debug.LogWarning(
                    $"[Paged LoD] {pageBuckets.Count} pages is high for VR streaming " +
                    $"(often from a small cell size or unit-scale mismatch / outliers). " +
                    "Try Auto Page Cell Size, or set Page Cell Size to 64–128+.");
            }

            var pageEntries = new List<GaussianSplatPageEntry>();
            int pageId = 0;

            try
            {
                foreach (var kv in pageBuckets)
                {
                    float progress = 0.1f + 0.8f * (pageId / (float)math.max(1, pageBuckets.Count));
                    EditorUtility.DisplayProgressBar(kProgressTitle, $"Page {pageId + 1}/{pageBuckets.Count}", progress);

                    using NativeArray<GaussianSplatAssetCreator.InputSplatData> pageSplats =
                        GaussianSplatLodBuilder.ExtractSubset(allSplats, kv.indices);

                    var (lodSplats, lodTreeBytes, lodNodeCount, leafCount) =
                        GaussianSplatLodBuilder.BuildQuickLod(pageSplats);

                    // Split cells share a grid coord, so the id keeps names unique.
                    string pageBase = $"{sceneBase}_page_{pageId:D3}_{kv.coord.x}_{kv.coord.y}_{kv.coord.z}";
                    // BuildQuickLod returns splats in exactly the same level order as lodTreeBytes.
                    // Keep that order: node index is the payload index throughout traversal and the
                    // coarse streamer relies on each tree prefix matching the same splat prefix.
                    GaussianSplatAsset splatAsset = creator.BuildAssetFromSplats(
                        lodSplats, pageBase, null, showProgress: false, preserveSplatOrder: true);
                    lodSplats.Dispose();

                    if (splatAsset == null)
                    {
                        m_ErrorMessage = "Failed to export page asset.";
                        return;
                    }

                    string lodPath = $"{m_OutputFolder}/{pageBase}_lodtree.bytes";
                    File.WriteAllBytes(lodPath, lodTreeBytes);
                    AssetDatabase.ImportAsset(lodPath);

                    var pageAsset = ScriptableObject.CreateInstance<GaussianSplatPageAsset>();
                    float3 pmin = new float3(float.MaxValue);
                    float3 pmax = new float3(float.MinValue);
                    for (int i = 0; i < kv.indices.Count; i++)
                    {
                        float3 p = allSplats[kv.indices[i]].pos;
                        pmin = math.min(pmin, p);
                        pmax = math.max(pmax, p);
                    }

                    pageAsset.Initialize(
                        pageId,
                        kv.coord,
                        pmin,
                        pmax,
                        splatAsset,
                        AssetDatabase.LoadAssetAtPath<TextAsset>(lodPath),
                        lodNodeCount,
                        leafCount);

                    string pageAssetPath = $"{m_OutputFolder}/{pageBase}_page.asset";
                    AssetDatabase.CreateAsset(pageAsset, pageAssetPath);

                    pageEntries.Add(new GaussianSplatPageEntry
                    {
                        pageId = pageId,
                        gridCoord = kv.coord,
                        boundsMin = pmin,
                        boundsMax = pmax,
                        pageAsset = pageAsset,
                        splatCount = splatAsset.splatCount,
                        lodNodeCount = lodNodeCount
                    });
                    pageId++;
                }

                var scene = ScriptableObject.CreateInstance<GaussianSplatPagedScene>();
                scene.Initialize(worldMin, worldMax, cellSize, pageEntries.ToArray(), m_DefaultLodBudget);
                scene.name = sceneBase + "_PagedScene";
                string scenePath = $"{m_OutputFolder}/{scene.name}.asset";
                AssetDatabase.CreateAsset(scene, scenePath);
                AssetDatabase.SaveAssets();

                Selection.activeObject = scene;
                Debug.Log($"Paged LoD scene created: {pageEntries.Count} pages, {allSplats.Length:N0} source splats -> {scenePath}");
            }
            catch (IOException e)
            {
                // Half a build is worse than none: stale partial pages both waste disk and confuse
                // the next attempt, so tear them down before surfacing the error.
                m_ErrorMessage = $"Build failed while writing page data ({e.Message}). " +
                                 "Partial output has been removed; free up disk space and rebuild.";
                DeletePreviousBuild(sceneBase);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
    }
}
