// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatCylinderBrush))]
    public class GaussianSplatCylinderBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatCylinderBrush m_Target;
        private bool m_BrushMode = false;
        private bool m_NavigationMode = false;
        private Tool m_ActiveTool = Tool.Move;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatCylinderBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Cylinder Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            float newRadius = EditorGUILayout.FloatField("Radius", m_Target.Radius);
            float newHeight = EditorGUILayout.FloatField("Height", m_Target.Height);
            Vector3 newPos = EditorGUILayout.Vector3Field("Position", m_Target.Position);
            Vector3 eulerAngles = m_Target.Rotation.eulerAngles;
            Vector3 newEuler = EditorGUILayout.Vector3Field("Rotation", eulerAngles);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Cylinder Settings");
                m_Target.Radius = newRadius;
                m_Target.Height = newHeight;
                m_Target.Position = newPos;
                m_Target.Rotation = Quaternion.Euler(newEuler);
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Visualization", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            Color cylColor = EditorGUILayout.ColorField("Cylinder Color", m_Target.CylinderColor);
            float cylAlpha = EditorGUILayout.Slider("Transparency", m_Target.CylinderAlpha, 0.05f, 0.5f);
            int segments = EditorGUILayout.IntSlider("Circle Segments", m_Target.CircleSegments, 8, 32);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Cylinder Visualization");
                m_Target.CylinderColor = cylColor;
                m_Target.CylinderAlpha = cylAlpha;
                m_Target.CircleSegments = segments;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            
            string helpText = "CYLINDER MODE:\n" +
                "1=Move | 2=Rotate | 3=Scale\n" +
                "Del = Delete splats inside\n" +
                "Shift+R = Restore splats inside\n" +
                "WASD = Navigate scene\n" +
                "Escape = Exit mode";
            EditorGUILayout.HelpBox(helpText, MessageType.Info);
            
            EditorGUILayout.Space();
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
            if (GUILayout.Button("Delete", GUILayout.Height(30)))
            {
                m_Target.DeleteSplatsInCylinder();
            }
            
            GUI.backgroundColor = new Color(0.5f, 0.8f, 1f);
            if (GUILayout.Button("Restore", GUILayout.Height(30)))
            {
                m_Target.RestoreSplatsInCylinder();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            if (GUILayout.Button("Reset Cylinder"))
                m_Target.ResetCylinder();
            
            EditorGUILayout.Space();
            
            GUI.backgroundColor = m_BrushMode ? new Color(0.8f, 0.3f, 1f) : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Cylinder Mode" : "Start Cylinder Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            if (m_BrushMode)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Active Tool", EditorStyles.boldLabel);
                EditorGUILayout.BeginHorizontal();
                
                GUI.backgroundColor = m_ActiveTool == Tool.Move ? Color.green : Color.white;
                if (GUILayout.Button("Move (1)"))
                    m_ActiveTool = Tool.Move;
                
                GUI.backgroundColor = m_ActiveTool == Tool.Rotate ? Color.green : Color.white;
                if (GUILayout.Button("Rotate (2)"))
                    m_ActiveTool = Tool.Rotate;
                
                GUI.backgroundColor = m_ActiveTool == Tool.Scale ? Color.green : Color.white;
                if (GUILayout.Button("Scale (3)"))
                    m_ActiveTool = Tool.Scale;
                
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
            }
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            m_NavigationMode = false;
            GaussianSplatCylinderBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            m_NavigationMode = false;
            GaussianSplatCylinderBrush.IsBrushModeActive = false;
            GaussianSplatCylinderBrush.HasValidBrushPosition = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatCylinderBrush.IsBrushModeActive = false;
                GaussianSplatCylinderBrush.HasValidBrushPosition = false;
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            // Toggle navigation with middle mouse
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                sceneView.Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            // Draw cylinder and handles
            DrawCylinderHandles(sceneView);
            DrawCylinderPreview(sceneView);
            
            // Tool hotkeys (1/2/3 to not conflict with WASD navigation)
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha1)
            {
                m_ActiveTool = Tool.Move;
                e.Use();
                Repaint();
            }
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha2)
            {
                m_ActiveTool = Tool.Rotate;
                e.Use();
                Repaint();
            }
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha3)
            {
                m_ActiveTool = Tool.Scale;
                e.Use();
                Repaint();
            }
            
            // Delete key
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
            {
                m_Target.DeleteSplatsInCylinder();
                e.Use();
                sceneView.Repaint();
            }
            
            // Shift+R to restore
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.R && e.shift)
            {
                m_Target.RestoreSplatsInCylinder();
                e.Use();
                sceneView.Repaint();
            }
            
            // Escape
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopBrushMode();
                Repaint();
                e.Use();
            }

            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private void DrawCylinderHandles(SceneView sceneView)
        {
            Vector3 pos = m_Target.Position;
            Quaternion rot = m_Target.Rotation;
            
            EditorGUI.BeginChangeCheck();
            
            switch (m_ActiveTool)
            {
                case Tool.Move:
                    Vector3 newPos = Handles.PositionHandle(pos, rot);
                    if (newPos != pos)
                    {
                        Undo.RecordObject(m_Target, "Move Cylinder");
                        m_Target.Position = newPos;
                        EditorUtility.SetDirty(m_Target);
                    }
                    break;
                    
                case Tool.Rotate:
                    Quaternion newRot = Handles.RotationHandle(rot, pos);
                    if (newRot != rot)
                    {
                        Undo.RecordObject(m_Target, "Rotate Cylinder");
                        m_Target.Rotation = newRot;
                        EditorUtility.SetDirty(m_Target);
                    }
                    break;
                    
                case Tool.Scale:
                    // Custom scale handles for radius and height
                    float handleSize = HandleUtility.GetHandleSize(pos) * 0.1f;
                    Vector3 up = m_Target.AxisDirection;
                    Vector3 right = GetPerpendicular(up);
                    Vector3 forward = Vector3.Cross(up, right);
                    
                    // Height handle (along axis)
                    Vector3 topHandle = pos + up * (m_Target.Height * 0.5f);
                    Vector3 bottomHandle = pos - up * (m_Target.Height * 0.5f);
                    
                    Handles.color = Color.green;
                    Vector3 newTop = Handles.Slider(topHandle, up, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
                    if (newTop != topHandle)
                    {
                        Undo.RecordObject(m_Target, "Scale Cylinder Height");
                        float delta = Vector3.Dot(newTop - topHandle, up);
                        m_Target.Height = Mathf.Max(0.01f, m_Target.Height + delta * 2f);
                        EditorUtility.SetDirty(m_Target);
                    }
                    
                    // Radius handles
                    Handles.color = Color.red;
                    Vector3 rightHandle = pos + right * m_Target.Radius;
                    Vector3 newRight = Handles.Slider(rightHandle, right, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
                    if (newRight != rightHandle)
                    {
                        Undo.RecordObject(m_Target, "Scale Cylinder Radius");
                        float delta = Vector3.Dot(newRight - rightHandle, right);
                        m_Target.Radius = Mathf.Max(0.01f, m_Target.Radius + delta);
                        EditorUtility.SetDirty(m_Target);
                    }
                    
                    Handles.color = Color.blue;
                    Vector3 forwardHandle = pos + forward * m_Target.Radius;
                    Vector3 newForward = Handles.Slider(forwardHandle, forward, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
                    if (newForward != forwardHandle)
                    {
                        Undo.RecordObject(m_Target, "Scale Cylinder Radius");
                        float delta = Vector3.Dot(newForward - forwardHandle, forward);
                        m_Target.Radius = Mathf.Max(0.01f, m_Target.Radius + delta);
                        EditorUtility.SetDirty(m_Target);
                    }
                    break;
            }
        }

        private void DrawCylinderPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Target.Position;
            float radius = m_Target.Radius;
            float height = m_Target.Height;
            Vector3 up = m_Target.AxisDirection;
            
            Color cylColor = m_Target.CylinderColor;
            float alpha = m_Target.CylinderAlpha;
            int segments = m_Target.CircleSegments;
            
            DrawSolid3DCylinder(pos, radius, height, up, cylColor, alpha, segments);
            
            // Instructions
            GUIStyle labelStyle = new GUIStyle
            {
                normal = { textColor = Color.white },
                fontSize = 11,
                fontStyle = FontStyle.Bold
            };
            
            string toolName = m_ActiveTool == Tool.Move ? "1:MOVE" : 
                              m_ActiveTool == Tool.Rotate ? "2:ROTATE" : "3:SCALE";
            Handles.Label(pos + up * (height * 0.5f + 0.15f), 
                $"[{toolName}] Del=Delete | WASD=Navigate", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawSolid3DCylinder(Vector3 center, float radius, float height, Vector3 up, 
            Color color, float alpha, int segments)
        {
            Vector3 right = GetPerpendicular(up);
            Vector3 forward = Vector3.Cross(up, right);
            
            float halfHeight = height * 0.5f;
            Vector3 topCenter = center + up * halfHeight;
            Vector3 bottomCenter = center - up * halfHeight;
            
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            // Generate circle points
            Vector3[] topPoints = new Vector3[segments];
            Vector3[] bottomPoints = new Vector3[segments];
            
            for (int i = 0; i < segments; i++)
            {
                float angle = (i / (float)segments) * Mathf.PI * 2f;
                Vector3 offset = (right * Mathf.Cos(angle) + forward * Mathf.Sin(angle)) * radius;
                topPoints[i] = topCenter + offset;
                bottomPoints[i] = bottomCenter + offset;
            }
            
            // Draw top cap
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Vector3[] tri = new Vector3[] { topCenter, topPoints[i], topPoints[next] };
                Handles.DrawSolidRectangleWithOutline(new Vector3[] { topCenter, topPoints[i], topPoints[next], topCenter }, 
                    fillColor, Color.clear);
            }
            
            // Draw bottom cap
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawSolidRectangleWithOutline(new Vector3[] { bottomCenter, bottomPoints[next], bottomPoints[i], bottomCenter }, 
                    fillColor, Color.clear);
            }
            
            // Draw side quads
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Vector3[] quad = new Vector3[] { bottomPoints[i], topPoints[i], topPoints[next], bottomPoints[next] };
                Handles.DrawSolidRectangleWithOutline(quad, fillColor, Color.clear);
            }
            
            // Draw wireframe
            Handles.color = outlineColor;
            
            // Top and bottom circles
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawLine(topPoints[i], topPoints[next], 1.5f);
                Handles.DrawLine(bottomPoints[i], bottomPoints[next], 1.5f);
            }
            
            // Vertical lines (every 4th segment for cleaner look)
            for (int i = 0; i < segments; i += Mathf.Max(1, segments / 4))
            {
                Handles.DrawLine(topPoints[i], bottomPoints[i], 1.5f);
            }
        }

        private Vector3 GetPerpendicular(Vector3 v)
        {
            if (Mathf.Abs(v.x) < 0.9f)
                return Vector3.Cross(v, Vector3.right).normalized;
            return Vector3.Cross(v, Vector3.up).normalized;
        }
    }
    
    [EditorTool("Splat Cylinder Brush", typeof(GaussianSplatCylinderBrush))]
    public class GaussianSplatCylinderBrushTool : EditorTool
    {
        private GaussianSplatCylinderBrush m_Brush;
        private bool m_NavigationMode = false;
        private Tool m_ActiveTool = Tool.Move;

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("d_SceneViewTools").image,
            "Splat Cylinder Brush Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatCylinderBrush;
            GaussianSplatCylinderBrush.IsBrushModeActive = true;
            m_NavigationMode = false;
        }
        
        private void OnDisable()
        {
            GaussianSplatCylinderBrush.IsBrushModeActive = false;
            GaussianSplatCylinderBrush.HasValidBrushPosition = false;
            m_NavigationMode = false;
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                GaussianSplatCylinderBrush.IsBrushModeActive = false;
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatCylinderBrush.IsBrushModeActive = true;
            
            DrawToolCylinderHandles(sceneView);
            DrawToolCylinderPreview(sceneView);
            
            // Tool hotkeys (1/2/3 to not conflict with WASD navigation)
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha1)
            {
                m_ActiveTool = Tool.Move;
                e.Use();
            }
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha2)
            {
                m_ActiveTool = Tool.Rotate;
                e.Use();
            }
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha3)
            {
                m_ActiveTool = Tool.Scale;
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
            {
                m_Brush.DeleteSplatsInCylinder();
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.R && e.shift)
            {
                m_Brush.RestoreSplatsInCylinder();
                e.Use();
            }

            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            sceneView.Repaint();
        }
        
        private void DrawToolCylinderHandles(SceneView sceneView)
        {
            Vector3 pos = m_Brush.Position;
            Quaternion rot = m_Brush.Rotation;
            
            switch (m_ActiveTool)
            {
                case Tool.Move:
                    EditorGUI.BeginChangeCheck();
                    Vector3 newPos = Handles.PositionHandle(pos, rot);
                    if (EditorGUI.EndChangeCheck())
                    {
                        Undo.RecordObject(m_Brush, "Move Cylinder");
                        m_Brush.Position = newPos;
                    }
                    break;
                    
                case Tool.Rotate:
                    EditorGUI.BeginChangeCheck();
                    Quaternion newRot = Handles.RotationHandle(rot, pos);
                    if (EditorGUI.EndChangeCheck())
                    {
                        Undo.RecordObject(m_Brush, "Rotate Cylinder");
                        m_Brush.Rotation = newRot;
                    }
                    break;
                    
                case Tool.Scale:
                    float handleSize = HandleUtility.GetHandleSize(pos) * 0.1f;
                    Vector3 up = m_Brush.AxisDirection;
                    Vector3 right = GetToolPerpendicular(up);
                    Vector3 forward = Vector3.Cross(up, right);
                    
                    // Height
                    Handles.color = Color.green;
                    Vector3 topHandle = pos + up * (m_Brush.Height * 0.5f);
                    EditorGUI.BeginChangeCheck();
                    Vector3 newTop = Handles.Slider(topHandle, up, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
                    if (EditorGUI.EndChangeCheck())
                    {
                        Undo.RecordObject(m_Brush, "Scale Cylinder Height");
                        float delta = Vector3.Dot(newTop - topHandle, up);
                        m_Brush.Height = Mathf.Max(0.01f, m_Brush.Height + delta * 2f);
                    }
                    
                    // Radius
                    Handles.color = Color.red;
                    Vector3 rightHandle = pos + right * m_Brush.Radius;
                    EditorGUI.BeginChangeCheck();
                    Vector3 newRight = Handles.Slider(rightHandle, right, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
                    if (EditorGUI.EndChangeCheck())
                    {
                        Undo.RecordObject(m_Brush, "Scale Cylinder Radius");
                        float delta = Vector3.Dot(newRight - rightHandle, right);
                        m_Brush.Radius = Mathf.Max(0.01f, m_Brush.Radius + delta);
                    }
                    
                    Handles.color = Color.blue;
                    Vector3 forwardHandle = pos + forward * m_Brush.Radius;
                    EditorGUI.BeginChangeCheck();
                    Vector3 newForward = Handles.Slider(forwardHandle, forward, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
                    if (EditorGUI.EndChangeCheck())
                    {
                        Undo.RecordObject(m_Brush, "Scale Cylinder Radius");
                        float delta = Vector3.Dot(newForward - forwardHandle, forward);
                        m_Brush.Radius = Mathf.Max(0.01f, m_Brush.Radius + delta);
                    }
                    break;
            }
        }

        private void DrawToolCylinderPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Brush.Position;
            float radius = m_Brush.Radius;
            float height = m_Brush.Height;
            Vector3 up = m_Brush.AxisDirection;
            
            Color cylColor = m_Brush.CylinderColor;
            float alpha = m_Brush.CylinderAlpha;
            int segments = m_Brush.CircleSegments;
            
            DrawToolSolid3DCylinder(pos, radius, height, up, cylColor, alpha, segments);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawToolSolid3DCylinder(Vector3 center, float radius, float height, Vector3 up, 
            Color color, float alpha, int segments)
        {
            Vector3 right = GetToolPerpendicular(up);
            Vector3 forward = Vector3.Cross(up, right);
            
            float halfHeight = height * 0.5f;
            Vector3 topCenter = center + up * halfHeight;
            Vector3 bottomCenter = center - up * halfHeight;
            
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            Vector3[] topPoints = new Vector3[segments];
            Vector3[] bottomPoints = new Vector3[segments];
            
            for (int i = 0; i < segments; i++)
            {
                float angle = (i / (float)segments) * Mathf.PI * 2f;
                Vector3 offset = (right * Mathf.Cos(angle) + forward * Mathf.Sin(angle)) * radius;
                topPoints[i] = topCenter + offset;
                bottomPoints[i] = bottomCenter + offset;
            }
            
            // Top cap
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawSolidRectangleWithOutline(new Vector3[] { topCenter, topPoints[i], topPoints[next], topCenter }, 
                    fillColor, Color.clear);
            }
            
            // Bottom cap
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawSolidRectangleWithOutline(new Vector3[] { bottomCenter, bottomPoints[next], bottomPoints[i], bottomCenter }, 
                    fillColor, Color.clear);
            }
            
            // Sides
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Vector3[] quad = new Vector3[] { bottomPoints[i], topPoints[i], topPoints[next], bottomPoints[next] };
                Handles.DrawSolidRectangleWithOutline(quad, fillColor, Color.clear);
            }
            
            // Wireframe
            Handles.color = outlineColor;
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawLine(topPoints[i], topPoints[next], 1.5f);
                Handles.DrawLine(bottomPoints[i], bottomPoints[next], 1.5f);
            }
            
            for (int i = 0; i < segments; i += Mathf.Max(1, segments / 4))
            {
                Handles.DrawLine(topPoints[i], bottomPoints[i], 1.5f);
            }
        }

        private Vector3 GetToolPerpendicular(Vector3 v)
        {
            if (Mathf.Abs(v.x) < 0.9f)
                return Vector3.Cross(v, Vector3.right).normalized;
            return Vector3.Cross(v, Vector3.up).normalized;
        }
    }
}

