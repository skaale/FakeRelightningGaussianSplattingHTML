// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;
using System.Collections.Generic;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatPatchTool))]
    public class GaussianSplatPatchToolEditor : UnityEditor.Editor
    {
        private GaussianSplatPatchTool m_Target;
        private bool m_EditMode = false;
        private int m_EditingPatchIndex = -1; // -1 = target, 0+ = source patch index
        private bool m_IsDrawingBox = false;
        private Vector3 m_BoxStartPoint;
        private Vector3 m_BoxEndPoint;
        private bool m_ShowGridPreview = true;
        private int m_SelectedPatchForPaste = 0;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatPatchTool;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUILayout.Space();
            DrawSourcePatchesSection();
            
            EditorGUILayout.Space();
            DrawTargetRegionSection();
            
            EditorGUILayout.Space();
            DrawGridSettingsSection();
            
            EditorGUILayout.Space();
            DrawActionsSection();
            
            EditorGUILayout.Space();
            DrawEditModeSection();
            
            serializedObject.ApplyModifiedProperties();
        }

        private void DrawSourcePatchesSection()
        {
            EditorGUILayout.LabelField("Source Patches (Good Areas)", EditorStyles.boldLabel);
            
            var patches = m_Target.SourcePatches;
            for (int i = 0; i < patches.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                
                GUI.backgroundColor = patches[i].gizmoColor;
                EditorGUILayout.LabelField($"[{i}] {patches[i].name}", GUILayout.Width(120));
                GUI.backgroundColor = Color.white;
                
                EditorGUILayout.LabelField($"Size: {patches[i].size.x:F1}x{patches[i].size.y:F1}x{patches[i].size.z:F1}", GUILayout.Width(140));
                
                if (GUILayout.Button("Edit", GUILayout.Width(40)))
                {
                    m_EditingPatchIndex = i;
                    StartEditMode();
                }
                
                if (GUILayout.Button("X", GUILayout.Width(25)))
                {
                    Undo.RecordObject(m_Target, "Remove Patch");
                    m_Target.RemoveSourcePatch(i);
                    EditorUtility.SetDirty(m_Target);
                    break;
                }
                
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = new Color(0.5f, 1f, 0.5f);
            if (GUILayout.Button("+ Add Source Patch"))
            {
                Undo.RecordObject(m_Target, "Add Patch");
                Vector3 pos = m_Target.TargetRenderer != null ? 
                    m_Target.TargetRenderer.GetWorldBounds().center : Vector3.zero;
                m_Target.AddSourcePatch(pos, Vector3.one);
                m_EditingPatchIndex = m_Target.SourcePatches.Count - 1;
                StartEditMode();
                EditorUtility.SetDirty(m_Target);
            }
            GUI.backgroundColor = Color.white;
            
            if (patches.Count > 0 && GUILayout.Button("Clear All", GUILayout.Width(70)))
            {
                Undo.RecordObject(m_Target, "Clear Patches");
                m_Target.ClearSourcePatches();
                EditorUtility.SetDirty(m_Target);
            }
            EditorGUILayout.EndHorizontal();
        }

        private void DrawTargetRegionSection()
        {
            EditorGUILayout.LabelField("Target Region (Area to Fix)", EditorStyles.boldLabel);
            
            var target = m_Target.TargetRegion;
            
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = EditorGUILayout.Vector3Field("Position", target.position);
            Vector3 newSize = EditorGUILayout.Vector3Field("Size", target.size);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Edit Target Region");
                target.position = newPos;
                target.size = newSize;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = new Color(1f, 0.7f, 0.7f);
            if (GUILayout.Button("Edit Target Region"))
            {
                m_EditingPatchIndex = -1;
                StartEditMode();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
        }

        private void DrawGridSettingsSection()
        {
            EditorGUILayout.LabelField("Grid Fill Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            Vector3 cellSize = EditorGUILayout.Vector3Field("Cell Size", m_Target.GridCellSize);
            Vector3 offset = EditorGUILayout.Vector3Field("Grid Offset", m_Target.GridOffset);
            float jitter = EditorGUILayout.Slider("Position Jitter", m_Target.PositionJitter, 0f, 0.5f);
            bool randomPatch = EditorGUILayout.Toggle("Random Patch Selection", m_Target.RandomizePatchSelection);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Edit Grid Settings");
                m_Target.GridCellSize = cellSize;
                m_Target.GridOffset = offset;
                m_Target.PositionJitter = jitter;
                m_Target.RandomizePatchSelection = randomPatch;
                EditorUtility.SetDirty(m_Target);
            }
            
            m_ShowGridPreview = EditorGUILayout.Toggle("Show Grid Preview", m_ShowGridPreview);
            
            // Show grid stats
            var positions = m_Target.GetGridPreviewPositions();
            EditorGUILayout.HelpBox($"Grid will place {positions.Count} patches", MessageType.Info);
        }

        private void DrawActionsSection()
        {
            EditorGUILayout.LabelField("Actions", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            
            GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
            if (GUILayout.Button("Delete Target", GUILayout.Height(30)))
            {
                m_Target.DeleteTargetRegion();
            }
            
            GUI.backgroundColor = new Color(0.5f, 0.8f, 1f);
            GUI.enabled = m_Target.SourcePatches.Count > 0;
            if (GUILayout.Button("Grid Fill", GUILayout.Height(30)))
            {
                m_Target.GridFillTargetRegion();
            }
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.EndHorizontal();
            
            GUI.backgroundColor = new Color(1f, 0.8f, 0.3f);
            GUI.enabled = m_Target.SourcePatches.Count > 0;
            if (GUILayout.Button("Delete & Fill (One Click)", GUILayout.Height(35)))
            {
                m_Target.DeleteAndFill();
            }
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            
            // Manual paste section
            if (m_Target.SourcePatches.Count > 0)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Manual Paste", EditorStyles.boldLabel);
                
                string[] patchNames = new string[m_Target.SourcePatches.Count];
                for (int i = 0; i < m_Target.SourcePatches.Count; i++)
                    patchNames[i] = $"[{i}] {m_Target.SourcePatches[i].name}";
                
                m_SelectedPatchForPaste = EditorGUILayout.Popup("Patch to Paste", m_SelectedPatchForPaste, patchNames);
                
                EditorGUILayout.HelpBox("In Edit Mode: Click in scene to paste selected patch", MessageType.None);
            }
        }

        private void DrawEditModeSection()
        {
            GUI.backgroundColor = m_EditMode ? Color.cyan : Color.white;
            string btnText = m_EditMode ? "Stop Edit Mode" : "Start Edit Mode";
            if (GUILayout.Button(btnText, GUILayout.Height(35)))
            {
                if (m_EditMode)
                    StopEditMode();
                else
                    StartEditMode();
            }
            GUI.backgroundColor = Color.white;
            
            if (m_EditMode)
            {
                string editTarget = m_EditingPatchIndex < 0 ? "Target Region" : $"Source Patch [{m_EditingPatchIndex}]";
                EditorGUILayout.HelpBox(
                    $"Editing: {editTarget}\n\n" +
                    "DRAG = Draw box\n" +
                    "Click = Paste selected patch\n" +
                    "ESC = Exit",
                    MessageType.Info);
            }
        }

        private void StartEditMode()
        {
            m_EditMode = true;
            m_IsDrawingBox = false;
            GaussianSplatPatchTool.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopEditMode()
        {
            m_EditMode = false;
            m_IsDrawingBox = false;
            GaussianSplatPatchTool.IsBrushModeActive = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            GaussianSplatPatchTool.IsBrushModeActive = false;
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_EditMode || m_Target == null) return;

            Event e = Event.current;
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetHitPoint(ray, sceneView);
            
            DrawAllBoxes();
            DrawGridPreview();
            DrawCursor(hitPoint);
            
            // Drag to draw box
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                m_IsDrawingBox = true;
                m_BoxStartPoint = hitPoint;
                m_BoxEndPoint = hitPoint;
                e.Use();
            }
            
            if (e.type == EventType.MouseDrag && e.button == 0 && m_IsDrawingBox)
            {
                m_BoxEndPoint = hitPoint;
                sceneView.Repaint();
                e.Use();
            }
            
            if (e.type == EventType.MouseUp && e.button == 0 && m_IsDrawingBox)
            {
                m_IsDrawingBox = false;
                ApplyDrawnBox();
                e.Use();
            }
            
            // Right-click to paste
            if (e.type == EventType.MouseDown && e.button == 1 && !m_IsDrawingBox)
            {
                if (m_Target.SourcePatches.Count > 0)
                {
                    Undo.RecordObject(m_Target.TargetRenderer, "Paste Patch");
                    m_Target.PastePatchAt(m_SelectedPatchForPaste, hitPoint);
                }
                e.Use();
            }
            
            // Tab to cycle editing target
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Tab)
            {
                m_EditingPatchIndex++;
                if (m_EditingPatchIndex >= m_Target.SourcePatches.Count)
                    m_EditingPatchIndex = -1;
                Repaint();
                e.Use();
            }
            
            // Escape to exit
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopEditMode();
                Repaint();
                e.Use();
            }

            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private void ApplyDrawnBox()
        {
            Vector3 min = Vector3.Min(m_BoxStartPoint, m_BoxEndPoint);
            Vector3 max = Vector3.Max(m_BoxStartPoint, m_BoxEndPoint);
            Vector3 center = (min + max) * 0.5f;
            Vector3 size = max - min;
            size = new Vector3(Mathf.Max(0.1f, size.x), Mathf.Max(0.1f, size.y), Mathf.Max(0.1f, size.z));
            
            Undo.RecordObject(m_Target, "Draw Box");
            
            if (m_EditingPatchIndex < 0)
            {
                m_Target.TargetRegion.position = center;
                m_Target.TargetRegion.size = size;
            }
            else if (m_EditingPatchIndex < m_Target.SourcePatches.Count)
            {
                m_Target.SourcePatches[m_EditingPatchIndex].position = center;
                m_Target.SourcePatches[m_EditingPatchIndex].size = size;
            }
            
            EditorUtility.SetDirty(m_Target);
        }

        private Vector3 GetHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            
            if (Physics.Raycast(ray, out RaycastHit hit, 1000f))
                return hit.point;
            
            if (m_Target.TargetRenderer != null)
            {
                Bounds bounds = m_Target.TargetRenderer.GetWorldBounds();
                if (bounds.size.sqrMagnitude > 0.001f)
                {
                    if (bounds.IntersectRay(ray, out float dist) && dist > 0)
                        return ray.GetPoint(dist);
                    
                    float focusDepth = Vector3.Distance(cameraPos, sceneView.pivot);
                    Vector3 hitPoint = ray.GetPoint(focusDepth);
                    if (!bounds.Contains(hitPoint))
                        hitPoint = bounds.ClosestPoint(hitPoint);
                    return hitPoint;
                }
            }
            
            return ray.GetPoint(Vector3.Distance(cameraPos, sceneView.pivot));
        }

        private void DrawAllBoxes()
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw source patches
            for (int i = 0; i < m_Target.SourcePatches.Count; i++)
            {
                var patch = m_Target.SourcePatches[i];
                bool isEditing = m_EditingPatchIndex == i;
                
                Handles.color = isEditing ? Color.yellow : new Color(patch.gizmoColor.r, patch.gizmoColor.g, patch.gizmoColor.b, 0.9f);
                Handles.DrawWireCube(patch.position, patch.size);
                
                if (isEditing)
                {
                    DrawBoxHandles(patch);
                }
                
                // Label
                GUIStyle style = new GUIStyle();
                style.normal.textColor = patch.gizmoColor;
                style.fontSize = 11;
                Handles.Label(patch.position + Vector3.up * patch.size.y * 0.5f, patch.name, style);
            }
            
            // Draw target region
            var target = m_Target.TargetRegion;
            bool editingTarget = m_EditingPatchIndex < 0;
            
            Handles.color = editingTarget ? Color.yellow : new Color(1f, 0.3f, 0.3f, 0.9f);
            Handles.DrawWireCube(target.position, target.size);
            
            if (editingTarget)
            {
                DrawBoxHandles(target);
            }
            
            // Label
            GUIStyle targetStyle = new GUIStyle();
            targetStyle.normal.textColor = new Color(1f, 0.5f, 0.5f);
            targetStyle.fontSize = 12;
            targetStyle.fontStyle = FontStyle.Bold;
            Handles.Label(target.position + Vector3.up * target.size.y * 0.5f, "TARGET", targetStyle);
            
            // Draw box being drawn
            if (m_IsDrawingBox)
            {
                Handles.color = new Color(1f, 1f, 0f, 0.7f);
                Vector3 min = Vector3.Min(m_BoxStartPoint, m_BoxEndPoint);
                Vector3 max = Vector3.Max(m_BoxStartPoint, m_BoxEndPoint);
                Vector3 center = (min + max) * 0.5f;
                Vector3 size = max - min;
                Handles.DrawWireCube(center, size);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawBoxHandles(GaussianSplatPatchTool.PatchData patch)
        {
            EditorGUI.BeginChangeCheck();
            
            // Position handle
            Vector3 newPos = Handles.PositionHandle(patch.position, Quaternion.identity);
            
            // Size handles
            float handleSize = HandleUtility.GetHandleSize(patch.position) * 0.08f;
            
            Handles.color = Color.red;
            Vector3 rightHandle = patch.position + Vector3.right * patch.size.x * 0.5f;
            Vector3 newRight = Handles.Slider(rightHandle, Vector3.right, handleSize, Handles.CubeHandleCap, 0.01f);
            
            Handles.color = Color.green;
            Vector3 upHandle = patch.position + Vector3.up * patch.size.y * 0.5f;
            Vector3 newUp = Handles.Slider(upHandle, Vector3.up, handleSize, Handles.CubeHandleCap, 0.01f);
            
            Handles.color = Color.blue;
            Vector3 forwardHandle = patch.position + Vector3.forward * patch.size.z * 0.5f;
            Vector3 newForward = Handles.Slider(forwardHandle, Vector3.forward, handleSize, Handles.CubeHandleCap, 0.01f);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Edit Patch");
                patch.position = newPos;
                patch.size = new Vector3(
                    Mathf.Max(0.1f, (newRight - patch.position).x * 2f),
                    Mathf.Max(0.1f, (newUp - patch.position).y * 2f),
                    Mathf.Max(0.1f, (newForward - patch.position).z * 2f));
                EditorUtility.SetDirty(m_Target);
            }
        }

        private void DrawGridPreview()
        {
            if (!m_ShowGridPreview) return;
            
            var positions = m_Target.GetGridPreviewPositions();
            
            Handles.color = new Color(1f, 1f, 0f, 0.3f);
            float dotSize = Mathf.Min(m_Target.GridCellSize.x, m_Target.GridCellSize.z) * 0.15f;
            
            foreach (var pos in positions)
            {
                Handles.SphereHandleCap(0, pos, Quaternion.identity, dotSize, EventType.Repaint);
            }
        }

        private void DrawCursor(Vector3 pos)
        {
            Handles.color = Color.white;
            Handles.SphereHandleCap(0, pos, Quaternion.identity, 0.05f, EventType.Repaint);
            
            GUIStyle style = new GUIStyle();
            style.normal.textColor = Color.white;
            style.fontSize = 11;
            
            string text = m_EditingPatchIndex < 0 ? "Editing: TARGET" : $"Editing: Patch [{m_EditingPatchIndex}]";
            text += "\nDrag=Draw | RClick=Paste | Tab=Cycle";
            Handles.Label(pos + Vector3.up * 0.15f, text, style);
        }
    }
}

