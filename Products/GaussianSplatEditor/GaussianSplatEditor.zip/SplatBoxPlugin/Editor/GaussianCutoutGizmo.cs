// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [DrawGizmo(GizmoType.NonSelected | GizmoType.Selected, typeof(GaussianCutout))]
    public static class GaussianCutoutGizmo
    {
        public static void OnDrawGizmos(GaussianCutout cutout, GizmoType gizmoType)
        {
            if (cutout == null) return;
            Gizmos.matrix = cutout.transform.localToWorldMatrix;
            var color = Color.magenta;
            color.a = 0.2f;
            if (Selection.Contains(cutout.gameObject))
                color.a = 0.9f;
            else
            {
                var activeGo = Selection.activeGameObject;
                if (activeGo != null)
                {
                    var activeSplat = activeGo.GetComponent<SplatBoxRenderer>();
                    if (activeSplat != null && activeSplat.m_Cutouts != null && System.Array.IndexOf(activeSplat.m_Cutouts, cutout) >= 0)
                        color.a = 0.5f;
                }
            }
            Gizmos.color = color;
            if (cutout.m_Type == GaussianCutout.Type.Ellipsoid)
                Gizmos.DrawWireSphere(Vector3.zero, 1.0f);
            if (cutout.m_Type == GaussianCutout.Type.Box)
                Gizmos.DrawWireCube(Vector3.zero, Vector3.one * 2);
        }
    }
}
