// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;

namespace GaussianSplatting.Editor
{
    static class SplatBoxLodDiagnosticsMenu
    {
        const string kMenuPath = "Tools/Splat Box/Log LoD Activity";

        [MenuItem(kMenuPath)]
        static void Toggle()
        {
            SplatBoxLodDiagnostics.enabled = !SplatBoxLodDiagnostics.enabled;
            Menu.SetChecked(kMenuPath, SplatBoxLodDiagnostics.enabled);
        }
    }
}
