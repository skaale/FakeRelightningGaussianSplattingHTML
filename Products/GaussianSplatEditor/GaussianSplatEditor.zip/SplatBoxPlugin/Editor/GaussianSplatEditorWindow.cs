// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEditor;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    public class GaussianSplatEditorWindow : EditorWindow
    {
        public enum BrushTool
        {
            None = 0,
            EraseBrush = 1,
            BoxBrush = 2,
            CloneBrush = 3,
            FloorFill = 4,
            PatchTool = 5,
            PolyMask = 6,
            ColorBrush = 7,
            VortexTool = 8,
            FillBrush = 9,
            PaintBrush = 10,
            CylinderBrush = 11,
            TextureStamp = 12,
            SculptBrush = 13,
            ColorizeBrush = 14
        }

        public enum StampBlendMode
        {
            Replace = 0,
            Multiply = 1,
            Screen = 2,
            Overlay = 3,
            Darken = 4,
            Lighten = 5
        }

        private static GaussianSplatEditorWindow s_Window;
        const string kTargetRendererGlobalIdKey = "SplatBox.Editor.TargetRendererGlobalId";
        const string kTargetRendererPathKey = "SplatBox.Editor.TargetRendererHierarchyPath";
        
        private SplatBoxRenderer m_TargetRenderer;
        private BrushTool m_CurrentTool = BrushTool.None;
        private bool m_IsToolActive = false;
        
        // Geo Brush primitive tool mode (1=Move, 2=Rotate, 3=Scale)
        private int m_GeoPrimitiveToolMode = 1;
        
        // Tool instances
        private GaussianSplatBrush m_EraseBrush;
        private GaussianSplatBoxBrush m_BoxBrush;
        private GaussianSplatCloneBrush m_CloneBrush;
        private GaussianSplatFloorFillBrush m_FloorFillBrush;
        private GaussianSplatPatchTool m_PatchTool;
        private GaussianPolyMask m_PolyMask;
        private GaussianSplatColorBrush m_ColorBrush;
        private GaussianSplatAttractor m_VortexAttractor;
        private GaussianSplatFillBrush m_FillBrush;
        private GaussianSplatPaintBrush m_PaintBrush;
        private GaussianSplatCylinderBrush m_CylinderBrush;
        private GaussianSplatColorizeBrush m_ColorizeBrush;
        
        // PolyMask drawing state
        private Vector3 m_LastMaskMousePos;
        private double m_LastMaskClickTime;
        
        // UI State
        private Vector2 m_ScrollPosition;
#pragma warning disable CS0414 // assigned for future use
        private bool m_ShowRendererSettings = true;
        private bool m_ShowBrushSettings = true;
#pragma warning restore CS0414
        private bool m_ShowToolSettings = true;
        private bool m_ShowQuickActions = true;
        private bool m_ShowHelp = false;
        private int m_HelpTabIndex = 0;
        private bool m_ShowExport = false;
        private bool m_ExportBakeTransform = false;
        // Remove oversized "floater" gaussians on export (they're hidden by the live renderer but
        // render as spikes/needles in external PLY/SPZ viewers). Threshold is a fraction of the
        // asset's bounds diagonal applied to the largest world-space scale axis.
        private bool m_ExportFilterSpikes = true;
        private float m_ExportSpikeScaleFraction = 0.25f;

        // Merge multiple splat renderers into one compressed asset
        private float m_MergeCompression = 2f; // 0=VeryLow .. 4=VeryHigh (maps to DataQuality)
        private string m_MergeAssetName = "MergedSplats";
        private string m_MergeOutputFolder = "Assets/GaussianAssets/Merged";
        private bool m_MergeDisableSources = true;
        private bool m_MergeBakeWorldTransform = true;

        // Smart decimation for Android VR / memory reduction
        private float m_DecimateRemoval = 0.5f;
        private float m_DecimateCompression = 1f; // 0=max compression, 4=best quality
        private bool m_DecimateSaveAsset = true;
        private string m_DecimateOutputFolder = "Assets/GaussianAssets/Decimated";
        private string m_DecimateAssetSuffix = "_vr";
        
        // Paint brush mode: 0 = Paint, 1 = Colorize, 2 = Animation
        private int m_PaintBrushMode = 0;
        
        // Animation Paint settings
        public enum AnimationPaintStyle { River = 0, Whirlpool = 1, Wave = 2, RandomLeaves = 3 }
        private AnimationPaintStyle m_AnimPaintStyle = AnimationPaintStyle.River;
        private float m_AnimPaintSpeed = 1f;
        private float m_AnimPaintVelocity = 0.5f;
        private float m_AnimPaintRadius = 2f;
        private float m_AnimPaintNoiseStrength = 0.2f;
        private float m_AnimPaintNoiseScale = 1f;
        private bool m_AnimPaintShowOverlay = true;
        private bool m_AnimPaintActive = false;
        private Vector3 m_AnimPaintLastDirection = Vector3.forward;
        private List<Vector3> m_AnimPaintStrokePoints = new List<Vector3>();
        private List<Vector3> m_AnimPaintStrokeDirections = new List<Vector3>();
        private bool m_AnimPaintUseManualDirection = false;
        private Vector3 m_AnimPaintManualDirection = new Vector3(1f, 0f, 0f);
        private bool m_AnimPaintDisableGravity = true;
        
        // Animation Recording/Playback
        private GaussianSplatAnimationRecorder m_AnimRecorder;
        private bool m_ShowAnimRecorder = true;
        private float m_AnimRecordFPS = 30f;
        private float m_AnimMaxDuration = 30f;
        private float m_AnimPlaybackSpeed = 1f;
        private bool m_AnimLoop = true;
        private bool m_AnimPingPong = false;
        
        // Tilt-Shift & Depth of Field Effect
        private bool m_ShowTiltShift = false;
        private bool m_TiltShiftEnabled = false;
        private int m_BlurMode = 0; // 0=TiltShift, 1=DoF, 2=Both
        private float m_TiltShiftFocusPosition = 0.5f;
        private float m_TiltShiftFocusWidth = 0.05f;
        private float m_TiltShiftTopBlurOffset = 0f;
        private float m_TiltShiftBottomBlurOffset = 0f;
        private float m_TiltShiftAngle = 0f;
        private float m_DoFFocusDistance = 10f;
        private float m_DoFFocusRange = 5f;
        private float m_DoFNearBlur = 0.5f;
        private float m_DoFFarBlur = 0.8f;
        private float m_TiltShiftBlurStrength = 10f;
        private int m_TiltShiftBlurSamples = 8;
        private float m_TiltShiftBokehShape = 0.5f;
        private float m_TiltShiftSaturation = 1f;
        private float m_TiltShiftContrast = 1f;
        private float m_TiltShiftVignette = 0.58f;
        private bool m_TiltShiftHighQuality = true;
        private Material m_TiltShiftMaterial;
        
        // Texture capture state
        private bool m_IsCapturingRect = false;
        private int m_CaptureTargetSlot = 0;
        private Vector2 m_CaptureStartPos;
        private Vector2 m_CaptureEndPos;
        private bool m_IsDraggingCapture = false;
        
        // Texture stamp state
        private Vector3 m_StampStartWorld;
        private Vector3 m_StampEndWorld;
        private bool m_IsDraggingStamp = false;
        private float m_StampSurfaceDepth = 10f;
        private int m_StampActiveSlot = 0;
        private int m_StampResolution = 32; // Single resolution, aspect from texture
        private float m_StampSplatSizeMultiplier = 1.2f; // Multiplier for auto-calculated size
        private float m_StampDensity = 1f;
        private bool m_StampAutoSize = true; // Auto-calculate splat size from stamp dimensions
        
        // Stamp layering state
        private bool m_StampLayeringEnabled = false;
        private float m_StampLayerSpacing = 0.01f;
        private int m_StampCurrentLayer = 0;
        
        // Stamp blend mode
        private StampBlendMode m_StampBlendMode = StampBlendMode.Replace;
        
        // Cached styles for preview (avoid allocating every frame)
        private static GUIStyle s_StampLabelStyle;
        
        // Smudge brush state
        // Sculpt Brush tab state: 0 = Smudge, 1 = Pinch, 2 = Move, 3 = Flatten, 4 = Relax
        private int m_SculptBrushTab = 0;
        
        // Smudge properties
        private float m_SmudgeRadius = 1.5f;
        private float m_SmudgeStrength = 0.5f;
        private float m_SmudgeFalloff = 0.5f;
        private bool m_SmudgeBlendColors = true;
        private Vector3 m_SmudgeLastPos;
        private bool m_IsSmudging = false;
        private bool m_IsPinching = false;
        
        // Pinch properties (separate from smudge)
        private float m_PinchRadius = 1.5f;
        private float m_PinchStrength = 0.3f;
        private float m_PinchFalloff = 0.5f;
        
        // Move brush properties
        private float m_MoveRadius = 2.0f;
        private float m_MoveStrength = 0.25f;  // Gentler than smudge
        private float m_MoveFalloff = 0.3f;
        private bool m_IsMoving = false;
        private bool m_MoveConstrainLine = false;  // SHIFT constrains to straight line
        private Vector3 m_MoveStartPos;
        private Vector3 m_MoveConstraintAxis;  // The axis to constrain movement to
        
        // Flatten brush properties
        private float m_FlattenRadius = 3.0f;  // Larger radius for flattening
        private float m_FlattenStrength = 0.4f;
        private float m_FlattenFalloff = 0.4f;
        private bool m_IsFlattening = false;
        private Vector3 m_FlattenPlanePoint;   // Point on the flatten plane
        private Vector3 m_FlattenPlaneNormal;  // Normal of the flatten plane (direction of movement)
        
        // Relax brush properties
        private float m_RelaxRadius = 2.0f;
        private float m_RelaxStrength = 0.3f;
        private float m_RelaxFalloff = 0.5f;
        private float m_RelaxNeighborRadius = 0.5f;  // Radius to search for neighbors (relative to brush)
        private bool m_IsRelaxing = false;
        private bool m_IsRoughening = false;  // SHIFT inverts relax to roughen/scatter
        
        // Restore brush mode (ALT to restore positions to original)
        private bool m_IsRestoringSculpt = false;
        
        // Smudge optimization - throttling and accumulation
        private double m_SmudgeLastExecuteTime;
        private Vector3 m_SmudgeAccumulatedDelta;
        private const double SMUDGE_MIN_INTERVAL = 0.016; // ~60Hz max update rate
        private const float SMUDGE_MIN_DISTANCE = 0.05f; // Minimum distance before executing
        
        // Smudge surface caching - avoid expensive GPU readback every frame
        private Vector3 m_SmudgeCachedSurfacePos;
        private float m_SmudgeCachedDepth;
        private bool m_SmudgeHasCachedSurface = false;
        private double m_SmudgeLastSurfaceUpdate;
        private const double SMUDGE_SURFACE_UPDATE_INTERVAL = 0.25; // Update surface detection every 250ms
        
        // Styling
        private static GUIStyle s_HeaderStyle;
        private static GUIStyle s_TitleStyle;
        private static GUIStyle s_ToolButtonStyle;
        private static GUIStyle s_ActiveToolStyle;
        private static GUIStyle s_StatusStyle;
        private static Texture2D s_HeaderBg;
        private static Texture2D s_DarkBg;
        private static Texture2D s_TitleBg;
        private static Texture2D s_AccentBg;
        private static bool s_StylesInitialized = false;

        // Colors - Professional dark theme
        private static readonly Color COL_BG_DARK = new Color(0.15f, 0.15f, 0.17f);
        private static readonly Color COL_BG_MED = new Color(0.22f, 0.22f, 0.24f);
        private static readonly Color COL_TITLE_BG = new Color(0.10f, 0.10f, 0.12f);
        private static readonly Color COL_ACCENT = new Color(0.18f, 0.52f, 0.89f);
        private static readonly Color COL_ACCENT_HOVER = new Color(0.28f, 0.62f, 0.99f);
        private static readonly Color COL_SUCCESS = new Color(0.35f, 0.75f, 0.45f);
        private static readonly Color COL_WARNING = new Color(0.95f, 0.65f, 0.25f);
        private static readonly Color COL_DANGER = new Color(0.85f, 0.35f, 0.35f);
        private static readonly Color COL_CYAN = new Color(0.3f, 0.85f, 0.95f);
        
        /// <summary>True when Relight plugin assembly is present (optional add-on).</summary>
        public static bool IsRelightPluginInstalled()
        {
            var t = Type.GetType("GaussianSplatting.Relight.Editor.RelightEditorWindow, GaussianSplatting.SplatBox.Relight.Editor");
            return t != null;
        }

        [MenuItem("SplatToolbox/Editor/Splat Editor %#G", false, 100)]
        public static void ShowWindow()
        {
            s_Window = GetWindow<GaussianSplatEditorWindow>();
            s_Window.titleContent = new GUIContent("Splat Editor", EditorGUIUtility.IconContent("d_SceneViewTools").image);
            s_Window.minSize = new Vector2(320, 450);
            s_Window.Show();
        }

        private void OnEnable()
        {
            s_Window = this;
            s_StylesInitialized = false;
            SceneView.duringSceneGui += OnSceneGUI;
            EditorApplication.update += OnEditorUpdate;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            FindOrCreateToolComponents();
            ResolveTargetRenderer(forceRescan: true);
        }

        private void OnDisable()
        {
            if (IsRendererAlive(m_TargetRenderer))
                SaveTargetRendererToPrefs(m_TargetRenderer);
            SceneView.duringSceneGui -= OnSceneGUI;
            EditorApplication.update -= OnEditorUpdate;
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            DeactivateCurrentTool();
            RemoveTiltShiftFromSceneViews();
            CleanupTiltShiftMaterial();
        }
        
        private void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            // Clear tool references when play mode changes to prevent GUILayout errors
            if (state == PlayModeStateChange.ExitingEditMode || state == PlayModeStateChange.ExitingPlayMode)
            {
                m_VortexAttractor = null;
                m_CylinderBrush = null;
                m_PatchTool = null;
            }
            else if (state == PlayModeStateChange.EnteredEditMode || state == PlayModeStateChange.EnteredPlayMode)
            {
                // Re-find components after mode change
                FindOrCreateToolComponents();
                ResolveTargetRenderer(forceRescan: true);
            }
        }

        [InitializeOnLoadMethod]
        static void RegisterAssemblyReloadHandler()
        {
            UnityEditor.AssemblyReloadEvents.afterAssemblyReload += OnAfterAssemblyReload;
        }

        static void OnAfterAssemblyReload()
        {
            if (s_Window != null)
                s_Window.ResolveTargetRenderer(forceRescan: true);
        }

        static bool IsRendererAlive(SplatBoxRenderer renderer)
        {
            if (renderer == null)
                return false;
            // Broken/missing-script refs survive domain reload but fail the typed ObjectField.
            if (renderer.gameObject == null)
                return false;
            return renderer.GetType() == typeof(SplatBoxRenderer);
        }

        static void SaveTargetRendererToPrefs(SplatBoxRenderer renderer)
        {
            if (!IsRendererAlive(renderer))
                return;
            var id = GlobalObjectId.GetGlobalObjectIdSlow(renderer);
            EditorPrefs.SetString(kTargetRendererGlobalIdKey, id.ToString());
            EditorPrefs.SetString(kTargetRendererPathKey, GetRendererHierarchyKey(renderer));
        }

        static string GetRendererHierarchyKey(SplatBoxRenderer renderer)
        {
            var scene = renderer.gameObject.scene;
            string sceneKey = scene.IsValid() ? scene.path : scene.name;
            return sceneKey + "|" + GetTransformPath(renderer.transform);
        }

        static string GetTransformPath(Transform t)
        {
            if (t == null)
                return string.Empty;
            var path = t.name;
            while (t.parent != null)
            {
                t = t.parent;
                path = t.name + "/" + path;
            }
            return path;
        }

        static Transform FindTransformByPath(string hierarchyPath)
        {
            if (string.IsNullOrEmpty(hierarchyPath))
                return null;

            var parts = hierarchyPath.Split('/');
            if (parts.Length == 0)
                return null;

            Transform found = null;
#if UNITY_2022_2_OR_NEWER
            var roots = UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects();
#else
            var roots = UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects();
#endif
            for (int i = 0; i < roots.Length; i++)
            {
                if (roots[i].name != parts[0])
                    continue;
                found = roots[i].transform;
                for (int p = 1; p < parts.Length && found != null; p++)
                    found = found.Find(parts[p]);
                if (found != null)
                    break;
            }
            return found;
        }

        static SplatBoxRenderer TryFindRendererBySavedPath()
        {
            var saved = EditorPrefs.GetString(kTargetRendererPathKey, "");
            if (string.IsNullOrEmpty(saved))
                return null;

            var split = saved.IndexOf('|');
            if (split <= 0)
                return null;

            var transform = FindTransformByPath(saved.Substring(split + 1));
            if (transform == null)
                return null;

            var renderer = transform.GetComponent<SplatBoxRenderer>();
            if (IsRendererAlive(renderer))
                return renderer;

            // Component lost after build — re-add so the scene object can render again.
            renderer = transform.gameObject.AddComponent<SplatBoxRenderer>();
            Debug.Log($"[SplatBox] Re-added missing SplatBoxRenderer on '{GetTransformPath(transform)}'. Re-assign the Gaussian Splat asset if needed.");
            return IsRendererAlive(renderer) ? renderer : null;
        }

        static bool TryLoadTargetRendererFromPrefs(out SplatBoxRenderer renderer)
        {
            renderer = null;
            var idStr = EditorPrefs.GetString(kTargetRendererGlobalIdKey, "");
            if (string.IsNullOrEmpty(idStr))
                return false;
            if (!GlobalObjectId.TryParse(idStr, out GlobalObjectId globalId))
                return false;

            var obj = GlobalObjectId.GlobalObjectIdentifierToObjectSlow(globalId);
            switch (obj)
            {
                case SplatBoxRenderer direct:
                    renderer = direct;
                    break;
                case GameObject go:
                    renderer = go.GetComponent<SplatBoxRenderer>();
                    break;
                case Component component:
                    renderer = component.GetComponent<SplatBoxRenderer>();
                    break;
            }

            return IsRendererAlive(renderer);
        }

        void ResolveTargetRenderer(bool forceRescan = false)
        {
            if (!forceRescan && IsRendererAlive(m_TargetRenderer))
                return;

            m_TargetRenderer = null;

            if (TryLoadTargetRendererFromPrefs(out var fromPrefs))
            {
                m_TargetRenderer = fromPrefs;
                SyncRendererToTools();
                return;
            }

            m_TargetRenderer = TryFindRendererBySavedPath();
            if (IsRendererAlive(m_TargetRenderer))
            {
                SaveTargetRendererToPrefs(m_TargetRenderer);
                SyncRendererToTools();
                return;
            }

            m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
            if (IsRendererAlive(m_TargetRenderer))
            {
                SaveTargetRendererToPrefs(m_TargetRenderer);
                SyncRendererToTools();
            }
        }
        
        private void CleanupTiltShiftMaterial()
        {
            if (m_TiltShiftMaterial != null)
            {
                DestroyImmediate(m_TiltShiftMaterial);
                m_TiltShiftMaterial = null;
            }
        }
        
        private void RemoveTiltShiftFromSceneViews()
        {
            // Reset global settings
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.Reset();
            
            // Remove tilt-shift components from all scene view cameras
            foreach (SceneView sv in SceneView.sceneViews)
            {
                if (sv.camera != null)
                {
                    var effect = sv.camera.GetComponent<GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect>();
                    if (effect != null)
                    {
                        DestroyImmediate(effect);
                    }
                }
            }
        }

        private void OnEditorUpdate()
        {
            // Handle animation recorder playback (force repaint during playback)
            if (m_AnimRecorder != null && (m_AnimRecorder.IsPlaying || m_AnimRecorder.IsRecording))
            {
                SceneView.RepaintAll();
                Repaint();
            }

            RepaintPagedLodReadout();

            // Only update when vortex tool is active and enabled
            if (m_CurrentTool != BrushTool.VortexTool || !m_IsToolActive)
                return;
                
            if (m_VortexAttractor == null || m_TargetRenderer == null)
                return;
                
            var so = new SerializedObject(m_VortexAttractor);
            if (!so.FindProperty("m_AttractorEnabled").boolValue)
                return;
            
            // Manually trigger attractor update in editor
            m_VortexAttractor.ManualUpdate();
            
            // Force renderer update
            m_TargetRenderer.Update();
            SceneView.RepaintAll();
        }

        double m_LastPagedLodRepaint;

        /// <summary>
        /// The paged-LoD numbers change as the Scene view camera moves, and an editor window only
        /// repaints on interaction, so a stale readout would be worse than none. A few refreshes a
        /// second is enough to follow streaming without making the window a constant repaint source.
        /// </summary>
        private void RepaintPagedLodReadout()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.UsesPagedLod)
                return;

            const double kInterval = 0.25;
            double now = EditorApplication.timeSinceStartup;
            if (now - m_LastPagedLodRepaint < kInterval)
                return;
            m_LastPagedLodRepaint = now;
            Repaint();
        }

        private void OnDestroy()
        {
            DestroyTextures();
        }

        private void InitStyles()
        {
            if (s_StylesInitialized) return;
            
            s_HeaderBg = MakeTexture(2, 2, COL_BG_DARK);
            s_DarkBg = MakeTexture(2, 2, COL_BG_MED);
            s_TitleBg = MakeTexture(2, 2, COL_TITLE_BG);
            s_AccentBg = MakeTexture(2, 2, COL_ACCENT);
            
            s_HeaderStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 13,
                alignment = TextAnchor.MiddleCenter,
                padding = new RectOffset(8, 8, 6, 6),
                margin = new RectOffset(0, 0, 4, 4)
            };
            s_HeaderStyle.normal.textColor = Color.white;
            
            s_TitleStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 18,
                alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(12, 12, 10, 10),
                margin = new RectOffset(0, 0, 0, 0)
            };
            s_TitleStyle.normal.textColor = Color.white;
            s_TitleStyle.normal.background = s_TitleBg;
            
            s_ToolButtonStyle = new GUIStyle(GUI.skin.button)
            {
                fontSize = 12,
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter,
                stretchWidth = true,
                margin = new RectOffset(1, 1, 2, 2),
                padding = new RectOffset(2, 2, 4, 4)
            };
            
            s_ActiveToolStyle = new GUIStyle(s_ToolButtonStyle);
            s_ActiveToolStyle.normal.background = s_AccentBg;
            s_ActiveToolStyle.normal.textColor = Color.white;
            
            s_StatusStyle = new GUIStyle(EditorStyles.helpBox)
            {
                fontSize = 11,
                padding = new RectOffset(8, 8, 6, 6),
                richText = true
            };
            
            s_StylesInitialized = true;
        }

        private static Texture2D MakeTexture(int w, int h, Color col)
        {
            var tex = new Texture2D(w, h);
            var pixels = new Color[w * h];
            for (int i = 0; i < pixels.Length; i++) pixels[i] = col;
            tex.SetPixels(pixels);
            tex.Apply();
            return tex;
        }

        private void DestroyTextures()
        {
            if (s_HeaderBg != null) DestroyImmediate(s_HeaderBg);
            if (s_DarkBg != null) DestroyImmediate(s_DarkBg);
            if (s_TitleBg != null) DestroyImmediate(s_TitleBg);
            if (s_AccentBg != null) DestroyImmediate(s_AccentBg);
            s_StylesInitialized = false;
        }

        private void OnGUI()
        {
            InitStyles();
            
            m_ScrollPosition = EditorGUILayout.BeginScrollView(m_ScrollPosition);
            
            DrawHeader();
            DrawTitle();
            DrawRendererSection();
            EditorGUILayout.Space(8);
            DrawToolbar();
            
            // Show Export/Help panels when toggled
            if (m_ShowExport)
            {
                EditorGUILayout.Space(4);
                DrawExportSection();
            }
            if (m_ShowHelp)
            {
                EditorGUILayout.Space(4);
                DrawHelpSection();
            }
            
            EditorGUILayout.Space(8);
            DrawToolSettings();
            EditorGUILayout.Space(8);
            DrawQuickActions();
            EditorGUILayout.Space(8);
            if (m_ShowTiltShift)
            {
                DrawTiltShiftSection();
                EditorGUILayout.Space(8);
            }
            DrawStatusBar();
            
            EditorGUILayout.EndScrollView();
            
            HandleKeyboardShortcuts();
        }

        private void DrawHeader()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            
            GUILayout.FlexibleSpace();
            
            if (m_CurrentTool != BrushTool.None)
            {
                GUI.backgroundColor = m_IsToolActive ? COL_DANGER : COL_SUCCESS;
                if (GUILayout.Button(m_IsToolActive ? "■ STOP" : "▶ START", GUILayout.Width(70), GUILayout.Height(20)))
                {
                    if (m_IsToolActive)
                        DeactivateCurrentTool();
                    else
                        ActivateCurrentTool();
                }
                GUI.backgroundColor = Color.white;
            }
            
            EditorGUILayout.EndHorizontal();
        }
        
        private void DrawTitle()
        {
            EditorGUILayout.Space(8);
            EditorGUILayout.BeginVertical();
            GUILayout.Label("Splat Box Editor", s_TitleStyle);
            if (IsRelightPluginInstalled())
            {
                bool useRelight = EditorPrefs.GetBool("SplatBox.Relight.UseRelight", true);
                EditorGUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                var prevBg = GUI.backgroundColor;
                if (useRelight)
                    GUI.backgroundColor = new Color(0.22f, 0.5f, 0.35f);
                if (GUILayout.Button(useRelight ? " Relight ✓ " : " Relight ", EditorStyles.miniButtonMid, GUILayout.ExpandWidth(false)))
                {
                    useRelight = !useRelight;
                    EditorPrefs.SetBool("SplatBox.Relight.UseRelight", useRelight);
                    if (m_TargetRenderer != null)
                    {
                        if (useRelight)
                            ApplyRelightShaderToRenderer(m_TargetRenderer);
                        else
                            ApplyDefaultShaderToRenderer(m_TargetRenderer);
                    }
                }
                GUI.backgroundColor = prevBg;
                if (GUILayout.Button("Open", EditorStyles.miniButtonRight, GUILayout.Width(36)))
                {
                    var t = Type.GetType("GaussianSplatting.Relight.Editor.RelightEditorWindow, GaussianSplatting.SplatBox.Relight.Editor");
                    var show = t?.GetMethod("ShowWindow", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                    show?.Invoke(null, null);
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(4);
        }

        private void DrawRendererSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);

            ResolveTargetRenderer();

            EditorGUI.BeginChangeCheck();
            m_TargetRenderer = (SplatBoxRenderer)EditorGUILayout.ObjectField(
                "Renderer", m_TargetRenderer, typeof(SplatBoxRenderer), true);
            if (EditorGUI.EndChangeCheck())
            {
                if (IsRendererAlive(m_TargetRenderer))
                    SaveTargetRendererToPrefs(m_TargetRenderer);
                else
                    m_TargetRenderer = null;
                SyncRendererToTools();
            }
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Find in Scene"))
            {
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
                if (IsRendererAlive(m_TargetRenderer))
                    SaveTargetRendererToPrefs(m_TargetRenderer);
                SyncRendererToTools();
            }
            if (GUILayout.Button("Create SplatBoxRender Object"))
            {
                GameObject newObj = new GameObject("SplatBoxRender");
                m_TargetRenderer = newObj.AddComponent<SplatBoxRenderer>();
                SaveTargetRendererToPrefs(m_TargetRenderer);
                Selection.activeGameObject = newObj;
                SyncRendererToTools();
            }
            EditorGUILayout.EndHorizontal();

            if (!IsRendererAlive(m_TargetRenderer))
            {
                EditorGUILayout.HelpBox(
                    "Renderer reference was lost after a build or script reload. Click Find in Scene, or assign the SplatBoxRenderer on your splat GameObject.",
                    MessageType.Warning);
            }
            else if (m_TargetRenderer != null)
            {
                EditorGUILayout.LabelField("Asset", m_TargetRenderer.asset != null ? m_TargetRenderer.asset.name : "None");
                
                if (m_TargetRenderer.HasValidAsset)
                {
                    GUI.color = COL_SUCCESS;
                    EditorGUILayout.LabelField("Status", "Ready ✓");
                    GUI.color = Color.white;
                }
                else
                {
                    GUI.color = COL_WARNING;
                    EditorGUILayout.LabelField("Status", "No valid asset");
                    GUI.color = Color.white;
                }
                if (IsRelightPluginInstalled())
                {
                    EditorGUILayout.Space(4);
                    EditorGUILayout.BeginHorizontal();
                    if (GUILayout.Button("Use Relight shader", GUILayout.Height(22)))
                        ApplyRelightShaderToRenderer(m_TargetRenderer);
                    if (GUILayout.Button("Use default shader", GUILayout.Height(22)))
                        ApplyDefaultShaderToRenderer(m_TargetRenderer);
                    EditorGUILayout.EndHorizontal();
                }

                DrawPagedLodControls(m_TargetRenderer);
            }
            
            EditorGUILayout.EndVertical();
        }

        /// <summary>
        /// Paged-LoD readout plus the two controls that decide whether you are looking at real splats
        /// or merged stand-ins. Mirrored from the renderer inspector so the scene can be diagnosed
        /// without leaving the tool window.
        /// </summary>
        private static void DrawPagedLodControls(SplatBoxRenderer gs)
        {
            if (gs == null || !gs.UsesPagedLod)
                return;

            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("PAGED LOD", s_HeaderStyle);

            SplatBoxLodQualityGUI.DrawStats(gs);

            if (gs.lodSimpleMode)
            {
                EditorGUILayout.Space(2);
                SplatBoxLodQualityGUI.DrawQualitySlider(gs);
            }

            if (SplatBoxLodQualityGUI.DrawDiagnosis(gs, gs.lodPixelScaleLimit, gs.lodDetailScale, gs.lodSimpleMode))
                SplatBoxLodQualityGUI.RestoreFullQuality(gs);

            // The stand-in toggle is an Advanced-mode knob; Simple mode always draws stand-ins so
            // the whole scene stays visible, and showing a button that cannot take effect would
            // only confuse.
            if (!gs.lodSimpleMode)
            {
                EditorGUILayout.Space(2);
                bool drawStandIns = gs.drawsCoarseStandIns;
                GUI.backgroundColor = drawStandIns ? COL_SUCCESS : COL_WARNING;
                string label = drawStandIns
                    ? "Coarse Stand-ins: On (whole scene visible)"
                    : "Coarse Stand-ins: Off (real splats only)";
                if (GUILayout.Button(new GUIContent(label,
                        "Merged stand-in splats fill in pages held at coarse detail. Turn them off to draw " +
                        "only real splats: holes appear where detail is missing, but nothing is approximated."),
                    GUILayout.Height(22)))
                {
                    SplatBoxLodQualityGUI.SetDrawCoarseStandIns(gs, !drawStandIns);
                }
                GUI.backgroundColor = Color.white;
            }

            EditorGUILayout.Space(2);
            if (GUILayout.Button(new GUIContent("Reset LoD Settings",
                    "Restore Simple mode at Quality 0.5 and every Advanced knob to its field default."),
                GUILayout.Height(22)))
            {
                SplatBoxLodQualityGUI.ResetLodSettings(gs);
            }
        }

        static void ApplyRelightShaderToRenderer(SplatBoxRenderer renderer)
        {
            if (renderer == null) return;
            Shader shader = AssetDatabase.LoadAssetAtPath<Shader>("Resources/RenderSplatsRelight.shader");
            if (shader == null)
            {
                var guids = AssetDatabase.FindAssets("RenderSplatsRelight t:Shader");
                if (guids.Length > 0)
                    shader = AssetDatabase.LoadAssetAtPath<Shader>(AssetDatabase.GUIDToAssetPath(guids[0]));
            }
            if (shader == null)
            {
                var guids = AssetDatabase.FindAssets("RenderGaussianSplats t:Shader");
                foreach (var g in guids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(g);
                    if (path != null && path.IndexOf("Relight", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        shader = AssetDatabase.LoadAssetAtPath<Shader>(path);
                        break;
                    }
                }
            }
            if (shader == null) return;
            var so = new SerializedObject(renderer);
            var prop = so.FindProperty("m_ShaderSplats");
            if (prop == null) return;
            prop.objectReferenceValue = shader;
            var useRelightProp = so.FindProperty("m_UseRelightShader");
            if (useRelightProp != null)
                useRelightProp.boolValue = true;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(renderer);
            if (renderer.gameObject.scene.IsValid())
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(renderer.gameObject.scene);
            renderer.enabled = false;
            renderer.enabled = true;
            ScheduleRelightBufferRefresh();
        }

        static void ScheduleRelightBufferRefresh()
        {
            // Defer until after OnEnable finishes recreating relight materials.
            EditorApplication.delayCall += DeferredRelightBufferRefresh;
        }

        static void DeferredRelightBufferRefresh()
        {
            EditorApplication.delayCall -= DeferredRelightBufferRefresh;
            RefreshRelightLightBuffers();
            SceneView.RepaintAll();
        }

        static void RefreshRelightLightBuffers()
        {
            var mgrType = Type.GetType("GaussianSplatting.Relight.CustomLightManager, GaussianSplatting.SplatBox.Relight");
            var refresh = mgrType?.GetMethod("RefreshAllInScene", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
            refresh?.Invoke(null, null);
        }

        static void ApplyDefaultShaderToRenderer(SplatBoxRenderer renderer)
        {
            if (renderer == null) return;
            var guids = AssetDatabase.FindAssets("RenderGaussianSplats t:Shader");
            string defaultPath = null;
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                if (path != null && path.IndexOf("Relight", StringComparison.OrdinalIgnoreCase) < 0)
                { defaultPath = path; break; }
            }
            if (defaultPath == null) return;
            var shader = AssetDatabase.LoadAssetAtPath<Shader>(defaultPath);
            if (shader == null) return;
            var so = new SerializedObject(renderer);
            var prop = so.FindProperty("m_ShaderSplats");
            if (prop == null) return;
            prop.objectReferenceValue = shader;
            var useRelightProp = so.FindProperty("m_UseRelightShader");
            if (useRelightProp != null)
                useRelightProp.boolValue = false;
            so.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(renderer);
            if (renderer.gameObject.scene.IsValid())
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(renderer.gameObject.scene);
            renderer.enabled = false;
            renderer.enabled = true;
        }

        private void DrawToolbar()
        {
            EditorGUILayout.LabelField("TOOLS", s_HeaderStyle);
            
            // Row 1: Edit tools (5 buttons)
            EditorGUILayout.BeginHorizontal();
            DrawToolButton("🔴\nErase", BrushTool.EraseBrush, "Delete/Restore splats with spherical brush");
            DrawToolButton("🔷\nGeo Eraser", BrushTool.CylinderBrush, "Delete splats with cylinder or box primitives");
            DrawToolButton("📦\nXcopy", BrushTool.BoxBrush, "Copy/Paste/Delete with Box, Planar, or Paint selection");
            DrawToolButton("🔄\nClone", BrushTool.CloneBrush, "Clone splats from polygon source");
            DrawToolButton("🖌️\nFill", BrushTool.FillBrush, "Draw polygon and fill with splats");
            EditorGUILayout.EndHorizontal();
            
            // Row 2: More tools (5 buttons)
            EditorGUILayout.BeginHorizontal();
            // DrawToolButton("🔧\nPatch", BrushTool.PatchTool, "Multi-patch grid repair tool");
            DrawToolButton("✂️\nMask", BrushTool.PolyMask, "Polygon cutout mask tool");
            DrawToolButton("🎨\nColor", BrushTool.ColorBrush, "Adjust splat colors in box region");
            DrawToolButton("🌀\nVortex", BrushTool.VortexTool, "Vortex attractor effect");
            DrawToolButton("✏️\nPaint", BrushTool.PaintBrush, "Paint new splats by sampling colors");
            if (IsRelightPluginInstalled())
            {
                bool isRelightActive = EditorPrefs.GetBool("SplatBox.Relight.UseRelight", true);
                DrawUtilityButton("💡\nRelight", "Toggle Relight shader for custom lighting", isRelightActive, new Color(0.22f, 0.5f, 0.35f), () => {
                    bool useRelight = !EditorPrefs.GetBool("SplatBox.Relight.UseRelight", true);
                    EditorPrefs.SetBool("SplatBox.Relight.UseRelight", useRelight);
                    if (m_TargetRenderer != null)
                    {
                        if (useRelight)
                            ApplyRelightShaderToRenderer(m_TargetRenderer);
                        else
                            ApplyDefaultShaderToRenderer(m_TargetRenderer);
                    }
                });
            }
            EditorGUILayout.EndHorizontal();
            
            // Row 3: Paint & Effects (5 buttons to match rows above)
            EditorGUILayout.BeginHorizontal();
            DrawToolButton("🖼️\nStamp", BrushTool.TextureStamp, "Drag rect to stamp texture onto splats");
            DrawToolButton("🖐️\nSculpt", BrushTool.SculptBrush, "Sculpt brushes: Smudge and Pinch splats");
            DrawUtilityButton("🎥\nTilt", "Tilt-shift miniature effect", m_TiltShiftEnabled, new Color(0.6f, 0.3f, 0.7f), () => {
                bool wasEnabled = m_TiltShiftEnabled;
                m_TiltShiftEnabled = !m_TiltShiftEnabled;
                m_ShowTiltShift = m_TiltShiftEnabled;
                if (m_TiltShiftEnabled && !wasEnabled)
                {
                    m_BlurMode = 0;
                    m_TiltShiftFocusPosition = 0.5f;
                    m_TiltShiftFocusWidth = 0.05f;
                    m_TiltShiftAngle = 0f;
                    m_TiltShiftBlurStrength = 10f;
                    m_TiltShiftBlurSamples = 8;
                    m_TiltShiftBokehShape = 0.5f;
                    m_TiltShiftSaturation = 1f;
                    m_TiltShiftContrast = 1f;
                    m_TiltShiftVignette = 0.58f;
                    m_TiltShiftHighQuality = true;
                }
                ApplyTiltShiftToSceneView();
            });
            DrawUtilityButton("📥\nExport", "Export PLY file", m_ShowExport, COL_SUCCESS, () => m_ShowExport = !m_ShowExport);
            DrawUtilityButton("❓\nHelp", "Tool descriptions and shortcuts", m_ShowHelp, COL_ACCENT, () => m_ShowHelp = !m_ShowHelp);
            EditorGUILayout.EndHorizontal();
        }
        
        private void DrawToolButton(string label, BrushTool tool, string tooltip)
        {
            bool isActive = m_CurrentTool == tool;
            GUI.backgroundColor = isActive ? COL_ACCENT : Color.white;
            
            var style = isActive ? s_ActiveToolStyle : s_ToolButtonStyle;
            
            // Use ExpandWidth and MinWidth for responsive sizing
            if (GUILayout.Button(new GUIContent(label, tooltip), style, GUILayout.MinWidth(50), GUILayout.Height(42), GUILayout.ExpandWidth(true)))
            {
                if (m_CurrentTool == tool)
                {
                    DeactivateCurrentTool();
                    m_CurrentTool = BrushTool.None;
                }
                else
                {
                    DeactivateCurrentTool();
                    m_CurrentTool = tool;
                    
                    if (tool == BrushTool.BoxBrush && m_BoxBrush != null)
                        m_BoxBrush.ResetAll();
                    
                    if (tool == BrushTool.ColorBrush && m_ColorBrush != null)
                    {
                        m_ColorBrush.BoxSize = Vector3.one;
                        m_ColorBrush.BoxPosition = Vector3.zero;
                        m_ColorBrush.ResetColorAdjustments();
                    }
                }
            }
            GUI.backgroundColor = Color.white;
        }
        
        private void DrawUtilityButton(string label, string tooltip, bool isActive, Color activeColor, System.Action onClick)
        {
            GUI.backgroundColor = isActive ? activeColor : Color.white;
            if (GUILayout.Button(new GUIContent(label, tooltip), s_ToolButtonStyle, GUILayout.MinWidth(50), GUILayout.Height(42), GUILayout.ExpandWidth(true)))
                onClick?.Invoke();
            GUI.backgroundColor = Color.white;
        }

        private void DrawToolSettings()
        {
            if (m_CurrentTool == BrushTool.None)
            {
                EditorGUILayout.HelpBox("Select a tool from the toolbar above.", MessageType.Info);
                return;
            }
            
            string toolSettingsTitle = m_CurrentTool == BrushTool.CylinderBrush
                ? "Geo Brush Settings"
                : m_CurrentTool == BrushTool.BoxBrush
                    ? "Xcopy Settings"
                    : $"{m_CurrentTool} Settings";
            m_ShowToolSettings = DrawFoldoutHeader(toolSettingsTitle, m_ShowToolSettings, COL_ACCENT);
            
            if (!m_ShowToolSettings) return;
            
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            switch (m_CurrentTool)
            {
                case BrushTool.EraseBrush:
                    DrawEraseBrushSettings();
                    break;
                case BrushTool.BoxBrush:
                    DrawBoxBrushSettings();
                    break;
                case BrushTool.CloneBrush:
                    DrawCloneBrushSettings();
                    break;
                case BrushTool.FloorFill:
                    DrawFloorFillSettings();
                    break;
                case BrushTool.PatchTool:
                    DrawPatchToolSettings();
                    break;
                case BrushTool.PolyMask:
                    DrawPolyMaskSettings();
                    break;
                case BrushTool.ColorBrush:
                    DrawColorBrushSettings();
                    break;
                case BrushTool.VortexTool:
                    DrawVortexToolSettings();
                    break;
                case BrushTool.FillBrush:
                    DrawFillBrushSettings();
                    break;
                case BrushTool.PaintBrush:
                    DrawPaintBrushSettings();
                    break;
                case BrushTool.CylinderBrush:
                    DrawCylinderBrushSettings();
                    break;
                case BrushTool.TextureStamp:
                    DrawTextureStampSettings();
                    break;
                case BrushTool.SculptBrush:
                    DrawSculptBrushSettings();
                    break;
            }
            
            EditorGUILayout.EndVertical();
        }
        
        private void DrawSculptBrushSettings()
        {
            EditorGUILayout.LabelField("Sculpt Brushes", EditorStyles.boldLabel);
            
            // Tab selection - Row 1
            // Tab selection - Row 1
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = m_SculptBrushTab == 0 ? COL_ACCENT : Color.white;
            if (GUILayout.Button("👆 Smudge", GUILayout.Height(26)))
                m_SculptBrushTab = 0;
            GUI.backgroundColor = m_SculptBrushTab == 1 ? COL_ACCENT : Color.white;
            if (GUILayout.Button("🤏 Pinch", GUILayout.Height(26)))
                m_SculptBrushTab = 1;
            GUI.backgroundColor = m_SculptBrushTab == 2 ? COL_ACCENT : Color.white;
            if (GUILayout.Button("✋ Move", GUILayout.Height(26)))
                m_SculptBrushTab = 2;
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            // Tab selection - Row 2
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = m_SculptBrushTab == 3 ? COL_ACCENT : Color.white;
            if (GUILayout.Button("📐 Flatten", GUILayout.Height(26)))
                m_SculptBrushTab = 3;
            GUI.backgroundColor = m_SculptBrushTab == 4 ? COL_ACCENT : Color.white;
            if (GUILayout.Button("🌊 Relax", GUILayout.Height(26)))
                m_SculptBrushTab = 4;
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(4);
            
            switch (m_SculptBrushTab)
            {
                case 0:
                    DrawSmudgeTabSettings();
                    break;
                case 1:
                    DrawPinchTabSettings();
                    break;
                case 2:
                    DrawMoveTabSettings();
                    break;
                case 3:
                    DrawFlattenTabSettings();
                    break;
                case 4:
                    DrawRelaxTabSettings();
                    break;
            }
            
            EditorGUILayout.Space();
            string controls;
            switch (m_SculptBrushTab)
            {
                case 2:
                    controls = "DRAG = Move | SHIFT = Straight | ALT = Restore | SCROLL = Resize";
                    break;
                case 3:
                    controls = "DRAG = Flatten | ALT = Restore | SCROLL = Resize";
                    break;
                case 4:
                    controls = "DRAG = Relax | SHIFT = Roughen | ALT = Restore | SCROLL = Resize";
                    break;
                default:
                    controls = "DRAG = Sculpt | SHIFT = Pinch | ALT = Restore | SCROLL = Resize";
                    break;
            }
            DrawToolControls(controls);
        }
        
        private void DrawSmudgeTabSettings()
        {
            EditorGUILayout.HelpBox("Drag to push and smudge splats in the direction of your stroke.", MessageType.Info);
            
            EditorGUILayout.LabelField("Brush Settings", EditorStyles.boldLabel);
            m_SmudgeRadius = EditorGUILayout.Slider("Brush Size", m_SmudgeRadius, 0.5f, 25f);
            m_SmudgeStrength = EditorGUILayout.Slider("Strength", m_SmudgeStrength, 0.1f, 2f);
            m_SmudgeFalloff = EditorGUILayout.Slider("Falloff", m_SmudgeFalloff, 0f, 1f);
            m_SmudgeBlendColors = EditorGUILayout.Toggle("Blend Colors", m_SmudgeBlendColors);
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Tips", EditorStyles.miniLabel);
            EditorGUILayout.HelpBox("• Lower falloff = sharper edge\n• Higher strength = more movement\n• Blend Colors mixes colors as splats move", MessageType.None);
        }
        
        private void DrawPinchTabSettings()
        {
            EditorGUILayout.HelpBox("Drag to pull splats toward the brush center. Use SHIFT while using Smudge to quick-pinch.", MessageType.Info);
            
            EditorGUILayout.LabelField("Brush Settings", EditorStyles.boldLabel);
            m_PinchRadius = EditorGUILayout.Slider("Brush Size", m_PinchRadius, 0.5f, 25f);
            m_PinchStrength = EditorGUILayout.Slider("Strength", m_PinchStrength, 0.05f, 1f);
            m_PinchFalloff = EditorGUILayout.Slider("Falloff", m_PinchFalloff, 0f, 1f);
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Tips", EditorStyles.miniLabel);
            EditorGUILayout.HelpBox("• Great for tightening loose edges\n• Use with low strength for subtle adjustments\n• Hold SHIFT in Smudge mode for quick access", MessageType.None);
        }
        
        private void DrawMoveTabSettings()
        {
            EditorGUILayout.HelpBox("Gently move splats in the direction of your stroke. Hold SHIFT to constrain to a straight line.", MessageType.Info);
            
            EditorGUILayout.LabelField("Brush Settings", EditorStyles.boldLabel);
            m_MoveRadius = EditorGUILayout.Slider("Brush Size", m_MoveRadius, 0.5f, 25f);
            m_MoveStrength = EditorGUILayout.Slider("Strength", m_MoveStrength, 0.05f, 1f);
            m_MoveFalloff = EditorGUILayout.Slider("Falloff", m_MoveFalloff, 0f, 1f);
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Tips", EditorStyles.miniLabel);
            EditorGUILayout.HelpBox("• Gentler than Smudge for precise adjustments\n• Hold SHIFT to lock movement to a straight line\n• Great for aligning edges and surfaces", MessageType.None);
        }
        
        private void DrawFlattenTabSettings()
        {
            EditorGUILayout.HelpBox("Flatten splats to create smooth, flat surfaces. Drag in the direction you want to flatten toward.", MessageType.Info);
            
            EditorGUILayout.LabelField("Brush Settings", EditorStyles.boldLabel);
            m_FlattenRadius = EditorGUILayout.Slider("Brush Size", m_FlattenRadius, 1f, 25f);
            m_FlattenStrength = EditorGUILayout.Slider("Strength", m_FlattenStrength, 0.05f, 1f);
            m_FlattenFalloff = EditorGUILayout.Slider("Falloff", m_FlattenFalloff, 0f, 1f);
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Tips", EditorStyles.miniLabel);
            EditorGUILayout.HelpBox("• Drag to establish the flatten direction\n• The flatten plane is perpendicular to brush movement\n• Great for creating walls, floors, and flat surfaces\n• Use large radius for broad flattening", MessageType.None);
        }
        
        private void DrawRelaxTabSettings()
        {
            EditorGUILayout.HelpBox("Smooth out splats by averaging their positions with neighbors. Hold SHIFT to invert (roughen/scatter).", MessageType.Info);
            
            EditorGUILayout.LabelField("Brush Settings", EditorStyles.boldLabel);
            m_RelaxRadius = EditorGUILayout.Slider("Brush Size", m_RelaxRadius, 0.5f, 25f);
            m_RelaxStrength = EditorGUILayout.Slider("Strength", m_RelaxStrength, 0.05f, 1f);
            m_RelaxFalloff = EditorGUILayout.Slider("Falloff", m_RelaxFalloff, 0f, 1f);
            m_RelaxNeighborRadius = EditorGUILayout.Slider("Neighbor Search", m_RelaxNeighborRadius, 0.1f, 1f);
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Tips", EditorStyles.miniLabel);
            EditorGUILayout.HelpBox("• Drag to continuously relax/smooth splats\n• Hold SHIFT to roughen/scatter instead\n• Higher strength = faster effect\n• Neighbor Search controls averaging range\n• Great for smoothing noise or adding detail", MessageType.None);
        }
        
        private void DrawColorizeModeSettings()
        {
            if (m_ColorizeBrush == null) { CreateToolGameObject(BrushTool.ColorizeBrush); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Colorize Brush Parameters", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            float newRadius = EditorGUILayout.Slider("Brush Size", m_ColorizeBrush.ScreenRadius, 0.1f, 10f);
            float newStrength = EditorGUILayout.Slider("Blend Strength", m_ColorizeBrush.BlendStrength, 0.01f, 1f);
            float newFalloff = EditorGUILayout.Slider("Falloff", m_ColorizeBrush.Falloff, 0f, 1f);
            Color newColor = EditorGUILayout.ColorField("Target Color", m_ColorizeBrush.TargetColor);
            var newBlendMode = (ColorizeBlendMode)EditorGUILayout.EnumPopup("Blend Mode", m_ColorizeBrush.BlendMode);
            float newBlendModeIntensity = EditorGUILayout.Slider("Blend Mode Intensity", m_ColorizeBrush.BlendModeIntensity, 0f, 1f);
            
            EditorGUILayout.Space(5);
            bool newUseNoise = EditorGUILayout.Toggle("Use Noise", m_ColorizeBrush.UseNoise);
            float newNoiseStrength = m_ColorizeBrush.NoiseStrength;
            float newNoiseScale = m_ColorizeBrush.NoiseScale;
            if (newUseNoise)
            {
                EditorGUI.indentLevel++;
                newNoiseStrength = EditorGUILayout.Slider("Noise Strength", m_ColorizeBrush.NoiseStrength, 0f, 1f);
                newNoiseScale = EditorGUILayout.Slider("Noise Scale", m_ColorizeBrush.NoiseScale, 0.1f, 10f);
                EditorGUI.indentLevel--;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorizeBrush, "Change Colorize Brush Settings");
                m_ColorizeBrush.ScreenRadius = newRadius;
                m_ColorizeBrush.BlendStrength = newStrength;
                m_ColorizeBrush.Falloff = newFalloff;
                m_ColorizeBrush.TargetColor = newColor;
                m_ColorizeBrush.BlendMode = newBlendMode;
                m_ColorizeBrush.BlendModeIntensity = newBlendModeIntensity;
                m_ColorizeBrush.UseNoise = newUseNoise;
                m_ColorizeBrush.NoiseStrength = newNoiseStrength;
                m_ColorizeBrush.NoiseScale = newNoiseScale;
                EditorUtility.SetDirty(m_ColorizeBrush);
            }
            
            EditorGUILayout.Space();
            
            // Color preview swatch
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Current Color:", GUILayout.Width(90));
            var colorRect = GUILayoutUtility.GetRect(40, 20);
            EditorGUI.DrawRect(colorRect, m_ColorizeBrush.TargetColor);
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            
            // Undo/Redo controls
            EditorGUILayout.LabelField("Stroke History", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            GUI.enabled = m_ColorizeBrush.CanUndo;
            if (GUILayout.Button($"◀ Undo ({m_ColorizeBrush.UndoCount})", GUILayout.Height(24)))
            {
                m_ColorizeBrush.Undo();
                SceneView.RepaintAll();
            }
            GUI.enabled = m_ColorizeBrush.CanRedo;
            if (GUILayout.Button($"Redo ({m_ColorizeBrush.RedoCount}) ▶", GUILayout.Height(24)))
            {
                m_ColorizeBrush.Redo();
                SceneView.RepaintAll();
            }
            GUI.enabled = true;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginChangeCheck();
            int newMaxUndo = EditorGUILayout.IntSlider("Max Undo Steps", m_ColorizeBrush.MaxUndoSteps, 5, 50);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorizeBrush, "Change Max Undo Steps");
                m_ColorizeBrush.MaxUndoSteps = newMaxUndo;
                EditorUtility.SetDirty(m_ColorizeBrush);
            }
            EditorGUILayout.EndHorizontal();
            
            if (m_ColorizeBrush.UndoCount > 0 || m_ColorizeBrush.RedoCount > 0)
            {
                if (GUILayout.Button("Clear History"))
                {
                    m_ColorizeBrush.ClearUndoHistory();
                }
            }
            
            EditorGUILayout.Space();
            DrawToolControls("LMB = Colorize | RMB = Sample | Ctrl+Z/Y = Undo/Redo");
        }
        
        private void DrawAnimationPaintSettings()
        {
            EditorGUILayout.LabelField("Animation Paint", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Paint strokes to add velocity animation to splats.", MessageType.Info);
            
            EditorGUILayout.Space(5);
            
            // Animation style
            m_AnimPaintStyle = (AnimationPaintStyle)EditorGUILayout.EnumPopup("Animation Style", m_AnimPaintStyle);
            
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Brush Settings", EditorStyles.boldLabel);
            m_AnimPaintRadius = EditorGUILayout.Slider("Brush Radius", m_AnimPaintRadius, 0.5f, 20f);
            m_AnimPaintVelocity = EditorGUILayout.Slider("Velocity Strength", m_AnimPaintVelocity, 0.01f, 2f);
            m_AnimPaintSpeed = EditorGUILayout.Slider("Animation Speed", m_AnimPaintSpeed, 0.1f, 5f);
            
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Direction", EditorStyles.boldLabel);
            m_AnimPaintUseManualDirection = EditorGUILayout.Toggle("Use Manual Direction", m_AnimPaintUseManualDirection);
            if (m_AnimPaintUseManualDirection)
            {
                EditorGUI.indentLevel++;
                m_AnimPaintManualDirection = EditorGUILayout.Vector3Field("Flow Direction", m_AnimPaintManualDirection);
                if (m_AnimPaintManualDirection.sqrMagnitude > 0.001f)
                    m_AnimPaintManualDirection = m_AnimPaintManualDirection.normalized;
                
                // Quick direction buttons
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("+X")) m_AnimPaintManualDirection = Vector3.right;
                if (GUILayout.Button("-X")) m_AnimPaintManualDirection = Vector3.left;
                if (GUILayout.Button("+Z")) m_AnimPaintManualDirection = Vector3.forward;
                if (GUILayout.Button("-Z")) m_AnimPaintManualDirection = Vector3.back;
                EditorGUILayout.EndHorizontal();
                EditorGUI.indentLevel--;
            }
            else
            {
                EditorGUILayout.HelpBox("Direction follows brush stroke", MessageType.None);
            }
            
            EditorGUILayout.Space(5);
            m_AnimPaintDisableGravity = EditorGUILayout.Toggle("Disable Gravity", m_AnimPaintDisableGravity);
            if (m_AnimPaintDisableGravity)
            {
                EditorGUILayout.HelpBox("Splats will flow horizontally without falling", MessageType.None);
            }
            
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Noise", EditorStyles.boldLabel);
            m_AnimPaintNoiseStrength = EditorGUILayout.Slider("Noise Strength", m_AnimPaintNoiseStrength, 0f, 1f);
            m_AnimPaintNoiseScale = EditorGUILayout.Slider("Noise Scale", m_AnimPaintNoiseScale, 0.1f, 10f);
            
            EditorGUILayout.Space(5);
            m_AnimPaintShowOverlay = EditorGUILayout.Toggle("Show Brush Overlay", m_AnimPaintShowOverlay);
            
            EditorGUILayout.Space();
            
            // Status
            if (m_AnimPaintActive)
            {
                GUI.color = COL_CYAN;
                EditorGUILayout.LabelField("🌊 PAINTING ANIMATION", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            
            // Style-specific info
            string styleInfo = m_AnimPaintStyle switch
            {
                AnimationPaintStyle.River => "River: Splats flow in direction",
                AnimationPaintStyle.Whirlpool => "Whirlpool: Splats spiral around center",
                AnimationPaintStyle.Wave => "Wave: Splats oscillate perpendicular",
                AnimationPaintStyle.RandomLeaves => "Leaves: Chaotic turbulent drift",
                _ => ""
            };
            EditorGUILayout.HelpBox(styleInfo, MessageType.None);
            
            EditorGUILayout.Space();
            
            // Clear animation buttons
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = new Color(1f, 0.6f, 0.3f);
            if (GUILayout.Button("Clear Velocities", GUILayout.Height(28)))
            {
                if (m_TargetRenderer != null)
                {
                    m_TargetRenderer.ClearAllVelocities();
                    SceneView.RepaintAll();
                }
            }
            GUI.backgroundColor = new Color(0.6f, 0.8f, 1f);
            if (GUILayout.Button("Reset Gravity", GUILayout.Height(28)))
            {
                if (m_TargetRenderer != null)
                {
                    m_TargetRenderer.ClearAllAnimationFlags();
                    SceneView.RepaintAll();
                }
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(10);
            
            // Animation Recording/Playback Section
            DrawAnimationRecorderUI();
            
            EditorGUILayout.Space();
            DrawToolControls("LMB = Paint | SPACE = Play/Pause | R = Record | [ ] = Step");
        }
        
        private void EnsureAnimRecorder()
        {
            if (m_AnimRecorder == null && m_TargetRenderer != null)
            {
                m_AnimRecorder = m_TargetRenderer.GetComponent<GaussianSplatAnimationRecorder>();
                if (m_AnimRecorder == null)
                {
                    m_AnimRecorder = m_TargetRenderer.gameObject.AddComponent<GaussianSplatAnimationRecorder>();
                    m_AnimRecorder.TargetRenderer = m_TargetRenderer;
                }
            }
        }
        
        private void DrawAnimationRecorderUI()
        {
            m_ShowAnimRecorder = EditorGUILayout.BeginFoldoutHeaderGroup(m_ShowAnimRecorder, "🎬 Animation Recording");
            
            if (m_ShowAnimRecorder)
            {
                EnsureAnimRecorder();
                
                if (m_AnimRecorder == null)
                {
                    EditorGUILayout.HelpBox("Select a SplatBoxRenderer to enable recording", MessageType.Info);
                    EditorGUILayout.EndFoldoutHeaderGroup();
                    return;
                }
                
                EditorGUILayout.Space(5);
                
                // Recording Settings
                EditorGUILayout.LabelField("Recording Settings", EditorStyles.boldLabel);
                m_AnimRecordFPS = EditorGUILayout.Slider("Record FPS", m_AnimRecordFPS, 10f, 60f);
                m_AnimMaxDuration = EditorGUILayout.Slider("Max Duration (s)", m_AnimMaxDuration, 5f, 120f);
                
                m_AnimRecorder.RecordFPS = m_AnimRecordFPS;
                m_AnimRecorder.MaxRecordDuration = m_AnimMaxDuration;
                
                // Memory usage estimate
                if (m_TargetRenderer != null && m_TargetRenderer.splatCount > 0 && !m_AnimRecorder.IsRecording)
                {
                    int splatCount = m_TargetRenderer.splatCount;
                    int estKeyframes = Mathf.CeilToInt(m_AnimMaxDuration * m_AnimRecordFPS);
                    long estBytes = (long)splatCount * 12 * estKeyframes;
                    string memStr = estBytes < 1024 * 1024 
                        ? $"{estBytes / 1024f:F1} KB" 
                        : $"{estBytes / (1024f * 1024f):F1} MB";
                    
                    if (estBytes > 500 * 1024 * 1024) // > 500MB
                        EditorGUILayout.HelpBox($"⚠ High memory: ~{memStr} for {splatCount:N0} splats × {estKeyframes} frames", MessageType.Warning);
                    else
                        EditorGUILayout.LabelField($"Est. memory: ~{memStr} ({splatCount:N0} splats)", EditorStyles.miniLabel);
                }
                
                EditorGUILayout.Space(5);
                
                // Recording Controls
                EditorGUILayout.BeginHorizontal();
                
                if (m_AnimRecorder.IsRecording)
                {
                    GUI.backgroundColor = new Color(1f, 0.3f, 0.3f);
                    if (GUILayout.Button("⏹ Stop Recording", GUILayout.Height(30)))
                    {
                        m_AnimRecorder.StopRecording();
                    }
                    GUI.backgroundColor = Color.white;
                    
                    // Show recording time
                    float elapsed = Time.realtimeSinceStartup - Time.time + m_AnimRecorder.PlaybackTime;
                    EditorGUILayout.LabelField($"⏺ Recording... {m_AnimRecorder.KeyframeCount} frames", 
                        EditorStyles.boldLabel, GUILayout.Width(150));
                }
                else
                {
                    GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
                    if (GUILayout.Button("⏺ Start Recording", GUILayout.Height(30)))
                    {
                        m_AnimRecorder.StartRecording();
                    }
                    GUI.backgroundColor = Color.white;
                }
                
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.Space(10);
                
                // Playback Section (only if we have a clip)
                if (m_AnimRecorder.HasClip)
                {
                    EditorGUILayout.LabelField("Playback Controls", EditorStyles.boldLabel);
                    
                    // Clip info
                    EditorGUILayout.LabelField($"Clip: {m_AnimRecorder.ClipDuration:F2}s | {m_AnimRecorder.KeyframeCount} keyframes | {m_AnimRecorder.GetClipMemoryUsageString()}", 
                        EditorStyles.miniLabel);
                    
                    EditorGUILayout.Space(3);
                    
                    // Playback Settings
                    EditorGUILayout.BeginHorizontal();
                    m_AnimPlaybackSpeed = EditorGUILayout.Slider("Speed", m_AnimPlaybackSpeed, 0.1f, 5f);
                    m_AnimRecorder.PlaybackSpeed = m_AnimPlaybackSpeed;
                    EditorGUILayout.EndHorizontal();
                    
                    EditorGUILayout.BeginHorizontal();
                    m_AnimLoop = EditorGUILayout.Toggle("Loop", m_AnimLoop, GUILayout.Width(60));
                    m_AnimPingPong = EditorGUILayout.Toggle("Ping-Pong", m_AnimPingPong, GUILayout.Width(90));
                    m_AnimRecorder.Loop = m_AnimLoop;
                    m_AnimRecorder.PingPong = m_AnimPingPong;
                    EditorGUILayout.EndHorizontal();
                    
                    EditorGUILayout.Space(5);
                    
                    // Timeline Scrubber
                    EditorGUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField($"{m_AnimRecorder.PlaybackTime:F2}s", GUILayout.Width(50));
                    
                    EditorGUI.BeginChangeCheck();
                    float progress = EditorGUILayout.Slider(m_AnimRecorder.PlaybackProgress, 0f, 1f);
                    if (EditorGUI.EndChangeCheck())
                    {
                        m_AnimRecorder.SeekToNormalized(progress);
                    }
                    
                    EditorGUILayout.LabelField($"{m_AnimRecorder.ClipDuration:F2}s", GUILayout.Width(50));
                    EditorGUILayout.EndHorizontal();
                    
                    EditorGUILayout.Space(3);
                    
                    // Transport Controls
                    EditorGUILayout.BeginHorizontal();
                    
                    // Step backward
                    if (GUILayout.Button("⏮", GUILayout.Width(35), GUILayout.Height(28)))
                    {
                        m_AnimRecorder.SeekTo(0f);
                    }
                    
                    // Frame backward
                    if (GUILayout.Button("◀◀", GUILayout.Width(35), GUILayout.Height(28)))
                    {
                        m_AnimRecorder.StepFrame(false);
                    }
                    
                    // Play/Pause
                    if (m_AnimRecorder.IsPlaying)
                    {
                        if (m_AnimRecorder.IsPaused)
                        {
                            GUI.backgroundColor = new Color(0.4f, 0.9f, 0.4f);
                            if (GUILayout.Button("▶ Resume", GUILayout.Height(28)))
                            {
                                m_AnimRecorder.Resume();
                            }
                        }
                        else
                        {
                            GUI.backgroundColor = new Color(1f, 0.8f, 0.3f);
                            if (GUILayout.Button("⏸ Pause", GUILayout.Height(28)))
                            {
                                m_AnimRecorder.Pause();
                            }
                        }
                        GUI.backgroundColor = Color.white;
                    }
                    else
                    {
                        GUI.backgroundColor = new Color(0.4f, 0.9f, 0.4f);
                        if (GUILayout.Button("▶ Play", GUILayout.Height(28)))
                        {
                            m_AnimRecorder.StartPlayback();
                        }
                        GUI.backgroundColor = Color.white;
                    }
                    
                    // Frame forward
                    if (GUILayout.Button("▶▶", GUILayout.Width(35), GUILayout.Height(28)))
                    {
                        m_AnimRecorder.StepFrame(true);
                    }
                    
                    // Go to end
                    if (GUILayout.Button("⏭", GUILayout.Width(35), GUILayout.Height(28)))
                    {
                        m_AnimRecorder.SeekTo(m_AnimRecorder.ClipDuration);
                    }
                    
                    EditorGUILayout.EndHorizontal();
                    
                    EditorGUILayout.Space(3);
                    
                    // Additional controls
                    EditorGUILayout.BeginHorizontal();
                    
                    // Reverse toggle
                    GUI.backgroundColor = new Color(0.7f, 0.7f, 1f);
                    if (GUILayout.Button("⟲ Reverse", GUILayout.Height(24)))
                    {
                        m_AnimRecorder.ToggleReverse();
                    }
                    GUI.backgroundColor = Color.white;
                    
                    // Stop and restore
                    if (m_AnimRecorder.IsPlaying)
                    {
                        GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
                        if (GUILayout.Button("⏹ Stop", GUILayout.Height(24)))
                        {
                            m_AnimRecorder.StopPlayback(false);
                        }
                        GUI.backgroundColor = Color.white;
                    }
                    
                    // Clear clip
                    GUI.backgroundColor = new Color(0.8f, 0.6f, 0.6f);
                    if (GUILayout.Button("🗑 Clear Clip", GUILayout.Height(24)))
                    {
                        if (EditorUtility.DisplayDialog("Clear Animation Clip", 
                            "Are you sure you want to clear the recorded animation?", "Yes", "Cancel"))
                        {
                            m_AnimRecorder.ClearClip();
                        }
                    }
                    GUI.backgroundColor = Color.white;
                    
                    EditorGUILayout.EndHorizontal();
                }
                else
                {
                    EditorGUILayout.HelpBox("No recording yet. Paint some animation and click 'Start Recording' to capture it.", MessageType.Info);
                }
            }
            
            EditorGUILayout.EndFoldoutHeaderGroup();
        }

        private void DrawTextureStampSettings()
        {
            EditorGUILayout.LabelField("Texture Stamp Tool", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Drag in scene to define a rectangle. Texture will be UV-mapped onto the stamp area.", MessageType.Info);
            
            // Texture slot selection (reuses PaintBrush slots)
            if (m_PaintBrush == null) 
            { 
                CreateToolGameObject(BrushTool.PaintBrush); 
                EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel);
                return; 
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Texture Slot", EditorStyles.boldLabel);
            
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Active:", GUILayout.Width(50));
            for (int i = 0; i < 3; i++)
            {
                bool hasTexture = m_PaintBrush.HasTextureInSlot(i);
                bool isActive = m_StampActiveSlot == i;
                
                GUI.backgroundColor = isActive ? COL_ACCENT : (hasTexture ? COL_SUCCESS : Color.gray);
                if (GUILayout.Button($"{i + 1}{(hasTexture ? " ✓" : "")}", GUILayout.Width(40)))
                    m_StampActiveSlot = i;
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            // Preview texture
            var activeTex = m_PaintBrush.GetTextureSlot(m_StampActiveSlot);
            if (activeTex != null)
            {
                EditorGUILayout.BeginHorizontal();
                GUILayout.FlexibleSpace();
                var previewRect = GUILayoutUtility.GetRect(80, 80, GUILayout.Width(80));
                EditorGUI.DrawPreviewTexture(previewRect, activeTex);
                GUILayout.FlexibleSpace();
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.LabelField($"{activeTex.width}x{activeTex.height}", EditorStyles.centeredGreyMiniLabel);
            }
            else
            {
                GUI.color = COL_WARNING;
                EditorGUILayout.LabelField("No texture - Use Paint tool to capture first", EditorStyles.centeredGreyMiniLabel);
                GUI.color = Color.white;
                
                if (GUILayout.Button("Open Paint Tool to Capture"))
                {
                    SelectTool(BrushTool.PaintBrush);
                }
                return;
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Stamp Parameters", EditorStyles.boldLabel);
            
            m_StampResolution = EditorGUILayout.IntSlider("Resolution", m_StampResolution, 8, 512);
            EditorGUILayout.HelpBox($"Grid: ~{m_StampResolution}x{m_StampResolution} = {m_StampResolution * m_StampResolution} splats max", MessageType.None);
            
            m_StampAutoSize = EditorGUILayout.Toggle("Auto Splat Size", m_StampAutoSize);
            if (!m_StampAutoSize)
            {
                m_StampSplatSizeMultiplier = EditorGUILayout.Slider("Splat Size Mult", m_StampSplatSizeMultiplier, 0.5f, 3f);
            }
            else
            {
                m_StampSplatSizeMultiplier = EditorGUILayout.Slider("Size Overlap", m_StampSplatSizeMultiplier, 0.8f, 2f);
                EditorGUILayout.HelpBox("1.0 = exact fit, >1 = overlap for solid fill", MessageType.None);
            }
            m_StampDensity = EditorGUILayout.Slider("Opacity", m_StampDensity, 0.1f, 2f);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Blend Mode", EditorStyles.boldLabel);
            m_StampBlendMode = (StampBlendMode)EditorGUILayout.EnumPopup("Mode", m_StampBlendMode);
            if (m_StampBlendMode != StampBlendMode.Replace)
            {
                EditorGUILayout.HelpBox("Blends texture with existing splat colors in stamp area", MessageType.None);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Layering", EditorStyles.boldLabel);
            
            m_StampLayeringEnabled = EditorGUILayout.Toggle("Enable Layering", m_StampLayeringEnabled);
            if (m_StampLayeringEnabled)
            {
                m_StampLayerSpacing = EditorGUILayout.Slider("Layer Spacing", m_StampLayerSpacing, 0.001f, 0.1f);
                EditorGUILayout.LabelField($"Current Layer: {m_StampCurrentLayer}", EditorStyles.miniLabel);
                if (GUILayout.Button("Reset Layers"))
                {
                    m_StampCurrentLayer = 0;
                }
            }
            
            EditorGUILayout.Space();
            
            // Show drag status
            if (m_IsDraggingStamp)
            {
                GUI.color = COL_CYAN;
                EditorGUILayout.LabelField("Dragging... release to stamp", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            
            DrawToolControls("DRAG = Define stamp rect | ESC = Cancel");
        }

        private void DrawCylinderBrushSettings()
        {
            if (m_CylinderBrush == null) { CreateToolGameObject(BrushTool.CylinderBrush); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Primitive Type", EditorStyles.boldLabel);
            EditorGUI.BeginChangeCheck();
            var newType = (PrimitiveBrushType)EditorGUILayout.EnumPopup("Type", m_CylinderBrush.PrimitiveType);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_CylinderBrush, "Change Primitive Type");
                m_CylinderBrush.PrimitiveType = newType;
                EditorUtility.SetDirty(m_CylinderBrush);
            }
            
            EditorGUILayout.Space();
            
            if (m_CylinderBrush.PrimitiveType == PrimitiveBrushType.Cylinder)
            {
                EditorGUILayout.LabelField("Cylinder Parameters", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                float newRadius = EditorGUILayout.FloatField("Radius", m_CylinderBrush.Radius);
                float newHeight = EditorGUILayout.FloatField("Height", m_CylinderBrush.Height);
                Vector3 newPos = EditorGUILayout.Vector3Field("Position", m_CylinderBrush.Position);
                Vector3 eulerAngles = m_CylinderBrush.Rotation.eulerAngles;
                Vector3 newEuler = EditorGUILayout.Vector3Field("Rotation", eulerAngles);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_CylinderBrush, "Change Cylinder Settings");
                    m_CylinderBrush.Radius = newRadius;
                    m_CylinderBrush.Height = newHeight;
                    m_CylinderBrush.Position = newPos;
                    m_CylinderBrush.Rotation = Quaternion.Euler(newEuler);
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Visualization", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Color cylColor = EditorGUILayout.ColorField("Cylinder Color", m_CylinderBrush.CylinderColor);
                float cylAlpha = EditorGUILayout.Slider("Transparency", m_CylinderBrush.CylinderAlpha, 0.05f, 0.5f);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_CylinderBrush, "Change Cylinder Visualization");
                    m_CylinderBrush.CylinderColor = cylColor;
                    m_CylinderBrush.CylinderAlpha = cylAlpha;
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                
                // Action buttons
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = COL_DANGER;
                if (GUILayout.Button("Delete", GUILayout.Height(28)))
                    m_CylinderBrush.DeleteSplatsInCylinder();
                
                GUI.backgroundColor = new Color(0.5f, 0.8f, 1f);
                if (GUILayout.Button("Restore", GUILayout.Height(28)))
                    m_CylinderBrush.RestoreSplatsInCylinder();
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                if (GUILayout.Button("Reset Cylinder"))
                {
                    Undo.RecordObject(m_CylinderBrush, "Reset Cylinder");
                    m_CylinderBrush.ResetCylinder();
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                DrawToolControls("1=Move | 2=Rotate | 3=Scale | Del=Delete | Shift+R=Restore | WASD=Navigate");
            }
            else if (m_CylinderBrush.PrimitiveType == PrimitiveBrushType.Box)
            {
                EditorGUILayout.LabelField("Box Parameters", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Vector3 newPos = EditorGUILayout.Vector3Field("Position", m_CylinderBrush.Position);
                Vector3 newBoxSize = EditorGUILayout.Vector3Field("Box Size", m_CylinderBrush.BoxSize);
                Vector3 eulerAngles = m_CylinderBrush.Rotation.eulerAngles;
                Vector3 newEuler = EditorGUILayout.Vector3Field("Rotation", eulerAngles);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_CylinderBrush, "Change Box Settings");
                    m_CylinderBrush.Position = newPos;
                    m_CylinderBrush.BoxSize = newBoxSize;
                    m_CylinderBrush.Rotation = Quaternion.Euler(newEuler);
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Visualization", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Color boxColor = EditorGUILayout.ColorField("Box Color", m_CylinderBrush.CylinderColor);
                float boxAlpha = EditorGUILayout.Slider("Transparency", m_CylinderBrush.CylinderAlpha, 0.05f, 0.5f);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_CylinderBrush, "Change Box Visualization");
                    m_CylinderBrush.CylinderColor = boxColor;
                    m_CylinderBrush.CylinderAlpha = boxAlpha;
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                
                // Action buttons
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = COL_DANGER;
                if (GUILayout.Button("Delete", GUILayout.Height(28)))
                    m_CylinderBrush.DeleteSplatsInBox();
                
                GUI.backgroundColor = new Color(0.5f, 0.8f, 1f);
                if (GUILayout.Button("Restore", GUILayout.Height(28)))
                    m_CylinderBrush.RestoreSplatsInBox();
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                if (GUILayout.Button("Reset Box"))
                {
                    Undo.RecordObject(m_CylinderBrush, "Reset Box");
                    m_CylinderBrush.ResetBox();
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                DrawToolControls("1=Move | 2=Rotate | 3=Scale | Del=Delete | Shift+R=Restore | WASD=Navigate");
            }
            else // Sphere mode
            {
                EditorGUILayout.LabelField("Sphere Parameters", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Vector3 newPos = EditorGUILayout.Vector3Field("Position", m_CylinderBrush.Position);
                float newSphereRadius = EditorGUILayout.FloatField("Radius", m_CylinderBrush.SphereRadius);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_CylinderBrush, "Change Sphere Settings");
                    m_CylinderBrush.Position = newPos;
                    m_CylinderBrush.SphereRadius = newSphereRadius;
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Visualization", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Color sphereColor = EditorGUILayout.ColorField("Sphere Color", m_CylinderBrush.CylinderColor);
                float sphereAlpha = EditorGUILayout.Slider("Transparency", m_CylinderBrush.CylinderAlpha, 0.05f, 0.5f);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_CylinderBrush, "Change Sphere Visualization");
                    m_CylinderBrush.CylinderColor = sphereColor;
                    m_CylinderBrush.CylinderAlpha = sphereAlpha;
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                
                // Action buttons
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = COL_DANGER;
                if (GUILayout.Button("Delete", GUILayout.Height(28)))
                    m_CylinderBrush.DeleteSplatsInSphere();
                
                GUI.backgroundColor = new Color(0.5f, 0.8f, 1f);
                if (GUILayout.Button("Restore", GUILayout.Height(28)))
                    m_CylinderBrush.RestoreSplatsInSphere();
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                if (GUILayout.Button("Reset Sphere"))
                {
                    Undo.RecordObject(m_CylinderBrush, "Reset Sphere");
                    m_CylinderBrush.ResetSphere();
                    EditorUtility.SetDirty(m_CylinderBrush);
                }
                
                EditorGUILayout.Space();
                DrawToolControls("1=Move | 3=Scale | Del=Delete | Shift+R=Restore | WASD=Navigate");
            }
        }

        private void DrawVortexToolSettings()
        {
            // Safety check - object may become invalid during play mode transitions
            if (m_VortexAttractor == null || !m_VortexAttractor)
            {
                CreateToolGameObject(BrushTool.VortexTool);
                EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel);
                return;
            }
            
            // Additional safety: check if we're in a valid state for GUI operations
            if (Event.current == null)
                return;
            
            SerializedObject so;
            try
            {
                so = new SerializedObject(m_VortexAttractor);
                so.Update();
            }
            catch (System.ArgumentException)
            {
                // Object was destroyed during play mode transition
                m_VortexAttractor = null;
                EditorGUILayout.LabelField("Reinitializing...", EditorStyles.centeredGreyMiniLabel);
                return;
            }
            
            EditorGUILayout.LabelField("Attractor Settings", EditorStyles.boldLabel);
            
            // Cache all properties upfront to ensure consistent layout
            var propMode = so.FindProperty("m_Mode");
            var propStrength = so.FindProperty("m_Strength");
            var propRange = so.FindProperty("m_Range");
            var propScale = so.FindProperty("m_Scale");
            var propFalloff = so.FindProperty("m_Falloff");
            var propShowVortexGizmo = so.FindProperty("m_ShowVortexGizmo");
            var propWaveFrequency = so.FindProperty("m_WaveFrequency");
            var propWaveAmplitude = so.FindProperty("m_WaveAmplitude");
            var propWaveSpeed = so.FindProperty("m_WaveSpeed");
            var propWaveAxis = so.FindProperty("m_WaveAxis");
            var propCurlStrength = so.FindProperty("m_CurlStrength");
            var propSecondaryFrequency = so.FindProperty("m_SecondaryFrequency");
            var propAttractorEnabled = so.FindProperty("m_AttractorEnabled");
            var propAttractorPaused = so.FindProperty("m_AttractorPaused");
            
            // Verify properties exist
            if (propMode == null || propAttractorEnabled == null || propAttractorPaused == null)
            {
                EditorGUILayout.HelpBox("Invalid attractor component - properties not found.", MessageType.Error);
                return;
            }
            
            EditorGUI.BeginChangeCheck();
            
            // Mode
            EditorGUILayout.PropertyField(propMode, new GUIContent("Mode"));
            
            EditorGUILayout.Space();
            
            // Effect settings
            if (propStrength != null) EditorGUILayout.PropertyField(propStrength, new GUIContent("Strength", "0.01 = very slow, 0.05 = slow, 0.1 = medium"));
            if (propRange != null) EditorGUILayout.PropertyField(propRange, new GUIContent("Range"));
            if (propScale != null) EditorGUILayout.PropertyField(propScale, new GUIContent("Scale", "Multiplier for effect range (0.1-10)"));
            if (propFalloff != null) EditorGUILayout.PropertyField(propFalloff, new GUIContent("Falloff"));
            
            int mode = propMode.enumValueIndex;
            
            // Vortex-specific settings
            if (mode == 0) // Vortex mode
            {
                EditorGUILayout.Space();
                GUI.color = Color.cyan;
                EditorGUILayout.LabelField("Vortex Settings", EditorStyles.boldLabel);
                GUI.color = Color.white;
                
                if (propShowVortexGizmo != null) EditorGUILayout.PropertyField(propShowVortexGizmo, new GUIContent("Show Gizmo", "Show vortex spiral visualization"));
            }
            
            // Wave-specific settings (only show when Wave mode is selected)
            if (mode == 3) // Wave mode
            {
                EditorGUILayout.Space();
                GUI.color = Color.yellow;
                EditorGUILayout.LabelField("Wave Settings", EditorStyles.boldLabel);
                GUI.color = Color.white;
                
                if (propWaveFrequency != null) EditorGUILayout.PropertyField(propWaveFrequency, new GUIContent("Frequency", "Wave density (0.1-20)"));
                if (propWaveAmplitude != null) EditorGUILayout.PropertyField(propWaveAmplitude, new GUIContent("Amplitude", "Wave height multiplier"));
                if (propWaveSpeed != null) EditorGUILayout.PropertyField(propWaveSpeed, new GUIContent("Speed", "Animation speed"));
                if (propWaveAxis != null) EditorGUILayout.PropertyField(propWaveAxis, new GUIContent("Axis", "0=X, 1=Y, 2=Z"));
                if (propCurlStrength != null) EditorGUILayout.PropertyField(propCurlStrength, new GUIContent("Curl", "Rotational twist intensity"));
                if (propSecondaryFrequency != null) EditorGUILayout.PropertyField(propSecondaryFrequency, new GUIContent("Secondary Freq", "Complex wave patterns"));
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
                SceneView.RepaintAll();
            }
            
            EditorGUILayout.Space();
            
            // Transport controls
            bool isEnabled = propAttractorEnabled.boolValue;
            bool isPaused = propAttractorPaused.boolValue;
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = isEnabled ? new Color(0.3f, 0.7f, 0.4f) : Color.gray;
            if (GUILayout.Button("▶ START", GUILayout.Height(26)))
            {
                Undo.RecordObject(m_VortexAttractor, "Start Vortex");
                propAttractorEnabled.boolValue = true;
                propAttractorPaused.boolValue = false;
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
                m_VortexAttractor.EnsureRegistered();
            }
            GUI.backgroundColor = (isEnabled && !isPaused) ? new Color(0.95f, 0.8f, 0.25f) : Color.gray;
            if (GUILayout.Button("⏸ PAUSE", GUILayout.Height(26)))
            {
                Undo.RecordObject(m_VortexAttractor, "Pause Vortex");
                propAttractorPaused.boolValue = true;
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
                if (m_TargetRenderer != null)
                    m_TargetRenderer.ClearAllVelocities();
            }
            GUI.backgroundColor = isEnabled ? COL_DANGER : Color.gray;
            if (GUILayout.Button("■ STOP", GUILayout.Height(26)))
            {
                Undo.RecordObject(m_VortexAttractor, "Stop Vortex");
                propAttractorEnabled.boolValue = false;
                propAttractorPaused.boolValue = false;
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
                if (m_TargetRenderer != null)
                    m_TargetRenderer.ClearAllVelocities();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            
            // Status
            string[] modeNames = { "Vortex", "Attract", "Repel", "Wave" };
            string modeName = modeNames[Mathf.Clamp(mode, 0, modeNames.Length - 1)];
            
            if (isEnabled && !isPaused)
            {
                string icon = mode == 3 ? "🌊" : "🌀";
                GUI.color = mode == 3 ? Color.yellow : COL_CYAN;
                EditorGUILayout.LabelField($"{icon} {modeName.ToUpper()} ACTIVE", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            else if (isEnabled && isPaused)
            {
                GUI.color = new Color(0.95f, 0.8f, 0.25f);
                EditorGUILayout.LabelField($"{modeName} PAUSED", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            else
            {
                EditorGUILayout.LabelField($"{modeName} inactive - press START to activate");
            }
            
            EditorGUILayout.Space();
            
            // Reset button
            GUI.backgroundColor = new Color(1f, 0.8f, 0.3f);
            if (GUILayout.Button("Reset to Defaults", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_VortexAttractor, "Reset Attractor");
                if (propStrength != null) propStrength.floatValue = 0.02f;
                if (propRange != null) propRange.floatValue = 2f;
                if (propScale != null) propScale.floatValue = 1f;
                if (propFalloff != null) propFalloff.floatValue = 1f;
                propMode.enumValueIndex = 0;
                var propVortexHeight = so.FindProperty("m_VortexHeight");
                if (propVortexHeight != null) propVortexHeight.floatValue = 0f;
                if (propShowVortexGizmo != null) propShowVortexGizmo.boolValue = true;
                if (propWaveFrequency != null) propWaveFrequency.floatValue = 2f;
                if (propWaveAmplitude != null) propWaveAmplitude.floatValue = 1f;
                if (propWaveSpeed != null) propWaveSpeed.floatValue = 3f;
                if (propWaveAxis != null) propWaveAxis.intValue = 1;
                if (propCurlStrength != null) propCurlStrength.floatValue = 0f;
                if (propSecondaryFrequency != null) propSecondaryFrequency.floatValue = 0f;
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
            }
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.Space();
            DrawToolControls("Drag position handle in scene | Scroll = Adjust range");
        }

        private void CleanupDuplicateAttractors()
        {
            // Find all attractors in scene
            var allAttractors = FindObjectsByType<GaussianSplatAttractor>();
            
            if (allAttractors.Length <= 1)
            {
                Debug.Log("No duplicate attractors found.");
                return;
            }
            
            // Keep only one, destroy the rest
            int destroyed = 0;
            for (int i = 1; i < allAttractors.Length; i++)
            {
                if (allAttractors[i] != null && allAttractors[i] != m_VortexAttractor)
                {
                    Undo.DestroyObjectImmediate(allAttractors[i].gameObject);
                    destroyed++;
                }
            }
            
            // If we destroyed the one we were tracking, update reference
            if (m_VortexAttractor == null && allAttractors.Length > 0)
            {
                m_VortexAttractor = FindAnyObjectByType<GaussianSplatAttractor>();
            }
            
            // Clear and re-register
            GaussianSplatAttractor.ClearAllAttractors();
            if (m_VortexAttractor != null)
                m_VortexAttractor.EnsureRegistered();
            
            Debug.Log($"✓ Cleaned up {destroyed} duplicate attractor(s)");
            SceneView.RepaintAll();
        }

        private void DrawColorBrushSettings()
        {
            if (m_ColorBrush == null) { CreateToolGameObject(BrushTool.ColorBrush); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Box Parameters", EditorStyles.boldLabel);
            
            m_ColorBrush.BoxSize = EditorGUILayout.Vector3Field("Box Size", m_ColorBrush.BoxSize);
            m_ColorBrush.BoxPosition = EditorGUILayout.Vector3Field("Box Position", m_ColorBrush.BoxPosition);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Color Adjustments", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            var adj = m_ColorBrush.ColorAdjust;
            adj.exposure = EditorGUILayout.Slider("Exposure", adj.exposure, -2f, 5f);
            adj.contrast = EditorGUILayout.Slider("Contrast", adj.contrast, 0f, 2f);
            adj.hueShift = EditorGUILayout.Slider("Hue Shift", adj.hueShift, -180f, 180f);
            adj.saturation = EditorGUILayout.Slider("Saturation", adj.saturation, 0f, 2f);
            adj.colorTint = EditorGUILayout.ColorField("Color Tint", adj.colorTint);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorBrush, "Change Color Adjustments");
                m_ColorBrush.ColorAdjust = adj;
                EditorUtility.SetDirty(m_ColorBrush);
                
                // Realtime update - apply as sliders change
                if (m_ColorBrush.HasAdjustments && m_ColorBrush.IsValid)
                    m_ColorBrush.ApplyColorAdjustments();
            }
            
            EditorGUILayout.Space();
            
            // Status
            if (m_ColorBrush.HasAdjustments)
            {
                GUI.color = new Color(0.8f, 0.3f, 0.9f);
                EditorGUILayout.LabelField("✓ Adjustments ready to apply", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            else
            {
                EditorGUILayout.LabelField("No adjustments set - modify sliders above");
            }
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = m_ColorBrush.HasAdjustments ? new Color(0.8f, 0.3f, 0.9f) : Color.gray;
            GUI.enabled = m_ColorBrush.HasAdjustments && m_ColorBrush.IsValid;
            if (GUILayout.Button("Apply Colors", GUILayout.Height(28)))
                m_ColorBrush.ApplyColorAdjustments();
            GUI.enabled = true;
            
            GUI.backgroundColor = new Color(1f, 0.8f, 0.3f);
            if (GUILayout.Button("Reset", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_ColorBrush, "Reset Color Adjustments");
                m_ColorBrush.ResetColorAdjustments();
                EditorUtility.SetDirty(m_ColorBrush);
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            DrawToolControls("Realtime update as you adjust sliders | ENTER = Apply again");
        }

        private void DrawFillBrushSettings()
        {
            if (m_FillBrush == null) { CreateToolGameObject(BrushTool.FillBrush); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Polygon Fill Tool", EditorStyles.boldLabel);
            
            m_FillBrush.SelectionDepth = EditorGUILayout.Slider("Selection Depth", m_FillBrush.SelectionDepth, 0.01f, 2f);
            m_FillBrush.EdgeSampleWidth = EditorGUILayout.Slider("Edge Sample Width", m_FillBrush.EdgeSampleWidth, 0.01f, 1f);
            m_FillBrush.FillDensity = EditorGUILayout.Slider("Fill Density", m_FillBrush.FillDensity, 0.5f, 5f);
            m_FillBrush.PositionJitter = EditorGUILayout.Slider("Position Jitter", m_FillBrush.PositionJitter, 0f, 0.5f);
            m_FillBrush.DeleteBeforeFill = EditorGUILayout.Toggle("Delete Before Fill", m_FillBrush.DeleteBeforeFill);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Fill Color", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            bool useFillColor = EditorGUILayout.Toggle("Use Fill Color", m_FillBrush.UseFillColor);
            
            GUI.enabled = useFillColor;
            Color fillColor = EditorGUILayout.ColorField("Fill Color", m_FillBrush.FillColor);
            float fillBlend = EditorGUILayout.Slider("Color Blend", m_FillBrush.FillColorBlend, 0f, 1f);
            GUI.enabled = true;
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_FillBrush, "Change Fill Color");
                m_FillBrush.UseFillColor = useFillColor;
                m_FillBrush.FillColor = fillColor;
                m_FillBrush.FillColorBlend = fillBlend;
                EditorUtility.SetDirty(m_FillBrush);
            }
            
            EditorGUILayout.Space();
            
            // Status
            GUIStyle statusStyle = new GUIStyle(EditorStyles.boldLabel);
            if (m_FillBrush.IsClosed)
            {
                GUI.color = COL_SUCCESS;
                EditorGUILayout.LabelField("✓ CLOSED - Transform & Fill!", statusStyle);
                GUI.color = Color.white;
            }
            else if (m_FillBrush.IsDrawing)
            {
                GUI.color = COL_WARNING;
                EditorGUILayout.LabelField($"Drawing... ({m_FillBrush.Vertices.Count} vertices)", statusStyle);
                GUI.color = Color.white;
            }
            else
            {
                EditorGUILayout.LabelField("Click in scene to start drawing", statusStyle);
            }
            
            EditorGUILayout.LabelField($"Vertices: {m_FillBrush.Vertices.Count}");
            
            // Transform controls (only when closed)
            if (m_FillBrush.IsClosed)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Transform Polygon", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Vector3 offset = EditorGUILayout.Vector3Field("Position Offset", m_FillBrush.TransformOffset);
                
                // Rotation as euler angles for easier editing
                Vector3 euler = m_FillBrush.TransformRotation.eulerAngles;
                euler = EditorGUILayout.Vector3Field("Rotation (Euler)", euler);
                
                float uniformScale = EditorGUILayout.Slider("Scale", m_FillBrush.UniformScale, 0.1f, 5f);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_FillBrush, "Transform Polygon");
                    m_FillBrush.TransformOffset = offset;
                    m_FillBrush.TransformRotation = Quaternion.Euler(euler);
                    m_FillBrush.UniformScale = uniformScale;
                    EditorUtility.SetDirty(m_FillBrush);
                    SceneView.RepaintAll();
                }
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Reset Transform"))
                {
                    Undo.RecordObject(m_FillBrush, "Reset Transform");
                    m_FillBrush.ResetTransform();
                    EditorUtility.SetDirty(m_FillBrush);
                    SceneView.RepaintAll();
                }
                if (GUILayout.Button("Bake Transform"))
                {
                    Undo.RecordObject(m_FillBrush, "Bake Transform");
                    m_FillBrush.BakeTransform();
                    EditorUtility.SetDirty(m_FillBrush);
                    SceneView.RepaintAll();
                }
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Color Adjustments", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            var adj = m_FillBrush.ColorAdjust;
            adj.exposure = EditorGUILayout.Slider("Exposure", adj.exposure, -2f, 5f);
            adj.contrast = EditorGUILayout.Slider("Contrast", adj.contrast, 0f, 2f);
            adj.hueShift = EditorGUILayout.Slider("Hue Shift", adj.hueShift, -180f, 180f);
            adj.saturation = EditorGUILayout.Slider("Saturation", adj.saturation, 0f, 2f);
            adj.colorTint = EditorGUILayout.ColorField("Color Tint", adj.colorTint);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_FillBrush, "Change Color Adjustments");
                m_FillBrush.ColorAdjust = adj;
                EditorUtility.SetDirty(m_FillBrush);
            }
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            GUI.enabled = m_FillBrush.CanFill;
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("Fill Polygon (F)", GUILayout.Height(28)))
                m_FillBrush.ExecuteFill();
            GUI.enabled = true;
            
            GUI.enabled = m_FillBrush.HasValidPolygon;
            GUI.backgroundColor = COL_DANGER;
            if (GUILayout.Button("Delete Area", GUILayout.Height(28)))
                m_FillBrush.DeletePolygonArea();
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Undo Vertex"))
                m_FillBrush.UndoLastVertex();
            GUI.backgroundColor = COL_WARNING;
            if (GUILayout.Button("Clear", GUILayout.Height(22)))
            {
                Undo.RecordObject(m_FillBrush, "Clear Polygon");
                m_FillBrush.Clear();
                EditorUtility.SetDirty(m_FillBrush);
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            DrawToolControls("CLICK = Add vertex | ENTER = Close | Drag vertices to align | F = Fill | Scroll = Scale");
        }

        private void DrawPaintBrushSettings()
        {
            if (m_PaintBrush == null) 
            { 
                CreateToolGameObject(BrushTool.PaintBrush);
                EditorGUILayout.LabelField("Initializing Paint Brush...", EditorStyles.centeredGreyMiniLabel);
                return; 
            }
            
            // Ensure colorize brush is also ready
            if (m_ColorizeBrush == null)
                CreateToolGameObject(BrushTool.ColorizeBrush);
            
            // Tab selection: Paint vs Colorize vs Animation
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = m_PaintBrushMode == 0 ? COL_ACCENT : Color.white;
            if (GUILayout.Button("✏️ Paint", GUILayout.Height(28)))
            {
                m_PaintBrushMode = 0;
                GaussianSplatColorizeBrush.IsBrushModeActive = false;
                GaussianSplatPaintBrush.IsBrushModeActive = true;
                m_AnimPaintActive = false;
            }
            GUI.backgroundColor = m_PaintBrushMode == 1 ? new Color(0.8f, 0.5f, 0.9f) : Color.white;
            if (GUILayout.Button("🖌️ Colorize", GUILayout.Height(28)))
            {
                m_PaintBrushMode = 1;
                GaussianSplatPaintBrush.IsBrushModeActive = false;
                GaussianSplatColorizeBrush.IsBrushModeActive = true;
                m_AnimPaintActive = false;
            }
            GUI.backgroundColor = m_PaintBrushMode == 2 ? new Color(0.3f, 0.8f, 0.9f) : Color.white;
            if (GUILayout.Button("🌊 Animate", GUILayout.Height(28)))
            {
                m_PaintBrushMode = 2;
                GaussianSplatPaintBrush.IsBrushModeActive = false;
                GaussianSplatColorizeBrush.IsBrushModeActive = false;
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(5);
            
            // Draw appropriate settings based on mode
            if (m_PaintBrushMode == 0)
                DrawPaintModeSettings();
            else if (m_PaintBrushMode == 1)
                DrawColorizeModeSettings();
            else
                DrawAnimationPaintSettings();
        }
        
        private void DrawPaintModeSettings()
        {
            EditorGUILayout.LabelField("Paint Brush Parameters", EditorStyles.boldLabel);
            
            m_PaintBrush.ScreenRadius = EditorGUILayout.Slider("Brush Radius", m_PaintBrush.ScreenRadius, 0.1f, 10f);
            m_PaintBrush.SplatSizeMultiplier = EditorGUILayout.Slider("Splat Size %", m_PaintBrush.SplatSizeMultiplier, 0.01f, 1f);
            m_PaintBrush.SplatsPerStroke = EditorGUILayout.IntSlider("Splats Per Stroke", m_PaintBrush.SplatsPerStroke, 1, 50);
            m_PaintBrush.PaintDensity = EditorGUILayout.Slider("Density/Opacity", m_PaintBrush.PaintDensity, 0.1f, 2f);
            m_PaintBrush.SamplePixelRadius = EditorGUILayout.IntSlider("Sample Radius (px)", m_PaintBrush.SamplePixelRadius, 5, 100);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Performance", EditorStyles.boldLabel);
            m_PaintBrush.UseGPUPaint = EditorGUILayout.Toggle("GPU Paint", m_PaintBrush.UseGPUPaint);
            if (m_PaintBrush.UseGPUPaint)
            {
                EditorGUILayout.HelpBox("GPU generates splats with zero CPU allocation (fastest)", MessageType.None);
            }
            m_PaintBrush.FastPaintMode = EditorGUILayout.Toggle("Fast Paint Mode", m_PaintBrush.FastPaintMode);
            if (m_PaintBrush.FastPaintMode)
            {
                EditorGUILayout.HelpBox("Fast mode caches surface depth for smoother painting", MessageType.None);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Layering", EditorStyles.boldLabel);
            m_PaintBrush.EnableLayering = EditorGUILayout.Toggle("Enable Layering", m_PaintBrush.EnableLayering);
            if (m_PaintBrush.EnableLayering)
            {
                m_PaintBrush.LayerSpacing = EditorGUILayout.Slider("Layer Spacing", m_PaintBrush.LayerSpacing, 0.0001f, 0.02f);
                EditorGUILayout.LabelField($"Current Layer: {m_PaintBrush.CurrentStrokeLayer}", EditorStyles.miniLabel);
                if (GUILayout.Button("Reset Layers"))
                {
                    m_PaintBrush.ResetLayers();
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Color Mode", EditorStyles.boldLabel);
            
            // Color mode toggle
            EditorGUI.BeginChangeCheck();
            bool useCustom = EditorGUILayout.Toggle("Use Custom Color", m_PaintBrush.UseCustomColor);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_PaintBrush, "Toggle Custom Color");
                m_PaintBrush.UseCustomColor = useCustom;
                EditorUtility.SetDirty(m_PaintBrush);
            }
            
            if (m_PaintBrush.UseCustomColor)
            {
                EditorGUI.indentLevel++;
                
                // Color picker
                EditorGUI.BeginChangeCheck();
                Color newColor = EditorGUILayout.ColorField(new GUIContent("Paint Color"), m_PaintBrush.CustomColor, true, true, false);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_PaintBrush, "Change Paint Color");
                    m_PaintBrush.CustomColor = newColor;
                    EditorUtility.SetDirty(m_PaintBrush);
                }
                
                // Color variation slider
                EditorGUI.BeginChangeCheck();
                float variation = EditorGUILayout.Slider("Color Variation", m_PaintBrush.ColorVariation, 0f, 1f);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_PaintBrush, "Change Color Variation");
                    m_PaintBrush.ColorVariation = variation;
                    EditorUtility.SetDirty(m_PaintBrush);
                }
                
                // Quick color buttons
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("White")) { m_PaintBrush.CustomColor = Color.white; EditorUtility.SetDirty(m_PaintBrush); }
                if (GUILayout.Button("Black")) { m_PaintBrush.CustomColor = Color.black; EditorUtility.SetDirty(m_PaintBrush); }
                if (GUILayout.Button("Red")) { m_PaintBrush.CustomColor = Color.red; EditorUtility.SetDirty(m_PaintBrush); }
                if (GUILayout.Button("Green")) { m_PaintBrush.CustomColor = Color.green; EditorUtility.SetDirty(m_PaintBrush); }
                if (GUILayout.Button("Blue")) { m_PaintBrush.CustomColor = Color.blue; EditorUtility.SetDirty(m_PaintBrush); }
                EditorGUILayout.EndHorizontal();
                
                // Copy from sampled
                if (m_PaintBrush.HasSampledColors)
                {
                    GUI.backgroundColor = COL_SUCCESS;
                    if (GUILayout.Button("Copy Average Sampled Color"))
                    {
                        Undo.RecordObject(m_PaintBrush, "Copy Sampled Color");
                        m_PaintBrush.CustomColor = m_PaintBrush.GetAverageColor();
                        EditorUtility.SetDirty(m_PaintBrush);
                    }
                    GUI.backgroundColor = Color.white;
                }
                
                EditorGUI.indentLevel--;
                
                // Show current paint color preview
                GUI.color = new Color(0.3f, 0.9f, 0.5f);
                EditorGUILayout.LabelField("✓ Using custom color", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            else
            {
                // Sampled colors mode
                EditorGUILayout.HelpBox("Right-click in scene to sample colors from splats", MessageType.Info);
                
                if (m_PaintBrush.HasSampledColors)
                {
                    GUI.color = COL_SUCCESS;
                    EditorGUILayout.LabelField($"✓ {m_PaintBrush.SampledColorCount} colors sampled", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    
                    // Show average color preview
                    Color avgColor = m_PaintBrush.GetAverageColor();
                    EditorGUILayout.ColorField("Average Sampled Color", avgColor);
                    
                    // Option to switch to custom with sampled color
                    GUI.backgroundColor = COL_ACCENT;
                    if (GUILayout.Button("Use This Color as Custom"))
                    {
                        Undo.RecordObject(m_PaintBrush, "Set Custom Color");
                        m_PaintBrush.SetCustomColorFromSample(avgColor);
                        EditorUtility.SetDirty(m_PaintBrush);
                    }
                    GUI.backgroundColor = Color.white;
                }
                else
                {
                    GUI.color = COL_WARNING;
                    EditorGUILayout.LabelField("No colors sampled - RIGHT CLICK to sample", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
            }
            
            EditorGUILayout.Space();
            
            // Texture Paint Section
            EditorGUILayout.LabelField("Texture Paint", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            bool useTexPaint = EditorGUILayout.Toggle("Use Texture Paint", m_PaintBrush.UseTexturePaint);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_PaintBrush, "Toggle Texture Paint");
                m_PaintBrush.UseTexturePaint = useTexPaint;
                EditorUtility.SetDirty(m_PaintBrush);
            }
            
            if (m_PaintBrush.UseTexturePaint)
            {
                EditorGUI.indentLevel++;
                
                // Texture slot selection
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Active Slot:", GUILayout.Width(80));
                for (int i = 0; i < 3; i++)
                {
                    bool hasTexture = m_PaintBrush.HasTextureInSlot(i);
                    bool isActive = m_PaintBrush.ActiveTextureSlot == i;
                    
                    GUI.backgroundColor = isActive ? COL_ACCENT : (hasTexture ? COL_SUCCESS : Color.gray);
                    if (GUILayout.Button($"{i + 1}{(hasTexture ? " ✓" : "")}", GUILayout.Width(40)))
                    {
                        Undo.RecordObject(m_PaintBrush, "Select Texture Slot");
                        m_PaintBrush.ActiveTextureSlot = i;
                        EditorUtility.SetDirty(m_PaintBrush);
                    }
                }
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                // Show active texture preview
                int activeSlot = m_PaintBrush.ActiveTextureSlot;
                var activeTex = m_PaintBrush.GetTextureSlot(activeSlot);
                
                if (activeTex != null)
                {
                    EditorGUILayout.BeginHorizontal();
                    GUILayout.FlexibleSpace();
                    var previewRect = GUILayoutUtility.GetRect(80, 80, GUILayout.Width(80));
                    EditorGUI.DrawPreviewTexture(previewRect, activeTex);
                    GUILayout.FlexibleSpace();
                    EditorGUILayout.EndHorizontal();
                    
                    EditorGUILayout.LabelField($"Size: {activeTex.width}x{activeTex.height}", EditorStyles.centeredGreyMiniLabel);
                }
                else
                {
                    GUI.color = COL_WARNING;
                    EditorGUILayout.LabelField("No texture in slot - Capture or Load", EditorStyles.centeredGreyMiniLabel);
                    GUI.color = Color.white;
                }
                
                // Texture parameters
                EditorGUI.BeginChangeCheck();
                float tileScale = EditorGUILayout.Slider("Tile Scale", m_PaintBrush.TextureTileScale, 0.1f, 10f);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_PaintBrush, "Change Tile Scale");
                    m_PaintBrush.TextureTileScale = tileScale;
                    EditorUtility.SetDirty(m_PaintBrush);
                }
                
                EditorGUI.BeginChangeCheck();
                float rotation = EditorGUILayout.Slider("Rotation", m_PaintBrush.TextureRotation, 0f, 360f);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_PaintBrush, "Change Texture Rotation");
                    m_PaintBrush.TextureRotation = rotation;
                    EditorUtility.SetDirty(m_PaintBrush);
                }
                
                EditorGUILayout.Space(5);
                
                // Capture buttons
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = COL_CYAN;
                if (GUILayout.Button($"Capture to Slot {activeSlot + 1}", GUILayout.Height(24)))
                {
                    m_IsCapturingRect = true;
                    m_CaptureTargetSlot = activeSlot;
                    SceneView.RepaintAll();
                }
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                // Load from file
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Load Image...", GUILayout.Height(24)))
                {
                    string path = EditorUtility.OpenFilePanel("Load Texture", "", "png,jpg,jpeg");
                    if (!string.IsNullOrEmpty(path))
                    {
                        byte[] data = System.IO.File.ReadAllBytes(path);
                        var tex = new Texture2D(2, 2);
                        if (tex.LoadImage(data))
                        {
                            m_PaintBrush.LoadTextureToSlot(tex, activeSlot);
                            DestroyImmediate(tex);
                            EditorUtility.SetDirty(m_PaintBrush);
                        }
                    }
                }
                
                // Save to file
                if (m_PaintBrush.HasTextureInSlot(activeSlot))
                {
                    if (GUILayout.Button("Save PNG...", GUILayout.Height(24)))
                    {
                        string path = EditorUtility.SaveFilePanel("Save Texture", "", $"paint_texture_{activeSlot + 1}", "png");
                        if (!string.IsNullOrEmpty(path))
                        {
                            byte[] png = m_PaintBrush.GetTextureSlotAsPNG(activeSlot);
                            if (png != null)
                                System.IO.File.WriteAllBytes(path, png);
                        }
                    }
                }
                EditorGUILayout.EndHorizontal();
                
                // Clear button
                if (m_PaintBrush.HasTextureInSlot(activeSlot))
                {
                    GUI.backgroundColor = COL_DANGER;
                    if (GUILayout.Button($"Clear Slot {activeSlot + 1}"))
                    {
                        Undo.RecordObject(m_PaintBrush, "Clear Texture Slot");
                        m_PaintBrush.ClearTextureSlot(activeSlot);
                        EditorUtility.SetDirty(m_PaintBrush);
                    }
                    GUI.backgroundColor = Color.white;
                }
                
                EditorGUI.indentLevel--;
                
                // Capture mode indicator
                if (m_IsCapturingRect)
                {
                    EditorGUILayout.Space();
                    GUI.color = COL_WARNING;
                    EditorGUILayout.HelpBox($"CAPTURE MODE: Draw rectangle in Scene View for Slot {m_CaptureTargetSlot + 1}\nPress ESC to cancel", MessageType.Warning);
                    GUI.color = Color.white;
                }
            }
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = COL_CYAN;
            if (GUILayout.Button("Sample Colors (RClick)", GUILayout.Height(28)))
            {
                EditorUtility.DisplayDialog("Sample Colors", "Right-click on splats in the scene view to sample their colors.", "OK");
            }
            
            GUI.backgroundColor = COL_WARNING;
            if (GUILayout.Button("Clear Sampled", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_PaintBrush, "Clear Sampled Colors");
                m_PaintBrush.ClearSampledColors();
                EditorUtility.SetDirty(m_PaintBrush);
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            string controls = m_PaintBrush.UseTexturePaint && m_PaintBrush.HasActiveTexture
                ? "LEFT CLICK = Paint Texture | RIGHT CLICK = Sample | SCROLL = Resize | MIDDLE = Stop"
                : "LEFT CLICK = Paint | RIGHT CLICK = Sample colors | SCROLL = Resize | MIDDLE = Stop";
            DrawToolControls(controls);
        }

        private void DrawEraseBrushSettings()
        {
            // Cache brush reference at start to ensure consistent GUI layout
            var brush = m_EraseBrush;
            bool brushValid = brush != null;
            
            if (!brushValid)
            {
                CreateToolGameObject(BrushTool.EraseBrush);
                brush = m_EraseBrush; // Try again after creation
                brushValid = brush != null;
            }
            
            // Cache values - use defaults if brush is null to maintain consistent control count
            float screenRadius = brushValid ? brush.ScreenRadius : 1f;
            float brushFalloff = brushValid ? brush.BrushFalloff : 0f;
            float noiseStrength = brushValid ? brush.NoiseStrength : 0f;
            float noiseScale = brushValid ? brush.NoiseScale : 1f;
            bool backfaceCulling = brushValid ? brush.BackfaceCulling : true;
            bool useColorFilter = brushValid ? brush.UseColorFilter : false;
            Color filterColor = brushValid ? brush.FilterColor : Color.white;
            float colorThreshold = brushValid ? brush.ColorThreshold : 0.1f;
            
            // Disable controls if brush is null but still draw them for consistent layout
            using (new EditorGUI.DisabledGroupScope(!brushValid))
            {
                EditorGUILayout.LabelField("Brush Parameters", EditorStyles.boldLabel);
                
                screenRadius = EditorGUILayout.Slider("Screen Radius", screenRadius, 0.1f, 25f);
                brushFalloff = EditorGUILayout.Slider("Falloff", brushFalloff, 0f, 1f);
                noiseStrength = EditorGUILayout.Slider("Noise Strength", noiseStrength, 0f, 1f);
                noiseScale = EditorGUILayout.Slider("Noise Scale", noiseScale, 0.1f, 10f);
                
                EditorGUILayout.Space();
                backfaceCulling = EditorGUILayout.Toggle(
                    new GUIContent("Backface Culling", "Only delete splats visible from camera (front surface only)"), 
                    backfaceCulling);

                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Color Filter", EditorStyles.boldLabel);
                useColorFilter = EditorGUILayout.Toggle("Use Color Filter", useColorFilter);
                
                // Always draw color filter controls to maintain consistent layout
                using (new EditorGUI.DisabledGroupScope(!useColorFilter))
                {
                    filterColor = EditorGUILayout.ColorField("Filter Color", filterColor);
                    colorThreshold = EditorGUILayout.Slider("Color Threshold", colorThreshold, 0.01f, 1.0f);
                    if (useColorFilter)
                        EditorGUILayout.HelpBox("0.1 = strict match | 0.5 = moderate | 1.0 = any color", MessageType.None);
                    else
                        EditorGUILayout.HelpBox(" ", MessageType.None); // Placeholder for consistent layout
                }
            }
            
            // Apply values back if brush still exists
            if (brushValid && brush != null)
            {
                brush.ScreenRadius = screenRadius;
                brush.BrushFalloff = brushFalloff;
                brush.NoiseStrength = noiseStrength;
                brush.NoiseScale = noiseScale;
                brush.BackfaceCulling = backfaceCulling;
                brush.UseColorFilter = useColorFilter;
                brush.FilterColor = filterColor;
                brush.ColorThreshold = colorThreshold;
            }
            
            EditorGUILayout.Space();
            DrawToolControls("LEFT CLICK = Delete | RIGHT CLICK = Restore | SCROLL = Resize | MIDDLE = Stop");

            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("VR Erase", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "In VR Play Mode / Quest: add SplatBoxVREraseBrush to the XR camera. Right trigger = delete, thumbstick up/down = brush size (Screen Radius).",
                MessageType.Info);
            if (GUILayout.Button("Add VR Erase Brush To Camera", GUILayout.Height(24)))
            {
                var cam = Camera.main;
                if (cam == null)
                    cam = UnityEngine.Object.FindAnyObjectByType<Camera>();
                if (cam == null)
                    EditorUtility.DisplayDialog("No Camera", "No camera found in the scene.", "OK");
                else if (cam.GetComponent<GaussianSplatting.Runtime.SplatBoxVREraseBrush>() != null)
                    EditorUtility.DisplayDialog("VR Erase", "SplatBoxVREraseBrush is already on " + cam.name, "OK");
                else
                {
                    Undo.AddComponent<GaussianSplatting.Runtime.SplatBoxVREraseBrush>(cam.gameObject);
                    var vrBrush = cam.GetComponent<GaussianSplatting.Runtime.SplatBoxVREraseBrush>();
                    if (vrBrush != null && m_TargetRenderer != null)
                        vrBrush.m_TargetRenderer = m_TargetRenderer;
                    EditorUtility.DisplayDialog("VR Erase",
                        "Added to " + cam.name + ".\nEnter VR Play Mode — right trigger deletes, thumbstick resizes.",
                        "OK");
                }
            }
        }

        private void DrawBoxBrushSettings()
        {
            if (m_BoxBrush == null) { CreateToolGameObject(BrushTool.BoxBrush); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            // Mode selection with 3 tabs
            EditorGUILayout.LabelField("Xcopy Mode", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            
            // Box Xcopy tab
            GUI.backgroundColor = m_BoxBrush.BrushMode == BoxBrushMode.Box3D ? COL_CYAN : Color.gray;
            if (GUILayout.Button("📦 Box Xcopy", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_BoxBrush, "Change Xcopy Mode");
                m_BoxBrush.BrushMode = BoxBrushMode.Box3D;
                EditorUtility.SetDirty(m_BoxBrush);
            }
            
            // Planar Xcopy tab
            GUI.backgroundColor = m_BoxBrush.BrushMode == BoxBrushMode.Planar ? COL_CYAN : Color.gray;
            if (GUILayout.Button("📐 Planar Xcopy", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_BoxBrush, "Change Xcopy Mode");
                m_BoxBrush.BrushMode = BoxBrushMode.Planar;
                EditorUtility.SetDirty(m_BoxBrush);
            }
            //version 1.3 
            // Paint Xcopy tab (hidden for now)
            // GUI.backgroundColor = m_BoxBrush.BrushMode == BoxBrushMode.PaintSelection ? COL_CYAN : Color.gray;
            // if (GUILayout.Button("🖌️ Paint Xcopy", GUILayout.Height(28)))
            // {
            //     Undo.RecordObject(m_BoxBrush, "Change Xcopy Mode");
            //     m_BoxBrush.BrushMode = BoxBrushMode.PaintSelection;
            //     EditorUtility.SetDirty(m_BoxBrush);
            // }
            
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            
            if (m_BoxBrush.BrushMode == BoxBrushMode.PaintSelection)
            {
                // Paint Selection mode settings
                EditorGUILayout.LabelField("Paint Selection Settings", EditorStyles.boldLabel);
                
                // Warning if asset doesn't support cloning
                if (!m_BoxBrush.SupportsCloning)
                {
                    EditorGUILayout.HelpBox("Copy/Paste requires VeryHigh quality splats. Current asset uses chunked data.", MessageType.Warning);
                }
                
                m_BoxBrush.SelectionBrushRadius = EditorGUILayout.Slider("Brush Radius", m_BoxBrush.SelectionBrushRadius, 0.01f, 2f);
                
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Source Color", GUILayout.Width(100));
                m_BoxBrush.SelectionColor = EditorGUILayout.ColorField(m_BoxBrush.SelectionColor);
                EditorGUILayout.LabelField("Target Color", GUILayout.Width(100));
                m_BoxBrush.TargetColor = EditorGUILayout.ColorField(m_BoxBrush.TargetColor);
                EditorGUILayout.EndHorizontal();
                
                m_BoxBrush.SelectionAddMode = EditorGUILayout.Toggle("Add Mode (uncheck to subtract)", m_BoxBrush.SelectionAddMode);
                m_BoxBrush.BackfaceCulling = EditorGUILayout.Toggle("Backface Culling", m_BoxBrush.BackfaceCulling);
                
                EditorGUILayout.Space();
                
                // Mode toggle: Source vs Target painting
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = !m_BoxBrush.PaintingTargetMode ? m_BoxBrush.SelectionColor : Color.gray;
                if (GUILayout.Button("Paint Source", GUILayout.Height(28)))
                    m_BoxBrush.PaintingTargetMode = false;
                GUI.backgroundColor = m_BoxBrush.PaintingTargetMode ? m_BoxBrush.TargetColor : Color.gray;
                if (GUILayout.Button("Paint Target", GUILayout.Height(28)))
                    m_BoxBrush.PaintingTargetMode = true;
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                string currentMode = m_BoxBrush.PaintingTargetMode ? "TARGET" : "SOURCE";
                Color modeColor = m_BoxBrush.PaintingTargetMode ? m_BoxBrush.TargetColor : m_BoxBrush.SelectionColor;
                GUI.color = modeColor;
                EditorGUILayout.LabelField($"Currently painting: {currentMode}", EditorStyles.boldLabel);
                GUI.color = Color.white;
                
                EditorGUILayout.Space();
                
                // Selection status - Source
                if (m_BoxBrush.HasSelection)
                {
                    GUI.color = m_BoxBrush.SelectionColor;
                    EditorGUILayout.LabelField($"✓ {m_BoxBrush.SelectedSplatCount} splats selected (SOURCE)", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                else
                {
                    EditorGUILayout.LabelField("No source splats selected");
                }
                
                // Selection status - Target
                if (m_BoxBrush.HasTargetSelection)
                {
                    GUI.color = m_BoxBrush.TargetColor;
                    EditorGUILayout.LabelField($"✓ {m_BoxBrush.TargetSelectedSplatCount} splats marked (TARGET)", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                
                // Target position
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Paste Target Position", EditorStyles.boldLabel);
                m_BoxBrush.BoxPosition = EditorGUILayout.Vector3Field("", m_BoxBrush.BoxPosition);
                
                EditorGUILayout.Space();
                
                // Selection buttons - Source
                EditorGUILayout.LabelField("Source Selection", EditorStyles.boldLabel);
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Select All"))
                    m_BoxBrush.SelectAll();
                if (GUILayout.Button("Invert"))
                    m_BoxBrush.InvertSelection();
                if (GUILayout.Button("Clear Source"))
                    m_BoxBrush.ClearSelection();
                EditorGUILayout.EndHorizontal();
                
                // Clear target button
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = m_BoxBrush.TargetColor;
                if (GUILayout.Button("Clear Target"))
                    m_BoxBrush.ClearTargetSelection();
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.Space();
                
                // Copy/Paste/Delete buttons
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = COL_SUCCESS;
                GUI.enabled = m_BoxBrush.HasSelection;
                if (GUILayout.Button("Copy Selection", GUILayout.Height(28)))
                {
                    // Copy with camera orientation for alignment
                    var sceneView = SceneView.lastActiveSceneView;
                    if (sceneView != null)
                        m_BoxBrush.CopySelectionWithOrientation(sceneView.camera.transform.forward, sceneView.camera.transform.up);
                    else
                    m_BoxBrush.CopySelection();
                }
                GUI.backgroundColor = COL_DANGER;
                if (GUILayout.Button("Delete Selection", GUILayout.Height(28)))
                    m_BoxBrush.DeleteSelection();
                GUI.enabled = true;
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                GUI.backgroundColor = m_BoxBrush.CanPasteSelection ? m_BoxBrush.TargetColor : Color.gray;
                GUI.enabled = m_BoxBrush.CanPasteSelection;
                if (GUILayout.Button("Paste at Target Position", GUILayout.Height(28)))
                    m_BoxBrush.PasteSelection();
                GUI.enabled = true;
                GUI.backgroundColor = Color.white;
                
                // Paste offset adjustment
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Paste Offset Adjustment", EditorStyles.boldLabel);
                
                // Toggle between Paint and Transform mode - ALWAYS visible
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = !m_BoxBrush.TransformModeActive ? Color.cyan : Color.gray;
                if (GUILayout.Button("🖌️ Paint Mode (G)", GUILayout.Height(28)))
                {
                    m_BoxBrush.TransformModeActive = false;
                }
                GUI.backgroundColor = m_BoxBrush.TransformModeActive ? Color.yellow : Color.gray;
                if (GUILayout.Button("🔧 Transform Mode (G)", GUILayout.Height(28)))
                {
                    m_BoxBrush.TransformModeActive = true;
                    Tools.current = Tool.Move;
                }
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                if (m_BoxBrush.TransformModeActive)
                {
                    EditorGUILayout.HelpBox("TRANSFORM MODE: W=Move | E=Rotate | R=Scale | G=Toggle", MessageType.Info);
                }
                else
                {
                    EditorGUILayout.HelpBox("PAINT MODE: Click to paint | G=Toggle to Transform", MessageType.Info);
                }
                
                // Show if splats are being adjusted in real-time
                if (m_BoxBrush.HasAdjustablePastedSplats)
                {
                    GUI.color = Color.cyan;
                    EditorGUILayout.LabelField($"✓ {m_BoxBrush.LastPastedCount} pasted splats ready to adjust", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                
                // Position adjustments
                m_BoxBrush.PasteOffset = EditorGUILayout.Vector3Field("XYZ Offset", m_BoxBrush.PasteOffset);
                m_BoxBrush.PasteDepthOffset = EditorGUILayout.Slider("Depth Offset", m_BoxBrush.PasteDepthOffset, -2f, 2f);
                
                // Rotation and Scale adjustments (only when adjustable)
                GUI.enabled = m_BoxBrush.HasAdjustablePastedSplats;
                m_BoxBrush.PasteRotationAdjust = EditorGUILayout.Vector3Field("Rotation Adjust", m_BoxBrush.PasteRotationAdjust);
                m_BoxBrush.PasteScaleAdjust = EditorGUILayout.Slider("Scale Adjust", m_BoxBrush.PasteScaleAdjust, 0.1f, 3f);
                GUI.enabled = true;
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Reset All"))
                {
                    m_BoxBrush.ResetPasteAdjustments();
                }
                GUI.enabled = m_BoxBrush.HasAdjustablePastedSplats;
                GUI.backgroundColor = Color.green;
                if (GUILayout.Button("Confirm"))
                {
                    m_BoxBrush.ConfirmPastedSplats();
                }
                GUI.backgroundColor = Color.white;
                GUI.enabled = true;
                EditorGUILayout.EndHorizontal();
            }
            else
            {
                // Box3D and Planar modes share these settings
                if (m_BoxBrush.BrushMode == BoxBrushMode.Planar)
                {
                    // Planar mode settings
                    EditorGUILayout.LabelField("Planar Settings (Floor)", EditorStyles.boldLabel);
                    
                    m_BoxBrush.FloorY = EditorGUILayout.FloatField("Floor Y", m_BoxBrush.FloorY);
                    m_BoxBrush.FloorThickness = EditorGUILayout.Slider("Thickness", m_BoxBrush.FloorThickness, 0.01f, 1f);
                    m_BoxBrush.PlanarSize = EditorGUILayout.Vector2Field("Size (XZ)", m_BoxBrush.PlanarSize);
                    m_BoxBrush.PlanarPosition = EditorGUILayout.Vector2Field("Position (XZ)", m_BoxBrush.PlanarPosition);
                    
                    // Drawing status
                    if (m_BoxBrush.IsDrawingPlanar)
                    {
                        GUI.color = COL_WARNING;
                        EditorGUILayout.LabelField("🖱️ Drawing... release to finish", EditorStyles.boldLabel);
                        GUI.color = Color.white;
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("Click and drag in scene to draw floor rectangle", MessageType.Info);
                    }
                }
                else
                {
                    // 3D Box mode settings
                    EditorGUILayout.LabelField("Box Parameters", EditorStyles.boldLabel);
                    
                    m_BoxBrush.BoxSize = EditorGUILayout.Vector3Field("Box Size", m_BoxBrush.BoxSize);
                    m_BoxBrush.BoxPosition = EditorGUILayout.Vector3Field("Box Position", m_BoxBrush.BoxPosition);
                    m_BoxBrush.BoxRotation = EditorGUILayout.Vector3Field("Box Rotation", m_BoxBrush.BoxRotation);
                }
                
                EditorGUILayout.Space();
                
                // Visualization settings (Box/Planar only)
                EditorGUILayout.LabelField("Visualization", EditorStyles.boldLabel);
                m_BoxBrush.BoxColor = EditorGUILayout.ColorField("Box Color", m_BoxBrush.BoxColor);
                m_BoxBrush.BoxAlpha = EditorGUILayout.Slider("Transparency", m_BoxBrush.BoxAlpha, 0.05f, 0.5f);
                
                EditorGUILayout.Space();
                
                // Status
                if (m_BoxBrush.HasCopiedData)
                {
                    GUI.color = COL_CYAN;
                    EditorGUILayout.LabelField("✓ Splats COPIED - Ready to paste!", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                
                EditorGUILayout.Space();
                
                // Paste Transform (rotation, scale, flip)
                m_BoxBrush.ApplyPasteTransform = EditorGUILayout.Toggle("Apply Paste Transform", m_BoxBrush.ApplyPasteTransform);
                if (m_BoxBrush.ApplyPasteTransform)
                {
                    EditorGUI.indentLevel++;
                    var pt = m_BoxBrush.PasteTransformSettings;
                    pt.rotation = EditorGUILayout.Vector3Field("Rotation", pt.rotation);
                    pt.scale = EditorGUILayout.Vector3Field("Scale", pt.scale);
                    pt.flip = (FlipAxis)EditorGUILayout.EnumFlagsField("Flip Axis", pt.flip);
                    m_BoxBrush.PasteTransformSettings = pt;
                    EditorGUI.indentLevel--;
                    
                    if (GUILayout.Button("Reset Paste Transform"))
                        m_BoxBrush.ResetPasteTransform();
                }
                
                EditorGUILayout.Space();
                
                // Color Adjustments
                m_BoxBrush.ApplyColorAdjustments = EditorGUILayout.Toggle("Apply Color Adjustments", m_BoxBrush.ApplyColorAdjustments);
                if (m_BoxBrush.ApplyColorAdjustments)
                {
                    EditorGUI.indentLevel++;
                    var adj = m_BoxBrush.ColorAdjust;
                    adj.exposure = EditorGUILayout.Slider("Exposure", adj.exposure, -2f, 5f);
                    adj.contrast = EditorGUILayout.Slider("Contrast", adj.contrast, 0f, 2f);
                    adj.hueShift = EditorGUILayout.Slider("Hue Shift", adj.hueShift, -180f, 180f);
                    adj.saturation = EditorGUILayout.Slider("Saturation", adj.saturation, 0f, 2f);
                    adj.colorTint = EditorGUILayout.ColorField("Color Tint", adj.colorTint);
                    m_BoxBrush.ColorAdjust = adj;
                    EditorGUI.indentLevel--;
                }
                
                EditorGUILayout.Space();
                
                // Action buttons (Box/Planar only)
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = COL_SUCCESS;
                if (GUILayout.Button("Copy", GUILayout.Height(28)))
                    m_BoxBrush.CopySplats();
                GUI.backgroundColor = COL_DANGER;
                if (GUILayout.Button("Delete", GUILayout.Height(28)))
                    m_BoxBrush.DeleteSplatsInBox();
                GUI.backgroundColor = m_BoxBrush.CanPaste ? COL_CYAN : Color.gray;
                GUI.enabled = m_BoxBrush.CanPaste;
                if (GUILayout.Button("Paste", GUILayout.Height(28)))
                    m_BoxBrush.PasteSplats();
                GUI.enabled = true;
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                GUI.backgroundColor = m_BoxBrush.CanPaste ? COL_WARNING : Color.gray;
                GUI.enabled = m_BoxBrush.CanPaste;
                if (GUILayout.Button("Delete & Paste", GUILayout.Height(28)))
                    m_BoxBrush.DeleteAndPaste();
                GUI.enabled = true;
                GUI.backgroundColor = Color.white;
                
                EditorGUILayout.Space();
                
                // Reset buttons (Box/Planar only)
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Clear Copied"))
                {
                    Undo.RecordObject(m_BoxBrush, "Clear Copied");
                    m_BoxBrush.ClearCopiedData();
                    EditorUtility.SetDirty(m_BoxBrush);
                }
                GUI.backgroundColor = COL_WARNING;
                if (GUILayout.Button("Reset All"))
                {
                    Undo.RecordObject(m_BoxBrush, "Reset All");
                    m_BoxBrush.ResetAll();
                    EditorUtility.SetDirty(m_BoxBrush);
                }
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.Space();
                string controls = m_BoxBrush.BrushMode == BoxBrushMode.Planar 
                    ? "DRAG = Draw rect | C = Copy | V = Paste | Del = Delete | X = Delete & Paste"
                    : "C = Copy | V = Paste | Del = Delete | X = Delete & Paste";
                DrawToolControls(controls);
            }
        }

        private void DrawCloneBrushSettings()
        {
            if (m_CloneBrush == null) { CreateToolGameObject(BrushTool.CloneBrush); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Clone Parameters", EditorStyles.boldLabel);
            
            m_CloneBrush.SelectionDepth = EditorGUILayout.Slider("Selection Depth", m_CloneBrush.SelectionDepth, 0.01f, 2f);
            m_CloneBrush.DepthOffset = EditorGUILayout.Slider("Depth Offset", m_CloneBrush.DepthOffset, -2f, 2f);
            
            EditorGUILayout.Space();
            
            // Status
            string status = m_CloneBrush.IsDrawingSource ? "Step 1: Draw SOURCE polygon" : "Step 2: Click TARGET position";
            Color statusCol = m_CloneBrush.IsDrawingSource ? COL_SUCCESS : COL_WARNING;
            GUI.color = statusCol;
            EditorGUILayout.LabelField(status, EditorStyles.boldLabel);
            GUI.color = Color.white;
            
            EditorGUILayout.LabelField($"Source vertices: {m_CloneBrush.SourceVertices.Count}");
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Undo Vertex"))
                m_CloneBrush.UndoLastVertex();
            if (GUILayout.Button("Clear All"))
                m_CloneBrush.ClearAll();
            EditorGUILayout.EndHorizontal();
            
            if (m_CloneBrush.CanClone)
            {
                GUI.backgroundColor = COL_SUCCESS;
                if (GUILayout.Button("Execute Clone", GUILayout.Height(30)))
                    m_CloneBrush.PerformClone();
                GUI.backgroundColor = Color.white;
            }
            
            EditorGUILayout.Space();
            DrawToolControls("CLICK = Add vertex | ENTER = Finish source | SPACE = Clone | BACKSPACE = Undo");
        }

        private void DrawFloorFillSettings()
        {
            if (m_FloorFillBrush == null) { CreateToolGameObject(BrushTool.FloorFill); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Fill Region", EditorStyles.boldLabel);
            
            m_FloorFillBrush.FillCenter = EditorGUILayout.Vector3Field("Center", m_FloorFillBrush.FillCenter);
            m_FloorFillBrush.FillSize = EditorGUILayout.Vector2Field("Size (XZ)", m_FloorFillBrush.FillSize);
            m_FloorFillBrush.FloorY = EditorGUILayout.FloatField("Floor Y", m_FloorFillBrush.FloorY);
            m_FloorFillBrush.FloorThickness = EditorGUILayout.FloatField("Thickness", m_FloorFillBrush.FloorThickness);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Sample Settings", EditorStyles.boldLabel);
            
            m_FloorFillBrush.CurrentSampleMode = (GaussianSplatFloorFillBrush.SampleMode)EditorGUILayout.EnumPopup("Sample Mode", m_FloorFillBrush.CurrentSampleMode);
            m_FloorFillBrush.SampleEdgeWidth = EditorGUILayout.FloatField("Edge Width", m_FloorFillBrush.SampleEdgeWidth);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Fill Settings", EditorStyles.boldLabel);
            
            m_FloorFillBrush.TileSize = EditorGUILayout.Vector2Field("Tile Size", m_FloorFillBrush.TileSize);
            m_FloorFillBrush.PositionJitter = EditorGUILayout.Slider("Jitter", m_FloorFillBrush.PositionJitter, 0f, 0.3f);
            m_FloorFillBrush.RandomizeTileSelection = EditorGUILayout.Toggle("Randomize Tiles", m_FloorFillBrush.RandomizeTileSelection);
            m_FloorFillBrush.DeleteBeforeFill = EditorGUILayout.Toggle("Delete Before Fill", m_FloorFillBrush.DeleteBeforeFill);
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = COL_DANGER;
            if (GUILayout.Button("Delete Region", GUILayout.Height(28)))
                m_FloorFillBrush.DeleteFillRegion();
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("Fill Floor", GUILayout.Height(28)))
                m_FloorFillBrush.ExecuteFill();
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            if (GUILayout.Button("Update Sample Regions"))
                m_FloorFillBrush.UpdateSampleRegions();
            
            EditorGUILayout.Space();
            DrawToolControls("DRAG = Draw region | F = Fill | D = Delete");
        }

        private void DrawPatchToolSettings()
        {
            if (m_PatchTool == null) { CreateToolGameObject(BrushTool.PatchTool); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField($"Source Patches ({m_PatchTool.SourcePatches.Count})", EditorStyles.boldLabel);
            
            // List patches
            for (int i = 0; i < m_PatchTool.SourcePatches.Count; i++)
            {
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = m_PatchTool.SourcePatches[i].gizmoColor;
                EditorGUILayout.LabelField($"[{i}] {m_PatchTool.SourcePatches[i].name}", GUILayout.Width(120));
                GUI.backgroundColor = Color.white;
                
                if (GUILayout.Button("X", GUILayout.Width(25)))
                {
                    m_PatchTool.RemoveSourcePatch(i);
                    break;
                }
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("+ Add Patch"))
            {
                Vector3 pos = m_TargetRenderer != null ? m_TargetRenderer.GetWorldBounds().center : Vector3.zero;
                m_PatchTool.AddSourcePatch(pos, Vector3.one);
            }
            GUI.backgroundColor = Color.white;
            if (GUILayout.Button("Clear All", GUILayout.Width(70)))
                m_PatchTool.ClearSourcePatches();
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Target Region", EditorStyles.boldLabel);
            
            var target = m_PatchTool.TargetRegion;
            target.position = EditorGUILayout.Vector3Field("Position", target.position);
            target.size = EditorGUILayout.Vector3Field("Size", target.size);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Grid Settings", EditorStyles.boldLabel);
            
            m_PatchTool.GridCellSize = EditorGUILayout.Vector3Field("Cell Size", m_PatchTool.GridCellSize);
            m_PatchTool.GridOffset = EditorGUILayout.Vector3Field("Offset", m_PatchTool.GridOffset);
            m_PatchTool.PositionJitter = EditorGUILayout.Slider("Jitter", m_PatchTool.PositionJitter, 0f, 0.5f);
            m_PatchTool.RandomizePatchSelection = EditorGUILayout.Toggle("Random Patch", m_PatchTool.RandomizePatchSelection);
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = COL_DANGER;
            if (GUILayout.Button("Delete Target", GUILayout.Height(28)))
                m_PatchTool.DeleteTargetRegion();
            GUI.backgroundColor = COL_CYAN;
            if (GUILayout.Button("Grid Fill", GUILayout.Height(28)))
                m_PatchTool.GridFillTargetRegion();
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            GUI.backgroundColor = COL_WARNING;
            if (GUILayout.Button("Delete & Fill", GUILayout.Height(30)))
                m_PatchTool.DeleteAndFill();
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.Space();
            DrawToolControls("DRAG = Draw box | RIGHT CLICK = Paste patch | TAB = Cycle edit target");
        }

        private void DrawPolyMaskSettings()
        {
            if (m_PolyMask == null) { CreateToolGameObject(BrushTool.PolyMask); EditorGUILayout.LabelField("Initializing...", EditorStyles.centeredGreyMiniLabel); return; }
            
            EditorGUILayout.LabelField("Polygon Mask", EditorStyles.boldLabel);
            
            // Shape type
            var newShape = (GaussianPolyMask.ShapeType)EditorGUILayout.EnumPopup("Shape Type", m_PolyMask.m_ShapeType);
            if (newShape != m_PolyMask.m_ShapeType)
            {
                Undo.RecordObject(m_PolyMask, "Change Shape Type");
                m_PolyMask.m_ShapeType = newShape;
                EditorUtility.SetDirty(m_PolyMask);
            }
            
            EditorGUILayout.Space();
            
            // Status
            GUIStyle statusStyle = new GUIStyle(EditorStyles.boldLabel);
            if (m_PolyMask.IsClosed)
            {
                GUI.color = COL_SUCCESS;
                EditorGUILayout.LabelField("✓ CLOSED - Ready to apply", statusStyle);
                GUI.color = Color.white;
            }
            else if (m_PolyMask.m_IsDrawing)
            {
                GUI.color = COL_WARNING;
                EditorGUILayout.LabelField($"Drawing... ({m_PolyMask.m_Vertices.Count} vertices)", statusStyle);
                GUI.color = Color.white;
            }
            else
            {
                EditorGUILayout.LabelField("Click in scene to start drawing", statusStyle);
            }
            
            EditorGUILayout.LabelField($"Vertices: {m_PolyMask.GetDisplayVertices().Count}");
            
            EditorGUILayout.Space();
            
            // Predefined shapes
            if (m_PolyMask.m_ShapeType != GaussianPolyMask.ShapeType.Custom)
            {
                EditorGUILayout.LabelField("Shape Settings", EditorStyles.boldLabel);
                
                SerializedObject so = new SerializedObject(m_PolyMask);
                EditorGUILayout.PropertyField(so.FindProperty("m_ShapeSize"), new GUIContent("Size"));
                so.ApplyModifiedProperties();
                
                GUI.backgroundColor = COL_ACCENT;
                if (GUILayout.Button($"Generate {m_PolyMask.m_ShapeType}", GUILayout.Height(28)))
                {
                    Undo.RecordObject(m_PolyMask, $"Generate {m_PolyMask.m_ShapeType}");
                    Vector3 pos = m_TargetRenderer != null ? m_TargetRenderer.GetWorldBounds().center : m_PolyMask.transform.position;
                    m_PolyMask.GenerateShape(pos, Vector3.up, 1f);
                    EditorUtility.SetDirty(m_PolyMask);
                }
                GUI.backgroundColor = Color.white;
            }
            
            EditorGUILayout.Space();
            
            // Cutout controls
            EditorGUILayout.LabelField("Cutout Controls", EditorStyles.boldLabel);
            
            SerializedObject maskSO = new SerializedObject(m_PolyMask);
            EditorGUILayout.PropertyField(maskSO.FindProperty("m_ExpansionX"), new GUIContent("Expansion X"));
            EditorGUILayout.PropertyField(maskSO.FindProperty("m_ExpansionY"), new GUIContent("Expansion Y"));
            EditorGUILayout.PropertyField(maskSO.FindProperty("m_OffsetX"), new GUIContent("Offset X"));
            EditorGUILayout.PropertyField(maskSO.FindProperty("m_OffsetY"), new GUIContent("Offset Y"));
            EditorGUILayout.PropertyField(maskSO.FindProperty("m_CutDepth"), new GUIContent("Cut Depth"));
            EditorGUILayout.PropertyField(maskSO.FindProperty("m_Invert"), new GUIContent("Invert"));
            maskSO.ApplyModifiedProperties();
            
            EditorGUILayout.Space();
            
            // Action buttons
            EditorGUILayout.BeginHorizontal();
            GUI.enabled = m_PolyMask.IsClosed;
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("Apply Cutout", GUILayout.Height(28)))
            {
                ApplyMaskCutout();
            }
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;
            
            GUI.backgroundColor = COL_DANGER;
            if (GUILayout.Button("Clear", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_PolyMask, "Clear Polygon");
                m_PolyMask.Clear();
                EditorUtility.SetDirty(m_PolyMask);
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            DrawToolControls("CLICK = Add vertex | DOUBLE-CLICK/ENTER = Close polygon | ESC = Cancel");
        }

        private void ApplyMaskCutout()
        {
            if (m_PolyMask == null || !m_PolyMask.IsClosed) return;
            
            SplatBoxRenderer[] renderers = FindObjectsByType<SplatBoxRenderer>();
            int appliedCount = 0;
            
            foreach (var renderer in renderers)
            {
                Undo.RecordObject(renderer, "Apply Cutout");
                
                if (renderer.m_Cutouts == null)
                {
                    renderer.m_Cutouts = new GaussianCutout[] { m_PolyMask };
                }
                else
                {
                    bool alreadyHas = false;
                    foreach (var cutout in renderer.m_Cutouts)
                    {
                        if (cutout == m_PolyMask) { alreadyHas = true; break; }
                    }
                    
                    if (!alreadyHas)
                    {
                        var newCutouts = new GaussianCutout[renderer.m_Cutouts.Length + 1];
                        for (int i = 0; i < renderer.m_Cutouts.Length; i++)
                            newCutouts[i] = renderer.m_Cutouts[i];
                        newCutouts[renderer.m_Cutouts.Length] = m_PolyMask;
                        renderer.m_Cutouts = newCutouts;
                    }
                }
                
                EditorUtility.SetDirty(renderer);
                appliedCount++;
            }
            
            // Force refresh
            foreach (var renderer in renderers)
            {
                renderer.enabled = false;
                renderer.enabled = true;
            }
            
            Debug.Log($"✓ Applied polygon cutout to {appliedCount} renderer(s)");
        }

        private void DrawQuickActions()
        {
            m_ShowQuickActions = DrawFoldoutHeader("Quick Actions", m_ShowQuickActions, COL_BG_MED);
            
            if (!m_ShowQuickActions) return;
            
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            // Import PLY/SPZ button
            GUI.backgroundColor = COL_ACCENT;
            if (GUILayout.Button("📦 Import PLY/SPZ File", GUILayout.Height(30)))
            {
                GaussianPlyImporterWindow.ShowImporter();
            }
            GUI.backgroundColor = Color.white;
            
            
            EditorGUILayout.Space(4);
            
            // Reset button - toggle renderer to clear all edits
            GUI.backgroundColor = COL_WARNING;
            GUI.enabled = m_TargetRenderer != null;
            if (GUILayout.Button("⟲ Reset All Edits (Toggle Renderer)", GUILayout.Height(28)))
            {
                if (m_TargetRenderer != null)
                {
                    Undo.RecordObject(m_TargetRenderer, "Reset Splat Edits");
                    m_TargetRenderer.enabled = false;
                    m_TargetRenderer.enabled = true;
                    EditorUtility.SetDirty(m_TargetRenderer);
                    SceneView.RepaintAll();
                    Debug.Log("✓ Reset all splat edits - renderer toggled");
                }
            }
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.EndVertical();
        }

        private void DrawTiltShiftSection()
        {
            m_ShowTiltShift = DrawFoldoutHeader("🎥 Camera Blur Effects", m_ShowTiltShift, new Color(0.6f, 0.3f, 0.7f));
            
            if (!m_ShowTiltShift) return;
            
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            
            // Enable toggle
            EditorGUI.BeginChangeCheck();
            bool wasEnabled = m_TiltShiftEnabled;
            m_TiltShiftEnabled = EditorGUILayout.Toggle("Enable Effect", m_TiltShiftEnabled);
            if (EditorGUI.EndChangeCheck())
            {
                // Apply defaults when first enabling
                if (m_TiltShiftEnabled && !wasEnabled)
                {
                    m_BlurMode = 0;
                    m_TiltShiftFocusPosition = 0.5f;
                    m_TiltShiftFocusWidth = 0.05f;
                    m_TiltShiftAngle = 0f;
                    m_TiltShiftBlurStrength = 10f;
                    m_TiltShiftBlurSamples = 8;
                    m_TiltShiftBokehShape = 0.5f;
                    m_TiltShiftSaturation = 1f;
                    m_TiltShiftContrast = 1f;
                    m_TiltShiftVignette = 0.58f;
                    m_TiltShiftHighQuality = true;
                }
                ApplyTiltShiftToSceneView();
            }
            
            if (!m_TiltShiftEnabled)
            {
                EditorGUILayout.HelpBox("Enable to apply blur effects to Scene View", MessageType.Info);
                EditorGUILayout.EndVertical();
                return;
            }
            
            EditorGUILayout.Space(4);
            
            // Mode selection
            EditorGUI.BeginChangeCheck();
            string[] modeNames = { "Tilt-Shift (Miniature)", "Depth of Field", "Combined" };
            m_BlurMode = EditorGUILayout.Popup("Blur Mode", m_BlurMode, modeNames);
            
            EditorGUILayout.Space(4);
            
            // Tilt-Shift settings (Mode 0 or 2)
            if (m_BlurMode == 0 || m_BlurMode == 2)
            {
                EditorGUILayout.LabelField("Tilt-Shift Focus", EditorStyles.boldLabel);
                m_TiltShiftFocusPosition = EditorGUILayout.Slider("Focus Position", m_TiltShiftFocusPosition, 0f, 1f);
                m_TiltShiftFocusWidth = EditorGUILayout.Slider("Focus Width", m_TiltShiftFocusWidth, 0.001f, 0.8f);
                m_TiltShiftTopBlurOffset = EditorGUILayout.Slider(new GUIContent("Top Blur Offset", "Move the top blur edge up (+) or down (-) to align the focus band (useful in VR)."), m_TiltShiftTopBlurOffset, -0.5f, 0.5f);
                m_TiltShiftBottomBlurOffset = EditorGUILayout.Slider(new GUIContent("Bottom Blur Offset", "Move the bottom blur edge down (+) or up (-) to align the focus band (useful in VR)."), m_TiltShiftBottomBlurOffset, -0.5f, 0.5f);
                m_TiltShiftAngle = EditorGUILayout.Slider("Tilt Angle", m_TiltShiftAngle, -45f, 45f);
                EditorGUILayout.Space(4);
            }
            
            // Depth of Field settings (Mode 1 or 2)
            if (m_BlurMode == 1 || m_BlurMode == 2)
            {
                EditorGUILayout.LabelField("Depth of Field", EditorStyles.boldLabel);
                m_DoFFocusDistance = EditorGUILayout.Slider("Focus Distance", m_DoFFocusDistance, 0.5f, 100f);
                m_DoFFocusRange = EditorGUILayout.Slider("Focus Range", m_DoFFocusRange, 0.1f, 50f);
                m_DoFNearBlur = EditorGUILayout.Slider("Near Blur", m_DoFNearBlur, 0f, 1f);
                m_DoFFarBlur = EditorGUILayout.Slider("Far Blur", m_DoFFarBlur, 0f, 1f);
                EditorGUILayout.Space(4);
            }
            
            EditorGUILayout.LabelField("Blur Settings", EditorStyles.boldLabel);
            m_TiltShiftBlurStrength = EditorGUILayout.Slider("Blur Strength", m_TiltShiftBlurStrength, 0f, 25f);
            m_TiltShiftBlurSamples = EditorGUILayout.IntSlider("Blur Samples", m_TiltShiftBlurSamples, 3, 16);
            m_TiltShiftBokehShape = EditorGUILayout.Slider("Bokeh Shape", m_TiltShiftBokehShape, 0f, 1f);
            
            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("Color Enhancement", EditorStyles.boldLabel);
            m_TiltShiftSaturation = EditorGUILayout.Slider("Saturation Boost", m_TiltShiftSaturation, 0.5f, 2f);
            m_TiltShiftContrast = EditorGUILayout.Slider("Contrast Boost", m_TiltShiftContrast, 0.5f, 2f);
            m_TiltShiftVignette = EditorGUILayout.Slider("Vignette", m_TiltShiftVignette, 0f, 1f);
            
            EditorGUILayout.Space(4);
            m_TiltShiftHighQuality = EditorGUILayout.Toggle("High Quality", m_TiltShiftHighQuality);
            
            if (EditorGUI.EndChangeCheck())
            {
                ApplyTiltShiftToSceneView();
                SceneView.RepaintAll();
            }
            
            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("VR Menu", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox(
                "Adds a world-space settings panel on the main/XR camera. Right controller A = toggle menu. Trigger = drag sliders.",
                MessageType.Info);
            if (GUILayout.Button("Add VR Settings Menu To Camera", GUILayout.Height(26)))
            {
                var cam = Camera.main;
                if (cam == null)
                    cam = UnityEngine.Object.FindAnyObjectByType<Camera>();
                if (cam == null)
                    EditorUtility.DisplayDialog("No Camera", "No camera found in the scene.", "OK");
                else if (cam.GetComponent<GaussianSplatting.Runtime.SplatBoxVRSettingsMenu>() != null)
                    EditorUtility.DisplayDialog("VR Menu", "SplatBoxVRSettingsMenu is already on " + cam.name, "OK");
                else
                {
                    Undo.AddComponent<GaussianSplatting.Runtime.SplatBoxVRSettingsMenu>(cam.gameObject);
                    EditorUtility.DisplayDialog("VR Menu",
                        "Added to " + cam.name + ".\nBuild to Quest — press A on the right controller to open the menu.",
                        "OK");
                }
            }
            
            EditorGUILayout.Space(6);
            
            // Preset buttons - different for each mode
            EditorGUILayout.LabelField("Presets", EditorStyles.boldLabel);
            
            if (m_BlurMode == 0) // Tilt-Shift presets
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Miniature", GUILayout.Height(24)))
                {
                    m_TiltShiftFocusPosition = 0.35f;
                    m_TiltShiftFocusWidth = 0.15f;
                    m_TiltShiftAngle = 0f;
                    m_TiltShiftBlurStrength = 6f;
                    m_TiltShiftBlurSamples = 10;
                    m_TiltShiftBokehShape = 0.6f;
                    m_TiltShiftSaturation = 1.5f;
                    m_TiltShiftContrast = 1.25f;
                    m_TiltShiftVignette = 0.35f;
                    ApplyTiltShiftToSceneView();
                }
                if (GUILayout.Button("Subtle", GUILayout.Height(24)))
                {
                    m_TiltShiftFocusPosition = 0.45f;
                    m_TiltShiftFocusWidth = 0.35f;
                    m_TiltShiftAngle = 0f;
                    m_TiltShiftBlurStrength = 2.5f;
                    m_TiltShiftBlurSamples = 6;
                    m_TiltShiftBokehShape = 0.3f;
                    m_TiltShiftSaturation = 1.15f;
                    m_TiltShiftContrast = 1.08f;
                    m_TiltShiftVignette = 0.15f;
                    ApplyTiltShiftToSceneView();
                }
                if (GUILayout.Button("Diagonal", GUILayout.Height(24)))
                {
                    m_TiltShiftFocusPosition = 0.5f;
                    m_TiltShiftFocusWidth = 0.2f;
                    m_TiltShiftAngle = 30f;
                    m_TiltShiftBlurStrength = 5f;
                    m_TiltShiftBlurSamples = 8;
                    m_TiltShiftBokehShape = 0.5f;
                    m_TiltShiftSaturation = 1.35f;
                    m_TiltShiftContrast = 1.2f;
                    m_TiltShiftVignette = 0.3f;
                    ApplyTiltShiftToSceneView();
                }
                EditorGUILayout.EndHorizontal();
            }
            else if (m_BlurMode == 1) // DoF presets
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Portrait", GUILayout.Height(24)))
                {
                    m_DoFFocusDistance = 5f;
                    m_DoFFocusRange = 2f;
                    m_DoFNearBlur = 0.3f;
                    m_DoFFarBlur = 0.9f;
                    m_TiltShiftBlurStrength = 5f;
                    m_TiltShiftBlurSamples = 8;
                    m_TiltShiftBokehShape = 0.7f;
                    m_TiltShiftSaturation = 1.1f;
                    m_TiltShiftContrast = 1.05f;
                    m_TiltShiftVignette = 0.2f;
                    ApplyTiltShiftToSceneView();
                }
                if (GUILayout.Button("Landscape", GUILayout.Height(24)))
                {
                    m_DoFFocusDistance = 20f;
                    m_DoFFocusRange = 15f;
                    m_DoFNearBlur = 0.7f;
                    m_DoFFarBlur = 0.2f;
                    m_TiltShiftBlurStrength = 4f;
                    m_TiltShiftBlurSamples = 8;
                    m_TiltShiftBokehShape = 0.4f;
                    m_TiltShiftSaturation = 1.2f;
                    m_TiltShiftContrast = 1.1f;
                    m_TiltShiftVignette = 0.15f;
                    ApplyTiltShiftToSceneView();
                }
                if (GUILayout.Button("Macro", GUILayout.Height(24)))
                {
                    m_DoFFocusDistance = 2f;
                    m_DoFFocusRange = 0.5f;
                    m_DoFNearBlur = 0.6f;
                    m_DoFFarBlur = 1f;
                    m_TiltShiftBlurStrength = 6f;
                    m_TiltShiftBlurSamples = 10;
                    m_TiltShiftBokehShape = 0.8f;
                    m_TiltShiftSaturation = 1.15f;
                    m_TiltShiftContrast = 1.1f;
                    m_TiltShiftVignette = 0.25f;
                    ApplyTiltShiftToSceneView();
                }
                EditorGUILayout.EndHorizontal();
            }
            else // Combined presets
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Cinematic", GUILayout.Height(24)))
                {
                    m_TiltShiftFocusPosition = 0.45f;
                    m_TiltShiftFocusWidth = 0.3f;
                    m_TiltShiftAngle = 0f;
                    m_DoFFocusDistance = 8f;
                    m_DoFFocusRange = 4f;
                    m_DoFNearBlur = 0.4f;
                    m_DoFFarBlur = 0.6f;
                    m_TiltShiftBlurStrength = 4f;
                    m_TiltShiftBlurSamples = 10;
                    m_TiltShiftBokehShape = 0.5f;
                    m_TiltShiftSaturation = 1.25f;
                    m_TiltShiftContrast = 1.15f;
                    m_TiltShiftVignette = 0.3f;
                    ApplyTiltShiftToSceneView();
                }
                if (GUILayout.Button("Dreamy", GUILayout.Height(24)))
                {
                    m_TiltShiftFocusPosition = 0.5f;
                    m_TiltShiftFocusWidth = 0.2f;
                    m_TiltShiftAngle = 15f;
                    m_DoFFocusDistance = 6f;
                    m_DoFFocusRange = 2f;
                    m_DoFNearBlur = 0.5f;
                    m_DoFFarBlur = 0.8f;
                    m_TiltShiftBlurStrength = 5f;
                    m_TiltShiftBlurSamples = 12;
                    m_TiltShiftBokehShape = 0.6f;
                    m_TiltShiftSaturation = 1.4f;
                    m_TiltShiftContrast = 1.2f;
                    m_TiltShiftVignette = 0.4f;
                    ApplyTiltShiftToSceneView();
                }
                EditorGUILayout.EndHorizontal();
            }
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Reset", GUILayout.Height(22)))
            {
                m_BlurMode = 0;
                m_TiltShiftFocusPosition = 0.5f;
                m_TiltShiftFocusWidth = 0.05f;
                m_TiltShiftAngle = 0f;
                m_DoFFocusDistance = 10f;
                m_DoFFocusRange = 5f;
                m_DoFNearBlur = 0.5f;
                m_DoFFarBlur = 0.8f;
                m_TiltShiftBlurStrength = 10f;
                m_TiltShiftBlurSamples = 8;
                m_TiltShiftBokehShape = 0.5f;
                m_TiltShiftSaturation = 1f;
                m_TiltShiftContrast = 1f;
                m_TiltShiftVignette = 0.58f;
                ApplyTiltShiftToSceneView();
            }
            
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("Add to Camera", GUILayout.Height(22)))
            {
                AddTiltShiftToMainCamera();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(2);
            string modeInfo = m_BlurMode == 0 ? "Tilt-Shift: Horizontal band blur for miniature look" :
                             m_BlurMode == 1 ? "DoF: Near/far blur based on depth (requires depth texture)" :
                             "Combined: Both effects applied together";
            EditorGUILayout.HelpBox(modeInfo, MessageType.Info);
            
            EditorGUILayout.EndVertical();
        }

        private void ApplyTiltShiftToSceneView()
        {
            // Update global settings (for URP Renderer Feature to read)
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.Enabled = m_TiltShiftEnabled;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.BlurMode = m_BlurMode;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.FocusPosition = m_TiltShiftFocusPosition;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.FocusWidth = m_TiltShiftFocusWidth;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.TopBlurOffset = m_TiltShiftTopBlurOffset;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.BottomBlurOffset = m_TiltShiftBottomBlurOffset;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.TiltAngle = m_TiltShiftAngle;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.FocusDistance = m_DoFFocusDistance;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.FocusRange = m_DoFFocusRange;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.NearBlurStrength = m_DoFNearBlur;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.FarBlurStrength = m_DoFFarBlur;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.BlurStrength = m_TiltShiftBlurStrength;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.BlurSamples = m_TiltShiftBlurSamples;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.BokehShape = m_TiltShiftBokehShape;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.SaturationBoost = m_TiltShiftSaturation;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.ContrastBoost = m_TiltShiftContrast;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.VignetteStrength = m_TiltShiftVignette;
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.HighQualityBlur = m_TiltShiftHighQuality;
            // Mark the globals as the live (editor-only) source so the renderer feature uses them for preview.
            GaussianSplatting.Runtime.GaussianTiltShiftGlobalSettings.Active = true;

            // Persist the same values into the renderer feature's SERIALIZED settings so the effect ships in
            // player/Android builds (the globals above are editor-only statics and reset to disabled in a build).
            // Done via a Runtime-side bridge because the Editor assembly does not reference URP directly.
            GaussianSplatting.Runtime.GaussianTiltShiftBuildSync.PersistGlobalsToRenderers();
            
            // Also add/update components on scene view cameras (for built-in pipeline)
            foreach (SceneView sv in SceneView.sceneViews)
            {
                if (sv.camera == null) continue;
                
                var effect = sv.camera.GetComponent<GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect>();
                
                if (m_TiltShiftEnabled)
                {
                    if (effect == null)
                    {
                        effect = sv.camera.gameObject.AddComponent<GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect>();
                        effect.hideFlags = HideFlags.HideAndDontSave;
                    }
                    
                    // Update settings
                    effect.blurMode = (GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect.BlurMode)m_BlurMode;
                    effect.focusPosition = m_TiltShiftFocusPosition;
                    effect.focusWidth = m_TiltShiftFocusWidth;
                    effect.topBlurOffset = m_TiltShiftTopBlurOffset;
                    effect.bottomBlurOffset = m_TiltShiftBottomBlurOffset;
                    effect.tiltAngle = m_TiltShiftAngle;
                    effect.focusDistance = m_DoFFocusDistance;
                    effect.focusRange = m_DoFFocusRange;
                    effect.nearBlurStrength = m_DoFNearBlur;
                    effect.farBlurStrength = m_DoFFarBlur;
                    effect.blurStrength = m_TiltShiftBlurStrength;
                    effect.blurSamples = m_TiltShiftBlurSamples;
                    effect.bokehShape = m_TiltShiftBokehShape;
                    effect.saturationBoost = m_TiltShiftSaturation;
                    effect.contrastBoost = m_TiltShiftContrast;
                    effect.vignetteStrength = m_TiltShiftVignette;
                    effect.highQualityBlur = m_TiltShiftHighQuality;
                    effect.effectEnabled = true;
                }
                else
                {
                    if (effect != null)
                    {
                        DestroyImmediate(effect);
                    }
                }
                
                sv.Repaint();
            }
        }

        private void AddTiltShiftToMainCamera()
        {
            Camera mainCam = Camera.main;
            if (mainCam == null)
            {
                mainCam = FindAnyObjectByType<Camera>();
            }
            
            if (mainCam == null)
            {
                EditorUtility.DisplayDialog("No Camera", "No camera found in scene.", "OK");
                return;
            }
            
            var existing = mainCam.GetComponent<GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect>();
            if (existing == null)
            {
                existing = Undo.AddComponent<GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect>(mainCam.gameObject);
            }
            
            // Copy current settings
            existing.blurMode = (GaussianSplatting.Runtime.GaussianSplatTiltShiftEffect.BlurMode)m_BlurMode;
            existing.focusPosition = m_TiltShiftFocusPosition;
            existing.focusWidth = m_TiltShiftFocusWidth;
            existing.topBlurOffset = m_TiltShiftTopBlurOffset;
            existing.bottomBlurOffset = m_TiltShiftBottomBlurOffset;
            existing.tiltAngle = m_TiltShiftAngle;
            existing.focusDistance = m_DoFFocusDistance;
            existing.focusRange = m_DoFFocusRange;
            existing.nearBlurStrength = m_DoFNearBlur;
            existing.farBlurStrength = m_DoFFarBlur;
            existing.blurStrength = m_TiltShiftBlurStrength;
            existing.blurSamples = m_TiltShiftBlurSamples;
            existing.bokehShape = m_TiltShiftBokehShape;
            existing.saturationBoost = m_TiltShiftSaturation;
            existing.contrastBoost = m_TiltShiftContrast;
            existing.vignetteStrength = m_TiltShiftVignette;
            existing.highQualityBlur = m_TiltShiftHighQuality;
            existing.effectEnabled = true;
            
            // Enable depth texture for DoF mode
            if (m_BlurMode == 1 || m_BlurMode == 2)
            {
                mainCam.depthTextureMode |= DepthTextureMode.Depth;
            }
            
            EditorUtility.SetDirty(existing);
            Selection.activeGameObject = mainCam.gameObject;
            
            string modeName = m_BlurMode == 0 ? "Tilt-Shift" : m_BlurMode == 1 ? "DoF" : "Combined";
            Debug.Log($"Camera blur effect ({modeName}) added to: {mainCam.name}");
        }

        private void DrawExportSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Export Gaussian Splats", EditorStyles.boldLabel);
            
            m_ExportBakeTransform = EditorGUILayout.Toggle("Bake Transform", m_ExportBakeTransform);

            m_ExportFilterSpikes = EditorGUILayout.Toggle(
                new GUIContent("Filter Spikes", "Skip oversized 'floater' gaussians that the editor hides but external viewers render as spikes/needles."),
                m_ExportFilterSpikes);
            if (m_ExportFilterSpikes)
            {
                EditorGUI.indentLevel++;
                m_ExportSpikeScaleFraction = EditorGUILayout.Slider(
                    new GUIContent("Max Size", "Largest allowed splat size as a fraction of the scene bounds. Lower = more aggressive spike removal."),
                    m_ExportSpikeScaleFraction, 0.02f, 2f);
                EditorGUI.indentLevel--;
            }
            
            GUI.enabled = m_TargetRenderer != null && m_TargetRenderer.HasValidAsset;
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button("📥 Export PLY", GUILayout.Height(28)))
            {
                ExportPlyFile();
            }
            GUI.backgroundColor = new Color(0.4f, 0.7f, 1f);
            if (GUILayout.Button("📥 Export SPZ", GUILayout.Height(28)))
            {
                ExportSpzFile();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            GUI.enabled = true;
            
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                EditorGUILayout.HelpBox("Select a valid renderer to export", MessageType.Warning);
            }
            else
            {
                EditorGUILayout.HelpBox("PLY: Standard format, larger files\nSPZ: Compressed format (Niantic/Scaniverse), smaller files\n\nFilter Spikes removes oversized floater gaussians that the editor hides but external viewers show as spikes. Lower 'Max Size' if spikes still appear.", MessageType.Info);
            }

            EditorGUILayout.Space(8);
            DrawMergeSection();

            EditorGUILayout.Space(8);
            DrawDecimateSection();
            
            EditorGUILayout.EndVertical();
        }

        private void DrawDecimateSection()
        {
            EditorGUILayout.LabelField("Smart Decimate (Android VR)", EditorStyles.boldLabel);

            bool hasTarget = m_TargetRenderer != null && m_TargetRenderer.HasValidAsset;
            int currentCount = hasTarget ? m_TargetRenderer.splatCount : 0;
            int deletedCount = hasTarget ? (int)m_TargetRenderer.editDeletedSplats : 0;
            int aliveCount = currentCount - deletedCount;
            int estimatedAfter = hasTarget
                ? Mathf.Max(1, Mathf.RoundToInt(aliveCount * (1f - m_DecimateRemoval)))
                : 0;

            EditorGUILayout.LabelField("Current Splats", hasTarget ? $"{currentCount:N0} ({aliveCount:N0} visible)" : "—");
            EditorGUILayout.LabelField("After Decimate (est.)", hasTarget ? $"~{estimatedAfter:N0}" : "—");

            m_DecimateRemoval = EditorGUILayout.Slider(
                new GUIContent("Remove", "Fraction of visible splats to remove. Keeps high-opacity, larger, round splats; removes faint, tiny, and needle-like ones first."),
                m_DecimateRemoval, 0.05f, 0.9f);

            m_DecimateSaveAsset = EditorGUILayout.Toggle(
                new GUIContent("Save Compressed Asset", "Write a new compressed asset instead of only hiding splats in the scene."),
                m_DecimateSaveAsset);

            if (m_DecimateSaveAsset)
            {
                EditorGUI.indentLevel++;
                m_DecimateAssetSuffix = EditorGUILayout.TextField("Asset Suffix", m_DecimateAssetSuffix);
                m_DecimateOutputFolder = EditorGUILayout.TextField("Output Folder", m_DecimateOutputFolder);
                m_DecimateCompression = EditorGUILayout.Slider(
                    new GUIContent("Compression", GetMergeCompressionLabel(m_DecimateCompression)),
                    m_DecimateCompression, 0f, 4f);
                EditorGUILayout.LabelField("Quality", GetMergeCompressionLabel(m_DecimateCompression), EditorStyles.miniLabel);
                EditorGUI.indentLevel--;
            }

            GUI.enabled = hasTarget && aliveCount > 1;
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = new Color(0.9f, 0.75f, 0.35f);
            if (GUILayout.Button("Preview Decimate", GUILayout.Height(28)))
                PreviewSmartDecimate();
            GUI.backgroundColor = COL_SUCCESS;
            if (GUILayout.Button(m_DecimateSaveAsset ? "Apply & Save Asset" : "Apply Decimate", GUILayout.Height(28)))
            {
                if (m_DecimateSaveAsset)
                    ApplyDecimateAndSaveAsset();
                else
                    PreviewSmartDecimate();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();

            GUI.enabled = hasTarget && deletedCount > 0;
            if (GUILayout.Button("Reset Deletions (Undo Preview)"))
                ResetDecimatePreview();
            GUI.enabled = true;

            if (!hasTarget)
                EditorGUILayout.HelpBox("Select a renderer with a valid splat asset.", MessageType.Info);
            else
                EditorGUILayout.HelpBox(
                    "Scores each splat by opacity, geometric size, and shape (penalizes needles/floaters). " +
                    "Removes the least important splats first — ideal for Quest / Android VR. " +
                    "Use Preview to check the result, then Apply & Save to create a smaller compressed asset.",
                    MessageType.Info);
        }

        private DecimationSettings BuildDecimationSettings()
        {
            return new DecimationSettings
            {
                removalRatio = m_DecimateRemoval,
                opacityWeight = 1f,
                sizeWeight = 0.6f,
                anisotropyPenalty = 0.5f,
                maxScale = 0f
            };
        }

        private void PreviewSmartDecimate()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;

            const string kProgressTitle = "Smart Decimate";
            try
            {
                EditorUtility.DisplayProgressBar(kProgressTitle, "Scoring splats...", 0.2f);
                m_TargetRenderer.ResetDeletedSplats();
                int removed = m_TargetRenderer.SmartDecimate(BuildDecimationSettings());
                EditorUtility.DisplayProgressBar(kProgressTitle, "Updating...", 1f);
                SceneView.RepaintAll();
                Debug.Log($"Smart decimate preview: removed {removed:N0} splats (~{(m_DecimateRemoval * 100f):F0}% of visible)");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void ResetDecimatePreview()
        {
            if (m_TargetRenderer == null)
                return;
            m_TargetRenderer.ResetDeletedSplats();
            SceneView.RepaintAll();
        }

        private void ApplyDecimateAndSaveAsset()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;

            if (string.IsNullOrWhiteSpace(m_DecimateOutputFolder) || !m_DecimateOutputFolder.StartsWith("Assets/"))
            {
                EditorUtility.DisplayDialog("Decimate Failed", "Output folder must be inside the project (Assets/...).", "OK");
                return;
            }

            const string kProgressTitle = "Smart Decimate";
            try
            {
                EditorUtility.DisplayProgressBar(kProgressTitle, "Scoring and removing splats...", 0.15f);
                m_TargetRenderer.ResetDeletedSplats();
                int removed = m_TargetRenderer.SmartDecimate(BuildDecimationSettings());
                if (removed <= 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate", "Nothing to remove at this setting.", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, "Exporting surviving splats...", 0.45f);

                var mergedSplats = new List<GaussianSplatAssetCreator.InputSplatData>();
                if (!CollectAliveSplatsFromRenderer(m_TargetRenderer, mergedSplats, false, ComputeExportMaxScale()))
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate Failed", "Could not export splat data.", "OK");
                    return;
                }

                if (mergedSplats.Count == 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate Failed", "No splats left after decimation.", "OK");
                    return;
                }

                string baseName = m_TargetRenderer.asset.name + m_DecimateAssetSuffix;
                var quality = GetMergeCompressionQuality(m_DecimateCompression);

                EditorUtility.DisplayProgressBar(kProgressTitle,
                    $"Creating {quality} asset ({mergedSplats.Count:N0} splats)...", 0.7f);

                using var nativeSplats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(
                    mergedSplats.ToArray(), Allocator.TempJob);

                string assetPath = GaussianSplatAssetCreator.CreateAssetFromSplats(
                    nativeSplats, m_DecimateOutputFolder.Trim(), baseName, quality);

                if (string.IsNullOrEmpty(assetPath))
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate Failed", "Asset creation failed. Check the Console.", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, "Assigning asset...", 0.95f);

                var savedAsset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(assetPath);
                Undo.RecordObject(m_TargetRenderer, "Smart Decimate");
                m_TargetRenderer.m_Asset = savedAsset;
                m_TargetRenderer.ResetDeletedSplats();
                EditorUtility.SetDirty(m_TargetRenderer);
                m_TargetRenderer.gameObject.SetActive(false);
                m_TargetRenderer.gameObject.SetActive(true);
                SceneView.RepaintAll();

                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Decimate Complete",
                    $"Removed {removed:N0} splats.\n\n" +
                    $"Remaining: {mergedSplats.Count:N0}\n" +
                    $"Quality: {GetMergeCompressionLabel(m_DecimateCompression)}\n" +
                    $"Asset: {assetPath}",
                    "OK");

                Debug.Log($"✓ Smart decimate saved {assetPath} ({mergedSplats.Count:N0} splats, removed {removed:N0})");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Smart decimate failed: {ex.Message}\n{ex.StackTrace}");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Decimate Failed", ex.Message, "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private void DrawMergeSection()
        {
            EditorGUILayout.LabelField("Merge Splat Assets", EditorStyles.boldLabel);

            var mergeRenderers = CollectMergeRenderers();
            int totalSplats = 0;
            foreach (var r in mergeRenderers)
                totalSplats += r.splatCount;

            EditorGUILayout.LabelField("Selected Objects", mergeRenderers.Count.ToString());
            EditorGUILayout.LabelField("Total Splats", $"{totalSplats:N0}");

            m_MergeAssetName = EditorGUILayout.TextField("Asset Name", m_MergeAssetName);
            m_MergeOutputFolder = EditorGUILayout.TextField("Output Folder", m_MergeOutputFolder);
            m_MergeBakeWorldTransform = EditorGUILayout.Toggle(
                new GUIContent("Bake World Transform", "Bake each object's transform into splat positions so the merged asset can live at the scene origin."),
                m_MergeBakeWorldTransform);
            m_MergeDisableSources = EditorGUILayout.Toggle(
                new GUIContent("Disable Source Objects", "Deactivate the original splat GameObjects after merge to save runtime memory."),
                m_MergeDisableSources);

            EditorGUILayout.Space(4);
            m_MergeCompression = EditorGUILayout.Slider(
                new GUIContent("Compression", GetMergeCompressionLabel(m_MergeCompression)),
                m_MergeCompression, 0f, 4f);
            EditorGUILayout.LabelField("Quality", GetMergeCompressionLabel(m_MergeCompression), EditorStyles.miniLabel);

            bool canMerge = mergeRenderers.Count >= 2
                && totalSplats > 0
                && totalSplats <= GaussianSplatAsset.kMaxSplats
                && !string.IsNullOrWhiteSpace(m_MergeAssetName)
                && !string.IsNullOrWhiteSpace(m_MergeOutputFolder)
                && m_MergeOutputFolder.StartsWith("Assets/");

            GUI.enabled = canMerge;
            GUI.backgroundColor = new Color(0.35f, 0.65f, 1f);
            if (GUILayout.Button("🔗 Merge Selected Into One Asset", GUILayout.Height(32)))
                MergeSelectedAssets();
            GUI.backgroundColor = Color.white;
            GUI.enabled = true;

            if (mergeRenderers.Count < 2)
                EditorGUILayout.HelpBox("Select two or more GameObjects with SplatBoxRenderer components in the Hierarchy, then click Merge.", MessageType.Info);
            else if (totalSplats > GaussianSplatAsset.kMaxSplats)
                EditorGUILayout.HelpBox($"Too many splats to merge (max {GaussianSplatAsset.kMaxSplats:N0}).", MessageType.Warning);
            else if (!m_MergeOutputFolder.StartsWith("Assets/"))
                EditorGUILayout.HelpBox("Output folder must be inside the project (Assets/...).", MessageType.Warning);
        }

        private static string GetMergeCompressionLabel(float value)
        {
            return GetMergeCompressionQuality(value) switch
            {
                GaussianSplatAssetCreator.DataQuality.VeryLow => "Very Low (~19× smaller, most compression)",
                GaussianSplatAssetCreator.DataQuality.Low => "Low (~14× smaller)",
                GaussianSplatAssetCreator.DataQuality.Medium => "Medium (~5× smaller, balanced)",
                GaussianSplatAssetCreator.DataQuality.High => "High (~3× smaller)",
                GaussianSplatAssetCreator.DataQuality.VeryHigh => "Very High (minimal compression, best quality)",
                _ => "Medium"
            };
        }

        private static GaussianSplatAssetCreator.DataQuality GetMergeCompressionQuality(float value)
        {
            // Slider 0 = max compression, 4 = best quality
            int level = Mathf.Clamp(Mathf.RoundToInt(value), 0, 4);
            return (GaussianSplatAssetCreator.DataQuality)(4 - level);
        }

        private List<SplatBoxRenderer> CollectMergeRenderers()
        {
            var result = new List<SplatBoxRenderer>();
            var seen = new HashSet<SplatBoxRenderer>();
            foreach (var go in Selection.gameObjects)
            {
                if (go == null) continue;
                var renderer = go.GetComponent<SplatBoxRenderer>();
                if (renderer == null || !renderer.HasValidAsset || renderer.splatCount <= 0)
                    continue;
                if (seen.Add(renderer))
                    result.Add(renderer);
            }
            return result;
        }

        private void MergeSelectedAssets()
        {
            var renderers = CollectMergeRenderers();
            if (renderers.Count < 2)
            {
                EditorUtility.DisplayDialog("Merge Failed", "Select at least two splat objects in the Hierarchy.", "OK");
                return;
            }

            int totalSplats = 0;
            foreach (var r in renderers)
                totalSplats += r.splatCount;
            if (totalSplats > GaussianSplatAsset.kMaxSplats)
            {
                EditorUtility.DisplayDialog("Merge Failed", $"Total splat count ({totalSplats:N0}) exceeds the maximum ({GaussianSplatAsset.kMaxSplats:N0}).", "OK");
                return;
            }

            string baseName = m_MergeAssetName.Trim();
            string outputFolder = m_MergeOutputFolder.Trim();
            if (!outputFolder.StartsWith("Assets/"))
            {
                EditorUtility.DisplayDialog("Merge Failed", "Output folder must be inside the project (Assets/...).", "OK");
                return;
            }

            const string kProgressTitle = "Merging Splats";
            var mergedSplats = new List<GaussianSplatAssetCreator.InputSplatData>(totalSplats);
            float maxExportScale = ComputeExportMaxScale();

            try
            {
                for (int i = 0; i < renderers.Count; i++)
                {
                    var renderer = renderers[i];
                    float progress = (float)i / renderers.Count * 0.55f;
                    EditorUtility.DisplayProgressBar(kProgressTitle,
                        $"Reading {renderer.name} ({i + 1}/{renderers.Count})...", progress);

                    if (!CollectAliveSplatsFromRenderer(renderer, mergedSplats, m_MergeBakeWorldTransform, maxExportScale))
                    {
                        EditorUtility.ClearProgressBar();
                        EditorUtility.DisplayDialog("Merge Failed",
                            $"Could not read splat data from '{renderer.name}'. Make sure it has a valid asset.", "OK");
                        return;
                    }
                }

                if (mergedSplats.Count == 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Merge Failed", "No splats to merge (all deleted or filtered).", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle,
                    $"Creating compressed asset ({mergedSplats.Count:N0} splats)...", 0.65f);

                var quality = GetMergeCompressionQuality(m_MergeCompression);
                using var nativeSplats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(
                    mergedSplats.ToArray(), Allocator.TempJob);

                string assetPath = GaussianSplatAssetCreator.CreateAssetFromSplats(nativeSplats, outputFolder, baseName, quality);
                if (string.IsNullOrEmpty(assetPath))
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Merge Failed", "Asset creation failed. Check the Console for details.", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, "Creating merged GameObject...", 0.95f);

                var savedAsset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(assetPath);
                var mergedGo = new GameObject(baseName);
                Undo.RegisterCreatedObjectUndo(mergedGo, "Merge Splats");
                var mergedRenderer = Undo.AddComponent<SplatBoxRenderer>(mergedGo);
                mergedRenderer.m_Asset = savedAsset;
                mergedGo.SetActive(false);
                mergedGo.SetActive(true);

                if (m_MergeDisableSources)
                {
                    foreach (var renderer in renderers)
                    {
                        if (renderer == null) continue;
                        Undo.RecordObject(renderer.gameObject, "Merge Splats");
                        renderer.gameObject.SetActive(false);
                    }
                }

                m_TargetRenderer = mergedRenderer;
                SaveTargetRendererToPrefs(mergedRenderer);
                Selection.activeGameObject = mergedGo;
                SceneView.RepaintAll();

                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Merge Complete",
                    $"Merged {renderers.Count} objects into one asset.\n\n" +
                    $"Splats: {mergedSplats.Count:N0}\n" +
                    $"Quality: {GetMergeCompressionLabel(m_MergeCompression)}\n" +
                    $"Asset: {assetPath}",
                    "OK");

                Debug.Log($"✓ Merged {renderers.Count} splat objects → {assetPath} ({mergedSplats.Count:N0} splats, {quality})");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Merge failed: {ex.Message}\n{ex.StackTrace}");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Merge Failed", ex.Message, "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private bool CollectAliveSplatsFromRenderer(
            SplatBoxRenderer renderer,
            List<GaussianSplatAssetCreator.InputSplatData> output,
            bool bakeTransform,
            float maxExportScale)
        {
            if (renderer == null || !renderer.HasValidAsset || renderer.splatCount <= 0)
                return false;

            int kSplatSize = UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>();
            using var gpuData = new GraphicsBuffer(GraphicsBuffer.Target.Structured, renderer.splatCount, kSplatSize);
            if (!renderer.EditExportData(gpuData, bakeTransform, maxExportScale))
                return false;

            var data = new GaussianSplatAssetCreator.InputSplatData[gpuData.count];
            gpuData.GetData(data);

            var gpuDeleted = renderer.GpuEditDeleted;
            if (gpuDeleted == null)
            {
                for (int i = 0; i < data.Length; i++)
                {
                    if (data[i].nor.sqrMagnitude <= 0)
                        output.Add(data[i]);
                }
                return true;
            }

            uint[] deleted = new uint[gpuDeleted.count];
            gpuDeleted.GetData(deleted);

            for (int i = 0; i < data.Length; i++)
            {
                int wordIdx = i >> 5;
                int bitIdx = i & 31;
                bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                bool isCutout = data[i].nor.sqrMagnitude > 0;
                if (!isDeleted && !isCutout)
                    output.Add(data[i]);
            }

            return true;
        }

        private void DrawHelpSection()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Tool Descriptions", EditorStyles.boldLabel);
            
            // Tab names
            string[] tabNames = new string[] {
                "🔴Erase", "📦Box", "🔄Clone", "🏠Floor", "🔧Patch", "✂️Mask", "🎨Color",
                "🌀Vortex", "🖌️Fill", "✏️Paint", "🖼️Stamp", "👆Smudge", "⭕Cyl", "🌈Colorize", "🎬Anim", "🎥Tilt"
            };
            
            // Draw tabs in two rows
            EditorGUILayout.BeginHorizontal();
            for (int i = 0; i < 8; i++)
            {
                bool selected = m_HelpTabIndex == i;
                GUI.backgroundColor = selected ? COL_ACCENT : Color.white;
                if (GUILayout.Button(tabNames[i], GUILayout.Height(24)))
                    m_HelpTabIndex = i;
            }
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            for (int i = 8; i < tabNames.Length; i++)
            {
                bool selected = m_HelpTabIndex == i;
                GUI.backgroundColor = selected ? COL_ACCENT : Color.white;
                if (GUILayout.Button(tabNames[i], GUILayout.Height(24)))
                    m_HelpTabIndex = i;
            }
            EditorGUILayout.EndHorizontal();
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.Space(4);
            
            // Custom style for help text
            GUIStyle helpTextStyle = new GUIStyle(EditorStyles.helpBox);
            helpTextStyle.fontSize = 11;
            helpTextStyle.wordWrap = true;
            helpTextStyle.padding = new RectOffset(12, 12, 10, 10);
            
            // Draw selected tool help
            switch (m_HelpTabIndex)
            {
                case 0: // Erase
                    GUI.color = COL_DANGER;
                    EditorGUILayout.LabelField("🔴 ERASE BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Delete or restore Gaussian splats with a spherical brush.\n\n" +
                        "• LEFT CLICK: Delete splats\n" +
                        "• RIGHT CLICK: Restore deleted splats\n" +
                        "• SCROLL: Resize brush\n" +
                        "• MIDDLE CLICK: Toggle tool on/off\n\n" +
                        "Use Falloff to create soft edges. Use Noise for organic deletion patterns.",
                        helpTextStyle);
                    break;
                    
                case 1: // Xcopy
                    GUI.color = COL_WARNING;
                    EditorGUILayout.LabelField("📦 XCOPY TOOL", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Copy, paste, and delete splats using 3 selection modes.\n\n" +
                        "MODES:\n" +
                        "• Box Xcopy: 3D box selection\n" +
                        "• Planar Xcopy: 2D floor rectangle (drag to draw)\n" +
                        "• Paint Xcopy: Paint source/target splats\n\n" +
                        "CONTROLS:\n" +
                        "• C: Copy splats in selection\n" +
                        "• V: Paste copied splats\n" +
                        "• DEL: Delete splats in selection\n" +
                        "• X: Delete & Paste (replace)\n\n" +
                        "PLANAR XCOPY:\n" +
                        "• Drag in scene to draw floor rectangle\n" +
                        "• Use handles to move/adjust position\n" +
                        "• Set Floor Y to match your floor height\n\n" +
                        "Use color adjustments to modify pasted splats.",
                        helpTextStyle);
                    break;
                    
                case 2: // Clone
                    GUI.color = COL_CYAN;
                    EditorGUILayout.LabelField("🔄 CLONE BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Clone splats from a polygon selection to a new location.\n\n" +
                        "1. Click to draw SOURCE polygon (min 3 vertices)\n" +
                        "2. Press ENTER to finish polygon\n" +
                        "3. Click to place TARGET position\n" +
                        "4. Press SPACE to execute clone\n\n" +
                        "• BACKSPACE: Undo last vertex\n" +
                        "• RIGHT CLICK: Clear all\n\n" +
                        "Use Depth Offset to move clones forward/backward.",
                        helpTextStyle);
                    break;
                    
                case 3: // Floor Fill
                    GUI.color = COL_SUCCESS;
                    EditorGUILayout.LabelField("🏠 FLOOR FILL", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Fill a floor region with tiled copies of sampled splats.\n\n" +
                        "• F: Execute fill\n" +
                        "• D: Delete fill region\n\n" +
                        "Sample Mode: Choose edge sampling pattern.\n" +
                        "Tile Size: Control grid spacing.\n" +
                        "Jitter: Add random offset for natural look.",
                        helpTextStyle);
                    break;
                    
                case 4: // Patch
                    GUI.color = COL_ACCENT;
                    EditorGUILayout.LabelField("🔧 PATCH TOOL", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Fill target region with patches sampled from source regions.\n\n" +
                        "1. Add source patches (green boxes)\n" +
                        "2. Define target region (red box)\n" +
                        "3. Set grid cell size\n" +
                        "4. Click 'Grid Fill' or 'Delete & Fill'\n\n" +
                        "Randomize Patch: Randomly select from multiple sources.",
                        helpTextStyle);
                    break;
                    
                case 5: // Mask
                    GUI.color = new Color(1f, 0.5f, 1f);
                    EditorGUILayout.LabelField("✂️ POLYGON MASK", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Create polygon cutout masks to hide splats.\n\n" +
                        "• CLICK: Add vertex\n" +
                        "• DOUBLE-CLICK/ENTER: Close polygon\n" +
                        "• RIGHT CLICK: Clear\n\n" +
                        "Shape Type: Use predefined shapes (Rectangle, Circle, etc.)\n" +
                        "Expansion/Offset: Fine-tune cutout boundaries.\n" +
                        "Invert: Flip inside/outside behavior.",
                        helpTextStyle);
                    break;
                    
                case 6: // Color Brush
                    GUI.color = new Color(0.8f, 0.3f, 0.9f);
                    EditorGUILayout.LabelField("🎨 COLOR BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Adjust colors of splats within a box region.\n\n" +
                        "• A: Apply color adjustments\n" +
                        "• R: Reset all adjustments\n\n" +
                        "Exposure: Brighten/darken (-2 to +5).\n" +
                        "Contrast: Adjust contrast (0 to 2, 1=neutral).\n" +
                        "Hue Shift: Rotate colors (-180° to +180°).\n" +
                        "Saturation: Color intensity (0=gray, 2=vivid).\n" +
                        "Color Tint: Multiply with a color.",
                        helpTextStyle);
                    break;
                    
                case 7: // Vortex/Attractor
                    GUI.color = COL_CYAN;
                    EditorGUILayout.LabelField("🌀 ATTRACTOR", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Creates vortex/attract/repel/wave effects on splats.\n\n" +
                        "Modes:\n" +
                        "• Vortex: Swirl splats around center\n" +
                        "• Attract: Pull splats toward center\n" +
                        "• Repel: Push splats away from center\n" +
                        "• Wave: Sine wave distortion with curl\n\n" +
                        "Wave Settings:\n" +
                        "• Frequency: Wave density (0.1-20)\n" +
                        "• Amplitude: Wave height multiplier\n" +
                        "• Speed: Animation speed\n" +
                        "• Axis: Wave direction (X/Y/Z)\n" +
                        "• Curl: Adds rotational twist to waves\n\n" +
                        "Strength: 0.01=slow, 0.1=fast\n" +
                        "Scroll: Adjust range in scene view",
                        helpTextStyle);
                    break;
                    
                case 8: // Fill Brush
                    GUI.color = new Color(0.4f, 0.9f, 0.6f);
                    EditorGUILayout.LabelField("🖌️ FILL BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Draw a polygon, align vertices to hole, then fill.\n\n" +
                        "1. Click to draw polygon vertices\n" +
                        "2. Press ENTER to close polygon\n" +
                        "3. DRAG vertices to align to hole edges\n" +
                        "4. Use center handles to Move/Rotate/Scale\n" +
                        "5. Press F to fill\n\n" +
                        "• DRAG VERTICES: Position each point precisely\n" +
                        "• SCROLL: Adjust overall scale\n" +
                        "• T: Reset transform | D: Delete area\n\n" +
                        "Edge Sample Width: How far from edges to sample.\n" +
                        "Fill Density: Splat density (higher = more).",
                        helpTextStyle);
                    break;
                    
                case 9: // Paint Brush
                    GUI.color = new Color(0.3f, 0.7f, 1f);
                    EditorGUILayout.LabelField("✏️ PAINT BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Paint new Gaussian splats onto surfaces.\n\n" +
                        "CONTROLS:\n" +
                        "• LEFT CLICK + DRAG: Paint splats\n" +
                        "• RIGHT CLICK: Sample colors from existing splats\n" +
                        "• SCROLL: Adjust brush size\n\n" +
                        "SETTINGS:\n" +
                        "• Brush Size: Radius of paint area\n" +
                        "• Splat Size: Size of each created splat\n" +
                        "• Density: Splats per paint stroke\n" +
                        "• GPU Paint: Zero-allocation GPU painting\n" +
                        "• Fast Paint Mode: Caches depth for smoother painting\n\n" +
                        "TEXTURE SLOTS:\n" +
                        "• Load textures into slots 1-3\n" +
                        "• Capture from scene to sample splat colors\n" +
                        "• Use sampled colors for organic blending",
                        helpTextStyle);
                    break;
                    
                case 10: // Texture Stamp
                    GUI.color = new Color(1f, 0.8f, 0.3f);
                    EditorGUILayout.LabelField("🖼️ TEXTURE STAMP", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Stamp a texture as splats onto the scene.\n\n" +
                        "CONTROLS:\n" +
                        "• DRAG: Define stamp rectangle\n" +
                        "• ESC: Cancel stamp\n\n" +
                        "SETTINGS:\n" +
                        "• Resolution: Grid density (8-512)\n" +
                        "• Auto Splat Size: Auto-calculate from stamp size\n" +
                        "• Size Overlap: >1 for solid fill without gaps\n" +
                        "• Opacity: Splat opacity (0.1-2)\n\n" +
                        "BLEND MODES:\n" +
                        "• Replace: Direct texture colors\n" +
                        "• Multiply/Screen/Overlay: Blend with existing\n" +
                        "• Darken/Lighten: Min/max blending\n\n" +
                        "LAYERING:\n" +
                        "• Enable to stack multiple stamps\n" +
                        "• Layer Spacing: Distance between layers\n" +
                        "• Reset Layers: Start new layer stack",
                        helpTextStyle);
                    break;
                    
                case 11: // Smudge
                    GUI.color = new Color(0.6f, 0.4f, 0.8f);
                    EditorGUILayout.LabelField("👆 SMUDGE BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Smudge or pinch splats.\n\n" +
                        "CONTROLS:\n" +
                        "• DRAG: Smudge splats in drag direction\n" +
                        "• SHIFT + DRAG: Pinch splats toward center\n" +
                        "• SCROLL: Adjust brush size\n\n" +
                        "SETTINGS:\n" +
                        "• Brush Size: Radius of effect area\n" +
                        "• Smudge Strength: How much splats move\n" +
                        "• Pinch Strength: How strongly splats pull in\n" +
                        "• Falloff: Soft edges vs hard edges",
                        helpTextStyle);
                    break;
                    
                case 12: // Cylinder
                    GUI.color = new Color(0.9f, 0.5f, 0.3f);
                    EditorGUILayout.LabelField("⭕ CYLINDER BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Erase or restore splats within a cylindrical region.\n\n" +
                        "CONTROLS:\n" +
                        "• LEFT CLICK: Delete splats in cylinder\n" +
                        "• RIGHT CLICK: Restore deleted splats\n" +
                        "• SCROLL: Adjust cylinder radius\n\n" +
                        "SETTINGS:\n" +
                        "• Radius: Cylinder radius\n" +
                        "• Height: Cylinder vertical extent\n" +
                        "• Axis: Cylinder orientation (X/Y/Z)\n\n" +
                        "Useful for cutting through objects or creating holes.",
                        helpTextStyle);
                    break;
                    
                case 13: // Colorize
                    GUI.color = new Color(1f, 0.4f, 0.6f);
                    EditorGUILayout.LabelField("🌈 COLORIZE BRUSH", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Paint colors directly onto existing splats.\n\n" +
                        "CONTROLS:\n" +
                        "• LEFT CLICK + DRAG: Apply color to splats\n" +
                        "• RIGHT CLICK: Sample color from splats\n" +
                        "• SCROLL: Adjust brush size\n\n" +
                        "SETTINGS:\n" +
                        "• Color: Target paint color\n" +
                        "• Opacity: Blend strength (0-1)\n" +
                        "• Brush Size: Radius of effect\n" +
                        "• Falloff: Soft vs hard edge blending\n\n" +
                        "Does not create new splats - only recolors existing ones.",
                        helpTextStyle);
                    break;
                    
                case 14: // Animation
                    GUI.color = new Color(0.3f, 0.9f, 0.9f);
                    EditorGUILayout.LabelField("🎬 ANIMATION PAINT", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Paint velocity animation onto splats.\n\n" +
                        "CONTROLS:\n" +
                        "• LEFT CLICK + DRAG: Apply velocity to splats\n" +
                        "• Direction follows brush stroke\n\n" +
                        "SETTINGS:\n" +
                        "• Speed: Velocity magnitude\n" +
                        "• Brush Size: Effect radius\n" +
                        "• Direction Mode: Stroke-based or fixed axis\n" +
                        "• Disable Gravity: Horizontal flow only\n\n" +
                        "STYLES:\n" +
                        "• Constant: Uniform velocity\n" +
                        "• Turbulent: Noisy, chaotic motion\n" +
                        "• Orbital: Circular flow patterns\n" +
                        "• Ripple: Radial wave motion\n\n" +
                        "RECORDING:\n" +
                        "• Start Recording to capture animation\n" +
                        "• Export keyframes as positions over time",
                        helpTextStyle);
                    break;
                    
                case 15: // Tilt-Shift
                    GUI.color = new Color(0.6f, 0.3f, 0.7f);
                    EditorGUILayout.LabelField("🎥 TILT-SHIFT", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    GUILayout.Label(
                        "Apply miniature/blur effects to Scene View.\n\n" +
                        "MODES:\n" +
                        "• Tilt-Shift: Horizontal blur bands\n" +
                        "• DoF: Depth-based focus blur\n" +
                        "• Combined: Both effects together\n\n" +
                        "TILT-SHIFT SETTINGS:\n" +
                        "• Focus Center: Vertical focus position\n" +
                        "• Band Width: Size of sharp region\n" +
                        "• Blur Amount: Blur intensity\n\n" +
                        "DoF SETTINGS:\n" +
                        "• Focus Distance: Sharp depth plane\n" +
                        "• Near/Far Start: Blur transition points\n\n" +
                        "Toggle on/off from toolbar button.",
                        helpTextStyle);
                    break;
            }
            
            EditorGUILayout.EndVertical();
        }

        /// <summary>
        /// Computes the max object-space splat scale allowed on export, based on the scene bounds
        /// and the user's spike-filter fraction. Returns 0 to disable filtering (when off or invalid).
        /// </summary>
        private float ComputeExportMaxScale()
        {
            if (!m_ExportFilterSpikes || m_TargetRenderer == null || m_TargetRenderer.asset == null)
                return 0f;

            var asset = m_TargetRenderer.asset;
            float diagonal = (asset.boundsMax - asset.boundsMin).magnitude;
            if (diagonal <= 0f || float.IsNaN(diagonal) || float.IsInfinity(diagonal))
                return 0f;

            return diagonal * m_ExportSpikeScaleFraction;
        }

        private unsafe void ExportPlyFile()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;
            
            var path = EditorUtility.SaveFilePanel(
                "Export Gaussian Splat PLY file", "", $"{m_TargetRenderer.asset.name}-edit.ply", "ply");
            if (string.IsNullOrWhiteSpace(path))
                return;

            const string kProgressTitle = "Exporting PLY";
            try
            {
                EditorUtility.DisplayProgressBar(kProgressTitle, "Reading splat data from GPU...", 0.1f);

                int kSplatSize = UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>();
                using var gpuData = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_TargetRenderer.splatCount, kSplatSize);

                if (!m_TargetRenderer.EditExportData(gpuData, m_ExportBakeTransform, ComputeExportMaxScale()))
                    return;

                GaussianSplatAssetCreator.InputSplatData[] data = new GaussianSplatAssetCreator.InputSplatData[gpuData.count];
                gpuData.GetData(data);

                var gpuDeleted = m_TargetRenderer.GpuEditDeleted;
                uint[] deleted = new uint[gpuDeleted.count];
                gpuDeleted.GetData(deleted);

                EditorUtility.DisplayProgressBar(kProgressTitle, "Counting splats...", 0.4f);

                // Count non-deleted splats
                int aliveCount = 0;
                for (int i = 0; i < data.Length; ++i)
                {
                    int wordIdx = i >> 5;
                    int bitIdx = i & 31;
                    bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                    bool isCutout = data[i].nor.sqrMagnitude > 0;
                    if (!isDeleted && !isCutout)
                        ++aliveCount;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, $"Writing {aliveCount:N0} splats to file...", 0.6f);

                using (FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write))
                {
                    var header = $"ply\nformat binary_little_endian 1.0\nelement vertex {aliveCount}\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\nproperty float f_dc_0\nproperty float f_dc_1\nproperty float f_dc_2\nproperty float f_rest_0\nproperty float f_rest_1\nproperty float f_rest_2\nproperty float f_rest_3\nproperty float f_rest_4\nproperty float f_rest_5\nproperty float f_rest_6\nproperty float f_rest_7\nproperty float f_rest_8\nproperty float f_rest_9\nproperty float f_rest_10\nproperty float f_rest_11\nproperty float f_rest_12\nproperty float f_rest_13\nproperty float f_rest_14\nproperty float f_rest_15\nproperty float f_rest_16\nproperty float f_rest_17\nproperty float f_rest_18\nproperty float f_rest_19\nproperty float f_rest_20\nproperty float f_rest_21\nproperty float f_rest_22\nproperty float f_rest_23\nproperty float f_rest_24\nproperty float f_rest_25\nproperty float f_rest_26\nproperty float f_rest_27\nproperty float f_rest_28\nproperty float f_rest_29\nproperty float f_rest_30\nproperty float f_rest_31\nproperty float f_rest_32\nproperty float f_rest_33\nproperty float f_rest_34\nproperty float f_rest_35\nproperty float f_rest_36\nproperty float f_rest_37\nproperty float f_rest_38\nproperty float f_rest_39\nproperty float f_rest_40\nproperty float f_rest_41\nproperty float f_rest_42\nproperty float f_rest_43\nproperty float f_rest_44\nproperty float opacity\nproperty float scale_0\nproperty float scale_1\nproperty float scale_2\nproperty float rot_0\nproperty float rot_1\nproperty float rot_2\nproperty float rot_3\nend_header\n";
                    fs.Write(Encoding.UTF8.GetBytes(header));

                    for (int i = 0; i < data.Length; ++i)
                    {
                        int wordIdx = i >> 5;
                        int bitIdx = i & 31;
                        bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                        bool isCutout = data[i].nor.sqrMagnitude > 0;
                        if (!isDeleted && !isCutout)
                        {
                            var splat = data[i];
                            byte* ptr = (byte*)&splat;
                            fs.Write(new ReadOnlySpan<byte>(ptr, kSplatSize));
                        }
                    }
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, "Finalizing...", 1f);

                // Get file size
                var fileInfo = new FileInfo(path);
                string sizeStr = FormatFileSize(fileInfo.Length);

                Debug.Log($"✓ Exported PLY: {Path.GetFileName(path)} with {aliveCount:N0} splats ({sizeStr})");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Export Complete", 
                    $"PLY file exported successfully!\n\n" +
                    $"File: {Path.GetFileName(path)}\n" +
                    $"Splats: {aliveCount:N0}\n" +
                    $"Size: {sizeStr}\n\n" +
                    $"Location:\n{path}", "OK");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"PLY Export failed: {ex.Message}");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Export Failed", $"Failed to export PLY file:\n\n{ex.Message}", "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
        
        private void ExportSpzFile()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;
            
            var path = EditorUtility.SaveFilePanel(
                "Export Gaussian Splat SPZ file", "", $"{m_TargetRenderer.asset.name}-edit.spz", "spz");
            if (string.IsNullOrWhiteSpace(path))
                return;

            const string kProgressTitle = "Exporting SPZ";
            try
            {
                EditorUtility.DisplayProgressBar(kProgressTitle, "Reading splat data from GPU...", 0.1f);

                int kSplatSize = UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>();
                using var gpuData = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_TargetRenderer.splatCount, kSplatSize);

                if (!m_TargetRenderer.EditExportData(gpuData, m_ExportBakeTransform, ComputeExportMaxScale()))
                    return;

                GaussianSplatAssetCreator.InputSplatData[] data = new GaussianSplatAssetCreator.InputSplatData[gpuData.count];
                gpuData.GetData(data);

                var gpuDeleted = m_TargetRenderer.GpuEditDeleted;
                uint[] deleted = new uint[gpuDeleted.count];
                gpuDeleted.GetData(deleted);

                EditorUtility.DisplayProgressBar(kProgressTitle, "Counting splats...", 0.4f);

                // Count non-deleted splats and collect alive indices
                var aliveIndices = new System.Collections.Generic.List<int>();
                for (int i = 0; i < data.Length; ++i)
                {
                    int wordIdx = i >> 5;
                    int bitIdx = i & 31;
                    bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                    bool isCutout = data[i].nor.sqrMagnitude > 0;
                    if (!isDeleted && !isCutout)
                        aliveIndices.Add(i);
                }

                int aliveCount = aliveIndices.Count;
                if (aliveCount == 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Export Failed", "No splats to export - all splats are deleted.", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, $"Compressing and writing {aliveCount:N0} splats...", 0.6f);

                WriteSPZFile(path, data, aliveIndices);

                EditorUtility.DisplayProgressBar(kProgressTitle, "Finalizing...", 1f);

                // Get file size
                var fileInfo = new FileInfo(path);
                string sizeStr = FormatFileSize(fileInfo.Length);

                Debug.Log($"✓ Exported SPZ: {Path.GetFileName(path)} with {aliveCount:N0} splats ({sizeStr})");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Export Complete", 
                    $"SPZ file exported successfully!\n\n" +
                    $"File: {Path.GetFileName(path)}\n" +
                    $"Splats: {aliveCount:N0}\n" +
                    $"Size: {sizeStr}\n\n" +
                    $"Location:\n{path}", "OK");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"SPZ Export failed: {ex.Message}");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Export Failed", $"Failed to export SPZ file:\n\n{ex.Message}", "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }
        
        private void WriteSPZFile(string path, GaussianSplatAssetCreator.InputSplatData[] data, System.Collections.Generic.List<int> aliveIndices)
        {
            int numPoints = aliveIndices.Count;
            
            // SPZ format settings
            const int shLevel = 0; // DC only (no higher order SH for now)
            const int fractBits = 11; // Position precision
            const int flags = 0;
            
            // Prepare packed data arrays
            byte[] packedPos = new byte[numPoints * 9];   // 3 components × 24-bit
            byte[] packedScale = new byte[numPoints * 3];
            byte[] packedRot = new byte[numPoints * 3];
            byte[] packedAlpha = new byte[numPoints];
            byte[] packedCol = new byte[numPoints * 3];
            
            float fractScale = 1 << fractBits;
            
            for (int idx = 0; idx < numPoints; idx++)
            {
                var splat = data[aliveIndices[idx]];
                
                // Pack position as 24-bit signed fixed point
                PackPosition(splat.pos, idx, packedPos, fractScale);
                
                // Pack scale (convert from log scale to quantized format)
                Vector3 logScale = splat.scale;
                packedScale[idx * 3 + 0] = (byte)Mathf.Clamp((logScale.x + 10.0f) * 16.0f, 0, 255);
                packedScale[idx * 3 + 1] = (byte)Mathf.Clamp((logScale.y + 10.0f) * 16.0f, 0, 255);
                packedScale[idx * 3 + 2] = (byte)Mathf.Clamp((logScale.z + 10.0f) * 16.0f, 0, 255);
                
                // Pack rotation. The export kernel writes the quaternion in PLY order (w,x,y,z) into the
                // struct, so splat.rot holds (x=w, y=x, z=y, w=z). Rebuild the true (x,y,z,w) quaternion.
                // SPZ stores the imaginary parts (x,y,z) and reconstructs w >= 0 on load.
                float qw = splat.rot.x;
                Quaternion q = new Quaternion(splat.rot.y, splat.rot.z, splat.rot.w, qw);
                q = Quaternion.Normalize(q);
                // Ensure w is non-negative so the import-time sqrt reconstruction recovers it
                if (q.w < 0) { q.x = -q.x; q.y = -q.y; q.z = -q.z; q.w = -q.w; }
                packedRot[idx * 3 + 0] = (byte)Mathf.Clamp((q.x + 1.0f) * 127.5f, 0, 255);
                packedRot[idx * 3 + 1] = (byte)Mathf.Clamp((q.y + 1.0f) * 127.5f, 0, 255);
                packedRot[idx * 3 + 2] = (byte)Mathf.Clamp((q.z + 1.0f) * 127.5f, 0, 255);
                
                // Pack opacity (apply sigmoid, then quantize)
                float sigmoid = 1.0f / (1.0f + Mathf.Exp(-splat.opacity));
                packedAlpha[idx] = (byte)Mathf.Clamp(sigmoid * 255.0f, 0, 255);
                
                // Pack color (DC0 SH coefficient)
                Vector3 col = splat.dc0 * 0.15f + new Vector3(0.5f, 0.5f, 0.5f);
                packedCol[idx * 3 + 0] = (byte)Mathf.Clamp(col.x * 255.0f, 0, 255);
                packedCol[idx * 3 + 1] = (byte)Mathf.Clamp(col.y * 255.0f, 0, 255);
                packedCol[idx * 3 + 2] = (byte)Mathf.Clamp(col.z * 255.0f, 0, 255);
            }
            
            // Write SPZ file (gzip compressed)
            using var fs = File.Create(path);
            using var gz = new System.IO.Compression.GZipStream(fs, System.IO.Compression.CompressionLevel.Optimal);
            
            // Write header
            uint sh_fracbits_flags = (uint)(shLevel | (fractBits << 8) | (flags << 16));
            byte[] header = new byte[16];
            // Magic: "NGSP" = 0x5053474E
            header[0] = 0x4E; header[1] = 0x47; header[2] = 0x53; header[3] = 0x50;
            // Version: 2
            header[4] = 2; header[5] = 0; header[6] = 0; header[7] = 0;
            // NumPoints
            header[8] = (byte)(numPoints & 0xFF);
            header[9] = (byte)((numPoints >> 8) & 0xFF);
            header[10] = (byte)((numPoints >> 16) & 0xFF);
            header[11] = (byte)((numPoints >> 24) & 0xFF);
            // sh_fracbits_flags
            header[12] = (byte)(sh_fracbits_flags & 0xFF);
            header[13] = (byte)((sh_fracbits_flags >> 8) & 0xFF);
            header[14] = (byte)((sh_fracbits_flags >> 16) & 0xFF);
            header[15] = (byte)((sh_fracbits_flags >> 24) & 0xFF);
            gz.Write(header, 0, 16);
            
            // Write data in SPZ order (already interleaved, no transpose needed for writing)
            gz.Write(packedPos, 0, packedPos.Length);
            gz.Write(packedAlpha, 0, packedAlpha.Length);
            gz.Write(packedCol, 0, packedCol.Length);
            gz.Write(packedScale, 0, packedScale.Length);
            gz.Write(packedRot, 0, packedRot.Length);
            // No SH data for shLevel=0
        }
        
        private void PackPosition(Vector3 pos, int idx, byte[] packed, float fractScale)
        {
            int[] fixedPos = new int[3];
            fixedPos[0] = Mathf.RoundToInt(pos.x * fractScale);
            fixedPos[1] = Mathf.RoundToInt(pos.y * fractScale);
            fixedPos[2] = Mathf.RoundToInt(pos.z * fractScale);
            
            for (int c = 0; c < 3; c++)
            {
                int fx = fixedPos[c];
                // Clamp to 24-bit signed range
                fx = Mathf.Clamp(fx, -8388608, 8388607);
                int baseIdx = idx * 9 + c * 3;
                packed[baseIdx + 0] = (byte)(fx & 0xFF);
                packed[baseIdx + 1] = (byte)((fx >> 8) & 0xFF);
                packed[baseIdx + 2] = (byte)((fx >> 16) & 0xFF);
            }
        }
        
        private string FormatFileSize(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{bytes / 1024.0:F1} KB";
            if (bytes < 1024 * 1024 * 1024) return $"{bytes / (1024.0 * 1024.0):F1} MB";
            return $"{bytes / (1024.0 * 1024.0 * 1024.0):F2} GB";
        }

        private void DrawStatusBar()
        {
            string status = "Ready";
            Color statusColor = Color.white;
            
            if (m_TargetRenderer == null)
            {
                status = "⚠ No renderer selected";
                statusColor = COL_WARNING;
            }
            else if (!m_TargetRenderer.HasValidAsset)
            {
                status = "⚠ Renderer has no valid asset";
                statusColor = COL_WARNING;
            }
            else if (m_IsToolActive)
            {
                status = $"● {m_CurrentTool} ACTIVE - Press ESC to stop";
                statusColor = COL_ACCENT;
            }
            else if (m_CurrentTool != BrushTool.None)
            {
                status = $"○ {m_CurrentTool} selected - Press START to activate";
                statusColor = COL_SUCCESS;
            }
            
            GUI.color = statusColor;
            EditorGUILayout.LabelField(status, s_StatusStyle);
            GUI.color = Color.white;
        }

        private void DrawToolControls(string controls)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            GUI.color = new Color(0.8f, 0.8f, 0.8f);
            EditorGUILayout.LabelField("Controls:", EditorStyles.miniBoldLabel);
            EditorGUILayout.LabelField(controls, EditorStyles.wordWrappedMiniLabel);
            GUI.color = Color.white;
            EditorGUILayout.EndVertical();
        }

        private bool DrawFoldoutHeader(string title, bool expanded, Color bgColor)
        {
            var rect = EditorGUILayout.GetControlRect(false, 22);
            EditorGUI.DrawRect(rect, bgColor);
            
            var foldoutRect = new Rect(rect.x + 4, rect.y, 16, rect.height);
            var labelRect = new Rect(rect.x + 18, rect.y, rect.width - 22, rect.height);
            
            GUI.color = Color.white;
            EditorGUI.LabelField(labelRect, title, s_HeaderStyle);
            
            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                expanded = !expanded;
                Event.current.Use();
                Repaint();
            }
            
            EditorGUI.LabelField(foldoutRect, expanded ? "▼" : "▶", s_HeaderStyle);
            
            return expanded;
        }

        private void HandleKeyboardShortcuts()
        {
            Event e = Event.current;
            if (e.type != EventType.KeyDown) return;
            
            // Number keys to switch tools
            if (e.keyCode == KeyCode.Alpha1) { SelectTool(BrushTool.EraseBrush); e.Use(); }
            if (e.keyCode == KeyCode.Alpha2) { SelectTool(BrushTool.BoxBrush); e.Use(); }
            if (e.keyCode == KeyCode.Alpha3) { SelectTool(BrushTool.CloneBrush); e.Use(); }
            if (e.keyCode == KeyCode.Alpha4) { SelectTool(BrushTool.PatchTool); e.Use(); }
            if (e.keyCode == KeyCode.Alpha5) { SelectTool(BrushTool.PolyMask); e.Use(); }
            if (e.keyCode == KeyCode.Alpha6) { SelectTool(BrushTool.ColorBrush); e.Use(); }
            if (e.keyCode == KeyCode.Alpha7) { SelectTool(BrushTool.VortexTool); e.Use(); }
            if (e.keyCode == KeyCode.Alpha8) { SelectTool(BrushTool.FillBrush); e.Use(); }
            if (e.keyCode == KeyCode.Alpha9) { SelectTool(BrushTool.PaintBrush); e.Use(); }
            if (e.keyCode == KeyCode.Alpha0) { SelectTool(BrushTool.TextureStamp); e.Use(); }
            
            // Tool-specific shortcuts (work even when Editor Window has focus)
            if (m_IsToolActive)
            {
                // BoxBrush shortcuts
                if (m_CurrentTool == BrushTool.BoxBrush && m_BoxBrush != null)
                {
                    if (e.keyCode == KeyCode.C) { m_BoxBrush.CopySplats(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.V && m_BoxBrush.CanPaste) { m_BoxBrush.PasteSplats(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.Delete) { m_BoxBrush.DeleteSplatsInBox(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.X && m_BoxBrush.CanPaste) { m_BoxBrush.DeleteAndPaste(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.R) { m_BoxBrush.ClearCopiedData(); e.Use(); SceneView.RepaintAll(); }
                }
                
                // CylinderBrush shortcuts
                if (m_CurrentTool == BrushTool.CylinderBrush && m_CylinderBrush != null)
                {
                    if (e.keyCode == KeyCode.Delete) { m_CylinderBrush.DeleteCurrentPrimitive(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.R && e.shift) { m_CylinderBrush.RestoreCurrentPrimitive(); e.Use(); SceneView.RepaintAll(); }
                }
                
                // FillBrush shortcuts
                if (m_CurrentTool == BrushTool.FillBrush && m_FillBrush != null)
                {
                    if (e.keyCode == KeyCode.F && m_FillBrush.CanFill) { m_FillBrush.ExecuteFill(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.D && m_FillBrush.HasValidPolygon) { m_FillBrush.DeletePolygonArea(); e.Use(); SceneView.RepaintAll(); }
                }
                
                // ColorBrush shortcuts
                if (m_CurrentTool == BrushTool.ColorBrush && m_ColorBrush != null)
                {
                    if ((e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) && m_ColorBrush.HasAdjustments && m_ColorBrush.IsValid)
                    { m_ColorBrush.ApplyColorAdjustments(); e.Use(); SceneView.RepaintAll(); }
                }
                
                // FloorFill shortcuts
                if (m_CurrentTool == BrushTool.FloorFill && m_FloorFillBrush != null)
                {
                    if (e.keyCode == KeyCode.F && m_FloorFillBrush.IsValid) { m_FloorFillBrush.ExecuteFill(); e.Use(); SceneView.RepaintAll(); }
                    if (e.keyCode == KeyCode.D) { m_FloorFillBrush.DeleteFillRegion(); e.Use(); SceneView.RepaintAll(); }
                }
            }
            
            // Escape to deactivate
            if (e.keyCode == KeyCode.Escape && m_IsToolActive)
            {
                DeactivateCurrentTool();
                e.Use();
            }
        }

        private void SelectTool(BrushTool tool)
        {
            if (m_CurrentTool == tool)
            {
                if (m_IsToolActive)
                    DeactivateCurrentTool();
                else
                    ActivateCurrentTool();
            }
            else
            {
                DeactivateCurrentTool();
                m_CurrentTool = tool;
                
                // Reset BoxBrush to defaults when selecting it
                if (tool == BrushTool.BoxBrush && m_BoxBrush != null)
                {
                    m_BoxBrush.ResetAll();
                }
            }
            Repaint();
        }

        private void ActivateCurrentTool()
        {
            if (m_CurrentTool == BrushTool.None) return;
            
            CreateToolGameObject(m_CurrentTool);
            
            // Ensure brush values are loaded from preferences (for EraseBrush)
            // This ensures the saved ScreenRadius is restored even if component already existed
            if (m_CurrentTool == BrushTool.EraseBrush && m_EraseBrush != null)
            {
                m_EraseBrush.ReloadScreenRadius();
            }
            
            m_IsToolActive = true;
            
            // Hide Unity's default transform handles for custom gizmo tools
            // so they don't appear on the selected SplatBoxRenderer
            if (m_CurrentTool == BrushTool.CylinderBrush || m_CurrentTool == BrushTool.BoxBrush)
            {
                Tools.hidden = true;
            }
            else
            {
                Tools.current = Tool.None;
            }
            
            switch (m_CurrentTool)
            {
                case BrushTool.EraseBrush:
                    GaussianSplatBrush.IsBrushModeActive = true;
                    break;
                case BrushTool.BoxBrush:
                    GaussianSplatBoxBrush.IsBrushModeActive = true;
                    break;
                case BrushTool.CloneBrush:
                    GaussianSplatCloneBrush.IsBrushModeActive = true;
                    break;
                case BrushTool.FloorFill:
                    GaussianSplatFloorFillBrush.IsBrushModeActive = true;
                    break;
                case BrushTool.PatchTool:
                    GaussianSplatPatchTool.IsBrushModeActive = true;
                    break;
                case BrushTool.PolyMask:
                    // PolyMask doesn't have static flag, handled via instance
                    break;
                case BrushTool.ColorBrush:
                    GaussianSplatColorBrush.IsBrushModeActive = true;
                    break;
                case BrushTool.VortexTool:
                    // Enable wind on renderer (required for attractors to work)
                    if (m_TargetRenderer != null)
                        m_TargetRenderer.enableWind = true;
                    // Enable the attractor
                    if (m_VortexAttractor != null)
                    {
                        var so = new SerializedObject(m_VortexAttractor);
                        so.FindProperty("m_AttractorEnabled").boolValue = true;
                        so.ApplyModifiedProperties();
                        m_VortexAttractor.EnsureRegistered();
                    }
                    break;
                case BrushTool.FillBrush:
                    GaussianSplatFillBrush.IsBrushModeActive = true;
                    break;
                case BrushTool.PaintBrush:
                    if (m_PaintBrushMode == 0)
                        GaussianSplatPaintBrush.IsBrushModeActive = true;
                    else if (m_PaintBrushMode == 1)
                        GaussianSplatColorizeBrush.IsBrushModeActive = true;
                    // Mode 2 (Animation) doesn't need a special brush mode flag
                    break;
                case BrushTool.CylinderBrush:
                    GaussianSplatCylinderBrush.IsBrushModeActive = true;
                    break;
            }
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void DeactivateCurrentTool()
        {
            m_IsToolActive = false;
            
            // Restore Unity's default transform handles
            Tools.hidden = false;
            
            GaussianSplatBrush.IsBrushModeActive = false;
            GaussianSplatBrush.HasValidBrushPosition = false;
            GaussianSplatBrush.IsDeleting = false;
            GaussianSplatBrush.IsRestoring = false;
            GaussianSplatBrush.IsLineMode = false;
            
            // Note: ScreenRadius is now persisted and will be restored when tool is reactivated
            // Other brush values are reset to defaults
            if (m_EraseBrush != null)
            {
                m_EraseBrush.BrushFalloff = 0f;
                m_EraseBrush.NoiseStrength = 0f;
                m_EraseBrush.NoiseScale = 1f;
            }
            
            GaussianSplatBoxBrush.IsBrushModeActive = false;
            GaussianSplatBoxBrush.HasValidBrushPosition = false;
            
            // Reset paint selections when switching away from BoxBrush tool
            if (m_BoxBrush != null)
            {
                m_BoxBrush.ResetPaintSelections();
            }
            
            GaussianSplatCloneBrush.IsBrushModeActive = false;
            GaussianSplatCloneBrush.HasValidBrushPosition = false;
            
            GaussianSplatFloorFillBrush.IsBrushModeActive = false;
            
            GaussianSplatPatchTool.IsBrushModeActive = false;
            
            GaussianSplatColorBrush.IsBrushModeActive = false;
            GaussianSplatColorBrush.HasValidBrushPosition = false;
            
            GaussianSplatColorizeBrush.IsBrushModeActive = false;
            GaussianSplatColorizeBrush.HasValidBrushPosition = false;
            GaussianSplatColorizeBrush.IsColorizing = false;
            GaussianSplatColorizeBrush.IsSampling = false;
            m_IsColorizeStrokeActive = false;
            
            GaussianSplatFillBrush.IsBrushModeActive = false;
            GaussianSplatFillBrush.HasValidBrushPosition = false;
            
            GaussianSplatPaintBrush.IsBrushModeActive = false;
            GaussianSplatPaintBrush.HasValidBrushPosition = false;
            GaussianSplatPaintBrush.IsPainting = false;
            GaussianSplatPaintBrush.IsSampling = false;
            m_IsPaintStrokeActive = false;
            
            GaussianSplatCylinderBrush.IsBrushModeActive = false;
            GaussianSplatCylinderBrush.HasValidBrushPosition = false;
            
            // Reset primitives tool when disabling
            if (m_CurrentTool == BrushTool.CylinderBrush && m_CylinderBrush != null)
            {
                m_CylinderBrush.ResetCurrentPrimitive();
            }
            
            // Reset paint brush buffer state for next activation
            if (m_PaintBrush != null)
                m_PaintBrush.ResetBufferState();
            
            // Reset sculpt brush states
            m_IsSmudging = false;
            m_IsPinching = false;
            m_IsMoving = false;
            m_IsFlattening = false;
            m_IsRelaxing = false;
            m_IsRoughening = false;
            m_IsRestoringSculpt = false;
            m_MoveConstrainLine = false;
            m_MoveConstraintAxis = Vector3.zero;
            m_FlattenPlaneNormal = Vector3.zero;
            m_SmudgeHasCachedSurface = false;
            m_SmudgeAccumulatedDelta = Vector3.zero;
            
            // Reset vertex dragging state
            m_DraggingVertexIndex = -1;
            
            // Reset color brush values
            if (m_ColorBrush != null)
            {
                m_ColorBrush.ResetColorAdjustments();
                m_ColorBrush.BoxPosition = Vector3.zero;
                m_ColorBrush.BoxSize = Vector3.one;
            }
            
            // Reset fill brush
            if (m_FillBrush != null)
                m_FillBrush.Clear();
            
            // Disable and reset vortex attractor when deactivating VortexTool
            if (m_CurrentTool == BrushTool.VortexTool && m_VortexAttractor != null)
            {
                var so = new SerializedObject(m_VortexAttractor);
                so.FindProperty("m_AttractorEnabled").boolValue = false;
                so.FindProperty("m_Mode").enumValueIndex = 0; // Vortex
                so.FindProperty("m_Strength").floatValue = 0.02f;
                so.FindProperty("m_Range").floatValue = 2f;
                so.FindProperty("m_Scale").floatValue = 1f;
                so.FindProperty("m_Falloff").floatValue = 1f;
                so.FindProperty("m_VortexHeight").floatValue = 0f;
                so.FindProperty("m_WaveFrequency").floatValue = 2f;
                so.FindProperty("m_WaveAmplitude").floatValue = 1f;
                so.FindProperty("m_WaveSpeed").floatValue = 3f;
                so.FindProperty("m_WaveAxis").intValue = 1;
                so.FindProperty("m_CurlStrength").floatValue = 0f;
                so.FindProperty("m_SecondaryFrequency").floatValue = 0f;
                so.ApplyModifiedProperties();
            }
            
            SceneView.RepaintAll();
        }

        private void FindOrCreateToolComponents()
        {
            // Find existing or get from holder
            var holder = FindOrCreateToolHolder();
            
            m_EraseBrush = holder.GetComponentInChildren<GaussianSplatBrush>();
            m_BoxBrush = holder.GetComponentInChildren<GaussianSplatBoxBrush>();
            m_CloneBrush = holder.GetComponentInChildren<GaussianSplatCloneBrush>();
            m_FloorFillBrush = holder.GetComponentInChildren<GaussianSplatFloorFillBrush>();
            m_PatchTool = holder.GetComponentInChildren<GaussianSplatPatchTool>();
            m_PolyMask = holder.GetComponentInChildren<GaussianPolyMask>();
            m_ColorBrush = holder.GetComponentInChildren<GaussianSplatColorBrush>();
            m_FillBrush = holder.GetComponentInChildren<GaussianSplatFillBrush>();
            m_PaintBrush = holder.GetComponentInChildren<GaussianSplatPaintBrush>();
            m_CylinderBrush = holder.GetComponentInChildren<GaussianSplatCylinderBrush>();
            m_ColorizeBrush = holder.GetComponentInChildren<GaussianSplatColorizeBrush>();
            
            // Find vortex attractor (may be standalone object)
            if (m_VortexAttractor == null)
                m_VortexAttractor = FindAnyObjectByType<GaussianSplatAttractor>();
            
            SyncRendererToTools();
        }

        private GameObject FindOrCreateToolHolder()
        {
            var holder = GameObject.Find("_SplatEditorTools");
            if (holder == null)
            {
                holder = new GameObject("_SplatEditorTools");
                holder.hideFlags = HideFlags.HideInHierarchy;
            }
            return holder;
        }

        private void CreateToolGameObject(BrushTool tool)
        {
            var holder = FindOrCreateToolHolder();
            
            switch (tool)
            {
                case BrushTool.EraseBrush:
                    if (m_EraseBrush == null)
                    {
                        var go = new GameObject("EraseBrush");
                        go.transform.SetParent(holder.transform);
                        m_EraseBrush = go.AddComponent<GaussianSplatBrush>();
                        m_EraseBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.BoxBrush:
                    if (m_BoxBrush == null)
                    {
                        var go = new GameObject("BoxBrush");
                        go.transform.SetParent(holder.transform);
                        m_BoxBrush = go.AddComponent<GaussianSplatBoxBrush>();
                        m_BoxBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.CloneBrush:
                    if (m_CloneBrush == null)
                    {
                        var go = new GameObject("CloneBrush");
                        go.transform.SetParent(holder.transform);
                        m_CloneBrush = go.AddComponent<GaussianSplatCloneBrush>();
                        m_CloneBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.FloorFill:
                    if (m_FloorFillBrush == null)
                    {
                        var go = new GameObject("FloorFillBrush");
                        go.transform.SetParent(holder.transform);
                        m_FloorFillBrush = go.AddComponent<GaussianSplatFloorFillBrush>();
                        m_FloorFillBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.PatchTool:
                    if (m_PatchTool == null)
                    {
                        var go = new GameObject("PatchTool");
                        go.transform.SetParent(holder.transform);
                        m_PatchTool = go.AddComponent<GaussianSplatPatchTool>();
                        m_PatchTool.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.PolyMask:
                    if (m_PolyMask == null)
                    {
                        var go = new GameObject("PolyMask");
                        go.transform.SetParent(holder.transform);
                        m_PolyMask = go.AddComponent<GaussianPolyMask>();
                    }
                    break;
                case BrushTool.ColorBrush:
                    if (m_ColorBrush == null)
                    {
                        var go = new GameObject("ColorBrush");
                        go.transform.SetParent(holder.transform);
                        m_ColorBrush = go.AddComponent<GaussianSplatColorBrush>();
                        m_ColorBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.FillBrush:
                    if (m_FillBrush == null)
                    {
                        var go = new GameObject("FillBrush");
                        go.transform.SetParent(holder.transform);
                        m_FillBrush = go.AddComponent<GaussianSplatFillBrush>();
                        m_FillBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.PaintBrush:
                    if (m_PaintBrush == null)
                    {
                        var go = new GameObject("PaintBrush");
                        go.transform.SetParent(holder.transform);
                        m_PaintBrush = go.AddComponent<GaussianSplatPaintBrush>();
                        m_PaintBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
                case BrushTool.VortexTool:
                    if (m_VortexAttractor == null)
                    {
                        var go = new GameObject("VortexAttractor");
                        go.transform.SetParent(holder.transform);
                        m_VortexAttractor = go.AddComponent<GaussianSplatAttractor>();
                        
                        // Position at renderer center
                        if (m_TargetRenderer != null)
                            go.transform.position = m_TargetRenderer.GetWorldBounds().center;
                        
                        // Set initial values - slow defaults
                        var so = new SerializedObject(m_VortexAttractor);
                        so.FindProperty("m_Mode").enumValueIndex = 0; // Vortex
                        so.FindProperty("m_Strength").floatValue = 0.02f;
                        so.FindProperty("m_Range").floatValue = 2f;
                        so.FindProperty("m_Falloff").floatValue = 1f;
                        so.FindProperty("m_DrawGizmos").boolValue = false;
                        so.ApplyModifiedProperties();
                    }
                    else
                    {
                        // Disable built-in gizmos - we draw our own
                        var so = new SerializedObject(m_VortexAttractor);
                        if (so.FindProperty("m_DrawGizmos").boolValue)
                        {
                            so.FindProperty("m_DrawGizmos").boolValue = false;
                            so.ApplyModifiedProperties();
                        }
                    }
                    break;
                case BrushTool.CylinderBrush:
                    if (m_CylinderBrush == null)
                    {
                        var go = new GameObject("CylinderBrush");
                        go.transform.SetParent(holder.transform);
                        m_CylinderBrush = go.AddComponent<GaussianSplatCylinderBrush>();
                        m_CylinderBrush.TargetRenderer = m_TargetRenderer;
                        
                        // Position at renderer center
                        if (m_TargetRenderer != null)
                            m_CylinderBrush.Position = m_TargetRenderer.GetWorldBounds().center;
                    }
                    break;
                case BrushTool.ColorizeBrush:
                    if (m_ColorizeBrush == null)
                    {
                        var go = new GameObject("ColorizeBrush");
                        go.transform.SetParent(holder.transform);
                        m_ColorizeBrush = go.AddComponent<GaussianSplatColorizeBrush>();
                        m_ColorizeBrush.TargetRenderer = m_TargetRenderer;
                    }
                    break;
            }
        }

        private void SyncRendererToTools()
        {
            if (m_EraseBrush != null) m_EraseBrush.TargetRenderer = m_TargetRenderer;
            if (m_BoxBrush != null) m_BoxBrush.TargetRenderer = m_TargetRenderer;
            if (m_CloneBrush != null) m_CloneBrush.TargetRenderer = m_TargetRenderer;
            if (m_FloorFillBrush != null) m_FloorFillBrush.TargetRenderer = m_TargetRenderer;
            if (m_PatchTool != null) m_PatchTool.TargetRenderer = m_TargetRenderer;
            if (m_ColorBrush != null) m_ColorBrush.TargetRenderer = m_TargetRenderer;
            if (m_FillBrush != null) m_FillBrush.TargetRenderer = m_TargetRenderer;
            if (m_PaintBrush != null) m_PaintBrush.TargetRenderer = m_TargetRenderer;
            if (m_CylinderBrush != null) m_CylinderBrush.TargetRenderer = m_TargetRenderer;
            if (m_ColorizeBrush != null) m_ColorizeBrush.TargetRenderer = m_TargetRenderer;
            // PolyMask doesn't have TargetRenderer property
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            Event e = Event.current;
            
            // Draw animation recording/playback status indicator
            DrawAnimationRecorderOverlay(sceneView);
            
            // Middle mouse button toggles tool on/off (works for all tools)
            if (e.type == EventType.MouseDown && e.button == 2 && m_CurrentTool != BrushTool.None)
            {
                if (m_IsToolActive)
                {
                    DeactivateCurrentTool();
                }
                else
                {
                    ActivateCurrentTool();
                }
                e.Use();
                Repaint();
                return;
            }
            
            if (!m_IsToolActive) return;
            
            // For EraseBrush, we need a valid renderer
            if (m_CurrentTool == BrushTool.EraseBrush && (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset))
                return;
            
            // Only take control for mouse events, allow keyboard events to pass through for scene navigation (WASD)
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            bool isMouseEvent = e.type == EventType.MouseDown || e.type == EventType.MouseDrag || 
                               e.type == EventType.MouseUp || e.type == EventType.MouseMove ||
                               e.type == EventType.ScrollWheel || e.type == EventType.Layout;
            if (e.type == EventType.Layout || (isMouseEvent && e.button == 0))
                HandleUtility.AddDefaultControl(controlID);
            
            switch (m_CurrentTool)
            {
                case BrushTool.EraseBrush:
                    HandleEraseBrushScene(sceneView, e);
                    break;
                case BrushTool.BoxBrush:
                    HandleBoxBrushScene(sceneView, e);
                    break;
                case BrushTool.CloneBrush:
                    HandleCloneBrushScene(sceneView, e);
                    break;
                case BrushTool.FloorFill:
                    HandleFloorFillScene(sceneView, e);
                    break;
                case BrushTool.PatchTool:
                    HandlePatchToolScene(sceneView, e);
                    break;
                case BrushTool.PolyMask:
                    HandlePolyMaskScene(sceneView, e);
                    break;
                case BrushTool.ColorBrush:
                    HandleColorBrushScene(sceneView, e);
                    break;
                case BrushTool.VortexTool:
                    HandleVortexToolScene(sceneView, e);
                    break;
                case BrushTool.FillBrush:
                    HandleFillBrushScene(sceneView, e);
                    break;
                case BrushTool.PaintBrush:
                    if (m_PaintBrushMode == 0)
                        HandlePaintBrushScene(sceneView, e);
                    else if (m_PaintBrushMode == 1)
                        HandleColorizeBrushScene(sceneView, e);
                    else
                        HandleAnimationPaintScene(sceneView, e);
                    break;
                case BrushTool.CylinderBrush:
                    HandleCylinderBrushScene(sceneView, e);
                    break;
                case BrushTool.TextureStamp:
                    HandleTextureStampScene(sceneView, e);
                    break;
                case BrushTool.SculptBrush:
                    HandleSculptBrushScene(sceneView, e);
                    break;
            }
            
            // Escape to deactivate
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
            }
            
            sceneView.Repaint();
        }

        // Store screen position for line mode with backface culling
        
        private void HandleEraseBrushScene(SceneView sceneView, Event e)
        {
            if (m_EraseBrush == null) return;
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            // Middle mouse button toggles tool active state
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
                return;
            }
            
            // Ensure brush uses the correct renderer
            m_EraseBrush.TargetRenderer = m_TargetRenderer;
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetBrushHitPoint(ray, sceneView);
            float worldRadius = CalculateWorldRadius(hitPoint, sceneView, m_EraseBrush.ScreenRadius);
            // Use moderate multiplier for erase brush (1x for consistency with preview)
            float brushRadius = worldRadius;
            
            // Calculate screen position and radius for backface culling mode
            // Convert world hitPoint to screen coords (same as paint selection)
            Camera cam = sceneView.camera;
            Vector3 screenPos3D = cam.WorldToScreenPoint(hitPoint);
            Vector2 screenCenterPx = new Vector2(screenPos3D.x, cam.pixelHeight - screenPos3D.y); // Flip Y for GUI coords
            
            // Calculate screen radius from world radius using perspective projection
            float dist = Vector3.Distance(cam.transform.position, hitPoint);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
            float screenRadius = Mathf.Clamp(brushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
            
            // Store the ray direction for consistent use
            Vector3 rayDir = ray.direction;
            bool isShiftHeld = e.shift;
            GaussianSplatBrush.LastBrushPosition = hitPoint;
            GaussianSplatBrush.HasValidBrushPosition = true;
            GaussianSplatBrush.CurrentWorldRadius = brushRadius;
            GaussianSplatBrush.CurrentViewDirection = rayDir;
            
            // Shift+Left Click for line mode - check FIRST before other handling
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && isShiftHeld && !GaussianSplatBrush.IsLineMode)
            {
                GaussianSplatBrush.IsLineMode = true;
                GaussianSplatBrush.LineStartPosition = hitPoint;
                GaussianSplatBrush.LineStartRadius = brushRadius;
                GaussianSplatBrush.LineStartViewDirection = rayDir;
                GaussianSplatBrush.LineStartScreenPosition = screenCenterPx; // Use properly converted screen coords
                GaussianSplatBrush.LineStartScreenRadius = screenRadius;
                GaussianSplatBrush.IsDeleting = true;
                e.Use();
            }
            // Line mode mouse up - complete the line deletion
            else if (e.type == EventType.MouseUp && e.button == 0 && GaussianSplatBrush.IsLineMode)
            {
                // Use screen-space deletion for consistent screen radius
                m_EraseBrush.DeleteLineAtScreenPosition(GaussianSplatBrush.LineStartScreenPosition, screenCenterPx, 
                    GaussianSplatBrush.LineStartScreenRadius, screenRadius, cam);
                GaussianSplatBrush.IsLineMode = false;
                GaussianSplatBrush.IsDeleting = false;
                e.Use();
            }
            // Regular deletion (not in line mode)
            else if (!GaussianSplatBrush.IsLineMode && (e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 0 && !e.alt)
            {
                // Use screen-space deletion for consistent screen radius
                m_EraseBrush.DeleteAtScreenPosition(screenCenterPx, screenRadius, cam);
                e.Use();
            }
            
            // Track action state for color (only when not in line mode)
            if (!GaussianSplatBrush.IsLineMode)
            {
                if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !isShiftHeld)
                    GaussianSplatBrush.IsDeleting = true;
                else if (e.type == EventType.MouseUp && e.button == 0)
                    GaussianSplatBrush.IsDeleting = false;
            }
            
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
                GaussianSplatBrush.IsRestoring = true;
            else if (e.type == EventType.MouseUp && e.button == 1)
                GaussianSplatBrush.IsRestoring = false;
            
            // Always draw brush preview
            DrawEraseBrushPreview(hitPoint, brushRadius, sceneView);
            
            // Draw line preview when in line mode
            if (GaussianSplatBrush.IsLineMode)
                DrawLinePreview(GaussianSplatBrush.LineStartPosition, hitPoint, GaussianSplatBrush.LineStartRadius, brushRadius, sceneView);
            
            // Scroll to resize
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_EraseBrush, "Resize Brush");
                m_EraseBrush.ScreenRadius = Mathf.Clamp(m_EraseBrush.ScreenRadius - e.delta.y * 0.1f, 0.1f, 25f);
                EditorUtility.SetDirty(m_EraseBrush);
                e.Use();
                Repaint();
            }
            
            // Restore with right click - call renderer directly
            if ((e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 1 && !e.alt)
            {
                m_TargetRenderer.EditRestoreCylinder(hitPoint, brushRadius, rayDir);
                e.Use();
            }
        }

        private void HandleBoxBrushScene(SceneView sceneView, Event e)
        {
            if (m_BoxBrush == null) return;
            
            // Middle mouse button toggles tool on/off
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
                return;
            }
            
            if (m_BoxBrush.BrushMode == BoxBrushMode.Planar)
            {
                HandlePlanarBrushScene(sceneView, e);
            }
            else if (m_BoxBrush.BrushMode == BoxBrushMode.PaintSelection)
            {
                HandlePaintSelectionScene(sceneView, e);
            }
            else
            {
                DrawBoxBrushHandles(sceneView);
                DrawBoxBrushPreview(sceneView);
                
                // Tool hotkeys (1/2/3/R to switch Unity tools)
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha1)
                {
                    Tools.current = Tool.Move;
                    e.Use();
                    Repaint();
                }
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Alpha2)
                {
                    Tools.current = Tool.Rotate;
                    e.Use();
                    Repaint();
                }
                if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.Alpha3 || e.keyCode == KeyCode.R))
                {
                    Tools.current = Tool.Scale;
                    e.Use();
                    Repaint();
                }
            }
            
            // Keyboard shortcuts (work for Box3D and Planar modes)
            if (m_BoxBrush.BrushMode != BoxBrushMode.PaintSelection && e.type == EventType.KeyDown)
            {
                if (e.keyCode == KeyCode.C) { m_BoxBrush.CopySplats(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.V && m_BoxBrush.CanPaste) { m_BoxBrush.PasteSplats(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.Delete) { m_BoxBrush.DeleteSplatsInBox(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.X && m_BoxBrush.CanPaste) { m_BoxBrush.DeleteAndPaste(); e.Use(); Repaint(); }
            }
        }
        
        private void HandlePlanarBrushScene(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetPlanarHitPoint(ray, sceneView, m_BoxBrush.FloorY);
            
            // Draw current planar rect and handles
            DrawPlanarBrushPreview(sceneView, hitPoint);
            
            // Only handle mouse events, let keyboard events pass through for scene navigation
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                Undo.RecordObject(m_BoxBrush, "Start Planar Draw");
                m_BoxBrush.StartPlanarDrag(hitPoint);
                EditorUtility.SetDirty(m_BoxBrush);
                e.Use();
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && m_BoxBrush.IsDrawingPlanar)
            {
                m_BoxBrush.UpdatePlanarDrag(hitPoint);
                EditorUtility.SetDirty(m_BoxBrush);
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0 && m_BoxBrush.IsDrawingPlanar)
            {
                m_BoxBrush.UpdatePlanarDrag(hitPoint);
                m_BoxBrush.EndPlanarDrag();
                EditorUtility.SetDirty(m_BoxBrush);
                e.Use();
                Repaint();
            }
        }
        
        private void HandlePaintSelectionScene(SceneView sceneView, Event e)
        {
            if (m_BoxBrush == null || m_TargetRenderer == null) return;
            
            // Get cursor position via raycast to splats or fallback plane
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 cursorPos = GetRayHitPoint(ray, sceneView);
            
            // Check if in transform mode
            bool inTransformMode = m_BoxBrush.ShowTransformHandles;
            
            if (inTransformMode)
            {
                // Draw transform handles instead of brush preview
                DrawPastedSplatsTransformHandles(sceneView);
            }
            else
            {
                // Draw preview (with appropriate color for source/target mode)
                DrawPaintSelectionPreview(sceneView, cursorPos);
            }
            
            // Handle painting - ONLY when not in transform mode
            bool isShiftHeld = e.shift;
            bool isPaintingTarget = m_BoxBrush.PaintingTargetMode;
            
            if (!inTransformMode && e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.control)
            {
                m_BoxBrush.IsPaintingSelection = true;
                
                if (isPaintingTarget)
                {
                    // Target mode: paint target selection (blue/cyan)
                    Camera cam = sceneView.camera;
                    // Convert world position to screen coords - WorldToScreenPoint has Y=0 at bottom, flip for GUI
                    Vector3 screenPos = cam.WorldToScreenPoint(cursorPos);
                    Vector2 mousePx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);
                    
                    float dist = Vector3.Distance(cam.transform.position, cursorPos);
                    float screenHeight = cam.pixelHeight;
                    float fov = cam.fieldOfView * Mathf.Deg2Rad;
                    float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
                    float radiusPx = Mathf.Clamp(m_BoxBrush.SelectionBrushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
                    
                    bool backfaceCull = m_BoxBrush.BackfaceCulling;
                    m_TargetRenderer.TargetSelectionColor = m_BoxBrush.TargetColor;
                    m_TargetRenderer.EditSelectTargetSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: isShiftHeld, backfaceCull);
                    m_BoxBrush.BoxPosition = cursorPos;
                    // Pass camera orientation for alignment
                    m_BoxBrush.SetTargetPaintPosition(cursorPos, cam.transform.forward, cam.transform.up);
                }
                else
                {
                    // Source mode: select splats
                    m_BoxBrush.SelectionAddMode = !isShiftHeld;
                    Camera cam = sceneView.camera;
                    // Convert world position to screen coords - WorldToScreenPoint has Y=0 at bottom, flip for GUI
                    Vector3 screenPos = cam.WorldToScreenPoint(cursorPos);
                    Vector2 mousePx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);
                    
                    float dist = Vector3.Distance(cam.transform.position, cursorPos);
                    float screenHeight = cam.pixelHeight;
                    float fov = cam.fieldOfView * Mathf.Deg2Rad;
                    float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
                    float radiusPx = Mathf.Clamp(m_BoxBrush.SelectionBrushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
                    
                    bool backfaceCull = m_BoxBrush.BackfaceCulling;
                    m_TargetRenderer.SelectionColor = m_BoxBrush.SelectionColor;
                    m_TargetRenderer.EditSelectSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: isShiftHeld, backfaceCull);
                }
                EditorUtility.SetDirty(m_BoxBrush);
                e.Use();
            }
            else if (!inTransformMode && e.type == EventType.MouseDrag && e.button == 0 && m_BoxBrush.IsPaintingSelection)
            {
                if (isPaintingTarget)
                {
                    // Target mode: paint target selection (blue/cyan)
                    Camera cam = sceneView.camera;
                    // Convert world position to screen coords - WorldToScreenPoint has Y=0 at bottom, flip for GUI
                    Vector3 screenPos = cam.WorldToScreenPoint(cursorPos);
                    Vector2 mousePx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);
                    
                    float dist = Vector3.Distance(cam.transform.position, cursorPos);
                    float screenHeight = cam.pixelHeight;
                    float fov = cam.fieldOfView * Mathf.Deg2Rad;
                    float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
                    float radiusPx = Mathf.Clamp(m_BoxBrush.SelectionBrushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
                    
                    bool backfaceCull = m_BoxBrush.BackfaceCulling;
                    m_TargetRenderer.TargetSelectionColor = m_BoxBrush.TargetColor;
                    m_TargetRenderer.EditSelectTargetSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: isShiftHeld, backfaceCull);
                    m_BoxBrush.BoxPosition = cursorPos;
                    // Pass camera orientation for alignment
                    m_BoxBrush.SetTargetPaintPosition(cursorPos, cam.transform.forward, cam.transform.up);
                }
                else
                {
                    // Source mode: continue selecting splats
                    m_BoxBrush.SelectionAddMode = !isShiftHeld;
                    Camera cam = sceneView.camera;
                    // Convert world position to screen coords - WorldToScreenPoint has Y=0 at bottom, flip for GUI
                    Vector3 screenPos = cam.WorldToScreenPoint(cursorPos);
                    Vector2 mousePx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);

                    float dist = Vector3.Distance(cam.transform.position, cursorPos);
                    float screenHeight = cam.pixelHeight;
                    float fov = cam.fieldOfView * Mathf.Deg2Rad;
                    float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
                    float radiusPx = Mathf.Clamp(m_BoxBrush.SelectionBrushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
                    
                    bool backfaceCull = m_BoxBrush.BackfaceCulling;
                    m_TargetRenderer.SelectionColor = m_BoxBrush.SelectionColor;
                    m_TargetRenderer.EditSelectSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: isShiftHeld, backfaceCull);
                }
                EditorUtility.SetDirty(m_BoxBrush);
                e.Use();
            }
            else if (!inTransformMode && e.type == EventType.MouseUp && e.button == 0)
            {
                m_BoxBrush.IsPaintingSelection = false;
                e.Use();
                Repaint();
            }
            
            // Scroll wheel to change brush size (no modifier needed)
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                m_BoxBrush.SelectionBrushRadius = Mathf.Clamp(
                    m_BoxBrush.SelectionBrushRadius - e.delta.y * 0.02f, 
                    0.01f, 2f);
                EditorUtility.SetDirty(m_BoxBrush);
                e.Use();
            }
            
            // Keyboard shortcuts for selection mode
            if (e.type == EventType.KeyDown)
            {
                if (e.keyCode == KeyCode.C && m_BoxBrush.HasSelection) 
                { 
                    // Copy with camera orientation for alignment
                    Camera cam = sceneView.camera;
                    m_BoxBrush.CopySelectionWithOrientation(cam.transform.forward, cam.transform.up); 
                    e.Use(); 
                    Repaint(); 
                }
                if (e.keyCode == KeyCode.V && m_BoxBrush.CanPasteSelection) { m_BoxBrush.PasteSelection(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.Delete && m_BoxBrush.HasSelection) { m_BoxBrush.DeleteSelection(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.A && e.control) { m_BoxBrush.SelectAll(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.I && e.control) { m_BoxBrush.InvertSelection(); e.Use(); Repaint(); }
                if (e.keyCode == KeyCode.Escape) { m_BoxBrush.ClearSelection(); e.Use(); Repaint(); }
                // T = Toggle between Source and Target painting mode
                if (e.keyCode == KeyCode.T && !e.control && !e.shift && !e.alt) 
                { 
                    m_BoxBrush.PaintingTargetMode = !m_BoxBrush.PaintingTargetMode; 
                    e.Use(); 
                    Repaint(); 
                }
                // G = Toggle between Paint and Transform mode
                if (e.keyCode == KeyCode.G && !e.control && !e.shift && !e.alt)
                {
                    m_BoxBrush.TransformModeActive = !m_BoxBrush.TransformModeActive;
                    if (m_BoxBrush.TransformModeActive)
                        Tools.current = Tool.Move;
                    e.Use();
                    Repaint();
                }
                // W/E/R = Switch transform tools when in transform mode
                if (m_BoxBrush.ShowTransformHandles)
                {
                    if (e.keyCode == KeyCode.W) { Tools.current = Tool.Move; e.Use(); }
                    if (e.keyCode == KeyCode.E) { Tools.current = Tool.Rotate; e.Use(); }
                    if (e.keyCode == KeyCode.R) { Tools.current = Tool.Scale; e.Use(); }
                }
            }
            
            // Position handle for paste target
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = Handles.PositionHandle(m_BoxBrush.BoxPosition, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_BoxBrush, "Move Paste Target");
                m_BoxBrush.BoxPosition = newPos;
                EditorUtility.SetDirty(m_BoxBrush);
            }
        }
        
        private Vector3 GetRayHitPoint(Ray ray, SceneView sceneView)
        {
            // Place brush on camera-facing plane at pivot distance
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private void DrawPaintSelectionPreview(SceneView sceneView, Vector3 cursorPos)
        {
            if (m_BoxBrush == null || m_TargetRenderer == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 camForward = sceneView.camera.transform.forward;
            float radius = m_BoxBrush.SelectionBrushRadius;
            bool isPaintingTarget = m_BoxBrush.PaintingTargetMode;
            
            // Use appropriate color based on source/target mode
            Color brushColor = isPaintingTarget ? m_BoxBrush.TargetColor : m_BoxBrush.SelectionColor;
            Color fillColor, outlineColor;
            
            if (isPaintingTarget)
            {
                // Target mode - use target color
                fillColor = new Color(brushColor.r, brushColor.g, brushColor.b, 0.3f);
                outlineColor = new Color(brushColor.r, brushColor.g, brushColor.b, 0.95f);
            }
            else if (m_BoxBrush.SelectionAddMode)
            {
                // Add mode - use selection color
                fillColor = new Color(brushColor.r, brushColor.g, brushColor.b, 0.25f);
                outlineColor = new Color(brushColor.r, brushColor.g, brushColor.b, 0.9f);
            }
            else
            {
                // Subtract mode - red tint
                fillColor = new Color(1f, 0.2f, 0.2f, 0.25f);
                outlineColor = new Color(1f, 0.2f, 0.2f, 0.9f);
            }
            
            // Draw filled disc
            Handles.color = fillColor;
            Handles.DrawSolidDisc(cursorPos, camForward, radius);
            
            // Draw outline
            Handles.color = outlineColor;
            Handles.DrawWireDisc(cursorPos, camForward, radius);
            Handles.DrawWireDisc(cursorPos, camForward, radius * 0.95f); // Double line for visibility
            
            // Draw paste target position handle (always visible when we have copied data)
            Color targetColor = m_BoxBrush.TargetColor;
            if (m_BoxBrush.HasCopiedSelection || isPaintingTarget)
            {
                Vector3 targetPos = m_BoxBrush.BoxPosition;
                
                // Draw crosshair at target
                Handles.color = new Color(targetColor.r, targetColor.g, targetColor.b, 0.95f);
                float crossSize = 0.15f;
                Handles.DrawLine(targetPos - Vector3.right * crossSize, targetPos + Vector3.right * crossSize);
                Handles.DrawLine(targetPos - Vector3.up * crossSize, targetPos + Vector3.up * crossSize);
                Handles.DrawLine(targetPos - Vector3.forward * crossSize, targetPos + Vector3.forward * crossSize);
                
                // Draw wire sphere at target
                Handles.DrawWireDisc(targetPos, Vector3.up, 0.1f);
                Handles.DrawWireDisc(targetPos, Vector3.forward, 0.1f);
                Handles.DrawWireDisc(targetPos, Vector3.right, 0.1f);
                
                Handles.Label(targetPos + Vector3.up * 0.2f, "TARGET", 
                    new GUIStyle { normal = { textColor = targetColor }, fontSize = 11, fontStyle = FontStyle.Bold });
            }
            
            // Simple status label near cursor
            string modeLabel = isPaintingTarget ? "TARGET" : (m_BoxBrush.SelectionAddMode ? "+" : "-");
            string selInfo = m_BoxBrush.HasSelection ? $" [{m_BoxBrush.SelectedSplatCount}]" : "";
            Handles.Label(cursorPos + Vector3.up * (radius + 0.05f), 
                $"{modeLabel}{selInfo}", new GUIStyle { normal = { textColor = brushColor }, fontSize = 10 });
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawPastedSplatsTransformHandles(SceneView sceneView)
        {
            if (m_BoxBrush == null) return;
            
            Vector3 pivot = m_BoxBrush.PastedSplatsPivot + m_BoxBrush.PasteOffset;
            Quaternion rot = m_BoxBrush.PastedSplatsRotation;
            float scale = m_BoxBrush.PasteScaleAdjust;
            
            // Ensure a valid tool is selected for handles
            if (Tools.current != Tool.Move && Tools.current != Tool.Rotate && Tools.current != Tool.Scale)
            {
                Tools.current = Tool.Move;
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pivot;
            Quaternion newRot = rot;
            float newScale = scale;
            
            // Show handles based on Unity's current tool
            switch (Tools.current)
            {
                case Tool.Move:
                    newPos = Handles.PositionHandle(pivot, rot);
                    break;
                    
                case Tool.Rotate:
                    newRot = Handles.RotationHandle(rot, pivot);
                    break;
                    
                case Tool.Scale:
                    Vector3 scaleVec = Handles.ScaleHandle(Vector3.one * scale, pivot, rot, HandleUtility.GetHandleSize(pivot));
                    newScale = (scaleVec.x + scaleVec.y + scaleVec.z) / 3f;
                    break;
                    
                default:
                    newPos = Handles.PositionHandle(pivot, rot);
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_BoxBrush, "Adjust Pasted Splats");
                
                // Position changed - update offset
                if (newPos != pivot)
                {
                    Vector3 delta = newPos - pivot;
                    m_BoxBrush.PasteOffset = m_BoxBrush.PasteOffset + delta;
                }
                
                // Rotation changed
                if (newRot != rot)
                {
                    m_BoxBrush.PasteRotationAdjust = newRot.eulerAngles;
                }
                
                // Scale changed
                if (Mathf.Abs(newScale - scale) > 0.001f)
                {
                    m_BoxBrush.PasteScaleAdjust = Mathf.Max(0.1f, newScale);
                }
                
                EditorUtility.SetDirty(m_BoxBrush);
            }
            
            // Draw visual indicator for pasted splats pivot
            Handles.color = Color.cyan;
            float handleSize = HandleUtility.GetHandleSize(pivot) * 0.15f;
            Handles.DrawWireCube(pivot, Vector3.one * handleSize);
            
            // Label showing current tool
            string toolName = Tools.current == Tool.Move ? "MOVE (W)" : 
                              Tools.current == Tool.Rotate ? "ROTATE (E)" : "SCALE (R)";
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.cyan }, fontSize = 11, fontStyle = FontStyle.Bold };
            Handles.Label(pivot + Vector3.up * handleSize * 2f, $"Adjusting {m_BoxBrush.LastPastedCount} splats | {toolName}", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private Vector3 GetPlanarHitPoint(Ray ray, SceneView sceneView, float floorY)
        {
            // Raycast to the floor plane at FloorY
            Plane floorPlane = new Plane(Vector3.up, new Vector3(0, floorY, 0));
            if (floorPlane.Raycast(ray, out float enter))
                return ray.GetPoint(enter);
            
            // Fallback to camera-facing plane
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private void DrawPlanarBrushPreview(SceneView sceneView, Vector3 cursorPos)
        {
            if (m_BoxBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_BoxBrush.PlanarBoxPosition;
            Vector3 size = m_BoxBrush.PlanarBoxSize;
            
            Color boxColor = m_BoxBrush.HasCopiedData ? new Color(0f, 0.8f, 1f, 1f) : m_BoxBrush.BoxColor;
            float alpha = m_BoxBrush.BoxAlpha;
            
            // Draw solid 3D box
            DrawSolid3DBox(pos, size, boxColor, alpha);
            
            // Wireframe
            Handles.color = boxColor;
            Handles.DrawWireCube(pos, size);
            
            // Draw cursor
            Handles.color = Color.yellow;
            Handles.DrawWireDisc(cursorPos, Vector3.up, 0.1f);
            Handles.DrawLine(cursorPos, cursorPos + Vector3.up * 0.2f);
            
            // Draw source rect if copied
            if (m_BoxBrush.HasCopiedData)
            {
                Color sourceColor = new Color(1f, 0.5f, 0f, 1f);
                DrawSolid3DBox(m_BoxBrush.CopiedSourcePosition, m_BoxBrush.CopiedBoxSize, sourceColor, alpha * 0.7f);
                
                Handles.color = sourceColor;
                Handles.DrawWireCube(m_BoxBrush.CopiedSourcePosition, m_BoxBrush.CopiedBoxSize);
                
                // Connection line
                Handles.color = Color.yellow;
                Handles.DrawLine(m_BoxBrush.CopiedSourcePosition, pos);
            }
            
            // Position handle for moving the rect (when not drawing)
            if (!m_BoxBrush.IsDrawingPlanar)
            {
                EditorGUI.BeginChangeCheck();
                Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_BoxBrush, "Move Planar Rect");
                    m_BoxBrush.PlanarPosition = new Vector2(newPos.x, newPos.z);
                    m_BoxBrush.FloorY = newPos.y;
                    EditorUtility.SetDirty(m_BoxBrush);
                }
            }
            
            // Instructions
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string info = m_BoxBrush.IsDrawingPlanar 
                ? "Drawing... release to finish" 
                : (m_BoxBrush.HasCopiedData ? "DRAG=New rect | C=Copy | V=Paste | X=Del&Paste" : "DRAG=Draw rect | C=Copy | Del=Delete");
            Handles.Label(pos + Vector3.up * 0.3f, info, labelStyle);
            
            // Size info
            GUIStyle sizeStyle = new GUIStyle { normal = { textColor = COL_CYAN }, fontSize = 10 };
            Handles.Label(pos + Vector3.up * 0.15f, $"Size: {size.x:F2} x {size.z:F2} | Y: {m_BoxBrush.FloorY:F2}", sizeStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void HandleCloneBrushScene(SceneView sceneView, Event e)
        {
            if (m_CloneBrush == null) return;
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetCloneHitPoint(ray, sceneView);
            
            GaussianSplatCloneBrush.LastBrushPosition = hitPoint;
            GaussianSplatCloneBrush.HasValidBrushPosition = true;
            
            DrawCloneBrushPreview(hitPoint, sceneView);
            
            // Left click to add vertex or set target
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                m_CloneBrush.AddVertex(hitPoint);
                e.Use();
                Repaint();
            }
            
            // Right click to clear
            if (e.type == EventType.MouseDown && e.button == 1)
            {
                m_CloneBrush.ClearAll();
                e.Use();
                Repaint();
            }
            
            // Keyboard
            if (e.type == EventType.KeyDown)
            {
                if ((e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) && 
                    m_CloneBrush.IsDrawingSource && m_CloneBrush.SourceVertices.Count >= 3)
                {
                    m_CloneBrush.FinishSourcePolygon();
                    e.Use();
                    Repaint();
                }
                if (e.keyCode == KeyCode.Backspace)
                {
                    m_CloneBrush.UndoLastVertex();
                    e.Use();
                    Repaint();
                }
                if (e.keyCode == KeyCode.Space && m_CloneBrush.CanClone)
                {
                    m_CloneBrush.PerformClone();
                    e.Use();
                    Repaint();
                }
            }
        }

        private void HandleFloorFillScene(SceneView sceneView, Event e)
        {
            if (m_FloorFillBrush == null) return;
            
            DrawFloorFillPreview(sceneView);
            DrawFloorFillHandles(sceneView);
            
            // Keyboard
            if (e.type == EventType.KeyDown)
            {
                if (e.keyCode == KeyCode.F && m_FloorFillBrush.IsValid && m_FloorFillBrush.SampleRegions.Count > 0)
                {
                    m_FloorFillBrush.ExecuteFill();
                    e.Use();
                }
                if (e.keyCode == KeyCode.D)
                {
                    m_FloorFillBrush.DeleteFillRegion();
                    e.Use();
                }
            }
        }

        private void HandlePatchToolScene(SceneView sceneView, Event e)
        {
            if (m_PatchTool == null) return;
            
            DrawPatchToolPreview(sceneView);
        }

        private void HandleColorBrushScene(SceneView sceneView, Event e)
        {
            if (m_ColorBrush == null) return;
            
            DrawColorBrushHandles(sceneView);
            DrawColorBrushPreview(sceneView);
            
            // Don't block camera movement keys (WASD, etc)
            // Only use Enter for apply
            if (e.type == EventType.KeyDown)
            {
                // Enter = Apply colors to box
                if ((e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) && 
                    m_ColorBrush.HasAdjustments && m_ColorBrush.IsValid)
                {
                    m_ColorBrush.ApplyColorAdjustments();
                    e.Use();
                    Repaint();
                }
            }
        }

        private void HandleVortexToolScene(SceneView sceneView, Event e)
        {
            if (m_VortexAttractor == null) return;
            
            var so = new SerializedObject(m_VortexAttractor);
            bool showGizmo = so.FindProperty("m_ShowVortexGizmo").boolValue;
            if (showGizmo)
            {
                DrawVortexToolHandles(sceneView);
                DrawVortexToolPreview(sceneView);
            }
            
            // Scroll to adjust range
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_VortexAttractor, "Adjust Attractor Range");
                float range = so.FindProperty("m_Range").floatValue;
                range = Mathf.Clamp(range - e.delta.y * 0.3f, 0.1f, 20f);
                so.FindProperty("m_Range").floatValue = range;
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
                e.Use();
                Repaint();
            }
            
            // Space to start/pause
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Space)
            {
                Undo.RecordObject(m_VortexAttractor, "Toggle Vortex");
                var enabledProp = so.FindProperty("m_AttractorEnabled");
                var pausedProp = so.FindProperty("m_AttractorPaused");
                bool isEnabled = enabledProp.boolValue;
                bool isPaused = pausedProp.boolValue;
                
                if (!isEnabled)
                {
                    enabledProp.boolValue = true;
                    pausedProp.boolValue = false;
                }
                else if (!isPaused)
                {
                    pausedProp.boolValue = true;
                    if (m_TargetRenderer != null)
                        m_TargetRenderer.ClearAllVelocities();
                }
                else
                {
                    pausedProp.boolValue = false;
                }
                so.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_VortexAttractor);
                
                // Ensure attractor is registered when enabling
                if (enabledProp.boolValue)
                    m_VortexAttractor.EnsureRegistered();
                
                e.Use();
                Repaint();
            }
        }

        private void HandleFillBrushScene(SceneView sceneView, Event e)
        {
            if (m_FillBrush == null) return;
            
            // Ensure renderer is always synced
            if (m_FillBrush.TargetRenderer != m_TargetRenderer)
                m_FillBrush.TargetRenderer = m_TargetRenderer;
            
            // When polygon is closed, handle vertex dragging and transform handles
            if (m_FillBrush.IsClosed)
            {
                // Handle vertex dragging first (higher priority)
                HandleFillBrushVertexDragging(sceneView, e);
                
                // Only show position handle if not dragging a vertex
                if (m_DraggingVertexIndex < 0)
                    DrawFillBrushTransformHandles(sceneView);
            }
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetFillHitPoint(ray, sceneView);
            
            GaussianSplatFillBrush.LastBrushPosition = hitPoint;
            GaussianSplatFillBrush.HasValidBrushPosition = true;
            
            DrawFillBrushPreview(hitPoint, sceneView);
            
            // Left click to add vertex (only when not closed and not dragging)
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !m_FillBrush.IsClosed && m_DraggingVertexIndex < 0)
            {
                m_FillBrush.AddVertex(hitPoint);
                e.Use();
                Repaint();
            }
            
            // Scroll wheel to adjust scale when closed (and not dragging)
            if (e.type == EventType.ScrollWheel && !e.alt && m_FillBrush.IsClosed && m_DraggingVertexIndex < 0)
            {
                Undo.RecordObject(m_FillBrush, "Scale Polygon");
                float scale = m_FillBrush.UniformScale - e.delta.y * 0.05f;
                m_FillBrush.UniformScale = Mathf.Clamp(scale, 0.1f, 5f);
                EditorUtility.SetDirty(m_FillBrush);
                e.Use();
                Repaint();
            }
            
            // Keyboard (only when not dragging)
            if (e.type == EventType.KeyDown && m_DraggingVertexIndex < 0)
            {
                // Enter = Close polygon (but don't fill yet)
                if ((e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
                {
                    if (m_FillBrush.IsDrawing && m_FillBrush.Vertices.Count >= 3)
                    {
                        Undo.RecordObject(m_FillBrush, "Close Polygon");
                        m_FillBrush.ClosePolygon();
                        EditorUtility.SetDirty(m_FillBrush);
                        e.Use();
                        Repaint();
                    }
                }
                
                // F = Fill (execute the fill)
                if (e.keyCode == KeyCode.F && m_FillBrush.CanFill)
                {
                    m_FillBrush.TargetRenderer = m_TargetRenderer;
                    m_FillBrush.ExecuteFill();
                    e.Use();
                    Repaint();
                }
                
                // Backspace = Undo last vertex (when drawing) or reset transform (when closed)
                if (e.keyCode == KeyCode.Backspace)
                {
                    if (m_FillBrush.IsDrawing)
                        m_FillBrush.UndoLastVertex();
                    else if (m_FillBrush.IsClosed)
                    {
                        Undo.RecordObject(m_FillBrush, "Reset Transform");
                        m_FillBrush.ResetTransform();
                        EditorUtility.SetDirty(m_FillBrush);
                    }
                    e.Use();
                    Repaint();
                }
                
                // D = Delete area
                if (e.keyCode == KeyCode.D && m_FillBrush.HasValidPolygon)
                {
                    m_FillBrush.DeletePolygonArea();
                    e.Use();
                    Repaint();
                }
                
                // T = Reset transform
                if (e.keyCode == KeyCode.T && m_FillBrush.IsClosed)
                {
                    Undo.RecordObject(m_FillBrush, "Reset Transform");
                    m_FillBrush.ResetTransform();
                    EditorUtility.SetDirty(m_FillBrush);
                    e.Use();
                    Repaint();
                }
            }
        }

        // Paint brush state
        private Vector3 m_LastPaintPosition;
        private double m_LastPaintTime;
        private bool m_IsPaintStrokeActive = false;
        private const float PAINT_MIN_DISTANCE = 0.001f; // Very small for continuous strokes
        private const double PAINT_MIN_INTERVAL = 0.008; // ~120 paints per second for fluid strokes
        
        // Colorize brush stroke tracking
        private Vector3 m_LastColorizePosition;
        private float m_LastColorizeRadius;
        private bool m_IsColorizeStrokeActive = false;
        private const float COLORIZE_STROKE_STEP = 0.3f; // Fraction of radius for interpolation steps
        
        private void HandlePaintBrushScene(SceneView sceneView, Event e)
        {
            if (m_PaintBrush == null) return;
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            // Handle texture capture mode
            if (m_IsCapturingRect)
            {
                HandleTextureCaptureMode(sceneView, e);
                return;
            }
            
            // Middle mouse button toggles tool on/off (preserves values)
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
                return;
            }
            
            m_PaintBrush.TargetRenderer = m_TargetRenderer;
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 rayDir = ray.direction;
            Camera cam = sceneView.camera;
            
            // Use pivot distance as reference depth for finding splat surface
            float pivotDist = Vector3.Distance(cam.transform.position, sceneView.pivot);
            
            // Find actual surface position for preview display
            Vector3? surfacePos = m_PaintBrush.GetSurfacePositionForPreview(ray, cam, pivotDist);
            Vector3 previewPos = surfacePos ?? GetBrushHitPoint(ray, sceneView);
            
            float worldRadius = CalculateWorldRadius(previewPos, sceneView, m_PaintBrush.ScreenRadius);
            float brushRadius = worldRadius * 10f;
            
            GaussianSplatPaintBrush.LastBrushPosition = previewPos;
            GaussianSplatPaintBrush.HasValidBrushPosition = surfacePos.HasValue;
            GaussianSplatPaintBrush.CurrentWorldRadius = brushRadius;
            GaussianSplatPaintBrush.CurrentViewDirection = rayDir;
            
            // Track action state and handle stroke start/end
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                GaussianSplatPaintBrush.IsPainting = true;
                m_IsPaintStrokeActive = true;
                m_PaintBrush.BeginPaintStroke(); // Reset surface cache for new stroke
                m_LastPaintPosition = previewPos;
                m_LastPaintTime = EditorApplication.timeSinceStartup;
            }
            else if (e.type == EventType.MouseUp && e.button == 0)
            {
                GaussianSplatPaintBrush.IsPainting = false;
                m_IsPaintStrokeActive = false;
            }
            
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
                GaussianSplatPaintBrush.IsSampling = true;
            else if (e.type == EventType.MouseUp && e.button == 1)
                GaussianSplatPaintBrush.IsSampling = false;
            
            DrawPaintBrushPreview(previewPos, brushRadius, sceneView);
            
            // Scroll to resize
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_PaintBrush, "Resize Brush");
                m_PaintBrush.ScreenRadius = Mathf.Clamp(m_PaintBrush.ScreenRadius - e.delta.y * 0.1f, 0.1f, 10f);
                EditorUtility.SetDirty(m_PaintBrush);
                e.Use();
                Repaint();
            }
            
            // Continuous painting - paint on mouse down, drag, and move while stroke is active
            bool isLeftClick = e.button == 0 && !e.alt;
            bool isPaintEvent = (e.type == EventType.MouseDown && isLeftClick) ||
                               (e.type == EventType.MouseDrag && isLeftClick) ||
                               (e.type == EventType.MouseMove && m_IsPaintStrokeActive);
            
            if (isPaintEvent)
            {
                double currentTime = EditorApplication.timeSinceStartup;
                float distance = Vector3.Distance(previewPos, m_LastPaintPosition);
                double timeDelta = currentTime - m_LastPaintTime;
                
                // Always paint on mouse down, or continuously during stroke with minimal gating
                bool shouldPaint = (e.type == EventType.MouseDown) || 
                                   (m_IsPaintStrokeActive && (distance > PAINT_MIN_DISTANCE || timeDelta > PAINT_MIN_INTERVAL));
                
                if (shouldPaint)
                {
                    // Use texture painting if enabled, otherwise regular color painting
                    if (m_PaintBrush.UseTexturePaint && m_PaintBrush.HasActiveTexture)
                        m_PaintBrush.PaintWithTextureAtRay(ray, cam, brushRadius, rayDir, pivotDist);
                    else
                        m_PaintBrush.PaintAtRay(ray, cam, brushRadius, rayDir, pivotDist);
                    m_LastPaintPosition = previewPos;
                    m_LastPaintTime = currentTime;
                }
                
                if (e.type == EventType.MouseDown || e.type == EventType.MouseDrag)
                    e.Use();
            }
            
            // Force continuous repaint while painting for smooth strokes
            if (m_IsPaintStrokeActive)
            {
                sceneView.Repaint();
            }
            
            // Right click = Sample colors using ray with pivot distance
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
            {
                m_PaintBrush.SampleColorsAtRay(ray, cam, pivotDist, 300f);
                e.Use();
                Repaint();
            }
        }
        
        private void HandleTextureCaptureMode(SceneView sceneView, Event e)
        {
            // Cancel with ESC or right-click
            if ((e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape) ||
                (e.type == EventType.MouseDown && e.button == 1))
            {
                m_IsCapturingRect = false;
                m_IsDraggingCapture = false;
                e.Use();
                Repaint();
                sceneView.Repaint();
                return;
            }
            
            // Start drag
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                m_CaptureStartPos = e.mousePosition;
                m_CaptureEndPos = e.mousePosition;
                m_IsDraggingCapture = true;
                e.Use();
            }
            
            // Continue drag
            if (e.type == EventType.MouseDrag && m_IsDraggingCapture)
            {
                m_CaptureEndPos = e.mousePosition;
                sceneView.Repaint();
                e.Use();
            }
            
            // End drag - capture
            if (e.type == EventType.MouseUp && e.button == 0 && m_IsDraggingCapture)
            {
                m_CaptureEndPos = e.mousePosition;
                m_IsDraggingCapture = false;
                
                // Calculate rect (handle inverted rects)
                float minX = Mathf.Min(m_CaptureStartPos.x, m_CaptureEndPos.x);
                float maxX = Mathf.Max(m_CaptureStartPos.x, m_CaptureEndPos.x);
                float minY = Mathf.Min(m_CaptureStartPos.y, m_CaptureEndPos.y);
                float maxY = Mathf.Max(m_CaptureStartPos.y, m_CaptureEndPos.y);
                
                float width = maxX - minX;
                float height = maxY - minY;
                
                if (width >= 4 && height >= 4)
                {
                    // Render the scene to a RenderTexture
                    Camera cam = sceneView.camera;
                    int rtWidth = (int)cam.pixelWidth;
                    int rtHeight = (int)cam.pixelHeight;
                    
                    var rt = RenderTexture.GetTemporary(rtWidth, rtHeight, 24, RenderTextureFormat.ARGB32);
                    var prevTarget = cam.targetTexture;
                    
                    cam.targetTexture = rt;
                    cam.Render();
                    cam.targetTexture = prevTarget;
                    
                    // Scene view position gives us the window rect
                    // GUI coordinates are relative to the scene view content area
                    // The camera renders to the full pixelWidth/Height
                    Rect viewPos = sceneView.position;
                    float scaleX = rtWidth / viewPos.width;
                    float scaleY = rtHeight / viewPos.height;
                    
                    // Convert GUI coordinates to render texture coordinates
                    // GUI Y is top-down, RT Y is bottom-up
                    float texMinX = minX * scaleX;
                    float texWidth = width * scaleX;
                    float texHeight = height * scaleY;
                    float texMinY = rtHeight - (maxY * scaleY);
                    
                    Rect captureRect = new Rect(texMinX, texMinY, texWidth, texHeight);
                    m_PaintBrush.CaptureTextureFromRT(rt, captureRect, m_CaptureTargetSlot);
                    
                    RenderTexture.ReleaseTemporary(rt);
                    
                    EditorUtility.SetDirty(m_PaintBrush);
                }
                
                m_IsCapturingRect = false;
                e.Use();
                Repaint();
                sceneView.Repaint();
                return;
            }
            
            // Draw capture overlay
            Handles.BeginGUI();
            
            // Dim background
            GUI.color = new Color(0, 0, 0, 0.3f);
            GUI.DrawTexture(new Rect(0, 0, sceneView.position.width, sceneView.position.height), EditorGUIUtility.whiteTexture);
            GUI.color = Color.white;
            
            // Draw selection rectangle
            if (m_IsDraggingCapture || (m_CaptureStartPos != m_CaptureEndPos))
            {
                float minX = Mathf.Min(m_CaptureStartPos.x, m_CaptureEndPos.x);
                float maxX = Mathf.Max(m_CaptureStartPos.x, m_CaptureEndPos.x);
                float minY = Mathf.Min(m_CaptureStartPos.y, m_CaptureEndPos.y);
                float maxY = Mathf.Max(m_CaptureStartPos.y, m_CaptureEndPos.y);
                
                Rect selRect = new Rect(minX, minY, maxX - minX, maxY - minY);
                
                // Clear area inside selection
                GUI.color = Color.clear;
                GUI.DrawTexture(selRect, EditorGUIUtility.whiteTexture);
                GUI.color = Color.white;
                
                // Draw border
                EditorGUI.DrawRect(new Rect(minX - 2, minY - 2, maxX - minX + 4, 2), COL_CYAN);
                EditorGUI.DrawRect(new Rect(minX - 2, maxY, maxX - minX + 4, 2), COL_CYAN);
                EditorGUI.DrawRect(new Rect(minX - 2, minY, 2, maxY - minY), COL_CYAN);
                EditorGUI.DrawRect(new Rect(maxX, minY, 2, maxY - minY), COL_CYAN);
                
                // Size label
                string sizeText = $"{(int)(maxX - minX)}x{(int)(maxY - minY)}";
                GUIStyle sizeStyle = new GUIStyle(EditorStyles.boldLabel) { normal = { textColor = Color.white } };
                GUI.Label(new Rect(minX + 5, minY + 5, 100, 20), sizeText, sizeStyle);
            }
            
            // Instructions
            GUIStyle instructionStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 14,
                normal = { textColor = COL_CYAN },
                alignment = TextAnchor.UpperCenter
            };
            GUI.Label(new Rect(0, 20, sceneView.position.width, 30), 
                $"CAPTURE MODE - Slot {m_CaptureTargetSlot + 1} | Drag to select | ESC to cancel", 
                instructionStyle);
            
            Handles.EndGUI();
        }

        private void DrawPaintBrushPreview(Vector3 pos, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            
            bool hasSamples = m_PaintBrush != null && m_PaintBrush.HasSampledColors;
            bool useCustom = m_PaintBrush != null && m_PaintBrush.UseCustomColor;
            bool useTexture = m_PaintBrush != null && m_PaintBrush.UseTexturePaint && m_PaintBrush.HasActiveTexture;
            bool hasValidColor = useCustom || hasSamples || useTexture;
            
            Color mainColor = GaussianSplatPaintBrush.IsSampling 
                ? new Color(0.3f, 0.8f, 1f, 0.9f)  // Cyan for sampling
                : (useTexture ? new Color(0.9f, 0.5f, 0.9f, 0.9f)  // Purple for texture
                : (hasValidColor ? new Color(0.3f, 0.9f, 0.4f, 0.9f) : new Color(0.9f, 0.6f, 0.2f, 0.9f))); // Green if has colors, orange if not
            Color fillColor = new Color(mainColor.r, mainColor.g, mainColor.b, 0.15f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(pos, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(pos, -camForward, radius, 2f);
            
            // Center dot
            Handles.color = mainColor;
            Handles.DrawSolidDisc(pos, -camForward, radius * 0.03f);
            
            // Show paint color preview (custom or sampled)
            if (m_PaintBrush != null)
            {
                Color paintColor = m_PaintBrush.GetCurrentPaintColor();
                Handles.color = new Color(paintColor.r, paintColor.g, paintColor.b, 0.6f);
                Handles.DrawSolidDisc(pos, -camForward, radius * 0.35f);
                
                // Inner ring showing exact color
                Handles.color = paintColor;
                Handles.DrawWireDisc(pos, -camForward, radius * 0.35f, 2f);
            }
            
            // Instructions
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string status;
            if (useTexture)
                status = $"TEXTURE (Slot {m_PaintBrush.ActiveTextureSlot + 1}) | LClick=Paint | RClick=Sample | MClick=Stop";
            else if (useCustom)
                status = "CUSTOM COLOR | LClick=Paint | RClick=Sample | MClick=Stop";
            else if (hasSamples)
                status = $"SAMPLED ({m_PaintBrush.SampledColorCount}) | LClick=Paint | RClick=Resample | MClick=Stop";
            else
                status = "RClick to sample colors OR use Custom Color | MClick=Stop";
            Handles.Label(pos + Vector3.up * (radius * 0.3f), status, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void HandleTextureStampScene(SceneView sceneView, Event e)
        {
            if (m_PaintBrush == null) return;
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            m_PaintBrush.TargetRenderer = m_TargetRenderer;
            
            var activeTex = m_PaintBrush.GetTextureSlot(m_StampActiveSlot);
            if (activeTex == null)
            {
                // Show message in scene
                Handles.BeginGUI();
                GUIStyle style = new GUIStyle(EditorStyles.boldLabel) { fontSize = 14, normal = { textColor = COL_WARNING } };
                GUI.Label(new Rect(20, 40, 400, 30), "No texture in slot - Use Paint tool to capture first", style);
                Handles.EndGUI();
                return;
            }
            
            Camera cam = sceneView.camera;
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 camForward = cam.transform.forward;
            
            // Only do expensive surface detection on mouse events, use simple hit for preview
            Vector3 hitPoint;
            if (e.type == EventType.MouseDown || e.type == EventType.MouseUp)
            {
                float pivotDist = Vector3.Distance(cam.transform.position, sceneView.pivot);
                Vector3? surfacePos = m_PaintBrush.GetSurfacePositionForPreview(ray, cam, pivotDist);
                hitPoint = surfacePos ?? GetBrushHitPoint(ray, sceneView);
            }
            else
            {
                hitPoint = GetBrushHitPoint(ray, sceneView);
            }
            
            // Cancel with ESC
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                m_IsDraggingStamp = false;
                e.Use();
                Repaint();
                return;
            }
            
            // Middle mouse to deactivate
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
                return;
            }
            
            // Start drag - lock surface depth
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                m_StampStartWorld = hitPoint;
                m_StampEndWorld = hitPoint;
                m_StampSurfaceDepth = Vector3.Dot(hitPoint - cam.transform.position, camForward);
                m_IsDraggingStamp = true;
                e.Use();
            }
            
            // Continue drag - project to locked depth plane
            if (e.type == EventType.MouseDrag && m_IsDraggingStamp)
            {
                // Project ray to the locked depth plane
                Plane depthPlane = new Plane(-camForward, cam.transform.position + camForward * m_StampSurfaceDepth);
                if (depthPlane.Raycast(ray, out float dragHitDist))
                    m_StampEndWorld = ray.GetPoint(dragHitDist);
                else
                    m_StampEndWorld = hitPoint;
                sceneView.Repaint();
                e.Use();
            }
            
            // End drag - execute stamp
            if (e.type == EventType.MouseUp && e.button == 0 && m_IsDraggingStamp)
            {
                // Project final position to locked depth
                Plane depthPlane = new Plane(-camForward, cam.transform.position + camForward * m_StampSurfaceDepth);
                if (depthPlane.Raycast(ray, out float endHitDist))
                    m_StampEndWorld = ray.GetPoint(endHitDist);
                
                m_IsDraggingStamp = false;
                
                // Calculate stamp rect using camera-aligned coordinates
                Vector3 camRight = cam.transform.right;
                Vector3 camUp = cam.transform.up;
                
                Vector3 diff = m_StampEndWorld - m_StampStartWorld;
                float width = Mathf.Abs(Vector3.Dot(diff, camRight));
                float height = Mathf.Abs(Vector3.Dot(diff, camUp));
                
                if (width > 0.01f && height > 0.01f)
                {
                    ExecuteTextureStamp(m_StampStartWorld, m_StampEndWorld, cam, activeTex);
                }
                
                e.Use();
                Repaint();
            }
            
            // Draw preview
            DrawTextureStampPreview(hitPoint, sceneView, activeTex);
        }
        
        private void ExecuteTextureStamp(Vector3 startPos, Vector3 endPos, Camera cam, Texture2D tex)
        {
            if (m_TargetRenderer == null) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 camRight = cam.transform.right;
            Vector3 camUp = cam.transform.up;
            Vector3 camForward = cam.transform.forward;
            
            // Calculate layer offset (towards camera)
            float layerOffset = m_StampLayeringEnabled ? m_StampCurrentLayer * m_StampLayerSpacing : 0f;
            Vector3 layerOffsetVec = -camForward * layerOffset;
            
            // Calculate camera-aligned dimensions
            Vector3 diff = endPos - startPos;
            float worldWidth = Vector3.Dot(diff, camRight);
            float worldHeight = Vector3.Dot(diff, camUp);
            
            // Determine origin corner
            Vector3 origin = startPos;
            float absWidth = Mathf.Abs(worldWidth);
            float absHeight = Mathf.Abs(worldHeight);
            
            if (worldWidth < 0)
            {
                origin += camRight * worldWidth;
                worldWidth = absWidth;
            }
            if (worldHeight < 0)
            {
                origin += camUp * worldHeight;
                worldHeight = absHeight;
            }
            
            if (absWidth < 0.01f || absHeight < 0.01f) return;
            
            // Calculate resolution based on texture aspect ratio
            float texAspect = (float)tex.width / tex.height;
            float stampAspect = worldWidth / worldHeight;
            
            int countX, countY;
            if (stampAspect > texAspect)
            {
                countY = m_StampResolution;
                countX = Mathf.Max(4, Mathf.RoundToInt(m_StampResolution * stampAspect / texAspect));
            }
            else
            {
                countX = m_StampResolution;
                countY = Mathf.Max(4, Mathf.RoundToInt(m_StampResolution * texAspect / stampAspect));
            }
            
            // Cap total splats for performance (512x512 = 262144 max)
            int totalSplats = countX * countY;
            int maxSplats = 262144;
            if (totalSplats > maxSplats)
            {
                float scale = Mathf.Sqrt((float)maxSplats / totalSplats);
                countX = Mathf.Max(4, Mathf.RoundToInt(countX * scale));
                countY = Mathf.Max(4, Mathf.RoundToInt(countY * scale));
                totalSplats = countX * countY;
            }
            
            // Auto-calculate splat size to fill the stamp area
            float cellWidth = worldWidth / countX;
            float cellHeight = worldHeight / countY;
            float splatSize = Mathf.Max(cellWidth, cellHeight) * m_StampSplatSizeMultiplier;
            
            // Convert to local space scale
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localSplatSize = splatSize / Mathf.Max(rendererScale, 0.001f);
            
            // Prepare data arrays
            Vector3[] positions = new Vector3[totalSplats];
            Color[] colors = new Color[totalSplats];
            float[] sizes = new float[totalSplats];
            
            Color[] texColors = tex.GetPixels();
            int texW = tex.width;
            int texH = tex.height;
            
            // Sample existing splats for blending if not Replace mode
            Color[] baseColors = null;
            if (m_StampBlendMode != StampBlendMode.Replace)
            {
                baseColors = SampleExistingSplatsInRegion(origin, camRight, camUp, worldWidth, worldHeight, cam);
            }
            
            int idx = 0;
            for (int y = 0; y < countY; y++)
            {
                for (int x = 0; x < countX; x++)
                {
                    float fx = (x + 0.5f) / countX;
                    float fy = (y + 0.5f) / countY;
                    
                    // World position at locked surface depth with layer offset
                    Vector3 worldPos = origin + camRight * (fx * worldWidth) + camUp * (fy * worldHeight) + layerOffsetVec;
                    Vector3 localPos = t.InverseTransformPoint(worldPos);
                    
                    // Sample texture with bilinear-ish sampling
                    int texX = Mathf.Clamp(Mathf.RoundToInt(fx * (texW - 1)), 0, texW - 1);
                    int texY = Mathf.Clamp(Mathf.RoundToInt(fy * (texH - 1)), 0, texH - 1);
                    Color col = texColors[texY * texW + texX];
                    
                    // Apply blend mode if we have base colors
                    if (baseColors != null && baseColors.Length > 0)
                    {
                        Color baseColor = baseColors[idx % baseColors.Length];
                        col = ApplyStampBlendMode(col, baseColor, m_StampBlendMode);
                    }
                    
                    positions[idx] = localPos;
                    colors[idx] = col;
                    sizes[idx] = localSplatSize;
                    idx++;
                }
            }
            
            // Paint splats - PaintSplatsBatch handles buffer expansion internally
            int startIndex = m_TargetRenderer.splatCount;
            m_TargetRenderer.PaintSplatsBatch(startIndex, positions, sizes, colors, totalSplats, m_StampDensity);
            
            // Finalize stamp - reset paint brush state and force re-sort
            m_PaintBrush.ResetBufferState();
            m_TargetRenderer.ForceResort();
            
            // Increment layer for next stamp if layering enabled
            string blendInfo = m_StampBlendMode != StampBlendMode.Replace ? $", blend={m_StampBlendMode}" : "";
            if (m_StampLayeringEnabled)
            {
                m_StampCurrentLayer++;
                Debug.Log($"Stamped {totalSplats} splats ({countX}x{countY}), layer={m_StampCurrentLayer - 1}{blendInfo}");
            }
            else
            {
                Debug.Log($"Stamped {totalSplats} splats ({countX}x{countY}){blendInfo}");
            }
        }
        
        private Color ApplyStampBlendMode(Color texColor, Color baseColor, StampBlendMode mode)
        {
            Color result;
            switch (mode)
            {
                case StampBlendMode.Multiply:
                    result = new Color(texColor.r * baseColor.r, texColor.g * baseColor.g, texColor.b * baseColor.b, texColor.a);
                    break;
                case StampBlendMode.Screen:
                    result = new Color(
                        1f - (1f - texColor.r) * (1f - baseColor.r),
                        1f - (1f - texColor.g) * (1f - baseColor.g),
                        1f - (1f - texColor.b) * (1f - baseColor.b),
                        texColor.a);
                    break;
                case StampBlendMode.Overlay:
                    result = new Color(
                        baseColor.r < 0.5f ? 2f * texColor.r * baseColor.r : 1f - 2f * (1f - texColor.r) * (1f - baseColor.r),
                        baseColor.g < 0.5f ? 2f * texColor.g * baseColor.g : 1f - 2f * (1f - texColor.g) * (1f - baseColor.g),
                        baseColor.b < 0.5f ? 2f * texColor.b * baseColor.b : 1f - 2f * (1f - texColor.b) * (1f - baseColor.b),
                        texColor.a);
                    break;
                case StampBlendMode.Darken:
                    result = new Color(
                        Mathf.Min(texColor.r, baseColor.r),
                        Mathf.Min(texColor.g, baseColor.g),
                        Mathf.Min(texColor.b, baseColor.b),
                        texColor.a);
                    break;
                case StampBlendMode.Lighten:
                    result = new Color(
                        Mathf.Max(texColor.r, baseColor.r),
                        Mathf.Max(texColor.g, baseColor.g),
                        Mathf.Max(texColor.b, baseColor.b),
                        texColor.a);
                    break;
                default: // Replace
                    result = texColor;
                    break;
            }
            return result;
        }

        private Color[] SampleExistingSplatsInRegion(Vector3 origin, Vector3 camRight, Vector3 camUp, float width, float height, Camera cam)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return null;
            
            var posBuffer = m_TargetRenderer.GpuPosData;
            if (posBuffer == null) return null;
            
            int splatCount = m_TargetRenderer.splatCount;
            if (splatCount <= 0) return null;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 center = origin + camRight * (width * 0.5f) + camUp * (height * 0.5f);
            float searchRadius = Mathf.Max(width, height) * 0.6f;
            
            // Read position data (smaller sample for performance)
            int maxSamples = Mathf.Min(splatCount, 10000);
            float[] posData = new float[maxSamples * 3];
            posBuffer.GetData(posData, 0, 0, maxSamples * 3);
            
            // Read color texture
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(splatCount);
            Texture colorTex = m_TargetRenderer.GpuColorData;
            Color[] texColors = null;
            
            if (colorTex is Texture2D tex2D)
            {
                try { texColors = tex2D.GetPixels(); }
                catch { return null; }
            }
            else if (colorTex is RenderTexture rt)
            {
                var prevActive = RenderTexture.active;
                try
                {
                    RenderTexture.active = rt;
                    var tempTex = new Texture2D(texWidth, texHeight, TextureFormat.RGBAHalf, false);
                    tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
                    tempTex.Apply();
                    texColors = tempTex.GetPixels();
                    DestroyImmediate(tempTex);
                }
                finally { RenderTexture.active = prevActive; }
            }
            
            if (texColors == null) return null;
            
            List<Color> foundColors = new List<Color>(100);
            float searchRadiusSq = searchRadius * searchRadius;
            
            for (int i = 0; i < maxSamples && foundColors.Count < 100; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 wpos = t.TransformPoint(localPos);
                
                if ((wpos - center).sqrMagnitude < searchRadiusSq)
                {
                    int cx = i % texWidth;
                    int cy = i / texWidth;
                    if (cy < texHeight && cx < texWidth)
                    {
                        int colorIdx = cy * texWidth + cx;
                        if (colorIdx < texColors.Length)
                            foundColors.Add(texColors[colorIdx]);
                    }
                }
            }
            
            return foundColors.Count > 0 ? foundColors.ToArray() : null;
        }

        private void DrawTextureStampPreview(Vector3 cursorPos, SceneView sceneView, Texture2D tex)
        {
            Camera cam = sceneView.camera;
            Vector3 camForward = cam.transform.forward;
            Vector3 camRight = cam.transform.right;
            Vector3 camUp = cam.transform.up;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            if (m_IsDraggingStamp)
            {
                // Calculate layer offset for preview
                float layerOffset = m_StampLayeringEnabled ? m_StampCurrentLayer * m_StampLayerSpacing : 0f;
                Vector3 layerOffsetVec = -camForward * layerOffset;
                
                // Use camera-aligned corners with layer offset
                Vector3 size = m_StampEndWorld - m_StampStartWorld;
                float w = Vector3.Dot(size, camRight);
                float h = Vector3.Dot(size, camUp);
                
                Vector3 start = m_StampStartWorld + layerOffsetVec;
                Vector3[] corners = new Vector3[4];
                corners[0] = start;
                corners[1] = start + camRight * w;
                corners[2] = start + camRight * w + camUp * h;
                corners[3] = start + camUp * h;
                
                // Fill
                Handles.color = new Color(0.9f, 0.5f, 0.9f, 0.2f);
                Handles.DrawAAConvexPolygon(corners);
                
                // Border
                Handles.color = new Color(0.9f, 0.5f, 0.9f, 0.9f);
                Handles.DrawLine(corners[0], corners[1], 2f);
                Handles.DrawLine(corners[1], corners[2], 2f);
                Handles.DrawLine(corners[2], corners[3], 2f);
                Handles.DrawLine(corners[3], corners[0], 2f);
                
                // Grid preview (simplified)
                Handles.color = new Color(1f, 1f, 1f, 0.3f);
                int gridLines = Mathf.Min(m_StampResolution, 12);
                for (int i = 1; i < gridLines; i++)
                {
                    float f = (float)i / gridLines;
                    Vector3 p0 = corners[0] + (corners[1] - corners[0]) * f;
                    Vector3 p1 = corners[3] + (corners[2] - corners[3]) * f;
                    Handles.DrawLine(p0, p1, 1f);
                    p0 = corners[0] + (corners[3] - corners[0]) * f;
                    p1 = corners[1] + (corners[2] - corners[1]) * f;
                    Handles.DrawLine(p0, p1, 1f);
                }
                
                // Size label (use cached style)
                if (s_StampLabelStyle == null)
                    s_StampLabelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
                
                int estSplats = m_StampResolution * m_StampResolution;
                string layerLabel = m_StampLayeringEnabled ? $" | Layer {m_StampCurrentLayer}" : "";
                Handles.Label(corners[2] + camUp * 0.1f, $"~{estSplats} splats{layerLabel}", s_StampLabelStyle);
            }
            else
            {
                // Cursor indicator
                Handles.color = new Color(0.9f, 0.5f, 0.9f, 0.7f);
                Handles.DrawWireDisc(cursorPos, -camForward, 0.1f, 2f);
                
                if (s_StampLabelStyle == null)
                    s_StampLabelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
                
                string layerInfo = m_StampLayeringEnabled ? $" | Layer {m_StampCurrentLayer}" : "";
                Handles.Label(cursorPos + camUp * 0.15f, $"STAMP (Slot {m_StampActiveSlot + 1}){layerInfo} | Drag to stamp", s_StampLabelStyle);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void HandleSculptBrushScene(SceneView sceneView, Event e)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            if (m_PaintBrush == null) { CreateToolGameObject(BrushTool.PaintBrush); return; }
            
            // Ensure original positions are captured for restore functionality (ALT key)
            m_TargetRenderer.EnsureOriginalPositionsCaptured();
            
            m_PaintBrush.TargetRenderer = m_TargetRenderer;
            
            Camera cam = sceneView.camera;
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            double now = EditorApplication.timeSinceStartup;
            
            // Determine current mode based on tab and modifiers
            bool isRelaxMode = m_SculptBrushTab == 4;
            bool isFlattenMode = m_SculptBrushTab == 3;
            bool isMoveMode = m_SculptBrushTab == 2;
            bool isPinchMode = m_SculptBrushTab == 1 || (m_SculptBrushTab == 0 && e.shift);  // Pinch tab OR shift in smudge
            bool isConstrainedMove = isMoveMode && e.shift;  // SHIFT in move mode = straight line
            
            // Get the active radius based on mode
            float activeRadius;
            if (isRelaxMode)
                activeRadius = m_RelaxRadius;
            else if (isFlattenMode)
                activeRadius = m_FlattenRadius;
            else if (isMoveMode)
                activeRadius = m_MoveRadius;
            else if (isPinchMode)
                activeRadius = m_PinchRadius;
            else
                activeRadius = m_SmudgeRadius;
            
            // OPTIMIZED: Use cached surface position, only update periodically to avoid GPU readback every frame
            float pivotDist = Vector3.Distance(cam.transform.position, sceneView.pivot);
            Vector3 hitPoint;
            
            bool shouldUpdateSurface = !m_SmudgeHasCachedSurface || 
                                       (now - m_SmudgeLastSurfaceUpdate > SMUDGE_SURFACE_UPDATE_INTERVAL) ||
                                       (e.type == EventType.MouseDown && e.button == 0);
            
            if (shouldUpdateSurface)
            {
                // Expensive: do GPU readback only periodically
                Vector3? surfacePos = m_PaintBrush.GetSurfacePositionForPreview(ray, cam, pivotDist);
                if (surfacePos.HasValue)
                {
                    m_SmudgeCachedSurfacePos = surfacePos.Value;
                    m_SmudgeCachedDepth = Vector3.Dot(surfacePos.Value - cam.transform.position, cam.transform.forward);
                    m_SmudgeHasCachedSurface = true;
                }
                m_SmudgeLastSurfaceUpdate = now;
                hitPoint = surfacePos ?? GetBrushHitPoint(ray, sceneView);
            }
            else if (m_SmudgeHasCachedSurface)
            {
                // Fast: project ray to cached depth plane
                Plane depthPlane = new Plane(-cam.transform.forward, cam.transform.position + cam.transform.forward * m_SmudgeCachedDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                    hitPoint = ray.GetPoint(hitDist);
                else
                    hitPoint = GetBrushHitPoint(ray, sceneView);
            }
            else
            {
                hitPoint = GetBrushHitPoint(ray, sceneView);
            }
            
            // Calculate world radius same as other brushes
            float worldRadius = CalculateWorldRadius(hitPoint, sceneView, activeRadius);
            float brushRadius = worldRadius * 10f; // Match paint brush scale
            
            // Middle mouse to deactivate
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                m_SmudgeHasCachedSurface = false;
                m_IsMoving = false;
                m_IsFlattening = false;
                m_IsRelaxing = false;
                m_MoveConstrainLine = false;
                e.Use();
                Repaint();
                return;
            }
            
            // Scroll to resize - resize the active brush
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                if (isRelaxMode)
                    m_RelaxRadius = Mathf.Clamp(m_RelaxRadius - e.delta.y * 0.3f, 0.5f, 25f);
                else if (isFlattenMode)
                    m_FlattenRadius = Mathf.Clamp(m_FlattenRadius - e.delta.y * 0.3f, 1f, 25f);
                else if (isMoveMode)
                    m_MoveRadius = Mathf.Clamp(m_MoveRadius - e.delta.y * 0.3f, 0.5f, 25f);
                else if (isPinchMode)
                    m_PinchRadius = Mathf.Clamp(m_PinchRadius - e.delta.y * 0.3f, 0.5f, 25f);
                else
                    m_SmudgeRadius = Mathf.Clamp(m_SmudgeRadius - e.delta.y * 0.3f, 0.5f, 25f);
                e.Use();
                Repaint();
            }
            
            // ALT+drag to restore splat positions to original (works with any sculpt brush)
            if (e.type == EventType.MouseDown && e.button == 0 && e.alt)
            {
                m_IsRestoringSculpt = true;
                m_SmudgeLastPos = hitPoint;
                m_SmudgeLastExecuteTime = now;
                
                // Execute restore immediately on click
                float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, activeRadius) * 10f;
                ExecuteRestoreOptimized(hitPoint, execWorldRadius);
                e.Use();
            }
            
            // Continue ALT+drag restore
            if ((e.type == EventType.MouseDrag || e.type == EventType.MouseMove) && m_IsRestoringSculpt && e.button == 0 && e.alt)
            {
                m_SmudgeLastPos = hitPoint;
                
                // Execute restore at throttled rate
                if (now - m_SmudgeLastExecuteTime >= SMUDGE_MIN_INTERVAL)
                {
                    float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, activeRadius) * 10f;
                    ExecuteRestoreOptimized(hitPoint, execWorldRadius);
                    m_SmudgeLastExecuteTime = now;
                }
                e.Use();
            }
            
            // End ALT+drag restore (mouse up or ALT released)
            if ((e.type == EventType.MouseUp && e.button == 0 && m_IsRestoringSculpt) || 
                (m_IsRestoringSculpt && !e.alt && (e.type == EventType.MouseDrag || e.type == EventType.MouseMove)))
            {
                m_IsRestoringSculpt = false;
            }
            
            // Start sculpt operation - do fresh surface detection
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                m_SmudgeLastPos = hitPoint;
                m_SmudgeAccumulatedDelta = Vector3.zero;
                m_SmudgeLastExecuteTime = now;
                
                if (isRelaxMode)
                {
                    m_IsRelaxing = true;
                    m_IsRoughening = e.shift;  // SHIFT = roughen/scatter instead of smooth
                    m_IsSmudging = false;
                    m_IsPinching = false;
                    m_IsMoving = false;
                    m_IsFlattening = false;
                    // Execute relax immediately on click
                    float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, m_RelaxRadius) * 10f;
                    ExecuteRelaxOptimized(hitPoint, execWorldRadius, m_IsRoughening);
                }
                else if (isFlattenMode)
                {
                    m_IsFlattening = true;
                    m_FlattenPlanePoint = hitPoint;
                    m_FlattenPlaneNormal = Vector3.zero;  // Will be set on first drag
                    m_IsSmudging = false;
                    m_IsPinching = false;
                    m_IsMoving = false;
                    m_IsRelaxing = false;
                }
                else if (isMoveMode)
                {
                    m_IsMoving = true;
                    m_MoveStartPos = hitPoint;
                    m_MoveConstrainLine = e.shift;
                    m_MoveConstraintAxis = Vector3.zero;  // Will be set on first drag
                    m_IsSmudging = false;
                    m_IsPinching = false;
                    m_IsFlattening = false;
                    m_IsRelaxing = false;
                }
                else
                {
                    m_IsPinching = isPinchMode;
                    m_IsSmudging = true;
                    m_IsMoving = false;
                    m_IsFlattening = false;
                    m_IsRelaxing = false;
                }
                e.Use();
            }
            
            // Continue sculpt with throttling
            if ((e.type == EventType.MouseDrag || e.type == EventType.MouseMove) && (m_IsSmudging || m_IsMoving || m_IsFlattening || m_IsRelaxing) && e.button == 0)
            {
                Vector3 delta = hitPoint - m_SmudgeLastPos;
                
                // Handle Relax mode - continuously apply while dragging
                if (m_IsRelaxing)
                {
                    m_SmudgeLastPos = hitPoint;
                    // Update roughening state based on current SHIFT
                    m_IsRoughening = e.shift;
                    
                    // Execute relax at throttled rate
                    if (now - m_SmudgeLastExecuteTime >= SMUDGE_MIN_INTERVAL)
                    {
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, m_RelaxRadius) * 10f;
                        ExecuteRelaxOptimized(hitPoint, execWorldRadius, m_IsRoughening);
                        m_SmudgeLastExecuteTime = now;
                    }
                }
                // Handle Flatten mode
                else if (m_IsFlattening)
                {
                    m_SmudgeAccumulatedDelta += delta;
                    m_SmudgeLastPos = hitPoint;
                    
                    // Determine flatten plane normal from accumulated movement direction
                    if (m_FlattenPlaneNormal == Vector3.zero && m_SmudgeAccumulatedDelta.magnitude > 0.02f)
                    {
                        m_FlattenPlaneNormal = m_SmudgeAccumulatedDelta.normalized;
                    }
                    
                    float accumulatedMag = m_SmudgeAccumulatedDelta.magnitude;
                    
                    if ((now - m_SmudgeLastExecuteTime >= SMUDGE_MIN_INTERVAL) && accumulatedMag > SMUDGE_MIN_DISTANCE && m_FlattenPlaneNormal != Vector3.zero)
                    {
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, m_FlattenRadius) * 10f;
                        ExecuteFlattenOptimized(hitPoint, m_FlattenPlaneNormal, execWorldRadius);
                        m_SmudgeAccumulatedDelta = Vector3.zero;
                        m_SmudgeLastExecuteTime = now;
                    }
                }
                // Handle Move mode with optional line constraint
                else if (m_IsMoving)
                {
                    // Check if SHIFT state changed during drag
                    m_MoveConstrainLine = e.shift;
                    
                    if (m_MoveConstrainLine)
                    {
                        // Constrain to straight line from start position
                        if (m_MoveConstraintAxis == Vector3.zero && delta.magnitude > 0.01f)
                        {
                            // Determine constraint axis based on initial movement direction
                            // Project onto camera plane and find dominant axis
                            Vector3 camRight = cam.transform.right;
                            Vector3 camUp = cam.transform.up;
                            
                            float rightComponent = Mathf.Abs(Vector3.Dot(delta, camRight));
                            float upComponent = Mathf.Abs(Vector3.Dot(delta, camUp));
                            
                            m_MoveConstraintAxis = rightComponent > upComponent ? camRight : camUp;
                        }
                        
                        if (m_MoveConstraintAxis != Vector3.zero)
                        {
                            // Project delta onto constraint axis
                            delta = Vector3.Project(delta, m_MoveConstraintAxis);
                        }
                    }
                    
                    m_SmudgeAccumulatedDelta += delta;
                    m_SmudgeLastPos = hitPoint;
                    
                    float accumulatedMag = m_SmudgeAccumulatedDelta.magnitude;
                    
                    if ((now - m_SmudgeLastExecuteTime >= SMUDGE_MIN_INTERVAL) && accumulatedMag > SMUDGE_MIN_DISTANCE)
                    {
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, m_MoveRadius) * 10f;
                        ExecuteMoveOptimized(hitPoint, m_SmudgeAccumulatedDelta, execWorldRadius);
                        m_SmudgeAccumulatedDelta = Vector3.zero;
                        m_SmudgeLastExecuteTime = now;
                    }
                }
                else
                {
                    // Smudge/Pinch mode
                    m_SmudgeAccumulatedDelta += delta;
                    m_SmudgeLastPos = hitPoint;
                    
                    // Update pinch mode based on current state (tab or shift)
                    m_IsPinching = m_SculptBrushTab == 1 || e.shift;
                    
                    float accumulatedMag = m_SmudgeAccumulatedDelta.magnitude;
                    
                    if ((now - m_SmudgeLastExecuteTime >= SMUDGE_MIN_INTERVAL) && accumulatedMag > SMUDGE_MIN_DISTANCE)
                    {
                        float execRadius = m_IsPinching ? m_PinchRadius : m_SmudgeRadius;
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, execRadius) * 10f;
                        
                        if (m_IsPinching)
                        {
                            ExecutePinchOptimized(hitPoint, execWorldRadius);
                        }
                        else
                        {
                            ExecuteSmudgeOptimized(hitPoint, m_SmudgeAccumulatedDelta, execWorldRadius);
                        }
                        m_SmudgeAccumulatedDelta = Vector3.zero;
                        m_SmudgeLastExecuteTime = now;
                    }
                }
                
                e.Use();
            }
            
            // End sculpt - flush any remaining accumulated delta
            if (e.type == EventType.MouseUp && e.button == 0)
            {
                if (m_SmudgeAccumulatedDelta.magnitude > 0.001f)
                {
                    if (m_IsFlattening && m_FlattenPlaneNormal != Vector3.zero)
                    {
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, m_FlattenRadius) * 10f;
                        ExecuteFlattenOptimized(hitPoint, m_FlattenPlaneNormal, execWorldRadius);
                    }
                    else if (m_IsMoving)
                    {
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, m_MoveRadius) * 10f;
                        ExecuteMoveOptimized(hitPoint, m_SmudgeAccumulatedDelta, execWorldRadius);
                    }
                    else if (m_IsSmudging)
                    {
                        float execRadius = m_IsPinching ? m_PinchRadius : m_SmudgeRadius;
                        float execWorldRadius = CalculateWorldRadius(hitPoint, sceneView, execRadius) * 10f;
                        
                        if (m_IsPinching)
                        {
                            ExecutePinchOptimized(hitPoint, execWorldRadius);
                        }
                        else
                        {
                            ExecuteSmudgeOptimized(hitPoint, m_SmudgeAccumulatedDelta, execWorldRadius);
                        }
                    }
                    // Relax doesn't need flush - it executes continuously
                }
                m_IsSmudging = false;
                m_IsPinching = false;
                m_IsFlattening = false;
                m_FlattenPlaneNormal = Vector3.zero;
                m_IsMoving = false;
                m_IsRelaxing = false;
                m_IsRoughening = false;
                m_MoveConstrainLine = false;
                m_MoveConstraintAxis = Vector3.zero;
                m_SmudgeAccumulatedDelta = Vector3.zero;
            }
            
            // Draw preview
            bool isRoughenMode = isRelaxMode && (e.shift || m_IsRoughening);
            bool isRestoreMode = e.alt || m_IsRestoringSculpt;
            DrawSculptBrushPreview(hitPoint, brushRadius, sceneView, isPinchMode, isMoveMode, isFlattenMode, isRelaxMode, isConstrainedMove || (m_IsMoving && m_MoveConstrainLine), isRoughenMode, isRestoreMode);
        }
        
        private void ExecuteSmudgeOptimized(Vector3 center, Vector3 delta, float worldRadius)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 localCenter = t.InverseTransformPoint(center);
            Vector3 localDelta = t.InverseTransformVector(delta);
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            
            // Use GPU-based smudge
            m_TargetRenderer.SmudgeSplatsGPU(localCenter, localDelta, localRadius, m_SmudgeFalloff, m_SmudgeStrength, m_SmudgeBlendColors);
            
            // Only repaint the current focused scene view, not all
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Repaint();
        }
        
        private void ExecutePinchOptimized(Vector3 center, float worldRadius)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 localCenter = t.InverseTransformPoint(center);
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            
            // Use GPU-based pinch with pinch-specific falloff
            m_TargetRenderer.PinchSplatsGPU(localCenter, localRadius, m_PinchFalloff, m_PinchStrength);
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Repaint();
        }
        
        private void ExecuteMoveOptimized(Vector3 center, Vector3 delta, float worldRadius)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 localCenter = t.InverseTransformPoint(center);
            Vector3 localDelta = t.InverseTransformVector(delta);
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            
            // Use GPU-based smudge but with Move brush's gentler settings (no color blending)
            m_TargetRenderer.SmudgeSplatsGPU(localCenter, localDelta, localRadius, m_MoveFalloff, m_MoveStrength, false);
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Repaint();
        }
        
        private void ExecuteFlattenOptimized(Vector3 center, Vector3 planeNormal, float worldRadius)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 localCenter = t.InverseTransformPoint(center);
            Vector3 localNormal = t.InverseTransformDirection(planeNormal).normalized;
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            
            // Use GPU-based flatten
            m_TargetRenderer.FlattenSplatsGPU(localCenter, localNormal, localRadius, m_FlattenFalloff, m_FlattenStrength);
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Repaint();
        }
        
        private void ExecuteRelaxOptimized(Vector3 center, float worldRadius, bool invert = false)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 localCenter = t.InverseTransformPoint(center);
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            
            // Use GPU-based relax with neighbor radius scaled by brush radius
            // invert = true means roughen/scatter instead of smooth
            float localNeighborRadius = localRadius * m_RelaxNeighborRadius;
            m_TargetRenderer.RelaxSplatsGPU(localCenter, localRadius, m_RelaxFalloff, m_RelaxStrength, localNeighborRadius, invert);
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Repaint();
        }
        
        private void ExecuteRestoreOptimized(Vector3 center, float worldRadius)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            Transform t = m_TargetRenderer.transform;
            Vector3 localCenter = t.InverseTransformPoint(center);
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            
            // Get active brush falloff and strength based on current tab
            float activeFalloff, activeStrength;
            switch (m_SculptBrushTab)
            {
                case 4: activeFalloff = m_RelaxFalloff; activeStrength = m_RelaxStrength; break;
                case 3: activeFalloff = m_FlattenFalloff; activeStrength = m_FlattenStrength; break;
                case 2: activeFalloff = m_MoveFalloff; activeStrength = m_MoveStrength; break;
                case 1: activeFalloff = m_PinchFalloff; activeStrength = m_PinchStrength; break;
                default: activeFalloff = m_SmudgeFalloff; activeStrength = m_SmudgeStrength; break;
            }
            
            m_TargetRenderer.RestorePositionsInSphereGPU(localCenter, localRadius, activeFalloff, activeStrength);
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Repaint();
        }
        
        private void DrawSculptBrushPreview(Vector3 pos, float radius, SceneView sceneView, bool isPinchMode, bool isMoveMode = false, bool isFlattenMode = false, bool isRelaxMode = false, bool isConstrainedMove = false, bool isRoughenMode = false, bool isRestoreMode = false)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Camera cam = sceneView.camera;
            Event e = Event.current;
            bool shiftHeld = e != null && e.shift;
            bool isTabPinch = m_SculptBrushTab == 1;
            bool isTabMove = m_SculptBrushTab == 2;
            bool isTabFlatten = m_SculptBrushTab == 3;
            bool isTabRelax = m_SculptBrushTab == 4;
            
            Color mainColor;
            // Restore mode takes priority - bright green color
            if (m_IsRestoringSculpt)
                mainColor = new Color(0.3f, 1f, 0.4f, 0.9f);  // Bright green when restoring
            else if (isRestoreMode && !m_IsSmudging && !m_IsMoving && !m_IsFlattening && !m_IsRelaxing)
                mainColor = new Color(0.3f, 0.9f, 0.4f, 0.7f);  // Green for restore mode preview (ALT held)
            else if (m_IsRelaxing && m_IsRoughening)
                mainColor = new Color(1f, 0.5f, 0.3f, 0.9f);  // Orange-red when roughening
            else if (m_IsRelaxing)
                mainColor = new Color(0.4f, 0.9f, 0.7f, 0.9f);  // Teal when relaxing
            else if (m_IsFlattening)
                mainColor = new Color(0.95f, 0.7f, 0.2f, 0.9f);  // Gold/Yellow when flattening
            else if (m_IsMoving && isConstrainedMove)
                mainColor = new Color(0.2f, 0.9f, 0.5f, 0.9f);  // Green when constrained move
            else if (m_IsMoving)
                mainColor = new Color(0.3f, 0.8f, 0.9f, 0.9f);  // Cyan when moving
            else if (m_IsSmudging && m_IsPinching)
                mainColor = new Color(0.8f, 0.2f, 1f, 0.9f);  // Purple when pinching
            else if (m_IsSmudging)
                mainColor = new Color(1f, 0.6f, 0.2f, 0.9f);  // Orange when smudging
            else if (isRelaxMode && isRoughenMode)
                mainColor = new Color(0.95f, 0.5f, 0.3f, 0.7f);  // Orange-red for roughen mode preview
            else if (isRelaxMode)
                mainColor = new Color(0.4f, 0.85f, 0.65f, 0.7f);  // Teal for relax mode
            else if (isFlattenMode)
                mainColor = new Color(0.9f, 0.65f, 0.2f, 0.7f);  // Gold for flatten mode
            else if (isMoveMode)
                mainColor = isConstrainedMove ? new Color(0.2f, 0.8f, 0.5f, 0.7f) : new Color(0.3f, 0.7f, 0.85f, 0.7f);  // Cyan/Green for move mode
            else if (isPinchMode)
                mainColor = new Color(0.7f, 0.5f, 1f, 0.7f);  // Light purple for pinch mode
            else
                mainColor = new Color(0.6f, 0.8f, 1f, 0.7f);  // Light blue for smudge mode
            Color fillColor = new Color(mainColor.r, mainColor.g, mainColor.b, 0.15f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(pos, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(pos, -camForward, radius, 2f);
            
            // Falloff ring - use the appropriate falloff based on mode
            float activeFalloff;
            if (isRelaxMode)
                activeFalloff = m_RelaxFalloff;
            else if (isFlattenMode)
                activeFalloff = m_FlattenFalloff;
            else if (isMoveMode)
                activeFalloff = m_MoveFalloff;
            else if (isPinchMode)
                activeFalloff = m_PinchFalloff;
            else
                activeFalloff = m_SmudgeFalloff;
            float falloffRadius = radius * (1f - activeFalloff);
            Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.4f);
            Handles.DrawWireDisc(pos, -camForward, falloffRadius, 1f);
            
            // Center dot
            Handles.color = mainColor;
            Handles.DrawSolidDisc(pos, -camForward, radius * 0.03f);
            
            // Direction/mode indicators
            if (m_IsFlattening)
            {
                // Draw flatten plane indicator - a line showing the flatten direction
                if (m_FlattenPlaneNormal != Vector3.zero)
                {
                    Handles.color = new Color(1f, 0.8f, 0.3f, 0.9f);
                    Vector3 normalDir = m_FlattenPlaneNormal.normalized;
                    Handles.DrawLine(pos, pos + normalDir * radius * 0.7f, 3f);
                    
                    // Draw a small plane indicator perpendicular to movement
                    Vector3 perpRight = Vector3.Cross(normalDir, cam.transform.forward).normalized;
                    if (perpRight.magnitude < 0.1f)
                        perpRight = Vector3.Cross(normalDir, cam.transform.up).normalized;
                    Vector3 perpUp = Vector3.Cross(perpRight, normalDir).normalized;
                    
                    Handles.color = new Color(1f, 0.85f, 0.4f, 0.5f);
                    float planeSize = radius * 0.4f;
                    Handles.DrawLine(pos - perpRight * planeSize, pos + perpRight * planeSize, 2f);
                    Handles.DrawLine(pos - perpUp * planeSize, pos + perpUp * planeSize, 2f);
                }
                else
                {
                    // No direction yet - show a flat surface indicator
                    Handles.color = new Color(1f, 0.8f, 0.3f, 0.5f);
                    Vector3 camRight = cam.transform.right;
                    Vector3 camUp = cam.transform.up;
                    Handles.DrawLine(pos - camRight * radius * 0.4f, pos + camRight * radius * 0.4f, 2f);
                    Handles.DrawLine(pos - camUp * radius * 0.4f, pos + camUp * radius * 0.4f, 2f);
                }
            }
            else if (m_IsMoving)
            {
                // Draw move direction indicator
                Vector3 dir = (pos - m_SmudgeLastPos).normalized;
                if (dir.magnitude > 0.01f)
                {
                    Handles.color = new Color(0.3f, 0.9f, 0.9f, 0.9f);
                    Handles.DrawLine(pos, pos + dir * radius * 0.6f, 3f);
                }
                
                // If constrained, show the constraint axis
                if (isConstrainedMove && m_MoveConstraintAxis != Vector3.zero)
                {
                    Handles.color = new Color(0.2f, 1f, 0.5f, 0.6f);
                    Handles.DrawLine(pos - m_MoveConstraintAxis * radius * 0.8f, pos + m_MoveConstraintAxis * radius * 0.8f, 2f);
                }
            }
            else if (m_IsSmudging)
            {
                if (m_IsPinching)
                {
                    // Draw inward arrows for pinch
                    Handles.color = new Color(0.9f, 0.4f, 1f, 0.8f);
                    int arrows = 8;
                    for (int i = 0; i < arrows; i++)
                    {
                        float angle = (i / (float)arrows) * Mathf.PI * 2f;
                        Vector3 dir = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0);
                        dir = cam.transform.TransformDirection(dir);
                        Vector3 start = pos + dir * radius * 0.7f;
                        Vector3 end = pos + dir * radius * 0.3f;
                        Handles.DrawLine(start, end, 2f);
                    }
                }
                else
                {
                    Vector3 dir = (pos - m_SmudgeLastPos).normalized;
                    if (dir.magnitude > 0.01f)
                    {
                        Handles.color = new Color(1f, 0.8f, 0.3f, 0.8f);
                        Handles.DrawLine(pos, pos + dir * radius * 0.5f, 3f);
                    }
                }
            }
            else if (isMoveMode && !m_IsMoving)
            {
                // Show four-way arrows for move mode (idle)
                Handles.color = new Color(0.3f, 0.7f, 0.85f, 0.5f);
                Vector3 camRight = cam.transform.right;
                Vector3 camUp = cam.transform.up;
                float arrowLen = radius * 0.5f;
                float arrowStart = radius * 0.2f;
                
                // Draw cross pattern for move indicator
                Handles.DrawLine(pos + camRight * arrowStart, pos + camRight * arrowLen, 2f);
                Handles.DrawLine(pos - camRight * arrowStart, pos - camRight * arrowLen, 2f);
                Handles.DrawLine(pos + camUp * arrowStart, pos + camUp * arrowLen, 2f);
                Handles.DrawLine(pos - camUp * arrowStart, pos - camUp * arrowLen, 2f);
                
                // If shift held, show constraint preview
                if (shiftHeld)
                {
                    Handles.color = new Color(0.2f, 1f, 0.5f, 0.4f);
                    Handles.DrawLine(pos - camRight * radius * 0.7f, pos + camRight * radius * 0.7f, 1.5f);
                    Handles.DrawLine(pos - camUp * radius * 0.7f, pos + camUp * radius * 0.7f, 1.5f);
                }
            }
            else if (isPinchMode && !m_IsSmudging)
            {
                // Show inward arrows when in pinch mode (idle)
                Handles.color = new Color(0.7f, 0.4f, 1f, 0.5f);
                int arrows = 8;
                for (int i = 0; i < arrows; i++)
                {
                    float angle = (i / (float)arrows) * Mathf.PI * 2f;
                    Vector3 dir = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0);
                    dir = cam.transform.TransformDirection(dir);
                    Vector3 start = pos + dir * radius * 0.6f;
                    Vector3 end = pos + dir * radius * 0.35f;
                    Handles.DrawLine(start, end, 1.5f);
                }
            }
            
            // Show flatten mode idle indicator
            if (isFlattenMode && !m_IsFlattening)
            {
                // Draw a flat surface indicator
                Handles.color = new Color(0.9f, 0.7f, 0.3f, 0.4f);
                Vector3 camRight = cam.transform.right;
                Vector3 camUp = cam.transform.up;
                float lineLen = radius * 0.5f;
                Handles.DrawLine(pos - camRight * lineLen, pos + camRight * lineLen, 2f);
                Handles.DrawLine(pos - camUp * lineLen, pos + camUp * lineLen, 2f);
            }
            
            // Show relax/roughen mode indicator
            if (isRelaxMode)
            {
                bool isRoughening = isRoughenMode || m_IsRoughening;
                
                if (isRoughening)
                {
                    // Roughen mode - outward spikes/explosion pattern
                    Handles.color = (m_IsRelaxing && m_IsRoughening) ? new Color(1f, 0.6f, 0.3f, 0.8f) : new Color(0.95f, 0.55f, 0.35f, 0.5f);
                    int spikes = 8;
                    for (int i = 0; i < spikes; i++)
                    {
                        float angle = (i / (float)spikes) * Mathf.PI * 2f;
                        Vector3 dir = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0);
                        dir = cam.transform.TransformDirection(dir);
                        // Animated outward pulse
                        float pulse = Mathf.Sin((float)EditorApplication.timeSinceStartup * 4f) * 0.1f + 1f;
                        Vector3 start = pos + dir * radius * 0.35f;
                        Vector3 end = pos + dir * (radius * 0.65f * pulse);
                        Handles.DrawLine(start, end, (m_IsRelaxing && m_IsRoughening) ? 2.5f : 1.5f);
                        
                        // Small arrowheads pointing outward
                        if (m_IsRelaxing && m_IsRoughening)
                        {
                            Vector3 perpDir = new Vector3(-Mathf.Sin(angle), Mathf.Cos(angle), 0);
                            perpDir = cam.transform.TransformDirection(perpDir);
                            Vector3 arrowTip = end;
                            Handles.DrawLine(arrowTip, arrowTip - dir * radius * 0.08f + perpDir * radius * 0.05f, 2f);
                            Handles.DrawLine(arrowTip, arrowTip - dir * radius * 0.08f - perpDir * radius * 0.05f, 2f);
                        }
                    }
                }
                else
                {
                    // Relax mode - wavy lines converging
                    Handles.color = m_IsRelaxing ? new Color(0.4f, 1f, 0.7f, 0.7f) : new Color(0.4f, 0.85f, 0.65f, 0.4f);
                    int waves = 6;
                    for (int i = 0; i < waves; i++)
                    {
                        float angle = (i / (float)waves) * Mathf.PI * 2f;
                        Vector3 dir = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0);
                        dir = cam.transform.TransformDirection(dir);
                        float waveOffset = Mathf.Sin(angle * 3f + (float)EditorApplication.timeSinceStartup * 3f) * radius * 0.05f;
                        Vector3 start = pos + dir * (radius * 0.3f + waveOffset);
                        Vector3 end = pos + dir * (radius * 0.6f + waveOffset);
                        Handles.DrawLine(start, end, m_IsRelaxing ? 2f : 1.5f);
                    }
                }
            }
            
            // Restore mode indicator - rewind/undo arrows
            if (isRestoreMode || m_IsRestoringSculpt)
            {
                Handles.color = m_IsRestoringSculpt ? new Color(0.3f, 1f, 0.5f, 0.8f) : new Color(0.3f, 0.9f, 0.4f, 0.5f);
                int arrows = 4;
                for (int i = 0; i < arrows; i++)
                {
                    float angle = (i / (float)arrows) * Mathf.PI * 2f + (float)EditorApplication.timeSinceStartup * -2f; // Rotating inward
                    Vector3 dir = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0);
                    dir = cam.transform.TransformDirection(dir);
                    Vector3 start = pos + dir * radius * 0.6f;
                    Vector3 end = pos + dir * radius * 0.25f;
                    Handles.DrawLine(start, end, m_IsRestoringSculpt ? 2.5f : 1.5f);
                    
                    // Small curved arrows indicating "rewind"
                    Vector3 perpDir = new Vector3(-Mathf.Sin(angle), Mathf.Cos(angle), 0);
                    perpDir = cam.transform.TransformDirection(perpDir);
                    Handles.DrawLine(end, end + dir * radius * 0.08f + perpDir * radius * 0.06f, m_IsRestoringSculpt ? 2f : 1.5f);
                    Handles.DrawLine(end, end + dir * radius * 0.08f - perpDir * radius * 0.06f, m_IsRestoringSculpt ? 2f : 1.5f);
                }
            }
            
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string status;
            if (m_IsRestoringSculpt)
                status = "RESTORING TO ORIGINAL...";
            else if (isRestoreMode && !m_IsSmudging && !m_IsMoving && !m_IsFlattening && !m_IsRelaxing)
                status = "ALT = Restore to Original";
            else if (m_IsRelaxing && m_IsRoughening)
                status = "ROUGHENING...";
            else if (m_IsRelaxing)
                status = "RELAXING...";
            else if (m_IsFlattening)
                status = "FLATTENING...";
            else if (m_IsMoving && isConstrainedMove)
                status = "MOVING (CONSTRAINED)...";
            else if (m_IsMoving)
                status = "MOVING...";
            else if (m_IsSmudging && m_IsPinching)
                status = "PINCHING...";
            else if (m_IsSmudging)
                status = "SMUDGING...";
            else if (isTabRelax)
                status = isRoughenMode ? "ROUGHEN | Shift=Scatter splats" : "RELAX | Drag=Smooth | Shift=Roughen";
            else if (isTabFlatten)
                status = "FLATTEN | Drag in flatten direction";
            else if (isTabMove)
                status = shiftHeld ? "MOVE | SHIFT=Straight Line" : "MOVE | Drag=Move | Shift=Straight";
            else if (isTabPinch)
                status = "PINCH | Drag to pinch";
            else if (shiftHeld)
                status = "QUICK PINCH | Drag to pinch";
            else
                status = "SMUDGE | Drag=Smudge | Shift=Pinch";
            Handles.Label(pos + Vector3.up * (radius * 0.3f), status, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void HandleColorizeBrushScene(SceneView sceneView, Event e)
        {
            if (m_ColorizeBrush == null) { CreateToolGameObject(BrushTool.ColorizeBrush); return; }
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            // Capture mouse input to prevent default context menu
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            m_ColorizeBrush.TargetRenderer = m_TargetRenderer;
            
            Camera cam = sceneView.camera;
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            
            // Use pivot depth as reference, then find actual splat surface
            float pivotDist = Vector3.Distance(cam.transform.position, sceneView.pivot);
            Vector3 refPoint = ray.origin + ray.direction * pivotDist;
            
            // Find nearest splat to get actual surface position
            Vector3 nearestSplat = m_TargetRenderer.FindNearestSplatInScreenSpace(refPoint, cam, 300f);
            Vector3 hitPoint;
            if (nearestSplat != refPoint)
            {
                // Project ray to the splat's depth for cursor alignment
                float splatDepth = Vector3.Dot(nearestSplat - cam.transform.position, cam.transform.forward);
                Plane depthPlane = new Plane(-cam.transform.forward, cam.transform.position + cam.transform.forward * splatDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                    hitPoint = ray.GetPoint(hitDist);
                else
                    hitPoint = nearestSplat;
            }
            else
            {
                hitPoint = GetBrushHitPoint(ray, sceneView);
            }
            
            float worldRadius = CalculateWorldRadius(hitPoint, sceneView, m_ColorizeBrush.ScreenRadius) * 50f;
            
            GaussianSplatColorizeBrush.LastBrushPosition = hitPoint;
            GaussianSplatColorizeBrush.HasValidBrushPosition = true;
            GaussianSplatColorizeBrush.CurrentWorldRadius = worldRadius;
            GaussianSplatColorizeBrush.CurrentViewDirection = ray.direction;
            
            // Keyboard shortcuts for undo/redo
            if (e.type == EventType.KeyDown)
            {
                if (e.control && e.keyCode == KeyCode.Z && !e.shift)
                {
                    if (m_ColorizeBrush.Undo())
                    {
                        Repaint();
                        sceneView.Repaint();
                    }
                    e.Use();
                    return;
                }
                else if ((e.control && e.keyCode == KeyCode.Y) || (e.control && e.shift && e.keyCode == KeyCode.Z))
                {
                    if (m_ColorizeBrush.Redo())
                    {
                        Repaint();
                        sceneView.Repaint();
                    }
                    e.Use();
                    return;
                }
            }
            
            // Middle mouse to deactivate
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
                return;
            }
            
            // Scroll to resize
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_ColorizeBrush, "Resize Colorize Brush");
                m_ColorizeBrush.ScreenRadius = Mathf.Clamp(m_ColorizeBrush.ScreenRadius - e.delta.y * 0.1f, 0.1f, 10f);
                EditorUtility.SetDirty(m_ColorizeBrush);
                e.Use();
                Repaint();
            }
            
            // Left-click: Colorize with fluid stroke
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                // Push undo state before starting stroke
                m_ColorizeBrush.PushUndoState();
                
                // Start new stroke
                m_IsColorizeStrokeActive = true;
                m_LastColorizePosition = hitPoint;
                m_LastColorizeRadius = worldRadius;
                m_ColorizeBrush.ColorizeAtPosition(hitPoint, worldRadius);
                GaussianSplatColorizeBrush.IsColorizing = true;
                e.Use();
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && !e.alt && m_IsColorizeStrokeActive)
            {
                // Interpolate between last position and current for fluid stroke
                float distance = Vector3.Distance(m_LastColorizePosition, hitPoint);
                float stepSize = worldRadius * COLORIZE_STROKE_STEP;
                
                if (distance > stepSize * 0.5f)
                {
                    int steps = Mathf.Max(1, Mathf.CeilToInt(distance / stepSize));
                    for (int i = 1; i <= steps; i++)
                    {
                        float t = (float)i / steps;
                        Vector3 interpPos = Vector3.Lerp(m_LastColorizePosition, hitPoint, t);
                        float interpRadius = Mathf.Lerp(m_LastColorizeRadius, worldRadius, t);
                        m_ColorizeBrush.ColorizeAtPosition(interpPos, interpRadius);
                    }
                    m_LastColorizePosition = hitPoint;
                    m_LastColorizeRadius = worldRadius;
                }
                GaussianSplatColorizeBrush.IsColorizing = true;
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0)
            {
                m_IsColorizeStrokeActive = false;
                GaussianSplatColorizeBrush.IsColorizing = false;
            }
            
            // Force continuous repaint while colorizing for smooth strokes
            if (m_IsColorizeStrokeActive)
            {
                sceneView.Repaint();
            }
            
            // Right-click: Sample color
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
            {
                Color sampledColor = m_ColorizeBrush.SampleColorAtPosition(hitPoint, worldRadius, cam);
                // Check if valid sample (not exactly gray fallback)
                bool isValidSample = Mathf.Abs(sampledColor.r - 0.5f) > 0.01f || 
                                     Mathf.Abs(sampledColor.g - 0.5f) > 0.01f || 
                                     Mathf.Abs(sampledColor.b - 0.5f) > 0.01f;
                if (isValidSample)
                {
                    Undo.RecordObject(m_ColorizeBrush, "Sample Color");
                    m_ColorizeBrush.SetTargetColorFromSample(sampledColor);
                    EditorUtility.SetDirty(m_ColorizeBrush);
                    Repaint();
                }
                GaussianSplatColorizeBrush.IsSampling = true;
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 1)
            {
                GaussianSplatColorizeBrush.IsSampling = false;
            }
            
            DrawColorizeBrushPreview(hitPoint, worldRadius, sceneView);
            
            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }
        
        private Vector3 m_AnimPaintLastPos;
        private bool m_AnimPaintStrokeActive = false;
        
        private void HandleAnimationPaintScene(SceneView sceneView, Event e)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset) return;
            
            // Capture mouse input
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            Camera cam = sceneView.camera;
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            
            // Get hit point at pivot depth
            float pivotDist = Vector3.Distance(cam.transform.position, sceneView.pivot);
            Vector3 refPoint = ray.origin + ray.direction * pivotDist;
            
            // Find nearest splat surface
            Vector3 nearestSplat = m_TargetRenderer.FindNearestSplatInScreenSpace(refPoint, cam, 300f);
            Vector3 hitPoint;
            if (nearestSplat != refPoint)
            {
                float splatDepth = Vector3.Dot(nearestSplat - cam.transform.position, cam.transform.forward);
                Plane depthPlane = new Plane(-cam.transform.forward, cam.transform.position + cam.transform.forward * splatDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                    hitPoint = ray.GetPoint(hitDist);
                else
                    hitPoint = nearestSplat;
            }
            else
            {
                hitPoint = GetBrushHitPoint(ray, sceneView);
            }
            
            float worldRadius = CalculateWorldRadius(hitPoint, sceneView, m_AnimPaintRadius) * 50f;
            
            // Middle mouse to deactivate
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                DeactivateCurrentTool();
                e.Use();
                Repaint();
                return;
            }
            
            // Keyboard shortcuts for animation recorder
            if (e.type == EventType.KeyDown && m_AnimRecorder != null)
            {
                switch (e.keyCode)
                {
                    case KeyCode.Space: // Play/Pause toggle
                        if (m_AnimRecorder.IsPlaying)
                            m_AnimRecorder.TogglePause();
                        else if (m_AnimRecorder.HasClip)
                            m_AnimRecorder.StartPlayback();
                        e.Use();
                        Repaint();
                        break;
                    case KeyCode.R: // Toggle recording (when not modifying)
                        if (!e.control && !e.shift && !e.alt)
                        {
                            if (m_AnimRecorder.IsRecording)
                                m_AnimRecorder.StopRecording();
                            else if (!m_AnimPaintStrokeActive)
                                m_AnimRecorder.StartRecording();
                            e.Use();
                            Repaint();
                        }
                        break;
                    case KeyCode.LeftBracket: // Step backward
                        if (m_AnimRecorder.HasClip)
                        {
                            m_AnimRecorder.StepFrame(false);
                            e.Use();
                            Repaint();
                        }
                        break;
                    case KeyCode.RightBracket: // Step forward
                        if (m_AnimRecorder.HasClip)
                        {
                            m_AnimRecorder.StepFrame(true);
                            e.Use();
                            Repaint();
                        }
                        break;
                    case KeyCode.Home: // Go to start
                        if (m_AnimRecorder.HasClip)
                        {
                            m_AnimRecorder.SeekTo(0f);
                            e.Use();
                            Repaint();
                        }
                        break;
                    case KeyCode.End: // Go to end
                        if (m_AnimRecorder.HasClip)
                        {
                            m_AnimRecorder.SeekTo(m_AnimRecorder.ClipDuration);
                            e.Use();
                            Repaint();
                        }
                        break;
                }
            }
            
            // Scroll to resize
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                m_AnimPaintRadius = Mathf.Clamp(m_AnimPaintRadius - e.delta.y * 0.2f, 0.5f, 20f);
                e.Use();
                Repaint();
            }
            
            // Left-click: Start animation paint stroke
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                m_AnimPaintStrokeActive = true;
                m_AnimPaintActive = true;
                m_AnimPaintLastPos = hitPoint;
                m_AnimPaintStrokePoints.Clear();
                m_AnimPaintStrokeDirections.Clear();
                m_AnimPaintStrokePoints.Add(hitPoint);
                e.Use();
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && !e.alt && m_AnimPaintStrokeActive)
            {
                Vector3 strokeDir = (hitPoint - m_AnimPaintLastPos).normalized;
                if (strokeDir.sqrMagnitude > 0.001f)
                {
                    m_AnimPaintLastDirection = strokeDir;
                    m_AnimPaintStrokePoints.Add(hitPoint);
                    m_AnimPaintStrokeDirections.Add(strokeDir);
                    
                    // Apply velocity based on animation style
                    ApplyAnimationVelocity(hitPoint, worldRadius, strokeDir);
                    
                    m_AnimPaintLastPos = hitPoint;
                }
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0)
            {
                m_AnimPaintStrokeActive = false;
                m_AnimPaintActive = false;
            }
            
            // Draw preview
            if (m_AnimPaintShowOverlay)
                DrawAnimationPaintPreview(hitPoint, worldRadius, sceneView);
            
            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }
        
        private void ApplyAnimationVelocity(Vector3 position, float radius, Vector3 strokeDirection)
        {
            if (m_TargetRenderer == null) return;
            
            // Use manual direction if enabled, otherwise use stroke direction
            Vector3 flowDir = m_AnimPaintUseManualDirection ? m_AnimPaintManualDirection : strokeDirection;
            
            // Ensure direction is normalized and horizontal if gravity is disabled
            if (flowDir.sqrMagnitude > 0.001f)
                flowDir = flowDir.normalized;
            else
                flowDir = Vector3.forward;
            
            // If disabling gravity, flatten the direction to horizontal
            if (m_AnimPaintDisableGravity)
            {
                flowDir.y = 0;
                if (flowDir.sqrMagnitude > 0.001f)
                    flowDir = flowDir.normalized;
                else
                    flowDir = Vector3.forward;
            }
            
            Vector3 velocity = Vector3.zero;
            
            switch (m_AnimPaintStyle)
            {
                case AnimationPaintStyle.River:
                    // Direct flow in direction
                    velocity = flowDir * m_AnimPaintVelocity * m_AnimPaintSpeed;
                    break;
                    
                case AnimationPaintStyle.Whirlpool:
                    // Will be computed per-splat in shader based on position relative to center
                    velocity = flowDir * m_AnimPaintVelocity * m_AnimPaintSpeed;
                    break;
                    
                case AnimationPaintStyle.Wave:
                    // Perpendicular oscillation
                    Vector3 perpDir = Vector3.Cross(flowDir, Vector3.up).normalized;
                    if (perpDir.sqrMagnitude < 0.001f)
                        perpDir = Vector3.Cross(flowDir, Vector3.right).normalized;
                    velocity = perpDir * m_AnimPaintVelocity * m_AnimPaintSpeed;
                    break;
                    
                case AnimationPaintStyle.RandomLeaves:
                    // Random drift with flow bias
                    velocity = flowDir * m_AnimPaintVelocity * m_AnimPaintSpeed * 0.5f;
                    break;
            }
            
            m_TargetRenderer.ApplyVelocityInSphere(position, radius, velocity, (int)m_AnimPaintStyle, m_AnimPaintNoiseStrength, m_AnimPaintNoiseScale, m_AnimPaintDisableGravity);
        }
        
        private void DrawAnimationPaintPreview(Vector3 pos, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            
            // Brush color based on style
            Color styleColor = m_AnimPaintStyle switch
            {
                AnimationPaintStyle.River => new Color(0.2f, 0.6f, 1f, 0.9f),
                AnimationPaintStyle.Whirlpool => new Color(0.8f, 0.3f, 0.9f, 0.9f),
                AnimationPaintStyle.Wave => new Color(0.3f, 0.9f, 0.6f, 0.9f),
                AnimationPaintStyle.RandomLeaves => new Color(0.9f, 0.7f, 0.2f, 0.9f),
                _ => Color.cyan
            };
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Fill
            Color fillColor = styleColor;
            fillColor.a = m_AnimPaintStrokeActive ? 0.3f : 0.15f;
            Handles.color = fillColor;
            Handles.DrawSolidDisc(pos, -camForward, radius);
            
            // Outline
            Handles.color = styleColor;
            Handles.DrawWireDisc(pos, -camForward, radius, 2f);
            
            // Direction indicator - use manual direction if enabled, otherwise stroke direction
            Vector3 displayDir = m_AnimPaintUseManualDirection ? m_AnimPaintManualDirection : m_AnimPaintLastDirection;
            if (m_AnimPaintDisableGravity)
            {
                displayDir.y = 0;
                if (displayDir.sqrMagnitude > 0.001f)
                    displayDir = displayDir.normalized;
            }
            
            if (displayDir.sqrMagnitude > 0.001f)
            {
                Vector3 arrowStart = pos;
                Vector3 arrowEnd = pos + displayDir * radius * 0.8f;
                
                // Draw arrow line
                Handles.color = m_AnimPaintUseManualDirection ? Color.yellow : Color.white;
                Handles.DrawLine(arrowStart, arrowEnd, 3f);
                
                // Arrow head
                Vector3 arrowRight = Vector3.Cross(displayDir, -camForward).normalized;
                if (arrowRight.sqrMagnitude < 0.001f)
                    arrowRight = Vector3.Cross(displayDir, Vector3.up).normalized;
                Vector3 arrowHead1 = arrowEnd - displayDir * radius * 0.2f + arrowRight * radius * 0.1f;
                Vector3 arrowHead2 = arrowEnd - displayDir * radius * 0.2f - arrowRight * radius * 0.1f;
                Handles.DrawLine(arrowEnd, arrowHead1, 2f);
                Handles.DrawLine(arrowEnd, arrowHead2, 2f);
            }
            
            // Style indicator
            if (m_AnimPaintStyle == AnimationPaintStyle.Whirlpool)
            {
                // Draw spiral hint
                Handles.color = new Color(styleColor.r, styleColor.g, styleColor.b, 0.5f);
                for (int i = 0; i < 3; i++)
                {
                    float r = radius * (0.3f + i * 0.25f);
                    Handles.DrawWireDisc(pos, -camForward, r, 1f);
                }
            }
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string status = m_AnimPaintStrokeActive ? $"ANIMATING ({m_AnimPaintStyle})..." : $"{m_AnimPaintStyle} | LMB=Paint | Scroll=Resize";
            Handles.Label(pos + Vector3.up * (radius * 0.3f), status, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawAnimationRecorderOverlay(SceneView sceneView)
        {
            if (m_AnimRecorder == null)
                return;
            
            bool showOverlay = m_AnimRecorder.IsRecording || m_AnimRecorder.IsPlaying;
            if (!showOverlay)
                return;
            
            Handles.BeginGUI();
            
            // Position in top-left corner
            float boxWidth = 200;
            float boxHeight = m_AnimRecorder.IsPlaying ? 80 : 50;
            Rect boxRect = new Rect(10, 10, boxWidth, boxHeight);
            
            // Background
            Color bgColor = m_AnimRecorder.IsRecording 
                ? new Color(0.8f, 0.2f, 0.2f, 0.85f) 
                : new Color(0.2f, 0.6f, 0.2f, 0.85f);
            EditorGUI.DrawRect(boxRect, bgColor);
            
            GUILayout.BeginArea(boxRect);
            GUILayout.BeginVertical();
            
            GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel) 
            { 
                fontSize = 14, 
                normal = { textColor = Color.white },
                alignment = TextAnchor.MiddleCenter
            };
            
            GUIStyle infoStyle = new GUIStyle(EditorStyles.label) 
            { 
                fontSize = 11, 
                normal = { textColor = Color.white },
                alignment = TextAnchor.MiddleCenter
            };
            
            if (m_AnimRecorder.IsRecording)
            {
                GUILayout.Label("⏺ RECORDING", titleStyle);
                GUILayout.Label($"Keyframes: {m_AnimRecorder.KeyframeCount}", infoStyle);
            }
            else if (m_AnimRecorder.IsPlaying)
            {
                string playStatus = m_AnimRecorder.IsPaused ? "⏸ PAUSED" : "▶ PLAYING";
                GUILayout.Label(playStatus, titleStyle);
                GUILayout.Label($"{m_AnimRecorder.PlaybackTime:F2}s / {m_AnimRecorder.ClipDuration:F2}s", infoStyle);
                
                // Progress bar
                Rect progressRect = GUILayoutUtility.GetRect(boxWidth - 20, 12);
                progressRect.x += 10;
                progressRect.width -= 20;
                EditorGUI.DrawRect(progressRect, new Color(0, 0, 0, 0.5f));
                
                Rect fillRect = progressRect;
                fillRect.width *= m_AnimRecorder.PlaybackProgress;
                EditorGUI.DrawRect(fillRect, Color.white);
                
                GUILayout.Label($"Speed: {m_AnimRecorder.PlaybackSpeed:F1}x", infoStyle);
            }
            
            GUILayout.EndVertical();
            GUILayout.EndArea();
            
            Handles.EndGUI();
        }
        
        private void DrawColorizeBrushPreview(Vector3 pos, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Color targetColor = m_ColorizeBrush.TargetColor;
            
            Color mainColor = GaussianSplatColorizeBrush.IsSampling 
                ? new Color(1f, 1f, 0f, 0.9f)
                : new Color(targetColor.r, targetColor.g, targetColor.b, 0.9f);
            
            Color fillColor = GaussianSplatColorizeBrush.IsSampling 
                ? new Color(1f, 1f, 0f, 0.15f)
                : new Color(targetColor.r, targetColor.g, targetColor.b, 0.2f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(pos, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(pos, -camForward, radius, 2f);
            
            // Falloff ring
            if (m_ColorizeBrush.Falloff > 0)
            {
                float innerRadius = radius * (1f - m_ColorizeBrush.Falloff);
                Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.5f);
                Handles.DrawWireDisc(pos, -camForward, innerRadius, 1f);
            }
            
            // Center dot with target color
            Handles.color = targetColor;
            Handles.DrawSolidDisc(pos, -camForward, radius * 0.08f);
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string status = GaussianSplatColorizeBrush.IsSampling ? "SAMPLING..." : 
                           (GaussianSplatColorizeBrush.IsColorizing ? "COLORIZING..." : "LMB=Color | RMB=Sample | Scroll=Resize");
            Handles.Label(pos + Vector3.up * (radius * 0.3f), status, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void HandleCylinderBrushScene(SceneView sceneView, Event e)
        {
            if (m_CylinderBrush == null) return;
            
            m_CylinderBrush.TargetRenderer = m_TargetRenderer;
            
            // Handle tool switching keys (1=Move, 2=Rotate, 3=Scale)
            // Note: W/E/R are left free for WASD scene navigation
            if (e.type == EventType.KeyDown)
            {
                bool toolChanged = false;
                if (e.keyCode == KeyCode.Alpha1)
                {
                    m_GeoPrimitiveToolMode = 1; // Move
                    toolChanged = true;
                }
                else if (e.keyCode == KeyCode.Alpha2)
                {
                    m_GeoPrimitiveToolMode = 2; // Rotate
                    toolChanged = true;
                }
                else if (e.keyCode == KeyCode.Alpha3)
                {
                    m_GeoPrimitiveToolMode = 3; // Scale
                    toolChanged = true;
                }
                
                if (toolChanged)
                {
                    e.Use();
                    sceneView.Repaint();
                }
            }
            
            // Draw primitive and handles
            if (m_CylinderBrush.PrimitiveType == PrimitiveBrushType.Cylinder)
            {
                DrawCylinderBrushHandles(sceneView);
                DrawCylinderBrushPreview(sceneView);
            }
            else if (m_CylinderBrush.PrimitiveType == PrimitiveBrushType.Box)
            {
                DrawBoxPrimitiveHandles(sceneView);
                DrawBoxPrimitivePreview(sceneView);
            }
            else // Sphere mode
            {
                DrawSpherePrimitiveHandles(sceneView);
                DrawSpherePrimitivePreview(sceneView);
            }
            
            // Delete key
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
            {
                m_CylinderBrush.DeleteCurrentPrimitive();
                e.Use();
            }
            
            // Shift+R to restore
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.R && e.shift)
            {
                m_CylinderBrush.RestoreCurrentPrimitive();
                e.Use();
            }
        }
        
        private void DrawCylinderBrushHandles(SceneView sceneView)
        {
            if (m_CylinderBrush == null || m_CylinderBrush.PrimitiveType != PrimitiveBrushType.Cylinder) return;
            
            Vector3 pos = m_CylinderBrush.Position;
            Quaternion rot = m_CylinderBrush.Rotation;
            
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = pos;
            Quaternion newRot = rot;
            float newRadius = m_CylinderBrush.Radius;
            float newHeight = m_CylinderBrush.Height;

            // Use our own tool mode instead of Tools.current (1=Move, 2=Rotate, 3=Scale)
            switch (m_GeoPrimitiveToolMode)
            {
                case 1: // Move
                    newPos = Handles.PositionHandle(pos, rot);
                    break;

                case 2: // Rotate
                    newRot = Handles.RotationHandle(rot, pos);
                    break;

                case 3: // Scale
                    Vector3 scale = new Vector3(m_CylinderBrush.Radius * 2f, m_CylinderBrush.Height, m_CylinderBrush.Radius * 2f);
                    Vector3 newScale = Handles.ScaleHandle(scale, pos, rot, HandleUtility.GetHandleSize(pos));
                    newRadius = Mathf.Max(0.01f, (newScale.x + newScale.z) * 0.25f);
                    newHeight = Mathf.Max(0.01f, newScale.y);
                    break;

                default:
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
            }

            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_CylinderBrush, "Transform Cylinder");
                m_CylinderBrush.Position = newPos;
                m_CylinderBrush.Rotation = newRot;
                m_CylinderBrush.Radius = newRadius;
                m_CylinderBrush.Height = newHeight;
                EditorUtility.SetDirty(m_CylinderBrush);
            }
        }
        
        private void DrawCylinderBrushPreview(SceneView sceneView)
        {
            if (m_CylinderBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_CylinderBrush.Position;
            Vector3 up = m_CylinderBrush.AxisDirection;
            Color primColor = m_CylinderBrush.CylinderColor;
            float alpha = m_CylinderBrush.CylinderAlpha;
            
            if (m_CylinderBrush.PrimitiveType == PrimitiveBrushType.Cylinder)
            {
                float radius = m_CylinderBrush.Radius;
                float height = m_CylinderBrush.Height;
                int segments = m_CylinderBrush.CircleSegments;
                
                DrawSolid3DCylinder(pos, radius, height, up, primColor, alpha, segments);
                
                // Instructions
                GUIStyle labelStyle = new GUIStyle
                {
                    normal = { textColor = Color.white },
                    fontSize = 11,
                    fontStyle = FontStyle.Bold
                };
                
                string toolName = m_GeoPrimitiveToolMode == 1 ? "MOVE" :
                                  m_GeoPrimitiveToolMode == 2 ? "ROTATE" :
                                  m_GeoPrimitiveToolMode == 3 ? "SCALE" : "MOVE";
                Handles.Label(pos + up * (height * 0.5f + 0.15f), 
                    $"[{toolName}] Del=Delete | WASD=Navigate", labelStyle);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawBoxPrimitiveHandles(SceneView sceneView)
        {
            if (m_CylinderBrush == null) return;
            
            Vector3 pos = m_CylinderBrush.Position;
            Quaternion rot = m_CylinderBrush.Rotation;
            Vector3 scale = m_CylinderBrush.BoxSize;
            
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pos;
            Quaternion newRot = rot;
            Vector3 newScale = scale;
            
            // Use our own tool mode (1=Move, 2=Rotate, 3=Scale)
            switch (m_GeoPrimitiveToolMode)
            {
                case 1: // Move
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
                    
                case 2: // Rotate
                    newRot = Handles.RotationHandle(rot, pos);
                    break;
                    
                case 3: // Scale
                    newScale = Handles.ScaleHandle(scale, pos, rot, HandleUtility.GetHandleSize(pos));
                    break;
                    
                default:
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_CylinderBrush, "Transform Box");
                
                if (newPos != pos)
                {
                    m_CylinderBrush.Position = newPos;
                }
                
                if (newRot != rot)
                {
                    m_CylinderBrush.Rotation = newRot;
                }
                
                if (newScale != scale)
                {
                    // Clamp scale to prevent negative or zero values
                    newScale = new Vector3(
                        Mathf.Max(0.01f, newScale.x),
                        Mathf.Max(0.01f, newScale.y),
                        Mathf.Max(0.01f, newScale.z));
                    m_CylinderBrush.BoxSize = newScale;
                }
                
                EditorUtility.SetDirty(m_CylinderBrush);
            }
        }
        
        private void DrawBoxPrimitivePreview(SceneView sceneView)
        {
            if (m_CylinderBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_CylinderBrush.Position;
            Vector3 size = m_CylinderBrush.BoxSize;
            Quaternion rot = m_CylinderBrush.Rotation;
            Color boxColor = m_CylinderBrush.CylinderColor;
            float alpha = m_CylinderBrush.CylinderAlpha;
            
            // Draw rotated box
            Matrix4x4 oldMatrix = Handles.matrix;
            Handles.matrix = Matrix4x4.TRS(pos, rot, Vector3.one);
            DrawSolid3DBox(Vector3.zero, size, boxColor, alpha);
            Handles.color = boxColor;
            Handles.DrawWireCube(Vector3.zero, size);
            Handles.matrix = oldMatrix;
            
            // Instructions
            GUIStyle labelStyle = new GUIStyle
            {
                normal = { textColor = Color.white },
                fontSize = 11,
                fontStyle = FontStyle.Bold
            };
            
            string toolName = m_GeoPrimitiveToolMode == 1 ? "MOVE" : 
                              m_GeoPrimitiveToolMode == 2 ? "ROTATE" : 
                              m_GeoPrimitiveToolMode == 3 ? "SCALE" : "MOVE";
            Vector3 labelOffset = rot * Vector3.up * (size.y * 0.5f + 0.15f);
            Handles.Label(pos + labelOffset, 
                $"[{toolName}] BOX | 1/2/3=Tool | Del=Delete | Shift+R=Restore | WASD=Navigate", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawSpherePrimitiveHandles(SceneView sceneView)
        {
            if (m_CylinderBrush == null || m_CylinderBrush.PrimitiveType != PrimitiveBrushType.Sphere) return;
            
            Vector3 pos = m_CylinderBrush.Position;
            float radius = m_CylinderBrush.SphereRadius;
            
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = pos;
            float newRadius = radius;

            // Use our own tool mode (1=Move, 2=Rotate (no-op for sphere), 3=Scale)
            switch (m_GeoPrimitiveToolMode)
            {
                case 1: // Move
                    newPos = Handles.PositionHandle(pos, Quaternion.identity);
                    break;

                case 3: // Scale
                    Vector3 scale = Vector3.one * (radius * 2f);
                    Vector3 newScale = Handles.ScaleHandle(scale, pos, Quaternion.identity, HandleUtility.GetHandleSize(pos));
                    newRadius = Mathf.Max(0.01f, (newScale.x + newScale.y + newScale.z) / 6f);
                    break;
                    
                default: // Move by default (sphere has no rotation)
                    newPos = Handles.PositionHandle(pos, Quaternion.identity);
                    break;
            }

            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_CylinderBrush, "Transform Sphere");
                m_CylinderBrush.Position = newPos;
                m_CylinderBrush.SphereRadius = newRadius;
                EditorUtility.SetDirty(m_CylinderBrush);
            }
        }
        
        private void DrawSpherePrimitivePreview(SceneView sceneView)
        {
            if (m_CylinderBrush == null || m_CylinderBrush.PrimitiveType != PrimitiveBrushType.Sphere) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_CylinderBrush.Position;
            float radius = m_CylinderBrush.SphereRadius;
            Color sphereColor = m_CylinderBrush.CylinderColor;
            float alpha = m_CylinderBrush.CylinderAlpha;
            int segments = m_CylinderBrush.CircleSegments;
            
            DrawSolid3DSphere(pos, radius, sphereColor, alpha, segments);
            
            // Instructions
            GUIStyle labelStyle = new GUIStyle
            {
                normal = { textColor = Color.white },
                fontSize = 11,
                fontStyle = FontStyle.Bold
            };
            
            string toolName = m_GeoPrimitiveToolMode == 1 ? "MOVE" :
                              m_GeoPrimitiveToolMode == 3 ? "SCALE" : "MOVE";
            Handles.Label(pos + Vector3.up * (radius + 0.15f), 
                $"[{toolName}] SPHERE | Del=Delete | Shift+R=Restore | WASD=Navigate", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawSolid3DSphere(Vector3 center, float radius, Color color, float alpha, int segments)
        {
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            // Draw three great circles (XY, XZ, YZ planes)
            Handles.color = outlineColor;
            Handles.DrawWireDisc(center, Vector3.right, radius);
            Handles.DrawWireDisc(center, Vector3.up, radius);
            Handles.DrawWireDisc(center, Vector3.forward, radius);
            
            // Draw additional latitude circles
            for (int lat = 1; lat < 4; lat++)
            {
                float latAngle = (lat / 4f) * Mathf.PI * 0.5f;
                float circleRadius = radius * Mathf.Cos(latAngle);
                float offset = radius * Mathf.Sin(latAngle);
                
                Handles.DrawWireDisc(center + Vector3.up * offset, Vector3.up, circleRadius);
                Handles.DrawWireDisc(center - Vector3.up * offset, Vector3.up, circleRadius);
            }
            
            // Draw solid sphere using disc slices
            Handles.color = fillColor;
            int slices = segments;
            for (int i = 0; i < slices; i++)
            {
                float angle = ((float)i / slices) * Mathf.PI;
                float sliceRadius = radius * Mathf.Sin(angle);
                float sliceY = radius * Mathf.Cos(angle);
                
                if (sliceRadius > 0.01f)
                {
                    Handles.DrawSolidDisc(center + Vector3.up * sliceY, Vector3.up, sliceRadius);
                }
            }
        }
        
        private void DrawSolid3DCylinder(Vector3 center, float radius, float height, Vector3 up, 
            Color color, float alpha, int segments)
        {
            Vector3 right = GetCylinderPerpendicular(up);
            Vector3 forward = Vector3.Cross(up, right);
            
            float halfHeight = height * 0.5f;
            Vector3 topCenter = center + up * halfHeight;
            Vector3 bottomCenter = center - up * halfHeight;
            
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            // Generate circle points
            Vector3[] topPoints = new Vector3[segments];
            Vector3[] bottomPoints = new Vector3[segments];
            
            for (int i = 0; i < segments; i++)
            {
                float angle = (i / (float)segments) * Mathf.PI * 2f;
                Vector3 offset = (right * Mathf.Cos(angle) + forward * Mathf.Sin(angle)) * radius;
                topPoints[i] = topCenter + offset;
                bottomPoints[i] = bottomCenter + offset;
            }
            
            // Draw top cap
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawSolidRectangleWithOutline(new Vector3[] { topCenter, topPoints[i], topPoints[next], topCenter }, 
                    fillColor, Color.clear);
            }
            
            // Draw bottom cap
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawSolidRectangleWithOutline(new Vector3[] { bottomCenter, bottomPoints[next], bottomPoints[i], bottomCenter }, 
                    fillColor, Color.clear);
            }
            
            // Draw side quads
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Vector3[] quad = new Vector3[] { bottomPoints[i], topPoints[i], topPoints[next], bottomPoints[next] };
                Handles.DrawSolidRectangleWithOutline(quad, fillColor, Color.clear);
            }
            
            // Draw wireframe
            Handles.color = outlineColor;
            
            // Top and bottom circles
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                Handles.DrawLine(topPoints[i], topPoints[next], 1.5f);
                Handles.DrawLine(bottomPoints[i], bottomPoints[next], 1.5f);
            }
            
            // Vertical lines (every 4th segment for cleaner look)
            for (int i = 0; i < segments; i += Mathf.Max(1, segments / 4))
            {
                Handles.DrawLine(topPoints[i], bottomPoints[i], 1.5f);
            }
        }
        
        private Vector3 GetCylinderPerpendicular(Vector3 v)
        {
            if (Mathf.Abs(v.x) < 0.9f)
                return Vector3.Cross(v, Vector3.right).normalized;
            return Vector3.Cross(v, Vector3.up).normalized;
        }
        
        // Vertex dragging state
        private int m_DraggingVertexIndex = -1;
        private Plane m_VertexDragPlane;
        
        private void DrawFillBrushTransformHandles(SceneView sceneView)
        {
            if (m_FillBrush == null || !m_FillBrush.IsClosed) return;
            
            Vector3 center = m_FillBrush.TransformedCenter;
            Quaternion rotation = m_FillBrush.TransformRotation;
            
            // Position handle at center (only show if not dragging vertex)
            if (m_DraggingVertexIndex < 0)
            {
                EditorGUI.BeginChangeCheck();
                Vector3 newCenter = Handles.PositionHandle(center, rotation);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_FillBrush, "Move Polygon");
                    m_FillBrush.TransformOffset = newCenter - m_FillBrush.PolygonCenter;
                    EditorUtility.SetDirty(m_FillBrush);
                }
            }
        }
        
        private void HandleFillBrushVertexDragging(SceneView sceneView, Event e)
        {
            if (m_FillBrush == null || !m_FillBrush.IsClosed) return;
            
            // Only process on relevant events to reduce overhead
            bool isRelevantEvent = e.type == EventType.Repaint || 
                                   e.type == EventType.MouseDown || 
                                   e.type == EventType.MouseDrag || 
                                   e.type == EventType.MouseUp ||
                                   e.type == EventType.MouseMove;
            
            if (!isRelevantEvent) return;
            
            int vertCount = m_FillBrush.VertexCount;
            Camera cam = sceneView.camera;
            float pickRadius = 15f;
            
            // Only draw vertices on repaint
            if (e.type == EventType.Repaint)
            {
                for (int i = 0; i < vertCount; i++)
                {
                    Vector3 vertPos = m_FillBrush.GetTransformedVertex(i);
                    float handleSize = HandleUtility.GetHandleSize(vertPos) * 0.07f;
                    
                    if (m_DraggingVertexIndex == i)
                        Handles.color = Color.white;
                    else
                        Handles.color = (i == 0) ? Color.cyan : new Color(1f, 0.6f, 0.2f, 1f);
                    
                    Handles.SphereHandleCap(0, vertPos, Quaternion.identity, handleSize, EventType.Repaint);
                }
                return;
            }
            
            // Handle mouse down - start drag
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && m_DraggingVertexIndex < 0)
            {
                float closestDist = pickRadius;
                int closestIdx = -1;
                
                for (int i = 0; i < vertCount; i++)
                {
                    Vector3 vertPos = m_FillBrush.GetTransformedVertex(i);
                    Vector2 screenPos = HandleUtility.WorldToGUIPoint(vertPos);
                    float dist = Vector2.Distance(screenPos, e.mousePosition);
                    
                    if (dist < closestDist)
                    {
                        closestDist = dist;
                        closestIdx = i;
                    }
                }
                
                if (closestIdx >= 0)
                {
                    m_DraggingVertexIndex = closestIdx;
                    Vector3 vertPos = m_FillBrush.GetTransformedVertex(closestIdx);
                    m_VertexDragPlane = new Plane(-cam.transform.forward, vertPos);
                    Undo.RecordObject(m_FillBrush, "Move Vertex");
                    e.Use();
                }
            }
            // Handle mouse drag - move vertex (no expensive snapping during drag)
            else if (e.type == EventType.MouseDrag && m_DraggingVertexIndex >= 0)
            {
                Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
                if (m_VertexDragPlane.Raycast(ray, out float enter))
                {
                    Vector3 newPos = ray.GetPoint(enter);
                    m_FillBrush.MoveTransformedVertex(m_DraggingVertexIndex, newPos);
                }
                e.Use();
            }
            // Handle mouse up - finish drag (no snapping, place exactly where released)
            else if (e.type == EventType.MouseUp && e.button == 0 && m_DraggingVertexIndex >= 0)
            {
                EditorUtility.SetDirty(m_FillBrush);
                m_DraggingVertexIndex = -1;
                e.Use();
            }
        }

        private Vector3 GetFillHitPoint(Ray ray, SceneView sceneView)
        {
            if (Physics.Raycast(ray, out RaycastHit hit, 1000f))
                return hit.point;
            
            Camera cam = sceneView.camera;
            Vector3 cameraPos = cam.transform.position;
            Vector3 cameraForward = cam.transform.forward;
            
            // PRIORITY 1: If we already have vertices, stay on their plane (keeps polygon flat)
            if (m_FillBrush != null && m_FillBrush.Vertices.Count > 0)
            {
                Vector3 planePoint = m_FillBrush.Vertices[0];
                Plane drawPlane = new Plane(-cameraForward, planePoint);
                if (drawPlane.Raycast(ray, out float enter))
                    return ray.GetPoint(enter);
            }
            
            // PRIORITY 2: For first vertex, find splat surface depth
            if (m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup)
            {
                // Use pivot distance as reference for better depth estimation
                float pivotDist = Vector3.Distance(cameraPos, sceneView.pivot);
                Vector3 refPoint = ray.origin + ray.direction * pivotDist;
                
                Vector3 nearestSplat = m_TargetRenderer.FindNearestSplatInScreenSpace(refPoint, cam, 300f);
                if (nearestSplat != refPoint)
                {
                    // Get the depth of the nearest splat
                    float splatDepth = Vector3.Dot(nearestSplat - cameraPos, cameraForward);
                    
                    // Project the ray to that depth
                    Plane depthPlane = new Plane(-cameraForward, cameraPos + cameraForward * splatDepth);
                    if (depthPlane.Raycast(ray, out float enter) && enter > 0)
                        return ray.GetPoint(enter);
                }
            }
            
            // FALLBACK: Camera pivot plane
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane2 = new Plane(-cameraForward, pivotPoint);
            if (depthPlane2.Raycast(ray, out float dist) && dist > 0)
                return ray.GetPoint(dist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        /// <summary>
        /// Sample the surface depth at a screen position by finding nearby splats
        /// </summary>
        private float? SampleSplatSurfaceDepth(Vector2 screenPos, Camera cam, float searchRadius)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return null;
            
            var renderer = m_TargetRenderer;
            int splatCount = renderer.splatCount;
            if (splatCount <= 0) return null;
            
            // Get position data
            var posBuffer = renderer.GpuPosData;
            if (posBuffer == null) return null;
            
            float[] posData = new float[Mathf.Min(splatCount, 50000) * 3];
            int samplesToCheck = Mathf.Min(splatCount, 50000);
            posBuffer.GetData(posData, 0, 0, samplesToCheck * 3);
            
            List<float> nearbyDepths = new List<float>();
            float searchRadiusSq = searchRadius * searchRadius;
            
            Transform t = renderer.transform;
            for (int i = 0; i < samplesToCheck; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = t.TransformPoint(localPos);
                Vector3 sp = cam.WorldToScreenPoint(worldPos);
                
                if (sp.z <= 0) continue;
                
                float dx = sp.x - screenPos.x;
                float dy = sp.y - screenPos.y;
                float distSq = dx * dx + dy * dy;
                
                if (distSq < searchRadiusSq)
                {
                    nearbyDepths.Add(sp.z);
                    if (nearbyDepths.Count >= 100) break;
                }
            }
            
            if (nearbyDepths.Count == 0) return null;
            
            // Return median depth for robustness
            nearbyDepths.Sort();
            return nearbyDepths[nearbyDepths.Count / 2];
        }

        private void DrawFillBrushPreview(Vector3 cursorPos, SceneView sceneView)
        {
            if (m_FillBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw cursor (only when drawing)
            if (!m_FillBrush.IsClosed)
            {
                Handles.color = Color.yellow;
                Handles.SphereHandleCap(0, cursorPos, Quaternion.identity, 0.04f, EventType.Repaint);
            }
            
            // Get appropriate vertices (transformed when closed)
            var verts = m_FillBrush.IsClosed ? m_FillBrush.GetTransformedVertices() : m_FillBrush.Vertices;
            Vector3 displayCenter = m_FillBrush.IsClosed ? m_FillBrush.TransformedCenter : m_FillBrush.PolygonCenter;
            
            // Draw polygon edges
            if (verts.Count > 0)
            {
                Handles.color = m_FillBrush.IsClosed ? new Color(0.3f, 0.9f, 0.5f, 0.9f) : new Color(0.9f, 0.7f, 0.2f, 0.9f);
                
                // Draw vertices
                foreach (var v in verts)
                    Handles.SphereHandleCap(0, v, Quaternion.identity, 0.03f, EventType.Repaint);
                
                // Draw edges
                for (int i = 0; i < verts.Count - 1; i++)
                    Handles.DrawLine(verts[i], verts[i + 1], 2f);
                
                // Close polygon if closed
                if (m_FillBrush.IsClosed && verts.Count >= 3)
                {
                    Handles.color = new Color(0.3f, 0.9f, 0.5f, 0.9f);
                    Handles.DrawLine(verts[verts.Count - 1], verts[0], 2f);
                    
                    // Draw filled area preview (semi-transparent)
                    Handles.color = new Color(0.3f, 0.9f, 0.5f, 0.15f);
                    Vector3[] vertArray = verts.ToArray();
                    Handles.DrawAAConvexPolygon(vertArray);
                }
                
                // Preview line to mouse (only when drawing)
                if (m_FillBrush.IsDrawing)
                {
                    var rawVerts = m_FillBrush.Vertices;
                    Handles.color = new Color(0.9f, 0.7f, 0.2f, 0.5f);
                    Handles.DrawDottedLine(rawVerts[rawVerts.Count - 1], cursorPos, 4f);
                    if (rawVerts.Count >= 2)
                        Handles.DrawDottedLine(cursorPos, rawVerts[0], 4f);
                }
            }
            
            // Draw center marker if polygon is valid
            if (verts.Count >= 3)
            {
                Handles.color = Color.yellow;
                Handles.DrawWireCube(displayCenter, Vector3.one * 0.06f);
                
                // Show transform info when closed
                if (m_FillBrush.IsClosed)
                {
                    // Draw rotation indicator
                    Vector3 normal = m_FillBrush.GetTransformedNormal();
                    Handles.color = Color.blue;
                    Handles.DrawLine(displayCenter, displayCenter + normal * 0.2f, 2f);
                }
            }
            
            // Instructions overlay
            Handles.BeginGUI();
            GUILayout.BeginArea(new Rect(10, 10, 420, 120));
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            GUILayout.Label("🖌️ FILL BRUSH", EditorStyles.boldLabel);
            
            GUIStyle statusStyle = new GUIStyle(EditorStyles.miniLabel) { fontStyle = FontStyle.Bold };
            int vertCount = m_FillBrush.Vertices.Count;
            
            if (m_FillBrush.IsClosed)
            {
                if (m_DraggingVertexIndex >= 0)
                {
                    statusStyle.normal.textColor = Color.white;
                    GUILayout.Label($"Dragging vertex {m_DraggingVertexIndex}...", statusStyle);
                }
                else
                {
                    statusStyle.normal.textColor = Color.green;
                    GUILayout.Label($"✓ CLOSED | Scale: {m_FillBrush.UniformScale:F2}x", statusStyle);
                }
                GUILayout.Label("Drag verts | F = Fill | Scroll = Scale", EditorStyles.miniLabel);
            }
            else if (m_FillBrush.IsDrawing)
            {
                GUILayout.Label("Click to add vertices, Enter to close polygon", EditorStyles.miniLabel);
                statusStyle.normal.textColor = Color.yellow;
                GUILayout.Label($"Vertices: {vertCount} | Drawing... (need {Mathf.Max(0, 3 - vertCount)} more)", statusStyle);
            }
            else
            {
                statusStyle.normal.textColor = Color.cyan;
                GUILayout.Label("Click to add vertex", statusStyle);
            }
            EditorGUILayout.EndVertical();
            GUILayout.EndArea();
            Handles.EndGUI();
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawVortexToolHandles(SceneView sceneView)
        {
            if (m_VortexAttractor == null) return;
            
            Vector3 pos = m_VortexAttractor.transform.position;
            
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_VortexAttractor.transform, "Move Vortex");
                m_VortexAttractor.transform.position = newPos;
            }
        }

        private void DrawVortexToolPreview(SceneView sceneView)
        {
            if (m_VortexAttractor == null) return;
            
            var so = new SerializedObject(m_VortexAttractor);
            bool isEnabled = so.FindProperty("m_AttractorEnabled").boolValue;
            float range = so.FindProperty("m_Range").floatValue;
            int mode = so.FindProperty("m_Mode").enumValueIndex;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_VortexAttractor.transform.position;
            float time = (float)EditorApplication.timeSinceStartup * 0.5f;
            
            // Draw range circle
            Handles.color = isEnabled ? new Color(0f, 0.8f, 1f, 0.5f) : new Color(0.5f, 0.5f, 0.5f, 0.3f);
            Handles.DrawWireDisc(pos, Vector3.up, range);
            Handles.DrawWireDisc(pos, Vector3.up, range * 0.5f);
            
            // Mode-specific visualization
            string[] modeNames = { "Vortex", "Attract", "Repel" };
            string modeName = modeNames[Mathf.Clamp(mode, 0, 2)];
            
            if (mode == 0) // Vortex - draw spiral
            {
                Handles.color = isEnabled ? COL_CYAN : Color.gray;
                for (int arm = 0; arm < 3; arm++)
                {
                    float armOffset = arm * Mathf.PI * 2f / 3f + time;
                    Vector3 prev = pos;
                    for (int i = 1; i <= 20; i++)
                    {
                        float t = i / 20f;
                        float angle = armOffset + t * Mathf.PI * 3f;
                        float radius = t * range * 0.8f;
                        Vector3 point = pos + new Vector3(Mathf.Cos(angle), 0, Mathf.Sin(angle)) * radius;
                        Handles.DrawLine(prev, point);
                        prev = point;
                    }
                }
            }
            else // Attract/Repel - draw arrows
            {
                Handles.color = mode == 1 ? Color.green : Color.red;
                for (int i = 0; i < 8; i++)
                {
                    float angle = i * Mathf.PI / 4f;
                    Vector3 dir = new Vector3(Mathf.Cos(angle), 0, Mathf.Sin(angle));
                    if (mode == 1) // Attract - arrows point inward
                        Handles.DrawLine(pos + dir * range * 0.8f, pos + dir * range * 0.4f);
                    else // Repel - arrows point outward
                        Handles.DrawLine(pos + dir * range * 0.4f, pos + dir * range * 0.8f);
                }
            }
            
            // Center indicator
            Handles.color = isEnabled ? Color.yellow : Color.gray;
            Handles.DrawWireCube(pos, Vector3.one * 0.2f);
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string info = isEnabled ? $"🌀 {modeName.ToUpper()} | Range: {range:F1}" : $"{modeName} - SPACE to toggle";
            Handles.Label(pos + Vector3.up * 0.5f, info, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void HandlePolyMaskScene(SceneView sceneView, Event e)
        {
            if (m_PolyMask == null) return;
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetMaskHitPoint(ray, sceneView);
            m_LastMaskMousePos = hitPoint;
            
            DrawPolyMaskPreview(hitPoint, sceneView);
            
            // Left click to add vertex
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
            {
                double currentTime = EditorApplication.timeSinceStartup;
                bool isDoubleClick = (currentTime - m_LastMaskClickTime) < 0.3;
                m_LastMaskClickTime = currentTime;
                
                if (!m_PolyMask.m_IsDrawing)
                {
                    Undo.RecordObject(m_PolyMask, "Start Drawing Polygon");
                    m_PolyMask.StartDrawing(hitPoint, Vector3.up);
                    EditorUtility.SetDirty(m_PolyMask);
                }
                else if (isDoubleClick && m_PolyMask.m_Vertices.Count >= 3)
                {
                    Undo.RecordObject(m_PolyMask, "Close Polygon");
                    m_PolyMask.ClosePath();
                    EditorUtility.SetDirty(m_PolyMask);
                    ApplyMaskCutout();
                }
                else
                {
                    Undo.RecordObject(m_PolyMask, "Add Vertex");
                    m_PolyMask.AddVertex3D(hitPoint);
                    EditorUtility.SetDirty(m_PolyMask);
                }
                
                e.Use();
                Repaint();
            }
            
            // Right click to clear
            if (e.type == EventType.MouseDown && e.button == 1)
            {
                Undo.RecordObject(m_PolyMask, "Clear Polygon");
                m_PolyMask.Clear();
                EditorUtility.SetDirty(m_PolyMask);
                e.Use();
                Repaint();
            }
            
            // Keyboard
            if (e.type == EventType.KeyDown)
            {
                if ((e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter) && 
                    m_PolyMask.m_IsDrawing && m_PolyMask.m_Vertices.Count >= 3)
                {
                    Undo.RecordObject(m_PolyMask, "Close Polygon");
                    m_PolyMask.ClosePath();
                    EditorUtility.SetDirty(m_PolyMask);
                    ApplyMaskCutout();
                    e.Use();
                    Repaint();
                }
            }
        }

        private Vector3 GetMaskHitPoint(Ray ray, SceneView sceneView)
        {
            if (Physics.Raycast(ray, out RaycastHit hit, 1000f))
                return hit.point;
            
            Vector3 planeNormal = -sceneView.camera.transform.forward;
            Vector3 planePoint;
            
            if (m_PolyMask.m_Vertices.Count > 0)
            {
                planePoint = m_PolyMask.transform.TransformPoint(m_PolyMask.m_Vertices[0]);
            }
            else
            {
                planePoint = m_PolyMask.transform.position;
                Vector3 toObject = planePoint - sceneView.camera.transform.position;
                if (Vector3.Dot(toObject, sceneView.camera.transform.forward) < 0.5f)
                {
                    planePoint = sceneView.camera.transform.position + sceneView.camera.transform.forward * 5f;
                }
            }
            
            Plane drawPlane = new Plane(planeNormal, planePoint);
            if (drawPlane.Raycast(ray, out float enter))
                return ray.GetPoint(enter);
            
            return ray.origin + ray.direction * 5f;
        }

        private void DrawPolyMaskPreview(Vector3 cursorPos, SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw cursor
            Handles.color = Color.yellow;
            Handles.DrawWireCube(cursorPos, Vector3.one * 0.1f);
            Handles.DrawLine(cursorPos, cursorPos + Vector3.up * 0.2f);
            
            var displayVerts = m_PolyMask.GetDisplayVertices();
            
            // Draw polygon edges
            if (displayVerts.Count > 1)
            {
                Handles.color = m_PolyMask.IsClosed ? Color.green : Color.cyan;
                for (int i = 0; i < displayVerts.Count - 1; i++)
                {
                    Vector3 p1 = m_PolyMask.transform.TransformPoint(displayVerts[i]);
                    Vector3 p2 = m_PolyMask.transform.TransformPoint(displayVerts[i + 1]);
                    Handles.DrawLine(p1, p2, 3f);
                }
                
                if (m_PolyMask.IsClosed && displayVerts.Count > 2)
                {
                    Handles.color = Color.green;
                    Vector3 first = m_PolyMask.transform.TransformPoint(displayVerts[0]);
                    Vector3 last = m_PolyMask.transform.TransformPoint(displayVerts[displayVerts.Count - 1]);
                    Handles.DrawLine(last, first, 3f);
                }
            }
            
            // Preview line to mouse
            if (m_PolyMask.m_IsDrawing && displayVerts.Count > 0)
            {
                Handles.color = Color.yellow;
                Vector3 lastVertex = m_PolyMask.transform.TransformPoint(displayVerts[displayVerts.Count - 1]);
                Handles.DrawDottedLine(lastVertex, cursorPos, 2f);
            }
            
            // Draw vertices
            if (displayVerts.Count > 0)
            {
                Handles.color = Color.cyan;
                foreach (var v in displayVerts)
                {
                    Vector3 worldPos = m_PolyMask.transform.TransformPoint(v);
                    Handles.SphereHandleCap(0, worldPos, Quaternion.identity, 0.05f, EventType.Repaint);
                }
            }
            
            // Instructions overlay
            Handles.BeginGUI();
            GUILayout.BeginArea(new Rect(10, 10, 400, 100));
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            GUILayout.Label("🎯 POLYGON MASK MODE", EditorStyles.boldLabel);
            GUILayout.Label("Left-click: Add vertex | Double-click/Enter: Close | Right-click: Clear", EditorStyles.miniLabel);
            
            GUIStyle statusStyle = new GUIStyle(EditorStyles.miniLabel) { fontStyle = FontStyle.Bold };
            int vertCount = m_PolyMask.m_Vertices.Count;
            if (m_PolyMask.IsClosed)
            {
                statusStyle.normal.textColor = Color.green;
                GUILayout.Label($"Vertices: {vertCount} | ✓ CLOSED", statusStyle);
            }
            else if (m_PolyMask.m_IsDrawing)
            {
                statusStyle.normal.textColor = Color.yellow;
                GUILayout.Label($"Vertices: {vertCount} | Drawing... (need {Mathf.Max(0, 3 - vertCount)} more)", statusStyle);
            }
            else
            {
                statusStyle.normal.textColor = Color.cyan;
                GUILayout.Label("Click in scene to start drawing", statusStyle);
            }
            EditorGUILayout.EndVertical();
            GUILayout.EndArea();
            Handles.EndGUI();
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        // Drawing helpers
        private Vector3 GetBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }

        private Vector3 GetCloneHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            
            // When placing target (not drawing source), use source center's depth plane
            if (m_CloneBrush != null && !m_CloneBrush.IsDrawingSource && m_CloneBrush.SourceVertices.Count >= 3)
            {
                Vector3 sourceCenter = m_CloneBrush.SourceCenter;
                Plane sourcePlane = new Plane(-cameraForward, sourceCenter);
                if (sourcePlane.Raycast(ray, out float planeDist) && planeDist > 0)
                    return ray.GetPoint(planeDist);
            }
            
            // When drawing source, use camera pivot plane for consistent depth
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float dist) && dist > 0)
                return ray.GetPoint(dist);
            
            return ray.origin + ray.direction * pivotDistance;
        }

        private float CalculateWorldRadius(Vector3 worldPos, SceneView sceneView, float screenRadius)
        {
            Camera cam = sceneView.camera;
            float distance = Vector3.Distance(cam.transform.position, worldPos);
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * distance * Mathf.Tan(fov * 0.5f)) / cam.pixelHeight;
            return screenRadius * worldPerPixel;
        }

        private void DrawEraseBrushPreview(Vector3 pos, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            
            Color mainColor = GaussianSplatBrush.IsRestoring 
                ? new Color(0.3f, 0.5f, 1f, 0.9f)
                : new Color(1f, 0.3f, 0.3f, 0.9f);
            Color fillColor = GaussianSplatBrush.IsRestoring 
                ? new Color(0.3f, 0.5f, 1f, 0.15f)
                : new Color(1f, 0.3f, 0.3f, 0.15f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(pos, -camForward, radius*3);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(pos, -camForward, radius, 2f);
            
            if (m_EraseBrush != null && m_EraseBrush.BrushFalloff > 0)
            {
                float innerRadius = radius * Mathf.Clamp01(m_EraseBrush.BrushFalloff);
                Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.5f);
                Handles.DrawWireDisc(pos, -camForward, innerRadius, 1f);
            }
            
            Handles.color = mainColor;
            Handles.DrawSolidDisc(pos, -camForward, radius * 0.03f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawLinePreview(Vector3 startPos, Vector3 endPos, float startRadius, float endRadius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Color lineColor = new Color(1f, 0.6f, 0.2f, 0.9f);
            Color fillColor = new Color(1f, 0.6f, 0.2f, 0.2f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw start disc
            Handles.color = fillColor;
            Handles.DrawSolidDisc(startPos, -camForward, startRadius);
            Handles.color = lineColor;
            Handles.DrawWireDisc(startPos, -camForward, startRadius, 2f);
            
            // Draw connecting line
            Handles.color = lineColor;
            Handles.DrawLine(startPos, endPos, 3f);
            
            // Draw perpendicular edges for line width visualization
            Vector3 lineDir = (endPos - startPos).normalized;
            if (lineDir.sqrMagnitude > 0.001f)
            {
                Vector3 perpDir = Vector3.Cross(lineDir, camForward).normalized;
                
                Handles.color = new Color(lineColor.r, lineColor.g, lineColor.b, 0.5f);
                Handles.DrawLine(startPos + perpDir * startRadius, endPos + perpDir * endRadius, 1.5f);
                Handles.DrawLine(startPos - perpDir * startRadius, endPos - perpDir * endRadius, 1.5f);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawBoxBrushHandles(SceneView sceneView)
        {
            if (m_BoxBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_BoxBrush.BoxPosition;
            Vector3 size = m_BoxBrush.BoxSize;
            Quaternion rot = m_BoxBrush.BoxRotationQuat;
            
            // Use Unity's Transform handles based on current tool
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pos;
            Quaternion newRot = rot;
            Vector3 newScale = size;
            
            // Show handles based on Unity's current tool
            switch (Tools.current)
            {
                case Tool.Move:
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
                    
                case Tool.Rotate:
                    newRot = Handles.RotationHandle(rot, pos);
                    break;
                    
                case Tool.Scale:
                    newScale = Handles.ScaleHandle(size, pos, rot, HandleUtility.GetHandleSize(pos));
                    break;
                    
                default:
                    // Fallback to Move to avoid overlapping gizmos
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_BoxBrush, "Transform Box");
                
                if (newPos != pos)
                    m_BoxBrush.BoxPosition = newPos;
                
                if (newRot != rot)
                    m_BoxBrush.BoxRotationQuat = newRot;
                
                if (newScale != size)
                {
                    newScale = new Vector3(
                        Mathf.Max(0.01f, newScale.x),
                        Mathf.Max(0.01f, newScale.y),
                        Mathf.Max(0.01f, newScale.z));
                    m_BoxBrush.BoxSize = newScale;
                }
                
                EditorUtility.SetDirty(m_BoxBrush);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawBoxBrushPreview(SceneView sceneView)
        {
            if (m_BoxBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_BoxBrush.BoxPosition;
            Vector3 size = m_BoxBrush.BoxSize;
            Quaternion rot = m_BoxBrush.BoxRotationQuat;
            
            Color boxColor = m_BoxBrush.HasCopiedData ? new Color(0f, 0.8f, 1f, 1f) : m_BoxBrush.BoxColor;
            float alpha = m_BoxBrush.BoxAlpha;
            
            // Draw solid 3D box with rotation
            DrawSolid3DBoxRotated(pos, size, rot, boxColor, alpha);
            
            // Wireframe
            Handles.color = boxColor;
            DrawWireCubeRotated(pos, size, rot);
            
            if (m_BoxBrush.HasCopiedData)
            {
                Color sourceColor = new Color(1f, 0.5f, 0f, 1f);
                DrawSolid3DBox(m_BoxBrush.CopiedSourcePosition, m_BoxBrush.CopiedBoxSize, sourceColor, alpha * 0.7f);
                
                Handles.color = sourceColor;
                Handles.DrawWireCube(m_BoxBrush.CopiedSourcePosition, m_BoxBrush.CopiedBoxSize);
                
                Handles.color = Color.yellow;
                Handles.DrawLine(m_BoxBrush.CopiedSourcePosition, pos);
            }
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string toolName = Tools.current == Tool.Move ? "MOVE" : 
                              Tools.current == Tool.Rotate ? "ROTATE" : 
                              Tools.current == Tool.Scale ? "SCALE" : "ALL";
            string controls = m_BoxBrush.HasCopiedData 
                ? $"C=Copy | Del=Delete | V=Paste | X=Del&Paste | 1/2/R={toolName} | MClick=Exit"
                : $"C=Copy | Del=Delete | 1/2/R={toolName} | MClick=Exit";
            Handles.Label(pos + Vector3.up * (size.y * 0.5f + 0.1f), controls, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawSolid3DBox(Vector3 center, Vector3 size, Color color, float alpha)
        {
            DrawSolid3DBoxRotated(center, size, Quaternion.identity, color, alpha);
        }
        
        private void DrawSolid3DBoxRotated(Vector3 center, Vector3 size, Quaternion rotation, Color color, float alpha)
        {
            Vector3 half = size * 0.5f;
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            // 8 corners (rotated)
            Vector3 c0 = center + rotation * new Vector3(-half.x, -half.y, -half.z);
            Vector3 c1 = center + rotation * new Vector3(half.x, -half.y, -half.z);
            Vector3 c2 = center + rotation * new Vector3(half.x, -half.y, half.z);
            Vector3 c3 = center + rotation * new Vector3(-half.x, -half.y, half.z);
            Vector3 c4 = center + rotation * new Vector3(-half.x, half.y, -half.z);
            Vector3 c5 = center + rotation * new Vector3(half.x, half.y, -half.z);
            Vector3 c6 = center + rotation * new Vector3(half.x, half.y, half.z);
            Vector3 c7 = center + rotation * new Vector3(-half.x, half.y, half.z);
            
            // Draw 6 faces
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c1, c2, c3 }, fillColor, outlineColor); // Bottom
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c4, c5, c6, c7 }, fillColor, outlineColor); // Top
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c3, c2, c6, c7 }, fillColor, outlineColor); // Front
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c1, c5, c4 }, fillColor, outlineColor); // Back
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c3, c7, c4 }, fillColor, outlineColor); // Left
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c1, c2, c6, c5 }, fillColor, outlineColor); // Right
        }
        
        private void DrawWireCubeRotated(Vector3 center, Vector3 size, Quaternion rotation)
        {
            Vector3 half = size * 0.5f;
            
            Vector3 c0 = center + rotation * new Vector3(-half.x, -half.y, -half.z);
            Vector3 c1 = center + rotation * new Vector3(half.x, -half.y, -half.z);
            Vector3 c2 = center + rotation * new Vector3(half.x, -half.y, half.z);
            Vector3 c3 = center + rotation * new Vector3(-half.x, -half.y, half.z);
            Vector3 c4 = center + rotation * new Vector3(-half.x, half.y, -half.z);
            Vector3 c5 = center + rotation * new Vector3(half.x, half.y, -half.z);
            Vector3 c6 = center + rotation * new Vector3(half.x, half.y, half.z);
            Vector3 c7 = center + rotation * new Vector3(-half.x, half.y, half.z);
            
            // Bottom
            Handles.DrawLine(c0, c1); Handles.DrawLine(c1, c2);
            Handles.DrawLine(c2, c3); Handles.DrawLine(c3, c0);
            // Top
            Handles.DrawLine(c4, c5); Handles.DrawLine(c5, c6);
            Handles.DrawLine(c6, c7); Handles.DrawLine(c7, c4);
            // Verticals
            Handles.DrawLine(c0, c4); Handles.DrawLine(c1, c5);
            Handles.DrawLine(c2, c6); Handles.DrawLine(c3, c7);
        }

        private void DrawCloneBrushPreview(Vector3 cursorPos, SceneView sceneView)
        {
            if (m_CloneBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 12, fontStyle = FontStyle.Bold };
            
            Handles.color = m_CloneBrush.IsDrawingSource ? new Color(0f, 1f, 0.5f, 0.9f) : new Color(1f, 0.5f, 0f, 0.9f);
            Handles.SphereHandleCap(0, cursorPos, Quaternion.identity, 0.04f, EventType.Repaint);
            
            // Draw source polygon
            var srcVerts = m_CloneBrush.SourceVertices;
            if (srcVerts.Count > 0)
            {
                Handles.color = new Color(0f, 1f, 0.5f, 0.9f);
                for (int i = 0; i < srcVerts.Count; i++)
                {
                    Handles.SphereHandleCap(0, srcVerts[i], Quaternion.identity, 0.03f, EventType.Repaint);
                    if (i > 0)
                        Handles.DrawLine(srcVerts[i - 1], srcVerts[i]);
                }
                
                if (srcVerts.Count >= 3 && !m_CloneBrush.IsDrawingSource)
                    Handles.DrawLine(srcVerts[srcVerts.Count - 1], srcVerts[0]);
                
                if (m_CloneBrush.IsDrawingSource && srcVerts.Count > 0)
                {
                    Handles.color = new Color(0f, 1f, 0.5f, 0.5f);
                    Handles.DrawDottedLine(srcVerts[srcVerts.Count - 1], cursorPos, 4f);
                    if (srcVerts.Count >= 2)
                        Handles.DrawDottedLine(cursorPos, srcVerts[0], 4f);
                }
            }
            
            // Draw target
            if (m_CloneBrush.HasTarget)
            {
                Handles.color = new Color(1f, 0.5f, 0f, 0.9f);
                Handles.SphereHandleCap(0, m_CloneBrush.TargetPosition, Quaternion.identity, 0.06f, EventType.Repaint);
                Handles.DrawWireCube(m_CloneBrush.TargetPosition, Vector3.one * 0.1f);
            }
            
            // Draw connection line
            if (m_CloneBrush.HasSourcePolygon && m_CloneBrush.HasTarget)
            {
                Handles.color = Color.yellow;
                Handles.DrawLine(m_CloneBrush.SourceCenter, m_CloneBrush.TargetPosition);
            }
            
            // Instructions
            string instruction = m_CloneBrush.IsDrawingSource 
                ? (srcVerts.Count < 3 ? $"Draw SOURCE ({srcVerts.Count}/3+ vertices)" : $"SOURCE: {srcVerts.Count} vertices - ENTER to finish")
                : (!m_CloneBrush.HasTarget ? "Click to place TARGET" : "SPACE to clone!");
            Handles.Label(cursorPos + Vector3.up * 0.15f, instruction, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawFloorFillPreview(SceneView sceneView)
        {
            if (m_FloorFillBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Fill region
            Handles.color = new Color(1f, 0.5f, 0f, 0.9f);
            Vector3 fillSize = new Vector3(m_FloorFillBrush.FillSize.x, m_FloorFillBrush.FloorThickness, m_FloorFillBrush.FillSize.y);
            Handles.DrawWireCube(m_FloorFillBrush.FillCenter, fillSize);
            
            // Sample regions
            Handles.color = new Color(0f, 1f, 0.5f, 0.9f);
            foreach (var bounds in m_FloorFillBrush.SampleRegions)
                Handles.DrawWireCube(bounds.center, bounds.size);
            
            // Grid preview
            Handles.color = new Color(1f, 1f, 0f, 0.3f);
            var gridPositions = m_FloorFillBrush.GetFillGridPositions();
            float tileHalfX = m_FloorFillBrush.TileSize.x * 0.5f;
            float tileHalfZ = m_FloorFillBrush.TileSize.y * 0.5f;
            
            foreach (var pos in gridPositions)
            {
                Handles.DrawLine(pos - Vector3.right * tileHalfX * 0.3f, pos + Vector3.right * tileHalfX * 0.3f);
                Handles.DrawLine(pos - Vector3.forward * tileHalfZ * 0.3f, pos + Vector3.forward * tileHalfZ * 0.3f);
            }
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            Handles.Label(m_FloorFillBrush.FillCenter + Vector3.up * 0.5f, "F=Fill | D=Delete", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawFloorFillHandles(SceneView sceneView)
        {
            if (m_FloorFillBrush == null) return;
            
            // Position handle
            EditorGUI.BeginChangeCheck();
            Vector3 newCenter = Handles.PositionHandle(m_FloorFillBrush.FillCenter, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_FloorFillBrush, "Move Fill Region");
                m_FloorFillBrush.FillCenter = newCenter;
                m_FloorFillBrush.UpdateSampleRegions();
            }
        }

        private void DrawPatchToolPreview(SceneView sceneView)
        {
            if (m_PatchTool == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Source patches
            for (int i = 0; i < m_PatchTool.SourcePatches.Count; i++)
            {
                var patch = m_PatchTool.SourcePatches[i];
                Handles.color = new Color(patch.gizmoColor.r, patch.gizmoColor.g, patch.gizmoColor.b, 0.9f);
                Handles.DrawWireCube(patch.position, patch.size);
            }
            
            // Target region
            var target = m_PatchTool.TargetRegion;
            Handles.color = new Color(1f, 0.3f, 0.3f, 0.9f);
            Handles.DrawWireCube(target.position, target.size);
            
            // Grid preview
            Handles.color = new Color(1f, 1f, 0f, 0.3f);
            var positions = m_PatchTool.GetGridPreviewPositions();
            float dotSize = Mathf.Min(m_PatchTool.GridCellSize.x, m_PatchTool.GridCellSize.z) * 0.15f;
            
            foreach (var pos in positions)
                Handles.SphereHandleCap(0, pos, Quaternion.identity, dotSize, EventType.Repaint);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawColorBrushHandles(SceneView sceneView)
        {
            if (m_ColorBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_ColorBrush.BoxPosition;
            Vector3 size = m_ColorBrush.BoxSize;
            
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorBrush, "Move Box");
                m_ColorBrush.BoxPosition = newPos;
            }
            
            // Size handles
            float handleSize = HandleUtility.GetHandleSize(pos) * 0.1f;
            
            Handles.color = Color.red;
            EditorGUI.BeginChangeCheck();
            Vector3 xHandle = Handles.Slider(pos + Vector3.right * size.x * 0.5f, Vector3.right, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorBrush, "Resize Box");
                m_ColorBrush.BoxSize = new Vector3(Mathf.Abs((xHandle.x - pos.x) * 2f), size.y, size.z);
            }
            
            Handles.color = Color.green;
            EditorGUI.BeginChangeCheck();
            Vector3 yHandle = Handles.Slider(pos + Vector3.up * size.y * 0.5f, Vector3.up, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorBrush, "Resize Box");
                m_ColorBrush.BoxSize = new Vector3(size.x, Mathf.Abs((yHandle.y - pos.y) * 2f), size.z);
            }
            
            Handles.color = Color.blue;
            EditorGUI.BeginChangeCheck();
            Vector3 zHandle = Handles.Slider(pos + Vector3.forward * size.z * 0.5f, Vector3.forward, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_ColorBrush, "Resize Box");
                m_ColorBrush.BoxSize = new Vector3(size.x, size.y, Mathf.Abs((zHandle.z - pos.z) * 2f));
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawColorBrushPreview(SceneView sceneView)
        {
            if (m_ColorBrush == null) return;
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_ColorBrush.BoxPosition;
            Vector3 size = m_ColorBrush.BoxSize;
            
            // Magenta/purple color for the color tool
            Handles.color = new Color(0.8f, 0.3f, 0.9f, 0.9f);
            Handles.DrawWireCube(pos, size);
            
            // Show color tint preview
            if (m_ColorBrush.HasAdjustments)
            {
                var adj = m_ColorBrush.ColorAdjust;
                Color previewColor = adj.colorTint;
                previewColor.a = 0.2f;
                Handles.color = previewColor;
                Handles.DrawWireCube(pos, size * 0.96f);
            }
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string info = m_ColorBrush.HasAdjustments ? "Adjust sliders for realtime update" : "Set color values in panel";
            Handles.Label(pos + Vector3.up * (size.y * 0.5f + 0.1f), info, labelStyle);
            
            // Show adjustment values
            if (m_ColorBrush.HasAdjustments)
            {
                var adj = m_ColorBrush.ColorAdjust;
                GUIStyle adjStyle = new GUIStyle { normal = { textColor = new Color(0.8f, 0.3f, 0.9f) }, fontSize = 10 };
                string adjInfo = $"Exp:{adj.exposure:F1} Con:{adj.contrast:F1} Hue:{adj.hueShift:F0} Sat:{adj.saturation:F1}";
                Handles.Label(pos + Vector3.up * (size.y * 0.5f + 0.2f), adjInfo, adjStyle);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
}

