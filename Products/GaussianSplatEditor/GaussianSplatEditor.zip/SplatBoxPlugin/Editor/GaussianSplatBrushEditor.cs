// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatBrush))]
    public class GaussianSplatBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatBrush m_Target;
        private bool m_BrushMode = false;
        private bool m_NavigationMode = false;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUI.BeginChangeCheck();
            float newScreenRadius = EditorGUILayout.Slider("Screen Radius", m_Target.ScreenRadius, 0.1f, 10f);
            float newFalloff = EditorGUILayout.Slider("Falloff", m_Target.BrushFalloff, 0.0f, 1.0f);
            float newNoise = EditorGUILayout.Slider("Noise Strength", m_Target.NoiseStrength, 0.0f, 1.0f);
            float newNoiseScale = EditorGUILayout.Slider("Noise Scale", m_Target.NoiseScale, 0.1f, 10.0f);
            bool newBackface = EditorGUILayout.Toggle(
                new GUIContent("Backface Culling", "Only delete splats visible from camera"), 
                m_Target.BackfaceCulling);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Color Filter", EditorStyles.boldLabel);
            bool newUseColorFilter = EditorGUILayout.Toggle("Use Color Filter", m_Target.UseColorFilter);
            Color newFilterColor = m_Target.FilterColor;
            float newColorThreshold = m_Target.ColorThreshold;
            
            if (newUseColorFilter)
            {
                newFilterColor = EditorGUILayout.ColorField("Filter Color", m_Target.FilterColor);
                newColorThreshold = EditorGUILayout.Slider("Color Threshold", m_Target.ColorThreshold, 0.01f, 1.0f);
                EditorGUILayout.HelpBox("0.1 = strict match | 0.5 = moderate | 1.0 = any color", MessageType.None);
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Brush Settings");
                m_Target.ScreenRadius = newScreenRadius;
                m_Target.BrushFalloff = newFalloff;
                m_Target.NoiseStrength = newNoise;
                m_Target.NoiseScale = newNoiseScale;
                m_Target.BackfaceCulling = newBackface;
                m_Target.UseColorFilter = newUseColorFilter;
                m_Target.FilterColor = newFilterColor;
                m_Target.ColorThreshold = newColorThreshold;
                EditorUtility.SetDirty(m_Target);
            }
            
            GUI.backgroundColor = m_BrushMode ? Color.green : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Brush Mode" : "Start Brush Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            m_NavigationMode = false;
            GaussianSplatBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            m_NavigationMode = false;
            GaussianSplatBrush.IsBrushModeActive = false;
            GaussianSplatBrush.HasValidBrushPosition = false;
            GaussianSplatBrush.IsDeleting = false;
            GaussianSplatBrush.IsRestoring = false;
            GaussianSplatBrush.IsLineMode = false;
            
            // Reset brush values
            if (m_Target != null)
            {
                m_Target.ScreenRadius = 1f;
                m_Target.BrushFalloff = 0f;
                m_Target.NoiseStrength = 0f;
                m_Target.NoiseScale = 1f;
            }
            
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatBrush.IsBrushModeActive = false;
                GaussianSplatBrush.HasValidBrushPosition = false;
                GaussianSplatBrush.IsDeleting = false;
                GaussianSplatBrush.IsRestoring = false;
                GaussianSplatBrush.IsLineMode = false;
                
                // Reset brush values
                if (m_Target != null)
                {
                    m_Target.ScreenRadius = 1f;
                    m_Target.BrushFalloff = 0f;
                    m_Target.NoiseStrength = 0f;
                    m_Target.NoiseScale = 1f;
                }
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                Ray navRay = HandleUtility.GUIPointToWorldRay(e.mousePosition);
                Vector3 navHitPoint = GetBrushHitPoint(navRay, sceneView);
                float navWorldRadius = CalculateWorldRadius(navHitPoint, sceneView);
                
                GaussianSplatBrush.LastBrushPosition = navHitPoint;
                GaussianSplatBrush.HasValidBrushPosition = true;
                GaussianSplatBrush.CurrentWorldRadius = navWorldRadius;
                
                Vector3 camForward = sceneView.camera.transform.forward;
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = new Color(0.5f, 0.5f, 0.5f, 0.4f);
                Handles.DrawWireDisc(navHitPoint, -camForward, navWorldRadius);
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
                
                sceneView.Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetBrushHitPoint(ray, sceneView);
            float worldRadius = CalculateWorldRadius(hitPoint, sceneView);

            GaussianSplatBrush.LastBrushPosition = hitPoint;
            GaussianSplatBrush.HasValidBrushPosition = true;
            GaussianSplatBrush.CurrentWorldRadius = worldRadius;
            GaussianSplatBrush.CurrentViewDirection = ray.direction;
            
            // Use the mouse ray for accurate screen-space deletion
            Vector3 rayDir = ray.direction;
            bool isShiftHeld = e.shift;
            
            // Scale radius to match visualization
            float brushRadius = worldRadius;
            
            // Calculate screen position and radius for backface culling mode
            Vector3 screenPos3D = sceneView.camera.WorldToScreenPoint(hitPoint);
            Vector2 screenCenterPx = new Vector2(screenPos3D.x, sceneView.camera.pixelHeight - screenPos3D.y);
            
            // Estimate screen radius in pixels
            float dist = Vector3.Distance(sceneView.camera.transform.position, hitPoint);
            float fovFact = sceneView.camera.pixelHeight * 0.5f / Mathf.Tan(sceneView.camera.fieldOfView * 0.5f * Mathf.Deg2Rad);
            float screenRadius = (brushRadius / dist) * fovFact;

            // Shift+Left Click for line mode - check FIRST before other handling
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && isShiftHeld && !GaussianSplatBrush.IsLineMode)
            {
                GaussianSplatBrush.IsLineMode = true;
                GaussianSplatBrush.LineStartPosition = hitPoint;
                GaussianSplatBrush.LineStartRadius = brushRadius;
                GaussianSplatBrush.LineStartViewDirection = rayDir;
                GaussianSplatBrush.LineStartScreenPosition = screenCenterPx;
                GaussianSplatBrush.LineStartScreenRadius = screenRadius;
                GaussianSplatBrush.IsDeleting = true;
                e.Use();
            }
            // Line mode mouse up - complete the line deletion
            else if (e.type == EventType.MouseUp && e.button == 0 && GaussianSplatBrush.IsLineMode)
            {
                if (m_Target.BackfaceCulling)
                {
                    m_Target.DeleteLineAtScreenPosition(GaussianSplatBrush.LineStartScreenPosition, screenCenterPx, 
                        GaussianSplatBrush.LineStartScreenRadius, screenRadius, sceneView.camera);
                }
                else
                {
                    m_Target.DeleteLine(GaussianSplatBrush.LineStartPosition, hitPoint, 
                        GaussianSplatBrush.LineStartRadius, brushRadius,
                        GaussianSplatBrush.LineStartViewDirection, rayDir, sceneView.camera);
                }
                GaussianSplatBrush.IsLineMode = false;
                GaussianSplatBrush.IsDeleting = false;
                e.Use();
            }
            // Regular deletion (not in line mode)
            else if (!GaussianSplatBrush.IsLineMode && (e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 0 && !e.alt)
            {
                if (m_Target.BackfaceCulling)
                {
                    m_Target.DeleteAtScreenPosition(screenCenterPx, screenRadius, sceneView.camera);
                }
                else
                {
                    m_Target.DeleteAtPosition(hitPoint, brushRadius, rayDir, sceneView.camera);
                }
                e.Use();
            }
            
            // Track action state for color (only when not in line mode)
            if (!GaussianSplatBrush.IsLineMode)
            {
                if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !isShiftHeld)
                    GaussianSplatBrush.IsDeleting = true;
                else if (e.type == EventType.MouseUp && e.button == 0)
                    GaussianSplatBrush.IsDeleting = false;
            }
            
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
                GaussianSplatBrush.IsRestoring = true;
            else if (e.type == EventType.MouseUp && e.button == 1)
                GaussianSplatBrush.IsRestoring = false;
            
            // Always draw brush preview
            DrawBrushPreview(hitPoint, brushRadius, sceneView);
            
            // Draw line preview when in line mode
            if (GaussianSplatBrush.IsLineMode)
                DrawLinePreview(GaussianSplatBrush.LineStartPosition, hitPoint, GaussianSplatBrush.LineStartRadius, brushRadius, sceneView);
            
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_Target, "Resize Brush");
                m_Target.ScreenRadius = Mathf.Clamp(m_Target.ScreenRadius - e.delta.y * 0.1f, 0.1f, 10f);
                EditorUtility.SetDirty(m_Target);
                e.Use();
                Repaint();
            }
            
            if ((e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 1 && !e.alt)
            {
                m_Target.RestoreAtPosition(hitPoint, brushRadius, rayDir);
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopBrushMode();
                Repaint();
                e.Use();
            }

            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private Vector3 GetBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            // Always place disc on plane at pivot depth - follows mouse directly
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }

        private float CalculateWorldRadius(Vector3 worldPos, SceneView sceneView)
        {
            Camera cam = sceneView.camera;
            float distance = Vector3.Distance(cam.transform.position, worldPos);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * distance * Mathf.Tan(fov * 0.5f)) / screenHeight;
            return m_Target.ScreenRadius * worldPerPixel;
        }

        private void DrawBrushPreview(Vector3 position, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            
            Color mainColor = GaussianSplatBrush.IsRestoring 
                ? new Color(0.3f, 0.5f, 1f, 0.9f)
                : new Color(1f, 0.3f, 0.3f, 0.9f);
            
            Color fillColor = GaussianSplatBrush.IsRestoring 
                ? new Color(0.3f, 0.5f, 1f, 0.15f)
                : new Color(1f, 0.3f, 0.3f, 0.15f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(position, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(position, -camForward, radius, 2f);
            
            if (m_Target.BrushFalloff > 0)
            {
                float innerRadius = radius * (1f - m_Target.BrushFalloff);
                Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.5f);
                Handles.DrawWireDisc(position, -camForward, innerRadius, 1f);
            }
            
            Handles.color = mainColor;
            Handles.DrawSolidDisc(position, -camForward, radius * 0.03f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawLinePreview(Vector3 startPos, Vector3 endPos, float startRadius, float endRadius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Color lineColor = new Color(1f, 0.6f, 0.2f, 0.9f);
            Color fillColor = new Color(1f, 0.6f, 0.2f, 0.2f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw start disc
            Handles.color = fillColor;
            Handles.DrawSolidDisc(startPos, -camForward, startRadius);
            Handles.color = lineColor;
            Handles.DrawWireDisc(startPos, -camForward, startRadius, 2f);
            
            // Draw connecting line
            Handles.color = lineColor;
            Handles.DrawLine(startPos, endPos, 3f);
            
            // Draw perpendicular edges for line width visualization
            Vector3 lineDir = (endPos - startPos).normalized;
            Vector3 perpDir = Vector3.Cross(lineDir, camForward).normalized;
            
            Handles.color = new Color(lineColor.r, lineColor.g, lineColor.b, 0.5f);
            Handles.DrawLine(startPos + perpDir * startRadius, endPos + perpDir * endRadius, 1.5f);
            Handles.DrawLine(startPos - perpDir * startRadius, endPos - perpDir * endRadius, 1.5f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
    
    [EditorTool("Splat Brush", typeof(GaussianSplatBrush))]
    public class GaussianSplatBrushTool : EditorTool
    {
        private GaussianSplatBrush m_Brush;
        private bool m_NavigationMode = false;

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("Grid.PaintTool").image,
            "Splat Brush Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatBrush;
            GaussianSplatBrush.IsBrushModeActive = true;
            m_NavigationMode = false;
        }
        
        private void OnDisable()
        {
            GaussianSplatBrush.IsBrushModeActive = false;
            GaussianSplatBrush.HasValidBrushPosition = false;
            GaussianSplatBrush.IsDeleting = false;
            GaussianSplatBrush.IsRestoring = false;
            GaussianSplatBrush.IsLineMode = false;
            m_NavigationMode = false;
            
            // Reset brush values
            if (m_Brush != null)
            {
                m_Brush.ScreenRadius = 1f;
                m_Brush.BrushFalloff = 0f;
                m_Brush.NoiseStrength = 0f;
                m_Brush.NoiseScale = 1f;
            }
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                GaussianSplatBrush.IsBrushModeActive = false;
                
                Ray navRay = HandleUtility.GUIPointToWorldRay(e.mousePosition);
                Vector3 navHitPoint = GetToolBrushHitPoint(navRay, sceneView);
                float navWorldRadius = CalculateToolWorldRadius(navHitPoint, sceneView);
                
                GaussianSplatBrush.LastBrushPosition = navHitPoint;
                GaussianSplatBrush.HasValidBrushPosition = true;
                GaussianSplatBrush.CurrentWorldRadius = navWorldRadius;
                
                Vector3 camForward = sceneView.camera.transform.forward;
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = new Color(0.5f, 0.5f, 0.5f, 0.4f);
                Handles.DrawWireDisc(navHitPoint, -camForward, navWorldRadius);
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
                
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatBrush.IsBrushModeActive = true;

            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetToolBrushHitPoint(ray, sceneView);
            float worldRadius = CalculateToolWorldRadius(hitPoint, sceneView);

            GaussianSplatBrush.LastBrushPosition = hitPoint;
            GaussianSplatBrush.HasValidBrushPosition = true;
            GaussianSplatBrush.CurrentWorldRadius = worldRadius;
            GaussianSplatBrush.CurrentViewDirection = ray.direction;
            
            // Use the mouse ray for accurate screen-space deletion
            Vector3 rayDir = ray.direction;
            bool isShiftHeld = e.shift;
            
            // Scale radius to match visualization
            float brushRadius = worldRadius;
            
            // Calculate screen position and radius for backface culling mode
            Vector3 screenPos3D = sceneView.camera.WorldToScreenPoint(hitPoint);
            Vector2 screenCenterPx = new Vector2(screenPos3D.x, sceneView.camera.pixelHeight - screenPos3D.y);
            
            // Estimate screen radius in pixels
            float dist = Vector3.Distance(sceneView.camera.transform.position, hitPoint);
            float fovFact = sceneView.camera.pixelHeight * 0.5f / Mathf.Tan(sceneView.camera.fieldOfView * 0.5f * Mathf.Deg2Rad);
            float screenRadius = (brushRadius / dist) * fovFact;

            // Shift+Left Click for line mode - check FIRST before other handling
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && isShiftHeld && !GaussianSplatBrush.IsLineMode)
            {
                GaussianSplatBrush.IsLineMode = true;
                GaussianSplatBrush.LineStartPosition = hitPoint;
                GaussianSplatBrush.LineStartRadius = brushRadius;
                GaussianSplatBrush.LineStartViewDirection = rayDir;
                GaussianSplatBrush.LineStartScreenPosition = screenCenterPx;
                GaussianSplatBrush.LineStartScreenRadius = screenRadius;
                GaussianSplatBrush.IsDeleting = true;
                e.Use();
            }
            // Line mode mouse up - complete the line deletion
            else if (e.type == EventType.MouseUp && e.button == 0 && GaussianSplatBrush.IsLineMode)
            {
                if (m_Brush.BackfaceCulling)
                {
                    m_Brush.DeleteLineAtScreenPosition(GaussianSplatBrush.LineStartScreenPosition, screenCenterPx, 
                        GaussianSplatBrush.LineStartScreenRadius, screenRadius, sceneView.camera);
                }
                else
                {
                    m_Brush.DeleteLine(GaussianSplatBrush.LineStartPosition, hitPoint, 
                        GaussianSplatBrush.LineStartRadius, brushRadius,
                        GaussianSplatBrush.LineStartViewDirection, rayDir, sceneView.camera);
                }
                GaussianSplatBrush.IsLineMode = false;
                GaussianSplatBrush.IsDeleting = false;
                e.Use();
            }
            // Regular deletion (not in line mode)
            else if (!GaussianSplatBrush.IsLineMode && (e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 0 && !e.alt)
            {
                if (m_Brush.BackfaceCulling)
                {
                    m_Brush.DeleteAtScreenPosition(screenCenterPx, screenRadius, sceneView.camera);
                }
                else
                {
                    m_Brush.DeleteAtPosition(hitPoint, brushRadius, rayDir, sceneView.camera);
                }
                e.Use();
            }
            
            // Track action state for color (only when not in line mode)
            if (!GaussianSplatBrush.IsLineMode)
            {
                if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !isShiftHeld)
                    GaussianSplatBrush.IsDeleting = true;
                else if (e.type == EventType.MouseUp && e.button == 0)
                    GaussianSplatBrush.IsDeleting = false;
            }
            
            if (e.type == EventType.MouseDown && e.button == 1 && !e.alt)
                GaussianSplatBrush.IsRestoring = true;
            else if (e.type == EventType.MouseUp && e.button == 1)
                GaussianSplatBrush.IsRestoring = false;
            
            // Always draw brush preview
            DrawToolBrushPreview(hitPoint, brushRadius, sceneView);
            
            // Draw line preview when in line mode
            if (GaussianSplatBrush.IsLineMode)
                DrawToolLinePreview(GaussianSplatBrush.LineStartPosition, hitPoint, GaussianSplatBrush.LineStartRadius, brushRadius, sceneView);
            
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_Brush, "Resize Brush");
                m_Brush.ScreenRadius = Mathf.Clamp(m_Brush.ScreenRadius - e.delta.y * 0.1f, 0.1f, 10f);
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }
            
            if ((e.type == EventType.MouseDown || e.type == EventType.MouseDrag) && e.button == 1 && !e.alt)
            {
                m_Brush.RestoreAtPosition(hitPoint, brushRadius, rayDir);
                e.Use();
            }

            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            sceneView.Repaint();
        }
        
        private Vector3 GetToolBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            // Always place disc on plane at pivot depth - follows mouse directly
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private float CalculateToolWorldRadius(Vector3 worldPos, SceneView sceneView)
        {
            Camera cam = sceneView.camera;
            float distance = Vector3.Distance(cam.transform.position, worldPos);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * distance * Mathf.Tan(fov * 0.5f)) / screenHeight;
            return m_Brush.ScreenRadius * worldPerPixel;
        }

        private void DrawToolBrushPreview(Vector3 position, float radius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            
            Color mainColor = GaussianSplatBrush.IsRestoring 
                ? new Color(0.3f, 0.5f, 1f, 0.9f)
                : new Color(1f, 0.3f, 0.3f, 0.9f);
            
            Color fillColor = GaussianSplatBrush.IsRestoring 
                ? new Color(0.3f, 0.5f, 1f, 0.15f)
                : new Color(1f, 0.3f, 0.3f, 0.15f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = fillColor;
            Handles.DrawSolidDisc(position, -camForward, radius);
            
            Handles.color = mainColor;
            Handles.DrawWireDisc(position, -camForward, radius, 2f);
            
            if (m_Brush.BrushFalloff > 0)
            {
                float innerRadius = radius * (1f - m_Brush.BrushFalloff);
                Handles.color = new Color(mainColor.r, mainColor.g, mainColor.b, 0.5f);
                Handles.DrawWireDisc(position, -camForward, innerRadius, 1f);
            }
            
            Handles.color = mainColor;
            Handles.DrawSolidDisc(position, -camForward, radius * 0.03f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawToolLinePreview(Vector3 startPos, Vector3 endPos, float startRadius, float endRadius, SceneView sceneView)
        {
            Vector3 camForward = sceneView.camera.transform.forward;
            Color lineColor = new Color(1f, 0.6f, 0.2f, 0.9f);
            Color fillColor = new Color(1f, 0.6f, 0.2f, 0.2f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw start disc
            Handles.color = fillColor;
            Handles.DrawSolidDisc(startPos, -camForward, startRadius);
            Handles.color = lineColor;
            Handles.DrawWireDisc(startPos, -camForward, startRadius, 2f);
            
            // Draw connecting line
            Handles.color = lineColor;
            Handles.DrawLine(startPos, endPos, 3f);
            
            // Draw perpendicular edges for line width visualization
            Vector3 lineDir = (endPos - startPos).normalized;
            Vector3 perpDir = Vector3.Cross(lineDir, camForward).normalized;
            
            Handles.color = new Color(lineColor.r, lineColor.g, lineColor.b, 0.5f);
            Handles.DrawLine(startPos + perpDir * startRadius, endPos + perpDir * endRadius, 1.5f);
            Handles.DrawLine(startPos - perpDir * startRadius, endPos - perpDir * endRadius, 1.5f);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
}
