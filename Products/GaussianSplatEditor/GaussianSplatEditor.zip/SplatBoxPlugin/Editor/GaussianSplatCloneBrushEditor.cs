// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;
using System.Collections.Generic;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatCloneBrush))]
    public class GaussianSplatCloneBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatCloneBrush m_Target;
        private bool m_BrushMode = false;
        private bool m_NavigationMode = false;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatCloneBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Selection Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            float newDepth = EditorGUILayout.Slider("Selection Depth", m_Target.SelectionDepth, 0.01f, 2.0f);
            float newDepthOffset = EditorGUILayout.Slider("Depth Offset", m_Target.DepthOffset, -2.0f, 2.0f);
            EditorGUILayout.HelpBox("Depth Offset: + moves clone toward camera, - moves away", MessageType.None);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Clone Brush Settings");
                m_Target.SelectionDepth = newDepth;
                m_Target.DepthOffset = newDepthOffset;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Status", EditorStyles.boldLabel);
            
            string modeText = m_Target.IsDrawingSource ? "Step 1: Draw SOURCE polygon" : "Step 2: Click TARGET position";
            Color modeColor = m_Target.IsDrawingSource ? new Color(0f, 1f, 0.5f) : new Color(1f, 0.5f, 0f);
            GUI.color = modeColor;
            EditorGUILayout.LabelField(modeText, EditorStyles.boldLabel);
            GUI.color = Color.white;
            
            EditorGUILayout.LabelField($"Source vertices: {m_Target.SourceVertices.Count}");
            if (m_Target.HasTarget)
                EditorGUILayout.Vector3Field("Target Position", m_Target.TargetPosition);
            
            EditorGUILayout.Space();
            
            EditorGUILayout.HelpBox(
                "1. LEFT CLICK - Add source vertices (min 3)\n" +
                "2. ENTER - Finish source polygon\n" +
                "3. LEFT CLICK - Set target position\n" +
                "4. SPACE - Execute clone\n\n" +
                "BACKSPACE - Undo | RIGHT CLICK - Clear all",
                MessageType.Info);
            
            EditorGUILayout.Space();
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Undo"))
                m_Target.UndoLastVertex();
            if (GUILayout.Button("Clear All"))
                m_Target.ClearAll();
            EditorGUILayout.EndHorizontal();
            
            if (m_Target.CanClone)
            {
                GUI.backgroundColor = Color.green;
                if (GUILayout.Button("Execute Clone", GUILayout.Height(30)))
                {
                    m_Target.PerformClone();
                }
                GUI.backgroundColor = Color.white;
            }
            
            EditorGUILayout.Space();
            
            GUI.backgroundColor = m_BrushMode ? Color.cyan : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Clone Mode" : "Start Clone Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            m_NavigationMode = false;
            GaussianSplatCloneBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            m_NavigationMode = false;
            GaussianSplatCloneBrush.IsBrushModeActive = false;
            GaussianSplatCloneBrush.HasValidBrushPosition = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatCloneBrush.IsBrushModeActive = false;
                GaussianSplatCloneBrush.HasValidBrushPosition = false;
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                sceneView.Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetBrushHitPoint(ray, sceneView);

            GaussianSplatCloneBrush.LastBrushPosition = hitPoint;
            GaussianSplatCloneBrush.HasValidBrushPosition = true;
            
            DrawPreview(hitPoint, sceneView);
            
            // Left click to add vertex or set target
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                m_Target.AddVertex(hitPoint);
                e.Use();
                sceneView.Repaint();
                Repaint();
            }
            
            // Right click to clear all
            if (e.type == EventType.MouseDown && e.button == 1)
            {
                m_Target.ClearAll();
                e.Use();
                sceneView.Repaint();
                Repaint();
            }
            
            // Enter to finish source polygon
            if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
            {
                if (m_Target.IsDrawingSource && m_Target.SourceVertices.Count >= 3)
                {
                    m_Target.FinishSourcePolygon();
                }
                e.Use();
                sceneView.Repaint();
                Repaint();
            }
            
            // Backspace to undo
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Backspace)
            {
                m_Target.UndoLastVertex();
                e.Use();
                sceneView.Repaint();
                Repaint();
            }
            
            // Space to execute clone
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Space)
            {
                if (m_Target.CanClone)
                {
                    m_Target.PerformClone();
                }
                e.Use();
                sceneView.Repaint();
                Repaint();
            }
            
            // Escape to stop brush mode
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopBrushMode();
                Repaint();
                e.Use();
            }

            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private Vector3 GetBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            
            // When placing target (not drawing source), use source center's depth plane
            if (!m_Target.IsDrawingSource && m_Target.SourceVertices.Count >= 3)
            {
                Vector3 sourceCenter = m_Target.SourceCenter;
                Plane sourcePlane = new Plane(-cameraForward, sourceCenter);
                if (sourcePlane.Raycast(ray, out float planeDist) && planeDist > 0)
                    return ray.GetPoint(planeDist);
            }
            
            // When drawing source, use camera pivot plane for consistent depth
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float dist) && dist > 0)
                return ray.GetPoint(dist);
            
            return ray.origin + ray.direction * pivotDistance;
        }

        private void DrawPreview(Vector3 cursorPos, SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            GUIStyle labelStyle = new GUIStyle();
            labelStyle.normal.textColor = Color.white;
            labelStyle.fontSize = 12;
            labelStyle.fontStyle = FontStyle.Bold;
            
            // Draw cursor point
            Handles.color = m_Target.IsDrawingSource ? new Color(0f, 1f, 0.5f, 0.9f) : new Color(1f, 0.5f, 0f, 0.9f);
            Handles.SphereHandleCap(0, cursorPos, Quaternion.identity, 0.04f, EventType.Repaint);
            
            // Draw source polygon (green)
            List<Vector3> srcVerts = m_Target.SourceVertices;
            if (srcVerts.Count > 0)
            {
                Handles.color = new Color(0f, 1f, 0.5f, 0.9f);
                for (int i = 0; i < srcVerts.Count; i++)
                {
                    Handles.SphereHandleCap(0, srcVerts[i], Quaternion.identity, 0.03f, EventType.Repaint);
                    if (i > 0)
                        Handles.DrawLine(srcVerts[i - 1], srcVerts[i]);
                }
                
                // Close polygon if source is finished
                if (srcVerts.Count >= 3 && !m_Target.IsDrawingSource)
                {
                    Handles.DrawLine(srcVerts[srcVerts.Count - 1], srcVerts[0]);
                    
                    // Draw source center
                    Handles.color = new Color(0f, 1f, 0.5f, 0.7f);
                    Handles.SphereHandleCap(0, m_Target.SourceCenter, Quaternion.identity, 0.05f, EventType.Repaint);
                }
                
                // Draw line from last vertex to cursor if drawing source
                if (m_Target.IsDrawingSource && srcVerts.Count > 0)
                {
                    Handles.color = new Color(0f, 1f, 0.5f, 0.5f);
                    Handles.DrawDottedLine(srcVerts[srcVerts.Count - 1], cursorPos, 4f);
                    if (srcVerts.Count >= 2)
                        Handles.DrawDottedLine(cursorPos, srcVerts[0], 4f);
                }
            }
            
            // Draw target position (orange)
            if (m_Target.HasTarget)
            {
                Handles.color = new Color(1f, 0.5f, 0f, 0.9f);
                Handles.SphereHandleCap(0, m_Target.TargetPosition, Quaternion.identity, 0.06f, EventType.Repaint);
                Handles.DrawWireCube(m_Target.TargetPosition, Vector3.one * 0.1f);
                Handles.Label(m_Target.TargetPosition + Vector3.up * 0.15f, "TARGET");
            }
            
            // Draw line from source center to target
            if (m_Target.HasSourcePolygon && m_Target.HasTarget)
            {
                Handles.color = Color.yellow;
                Handles.DrawLine(m_Target.SourceCenter, m_Target.TargetPosition);
                
                Vector3 offset = m_Target.TargetPosition - m_Target.SourceCenter;
                Vector3 midPoint = (m_Target.SourceCenter + m_Target.TargetPosition) / 2f;
                
                labelStyle.normal.textColor = Color.yellow;
                Handles.Label(midPoint + Vector3.up * 0.1f, $"Offset: {offset.magnitude:F2}m\nSPACE to clone!", labelStyle);
            }
            // Show preview line from source center to cursor when placing target
            else if (m_Target.HasSourcePolygon && !m_Target.IsDrawingSource && !m_Target.HasTarget)
            {
                Handles.color = new Color(1f, 0.5f, 0f, 0.5f);
                Handles.DrawDottedLine(m_Target.SourceCenter, cursorPos, 4f);
            }
            
            // Show instructions
            labelStyle.normal.textColor = Color.white;
            string instruction;
            if (m_Target.IsDrawingSource)
            {
                if (srcVerts.Count < 3)
                    instruction = $"Draw SOURCE ({srcVerts.Count}/3+ vertices) - Click to add";
                else
                    instruction = $"SOURCE: {srcVerts.Count} vertices - ENTER to finish";
            }
            else if (!m_Target.HasTarget)
            {
                instruction = "Click to place TARGET position";
            }
            else
            {
                instruction = "SPACE to clone!";
            }
            
            Handles.Label(cursorPos + Vector3.up * 0.15f, instruction, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
    
    [EditorTool("Splat Clone Brush", typeof(GaussianSplatCloneBrush))]
    public class GaussianSplatCloneBrushTool : EditorTool
    {
        private GaussianSplatCloneBrush m_Brush;
        private bool m_NavigationMode = false;

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("Grid.PaintTool").image,
            "Splat Clone Brush Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatCloneBrush;
            GaussianSplatCloneBrush.IsBrushModeActive = true;
            m_NavigationMode = false;
        }
        
        private void OnDisable()
        {
            GaussianSplatCloneBrush.IsBrushModeActive = false;
            GaussianSplatCloneBrush.HasValidBrushPosition = false;
            m_NavigationMode = false;
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                GaussianSplatCloneBrush.IsBrushModeActive = false;
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatCloneBrush.IsBrushModeActive = true;

            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetToolBrushHitPoint(ray, sceneView);

            GaussianSplatCloneBrush.LastBrushPosition = hitPoint;
            GaussianSplatCloneBrush.HasValidBrushPosition = true;
            
            DrawToolPreview(hitPoint, sceneView);
            
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                m_Brush.AddVertex(hitPoint);
                e.Use();
            }
            
            if (e.type == EventType.MouseDown && e.button == 1)
            {
                m_Brush.ClearAll();
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
            {
                if (m_Brush.IsDrawingSource && m_Brush.SourceVertices.Count >= 3)
                    m_Brush.FinishSourcePolygon();
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Backspace)
            {
                m_Brush.UndoLastVertex();
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Space)
            {
                if (m_Brush.CanClone)
                    m_Brush.PerformClone();
                e.Use();
            }

            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            sceneView.Repaint();
        }
        
        private Vector3 GetToolBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            
            // When placing target (not drawing source), use source center's depth plane
            if (m_Brush != null && !m_Brush.IsDrawingSource && m_Brush.SourceVertices.Count >= 3)
            {
                Vector3 sourceCenter = m_Brush.SourceCenter;
                Plane sourcePlane = new Plane(-cameraForward, sourceCenter);
                if (sourcePlane.Raycast(ray, out float planeDist) && planeDist > 0)
                    return ray.GetPoint(planeDist);
            }
            
            // When drawing source, use camera pivot plane for consistent depth
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float dist) && dist > 0)
                return ray.GetPoint(dist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private void DrawToolPreview(Vector3 cursorPos, SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Handles.color = m_Brush.IsDrawingSource ? new Color(0f, 1f, 0.5f, 0.9f) : new Color(1f, 0.5f, 0f, 0.9f);
            Handles.SphereHandleCap(0, cursorPos, Quaternion.identity, 0.04f, EventType.Repaint);
            
            List<Vector3> srcVerts = m_Brush.SourceVertices;
            if (srcVerts.Count > 0)
            {
                Handles.color = new Color(0f, 1f, 0.5f, 0.9f);
                for (int i = 0; i < srcVerts.Count; i++)
                {
                    Handles.SphereHandleCap(0, srcVerts[i], Quaternion.identity, 0.03f, EventType.Repaint);
                    if (i > 0)
                        Handles.DrawLine(srcVerts[i - 1], srcVerts[i]);
                }
                
                if (srcVerts.Count >= 3 && !m_Brush.IsDrawingSource)
                    Handles.DrawLine(srcVerts[srcVerts.Count - 1], srcVerts[0]);
                
                if (m_Brush.IsDrawingSource && srcVerts.Count > 0)
                {
                    Handles.color = new Color(0f, 1f, 0.5f, 0.5f);
                    Handles.DrawDottedLine(srcVerts[srcVerts.Count - 1], cursorPos, 4f);
                    if (srcVerts.Count >= 2)
                        Handles.DrawDottedLine(cursorPos, srcVerts[0], 4f);
                }
            }
            
            if (m_Brush.HasTarget)
            {
                Handles.color = new Color(1f, 0.5f, 0f, 0.9f);
                Handles.SphereHandleCap(0, m_Brush.TargetPosition, Quaternion.identity, 0.06f, EventType.Repaint);
            }
            
            if (m_Brush.HasSourcePolygon && m_Brush.HasTarget)
            {
                Handles.color = Color.yellow;
                Handles.DrawLine(m_Brush.SourceCenter, m_Brush.TargetPosition);
            }
            else if (m_Brush.HasSourcePolygon && !m_Brush.IsDrawingSource && !m_Brush.HasTarget)
            {
                Handles.color = new Color(1f, 0.5f, 0f, 0.5f);
                Handles.DrawDottedLine(m_Brush.SourceCenter, cursorPos, 4f);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
}
