// SPDX-License-Identifier: MIT
// Builds a separate Relight plugin package. Requires SplatBox to be installed first.

using UnityEngine;
using UnityEditor;
using System;
using System.IO;

namespace GaussianSplatting.Editor
{
    public static class RelightPluginBuilder
    {
        const string kPackageName = "com.gaussiansplatting.splatbox.relight";
        const string kSplatBoxPluginDep = "com.gaussiansplatting.splatbox.plugin";

        static string PluginOutputPath
        {
            get
            {
                string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                return Path.Combine(projectPath, "RelightPlugin");
            }
        }

        [MenuItem("SplatBox/Build Relight Plugin Package")]
        public static void BuildRelightPluginPackage()
        {
            string packageRoot = GetPackageRoot();
            if (string.IsNullOrEmpty(packageRoot))
            {
                EditorUtility.DisplayDialog("Relight Plugin Builder - Error",
                    "Could not determine package root.\nEnsure SplatBox (with Relight) is installed.",
                    "OK");
                return;
            }

            if (!Directory.Exists(PluginOutputPath))
                Directory.CreateDirectory(PluginOutputPath);

            string pluginsFolder = Path.Combine(PluginOutputPath, "Plugins");
            string pluginsEditorFolder = Path.Combine(pluginsFolder, "Editor");
            string shadersFolder = Path.Combine(PluginOutputPath, "Shaders");
            string resourcesFolder = Path.Combine(PluginOutputPath, "Resources");

            CreateDir(pluginsFolder);
            CreateDir(pluginsEditorFolder);
            CreateDir(shadersFolder);
            CreateDir(resourcesFolder);

            string libraryPath = Path.Combine(Application.dataPath, "..", "Library", "ScriptAssemblies");
            int count = 0;

            count += CopyDll(libraryPath, pluginsFolder, "GaussianSplatting.SplatBox.Relight.dll");
            CopyDll(libraryPath, pluginsFolder, "GaussianSplatting.SplatBox.Relight.pdb");
            count += CopyDll(libraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Relight.Editor.dll");
            CopyDll(libraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Relight.Editor.pdb");

            if (count < 2)
            {
                EditorUtility.DisplayDialog("Relight Plugin Builder - Error",
                    "Relight DLLs not found. Ensure the Relight assemblies are compiled:\n" +
                    "GaussianSplatting.SplatBox.Relight.dll\n" +
                    "GaussianSplatting.SplatBox.Relight.Editor.dll\n\n" +
                    "Build the project or reimport the Relight scripts.",
                    "OK");
                return;
            }

            CreateDllMeta(pluginsFolder, "GaussianSplatting.SplatBox.Relight.dll", false);
            CreateDllMeta(pluginsEditorFolder, "GaussianSplatting.SplatBox.Relight.Editor.dll", true);
            count += 2;

            string relightShaderSrc = Path.Combine(packageRoot, "Resources", "RenderSplatsRelight.shader");
            if (!File.Exists(relightShaderSrc))
                relightShaderSrc = Path.Combine(packageRoot, "Shaders", "Relight", "RenderGaussianSplats.shader");
            if (File.Exists(relightShaderSrc))
            {
                string shaderText = File.ReadAllText(relightShaderSrc);
                string shadersCopy = shaderText.Replace("../Shaders/SplatBox.hlsl", "SplatBox.hlsl")
                    .Replace("../SplatBox.hlsl", "SplatBox.hlsl");
                File.WriteAllText(Path.Combine(shadersFolder, "RenderSplatsRelight.shader"), shadersCopy);
                File.WriteAllText(Path.Combine(resourcesFolder, "RenderSplatsRelight.shader"), shaderText);
                count += 2;
            }
            else
            {
                Debug.LogWarning("[Relight Plugin Builder] Relight shader not found.");
            }

            CreatePackageJson(PluginOutputPath);
            CreateRelightAssemblyDefinitions(pluginsFolder, pluginsEditorFolder);
            CreateRelightReadme(PluginOutputPath);
            count += 3;

            Debug.Log($"[Relight Plugin Builder] Built: {PluginOutputPath} ({count} items)");
            EditorUtility.DisplayDialog("Relight Plugin Builder",
                $"Relight plugin built.\n\nOutput: {PluginOutputPath}\n\n" +
                "Requires SplatBox plugin to be installed. Add via Package Manager (Add from disk) using package.json.",
                "OK");
            EditorUtility.RevealInFinder(PluginOutputPath);
        }

        [MenuItem("SplatBox/Open Relight Plugin Folder")]
        public static void OpenRelightPluginFolder()
        {
            if (Directory.Exists(PluginOutputPath))
                EditorUtility.RevealInFinder(PluginOutputPath);
            else
                EditorUtility.DisplayDialog("Relight Plugin Builder", "Build the Relight plugin first.", "OK");
        }

        static string GetPackageRoot()
        {
            string[] guids = AssetDatabase.FindAssets("SplatBoxPluginBuilder t:MonoScript");
            if (guids.Length > 0)
            {
                string path = Path.GetFullPath(AssetDatabase.GUIDToAssetPath(guids[0]));
                return Path.GetDirectoryName(Path.GetDirectoryName(path));
            }
            guids = AssetDatabase.FindAssets("package t:TextAsset", new[] { "Packages/com.gaussiansplatting.splatbox" });
            if (guids.Length > 0)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[0]);
                return Path.GetDirectoryName(Path.GetFullPath(path));
            }
            return null;
        }

        static void CreateDir(string path)
        {
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        }

        static int CopyDll(string sourceDir, string destDir, string fileName)
        {
            string src = Path.Combine(sourceDir, fileName);
            if (!File.Exists(src)) return 0;
            File.Copy(src, Path.Combine(destDir, fileName), true);
            return 1;
        }

        static void CreateDllMeta(string folder, string dllName, bool editorOnly)
        {
            string guid;
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] h = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes("Relight_" + dllName));
                guid = new Guid(h).ToString("N");
            }
            string platform = editorOnly
                ? @"  platformData:
  - first: { Any: }
    second: { enabled: 0, settings: {} }
  - first: { Editor: Editor }
    second: { enabled: 1, settings: { DefaultValueInitialized: true } }"
                : @"  platformData:
  - first: { Any: }
    second: { enabled: 1, settings: {} }
  - first: { Editor: Editor }
    second: { enabled: 1, settings: { DefaultValueInitialized: true } }";
            string meta = $@"fileFormatVersion: 2
guid: {guid}
PluginImporter:
  externalObjects: {{}}
  serializedVersion: 2
  iconMap: {{}}
  executionOrder: {{}}
  defineConstraints: []
  isPreloaded: 0
  isOverridable: 0
  isExplicitlyReferenced: 0
  validateReferences: 0
{platform}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
";
            File.WriteAllText(Path.Combine(folder, dllName + ".meta"), meta);
        }

        static void CreatePackageJson(string outputPath)
        {
            string json = $@"{{
    ""name"": ""{kPackageName}"",
    ""version"": ""1.0.0"",
    ""displayName"": ""SplatBox Relight Plugin"",
    ""description"": ""Relight add-on for SplatBox: custom lights and Render Splats Relight shader for Gaussian splats. Requires SplatBox."",
    ""unity"": ""6000.3"",
    ""dependencies"": {{
        ""{kSplatBoxPluginDep}"": ""1.0.0""
    }},
    ""keywords"": [ ""gaussian"", ""splatting"", ""relight"", ""lighting"", ""splatbox"" ],
    ""author"": {{ ""name"": ""SplatBox"" }}
}}";
            File.WriteAllText(Path.Combine(outputPath, "package.json"), json);
        }

        static void CreateRelightAssemblyDefinitions(string pluginsFolder, string editorFolder)
        {
            string runtimeAsmdef = @"{
    ""name"": ""GaussianSplatting.SplatBox.Relight.Plugin"",
    ""rootNamespace"": ""GaussianSplatting.Relight"",
    ""references"": [ ""GaussianSplatting.SplatBox.Plugin"" ],
    ""includePlatforms"": [],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": false,
    ""overrideReferences"": true,
    ""precompiledReferences"": [ ""GaussianSplatting.SplatBox.Relight.dll"" ],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""versionDefines"": [],
    ""noEngineReferences"": false
}";
            File.WriteAllText(Path.Combine(pluginsFolder, "GaussianSplatting.SplatBox.Relight.Plugin.asmdef"), runtimeAsmdef);

            string editorAsmdef = @"{
    ""name"": ""GaussianSplatting.SplatBox.Relight.Plugin.Editor"",
    ""rootNamespace"": ""GaussianSplatting.Relight.Editor"",
    ""references"": [
        ""GaussianSplatting.SplatBox.Plugin.Editor"",
        ""GaussianSplatting.SplatBox.Relight.Plugin""
    ],
    ""includePlatforms"": [ ""Editor"" ],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": false,
    ""overrideReferences"": true,
    ""precompiledReferences"": [ ""GaussianSplatting.SplatBox.Relight.Editor.dll"" ],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""versionDefines"": [],
    ""noEngineReferences"": false
}";
            File.WriteAllText(Path.Combine(editorFolder, "GaussianSplatting.SplatBox.Relight.Plugin.Editor.asmdef"), editorAsmdef);
        }

        static void CreateRelightReadme(string outputPath)
        {
            string readme = @"# SplatBox Relight Plugin

Separate add-on for SplatBox: custom lighting and the Relight shader for Gaussian splats.

**Requires:** SplatBox plugin must be installed first.

## Installation

1. Install SplatBox plugin (main package).
2. In Package Manager: Add package from disk → select this folder's `package.json`.
3. Or copy this folder into `Packages/` and ensure the main SplatBox plugin is present.

## Contents

- **Plugins/** – Relight runtime and editor DLLs (CustomLightManager, point/spot/directional/planar light components, custom editors, Relight Editor window).
- **Shaders/** – `RenderGaussianSplats.shader` (Gaussian Splatting/Render Splats Relight).

## Usage

- Menu: **SplatToolbox → Relight → Relight Editor**.
- In Splat Editor, use the Relight toggle and ""Use Relight shader"" so the renderer uses the Relight shader.
- Add **Custom Light Manager** to the scene, then add **Point**, **Spot**, **Directional**, or **Planar** lights as child objects. Move and rotate them in the Scene; edit properties (intensity, range, attenuation, etc.) in each light's inspector. Each light has a **Show gizmo** option; CustomLightManager has a global **Show Gizmos** checkbox.
- Directional: effect range (1–50 m) and shadow softness; direction from transform (preset can apply rotation). Point/spot/planar: range sliders, no negative values, reset-to-default button.
";
            File.WriteAllText(Path.Combine(outputPath, "README.md"), readme);
        }
    }
}
