// SPDX-License-Identifier: MIT
// Gaussian Splat Importer - Utility class for importing PLY and SPZ files

using System;
using System.IO;
using GaussianSplatting.Runtime;
using Unity.Collections;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor.Utils
{
    /// <summary>
    /// Static utility class for importing PLY and SPZ files to GaussianSplatAsset.
    /// Wraps the GaussianSplatAssetCreator functionality in a simple API.
    /// Supported formats:
    /// - PLY: Standard point cloud format from 3D Gaussian Splatting
    /// - SPZ: Niantic/Scaniverse compressed format (https://scaniverse.com/spz)
    /// </summary>
    public static class GaussianPlyImporter
    {
        /// <summary>
        /// Import a PLY file and create a GaussianSplatAsset.
        /// Uses the existing GaussianSplatAssetCreator infrastructure.
        /// </summary>
        public static GaussianSplatAsset ImportPlyFile(
            string plyPath,
            string outputFolder,
            string assetName,
            GaussianSplatAsset.VectorFormat posFormat,
            GaussianSplatAsset.VectorFormat scaleFormat,
            GaussianSplatAsset.ColorFormat colorFormat,
            GaussianSplatAsset.SHFormat shFormat,
            bool importCameras = true)
        {
            if (string.IsNullOrWhiteSpace(plyPath) || !File.Exists(plyPath))
            {
                Debug.LogError($"[PLY Importer] Source file not found: {plyPath}");
                return null;
            }

            if (string.IsNullOrWhiteSpace(outputFolder) || !outputFolder.StartsWith("Assets/"))
            {
                Debug.LogError($"[PLY Importer] Output folder must be within Assets: {outputFolder}");
                return null;
            }

            try
            {
                // Validate PLY file first
                PLYFileReader.ReadFileHeader(plyPath, out int vertexCount, out int vertexStride, out var attrNames);
                
                if (vertexCount <= 0)
                {
                    Debug.LogError($"[PLY Importer] Invalid PLY file - no vertices found");
                    return null;
                }

                Debug.Log($"[PLY Importer] Starting import of {Path.GetFileName(plyPath)}");
                Debug.Log($"[PLY Importer] Vertices: {vertexCount:N0}, Stride: {vertexStride} bytes, Attributes: {attrNames.Count}");

                // Create output directory
                Directory.CreateDirectory(outputFolder);

                // Create asset directly without opening a window
                var creator = ScriptableObject.CreateInstance<GaussianSplatAssetCreator>();
                var so = new SerializedObject(creator);
                so.FindProperty("m_InputFile").stringValue = plyPath;
                so.FindProperty("m_OutputFolder").stringValue = outputFolder;
                so.FindProperty("m_ImportCameras").boolValue = importCameras;
                so.FindProperty("m_Quality").intValue = 5; // Custom
                so.FindProperty("m_FormatPos").intValue = (int)posFormat;
                so.FindProperty("m_FormatScale").intValue = (int)scaleFormat;
                so.FindProperty("m_FormatColor").intValue = (int)colorFormat;
                so.FindProperty("m_FormatSH").intValue = (int)shFormat;
                so.ApplyModifiedPropertiesWithoutUndo();
                
                // Call internal method via reflection
                var method = typeof(GaussianSplatAssetCreator).GetMethod("CreateAssetInternal", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                string assetPath = method?.Invoke(creator, null) as string;
                
                ScriptableObject.DestroyImmediate(creator);

                if (!string.IsNullOrEmpty(assetPath))
                {
                    Debug.Log($"[PLY Importer] Successfully created asset: {assetPath}");
                    return AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(assetPath);
                }
                
                Debug.LogError("[PLY Importer] Asset creation failed");
                return null;
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                Debug.LogError($"[PLY Importer] Import failed: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Quick import with default balanced quality settings
        /// </summary>
        public static GaussianSplatAsset QuickImport(string plyPath, string outputFolder = null)
        {
            if (string.IsNullOrWhiteSpace(outputFolder))
                outputFolder = "Assets/GaussianAssets";

            string assetName = Path.GetFileNameWithoutExtension(plyPath);

            return ImportPlyFile(
                plyPath,
                outputFolder,
                assetName,
                GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.VectorFormat.Norm11,
                GaussianSplatAsset.ColorFormat.Norm8x4,
                GaussianSplatAsset.SHFormat.Norm6,
                true
            );
        }

        /// <summary>
        /// Get information about a PLY file without importing it
        /// </summary>
        public static PlyFileInfo GetPlyInfo(string plyPath)
        {
            var info = new PlyFileInfo { path = plyPath };
            
            if (string.IsNullOrWhiteSpace(plyPath) || !File.Exists(plyPath))
            {
                info.isValid = false;
                info.errorMessage = "File not found";
                return info;
            }

            try
            {
                PLYFileReader.ReadFileHeader(plyPath, out info.vertexCount, out info.vertexStride, out info.attributes);
                info.fileSize = new FileInfo(plyPath).Length;
                info.isValid = info.vertexCount > 0;
                
                // Check if cameras.json exists
                string dir = Path.GetDirectoryName(plyPath);
                info.hasCameras = File.Exists(Path.Combine(dir ?? "", "cameras.json")) ||
                                 File.Exists(Path.Combine(Path.GetDirectoryName(dir) ?? "", "cameras.json"));
            }
            catch (Exception ex)
            {
                info.isValid = false;
                info.errorMessage = ex.Message;
            }

            return info;
        }

        /// <summary>
        /// Information about a PLY file
        /// </summary>
        public struct PlyFileInfo
        {
            public string path;
            public bool isValid;
            public string errorMessage;
            public int vertexCount;
            public int vertexStride;
            public long fileSize;
            public bool hasCameras;
            public System.Collections.Generic.List<string> attributes;
        }
    }
}
