// SPDX-License-Identifier: MIT
// SPZ File Reader - Reads Niantic/Scaniverse .SPZ files
// Based on: https://github.com/nianticlabs/spz and https://scaniverse.com/spz

using System.IO;
using Unity.Collections;
using System.IO.Compression;
using GaussianSplatting.Runtime;
using Unity.Burst;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Editor.Utils
{
    /// <summary>
    /// Reads Niantic/Scaniverse .SPZ files for Gaussian Splatting
    /// SPZ is a compressed format used by Scaniverse app
    /// </summary>
    [BurstCompile]
    public static class SPZFileReader
    {
        struct SpzHeader
        {
            public uint magic;      // 0x5053474e "NGSP"
            public uint version;    // 2
            public uint numPoints;
            public uint sh_fracbits_flags_reserved;
        }

        /// <summary>
        /// Read only the header to get vertex count
        /// </summary>
        public static void ReadFileHeader(string filePath, out int vertexCount)
        {
            vertexCount = 0;
            if (!File.Exists(filePath))
                return;
            using var fs = File.OpenRead(filePath);
            using var gz = new GZipStream(fs, CompressionMode.Decompress);
            ReadHeaderImpl(filePath, gz, out vertexCount, out _, out _, out _);
        }

        static void ReadHeaderImpl(string filePath, Stream fs, out int vertexCount, out int shLevel, out int fractBits, out int flags)
        {
            var header = new NativeArray<SpzHeader>(1, Allocator.Temp);
            var readBytes = fs.Read(header.Reinterpret<byte>(16));
            if (readBytes != 16)
                throw new IOException($"SPZ {filePath} read error, failed to read header");

            if (header[0].magic != 0x5053474e)
                throw new IOException($"SPZ {filePath} read error, header magic unexpected {header[0].magic:X8} (expected 0x5053474E 'NGSP')");
            if (header[0].version != 2)
                throw new IOException($"SPZ {filePath} read error, header version unexpected {header[0].version} (expected 2)");

            vertexCount = (int)header[0].numPoints;
            shLevel = (int)(header[0].sh_fracbits_flags_reserved & 0xFF);
            fractBits = (int)((header[0].sh_fracbits_flags_reserved >> 8) & 0xFF);
            flags = (int)((header[0].sh_fracbits_flags_reserved >> 16) & 0xFF);
            
            header.Dispose();
        }

        static int SHCoeffsForLevel(int level)
        {
            return level switch
            {
                0 => 0,
                1 => 3,
                2 => 8,
                3 => 15,
                _ => 0
            };
        }

        /// <summary>
        /// AntiTranspose: convert from planar layout (better compression) to interleaved
        /// SPZ stores data as [all byte0][all byte1]... for compression
        /// We need [point0: all bytes][point1: all bytes]...
        /// </summary>
        static void AntiTranspose(NativeArray<byte> data, int numPoints, int bytesPerPoint)
        {
            if (numPoints <= 0 || bytesPerPoint <= 0) return;
            
            var temp = new NativeArray<byte>(data.Length, Allocator.Temp);
            for (int i = 0; i < numPoints; i++)
            {
                for (int j = 0; j < bytesPerPoint; j++)
                {
                    // Source: planar layout - byte j for all points stored contiguously
                    // Dest: interleaved layout - all bytes for point i stored contiguously
                    temp[i * bytesPerPoint + j] = data[j * numPoints + i];
                }
            }
            temp.CopyTo(data);
            temp.Dispose();
        }

        /// <summary>
        /// Read entire SPZ file and return splat data
        /// </summary>
        public static void ReadFile(string filePath, out NativeArray<GaussianSplatAssetCreator.InputSplatData> splats)
        {
            using var fs = File.OpenRead(filePath);
            using var gz = new GZipStream(fs, CompressionMode.Decompress);
            ReadHeaderImpl(filePath, gz, out var splatCount, out var shLevel, out var fractBits, out var flags);

            if (splatCount < 1 || splatCount > 10_000_000)
                throw new IOException($"SPZ {filePath} read error, out of range splat count {splatCount}");
            if (shLevel < 0 || shLevel > 3)
                throw new IOException($"SPZ {filePath} read error, out of range SH level {shLevel}");
            if (fractBits < 0 || fractBits > 24)
                throw new IOException($"SPZ {filePath} read error, out of range fractional bits {fractBits}");

            Debug.Log($"[SPZ Reader] {Path.GetFileName(filePath)}: {splatCount} splats, SH level {shLevel}, frac bits {fractBits}");

            // Allocate temporary storage for packed data
            // Positions: 9 bytes each (3 components × 24-bit signed fixed point)
            int shCoeffs = SHCoeffsForLevel(shLevel);
            NativeArray<byte> packedPos = new(splatCount * 9, Allocator.Persistent);
            NativeArray<byte> packedScale = new(splatCount * 3, Allocator.Persistent);
            NativeArray<byte> packedRot = new(splatCount * 3, Allocator.Persistent);
            NativeArray<byte> packedAlpha = new(splatCount, Allocator.Persistent);
            NativeArray<byte> packedCol = new(splatCount * 3, Allocator.Persistent);
            NativeArray<byte> packedSh = new(splatCount * 3 * shCoeffs, Allocator.Persistent);

            // Read file contents into temporaries (in SPZ file order)
            bool readOk = true;
            readOk &= gz.Read(packedPos) == packedPos.Length;
            readOk &= gz.Read(packedAlpha) == packedAlpha.Length;
            readOk &= gz.Read(packedCol) == packedCol.Length;
            readOk &= gz.Read(packedScale) == packedScale.Length;
            readOk &= gz.Read(packedRot) == packedRot.Length;
            readOk &= gz.Read(packedSh) == packedSh.Length;

            // Unpack into full splat data
            splats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(splatCount, Allocator.Persistent);
            float fractScale = 1.0f / (1 << fractBits);
            UnpackDataJob job = new UnpackDataJob
            {
                packedPos = packedPos,
                packedScale = packedScale,
                packedRot = packedRot,
                packedAlpha = packedAlpha,
                packedCol = packedCol,
                packedSh = packedSh,
                shCoeffs = shCoeffs,
                fractScale = fractScale,
                splats = splats
            };
            job.Schedule(splatCount, 4096).Complete();

            // Cleanup packed data
            packedPos.Dispose();
            packedScale.Dispose();
            packedRot.Dispose();
            packedAlpha.Dispose();
            packedCol.Dispose();
            packedSh.Dispose();

            if (!readOk)
            {
                splats.Dispose();
                throw new IOException($"SPZ {filePath} read error, file smaller than it should be");
            }
        }

        [BurstCompile]
        struct UnpackDataJob : IJobParallelFor
        {
            [NativeDisableParallelForRestriction] [ReadOnly] public NativeArray<byte> packedPos;
            [NativeDisableParallelForRestriction] [ReadOnly] public NativeArray<byte> packedScale;
            [NativeDisableParallelForRestriction] [ReadOnly] public NativeArray<byte> packedRot;
            [NativeDisableParallelForRestriction] [ReadOnly] public NativeArray<byte> packedAlpha;
            [NativeDisableParallelForRestriction] [ReadOnly] public NativeArray<byte> packedCol;
            [NativeDisableParallelForRestriction] [ReadOnly] public NativeArray<byte> packedSh;
            public float fractScale;
            public int shCoeffs;
            public NativeArray<GaussianSplatAssetCreator.InputSplatData> splats;

            public void Execute(int index)
            {
                var splat = splats[index];

                // Unpack position (3 components × 24-bit signed fixed point)
                splat.pos = new Vector3(
                    UnpackFloat(index * 3 + 0) * fractScale,
                    UnpackFloat(index * 3 + 1) * fractScale,
                    UnpackFloat(index * 3 + 2) * fractScale
                );

                // Unpack scale (stored as quantized log scale)
                // Note: LinearScale will be applied by GaussianSplatAssetCreator later
                splat.scale = new Vector3(
                    packedScale[index * 3 + 0],
                    packedScale[index * 3 + 1],
                    packedScale[index * 3 + 2]
                ) / 16.0f - new Vector3(10.0f, 10.0f, 10.0f);

                // Unpack rotation (xyz components mapped from 0-255 to -1 to 1, w computed)
                // SPZ assumes w is largest/positive. Match PLY quaternion order: (w, x, y, z) stored as Quaternion(x,y,z,w)
                Vector3 xyz = new Vector3(
                    packedRot[index * 3 + 0],
                    packedRot[index * 3 + 1],
                    packedRot[index * 3 + 2]
                ) * (1.0f / 127.5f) - new Vector3(1, 1, 1);
                float w = math.sqrt(math.max(0.0f, 1.0f - xyz.sqrMagnitude));
                var q = new float4(w, xyz.x, xyz.y, xyz.z);
                var qq = math.normalize(q);
                // Store as (w, x, y, z) to match PLY format that LinearizeData expects
                splat.rot = new Quaternion(qq.x, qq.y, qq.z, qq.w);

                // Unpack opacity - SPZ stores sigmoid-transformed value, need inverse sigmoid
                // to get raw value that asset creator expects (it will apply sigmoid later)
                float sigmoidAlpha = packedAlpha[index] / 255.0f;
                sigmoidAlpha = math.clamp(sigmoidAlpha, 0.001f, 0.999f); // Avoid log(0) or log(inf)
                splat.opacity = math.log(sigmoidAlpha / (1.0f - sigmoidAlpha)); // Inverse sigmoid

                // Unpack color (DC0 SH coefficient)
                // Note: SH0ToColor will be applied by GaussianSplatAssetCreator later
                Vector3 col = new Vector3(
                    packedCol[index * 3 + 0],
                    packedCol[index * 3 + 1],
                    packedCol[index * 3 + 2]
                );
                col = col / 255.0f - new Vector3(0.5f, 0.5f, 0.5f);
                col /= 0.15f;
                splat.dc0 = col;

                // Unpack SH coefficients
                if (shCoeffs > 0)
                {
                    int shIdx = index * shCoeffs * 3;
                    splat.sh1 = UnpackSH(shIdx); shIdx += 3;
                    if (shCoeffs > 1) { splat.sh2 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 2) { splat.sh3 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 3) { splat.sh4 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 4) { splat.sh5 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 5) { splat.sh6 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 6) { splat.sh7 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 7) { splat.sh8 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 8) { splat.sh9 = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 9) { splat.shA = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 10) { splat.shB = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 11) { splat.shC = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 12) { splat.shD = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 13) { splat.shE = UnpackSH(shIdx); shIdx += 3; }
                    if (shCoeffs > 14) { splat.shF = UnpackSH(shIdx); }
                }

                // Normal is not stored in SPZ, set to zero
                splat.nor = Vector3.zero;

                splats[index] = splat;
            }

            // Unpack 24-bit signed fixed point value
            float UnpackFloat(int idx)
            {
                int fx = packedPos[idx * 3 + 0] | (packedPos[idx * 3 + 1] << 8) | (packedPos[idx * 3 + 2] << 16);
                fx |= (fx & 0x800000) != 0 ? -16777216 : 0; // sign extension with 0xff000000
                return fx;
            }

            Vector3 UnpackSH(int idx)
            {
                if (idx + 2 >= packedSh.Length) return Vector3.zero;
                Vector3 sh = new Vector3(packedSh[idx], packedSh[idx + 1], packedSh[idx + 2]) - new Vector3(128.0f, 128.0f, 128.0f);
                sh /= 128.0f;
                return sh;
            }
        }
    }
}
