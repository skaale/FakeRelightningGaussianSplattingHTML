// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    using InputSplatData = GaussianSplatAssetCreator.InputSplatData;

    /// <summary>
    /// Spark-inspired Quick LoD tree builder (voxel hierarchy, base 1.5).
    /// </summary>
    public static class GaussianSplatLodBuilder
    {
        const float kDefaultLodBase = 1.5f;

        struct BuildNode
        {
            public InputSplatData splat;
            public List<int> children;
            public int parent;
            public bool merged;
        }

        public static Dictionary<Vector3Int, List<int>> PartitionByGrid(
            NativeArray<InputSplatData> splats,
            float cellSize,
            float3 worldMin)
        {
            var buckets = new Dictionary<Vector3Int, List<int>>();
            for (int i = 0; i < splats.Length; i++)
            {
                float3 p = splats[i].pos;
                var coord = new Vector3Int(
                    Mathf.FloorToInt((p.x - worldMin.x) / cellSize),
                    Mathf.FloorToInt((p.y - worldMin.y) / cellSize),
                    Mathf.FloorToInt((p.z - worldMin.z) / cellSize));
                if (!buckets.TryGetValue(coord, out var list))
                {
                    list = new List<int>();
                    buckets[coord] = list;
                }
                list.Add(i);
            }
            return buckets;
        }

        /// <summary>
        /// Picks a grid cell size so occupied cells land near <paramref name="targetOccupiedCells"/>.
        /// LoD page count is mostly "how many 3D cells have any splat", not tree depth — a 28 m cell
        /// on a large or cm-scaled capture creates thousands of tiny pages.
        /// </summary>
        public static float ChoosePageCellSize(
            NativeArray<InputSplatData> splats,
            float3 worldMin,
            float3 worldMax,
            int targetOccupiedCells)
        {
            targetOccupiedCells = Mathf.Clamp(targetOccupiedCells, 16, 1024);
            float3 extent = math.max(worldMax - worldMin, new float3(1e-3f));
            float maxExtent = math.cmax(extent);
            if (maxExtent < 1e-3f || !splats.IsCreated || splats.Length == 0)
                return 64f;

            // Volume guess assuming moderate fill, then binary-search on occupied cell count.
            float volume = math.max(extent.x * extent.y * extent.z, 1e-3f);
            float lo = math.max(maxExtent / 512f, 0.5f);
            float hi = math.max(maxExtent, lo * 2f);
            float guess = Mathf.Pow(volume / targetOccupiedCells, 1f / 3f);
            guess = Mathf.Clamp(guess, lo, hi);

            float best = guess;
            int bestErr = int.MaxValue;
            for (int iter = 0; iter < 12; iter++)
            {
                float mid = iter == 0 ? guess : 0.5f * (lo + hi);
                int occupied = PartitionByGrid(splats, mid, worldMin).Count;
                int err = Mathf.Abs(occupied - targetOccupiedCells);
                if (err < bestErr)
                {
                    bestErr = err;
                    best = mid;
                }

                // Too many occupied cells → cell too small → raise mid.
                if (occupied > targetOccupiedCells)
                    lo = mid;
                else
                    hi = mid;
            }

            return Mathf.Max(0.5f, best);
        }

        /// <summary>
        /// Grid partition followed by median splits of any cell holding more than
        /// <paramref name="maxSplatsPerPage"/> splats. A dense model can land entirely inside one
        /// grid cell, and a single page defeats streaming: the whole model has to be resident at
        /// once and the coarse/detail tiers have nothing to choose between.
        /// </summary>
        public static List<(Vector3Int coord, List<int> indices)> PartitionToPages(
            NativeArray<InputSplatData> splats,
            float cellSize,
            float3 worldMin,
            int maxSplatsPerPage)
        {
            maxSplatsPerPage = Mathf.Max(4096, maxSplatsPerPage);
            var buckets = PartitionByGrid(splats, cellSize, worldMin);
            var pages = new List<(Vector3Int, List<int>)>();
            foreach (var kv in buckets)
                SplitToSize(splats, kv.Key, kv.Value, maxSplatsPerPage, pages);
            return pages;
        }

        static void SplitToSize(
            NativeArray<InputSplatData> splats,
            Vector3Int coord,
            List<int> indices,
            int maxSplats,
            List<(Vector3Int, List<int>)> output)
        {
            if (indices.Count <= maxSplats)
            {
                output.Add((coord, indices));
                return;
            }

            float3 bmin = new float3(float.MaxValue);
            float3 bmax = new float3(float.MinValue);
            for (int i = 0; i < indices.Count; i++)
            {
                float3 p = splats[indices[i]].pos;
                bmin = math.min(bmin, p);
                bmax = math.max(bmax, p);
            }

            // Median split along the longest axis keeps the halves balanced, which in turn keeps
            // page sizes even — important because the renderer's detail slots are uniformly sized.
            float3 size = bmax - bmin;
            int axis = size.x >= size.y && size.x >= size.z ? 0 : (size.y >= size.z ? 1 : 2);
            indices.Sort((a, b) => splats[a].pos[axis].CompareTo(splats[b].pos[axis]));

            int mid = indices.Count / 2;
            var upper = indices.GetRange(mid, indices.Count - mid);
            indices.RemoveRange(mid, indices.Count - mid);
            SplitToSize(splats, coord, indices, maxSplats, output);
            SplitToSize(splats, coord, upper, maxSplats, output);
        }

        public static NativeArray<InputSplatData> ExtractSubset(NativeArray<InputSplatData> all, List<int> indices)
        {
            var subset = new NativeArray<InputSplatData>(indices.Count, Allocator.Temp);
            for (int i = 0; i < indices.Count; i++)
                subset[i] = all[indices[i]];
            return subset;
        }

        public static (NativeArray<InputSplatData> splats, byte[] lodTreeBytes, int lodNodeCount, int leafCount)
            BuildQuickLod(NativeArray<InputSplatData> sourceSplats, float lodBase = kDefaultLodBase)
        {
            if (!sourceSplats.IsCreated || sourceSplats.Length == 0)
                return (default, Array.Empty<byte>(), 0, 0);

            var nodes = new List<BuildNode>(sourceSplats.Length * 2);
            for (int i = 0; i < sourceSplats.Length; i++)
            {
                nodes.Add(new BuildNode
                {
                    splat = sourceSplats[i],
                    children = new List<int>(),
                    parent = -1,
                    merged = false
                });
            }

            float minFeature = float.MaxValue;
            float3 bmin = new float3(float.MaxValue);
            float3 bmax = new float3(float.MinValue);
            for (int i = 0; i < nodes.Count; i++)
            {
                float3 s = LinearScaleOf(nodes[i].splat);
                float feature = 2f * math.max(s.x, math.max(s.y, s.z));
                minFeature = math.min(minFeature, math.max(feature, 1e-4f));
                bmin = math.min(bmin, nodes[i].splat.pos);
                bmax = math.max(bmax, nodes[i].splat.pos);
            }

            float3 center = (bmin + bmax) * 0.5f;
            float maxExtent = math.cmax(bmax - bmin);
            float logBase = math.log(lodBase);
            int minLevel = Mathf.FloorToInt(math.log(math.max(minFeature, 1e-3f)) / logBase);
            int maxLevel = Mathf.CeilToInt(math.log(math.max(maxExtent, 1e-2f)) / logBase) + 2;

            var active = new List<int>(nodes.Count);
            for (int i = 0; i < nodes.Count; i++)
                active.Add(i);

            for (int level = minLevel; level <= maxLevel; level++)
            {
                float step = math.pow(lodBase, level);
                var voxelMap = new Dictionary<long, List<int>>();
                var nextActive = new List<int>();

                foreach (int idx in active)
                {
                    float3 p = nodes[idx].splat.pos;
                    int3 cell = (int3)math.floor((p - center) / step);
                    long key = PackCell(cell);
                    if (!voxelMap.TryGetValue(key, out var group))
                    {
                        group = new List<int>();
                        voxelMap[key] = group;
                    }
                    group.Add(idx);
                }

                foreach (var kv in voxelMap)
                {
                    var group = kv.Value;
                    if (group.Count == 1)
                    {
                        nextActive.Add(group[0]);
                        continue;
                    }

                    var childSplats = new List<InputSplatData>(group.Count);
                    foreach (int ci in group)
                        childSplats.Add(nodes[ci].splat);
                    InputSplatData merged = MergeSplats(childSplats);
                    int parentIdx = nodes.Count;
                    nodes.Add(new BuildNode
                    {
                        splat = merged,
                        children = new List<int>(group),
                        parent = -1,
                        merged = true
                    });
                    foreach (int ci in group)
                    {
                        var n = nodes[ci];
                        n.parent = parentIdx;
                        nodes[ci] = n;
                    }
                    nextActive.Add(parentIdx);
                }

                active = nextActive;

                float footprint = step * 2f;
                if (footprint >= maxExtent * 0.5f && active.Count <= 8)
                    break;
            }

            if (active.Count > 1)
            {
                var childSplats = new List<InputSplatData>(active.Count);
                var childIdx = new List<int>(active);
                foreach (int ai in active)
                    childSplats.Add(nodes[ai].splat);
                InputSplatData rootSplat = MergeSplats(childSplats);
                int rootIdx = nodes.Count;
                nodes.Add(new BuildNode
                {
                    splat = rootSplat,
                    children = new List<int>(childIdx),
                    parent = -1,
                    merged = true
                });
                foreach (int ci in childIdx)
                {
                    var n = nodes[ci];
                    n.parent = rootIdx;
                    nodes[ci] = n;
                }
                active = new List<int> { rootIdx };
            }

            int rootIndex = active[0];
            var order = new List<int>();
            LinearizeTree(nodes, rootIndex, order);

            var outSplats = new NativeArray<InputSplatData>(order.Count, Allocator.Persistent);
            var treeNodes = new LodTreeNode[order.Count];
            var oldToNew = new Dictionary<int, int>();
            for (int i = 0; i < order.Count; i++)
                oldToNew[order[i]] = i;

            var featureSizes = ComputeSubtreeExtents(nodes, order);

            int leafCount = 0;
            for (int i = 0; i < order.Count; i++)
            {
                int oldIdx = order[i];
                outSplats[i] = nodes[oldIdx].splat;
                var bn = nodes[oldIdx];
                float feature = featureSizes[oldIdx];

                uint childStart = 0;
                ushort childCount = 0;
                if (bn.children != null && bn.children.Count > 0)
                {
                    childCount = (ushort)math.min(bn.children.Count, ushort.MaxValue);
                    childStart = (uint)oldToNew[bn.children[0]];
                }
                else
                    leafCount++;

                treeNodes[i] = new LodTreeNode
                {
                    center = bn.splat.pos,
                    featureSize = feature,
                    childCount = childCount,
                    childStart = childStart,
                    flags = 0
                };
            }

            byte[] treeBytes = LodTreeNode.ToBytes(treeNodes);
            return (outSplats, treeBytes, treeNodes.Length, leafCount);
        }

        /// <summary>
        /// featureSize drives LoD screen-size tests, so an internal node must report the spatial
        /// diameter of everything it stands in for, not the averaged scale of its merged Gaussian.
        /// Pre-order puts every parent before its children, so one reverse pass resolves the tree.
        /// </summary>
        static float[] ComputeSubtreeExtents(List<BuildNode> nodes, List<int> order)
        {
            var feature = new float[nodes.Count];
            for (int i = 0; i < nodes.Count; i++)
            {
                float3 sc = LinearScaleOf(nodes[i].splat);
                feature[i] = math.max(2f * math.cmax(sc), 1e-4f);
            }

            for (int k = order.Count - 1; k >= 0; k--)
            {
                int idx = order[k];
                var bn = nodes[idx];
                if (bn.children == null || bn.children.Count == 0)
                    continue;

                float3 center = bn.splat.pos;
                float radius = feature[idx] * 0.5f;
                foreach (int ci in bn.children)
                    radius = math.max(radius, math.distance(center, (float3)nodes[ci].splat.pos) + feature[ci] * 0.5f);
                feature[idx] = math.max(radius * 2f, 1e-4f);
            }

            return feature;
        }

        /// <summary>
        /// Level-order layout. Siblings end up contiguous (so childStart/childCount address them
        /// directly) and every prefix of the array is a complete coarse LoD level, which is what
        /// lets the streamer upload a low-detail version of a page as one contiguous range.
        /// </summary>
        static void LinearizeTree(List<BuildNode> nodes, int root, List<int> order)
        {
            order.Add(root);
            for (int head = 0; head < order.Count; head++)
            {
                var bn = nodes[order[head]];
                if (bn.children == null)
                    continue;
                foreach (int c in bn.children)
                    order.Add(c);
            }
        }

        static InputSplatData MergeSplats(List<InputSplatData> splats)
        {
            float weightSum = 0f;
            float3 pos = 0;
            float3 dc0 = 0;

            foreach (var s in splats)
            {
                float w = MergeWeight(s);
                weightSum += w;
                pos += (float3)s.pos * w;
                dc0 += (float3)s.dc0 * w;
            }

            if (weightSum <= 0f)
                weightSum = 1f;

            pos /= weightSum;
            dc0 /= weightSum;

            // The merged Gaussian stands in for the whole cluster, so its covariance is the sum of
            // the children's own covariances and their positional spread (parallel axis theorem).
            // The off-diagonal terms have to be kept: without them a tilted flat cluster inflates
            // into its axis-aligned bounding ellipsoid, which is what turns a wall into a round blob.
            float3x3 cov = float3x3.zero;
            float childArea = 0f;
            foreach (var s in splats)
            {
                float w = MergeWeight(s);
                float3 sc = LinearScaleOf(s);
                float3x3 rot = RotationOf(s);
                float3x3 childCov = math.mul(math.mul(rot, Diagonal(sc * sc)), math.transpose(rot));
                float3 d = (float3)s.pos - pos;
                cov += w * (childCov + OuterProduct(d, d));
                childArea += LinearOpacityOf(s) * ProjectedArea(sc);
            }
            cov *= 1f / weightSum;

            JacobiEigenSymmetric(cov, out float3 variance, out float3x3 basis);
            float3 sigma = math.max(math.sqrt(math.max(variance, 0f)), new float3(1e-4f));

            // One big Gaussian replaces many small ones, so opacity has to preserve the coverage they
            // added up to. Measuring that as projected area keeps surfaces solid while genuinely
            // volumetric clusters fade out instead of becoming fog.
            float opacity = math.clamp(childArea / ProjectedArea(sigma), 0.04f, 0.98f);

            var result = splats[0];
            result.pos = pos;
            result.dc0 = dc0;
            // Back to importer space: GaussianSplatAssetCreator applies exp/sigmoid/swizzle later.
            result.scale = math.log(sigma);
            result.opacity = math.log(opacity / (1f - opacity));
            result.rot = RawRotation(basis);
            return result;
        }

        // BuildQuickLod runs before GaussianSplatAssetCreator.LinearizeData, so a splat's scale is
        // still a log scale, its opacity a logit, and its rotation laid out as (w,x,y,z). Merging has
        // to convert into linear space and back, or the exp() applied later turns a merged sigma of
        // a few log units into tens of metres.
        static float3 LinearScaleOf(in InputSplatData s) => GaussianUtils.LinearScale((float3)s.scale);

        static float LinearOpacityOf(in InputSplatData s) => GaussianUtils.Sigmoid(s.opacity);

        /// <summary>Opacity-weighted volume: how much of the merged Gaussian each child accounts for.</summary>
        static float MergeWeight(in InputSplatData s)
        {
            float3 sc = LinearScaleOf(s);
            return math.max(1e-12f, LinearOpacityOf(s) * sc.x * sc.y * sc.z);
        }

        static float3x3 RotationOf(in InputSplatData s)
        {
            var r = s.rot;
            var xyzw = new float4(r.y, r.z, r.w, r.x);
            if (math.lengthsq(xyzw) < 1e-12f)
                return float3x3.identity;
            return new float3x3(math.normalize(new quaternion(xyzw)));
        }

        static Quaternion RawRotation(float3x3 basis)
        {
            // A reflection is not a rotation; flipping one axis keeps the same ellipsoid.
            if (math.determinant(basis) < 0f)
                basis.c2 = -basis.c2;
            float4 q = math.normalize(new quaternion(basis)).value;
            return new Quaternion(q.w, q.x, q.y, q.z);
        }

        static float3x3 Diagonal(float3 d) => new float3x3(
            new float3(d.x, 0f, 0f), new float3(0f, d.y, 0f), new float3(0f, 0f, d.z));

        static float3x3 OuterProduct(float3 a, float3 b) => new float3x3(a * b.x, a * b.y, a * b.z);

        /// <summary>Area of the Gaussian's widest cross-section, using its two largest axes.</summary>
        static float ProjectedArea(float3 sigma)
        {
            float largest = math.cmax(sigma);
            float smallest = math.cmin(sigma);
            float middle = math.csum(sigma) - largest - smallest;
            return math.max(1e-12f, largest * middle);
        }

        /// <summary>
        /// Eigen-decomposition of a symmetric 3x3 by cyclic Jacobi rotations: returns the variances
        /// along the principal axes and the axes themselves as the columns of <paramref name="basis"/>.
        /// </summary>
        static void JacobiEigenSymmetric(float3x3 m, out float3 variance, out float3x3 basis)
        {
            float a00 = m.c0.x, a11 = m.c1.y, a22 = m.c2.z;
            float a01 = m.c1.x, a02 = m.c2.x, a12 = m.c2.y;
            float3 v0 = new float3(1f, 0f, 0f);
            float3 v1 = new float3(0f, 1f, 0f);
            float3 v2 = new float3(0f, 0f, 1f);

            float scale = math.max(math.abs(a00) + math.abs(a11) + math.abs(a22), 1e-20f);
            for (int sweep = 0; sweep < 6; sweep++)
            {
                if (math.abs(a01) + math.abs(a02) + math.abs(a12) < 1e-9f * scale)
                    break;
                JacobiRotate(ref a00, ref a11, ref a01, ref a02, ref a12, ref v0, ref v1);
                JacobiRotate(ref a00, ref a22, ref a02, ref a01, ref a12, ref v0, ref v2);
                JacobiRotate(ref a11, ref a22, ref a12, ref a01, ref a02, ref v1, ref v2);
            }

            variance = new float3(a00, a11, a22);
            basis = new float3x3(
                math.normalizesafe(v0, new float3(1f, 0f, 0f)),
                math.normalizesafe(v1, new float3(0f, 1f, 0f)),
                math.normalizesafe(v2, new float3(0f, 0f, 1f)));
        }

        /// <summary>
        /// One Jacobi rotation in the (p,q) plane, zeroing <paramref name="apq"/>. The remaining row
        /// r is carried in apr/aqr, and vp/vq accumulate the eigenvector basis.
        /// </summary>
        static void JacobiRotate(
            ref float app, ref float aqq, ref float apq, ref float apr, ref float aqr,
            ref float3 vp, ref float3 vq)
        {
            if (math.abs(apq) < 1e-20f)
                return;

            float theta = (aqq - app) / (2f * apq);
            float t = (theta >= 0f ? 1f : -1f) / (math.abs(theta) + math.sqrt(theta * theta + 1f));
            float c = math.rsqrt(t * t + 1f);
            float s = t * c;

            app -= t * apq;
            aqq += t * apq;
            apq = 0f;

            float pr = c * apr - s * aqr;
            float qr = s * apr + c * aqr;
            apr = pr;
            aqr = qr;

            float3 np = c * vp - s * vq;
            float3 nq = s * vp + c * vq;
            vp = np;
            vq = nq;
        }

        static long PackCell(int3 cell)
        {
            unchecked
            {
                return ((long)(cell.x & 0x1FFFFF) << 42) |
                       ((long)(cell.y & 0x1FFFFF) << 21) |
                       (long)(cell.z & 0x1FFFFF);
            }
        }
    }
}
