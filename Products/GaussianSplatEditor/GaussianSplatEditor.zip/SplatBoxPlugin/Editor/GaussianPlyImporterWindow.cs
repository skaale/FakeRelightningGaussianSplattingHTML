// SPDX-License-Identifier: MIT
// Gaussian Splat Importer - Editor window for importing PLY and SPZ files

using System;
using System.IO;
using GaussianSplatting.Editor.Utils;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    public class GaussianPlyImporterWindow : EditorWindow
    {
        #region Constants
        const string kPrefQuality = "GS.Importer.Quality";
        const string kPrefOutputFolder = "GS.Importer.OutputFolder";
        #endregion

        #region Enums
        public enum ImportQuality
        {
            Lossless = 0,
            HighQuality = 1,
            Balanced = 2,
            Optimized = 3,
            Compressed = 4
        }
        
        public enum SourceFormat
        {
            Unknown,
            PLY,
            SPZ
        }
        #endregion

        #region Serialized Fields
        [SerializeField] string m_SourcePath;
        [SerializeField] string m_DestinationFolder = "Assets/GaussianAssets";
        [SerializeField] string m_AssetName;
        [SerializeField] ImportQuality m_ImportQuality = ImportQuality.Balanced;
        [SerializeField] bool m_IncludeCameras = true;
        #endregion

        #region Private Fields
        readonly FilePickerControl m_FilePicker = new();
        string m_StatusMessage;
        MessageType m_StatusType = MessageType.None;
        int m_CachedSplatCount;
        long m_CachedFileSize;
        string m_CachedSourcePath;
        SourceFormat m_DetectedFormat = SourceFormat.Unknown;
        Vector2 m_ScrollPos;
        
        // Legacy compatibility
        [SerializeField] string m_SourcePlyPath;
        #endregion

        #region Menu Items
        [MenuItem("SplatToolbox/Import PLY", false, 10)]
        public static void ShowImporter()
        {
            var window = GetWindow<GaussianPlyImporterWindow>(false, "Splat Importer", true);
            window.minSize = new Vector2(400, 450);
            window.Show();
        }

        public static void ShowImporterWithPath(string sourcePath)
        {
            var window = GetWindow<GaussianPlyImporterWindow>(false, "Splat Importer", true);
            window.minSize = new Vector2(400, 450);
            window.m_SourcePath = sourcePath;
            window.m_AssetName = Path.GetFileNameWithoutExtension(sourcePath);
            window.RefreshSourceInfo();
            window.Show();
        }
        #endregion

        #region Unity Callbacks
        void Awake()
        {
            m_ImportQuality = (ImportQuality)EditorPrefs.GetInt(kPrefQuality, (int)ImportQuality.Balanced);
            m_DestinationFolder = EditorPrefs.GetString(kPrefOutputFolder, "Assets/GaussianAssets");
        }

        void OnGUI()
        {
            m_ScrollPos = EditorGUILayout.BeginScrollView(m_ScrollPos);
            
            DrawHeader();
            EditorGUILayout.Space(10);
            DrawSourceSection();
            EditorGUILayout.Space(10);
            DrawDestinationSection();
            EditorGUILayout.Space(10);
            DrawQualitySection();
            EditorGUILayout.Space(10);
            DrawInfoSection();
            EditorGUILayout.Space(20);
            DrawImportButton();
            DrawStatusMessage();
            
            EditorGUILayout.EndScrollView();
        }
        #endregion

        #region GUI Drawing
        void DrawHeader()
        {
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            
            var headerStyle = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 18,
                alignment = TextAnchor.MiddleCenter
            };
            GUILayout.Label("Gaussian Splat Importer", headerStyle);
            
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space(5);
            var subtitleStyle = new GUIStyle(EditorStyles.centeredGreyMiniLabel);
            EditorGUILayout.LabelField("Import PLY or SPZ files to GaussianSplatAsset", subtitleStyle);
        }

        void DrawSourceSection()
        {
            EditorGUILayout.LabelField("Source", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            
            // Support both PLY and SPZ files
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.PrefixLabel("Source File");
            
            string currentPath = m_SourcePath ?? m_SourcePlyPath ?? "";
            string newPath = EditorGUILayout.TextField(currentPath);
            
            if (GUILayout.Button("Browse...", GUILayout.Width(70)))
            {
                string selected = EditorUtility.OpenFilePanelWithFilters(
                    "Select Gaussian Splat File",
                    string.IsNullOrEmpty(currentPath) ? "" : Path.GetDirectoryName(currentPath),
                    new[] { "Gaussian Splat Files", "ply,spz", "PLY Files", "ply", "SPZ Files", "spz" }
                );
                if (!string.IsNullOrEmpty(selected))
                {
                    newPath = selected;
                }
            }
            EditorGUILayout.EndHorizontal();
            
            if (newPath != currentPath)
            {
                m_SourcePath = newPath;
                m_SourcePlyPath = newPath; // Legacy compatibility
                if (!string.IsNullOrWhiteSpace(newPath) && string.IsNullOrWhiteSpace(m_AssetName))
                {
                    m_AssetName = Path.GetFileNameWithoutExtension(newPath);
                }
                RefreshSourceInfo();
            }
            
            // Show detected format
            if (m_DetectedFormat != SourceFormat.Unknown)
            {
                EditorGUILayout.LabelField("Format", m_DetectedFormat.ToString(), EditorStyles.boldLabel);
            }
            
            m_IncludeCameras = EditorGUILayout.Toggle(new GUIContent("Import Cameras", "Import camera positions from cameras.json if present (PLY only)"), m_IncludeCameras);
            
            EditorGUI.indentLevel--;
        }

        void DrawDestinationSection()
        {
            EditorGUILayout.LabelField("Destination", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            
            var rect = EditorGUILayout.GetControlRect(true);
            string newFolder = m_FilePicker.PathFieldGUI(rect, new GUIContent("Output Folder"), m_DestinationFolder, null, "GS_OutputFolder");
            
            if (newFolder != m_DestinationFolder)
            {
                m_DestinationFolder = newFolder;
                EditorPrefs.SetString(kPrefOutputFolder, m_DestinationFolder);
            }
            
            m_AssetName = EditorGUILayout.TextField(new GUIContent("Asset Name", "Name for the created asset"), m_AssetName);
            
            EditorGUI.indentLevel--;
        }

        void DrawQualitySection()
        {
            EditorGUILayout.LabelField("Quality Settings", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            
            var newQuality = (ImportQuality)EditorGUILayout.EnumPopup(new GUIContent("Quality Preset", "Preset quality levels"), m_ImportQuality);
            if (newQuality != m_ImportQuality)
            {
                m_ImportQuality = newQuality;
                EditorPrefs.SetInt(kPrefQuality, (int)m_ImportQuality);
            }
            
            // Show quality description
            string qualityDesc = m_ImportQuality switch
            {
                ImportQuality.Lossless => "Full precision, largest file size, editable",
                ImportQuality.HighQuality => "High quality, ~3x compression",
                ImportQuality.Balanced => "Good quality, ~5x compression",
                ImportQuality.Optimized => "Optimized size, ~14x compression",
                ImportQuality.Compressed => "Maximum compression, ~18x smaller",
                _ => ""
            };
            EditorGUILayout.HelpBox(qualityDesc, MessageType.None);
            
            EditorGUI.indentLevel--;
        }

        void DrawInfoSection()
        {
            if (m_CachedSplatCount <= 0) return;
            
            EditorGUILayout.LabelField("File Information", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            
            EditorGUILayout.LabelField("Splat Count", $"{m_CachedSplatCount:N0}");
            EditorGUILayout.LabelField("Source Size", EditorUtility.FormatBytes(m_CachedFileSize));
            
            // Estimate output size based on quality
            float compressionRatio = m_ImportQuality switch
            {
                ImportQuality.Lossless => 1.05f,
                ImportQuality.HighQuality => 2.94f,
                ImportQuality.Balanced => 5.14f,
                ImportQuality.Optimized => 14.01f,
                ImportQuality.Compressed => 18.62f,
                _ => 1f
            };
            
            long estimatedSize = (long)(m_CachedFileSize / compressionRatio);
            EditorGUILayout.LabelField("Estimated Output", EditorUtility.FormatBytes(estimatedSize));
            
            EditorGUI.indentLevel--;
        }

        void DrawImportButton()
        {
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            
            GUI.backgroundColor = new Color(0.3f, 0.7f, 0.4f);
            bool canImport = !string.IsNullOrWhiteSpace(m_SourcePlyPath) && 
                            !string.IsNullOrWhiteSpace(m_DestinationFolder) &&
                            !string.IsNullOrWhiteSpace(m_AssetName);
            
            EditorGUI.BeginDisabledGroup(!canImport);
            if (GUILayout.Button("Import PLY to Asset", GUILayout.Width(200), GUILayout.Height(35)))
            {
                ExecuteImport();
            }
            EditorGUI.EndDisabledGroup();
            GUI.backgroundColor = Color.white;
            
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            
            // EditorGUILayout.Space(10);
            
            // // Alternative: Open advanced creator
            // EditorGUILayout.BeginHorizontal();
            // GUILayout.FlexibleSpace();
            // if (GUILayout.Button("Open Advanced Creator (Custom Formats)...", GUILayout.Width(250)))
            // {
            //     GaussianSplatAssetCreator.Init();
            // }
            // GUILayout.FlexibleSpace();
            // EditorGUILayout.EndHorizontal();
        }

        void DrawStatusMessage()
        {
            if (!string.IsNullOrWhiteSpace(m_StatusMessage))
            {
                EditorGUILayout.Space(10);
                EditorGUILayout.HelpBox(m_StatusMessage, m_StatusType);
            }
        }
        #endregion

        #region Import Logic
        
        SourceFormat DetectFormat(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return SourceFormat.Unknown;
            
            string ext = Path.GetExtension(path).ToLowerInvariant();
            return ext switch
            {
                ".ply" => SourceFormat.PLY,
                ".spz" => SourceFormat.SPZ,
                _ => SourceFormat.Unknown
            };
        }
        
        void RefreshSourceInfo()
        {
            string currentPath = m_SourcePath ?? m_SourcePlyPath;
            if (currentPath == m_CachedSourcePath) return;
            
            m_CachedSourcePath = currentPath;
            m_CachedSplatCount = 0;
            m_CachedFileSize = 0;
            m_DetectedFormat = SourceFormat.Unknown;
            
            if (string.IsNullOrWhiteSpace(currentPath) || !File.Exists(currentPath))
                return;
            
            m_DetectedFormat = DetectFormat(currentPath);
            
            try
            {
                switch (m_DetectedFormat)
                {
                    case SourceFormat.PLY:
                        PLYFileReader.ReadFileHeader(currentPath, out m_CachedSplatCount, out _, out _);
                        break;
                    case SourceFormat.SPZ:
                        SPZFileReader.ReadFileHeader(currentPath, out m_CachedSplatCount);
                        break;
                    default:
                        m_StatusMessage = "Unsupported file format. Use .ply or .spz files.";
                        m_StatusType = MessageType.Warning;
                        return;
                }
                m_CachedFileSize = new FileInfo(currentPath).Length;
                m_StatusMessage = null;
            }
            catch (Exception ex)
            {
                m_StatusMessage = $"Error reading file: {ex.Message}";
                m_StatusType = MessageType.Error;
            }
        }
        
        // Legacy compatibility
        void RefreshPlyInfo() => RefreshSourceInfo();

        void ExecuteImport()
        {
            m_StatusMessage = null;
            m_StatusType = MessageType.None;
            
            // Validate inputs
            if (!ValidateImportSettings())
                return;
            
            string sourcePath = m_SourcePath ?? m_SourcePlyPath;
            
            try
            {
                var formats = GetFormatsForQuality(m_ImportQuality);
                
                // Create asset directly without opening another window
                Directory.CreateDirectory(m_DestinationFolder);
                
                var creator = ScriptableObject.CreateInstance<GaussianSplatAssetCreator>();
                var so = new SerializedObject(creator);
                so.FindProperty("m_InputFile").stringValue = sourcePath;
                so.FindProperty("m_OutputFolder").stringValue = m_DestinationFolder;
                so.FindProperty("m_ImportCameras").boolValue = m_IncludeCameras && m_DetectedFormat == SourceFormat.PLY;
                so.FindProperty("m_Quality").intValue = 5; // Custom mode
                so.FindProperty("m_FormatPos").intValue = (int)formats.posFormat;
                so.FindProperty("m_FormatScale").intValue = (int)formats.scaleFormat;
                so.FindProperty("m_FormatColor").intValue = (int)formats.colorFormat;
                so.FindProperty("m_FormatSH").intValue = (int)formats.shFormat;
                so.ApplyModifiedPropertiesWithoutUndo();
                
                // Call the internal method via reflection since it's not public
                var method = typeof(GaussianSplatAssetCreator).GetMethod("CreateAssetInternal", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                string assetPath = method?.Invoke(creator, null) as string;
                
                ScriptableObject.DestroyImmediate(creator);
                
                if (!string.IsNullOrEmpty(assetPath))
                {
                    string formatName = m_DetectedFormat == SourceFormat.SPZ ? "SPZ" : "PLY";
                    m_StatusMessage = $"Successfully imported {formatName} to {assetPath}";
                    m_StatusType = MessageType.Info;
                    
                    // Select the created asset
                    var asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(assetPath);
                    if (asset != null)
                        Selection.activeObject = asset;
                }
                else
                {
                    m_StatusMessage = "Import failed - check console for details";
                    m_StatusType = MessageType.Error;
                }
            }
            catch (Exception ex)
            {
                m_StatusMessage = $"Import failed: {ex.Message}";
                m_StatusType = MessageType.Error;
                Debug.LogException(ex);
            }
        }

        bool ValidateImportSettings()
        {
            string sourcePath = m_SourcePath ?? m_SourcePlyPath;
            
            if (string.IsNullOrWhiteSpace(sourcePath))
            {
                m_StatusMessage = "Please select a source PLY or SPZ file";
                m_StatusType = MessageType.Error;
                return false;
            }
            
            if (!File.Exists(sourcePath))
            {
                m_StatusMessage = "Source file does not exist";
                m_StatusType = MessageType.Error;
                return false;
            }
            
            if (m_DetectedFormat == SourceFormat.Unknown)
            {
                m_StatusMessage = "Unsupported file format. Use .ply or .spz files.";
                m_StatusType = MessageType.Error;
                return false;
            }
            
            if (string.IsNullOrWhiteSpace(m_DestinationFolder) || !m_DestinationFolder.StartsWith("Assets/"))
            {
                m_StatusMessage = "Output folder must be within the Assets folder";
                m_StatusType = MessageType.Error;
                return false;
            }
            
            if (string.IsNullOrWhiteSpace(m_AssetName))
            {
                m_StatusMessage = "Please enter an asset name";
                m_StatusType = MessageType.Error;
                return false;
            }
            
            return true;
        }

        (GaussianSplatAsset.VectorFormat posFormat, GaussianSplatAsset.VectorFormat scaleFormat, 
         GaussianSplatAsset.ColorFormat colorFormat, GaussianSplatAsset.SHFormat shFormat) 
        GetFormatsForQuality(ImportQuality quality)
        {
            return quality switch
            {
                ImportQuality.Lossless => (
                    GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.VectorFormat.Float32,
                    GaussianSplatAsset.ColorFormat.Float32x4,
                    GaussianSplatAsset.SHFormat.Float32
                ),
                ImportQuality.HighQuality => (
                    GaussianSplatAsset.VectorFormat.Norm16,
                    GaussianSplatAsset.VectorFormat.Norm16,
                    GaussianSplatAsset.ColorFormat.Float16x4,
                    GaussianSplatAsset.SHFormat.Norm11
                ),
                ImportQuality.Balanced => (
                    GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.ColorFormat.Norm8x4,
                    GaussianSplatAsset.SHFormat.Norm6
                ),
                ImportQuality.Optimized => (
                    GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.VectorFormat.Norm6,
                    GaussianSplatAsset.ColorFormat.Norm8x4,
                    GaussianSplatAsset.SHFormat.Cluster16k
                ),
                ImportQuality.Compressed => (
                    GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.VectorFormat.Norm6,
                    GaussianSplatAsset.ColorFormat.BC7,
                    GaussianSplatAsset.SHFormat.Cluster4k
                ),
                _ => (
                    GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.VectorFormat.Norm11,
                    GaussianSplatAsset.ColorFormat.Norm8x4,
                    GaussianSplatAsset.SHFormat.Norm6
                )
            };
        }
        #endregion
    }
}
