// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatColorBrush))]
    public class GaussianSplatColorBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatColorBrush m_Target;
        private bool m_BrushMode = false;
        private bool m_NavigationMode = false;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatColorBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Box Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            Vector3 newSize = EditorGUILayout.Vector3Field("Box Size", m_Target.BoxSize);
            Vector3 newPos = EditorGUILayout.Vector3Field("Box Position", m_Target.BoxPosition);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Color Brush Settings");
                m_Target.BoxSize = newSize;
                m_Target.BoxPosition = newPos;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Color Adjustments", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            var adj = m_Target.ColorAdjust;
            adj.exposure = EditorGUILayout.Slider("Exposure", adj.exposure, -2f, 5f);
            adj.contrast = EditorGUILayout.Slider("Contrast", adj.contrast, 0f, 2f);
            adj.hueShift = EditorGUILayout.Slider("Hue Shift", adj.hueShift, -180f, 180f);
            adj.saturation = EditorGUILayout.Slider("Saturation", adj.saturation, 0f, 2f);
            adj.colorTint = EditorGUILayout.ColorField("Color Tint", adj.colorTint);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Color Adjustments");
                m_Target.ColorAdjust = adj;
                EditorUtility.SetDirty(m_Target);
                
                // Realtime update
                if (m_Target.HasAdjustments && m_Target.IsValid)
                    m_Target.ApplyColorAdjustments();
            }
            
            EditorGUILayout.Space();
            
            if (m_Target.HasAdjustments)
            {
                GUI.color = new Color(0.8f, 0.3f, 0.9f);
                EditorGUILayout.LabelField("✓ Adjustments ready to apply", EditorStyles.boldLabel);
                GUI.color = Color.white;
            }
            else
            {
                EditorGUILayout.LabelField("No adjustments set");
            }
            
            EditorGUILayout.Space();
            
            EditorGUILayout.HelpBox(
                "1. Position the box over splats\n" +
                "2. Adjust sliders - updates in realtime\n" +
                "3. WASD camera movement works normally",
                MessageType.Info);
            
            EditorGUILayout.Space();
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = m_Target.HasAdjustments ? new Color(0.8f, 0.3f, 0.9f) : Color.gray;
            GUI.enabled = m_Target.HasAdjustments && m_Target.IsValid;
            if (GUILayout.Button("Apply Colors", GUILayout.Height(30)))
            {
                m_Target.ApplyColorAdjustments();
            }
            GUI.enabled = true;
            
            GUI.backgroundColor = new Color(1f, 0.8f, 0.3f);
            if (GUILayout.Button("Reset", GUILayout.Height(30)))
            {
                Undo.RecordObject(m_Target, "Reset Color Adjustments");
                m_Target.ResetColorAdjustments();
                EditorUtility.SetDirty(m_Target);
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            if (GUILayout.Button("Reset Box"))
            {
                Undo.RecordObject(m_Target, "Reset Box");
                m_Target.ResetBox();
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            
            GUI.backgroundColor = m_BrushMode ? new Color(0.8f, 0.3f, 0.9f) : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Color Mode" : "Start Color Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            m_NavigationMode = false;
            GaussianSplatColorBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            m_NavigationMode = false;
            GaussianSplatColorBrush.IsBrushModeActive = false;
            GaussianSplatColorBrush.HasValidBrushPosition = false;
            
            // Reset color adjustments and box position
            if (m_Target != null)
            {
                m_Target.ResetColorAdjustments();
                m_Target.BoxPosition = Vector3.zero;
                m_Target.BoxSize = Vector3.one;
            }
            
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatColorBrush.IsBrushModeActive = false;
                GaussianSplatColorBrush.HasValidBrushPosition = false;
                
                // Reset color adjustments and box position
                if (m_Target != null)
                {
                    m_Target.ResetColorAdjustments();
                    m_Target.BoxPosition = Vector3.zero;
                    m_Target.BoxSize = Vector3.one;
                }
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                sceneView.Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            DrawBoxHandles(sceneView);
            DrawPreview(sceneView);
            
            // Enter to apply
            if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.Return || e.keyCode == KeyCode.KeypadEnter))
            {
                if (m_Target.HasAdjustments && m_Target.IsValid)
                    m_Target.ApplyColorAdjustments();
                e.Use();
                sceneView.Repaint();
                Repaint();
            }
            
            // Escape to stop brush mode
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopBrushMode();
                Repaint();
                e.Use();
            }

            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private void DrawBoxHandles(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Target.BoxPosition;
            Vector3 size = m_Target.BoxSize;
            
            // Center move handle
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
            if (newPos != pos)
            {
                Undo.RecordObject(m_Target, "Move Box");
                m_Target.BoxPosition = newPos;
                EditorUtility.SetDirty(m_Target);
            }
            
            // Size handles on each face
            Handles.color = new Color(0.8f, 0.3f, 0.9f, 0.9f);
            float handleSize = HandleUtility.GetHandleSize(pos) * 0.1f;
            
            float newX = DrawSizeHandle(pos + Vector3.right * size.x * 0.5f, Vector3.right, size.x, handleSize, Color.red);
            float newY = DrawSizeHandle(pos + Vector3.up * size.y * 0.5f, Vector3.up, size.y, handleSize, Color.green);
            float newZ = DrawSizeHandle(pos + Vector3.forward * size.z * 0.5f, Vector3.forward, size.z, handleSize, Color.blue);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Resize Box");
                m_Target.BoxSize = new Vector3(
                    Mathf.Abs(newX) * 2f,
                    Mathf.Abs(newY) * 2f,
                    Mathf.Abs(newZ) * 2f);
                EditorUtility.SetDirty(m_Target);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private float DrawSizeHandle(Vector3 handlePos, Vector3 direction, float currentSize, float handleSize, Color color)
        {
            Handles.color = color;
            Vector3 newHandlePos = Handles.Slider(handlePos, direction, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
            float delta = Vector3.Dot(newHandlePos - handlePos, direction);
            return currentSize * 0.5f + delta;
        }

        private void DrawPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Target.BoxPosition;
            Vector3 size = m_Target.BoxSize;
            
            // Draw current box - magenta/purple for color tool
            Handles.color = new Color(0.8f, 0.3f, 0.9f, 0.9f);
            Handles.DrawWireCube(pos, size);
            
            // Fill with color preview
            if (m_Target.HasAdjustments)
            {
                var adj = m_Target.ColorAdjust;
                // Show a hint of what color will be applied
                Color previewColor = adj.colorTint;
                previewColor.a = 0.15f;
                Handles.color = previewColor;
                Handles.DrawWireCube(pos, size * 0.98f);
            }
            
            // Instructions at box
            GUIStyle instructionStyle = new GUIStyle();
            instructionStyle.normal.textColor = Color.white;
            instructionStyle.fontSize = 11;
            
            string info = m_Target.HasAdjustments ? "A=Apply | R=Reset" : "Set color values first";
            Handles.Label(pos + Vector3.up * (size.y * 0.5f + 0.1f), info, instructionStyle);
            
            // Show current adjustments
            if (m_Target.HasAdjustments)
            {
                var adj = m_Target.ColorAdjust;
                GUIStyle adjStyle = new GUIStyle();
                adjStyle.normal.textColor = new Color(0.8f, 0.3f, 0.9f);
                adjStyle.fontSize = 10;
                string adjInfo = $"Exp:{adj.exposure:F1} Con:{adj.contrast:F1} Hue:{adj.hueShift:F0} Sat:{adj.saturation:F1}";
                Handles.Label(pos + Vector3.up * (size.y * 0.5f + 0.2f), adjInfo, adjStyle);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
    
    [EditorTool("Splat Color Brush", typeof(GaussianSplatColorBrush))]
    public class GaussianSplatColorBrushTool : EditorTool
    {
        private GaussianSplatColorBrush m_Brush;
        private bool m_NavigationMode = false;

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("d_ColorPicker.CycleColor").image,
            "Splat Color Brush Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatColorBrush;
            GaussianSplatColorBrush.IsBrushModeActive = true;
            m_NavigationMode = false;
        }
        
        private void OnDisable()
        {
            GaussianSplatColorBrush.IsBrushModeActive = false;
            GaussianSplatColorBrush.HasValidBrushPosition = false;
            m_NavigationMode = false;
            
            // Reset color adjustments and box position
            if (m_Brush != null)
            {
                m_Brush.ResetColorAdjustments();
                m_Brush.BoxPosition = Vector3.zero;
                m_Brush.BoxSize = Vector3.one;
            }
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                GaussianSplatColorBrush.IsBrushModeActive = false;
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatColorBrush.IsBrushModeActive = true;
            
            DrawToolBox(sceneView);
            DrawToolPreview(sceneView);
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.A)
            {
                if (m_Brush.HasAdjustments && m_Brush.IsValid)
                    m_Brush.ApplyColorAdjustments();
                e.Use();
            }
            
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.R)
            {
                Undo.RecordObject(m_Brush, "Reset Color Adjustments");
                m_Brush.ResetColorAdjustments();
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }

            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            sceneView.Repaint();
        }
        
        private void DrawToolBox(SceneView sceneView)
        {
            Vector3 pos = m_Brush.BoxPosition;
            
            EditorGUI.BeginChangeCheck();
            Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Brush, "Move Box");
                m_Brush.BoxPosition = newPos;
            }
        }
        
        private void DrawToolPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Brush.BoxPosition;
            Vector3 size = m_Brush.BoxSize;
            
            Handles.color = new Color(0.8f, 0.3f, 0.9f, 0.9f);
            Handles.DrawWireCube(pos, size);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
}

