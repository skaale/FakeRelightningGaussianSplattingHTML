// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatBoxBrush))]
    public class GaussianSplatBoxBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatBoxBrush m_Target;
        private bool m_BrushMode = false;
#pragma warning disable CS0414 // assigned for future use
        private bool m_NavigationMode = false;
#pragma warning restore CS0414

        private void OnEnable()
        {
            m_Target = target as GaussianSplatBoxBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUILayout.Space();
            
            // Mode selection with 3 tabs
            EditorGUILayout.LabelField("Xcopy Mode", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            
            // Box Xcopy tab
            GUI.backgroundColor = m_Target.BrushMode == BoxBrushMode.Box3D ? Color.cyan : Color.gray;
            if (GUILayout.Button("📦 Box Xcopy", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_Target, "Change Xcopy Mode");
                m_Target.BrushMode = BoxBrushMode.Box3D;
                EditorUtility.SetDirty(m_Target);
            }
            
            // Planar Xcopy tab
            GUI.backgroundColor = m_Target.BrushMode == BoxBrushMode.Planar ? Color.cyan : Color.gray;
            if (GUILayout.Button("📐 Planar Xcopy", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_Target, "Change Xcopy Mode");
                m_Target.BrushMode = BoxBrushMode.Planar;
                EditorUtility.SetDirty(m_Target);
            }
            
            // Paint Xcopy tab
            GUI.backgroundColor = m_Target.BrushMode == BoxBrushMode.PaintSelection ? Color.cyan : Color.gray;
            if (GUILayout.Button("🖌️ Paint Xcopy", GUILayout.Height(28)))
            {
                Undo.RecordObject(m_Target, "Change Xcopy Mode");
                m_Target.BrushMode = BoxBrushMode.PaintSelection;
                EditorUtility.SetDirty(m_Target);
            }
            
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            
            // Visualization settings
            EditorGUILayout.LabelField("Visualization", EditorStyles.boldLabel);
            EditorGUI.BeginChangeCheck();
            Color boxColor = EditorGUILayout.ColorField("Box Color", m_Target.BoxColor);
            float boxAlpha = EditorGUILayout.Slider("Transparency", m_Target.BoxAlpha, 0.05f, 0.5f);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Box Visualization");
                m_Target.BoxColor = boxColor;
                m_Target.BoxAlpha = boxAlpha;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            
            if (m_Target.BrushMode == BoxBrushMode.Planar)
            {
                EditorGUILayout.LabelField("Planar Settings (Floor)", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                float floorY = EditorGUILayout.FloatField("Floor Y", m_Target.FloorY);
                float thickness = EditorGUILayout.Slider("Thickness", m_Target.FloorThickness, 0.01f, 1f);
                Vector2 planarSize = EditorGUILayout.Vector2Field("Size (XZ)", m_Target.PlanarSize);
                Vector2 planarPos = EditorGUILayout.Vector2Field("Position (XZ)", m_Target.PlanarPosition);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Planar Settings");
                    m_Target.FloorY = floorY;
                    m_Target.FloorThickness = thickness;
                    m_Target.PlanarSize = planarSize;
                    m_Target.PlanarPosition = planarPos;
                    EditorUtility.SetDirty(m_Target);
                }
                
                EditorGUILayout.HelpBox("Click and drag in scene to draw floor rectangle", MessageType.Info);
            }
            else if (m_Target.BrushMode == BoxBrushMode.PaintSelection)
            {
                EditorGUILayout.LabelField("Paint Selection Settings", EditorStyles.boldLabel);
                
                // Warning if asset doesn't support cloning
                if (!m_Target.SupportsCloning)
                {
                    EditorGUILayout.HelpBox("Copy/Paste requires VeryHigh quality splats.", MessageType.Warning);
                }
                
                EditorGUI.BeginChangeCheck();
                float brushRadius = EditorGUILayout.Slider("Brush Radius", m_Target.SelectionBrushRadius, 0.01f, 5f);
                
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField("Source Color", GUILayout.Width(85));
                Color selColor = EditorGUILayout.ColorField(m_Target.SelectionColor);
                EditorGUILayout.LabelField("Target Color", GUILayout.Width(85));
                Color targColor = EditorGUILayout.ColorField(m_Target.TargetColor);
                EditorGUILayout.EndHorizontal();
                
                bool addMode = EditorGUILayout.Toggle("Add Mode (uncheck to subtract)", m_Target.SelectionAddMode);
                bool backfaceCull = EditorGUILayout.Toggle("Backface Culling", m_Target.BackfaceCulling);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Paint Selection Settings");
                    m_Target.SelectionBrushRadius = brushRadius;
                    m_Target.SelectionColor = selColor;
                    m_Target.TargetColor = targColor;
                    m_Target.SelectionAddMode = addMode;
                    m_Target.BackfaceCulling = backfaceCull;
                    EditorUtility.SetDirty(m_Target);
                }
                
                EditorGUILayout.Space();
                
                // Paint Mode Toggle: Source vs Target
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = !m_Target.PaintingTargetMode ? m_Target.SelectionColor : Color.gray;
                if (GUILayout.Button("Paint Source", GUILayout.Height(28)))
                {
                    Undo.RecordObject(m_Target, "Switch to Paint Source");
                    m_Target.PaintingTargetMode = false;
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.backgroundColor = m_Target.PaintingTargetMode ? m_Target.TargetColor : Color.gray;
                if (GUILayout.Button("Paint Target", GUILayout.Height(28)))
                {
                    Undo.RecordObject(m_Target, "Switch to Paint Target");
                    m_Target.PaintingTargetMode = true;
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                string currentMode = m_Target.PaintingTargetMode ? "TARGET" : "SOURCE";
                Color modeColor = m_Target.PaintingTargetMode ? m_Target.TargetColor : m_Target.SelectionColor;
                GUI.color = modeColor;
                EditorGUILayout.LabelField($"Currently painting: {currentMode}", EditorStyles.boldLabel);
                GUI.color = Color.white;
                
                EditorGUILayout.Space();
                
                // Source selection count
                if (m_Target.HasSelection)
                {
                    GUI.color = m_Target.SelectionColor;
                    EditorGUILayout.LabelField($"✓ {m_Target.SelectedSplatCount} splats (SOURCE)", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                else
                {
                    EditorGUILayout.LabelField("No source splats selected");
                }
                
                // Target selection count
                if (m_Target.HasTargetSelection)
                {
                    GUI.color = m_Target.TargetColor;
                    EditorGUILayout.LabelField($"✓ {m_Target.TargetSelectedSplatCount} splats (TARGET)", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                
                // Show actual target center from painted splats
                if (m_Target.HasTargetSelection && m_Target.TargetRenderer != null)
                {
                    Vector3 actualTargetCenter = m_Target.TargetRenderer.GetTargetSelectedSplatsCenter();
                    GUI.enabled = false;
                    EditorGUILayout.Vector3Field("Target Splats Center", actualTargetCenter);
                    GUI.enabled = true;
                }
                else
                {
                EditorGUI.BeginChangeCheck();
                    Vector3 targetPos = EditorGUILayout.Vector3Field("Paste Target Position", m_Target.BoxPosition);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Target Position");
                    m_Target.BoxPosition = targetPos;
                    EditorUtility.SetDirty(m_Target);
                    }
                }
                
                // Show alignment info when data is copied
                if (m_Target.HasCopiedSelection && m_Target.HasTargetSelection)
                {
                    GUI.color = Color.green;
                    EditorGUILayout.LabelField("✓ Will paste at target splats center with alignment", EditorStyles.miniLabel);
                    GUI.color = Color.white;
                }
                
                EditorGUILayout.Space();
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Clear Source"))
                    m_Target.ClearSelection();
                GUI.backgroundColor = m_Target.TargetColor;
                if (GUILayout.Button("Clear Target"))
                    m_Target.ClearTargetSelection();
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Invert Selection"))
                    m_Target.InvertSelection();
                if (GUILayout.Button("Select All"))
                    m_Target.SelectAll();
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.Space();
                
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = new Color(0.5f, 1f, 0.5f);
                GUI.enabled = m_Target.HasSelection;
                if (GUILayout.Button("Copy Selection", GUILayout.Height(30)))
                {
                    // Use last active scene view camera orientation
                    var sceneView = SceneView.lastActiveSceneView;
                    if (sceneView != null)
                        m_Target.CopySelectionWithOrientation(sceneView.camera.transform.forward, sceneView.camera.transform.up);
                    else
                    m_Target.CopySelection();
                }
                
                GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
                if (GUILayout.Button("Delete Selection", GUILayout.Height(30)))
                    m_Target.DeleteSelection();
                GUI.enabled = true;
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                GUI.backgroundColor = m_Target.CanPasteSelection ? m_Target.TargetColor : Color.gray;
                GUI.enabled = m_Target.CanPasteSelection;
                if (GUILayout.Button("Paste at Target", GUILayout.Height(28)))
                    m_Target.PasteSelection();
                GUI.enabled = true;
                GUI.backgroundColor = Color.white;
                
                // Paste offset adjustment
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("Paste Offset Adjustment", EditorStyles.boldLabel);
                
                // Toggle between Paint and Transform mode - ALWAYS visible
                EditorGUILayout.BeginHorizontal();
                GUI.backgroundColor = !m_Target.TransformModeActive ? Color.cyan : Color.gray;
                if (GUILayout.Button("🖌️ Paint Mode (G)", GUILayout.Height(28)))
                {
                    m_Target.TransformModeActive = false;
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.backgroundColor = m_Target.TransformModeActive ? Color.yellow : Color.gray;
                if (GUILayout.Button("🔧 Transform Mode (G)", GUILayout.Height(28)))
                {
                    m_Target.TransformModeActive = true;
                    Tools.current = Tool.Move;
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.backgroundColor = Color.white;
                EditorGUILayout.EndHorizontal();
                
                if (m_Target.TransformModeActive)
                {
                    EditorGUILayout.HelpBox("TRANSFORM MODE: W=Move | E=Rotate | R=Scale | G=Toggle", MessageType.Info);
                }
                else
                {
                    EditorGUILayout.HelpBox("PAINT MODE: Click to paint | G=Toggle to Transform", MessageType.Info);
                }
                
                // Show if splats are being adjusted in real-time
                if (m_Target.HasAdjustablePastedSplats)
                {
                    GUI.color = Color.cyan;
                    EditorGUILayout.LabelField($"✓ {m_Target.LastPastedCount} pasted splats ready to adjust", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                }
                
                // Position adjustments
                EditorGUI.BeginChangeCheck();
                Vector3 pasteOffset = EditorGUILayout.Vector3Field("XYZ Offset", m_Target.PasteOffset);
                float depthOffset = EditorGUILayout.Slider("Depth Offset", m_Target.PasteDepthOffset, -2f, 2f);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Paste Offset");
                    m_Target.PasteOffset = pasteOffset;
                    m_Target.PasteDepthOffset = depthOffset;
                    EditorUtility.SetDirty(m_Target);
                }
                
                // Rotation and Scale adjustments (only when adjustable)
                GUI.enabled = m_Target.HasAdjustablePastedSplats;
                EditorGUI.BeginChangeCheck();
                Vector3 rotAdjust = EditorGUILayout.Vector3Field("Rotation Adjust", m_Target.PasteRotationAdjust);
                float scaleAdjust = EditorGUILayout.Slider("Scale Adjust", m_Target.PasteScaleAdjust, 0.1f, 3f);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Paste Transform");
                    m_Target.PasteRotationAdjust = rotAdjust;
                    m_Target.PasteScaleAdjust = scaleAdjust;
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.enabled = true;
                
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Reset All"))
                {
                    Undo.RecordObject(m_Target, "Reset Paste Adjustments");
                    m_Target.ResetPasteAdjustments();
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.enabled = m_Target.HasAdjustablePastedSplats;
                GUI.backgroundColor = Color.green;
                if (GUILayout.Button("Confirm"))
                {
                    m_Target.ConfirmPastedSplats();
                    EditorUtility.SetDirty(m_Target);
                }
                GUI.backgroundColor = Color.white;
                GUI.enabled = true;
                EditorGUILayout.EndHorizontal();
                
                EditorGUILayout.HelpBox("1. Paint SOURCE → Copy (C)\n2. Paint TARGET (T) → Paste (V)\n3. Adjust with handles: W=Move | E=Rotate | R=Scale\n4. Confirm when done", MessageType.Info);
            }
            else
            {
                EditorGUILayout.LabelField("Box Settings", EditorStyles.boldLabel);
                
                EditorGUI.BeginChangeCheck();
                Vector3 newSize = EditorGUILayout.Vector3Field("Box Size", m_Target.BoxSize);
                Vector3 newPos = EditorGUILayout.Vector3Field("Box Position", m_Target.BoxPosition);
                Vector3 newRot = EditorGUILayout.Vector3Field("Box Rotation", m_Target.BoxRotation);
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Box Brush Settings");
                    m_Target.BoxSize = newSize;
                    m_Target.BoxPosition = newPos;
                    m_Target.BoxRotation = newRot;
                    EditorUtility.SetDirty(m_Target);
                }
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Status", EditorStyles.boldLabel);
            
            if (m_Target.HasCopiedData)
            {
                GUI.color = Color.cyan;
                EditorGUILayout.LabelField("Splats COPIED - Ready to paste!", EditorStyles.boldLabel);
                GUI.color = Color.white;
                EditorGUILayout.LabelField($"Source: {m_Target.CopiedSourcePosition}");
                EditorGUILayout.LabelField($"Size: {m_Target.CopiedBoxSize}");
                
                if (m_Target.ApplyPasteTransform && m_Target.PasteTransformSettings.HasTransform)
                {
                    var pt = m_Target.PasteTransformSettings;
                    GUI.color = Color.yellow;
                    if (pt.rotation != Vector3.zero)
                        EditorGUILayout.LabelField($"  Rotation: {pt.rotation}");
                    if (pt.scale != Vector3.one)
                        EditorGUILayout.LabelField($"  Scale: {pt.scale}");
                    if (pt.flip != FlipAxis.None)
                        EditorGUILayout.LabelField($"  Flip: {pt.flip}");
                    GUI.color = Color.white;
                }
            }
            else
            {
                EditorGUILayout.LabelField("No splats copied");
            }
            
            EditorGUILayout.Space();
            
            string helpText = m_Target.BrushMode == BoxBrushMode.Planar
                ? "PLANAR XCOPY:\n1. Drag in scene to draw floor rect\n2. Click COPY\n3. Drag to new position\n4. Click PASTE\n\nKeys: C=Copy | V=Paste | Del=Delete | X=Delete&Paste"
                : "BOX XCOPY:\n1. Set Box Size and Position\n2. Click COPY\n3. Move box to new position\n4. Click DELETE then PASTE (or Delete & Paste)\n\nKeys: C=Copy | V=Paste | Del=Delete | X=Delete&Paste";
            EditorGUILayout.HelpBox(helpText, MessageType.Info);
            
            EditorGUILayout.Space();
            
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = new Color(0.5f, 1f, 0.5f);
            if (GUILayout.Button("Copy", GUILayout.Height(30)))
            {
                m_Target.CopySplats();
            }
            
            GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
            if (GUILayout.Button("Delete", GUILayout.Height(30)))
            {
                m_Target.DeleteSplatsInBox();
            }
            
            GUI.backgroundColor = m_Target.CanPaste ? Color.cyan : Color.gray;
            GUI.enabled = m_Target.CanPaste;
            if (GUILayout.Button("Paste", GUILayout.Height(30)))
            {
                m_Target.PasteSplats();
            }
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();
            
            GUI.backgroundColor = m_Target.CanPaste ? new Color(1f, 0.8f, 0.3f) : Color.gray;
            GUI.enabled = m_Target.CanPaste;
            if (GUILayout.Button("Delete & Paste", GUILayout.Height(25)))
            {
                m_Target.DeleteAndPaste();
            }
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Clear Copied"))
                m_Target.ClearCopiedData();
            if (GUILayout.Button("Reset Box"))
                m_Target.ResetBox();
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            
            // Paste Transform Section
            EditorGUILayout.LabelField("Paste Transform (Applied on Paste)", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            bool applyTransform = EditorGUILayout.Toggle("Apply Transform", m_Target.ApplyPasteTransform);
            
            if (applyTransform)
            {
                var pt = m_Target.PasteTransformSettings;
                EditorGUI.indentLevel++;
                pt.rotation = EditorGUILayout.Vector3Field("Rotation", pt.rotation);
                pt.scale = EditorGUILayout.Vector3Field("Scale", pt.scale);
                pt.flip = (FlipAxis)EditorGUILayout.EnumFlagsField("Flip Axis", pt.flip);
                EditorGUI.indentLevel--;
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Paste Transform");
                    m_Target.ApplyPasteTransform = applyTransform;
                    m_Target.PasteTransformSettings = pt;
                    EditorUtility.SetDirty(m_Target);
                }
                
                if (GUILayout.Button("Reset Paste Transform"))
                {
                    Undo.RecordObject(m_Target, "Reset Paste Transform");
                    m_Target.ResetPasteTransform();
                    EditorUtility.SetDirty(m_Target);
                }
            }
            else
            {
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Toggle Paste Transform");
                    m_Target.ApplyPasteTransform = applyTransform;
                    EditorUtility.SetDirty(m_Target);
                }
            }
            
            EditorGUILayout.Space();
            
            // Color Adjustments Section
            EditorGUILayout.LabelField("Color Adjustments (Applied on Paste)", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            bool applyColor = EditorGUILayout.Toggle("Apply Color Adjustments", m_Target.ApplyColorAdjustments);
            
            if (applyColor)
            {
                var adj = m_Target.ColorAdjust;
                EditorGUI.indentLevel++;
                adj.exposure = EditorGUILayout.Slider("Exposure", adj.exposure, -2f, 5f);
                adj.contrast = EditorGUILayout.Slider("Contrast", adj.contrast, 0f, 2f);
                adj.hueShift = EditorGUILayout.Slider("Hue Shift", adj.hueShift, -180f, 180f);
                adj.saturation = EditorGUILayout.Slider("Saturation", adj.saturation, 0f, 2f);
                adj.colorTint = EditorGUILayout.ColorField("Color Tint", adj.colorTint);
                EditorGUI.indentLevel--;
                
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Change Color Adjustments");
                    m_Target.ApplyColorAdjustments = applyColor;
                    m_Target.ColorAdjust = adj;
                    EditorUtility.SetDirty(m_Target);
                }
                
                if (GUILayout.Button("Reset Color Adjustments"))
                {
                    Undo.RecordObject(m_Target, "Reset Color Adjustments");
                    m_Target.ResetColorAdjustments();
                    EditorUtility.SetDirty(m_Target);
                }
            }
            else
            {
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Toggle Color Adjustments");
                    m_Target.ApplyColorAdjustments = applyColor;
                    EditorUtility.SetDirty(m_Target);
                }
            }
            
            EditorGUILayout.Space();
            
            GUI.backgroundColor = m_BrushMode ? Color.cyan : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Xcopy Mode" : "Start Xcopy Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            m_NavigationMode = false;
            GaussianSplatBoxBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            m_NavigationMode = false;
            GaussianSplatBoxBrush.IsBrushModeActive = false;
            GaussianSplatBoxBrush.HasValidBrushPosition = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatBoxBrush.IsBrushModeActive = false;
                GaussianSplatBoxBrush.HasValidBrushPosition = false;
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            // Middle mouse button toggles tool on/off
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                StopBrushMode();
                e.Use();
                sceneView.Repaint();
                Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            
            // Only grab default control if NOT adjusting pasted splats (let handles receive input)
            bool adjustingPastedSplats = m_Target.BrushMode == BoxBrushMode.PaintSelection && m_Target.ShowTransformHandles;
            if (e.type == EventType.Layout && !adjustingPastedSplats)
                HandleUtility.AddDefaultControl(controlID);
            
            if (m_Target.BrushMode == BoxBrushMode.Planar)
            {
                HandlePlanarMode(sceneView, e);
            }
            else if (m_Target.BrushMode == BoxBrushMode.PaintSelection)
            {
                HandlePaintSelectionMode(sceneView, e);
            }
            else
            {
                DrawBoxHandles(sceneView);
                DrawPreview(sceneView);
                
                // Tool hotkeys (1/2/3/R to switch Unity tools)
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.W)
                {
                    Tools.current = Tool.Move;
                    e.Use();
                    Repaint();
                }
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.E)
                {
                    Tools.current = Tool.Rotate;
                    e.Use();
                    Repaint();
                }
                if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.R))
                {
                    Tools.current = Tool.Scale;
                    e.Use();
                    Repaint();
                }
            }
            
            // Mode-specific hotkeys
            if (m_Target.BrushMode == BoxBrushMode.PaintSelection)
            {
                // C to copy selection with camera orientation
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.C)
                {
                    Camera cam = sceneView.camera;
                    m_Target.CopySelectionWithOrientation(cam.transform.forward, cam.transform.up);
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // V to paste selection
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.V)
                {
                    if (m_Target.CanPasteSelection)
                        m_Target.PasteSelection();
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // Delete to delete selection
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
                {
                    if (m_Target.HasSelection)
                        m_Target.DeleteSelection();
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // T to toggle between Source and Target painting mode
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.T && !e.control && !e.shift && !e.alt)
                {
                    Undo.RecordObject(m_Target, "Toggle Paint Mode");
                    m_Target.PaintingTargetMode = !m_Target.PaintingTargetMode;
                    EditorUtility.SetDirty(m_Target);
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // G to toggle between Paint and Transform mode
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.G && !e.control && !e.shift && !e.alt)
                {
                    Undo.RecordObject(m_Target, "Toggle Transform Mode");
                    m_Target.TransformModeActive = !m_Target.TransformModeActive;
                    if (m_Target.TransformModeActive)
                        Tools.current = Tool.Move;
                    EditorUtility.SetDirty(m_Target);
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // Tool hotkeys for adjusting pasted splats (W/E/R) - only when transform mode is active
                if (m_Target.ShowTransformHandles)
                {
                    if (e.type == EventType.KeyDown && e.keyCode == KeyCode.W)
                    {
                        Tools.current = Tool.Move;
                        e.Use();
                        Repaint();
                    }
                    if (e.type == EventType.KeyDown && e.keyCode == KeyCode.E)
                    {
                        Tools.current = Tool.Rotate;
                        e.Use();
                        Repaint();
                    }
                    if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.R))
                    {
                        Tools.current = Tool.Scale;
                        e.Use();
                        Repaint();
                    }
                }
            }
            else
            {
                // C to copy
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.C)
                {
                    m_Target.CopySplats();
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // V to paste
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.V)
                {
                    if (m_Target.CanPaste)
                        m_Target.PasteSplats();
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
            }
            
            // Delete key and X to delete (only for non-PaintSelection modes)
            if (m_Target.BrushMode != BoxBrushMode.PaintSelection)
            {
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
                {
                    m_Target.DeleteSplatsInBox();
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
                
                // X to delete & paste
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.X)
                {
                    if (m_Target.CanPaste)
                        m_Target.DeleteAndPaste();
                    e.Use();
                    sceneView.Repaint();
                    Repaint();
                }
            }
            
            // Escape to stop brush mode
            if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
            {
                StopBrushMode();
                Repaint();
                e.Use();
            }

            // Only grab default control if NOT adjusting pasted splats
            if (!adjustingPastedSplats)
                HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }
        
        private void HandlePlanarMode(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 hitPoint = GetPlanarHitPoint(ray, sceneView, m_Target.FloorY);
            
            DrawPlanarPreview(sceneView, hitPoint);
            
            // Only handle mouse events, let keyboard pass through for scene navigation
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                Undo.RecordObject(m_Target, "Start Planar Draw");
                m_Target.StartPlanarDrag(hitPoint);
                EditorUtility.SetDirty(m_Target);
                e.Use();
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && m_Target.IsDrawingPlanar)
            {
                m_Target.UpdatePlanarDrag(hitPoint);
                EditorUtility.SetDirty(m_Target);
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0 && m_Target.IsDrawingPlanar)
            {
                m_Target.UpdatePlanarDrag(hitPoint);
                m_Target.EndPlanarDrag();
                EditorUtility.SetDirty(m_Target);
                e.Use();
                Repaint();
            }
        }
        
        private void HandlePaintSelectionMode(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 brushPos = GetBrushHitPoint(ray, sceneView);
            float brushRadius = m_Target.SelectionBrushRadius;
            
            // Draw transform handles when transform mode is active, otherwise show brush
            if (m_Target.ShowTransformHandles)
            {
                DrawPastedSplatsTransformHandles(sceneView);
            }
            else
            {
                // Draw brush preview when in paint mode
                DrawPaintSelectionBrush(sceneView, brushPos, brushRadius);
            }
            
            // Scroll wheel to resize brush
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_Target, "Resize Selection Brush");
                float delta = -e.delta.y * 0.05f;
                m_Target.SelectionBrushRadius = Mathf.Clamp(brushRadius + delta, 0.01f, 10f);
                EditorUtility.SetDirty(m_Target);
                e.Use();
            }
            
            // Paint selection with left mouse button - DISABLED when transform mode is active
            if (!m_Target.ShowTransformHandles)
            {
                bool isPainting = e.button == 0 && !e.alt;
                bool subtractMode = e.shift; // Hold Shift to subtract
                
                if (e.type == EventType.MouseDown && isPainting)
                {
                    m_Target.IsPaintingSelection = true;
                    PaintSelectionAtPoint(sceneView, e.mousePosition, brushPos, !subtractMode);
                    e.Use();
                }
                else if (e.type == EventType.MouseDrag && m_Target.IsPaintingSelection)
                {
                    PaintSelectionAtPoint(sceneView, e.mousePosition, brushPos, !subtractMode);
                    e.Use();
                }
                else if (e.type == EventType.MouseUp && e.button == 0)
                {
                    m_Target.IsPaintingSelection = false;
                    Repaint();
                    e.Use();
                }
            }
        }
        
        private void DrawPastedSplatsTransformHandles(SceneView sceneView)
        {
            Vector3 pivot = m_Target.PastedSplatsPivot + m_Target.PasteOffset;
            Quaternion rot = m_Target.PastedSplatsRotation;
            float scale = m_Target.PasteScaleAdjust;
            
            // Ensure a valid tool is selected for handles
            if (Tools.current != Tool.Move && Tools.current != Tool.Rotate && Tools.current != Tool.Scale)
            {
                Tools.current = Tool.Move;
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pivot;
            Quaternion newRot = rot;
            float newScale = scale;
            
            // Show handles based on Unity's current tool
            switch (Tools.current)
            {
                case Tool.Move:
                    newPos = Handles.PositionHandle(pivot, rot);
                    break;
                    
                case Tool.Rotate:
                    newRot = Handles.RotationHandle(rot, pivot);
                    break;
                    
                case Tool.Scale:
                    Vector3 scaleVec = Handles.ScaleHandle(Vector3.one * scale, pivot, rot, HandleUtility.GetHandleSize(pivot));
                    newScale = (scaleVec.x + scaleVec.y + scaleVec.z) / 3f;
                    break;
                    
                default:
                    newPos = Handles.PositionHandle(pivot, rot);
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Adjust Pasted Splats");
                
                // Position changed - update offset
                if (newPos != pivot)
                {
                    Vector3 delta = newPos - pivot;
                    m_Target.PasteOffset = m_Target.PasteOffset + delta;
                }
                
                // Rotation changed
                if (newRot != rot)
                {
                    m_Target.PasteRotationAdjust = newRot.eulerAngles;
                }
                
                // Scale changed
                if (Mathf.Abs(newScale - scale) > 0.001f)
                {
                    m_Target.PasteScaleAdjust = Mathf.Max(0.1f, newScale);
                }
                
                EditorUtility.SetDirty(m_Target);
            }
            
            // Draw visual indicator for pasted splats pivot
            Handles.color = Color.cyan;
            float handleSize = HandleUtility.GetHandleSize(pivot) * 0.15f;
            Handles.DrawWireCube(pivot, Vector3.one * handleSize);
            
            // Label showing current tool
            string toolName = Tools.current == Tool.Move ? "MOVE (W)" : 
                              Tools.current == Tool.Rotate ? "ROTATE (E)" : "SCALE (R)";
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.cyan }, fontSize = 11, fontStyle = FontStyle.Bold };
            Handles.Label(pivot + Vector3.up * handleSize * 2f, $"Adjusting {m_Target.LastPastedCount} splats | {toolName}", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private Vector3 GetBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            // Place brush on plane at pivot depth - follows mouse directly
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private void PaintSelectionAtPoint(SceneView sceneView, Vector2 guiMousePos, Vector3 worldPos, bool addToSelection)
        {
            if (m_Target.TargetRenderer == null) return;
            if (!m_Target.TargetRenderer.HasValidAsset || !m_Target.TargetRenderer.HasValidRenderSetup) return;

            Camera cam = sceneView.camera;
            // Convert world position to screen coords - WorldToScreenPoint has Y=0 at bottom, flip for GUI
            Vector3 screenPos = cam.WorldToScreenPoint(worldPos);
            Vector2 mousePx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);
            
            float dist = Vector3.Distance(cam.transform.position, worldPos);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
            float radiusPx = Mathf.Clamp(m_Target.SelectionBrushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
            
            bool backfaceCulling = m_Target.BackfaceCulling;
            
            // Check if we're in target painting mode
            if (m_Target.PaintingTargetMode)
            {
                // Target mode: paint target selection (blue/cyan)
                m_Target.TargetRenderer.TargetSelectionColor = m_Target.TargetColor;
                m_Target.TargetRenderer.EditSelectTargetSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: !addToSelection, backfaceCulling);
                m_Target.BoxPosition = worldPos;
                // Pass camera orientation for alignment calculation
                m_Target.SetTargetPaintPosition(worldPos, cam.transform.forward, cam.transform.up);
            }
            else
            {
                // Source mode: select splats
                m_Target.TargetRenderer.SelectionColor = m_Target.SelectionColor;
                m_Target.TargetRenderer.EditSelectSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: !addToSelection, backfaceCulling);
            }
        }
        
        private void DrawPaintSelectionBrush(SceneView sceneView, Vector3 position, float radius)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            bool isPaintingTarget = m_Target.PaintingTargetMode;
            
            // Use appropriate color based on source/target mode
            Color baseColor = isPaintingTarget ? m_Target.TargetColor : m_Target.SelectionColor;
            Color brushColor, fillColor;
            
            if (isPaintingTarget)
            {
                // Target mode - use target color
                brushColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.95f);
                fillColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.3f);
            }
            else if (m_Target.SelectionAddMode)
            {
                // Source add mode
                brushColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.9f);
                fillColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.2f);
            }
            else
            {
                // Source subtract mode - red
                brushColor = new Color(1f, 0.2f, 0.2f, 0.9f);
                fillColor = new Color(1f, 0.2f, 0.2f, 0.2f);
            }
            
            // Draw filled disc facing camera
            Vector3 camForward = sceneView.camera.transform.forward;
            Handles.color = fillColor;
            Handles.DrawSolidDisc(position, camForward, radius);
            
            // Draw outline
            Handles.color = brushColor;
            Handles.DrawWireDisc(position, camForward, radius);
            Handles.DrawWireDisc(position, camForward, radius * 0.95f);
            
            // Info label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = baseColor }, fontSize = 11, fontStyle = FontStyle.Bold };
            string modeLabel = isPaintingTarget ? "TARGET" : (m_Target.SelectionAddMode ? "+" : "-");
            string info = isPaintingTarget ? "TARGET" : $"{modeLabel} [{m_Target.SelectedSplatCount}]";
            Handles.Label(position + Vector3.up * (radius + 0.05f), info, labelStyle);
            
            // Draw target position crosshair if we have target splats painted
            if (m_Target.HasCopiedSelection || m_Target.HasTargetSelection)
            {
                // Use actual center of painted target splats if available
                Vector3 targetPos = m_Target.HasTargetSelection && m_Target.TargetRenderer != null
                    ? m_Target.TargetRenderer.GetTargetSelectedSplatsCenter()
                    : m_Target.BoxPosition;
                Color targetColor = m_Target.TargetColor;
                
                Handles.color = new Color(targetColor.r, targetColor.g, targetColor.b, 0.95f);
                float crossSize = 0.15f;
                Handles.DrawLine(targetPos - Vector3.right * crossSize, targetPos + Vector3.right * crossSize);
                Handles.DrawLine(targetPos - Vector3.up * crossSize, targetPos + Vector3.up * crossSize);
                Handles.DrawLine(targetPos - Vector3.forward * crossSize, targetPos + Vector3.forward * crossSize);
                
                Handles.DrawWireDisc(targetPos, Vector3.up, 0.1f);
                Handles.DrawWireDisc(targetPos, Vector3.forward, 0.1f);
                Handles.DrawWireDisc(targetPos, Vector3.right, 0.1f);
                
                GUIStyle targetLabelStyle = new GUIStyle { normal = { textColor = targetColor }, fontSize = 11, fontStyle = FontStyle.Bold };
                string targetLabel = m_Target.HasTargetSelection ? "PASTE HERE" : "TARGET";
                Handles.Label(targetPos + Vector3.up * 0.2f, targetLabel, targetLabelStyle);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private Vector3 GetPlanarHitPoint(Ray ray, SceneView sceneView, float floorY)
        {
            Plane floorPlane = new Plane(Vector3.up, new Vector3(0, floorY, 0));
            if (floorPlane.Raycast(ray, out float enter))
                return ray.GetPoint(enter);
            
            Vector3 cameraPos = sceneView.camera.transform.position;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private void DrawPlanarPreview(SceneView sceneView, Vector3 cursorPos)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Target.PlanarBoxPosition;
            Vector3 size = m_Target.PlanarBoxSize;
            
            // Get colors from target
            Color boxColor = m_Target.HasCopiedData ? new Color(0f, 0.8f, 1f, 1f) : m_Target.BoxColor;
            float alpha = m_Target.BoxAlpha;
            
            // Draw solid 3D box
            DrawSolid3DBox(pos, size, boxColor, alpha);
            
            // Wireframe
            Handles.color = boxColor;
            Handles.DrawWireCube(pos, size);
            
            // Cursor
            Handles.color = Color.yellow;
            Handles.DrawWireDisc(cursorPos, Vector3.up, 0.1f);
            
            // Source if copied
            if (m_Target.HasCopiedData)
            {
                Color sourceColor = new Color(1f, 0.5f, 0f, 1f);
                DrawSolid3DBox(m_Target.CopiedSourcePosition, m_Target.CopiedBoxSize, sourceColor, alpha * 0.7f);
                
                Handles.color = sourceColor;
                Handles.DrawWireCube(m_Target.CopiedSourcePosition, m_Target.CopiedBoxSize);
                
                Handles.color = Color.yellow;
                Handles.DrawLine(m_Target.CopiedSourcePosition, pos);
            }
            
            // Position handle when not drawing
            if (!m_Target.IsDrawingPlanar)
            {
                EditorGUI.BeginChangeCheck();
                Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Target, "Move Planar Rect");
                    m_Target.PlanarPosition = new Vector2(newPos.x, newPos.z);
                    m_Target.FloorY = newPos.y;
                    EditorUtility.SetDirty(m_Target);
                }
            }
            
            // Label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 11, fontStyle = FontStyle.Bold };
            string info = m_Target.IsDrawingPlanar ? "Drawing..." : (m_Target.HasCopiedData ? "C=Copy | V=Paste | X=Del&Paste" : "DRAG=Draw | C=Copy");
            Handles.Label(pos + Vector3.up * 0.3f, info, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawBoxHandles(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Target.BoxPosition;
            Vector3 size = m_Target.BoxSize;
            Quaternion rot = m_Target.BoxRotationQuat;
            
            // Use Unity's Transform handles based on current tool
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pos;
            Quaternion newRot = rot;
            Vector3 newScale = size;
            
            // Show handles based on Unity's current tool
            switch (Tools.current)
            {
                case Tool.Move:
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
                    
                case Tool.Rotate:
                    newRot = Handles.RotationHandle(rot, pos);
                    break;
                    
                case Tool.Scale:
                    newScale = Handles.ScaleHandle(size, pos, rot, HandleUtility.GetHandleSize(pos));
                    break;
                    
                default:
                    // Show all handles when tool is None or other
                    newPos = Handles.PositionHandle(pos, rot);
                    newRot = Handles.RotationHandle(rot, pos);
                    newScale = Handles.ScaleHandle(size, pos, rot, HandleUtility.GetHandleSize(pos));
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Transform Box");
                
                if (newPos != pos)
                    m_Target.BoxPosition = newPos;
                
                if (newRot != rot)
                    m_Target.BoxRotationQuat = newRot;
                
                if (newScale != size)
                {
                    newScale = new Vector3(
                        Mathf.Max(0.01f, newScale.x),
                        Mathf.Max(0.01f, newScale.y),
                        Mathf.Max(0.01f, newScale.z));
                    m_Target.BoxSize = newScale;
                }
                
                EditorUtility.SetDirty(m_Target);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Target.BoxPosition;
            Vector3 size = m_Target.BoxSize;
            Quaternion rot = m_Target.BoxRotationQuat;
            
            // Get colors from target
            Color boxColor = m_Target.HasCopiedData ? new Color(0f, 0.8f, 1f, 1f) : m_Target.BoxColor;
            float alpha = m_Target.BoxAlpha;
            
            // Draw solid 3D box with rotation
            DrawSolid3DBoxRotated(pos, size, rot, boxColor, alpha);
            
            // Draw wireframe on top
            Handles.color = boxColor;
            DrawWireCubeRotated(pos, size, rot);
            
            // Draw source box if copied
            if (m_Target.HasCopiedData)
            {
                Color sourceColor = new Color(1f, 0.5f, 0f, 1f);
                DrawSolid3DBox(m_Target.CopiedSourcePosition, m_Target.CopiedBoxSize, sourceColor, alpha * 0.7f);
                
                Handles.color = sourceColor;
                Handles.DrawWireCube(m_Target.CopiedSourcePosition, m_Target.CopiedBoxSize);
                
                Handles.color = Color.yellow;
                Handles.DrawLine(m_Target.CopiedSourcePosition, pos);
                
                Vector3 offset = pos - m_Target.CopiedSourcePosition;
                Vector3 midPoint = (m_Target.CopiedSourcePosition + pos) / 2f;
                
                GUIStyle labelStyle = new GUIStyle();
                labelStyle.normal.textColor = Color.yellow;
                labelStyle.fontSize = 12;
                labelStyle.fontStyle = FontStyle.Bold;
                Handles.Label(midPoint + Vector3.up * 0.1f, $"Offset: {offset.magnitude:F2}m\nV=Paste", labelStyle);
            }
            
            // Instructions at box
            GUIStyle instructionStyle = new GUIStyle();
            instructionStyle.normal.textColor = Color.white;
            instructionStyle.fontSize = 11;
            string toolName = Tools.current == Tool.Move ? "MOVE" : 
                              Tools.current == Tool.Rotate ? "ROTATE" : 
                              Tools.current == Tool.Scale ? "SCALE" : "ALL";
            string controls = m_Target.HasCopiedData 
                ? $"C=Copy | Del=Delete | V=Paste | X=Del&Paste | W/E/R={toolName}"
                : $"C=Copy | Del=Delete | W/E/R={toolName}";
            Handles.Label(pos + Vector3.up * (size.y * 0.5f + 0.1f), controls, instructionStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawSolid3DBox(Vector3 center, Vector3 size, Color color, float alpha)
        {
            DrawSolid3DBoxRotated(center, size, Quaternion.identity, color, alpha);
        }
        
        private void DrawSolid3DBoxRotated(Vector3 center, Vector3 size, Quaternion rotation, Color color, float alpha)
        {
            Vector3 half = size * 0.5f;
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            // 8 corners of the box (rotated)
            Vector3 c0 = center + rotation * new Vector3(-half.x, -half.y, -half.z);
            Vector3 c1 = center + rotation * new Vector3(half.x, -half.y, -half.z);
            Vector3 c2 = center + rotation * new Vector3(half.x, -half.y, half.z);
            Vector3 c3 = center + rotation * new Vector3(-half.x, -half.y, half.z);
            Vector3 c4 = center + rotation * new Vector3(-half.x, half.y, -half.z);
            Vector3 c5 = center + rotation * new Vector3(half.x, half.y, -half.z);
            Vector3 c6 = center + rotation * new Vector3(half.x, half.y, half.z);
            Vector3 c7 = center + rotation * new Vector3(-half.x, half.y, half.z);
            
            // Draw 6 faces
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c1, c2, c3 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c4, c5, c6, c7 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c3, c2, c6, c7 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c1, c5, c4 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c3, c7, c4 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c1, c2, c6, c5 }, fillColor, outlineColor);
        }
        
        private void DrawWireCubeRotated(Vector3 center, Vector3 size, Quaternion rotation)
        {
            Vector3 half = size * 0.5f;
            
            Vector3 c0 = center + rotation * new Vector3(-half.x, -half.y, -half.z);
            Vector3 c1 = center + rotation * new Vector3(half.x, -half.y, -half.z);
            Vector3 c2 = center + rotation * new Vector3(half.x, -half.y, half.z);
            Vector3 c3 = center + rotation * new Vector3(-half.x, -half.y, half.z);
            Vector3 c4 = center + rotation * new Vector3(-half.x, half.y, -half.z);
            Vector3 c5 = center + rotation * new Vector3(half.x, half.y, -half.z);
            Vector3 c6 = center + rotation * new Vector3(half.x, half.y, half.z);
            Vector3 c7 = center + rotation * new Vector3(-half.x, half.y, half.z);
            
            // Bottom
            Handles.DrawLine(c0, c1); Handles.DrawLine(c1, c2);
            Handles.DrawLine(c2, c3); Handles.DrawLine(c3, c0);
            // Top
            Handles.DrawLine(c4, c5); Handles.DrawLine(c5, c6);
            Handles.DrawLine(c6, c7); Handles.DrawLine(c7, c4);
            // Verticals
            Handles.DrawLine(c0, c4); Handles.DrawLine(c1, c5);
            Handles.DrawLine(c2, c6); Handles.DrawLine(c3, c7);
        }
    }
    
    [EditorTool("Splat Xcopy Tool", typeof(GaussianSplatBoxBrush))]
    public class GaussianSplatBoxBrushTool : EditorTool
    {
        private GaussianSplatBoxBrush m_Brush;
#pragma warning disable CS0414 // assigned for future use
        private bool m_NavigationMode = false;
#pragma warning restore CS0414

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("d_SceneViewTools").image,
            "Splat Xcopy Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatBoxBrush;
            GaussianSplatBoxBrush.IsBrushModeActive = true;
            m_NavigationMode = false;
        }
        
        private void OnDisable()
        {
            GaussianSplatBoxBrush.IsBrushModeActive = false;
            GaussianSplatBoxBrush.HasValidBrushPosition = false;
            m_NavigationMode = false;
            
            // Reset paint selections when tool is deactivated
            if (m_Brush != null)
            {
                m_Brush.ResetPaintSelections();
            }
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            // Middle mouse button exits tool
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                GaussianSplatBoxBrush.IsBrushModeActive = false;
                GaussianSplatBoxBrush.HasValidBrushPosition = false;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatBoxBrush.IsBrushModeActive = true;
            
            if (m_Brush.BrushMode == BoxBrushMode.Planar)
            {
                HandleToolPlanarMode(sceneView, e);
            }
            else if (m_Brush.BrushMode == BoxBrushMode.PaintSelection)
            {
                HandleToolPaintSelectionMode(sceneView, e);
            }
            else
            {
                DrawToolBox(sceneView);
                DrawToolPreview(sceneView);
            }
            
            // Tool hotkeys (only for Box3D mode)
            if (m_Brush.BrushMode == BoxBrushMode.Box3D)
            {
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.W)
                {
                    Tools.current = Tool.Move;
                    e.Use();
                }
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.E)
                {
                    Tools.current = Tool.Rotate;
                    e.Use();
                }
                if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.R))
                {
                    Tools.current = Tool.Scale;
                    e.Use();
                }
            }
            
            // Mode-specific hotkeys
            if (m_Brush.BrushMode == BoxBrushMode.PaintSelection)
            {
                // C to copy selection with camera orientation
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.C)
                {
                    Camera cam = sceneView.camera;
                    m_Brush.CopySelectionWithOrientation(cam.transform.forward, cam.transform.up);
                    e.Use();
                }
                
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.V)
                {
                    if (m_Brush.CanPasteSelection)
                        m_Brush.PasteSelection();
                    e.Use();
                }
                
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
                {
                    if (m_Brush.HasSelection)
                        m_Brush.DeleteSelection();
                    e.Use();
                }
                
                // T to toggle between Source and Target painting mode
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.T && !e.control && !e.shift && !e.alt)
                {
                    Undo.RecordObject(m_Brush, "Toggle Paint Mode");
                    m_Brush.PaintingTargetMode = !m_Brush.PaintingTargetMode;
                    EditorUtility.SetDirty(m_Brush);
                    e.Use();
                }
                
                // G to toggle between Paint and Transform mode
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.G && !e.control && !e.shift && !e.alt)
                {
                    Undo.RecordObject(m_Brush, "Toggle Transform Mode");
                    m_Brush.TransformModeActive = !m_Brush.TransformModeActive;
                    if (m_Brush.TransformModeActive)
                        Tools.current = Tool.Move;
                    EditorUtility.SetDirty(m_Brush);
                    e.Use();
                }
                
                // Tool hotkeys for adjusting pasted splats (W/E/R) - only when transform mode is active
                if (m_Brush.ShowTransformHandles)
                {
                    if (e.type == EventType.KeyDown && e.keyCode == KeyCode.W)
                    {
                        Tools.current = Tool.Move;
                        e.Use();
                    }
                    if (e.type == EventType.KeyDown && e.keyCode == KeyCode.E)
                    {
                        Tools.current = Tool.Rotate;
                        e.Use();
                    }
                    if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.R))
                    {
                        Tools.current = Tool.Scale;
                        e.Use();
                    }
                }
            }
            else
            {
                // Box/Planar mode hotkeys
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.C)
                {
                    m_Brush.CopySplats();
                    e.Use();
                }
                
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.V)
                {
                    if (m_Brush.CanPaste)
                        m_Brush.PasteSplats();
                    e.Use();
                }
                
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Delete)
                {
                    m_Brush.DeleteSplatsInBox();
                    e.Use();
                }
                
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.X)
                {
                    if (m_Brush.CanPaste)
                        m_Brush.DeleteAndPaste();
                    e.Use();
                }
            }

            // Only grab default control if NOT adjusting pasted splats (let handles receive input)
            bool adjustingPastedSplats = m_Brush.BrushMode == BoxBrushMode.PaintSelection && m_Brush.ShowTransformHandles;
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (!adjustingPastedSplats)
            {
                HandleUtility.AddDefaultControl(controlID);
                if (e.type == EventType.Layout)
                    HandleUtility.AddDefaultControl(controlID);
            }
            
            sceneView.Repaint();
        }
        
        private void HandleToolPlanarMode(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Plane floorPlane = new Plane(Vector3.up, new Vector3(0, m_Brush.FloorY, 0));
            Vector3 hitPoint = Vector3.zero;
            if (floorPlane.Raycast(ray, out float enter))
                hitPoint = ray.GetPoint(enter);
            else
                hitPoint = ray.origin + ray.direction * 10f;
            
            DrawToolPlanarPreview(sceneView, hitPoint);
            
            // Only handle mouse events, let keyboard pass through for scene navigation
            if (e.type == EventType.MouseDown && e.button == 0 && !e.alt && !e.shift && !e.control)
            {
                Undo.RecordObject(m_Brush, "Start Planar Draw");
                m_Brush.StartPlanarDrag(hitPoint);
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }
            else if (e.type == EventType.MouseDrag && e.button == 0 && m_Brush.IsDrawingPlanar)
            {
                m_Brush.UpdatePlanarDrag(hitPoint);
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }
            else if (e.type == EventType.MouseUp && e.button == 0 && m_Brush.IsDrawingPlanar)
            {
                m_Brush.UpdatePlanarDrag(hitPoint);
                m_Brush.EndPlanarDrag();
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }
        }
        
        private void HandleToolPaintSelectionMode(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Vector3 brushPos = GetToolBrushHitPoint(ray, sceneView);
            float brushRadius = m_Brush.SelectionBrushRadius;
            
            // Draw transform handles when transform mode is active, otherwise show brush
            if (m_Brush.ShowTransformHandles)
            {
                DrawToolPastedSplatsTransformHandles(sceneView);
            }
            else
            {
                // Draw brush preview when in paint mode
                DrawToolPaintSelectionBrush(sceneView, brushPos, brushRadius);
            }
            
            // Scroll wheel to resize brush
            if (e.type == EventType.ScrollWheel && !e.alt)
            {
                Undo.RecordObject(m_Brush, "Resize Selection Brush");
                float delta = -e.delta.y * 0.05f;
                m_Brush.SelectionBrushRadius = Mathf.Clamp(brushRadius + delta, 0.01f, 10f);
                EditorUtility.SetDirty(m_Brush);
                e.Use();
            }
            
            // Paint selection with left mouse button - DISABLED when transform mode is active
            if (!m_Brush.ShowTransformHandles)
            {
                bool isPainting = e.button == 0 && !e.alt;
                bool subtractMode = e.shift;
                
                if (e.type == EventType.MouseDown && isPainting)
                {
                    m_Brush.IsPaintingSelection = true;
                    PaintToolSelectionAtPoint(sceneView, e.mousePosition, brushPos, !subtractMode);
                    e.Use();
                }
                else if (e.type == EventType.MouseDrag && m_Brush.IsPaintingSelection)
                {
                    PaintToolSelectionAtPoint(sceneView, e.mousePosition, brushPos, !subtractMode);
                    e.Use();
                }
                else if (e.type == EventType.MouseUp && e.button == 0)
                {
                    m_Brush.IsPaintingSelection = false;
                    e.Use();
                }
            }
        }
        
        private void DrawToolPastedSplatsTransformHandles(SceneView sceneView)
        {
            Vector3 pivot = m_Brush.PastedSplatsPivot + m_Brush.PasteOffset;
            Quaternion rot = m_Brush.PastedSplatsRotation;
            float scale = m_Brush.PasteScaleAdjust;
            
            // Ensure a valid tool is selected for handles
            if (Tools.current != Tool.Move && Tools.current != Tool.Rotate && Tools.current != Tool.Scale)
            {
                Tools.current = Tool.Move;
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pivot;
            Quaternion newRot = rot;
            float newScale = scale;
            
            // Show handles based on Unity's current tool
            switch (Tools.current)
            {
                case Tool.Move:
                    newPos = Handles.PositionHandle(pivot, rot);
                    break;
                    
                case Tool.Rotate:
                    newRot = Handles.RotationHandle(rot, pivot);
                    break;
                    
                case Tool.Scale:
                    Vector3 scaleVec = Handles.ScaleHandle(Vector3.one * scale, pivot, rot, HandleUtility.GetHandleSize(pivot));
                    newScale = (scaleVec.x + scaleVec.y + scaleVec.z) / 3f;
                    break;
                    
                default:
                    newPos = Handles.PositionHandle(pivot, rot);
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Brush, "Adjust Pasted Splats");
                
                // Position changed - update offset
                if (newPos != pivot)
                {
                    Vector3 delta = newPos - pivot;
                    m_Brush.PasteOffset = m_Brush.PasteOffset + delta;
                }
                
                // Rotation changed
                if (newRot != rot)
                {
                    m_Brush.PasteRotationAdjust = newRot.eulerAngles;
                }
                
                // Scale changed
                if (Mathf.Abs(newScale - scale) > 0.001f)
                {
                    m_Brush.PasteScaleAdjust = Mathf.Max(0.1f, newScale);
                }
                
                EditorUtility.SetDirty(m_Brush);
            }
            
            // Draw visual indicator for pasted splats pivot
            Handles.color = Color.cyan;
            float handleSize = HandleUtility.GetHandleSize(pivot) * 0.15f;
            Handles.DrawWireCube(pivot, Vector3.one * handleSize);
            
            // Label showing current tool
            string toolName = Tools.current == Tool.Move ? "MOVE (W)" : 
                              Tools.current == Tool.Rotate ? "ROTATE (E)" : "SCALE (R)";
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = Color.cyan }, fontSize = 11, fontStyle = FontStyle.Bold };
            Handles.Label(pivot + Vector3.up * handleSize * 2f, $"Adjusting {m_Brush.LastPastedCount} splats | {toolName}", labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private Vector3 GetToolBrushHitPoint(Ray ray, SceneView sceneView)
        {
            Vector3 cameraPos = sceneView.camera.transform.position;
            Vector3 cameraForward = sceneView.camera.transform.forward;
            float pivotDistance = Vector3.Distance(cameraPos, sceneView.pivot);
            Vector3 pivotPoint = cameraPos + cameraForward * pivotDistance;
            
            Plane depthPlane = new Plane(-cameraForward, pivotPoint);
            if (depthPlane.Raycast(ray, out float planeDist) && planeDist > 0)
                return ray.GetPoint(planeDist);
            
            return ray.origin + ray.direction * pivotDistance;
        }
        
        private void PaintToolSelectionAtPoint(SceneView sceneView, Vector2 guiMousePos, Vector3 worldPos, bool addToSelection)
        {
            if (m_Brush.TargetRenderer == null) return;
            if (!m_Brush.TargetRenderer.HasValidAsset || !m_Brush.TargetRenderer.HasValidRenderSetup) return;

            Camera cam = sceneView.camera;
            // Convert world position to screen coords - WorldToScreenPoint has Y=0 at bottom, flip for GUI
            Vector3 screenPos = cam.WorldToScreenPoint(worldPos);
            Vector2 mousePx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);
            
            float dist = Vector3.Distance(cam.transform.position, worldPos);
            float screenHeight = cam.pixelHeight;
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * dist * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, screenHeight);
            float radiusPx = Mathf.Clamp(m_Brush.SelectionBrushRadius / Mathf.Max(1e-6f, worldPerPixel), 1f, 10000f);
            
            bool backfaceCulling = m_Brush.BackfaceCulling;
            
            // Check if we're in target painting mode
            if (m_Brush.PaintingTargetMode)
            {
                // Target mode: paint target selection (blue/cyan)
                m_Brush.TargetRenderer.TargetSelectionColor = m_Brush.TargetColor;
                m_Brush.TargetRenderer.EditSelectTargetSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: !addToSelection, backfaceCulling);
                m_Brush.BoxPosition = worldPos;
                // Pass camera orientation for alignment calculation
                m_Brush.SetTargetPaintPosition(worldPos, cam.transform.forward, cam.transform.up);
            }
            else
            {
                // Source mode: select splats
                m_Brush.TargetRenderer.SelectionColor = m_Brush.SelectionColor;
                m_Brush.TargetRenderer.EditSelectSplatsInScreenCircle(mousePx, radiusPx, cam, subtract: !addToSelection, backfaceCulling);
            }
        }
        
        private void DrawToolPaintSelectionBrush(SceneView sceneView, Vector3 position, float radius)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            bool isPaintingTarget = m_Brush.PaintingTargetMode;
            
            // Use appropriate color based on source/target mode
            Color baseColor = isPaintingTarget ? m_Brush.TargetColor : m_Brush.SelectionColor;
            Color brushColor, fillColor;
            
            if (isPaintingTarget)
            {
                // Target mode
                brushColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.95f);
                fillColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.3f);
            }
            else if (m_Brush.SelectionAddMode)
            {
                // Source add mode
                brushColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.9f);
                fillColor = new Color(baseColor.r, baseColor.g, baseColor.b, 0.2f);
            }
            else
            {
                // Source subtract mode
                brushColor = new Color(1f, 0.2f, 0.2f, 0.9f);
                fillColor = new Color(1f, 0.2f, 0.2f, 0.2f);
            }
            
            // Draw filled disc facing camera
            Vector3 camForward = sceneView.camera.transform.forward;
            Handles.color = fillColor;
            Handles.DrawSolidDisc(position, camForward, radius);
            
            // Draw outline
            Handles.color = brushColor;
            Handles.DrawWireDisc(position, camForward, radius);
            Handles.DrawWireDisc(position, camForward, radius * 0.95f);
            
            // Info label
            GUIStyle labelStyle = new GUIStyle { normal = { textColor = baseColor }, fontSize = 11, fontStyle = FontStyle.Bold };
            string modeLabel = isPaintingTarget ? "TARGET" : (m_Brush.SelectionAddMode ? "+" : "-");
            string info = isPaintingTarget ? "TARGET" : $"{modeLabel} [{m_Brush.SelectedSplatCount}]";
            Handles.Label(position + Vector3.up * (radius + 0.05f), info, labelStyle);
            
            // Draw target position crosshair if we have target splats painted
            if (m_Brush.HasCopiedSelection || m_Brush.HasTargetSelection)
            {
                // Use actual center of painted target splats if available
                Vector3 targetPos = m_Brush.HasTargetSelection && m_Brush.TargetRenderer != null
                    ? m_Brush.TargetRenderer.GetTargetSelectedSplatsCenter()
                    : m_Brush.BoxPosition;
                Color targetColor = m_Brush.TargetColor;
                
                Handles.color = new Color(targetColor.r, targetColor.g, targetColor.b, 0.95f);
                float crossSize = 0.15f;
                Handles.DrawLine(targetPos - Vector3.right * crossSize, targetPos + Vector3.right * crossSize);
                Handles.DrawLine(targetPos - Vector3.up * crossSize, targetPos + Vector3.up * crossSize);
                Handles.DrawLine(targetPos - Vector3.forward * crossSize, targetPos + Vector3.forward * crossSize);
                
                Handles.DrawWireDisc(targetPos, Vector3.up, 0.1f);
                Handles.DrawWireDisc(targetPos, Vector3.forward, 0.1f);
                Handles.DrawWireDisc(targetPos, Vector3.right, 0.1f);
                
                GUIStyle targetLabelStyle = new GUIStyle { normal = { textColor = targetColor }, fontSize = 11, fontStyle = FontStyle.Bold };
                string targetLabel = m_Brush.HasTargetSelection ? "PASTE HERE" : "TARGET";
                Handles.Label(targetPos + Vector3.up * 0.2f, targetLabel, targetLabelStyle);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawToolPlanarPreview(SceneView sceneView, Vector3 cursorPos)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Brush.PlanarBoxPosition;
            Vector3 size = m_Brush.PlanarBoxSize;
            
            Color boxColor = m_Brush.HasCopiedData ? new Color(0f, 0.8f, 1f, 1f) : m_Brush.BoxColor;
            float alpha = m_Brush.BoxAlpha;
            
            DrawSolid3DBoxToolRotated(pos, size, Quaternion.identity, boxColor, alpha);
            Handles.color = boxColor;
            Handles.DrawWireCube(pos, size);
            
            // Cursor
            Handles.color = Color.yellow;
            Handles.DrawWireDisc(cursorPos, Vector3.up, 0.1f);
            
            if (m_Brush.HasCopiedData)
            {
                Color sourceColor = new Color(1f, 0.5f, 0f, 1f);
                DrawSolid3DBoxToolRotated(m_Brush.CopiedSourcePosition, m_Brush.CopiedBoxSize, Quaternion.identity, sourceColor, alpha * 0.7f);
                
                Handles.color = sourceColor;
                Handles.DrawWireCube(m_Brush.CopiedSourcePosition, m_Brush.CopiedBoxSize);
                
                Handles.color = Color.yellow;
                Handles.DrawLine(m_Brush.CopiedSourcePosition, pos);
            }
            
            // Position handle when not drawing
            if (!m_Brush.IsDrawingPlanar)
            {
                EditorGUI.BeginChangeCheck();
                Vector3 newPos = Handles.PositionHandle(pos, Quaternion.identity);
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(m_Brush, "Move Planar Rect");
                    m_Brush.PlanarPosition = new Vector2(newPos.x, newPos.z);
                    m_Brush.FloorY = newPos.y;
                }
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawToolBox(SceneView sceneView)
        {
            Vector3 pos = m_Brush.BoxPosition;
            Vector3 size = m_Brush.BoxSize;
            Quaternion rot = m_Brush.BoxRotationQuat;
            
            EditorGUI.BeginChangeCheck();
            
            Vector3 newPos = pos;
            Quaternion newRot = rot;
            Vector3 newScale = size;
            
            switch (Tools.current)
            {
                case Tool.Move:
                    newPos = Handles.PositionHandle(pos, rot);
                    break;
                    
                case Tool.Rotate:
                    newRot = Handles.RotationHandle(rot, pos);
                    break;
                    
                case Tool.Scale:
                    newScale = Handles.ScaleHandle(size, pos, rot, HandleUtility.GetHandleSize(pos));
                    break;
                    
                default:
                    newPos = Handles.PositionHandle(pos, rot);
                    newRot = Handles.RotationHandle(rot, pos);
                    newScale = Handles.ScaleHandle(size, pos, rot, HandleUtility.GetHandleSize(pos));
                    break;
            }
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Brush, "Transform Box");
                
                if (newPos != pos)
                    m_Brush.BoxPosition = newPos;
                
                if (newRot != rot)
                    m_Brush.BoxRotationQuat = newRot;
                
                if (newScale != size)
                {
                    newScale = new Vector3(
                        Mathf.Max(0.01f, newScale.x),
                        Mathf.Max(0.01f, newScale.y),
                        Mathf.Max(0.01f, newScale.z));
                    m_Brush.BoxSize = newScale;
                }
            }
        }
        
        private void DrawToolPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            Vector3 pos = m_Brush.BoxPosition;
            Vector3 size = m_Brush.BoxSize;
            Quaternion rot = m_Brush.BoxRotationQuat;
            
            Color boxColor = m_Brush.HasCopiedData ? new Color(0f, 0.8f, 1f, 1f) : m_Brush.BoxColor;
            float alpha = m_Brush.BoxAlpha;
            
            DrawSolid3DBoxToolRotated(pos, size, rot, boxColor, alpha);
            Handles.color = boxColor;
            DrawWireCubeToolRotated(pos, size, rot);
            
            if (m_Brush.HasCopiedData)
            {
                Color sourceColor = new Color(1f, 0.5f, 0f, 1f);
                DrawSolid3DBoxToolRotated(m_Brush.CopiedSourcePosition, m_Brush.CopiedBoxSize, Quaternion.identity, sourceColor, alpha * 0.7f);
                
                Handles.color = sourceColor;
                Handles.DrawWireCube(m_Brush.CopiedSourcePosition, m_Brush.CopiedBoxSize);
                
                Handles.color = Color.yellow;
                Handles.DrawLine(m_Brush.CopiedSourcePosition, pos);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
        
        private void DrawSolid3DBoxToolRotated(Vector3 center, Vector3 size, Quaternion rotation, Color color, float alpha)
        {
            Vector3 half = size * 0.5f;
            Color fillColor = new Color(color.r, color.g, color.b, alpha);
            Color outlineColor = new Color(color.r, color.g, color.b, alpha * 2f);
            
            Vector3 c0 = center + rotation * new Vector3(-half.x, -half.y, -half.z);
            Vector3 c1 = center + rotation * new Vector3(half.x, -half.y, -half.z);
            Vector3 c2 = center + rotation * new Vector3(half.x, -half.y, half.z);
            Vector3 c3 = center + rotation * new Vector3(-half.x, -half.y, half.z);
            Vector3 c4 = center + rotation * new Vector3(-half.x, half.y, -half.z);
            Vector3 c5 = center + rotation * new Vector3(half.x, half.y, -half.z);
            Vector3 c6 = center + rotation * new Vector3(half.x, half.y, half.z);
            Vector3 c7 = center + rotation * new Vector3(-half.x, half.y, half.z);
            
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c1, c2, c3 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c4, c5, c6, c7 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c3, c2, c6, c7 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c1, c5, c4 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c0, c3, c7, c4 }, fillColor, outlineColor);
            Handles.DrawSolidRectangleWithOutline(new Vector3[] { c1, c2, c6, c5 }, fillColor, outlineColor);
        }
        
        private void DrawWireCubeToolRotated(Vector3 center, Vector3 size, Quaternion rotation)
        {
            Vector3 half = size * 0.5f;
            
            Vector3 c0 = center + rotation * new Vector3(-half.x, -half.y, -half.z);
            Vector3 c1 = center + rotation * new Vector3(half.x, -half.y, -half.z);
            Vector3 c2 = center + rotation * new Vector3(half.x, -half.y, half.z);
            Vector3 c3 = center + rotation * new Vector3(-half.x, -half.y, half.z);
            Vector3 c4 = center + rotation * new Vector3(-half.x, half.y, -half.z);
            Vector3 c5 = center + rotation * new Vector3(half.x, half.y, -half.z);
            Vector3 c6 = center + rotation * new Vector3(half.x, half.y, half.z);
            Vector3 c7 = center + rotation * new Vector3(-half.x, half.y, half.z);
            
            Handles.DrawLine(c0, c1); Handles.DrawLine(c1, c2);
            Handles.DrawLine(c2, c3); Handles.DrawLine(c3, c0);
            Handles.DrawLine(c4, c5); Handles.DrawLine(c5, c6);
            Handles.DrawLine(c6, c7); Handles.DrawLine(c7, c4);
            Handles.DrawLine(c0, c4); Handles.DrawLine(c1, c5);
            Handles.DrawLine(c2, c6); Handles.DrawLine(c3, c7);
        }
    }
}
