// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [DrawGizmo(GizmoType.NonSelected | GizmoType.Selected, typeof(GaussianPolyMask))]
    public static class GaussianPolyMaskGizmo
    {
        public static void OnDrawGizmos(GaussianPolyMask poly, GizmoType gizmoType)
        {
            if (poly == null) return;
            var drawVerts = poly.GetDisplayVertices();
            if (drawVerts == null || drawVerts.Count == 0) return;

            Gizmos.matrix = poly.transform.localToWorldMatrix;
            Color color = Color.cyan;
            color.a = 0.2f;
            if (Selection.Contains(poly.gameObject))
                color.a = 0.9f;
            else
            {
                var activeGo = Selection.activeGameObject;
                if (activeGo != null)
                {
                    var activeSplat = activeGo.GetComponent<SplatBoxRenderer>();
                    if (activeSplat != null && activeSplat.m_Cutouts != null)
                    {
                        foreach (var cutout in activeSplat.m_Cutouts)
                        {
                            if (cutout == poly) { color.a = 0.5f; break; }
                        }
                    }
                }
            }
            Gizmos.color = color;

            for (int i = 0; i < drawVerts.Count; i++)
            {
                int next = (i + 1) % drawVerts.Count;
                if (poly.IsClosed || i < drawVerts.Count - 1)
                    Gizmos.DrawLine(drawVerts[i], drawVerts[next]);
            }
            color.a = 1.0f;
            Gizmos.color = color;
            foreach (var v in drawVerts)
                Gizmos.DrawWireSphere(v, 0.05f);

            if (poly.IsClosed)
            {
                color.a = 0.15f;
                Gizmos.color = color;
                uint axis = poly.EffectiveExtrusionAxis;
                Vector3 extrudeDir = axis == 1 ? Vector3.right : (axis == 2 ? Vector3.up : Vector3.forward);
                Vector3 depthFwd = extrudeDir * poly.CutDepth;
                Vector3 depthBack = -extrudeDir * poly.CutDepth;
                for (int i = 0; i < drawVerts.Count; i++)
                    Gizmos.DrawLine(drawVerts[i] + depthBack, drawVerts[i] + depthFwd);
            }
        }
    }
}
