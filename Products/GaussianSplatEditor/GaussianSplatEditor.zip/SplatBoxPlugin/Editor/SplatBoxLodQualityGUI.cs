// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    /// <summary>
    /// Paged-LoD readout and quality diagnosis, shared by the renderer inspector and the SplatBox
    /// editor window so the two cannot drift apart. Drawing is separated from writing: these methods
    /// report what the user asked for and each caller applies it in its own idiom (SerializedProperty
    /// in the inspector, SerializedObject in the window).
    /// </summary>
    static class SplatBoxLodQualityGUI
    {
        public static readonly GUIContent qualitySliderLabel = new GUIContent("Quality",
            "How much detail the scene keeps into the distance. Higher values raise the splat " +
            "budget and refine to finer screen sizes before stopping; lower values are faster. " +
            "1 = best quality this system can deliver.");

        /// <summary>Concrete numbers behind a Quality value, shown under the slider.</summary>
        public static string QualitySummary(float quality) =>
            $"{SplatBoxRenderer.LodQualityToBudget(quality):N0} splat budget \u00b7 refine to " +
            $"\u2248{SplatBoxRenderer.LodQualityToPixelCutoff(quality):0.0} px";

        /// <summary>
        /// Simple-mode Quality slider for callers without an already-bound SerializedObject, such
        /// as the SplatBox tool window.
        /// </summary>
        public static void DrawQualitySlider(SplatBoxRenderer gs)
        {
            if (gs == null)
                return;

            var so = new SerializedObject(gs);
            var quality = so.FindProperty(SplatBoxRenderer.kPropLodQuality);
            if (quality == null)
                return;

            EditorGUI.BeginChangeCheck();
            EditorGUILayout.Slider(quality, 0f, 1f, qualitySliderLabel);
            EditorGUILayout.LabelField(" ", QualitySummary(quality.floatValue), EditorStyles.miniLabel);
            if (EditorGUI.EndChangeCheck())
            {
                so.ApplyModifiedProperties();
                SceneView.RepaintAll();
            }
        }

        public static void DrawStats(SplatBoxRenderer gs)
        {
            int totalPages = gs.pagedScene != null ? gs.pagedScene.pageCount : 0;
            int loadedPages = gs.lodStreamer != null ? gs.lodStreamer.loadedPages.Count : 0;

            EditorGUILayout.LabelField("Scene Splats", $"{gs.pagedSceneSplatCount:N0}");
            EditorGUILayout.LabelField("Active Splats", $"{gs.activeSplatCount:N0} / {gs.EffectiveLodBudget:N0} budget");
            EditorGUILayout.LabelField("Pages", $"{loadedPages} loaded / {totalPages} total");
            EditorGUILayout.LabelField("Full Detail Pages", gs.detailPageCount.ToString());
            EditorGUILayout.LabelField("Detail Cutoff", $"{gs.currentLodPixelScaleLimit:0.0} px");
            EditorGUILayout.LabelField("Selection",
                $"{gs.lastLodLeafCount:N0} leaves / {gs.lastLodMergedCount:N0} merged / " +
                $"{gs.lastLodMergedDropCount:N0} dropped");
            EditorGUILayout.LabelField(
                new GUIContent("CPU Cost",
                    "Main-thread time the paged LoD system spends per update. Selection runs whenever " +
                    "the view moves, so it is felt as frame time; the atlas rebuild only runs when " +
                    "pages stream in or out. If both are small and the editor is still slow, the cost " +
                    "is GPU-side fill rate rather than this system."),
                new GUIContent($"{gs.lastLodSelectMs:0.0} ms select / {gs.lastLodAtlasMs:0.0} ms atlas"));
        }

        /// <summary>
        /// Explains why a paged scene is drawing coarse stand-ins instead of real splats. The usual
        /// cause is a quality setting left over from performance tuning rather than anything about the
        /// scene, and the symptom (soft blobs in roughly the right places, with washed-out colour) is
        /// easy to mistake for broken data.
        /// </summary>
        /// <returns>True when the user asked for the quality knobs to be put back to full.</returns>
        public static bool DrawDiagnosis(SplatBoxRenderer gs, float pixelScaleLimit, float detailScale,
            bool simpleMode)
        {
            int active = gs.activeSplatCount;
            int budget = gs.EffectiveLodBudget;

            bool coarseDominates = gs.lastLodMergedCount > gs.lastLodLeafCount;
            bool budgetUnspent = budget > 0 && active < budget * 0.9f;
            bool throttled = pixelScaleLimit > 0.01f || detailScale < 0.99f;
            float requestedCutoff = (pixelScaleLimit > 0.01f ? pixelScaleLimit : 1f) /
                                    Mathf.Max(0.01f, detailScale);
            bool budgetLimited =
                budget > 0 &&
                active >= budget * 0.98f &&
                gs.currentLodPixelScaleLimit > requestedCutoff * 1.25f;

            if (gs.hasMismatchedLodSplatOrder)
            {
                EditorGUILayout.HelpBox(
                    "This paged scene uses an older broken export: the LoD tree and splat payload " +
                    "were saved in different orders. It cannot render the correct positions, sizes, " +
                    "or colours. Rebuild it with Tools > Gaussian Splatting > Create Paged LoD Scene.",
                    MessageType.Error);
            }

            DrawPageSizeWarning(gs);

            if (budgetLimited)
            {
                EditorGUILayout.HelpBox(simpleMode
                        ? $"The splat budget is full ({active:N0} / {budget:N0}), so close-up detail " +
                          $"stops at {gs.currentLodPixelScaleLimit:0.0} px instead of the requested " +
                          $"{requestedCutoff:0.0} px. Raise Quality to allow more."
                        : $"The LoD budget is full ({active:N0} / {budget:N0}). This view requested roughly " +
                          $"{requestedCutoff:0.0} px detail, but refinement ran out of slots at " +
                          $"{gs.currentLodPixelScaleLimit:0.0} px. Raise LoD Splat Budget to allow close-up " +
                          "detail; distant views will still stop early at the requested pixel cutoff.",
                    MessageType.Warning);
                return false;
            }

            // Simple mode has no knobs to explain: a low slider is a deliberate trade, so only a view
            // dominated by stand-in blobs is worth a warning, and the fix is always the same slider.
            if (simpleMode)
            {
                if (!coarseDominates)
                    return false;

                bool canRaise = gs.lodQuality < 0.999f;
                EditorGUILayout.HelpBox(canRaise
                        ? "Most of what is drawn right now is merged stand-ins rather than real " +
                          "splats. Raise Quality, or wait a moment while detail pages stream in."
                        : "Most of the selection is merged stand-ins even at maximum Quality: the " +
                          "view needs more than the budget can hold, or the pages in view are stuck " +
                          "at coarse detail because no detail slots are free.",
                    MessageType.Warning);
                return canRaise && GUILayout.Button("Set Quality to Maximum");
            }

            if (!coarseDominates && !throttled)
                return false;

            if (coarseDominates && throttled && budgetUnspent)
            {
                // Refinement stopped while the budget still had room, so neither the scene nor the
                // memory budget is the limit here — the quality knobs are.
                EditorGUILayout.HelpBox(
                    $"Refinement is stopping early: {active:N0} of {budget:N0} splats are in use and most " +
                    "of them are merged stand-ins, so you are looking at approximated blobs instead of " +
                    $"real splats. Pixel Scale Limit {pixelScaleLimit:0.00} and LoD Detail Scale " +
                    $"{detailScale:0.00} are cutting detail off before the budget runs out. Use 0 and 1 " +
                    "for full quality.",
                    MessageType.Warning);
            }
            else if (coarseDominates)
            {
                EditorGUILayout.HelpBox(
                    "Most of the selection is merged stand-ins rather than real splats. The budget is " +
                    "either far below what this view needs, or the pages in view are stuck at coarse " +
                    "quality because no detail slots are free.",
                    MessageType.Warning);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    (pixelScaleLimit > 0.01f
                        ? $"Pixel Scale Limit {pixelScaleLimit:0.00} stops refinement early. "
                        : "") +
                    (detailScale < 0.99f
                        ? $"LoD Detail Scale {detailScale:0.00} refines as if the scene were smaller on screen. "
                        : "") +
                    "Both cost quality; use 0 and 1 respectively for full detail.",
                    MessageType.Info);
            }

            return throttled && GUILayout.Button("Restore Full LoD Quality");
        }

        /// <summary>
        /// Detail slots are uniform and sized for the largest page in the scene, so a single oversized
        /// page makes every slot expensive and cuts how many fit in the atlas. That trade is invisible
        /// from the settings, so it is worth calling out with the numbers behind it.
        /// </summary>
        static void DrawPageSizeWarning(SplatBoxRenderer gs)
        {
            var scene = gs.pagedScene;
            int slotSplats = gs.lodAtlasSlotSplats;
            if (scene == null || scene.pageCount == 0 || slotSplats <= 0)
                return;

            int average = Mathf.Max(1, gs.pagedSceneSplatCount / scene.pageCount);
            if (slotSplats < average * 2)
                return;

            int slots = gs.lodAtlasDetailSlots;
            int wouldFit = slots * slotSplats / average;
            EditorGUILayout.HelpBox(
                $"Page sizes are uneven: every detail slot reserves {slotSplats:N0} splats to fit the " +
                $"largest page, while the average page needs only {average:N0}. That is why the atlas " +
                $"holds {slots} full-detail pages instead of roughly {wouldFit}. Rebuilding with a " +
                "smaller Max Splats Per Page gives more slots for the same memory, so detail follows " +
                "the camera more closely.",
                MessageType.Info);
        }

        /// <summary>
        /// Writes the full-quality values straight onto the renderer. Used where no SerializedObject
        /// is already bound, such as the editor window.
        /// </summary>
        public static void RestoreFullQuality(SplatBoxRenderer gs)
        {
            if (gs == null)
                return;

            var so = new SerializedObject(gs);
            if (gs.lodSimpleMode)
            {
                var quality = so.FindProperty(SplatBoxRenderer.kPropLodQuality);
                if (quality != null)
                    quality.floatValue = 1f;
            }
            else
            {
                var limit = so.FindProperty(SplatBoxRenderer.kPropLodPixelScaleLimit);
                var scale = so.FindProperty(SplatBoxRenderer.kPropLodDetailScale);
                var standIn = so.FindProperty("m_LodMaxStandInPixels");
                if (limit != null)
                    limit.floatValue = 0f;
                if (scale != null)
                    scale.floatValue = 1f;
                if (standIn != null)
                    standIn.floatValue = SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels;
            }
            so.ApplyModifiedProperties();
            SceneView.RepaintAll();
        }

        /// <summary>
        /// Restores every paged LoD knob to the field defaults: Simple mode at Quality 0.5, and the
        /// matching Advanced values underneath so switching modes after a reset stays coherent.
        /// </summary>
        public static void ResetLodSettings(SplatBoxRenderer gs)
        {
            if (gs == null)
                return;

            Undo.RecordObject(gs, "Reset LoD Settings");
            var so = new SerializedObject(gs);
            ApplyLodSettingDefaults(so);
            so.ApplyModifiedProperties();
            EditorUtility.SetDirty(gs);
            SceneView.RepaintAll();
        }

        /// <summary>
        /// Writes the field-default LoD values into an already-bound SerializedObject. Callers must
        /// ApplyModifiedProperties afterwards.
        /// </summary>
        public static void ApplyLodSettingDefaults(SerializedObject so)
        {
            if (so == null)
                return;

            SetBool(so, SplatBoxRenderer.kPropLodSimpleMode, true);
            SetFloat(so, SplatBoxRenderer.kPropLodQuality, 0.5f);
            SetInt(so, "m_LodSplatBudget", 500_000);
            SetBool(so, "m_LodFastEditorPreview", true);
            SetFloat(so, SplatBoxRenderer.kPropLodPixelScaleLimit, 0f);
            SetFloat(so, SplatBoxRenderer.kPropLodDetailScale, 1f);
            SetBool(so, "m_LodFrustumCull", true);
            SetBool(so, SplatBoxRenderer.kPropLodDrawCoarseStandIns, true);
            SetFloat(so, "m_LodMaxStandInPixels",
                SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels); // 512: keep whole scene filled
            SetFloat(so, "m_LodCullPaddingDeg", 10f);
            SetInt(so, "m_LodAtlasBudgetMB", 1024);
            SetFloat(so, "m_OutsideFoveate", 0.4f);
            SetFloat(so, "m_BehindFoveate", 0.2f);
        }

        static void SetBool(SerializedObject so, string name, bool value)
        {
            var p = so.FindProperty(name);
            if (p != null) p.boolValue = value;
        }

        static void SetFloat(SerializedObject so, string name, float value)
        {
            var p = so.FindProperty(name);
            if (p != null) p.floatValue = value;
        }

        static void SetInt(SerializedObject so, string name, int value)
        {
            var p = so.FindProperty(name);
            if (p != null) p.intValue = value;
        }

        public static void SetDrawCoarseStandIns(SplatBoxRenderer gs, bool draw)
        {
            if (gs == null)
                return;

            var so = new SerializedObject(gs);
            var prop = so.FindProperty(SplatBoxRenderer.kPropLodDrawCoarseStandIns);
            if (prop == null)
                return;
            prop.boolValue = draw;
            so.ApplyModifiedProperties();
            SceneView.RepaintAll();
        }
    }
}
