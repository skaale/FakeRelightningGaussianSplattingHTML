// SPDX-License-Identifier: MIT

// The Overlay/Toolbar API (UnityEditor.Overlays, UnityEditor.Toolbars) requires Unity 2022.1+.
// Without this guard, precompiled DLLs built on 2022+ will fail to load on older Unity versions
// with: "Unable to resolve reference 'UnityEditor.EditorToolbarModule'"
#if UNITY_2022_1_OR_NEWER

using UnityEngine;
using UnityEditor;
using UnityEditor.Overlays;
using UnityEditor.Toolbars;
using UnityEngine.UIElements;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [Overlay(typeof(SceneView), "Splat Editor", true)]
    [Icon("d_SceneViewTools")]
    public class GaussianSplatEditorOverlay : ToolbarOverlay
    {
        public GaussianSplatEditorOverlay() : base(
            SplatToolDropdown.k_Id,
            SplatQuickActions.k_Id,
            SplatStatusIndicator.k_Id
        ) { }
    }

    [EditorToolbarElement(k_Id, typeof(SceneView))]
    class SplatToolDropdown : EditorToolbarDropdown
    {
        public const string k_Id = "SplatEditor/ToolDropdown";
        
        private static readonly string[] s_ToolNames = { "None", "Erase", "Box", "Clone", "Floor", "Patch", "Mask" };
        private static int s_CurrentTool = 0;
        
        public SplatToolDropdown()
        {
            text = "🎨 Splat: None";
            tooltip = "Select a Gaussian Splat editing tool";
            clicked += ShowDropdown;
        }

        private void ShowDropdown()
        {
            var menu = new GenericMenu();
            
            for (int i = 0; i < s_ToolNames.Length; i++)
            {
                int idx = i;
                menu.AddItem(new GUIContent(s_ToolNames[i]), s_CurrentTool == i, () => SelectTool(idx));
            }
            
            menu.DropDown(worldBound);
        }

        private void SelectTool(int idx)
        {
            s_CurrentTool = idx;
            text = $"🎨 Splat: {s_ToolNames[idx]}";
            
            // Deactivate all
            GaussianSplatBrush.IsBrushModeActive = false;
            GaussianSplatBoxBrush.IsBrushModeActive = false;
            GaussianSplatCloneBrush.IsBrushModeActive = false;
            GaussianSplatFloorFillBrush.IsBrushModeActive = false;
            GaussianSplatPatchTool.IsBrushModeActive = false;
            
            // Activate selected
            switch (idx)
            {
                case 1: GaussianSplatBrush.IsBrushModeActive = true; break;
                case 2: GaussianSplatBoxBrush.IsBrushModeActive = true; break;
                case 3: GaussianSplatCloneBrush.IsBrushModeActive = true; break;
                case 4: GaussianSplatFloorFillBrush.IsBrushModeActive = true; break;
                case 5: GaussianSplatPatchTool.IsBrushModeActive = true; break;
            }
            
            SceneView.RepaintAll();
        }
        
        public static void SetTool(int idx)
        {
            s_CurrentTool = idx;
        }
        
        public static int GetCurrentTool() => s_CurrentTool;
    }

    [EditorToolbarElement(k_Id, typeof(SceneView))]
    class SplatQuickActions : VisualElement
    {
        public const string k_Id = "SplatEditor/QuickActions";

        public SplatQuickActions()
        {
            style.flexDirection = FlexDirection.Row;
            style.alignItems = Align.Center;
            
            var openWindowBtn = new Button(() => GaussianSplatEditorWindow.ShowWindow())
            {
                text = "📐",
                tooltip = "Open Splat Editor Window (Ctrl+Shift+G)"
            };
            openWindowBtn.style.width = 28;
            openWindowBtn.style.height = 22;
            Add(openWindowBtn);
            
            var focusBtn = new Button(FocusSplatRenderer)
            {
                text = "🎯",
                tooltip = "Focus on Splat Renderer in scene"
            };
            focusBtn.style.width = 28;
            focusBtn.style.height = 22;
            Add(focusBtn);
        }

        private void FocusSplatRenderer()
        {
            var renderer = Object.FindAnyObjectByType<SplatBoxRenderer>();
            if (renderer != null)
            {
                Selection.activeGameObject = renderer.gameObject;
                SceneView.FrameLastActiveSceneView();
            }
        }
    }

    [EditorToolbarElement(k_Id, typeof(SceneView))]
    class SplatStatusIndicator : VisualElement
    {
        public const string k_Id = "SplatEditor/StatusIndicator";
        
        private Label m_StatusLabel;
        private VisualElement m_StatusDot;

        public SplatStatusIndicator()
        {
            style.flexDirection = FlexDirection.Row;
            style.alignItems = Align.Center;
            style.marginLeft = 8;
            
            m_StatusDot = new VisualElement();
            m_StatusDot.style.width = 8;
            m_StatusDot.style.height = 8;
            m_StatusDot.style.borderTopLeftRadius = 4;
            m_StatusDot.style.borderTopRightRadius = 4;
            m_StatusDot.style.borderBottomLeftRadius = 4;
            m_StatusDot.style.borderBottomRightRadius = 4;
            m_StatusDot.style.marginRight = 4;
            m_StatusDot.style.backgroundColor = new StyleColor(Color.gray);
            Add(m_StatusDot);
            
            m_StatusLabel = new Label("Ready");
            m_StatusLabel.style.fontSize = 10;
            Add(m_StatusLabel);
            
            schedule.Execute(UpdateStatus).Every(200);
        }

        private void UpdateStatus()
        {
            bool anyActive = GaussianSplatBrush.IsBrushModeActive ||
                            GaussianSplatBoxBrush.IsBrushModeActive ||
                            GaussianSplatCloneBrush.IsBrushModeActive ||
                            GaussianSplatFloorFillBrush.IsBrushModeActive ||
                            GaussianSplatPatchTool.IsBrushModeActive;
            
            if (anyActive)
            {
                m_StatusDot.style.backgroundColor = new StyleColor(new Color(0.3f, 0.85f, 0.45f));
                
                if (GaussianSplatBrush.IsBrushModeActive)
                    m_StatusLabel.text = "Erase Active";
                else if (GaussianSplatBoxBrush.IsBrushModeActive)
                    m_StatusLabel.text = "Box Active";
                else if (GaussianSplatCloneBrush.IsBrushModeActive)
                    m_StatusLabel.text = "Clone Active";
                else if (GaussianSplatFloorFillBrush.IsBrushModeActive)
                    m_StatusLabel.text = "Floor Active";
                else if (GaussianSplatPatchTool.IsBrushModeActive)
                    m_StatusLabel.text = "Patch Active";
            }
            else
            {
                var renderer = Object.FindAnyObjectByType<SplatBoxRenderer>();
                if (renderer == null)
                {
                    m_StatusDot.style.backgroundColor = new StyleColor(new Color(0.95f, 0.65f, 0.25f));
                    m_StatusLabel.text = "No Renderer";
                }
                else
                {
                    m_StatusDot.style.backgroundColor = new StyleColor(Color.gray);
                    m_StatusLabel.text = "Ready";
                }
            }
        }
    }
}

#endif // UNITY_2022_1_OR_NEWER
