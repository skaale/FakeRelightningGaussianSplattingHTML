// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianSplatFloorFillBrush))]
    public class GaussianSplatFloorFillBrushEditor : UnityEditor.Editor
    {
        private GaussianSplatFloorFillBrush m_Target;
        private bool m_BrushMode = false;
        private bool m_NavigationMode = false;
        private Vector3 m_DragStart;
        private bool m_IsDragging = false;

        private void OnEnable()
        {
            m_Target = target as GaussianSplatFloorFillBrush;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_TargetRenderer"));
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Fill Region", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            Vector3 newCenter = EditorGUILayout.Vector3Field("Fill Center", m_Target.FillCenter);
            Vector2 newSize = EditorGUILayout.Vector2Field("Fill Size (XZ)", m_Target.FillSize);
            float newY = EditorGUILayout.FloatField("Floor Y", m_Target.FloorY);
            float newThick = EditorGUILayout.FloatField("Floor Thickness", m_Target.FloorThickness);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Floor Fill Settings");
                m_Target.FillCenter = newCenter;
                m_Target.FillSize = newSize;
                m_Target.FloorY = newY;
                m_Target.FloorThickness = newThick;
                m_Target.UpdateSampleRegions();
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Sample Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            var newMode = (GaussianSplatFloorFillBrush.SampleMode)EditorGUILayout.EnumPopup("Sample Mode", m_Target.CurrentSampleMode);
            float newEdgeWidth = EditorGUILayout.FloatField("Edge Width", m_Target.SampleEdgeWidth);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Sample Settings");
                m_Target.CurrentSampleMode = newMode;
                m_Target.SampleEdgeWidth = newEdgeWidth;
                m_Target.UpdateSampleRegions();
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Fill Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            Vector2 newTileSize = EditorGUILayout.Vector2Field("Tile Size", m_Target.TileSize);
            float newJitter = EditorGUILayout.Slider("Position Jitter", m_Target.PositionJitter, 0f, 0.3f);
            bool newRandomize = EditorGUILayout.Toggle("Randomize Tiles", m_Target.RandomizeTileSelection);
            bool newDeleteFirst = EditorGUILayout.Toggle("Delete Before Fill", m_Target.DeleteBeforeFill);
            
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Change Fill Settings");
                m_Target.TileSize = newTileSize;
                m_Target.PositionJitter = newJitter;
                m_Target.RandomizeTileSelection = newRandomize;
                m_Target.DeleteBeforeFill = newDeleteFirst;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.Space();
            
            // Status
            EditorGUILayout.LabelField("Status", EditorStyles.boldLabel);
            EditorGUILayout.LabelField($"Sample Regions: {m_Target.SampleRegions.Count}");
            
            var gridPos = m_Target.GetFillGridPositions();
            EditorGUILayout.LabelField($"Grid Tiles: {gridPos.Count}");
            
            EditorGUILayout.Space();
            EditorGUILayout.HelpBox(
                "1. Click 'Start Draw Mode' or 'Start Box Mode'\n" +
                "2. Draw/drag to define floor area\n" +
                "3. Adjust sample edges if needed\n" +
                "4. Click 'Fill Floor'\n\n" +
                "Keys: F=Fill | D=Delete | Esc=Exit",
                MessageType.Info);
            
            EditorGUILayout.Space();
            
            // Main action buttons
            EditorGUILayout.BeginHorizontal();
            
            GUI.backgroundColor = new Color(1f, 0.5f, 0.5f);
            if (GUILayout.Button("Delete Region", GUILayout.Height(30)))
            {
                m_Target.DeleteFillRegion();
            }
            
            GUI.backgroundColor = new Color(0.5f, 1f, 0.5f);
            GUI.enabled = m_Target.IsValid && m_Target.SampleRegions.Count > 0;
            if (GUILayout.Button("Fill Floor", GUILayout.Height(30)))
            {
                m_Target.ExecuteFill();
            }
            GUI.enabled = true;
            GUI.backgroundColor = Color.white;
            
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Update Samples"))
                m_Target.UpdateSampleRegions();
            if (GUILayout.Button("Reset All"))
                m_Target.Reset();
            EditorGUILayout.EndHorizontal();
            
            EditorGUILayout.Space();
            
            // Mode buttons
            GUI.backgroundColor = m_BrushMode ? Color.cyan : Color.white;
            if (GUILayout.Button(m_BrushMode ? "Stop Draw Mode (Esc)" : "Start Draw Mode", GUILayout.Height(35)))
            {
                if (m_BrushMode)
                    StopBrushMode();
                else
                    StartBrushMode();
            }
            GUI.backgroundColor = Color.white;
            
            serializedObject.ApplyModifiedProperties();
        }

        private void StartBrushMode()
        {
            m_BrushMode = true;
            m_NavigationMode = false;
            GaussianSplatFloorFillBrush.IsBrushModeActive = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            if (SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.Focus();
            
            SceneView.RepaintAll();
        }

        private void StopBrushMode()
        {
            m_BrushMode = false;
            m_NavigationMode = false;
            m_IsDragging = false;
            GaussianSplatFloorFillBrush.IsBrushModeActive = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            if (m_BrushMode)
            {
                GaussianSplatFloorFillBrush.IsBrushModeActive = false;
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_BrushMode || m_Target == null) return;

            Event e = Event.current;
            
            // Middle mouse toggle navigation
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                sceneView.Repaint();
                return;
            }
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            HandleMouseInput(sceneView, e);
            HandleKeyInput(sceneView, e);
            DrawPreview(sceneView);
            DrawHandles(sceneView);
            
            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }

        private void HandleMouseInput(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            
            // Raycast to floor plane
            Plane floorPlane = new Plane(Vector3.up, new Vector3(0, m_Target.FloorY, 0));
            float enter;
            Vector3 hitPoint = Vector3.zero;
            bool hasHit = floorPlane.Raycast(ray, out enter);
            if (hasHit)
            {
                hitPoint = ray.GetPoint(enter);
            }
            
            // Start drag
            if (e.type == EventType.MouseDown && e.button == 0 && hasHit)
            {
                m_IsDragging = true;
                m_DragStart = hitPoint;
                m_Target.StartDrawing(hitPoint);
                e.Use();
            }
            
            // Continue drag
            if (e.type == EventType.MouseDrag && e.button == 0 && m_IsDragging && hasHit)
            {
                m_Target.AddDrawPoint(hitPoint);
                e.Use();
            }
            
            // End drag
            if (e.type == EventType.MouseUp && e.button == 0 && m_IsDragging)
            {
                m_IsDragging = false;
                
                // Create box from drag
                if (m_Target.DrawPoints.Count >= 2)
                {
                    Vector3 min = m_DragStart;
                    Vector3 max = hitPoint;
                    
                    Vector3 center = (min + max) * 0.5f;
                    center.y = m_Target.FloorY;
                    
                    Vector2 size = new Vector2(
                        Mathf.Abs(max.x - min.x),
                        Mathf.Abs(max.z - min.z));
                    
                    if (size.x < 0.1f) size.x = 0.5f;
                    if (size.y < 0.1f) size.y = 0.5f;
                    
                    m_Target.SetFillRegion(center, size);
                }
                
                m_Target.FinishDrawing();
                e.Use();
            }
        }

        private void HandleKeyInput(SceneView sceneView, Event e)
        {
            if (e.type != EventType.KeyDown) return;
            
            switch (e.keyCode)
            {
                case KeyCode.F:
                    if (m_Target.IsValid && m_Target.SampleRegions.Count > 0)
                        m_Target.ExecuteFill();
                    e.Use();
                    break;
                    
                case KeyCode.D:
                    m_Target.DeleteFillRegion();
                    e.Use();
                    break;
                    
                case KeyCode.R:
                    m_Target.Reset();
                    e.Use();
                    break;
                    
                case KeyCode.Escape:
                    if (m_Target.IsDrawing)
                        m_Target.CancelDrawing();
                    else
                        StopBrushMode();
                    Repaint();
                    e.Use();
                    break;
            }
        }

        private void DrawPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Draw fill region
            Handles.color = new Color(1f, 0.5f, 0f, 0.9f);
            Vector3 fillSize = new Vector3(m_Target.FillSize.x, m_Target.FloorThickness, m_Target.FillSize.y);
            Handles.DrawWireCube(m_Target.FillCenter, fillSize);
            
            // Draw sample regions
            Handles.color = new Color(0f, 1f, 0.5f, 0.9f);
            foreach (var bounds in m_Target.SampleRegions)
            {
                Handles.DrawWireCube(bounds.center, bounds.size);
            }
            
            // Draw grid preview
            Handles.color = new Color(1f, 1f, 0f, 0.3f);
            var gridPositions = m_Target.GetFillGridPositions();
            float tileHalfX = m_Target.TileSize.x * 0.5f;
            float tileHalfZ = m_Target.TileSize.y * 0.5f;
            
            foreach (var pos in gridPositions)
            {
                // Draw small cross at each tile position
                Handles.DrawLine(pos - Vector3.right * tileHalfX * 0.3f, pos + Vector3.right * tileHalfX * 0.3f);
                Handles.DrawLine(pos - Vector3.forward * tileHalfZ * 0.3f, pos + Vector3.forward * tileHalfZ * 0.3f);
            }
            
            // Draw current drag
            if (m_IsDragging && m_Target.DrawPoints.Count > 0)
            {
                Handles.color = Color.yellow;
                for (int i = 0; i < m_Target.DrawPoints.Count - 1; i++)
                {
                    Handles.DrawLine(m_Target.DrawPoints[i], m_Target.DrawPoints[i + 1]);
                }
                
                // Draw rectangle preview
                Handles.color = new Color(1f, 1f, 0f, 0.5f);
                Vector3 start = m_DragStart;
                Vector3 current = m_Target.DrawPoints[m_Target.DrawPoints.Count - 1];
                
                Vector3[] rectPoints = new Vector3[4];
                rectPoints[0] = new Vector3(start.x, m_Target.FloorY, start.z);
                rectPoints[1] = new Vector3(current.x, m_Target.FloorY, start.z);
                rectPoints[2] = new Vector3(current.x, m_Target.FloorY, current.z);
                rectPoints[3] = new Vector3(start.x, m_Target.FloorY, current.z);
                
                Handles.DrawSolidRectangleWithOutline(rectPoints, new Color(1f, 0.5f, 0f, 0.2f), Color.yellow);
            }
            
            // Draw labels
            GUIStyle labelStyle = new GUIStyle();
            labelStyle.normal.textColor = Color.white;
            labelStyle.fontSize = 11;
            labelStyle.fontStyle = FontStyle.Bold;
            
            Vector3 labelPos = m_Target.FillCenter + Vector3.up * 0.5f;
            string status = m_IsDragging ? "Drawing..." : "F=Fill | D=Delete | Drag to draw";
            Handles.Label(labelPos, status, labelStyle);
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }

        private void DrawHandles(SceneView sceneView)
        {
            if (m_IsDragging) return;
            
            // Position handle for fill center
            EditorGUI.BeginChangeCheck();
            Vector3 newCenter = Handles.PositionHandle(m_Target.FillCenter, Quaternion.identity);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Move Fill Region");
                m_Target.FillCenter = newCenter;
                m_Target.UpdateSampleRegions();
                EditorUtility.SetDirty(m_Target);
            }
            
            // Size handles
            Handles.color = Color.cyan;
            float handleSize = HandleUtility.GetHandleSize(m_Target.FillCenter) * 0.1f;
            
            Vector3 pos = m_Target.FillCenter;
            Vector2 size = m_Target.FillSize;
            
            // X+ handle
            EditorGUI.BeginChangeCheck();
            Vector3 xHandle = Handles.Slider(pos + Vector3.right * size.x * 0.5f, Vector3.right, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Resize Fill Region");
                float newWidth = (xHandle.x - pos.x) * 2f;
                m_Target.FillSize = new Vector2(Mathf.Max(0.1f, newWidth), size.y);
                m_Target.UpdateSampleRegions();
                EditorUtility.SetDirty(m_Target);
            }
            
            // Z+ handle
            EditorGUI.BeginChangeCheck();
            Vector3 zHandle = Handles.Slider(pos + Vector3.forward * size.y * 0.5f, Vector3.forward, handleSize * 2f, Handles.CubeHandleCap, 0.01f);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_Target, "Resize Fill Region");
                float newDepth = (zHandle.z - pos.z) * 2f;
                m_Target.FillSize = new Vector2(size.x, Mathf.Max(0.1f, newDepth));
                m_Target.UpdateSampleRegions();
                EditorUtility.SetDirty(m_Target);
            }
        }
    }
    
    [EditorTool("Floor Fill Brush", typeof(GaussianSplatFloorFillBrush))]
    public class GaussianSplatFloorFillBrushTool : EditorTool
    {
        private GaussianSplatFloorFillBrush m_Brush;
        private bool m_NavigationMode = false;
        private Vector3 m_DragStart;
        private bool m_IsDragging = false;

        public override GUIContent toolbarIcon => new GUIContent(
            EditorGUIUtility.IconContent("d_Grid.FillTool").image,
            "Floor Fill Brush Tool");

        private void OnEnable()
        {
            m_Brush = target as GaussianSplatFloorFillBrush;
            GaussianSplatFloorFillBrush.IsBrushModeActive = true;
            m_NavigationMode = false;
        }
        
        private void OnDisable()
        {
            GaussianSplatFloorFillBrush.IsBrushModeActive = false;
            m_NavigationMode = false;
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_Brush == null)
                return;

            Event e = Event.current;
            
            if (e.type == EventType.MouseDown && e.button == 2)
            {
                m_NavigationMode = !m_NavigationMode;
                e.Use();
                sceneView.Repaint();
                return;
            }
            
            if (m_NavigationMode)
            {
                GaussianSplatFloorFillBrush.IsBrushModeActive = false;
                sceneView.Repaint();
                return;
            }
            
            GaussianSplatFloorFillBrush.IsBrushModeActive = true;
            
            HandleToolInput(sceneView, e);
            DrawToolPreview(sceneView);
            
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            if (e.type == EventType.Layout)
                HandleUtility.AddDefaultControl(controlID);
            
            sceneView.Repaint();
        }
        
        private void HandleToolInput(SceneView sceneView, Event e)
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            Plane floorPlane = new Plane(Vector3.up, new Vector3(0, m_Brush.FloorY, 0));
            float enter;
            Vector3 hitPoint = Vector3.zero;
            bool hasHit = floorPlane.Raycast(ray, out enter);
            if (hasHit) hitPoint = ray.GetPoint(enter);
            
            if (e.type == EventType.MouseDown && e.button == 0 && hasHit)
            {
                m_IsDragging = true;
                m_DragStart = hitPoint;
                m_Brush.StartDrawing(hitPoint);
                e.Use();
            }
            
            if (e.type == EventType.MouseDrag && e.button == 0 && m_IsDragging && hasHit)
            {
                m_Brush.AddDrawPoint(hitPoint);
                e.Use();
            }
            
            if (e.type == EventType.MouseUp && e.button == 0 && m_IsDragging)
            {
                m_IsDragging = false;
                
                if (m_Brush.DrawPoints.Count >= 2)
                {
                    Vector3 center = (m_DragStart + hitPoint) * 0.5f;
                    center.y = m_Brush.FloorY;
                    
                    Vector2 size = new Vector2(
                        Mathf.Abs(hitPoint.x - m_DragStart.x),
                        Mathf.Abs(hitPoint.z - m_DragStart.z));
                    
                    if (size.x < 0.1f) size.x = 0.5f;
                    if (size.y < 0.1f) size.y = 0.5f;
                    
                    m_Brush.SetFillRegion(center, size);
                }
                
                m_Brush.FinishDrawing();
                e.Use();
            }
            
            // Keyboard
            if (e.type == EventType.KeyDown)
            {
                switch (e.keyCode)
                {
                    case KeyCode.F:
                        if (m_Brush.IsValid && m_Brush.SampleRegions.Count > 0)
                            m_Brush.ExecuteFill();
                        e.Use();
                        break;
                    case KeyCode.D:
                        m_Brush.DeleteFillRegion();
                        e.Use();
                        break;
                    case KeyCode.R:
                        m_Brush.Reset();
                        e.Use();
                        break;
                }
            }
        }
        
        private void DrawToolPreview(SceneView sceneView)
        {
            Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
            
            // Fill region
            Handles.color = new Color(1f, 0.5f, 0f, 0.9f);
            Vector3 fillSize = new Vector3(m_Brush.FillSize.x, m_Brush.FloorThickness, m_Brush.FillSize.y);
            Handles.DrawWireCube(m_Brush.FillCenter, fillSize);
            
            // Sample regions
            Handles.color = new Color(0f, 1f, 0.5f, 0.9f);
            foreach (var bounds in m_Brush.SampleRegions)
            {
                Handles.DrawWireCube(bounds.center, bounds.size);
            }
            
            // Drag preview
            if (m_IsDragging && m_Brush.DrawPoints.Count > 0)
            {
                Vector3 current = m_Brush.DrawPoints[m_Brush.DrawPoints.Count - 1];
                
                Vector3[] rectPoints = new Vector3[4];
                rectPoints[0] = new Vector3(m_DragStart.x, m_Brush.FloorY, m_DragStart.z);
                rectPoints[1] = new Vector3(current.x, m_Brush.FloorY, m_DragStart.z);
                rectPoints[2] = new Vector3(current.x, m_Brush.FloorY, current.z);
                rectPoints[3] = new Vector3(m_DragStart.x, m_Brush.FloorY, current.z);
                
                Handles.DrawSolidRectangleWithOutline(rectPoints, new Color(1f, 0.5f, 0f, 0.2f), Color.yellow);
            }
            
            Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
        }
    }
}

