// SPDX-License-Identifier: MIT
// Builds a single plugin package containing both the SplatBox renderer and the Relight add-on.

using UnityEngine;
using UnityEditor;
using UnityEditor.Build.Reporting;
using System;
using System.IO;
using System.Linq;

namespace GaussianSplatting.Editor
{
    public static class SplatBoxCombinedBuilder
    {
        const string kPackageName = "com.gaussiansplatting.splatbox.combined";

        static string PluginOutputPath
        {
            get
            {
                string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
                return Path.Combine(projectPath, "SplatBoxCombined");
            }
        }

        [MenuItem("SplatBox/Build Combined Plugin (Render + Relight)")]
        public static void BuildCombinedPluginPackage()
        {
#if !GS_ENABLE_URP
            bool proceed = EditorUtility.DisplayDialog("Combined Plugin Builder - Warning",
                "URP (Universal Render Pipeline) is not detected!\n\n" +
                "The GaussianSplatURPFeature class will NOT be included in the Runtime DLL.\n" +
                "Users won't be able to add the Gaussian Splat renderer feature to URP.\n\n" +
                "For full functionality, build from a project with URP installed.\n\n" +
                "Continue anyway?",
                "Continue", "Cancel");
            if (!proceed) return;
#endif

            string packageRoot = GetPackageRoot();
            if (string.IsNullOrEmpty(packageRoot))
            {
                EditorUtility.DisplayDialog("Combined Plugin Builder - Error",
                    "Could not determine package root directory.\n\n" +
                    "Ensure the SplatBox package (with Relight) is properly installed.",
                    "OK");
                return;
            }

            if (!Directory.Exists(PluginOutputPath))
                Directory.CreateDirectory(PluginOutputPath);

            // Folder structure
            string pluginsFolder = Path.Combine(PluginOutputPath, "Plugins");
            string pluginsEditorFolder = Path.Combine(pluginsFolder, "Editor");
            string editorIconsFolder = Path.Combine(PluginOutputPath, "Editor", "Icons");
            string shadersFolder = Path.Combine(PluginOutputPath, "Shaders");
            string resourcesFolder = Path.Combine(PluginOutputPath, "Resources");

            CreateDir(pluginsFolder);
            CreateDir(pluginsEditorFolder);
            CreateDir(editorIconsFolder);
            CreateDir(shadersFolder);
            CreateDir(resourcesFolder);

            string unityLibraryPath = Path.Combine(Application.dataPath, "..", "Library", "ScriptAssemblies");

            Debug.Log($"[Combined Builder] Package root: {packageRoot}");
            Debug.Log($"[Combined Builder] Unity version: {Application.unityVersion}");

            int copiedFiles = 0;

            // ── 1. Build minimal player to get Runtime/Core DLLs without UnityEditor ──
            string runtimeManagedPath = BuildRuntimeDllsNoEditor();
            if (string.IsNullOrEmpty(runtimeManagedPath))
            {
                EditorUtility.DisplayDialog("Combined Plugin Builder - Error",
                    "Minimal player build failed. Runtime/Core DLLs must be built without UNITY_EDITOR.\n\n" +
                    "Ensure Build Settings has at least one scene and the build completes without errors.",
                    "OK");
                return;
            }

            // ── 2. Copy SplatBox DLLs (Core + Runtime from player build, Editor from session) ──
            copiedFiles += CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Core.dll");
            copiedFiles += CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Runtime.dll");
            CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Core.pdb");
            CopyDll(runtimeManagedPath, pluginsFolder, "GaussianSplatting.SplatBox.Runtime.pdb");

            copiedFiles += CopyDll(unityLibraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Editor.dll");
            CopyDll(unityLibraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Editor.pdb");

            CleanupTempBuildFolder();

            if (copiedFiles < 3)
            {
                EditorUtility.DisplayDialog("Combined Plugin Builder - Error",
                    "SplatBox DLLs not found. Ensure the project compiles:\n" +
                    "  GaussianSplatting.SplatBox.Core.dll\n" +
                    "  GaussianSplatting.SplatBox.Runtime.dll\n" +
                    "  GaussianSplatting.SplatBox.Editor.dll",
                    "OK");
                return;
            }

            CreateDllMeta(pluginsFolder, "GaussianSplatting.SplatBox.Core.dll", false);
            CreateDllMeta(pluginsFolder, "GaussianSplatting.SplatBox.Runtime.dll", false);
            CreateDllMeta(pluginsEditorFolder, "GaussianSplatting.SplatBox.Editor.dll", true);
            copiedFiles += 3;

            // ── 3. Copy Relight DLLs (from current session assemblies) ──
            int relightCount = 0;
            relightCount += CopyDll(unityLibraryPath, pluginsFolder, "GaussianSplatting.SplatBox.Relight.dll");
            CopyDll(unityLibraryPath, pluginsFolder, "GaussianSplatting.SplatBox.Relight.pdb");
            relightCount += CopyDll(unityLibraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Relight.Editor.dll");
            CopyDll(unityLibraryPath, pluginsEditorFolder, "GaussianSplatting.SplatBox.Relight.Editor.pdb");

            if (relightCount < 2)
            {
                EditorUtility.DisplayDialog("Combined Plugin Builder - Error",
                    "Relight DLLs not found. Ensure the Relight assemblies are compiled:\n" +
                    "  GaussianSplatting.SplatBox.Relight.dll\n" +
                    "  GaussianSplatting.SplatBox.Relight.Editor.dll\n\n" +
                    "Build the project or reimport the Relight scripts.",
                    "OK");
                return;
            }

            CreateDllMeta(pluginsFolder, "GaussianSplatting.SplatBox.Relight.dll", false);
            CreateDllMeta(pluginsEditorFolder, "GaussianSplatting.SplatBox.Relight.Editor.dll", true);
            copiedFiles += relightCount + 2;

            // ── 4. Copy Editor Icons ──
            string sourceIcons = Path.Combine(packageRoot, "Editor", "Icons");
            if (Directory.Exists(sourceIcons))
            {
                foreach (var ext in new[] { "*.png", "*.png.meta" })
                {
                    foreach (var file in Directory.GetFiles(sourceIcons, ext))
                    {
                        File.Copy(file, Path.Combine(editorIconsFolder, Path.GetFileName(file)), true);
                        copiedFiles++;
                    }
                }
                Debug.Log("[Combined Builder] Copied editor icons");
            }

            // ── 5. Copy SplatBox shaders (including Relight subfolder) ──
            string sourceShaders = Path.Combine(packageRoot, "Shaders");
            if (Directory.Exists(sourceShaders))
            {
                foreach (var ext in new[] { "*.shader", "*.hlsl", "*.compute", "*.cginc" })
                {
                    foreach (var file in Directory.GetFiles(sourceShaders, ext))
                    {
                        File.Copy(file, Path.Combine(shadersFolder, Path.GetFileName(file)), true);
                        copiedFiles++;
                        Debug.Log($"[Combined Builder] Copied shader: {Path.GetFileName(file)}");
                    }
                }
                string relightShadersDir = Path.Combine(sourceShaders, "Relight");
                if (Directory.Exists(relightShadersDir))
                {
                    foreach (var file in Directory.GetFiles(relightShadersDir, "RenderGaussianSplats.shader"))
                    {
                        string shaderText = File.ReadAllText(file);
                        shaderText = shaderText.Replace("../SplatBox.hlsl", "SplatBox.hlsl");
                        File.WriteAllText(Path.Combine(shadersFolder, "RenderSplatsRelight.shader"), shaderText);
                        copiedFiles++;
                        Debug.Log("[Combined Builder] Copied Relight shader as RenderSplatsRelight.shader");
                    }
                }
            }

            // ── 6. Copy Resources (compute + player-loadable relight shader) ──
            string sourceResources = Path.Combine(packageRoot, "Resources");
            if (Directory.Exists(sourceResources))
            {
                foreach (var ext in new[] { "*.compute", "*.hlsl", "*.shader" })
                {
                    foreach (var file in Directory.GetFiles(sourceResources, ext))
                    {
                        File.Copy(file, Path.Combine(resourcesFolder, Path.GetFileName(file)), true);
                        copiedFiles++;
                        Debug.Log($"[Combined Builder] Copied resource: {Path.GetFileName(file)}");
                    }
                }
            }
            else
            {
                Debug.LogWarning("[Combined Builder] Resources folder not found. Windows standalone builds may fail to load compute shaders at runtime.");
            }

            // ── 8. Create package metadata ──
            CreatePackageJson(PluginOutputPath);
            CreateCombinedAssemblyDefinitions(pluginsFolder, pluginsEditorFolder);
            CreateReadme(PluginOutputPath);
            copiedFiles += 4;

            Debug.Log($"[Combined Builder] Combined plugin built: {PluginOutputPath} ({copiedFiles} items)");

            EditorUtility.DisplayDialog("Combined Plugin Builder",
                $"Combined plugin (Render + Relight) built successfully!\n\n" +
                $"Output: {PluginOutputPath}\n" +
                $"Total files: {copiedFiles}\n" +
                $"Built with: Unity {Application.unityVersion}\n\n" +
                "All SplatBox + Relight assemblies in one package.\n" +
                "Add via Package Manager (Add from disk) using package.json.\n\n" +
                "IMPORTANT: Use with the same major Unity version it was built with.",
                "OK");

            EditorUtility.RevealInFinder(PluginOutputPath);
        }

        [MenuItem("SplatBox/Open Combined Plugin Folder")]
        public static void OpenCombinedPluginFolder()
        {
            if (Directory.Exists(PluginOutputPath))
                EditorUtility.RevealInFinder(PluginOutputPath);
            else
                EditorUtility.DisplayDialog("Combined Plugin Builder", "Build the combined plugin first.", "OK");
        }

        // ─── Helpers ───────────────────────────────────────────────────────

        static string GetPackageRoot()
        {
            string[] guids = AssetDatabase.FindAssets("package t:TextAsset", new[] { "Packages/com.gaussiansplatting.splatbox" });
            if (guids.Length > 0)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[0]);
                return Path.GetDirectoryName(Path.GetFullPath(path));
            }
            guids = AssetDatabase.FindAssets("SplatBoxPluginBuilder t:MonoScript");
            if (guids.Length > 0)
            {
                string path = Path.GetFullPath(AssetDatabase.GUIDToAssetPath(guids[0]));
                return Path.GetDirectoryName(Path.GetDirectoryName(path));
            }
            return null;
        }

        static void CreateDir(string path)
        {
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        }

        static int CopyDll(string sourceDir, string destDir, string fileName)
        {
            string src = Path.Combine(sourceDir, fileName);
            if (!File.Exists(src))
            {
                if (fileName.EndsWith(".dll"))
                    Debug.LogWarning($"[Combined Builder] DLL not found: {src}");
                return 0;
            }
            File.Copy(src, Path.Combine(destDir, fileName), true);
            Debug.Log($"[Combined Builder] Copied: {fileName}");
            return 1;
        }

        static string BuildRuntimeDllsNoEditor()
        {
            var scenes = EditorBuildSettings.scenes
                .Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0)
            {
                Debug.LogError("[Combined Builder] No enabled scenes in Build Settings.");
                return null;
            }

            string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string tempBuildDir = Path.Combine(projectPath, "SplatBoxCombinedBuildTemp");
            if (Directory.Exists(tempBuildDir))
            {
                try { Directory.Delete(tempBuildDir, true); } catch { }
            }
            Directory.CreateDirectory(tempBuildDir);

            BuildTarget target = EditorUserBuildSettings.activeBuildTarget;
            string exeName = "SplatBoxMinimal";
            string locationPathName;
            if (target == BuildTarget.StandaloneWindows || target == BuildTarget.StandaloneWindows64)
                locationPathName = Path.Combine(tempBuildDir, exeName + ".exe");
            else if (target == BuildTarget.StandaloneOSX)
                locationPathName = Path.Combine(tempBuildDir, exeName + ".app");
            else
                locationPathName = Path.Combine(tempBuildDir, exeName);

            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = locationPathName,
                target = target,
                options = BuildOptions.None
            };

            Debug.Log($"[Combined Builder] Building minimal player for {target} ...");
            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != BuildResult.Succeeded)
            {
                Debug.LogError($"[Combined Builder] Build failed: {report.summary.result}, {report.summary.totalErrors} error(s).");
                return null;
            }

            string managedPath = GetManagedPath(report.summary.outputPath, target);
            if (string.IsNullOrEmpty(managedPath) || !Directory.Exists(managedPath))
            {
                Debug.LogError("[Combined Builder] Could not find Managed folder in build output.");
                return null;
            }

            Debug.Log("[Combined Builder] Runtime/Core DLLs built without UnityEditor reference.");
            return managedPath;
        }

        static void CleanupTempBuildFolder()
        {
            string projectPath = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            string tempBuildDir = Path.Combine(projectPath, "SplatBoxCombinedBuildTemp");
            if (Directory.Exists(tempBuildDir))
            {
                try { Directory.Delete(tempBuildDir, true); } catch { }
            }
        }

        static string GetManagedPath(string outputPath, BuildTarget target)
        {
            if (string.IsNullOrEmpty(outputPath)) return null;
            if (target == BuildTarget.StandaloneOSX && outputPath.EndsWith(".app"))
                return Path.Combine(outputPath, "Contents", "Data", "Managed");
            string dir = Path.GetDirectoryName(outputPath);
            string name = Path.GetFileNameWithoutExtension(outputPath);
            return Path.Combine(dir, name + "_Data", "Managed");
        }

        static void CreateDllMeta(string folder, string dllName, bool editorOnly)
        {
            string guid;
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] h = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes("Combined_" + dllName));
                guid = new Guid(h).ToString("N");
            }
            string platform = editorOnly
                ? @"  platformData:
  - first:
      Any: 
    second:
      enabled: 0
      settings: {}
  - first:
      Editor: Editor
    second:
      enabled: 1
      settings:
        DefaultValueInitialized: true"
                : @"  platformData:
  - first:
      Any: 
    second:
      enabled: 1
      settings: {}
  - first:
      Editor: Editor
    second:
      enabled: 1
      settings:
        DefaultValueInitialized: true";

            string meta = $@"fileFormatVersion: 2
guid: {guid}
PluginImporter:
  externalObjects: {{}}
  serializedVersion: 2
  iconMap: {{}}
  executionOrder: {{}}
  defineConstraints: []
  isPreloaded: 0
  isOverridable: 0
  isExplicitlyReferenced: 0
  validateReferences: 0
{platform}
  userData: 
  assetBundleName: 
  assetBundleVariant: 
";
            File.WriteAllText(Path.Combine(folder, dllName + ".meta"), meta);
        }

        static void CreatePackageJson(string outputPath)
        {
            string json = $@"{{
    ""name"": ""{kPackageName}"",
    ""version"": ""1.0.0"",
    ""displayName"": ""SplatBox Combined (Render + Relight)"",
    ""description"": ""All-in-one SplatBox package: Gaussian Splat editing toolbox with brush tools, clone, paint, sculpt, and integrated Relight add-on for custom lighting."",
    ""unity"": ""6000.0"",
    ""dependencies"": {{
        ""com.unity.mathematics"": ""1.2.6"",
        ""com.unity.collections"": ""2.2.1"",
        ""com.unity.burst"": ""1.8.18""
    }},
    ""keywords"": [
        ""gaussian"",
        ""splatting"",
        ""3dgs"",
        ""editor"",
        ""brush"",
        ""tools"",
        ""relight"",
        ""lighting"",
        ""plugin""
    ],
    ""author"": {{
        ""name"": ""SplatBox""
    }}
}}";
            File.WriteAllText(Path.Combine(outputPath, "package.json"), json);
            Debug.Log("[Combined Builder] Created package.json");
        }

        static void CreateCombinedAssemblyDefinitions(string pluginsFolder, string editorFolder)
        {
            // Runtime asmdef wrapping Core + Runtime + Relight runtime DLLs
            string runtimeAsmdef = @"{
    ""name"": ""GaussianSplatting.SplatBox.Combined"",
    ""rootNamespace"": ""GaussianSplatting.Runtime"",
    ""references"": [
        ""Unity.Mathematics"",
        ""Unity.Collections"",
        ""Unity.RenderPipelines.Core.Runtime"",
        ""Unity.RenderPipelines.Universal.Runtime""
    ],
    ""includePlatforms"": [],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": true,
    ""overrideReferences"": true,
    ""precompiledReferences"": [
        ""GaussianSplatting.SplatBox.Core.dll"",
        ""GaussianSplatting.SplatBox.Runtime.dll"",
        ""GaussianSplatting.SplatBox.Relight.dll""
    ],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""versionDefines"": [
        {
            ""name"": ""com.unity.render-pipelines.universal"",
            ""expression"": """",
            ""define"": ""GS_ENABLE_URP""
        }
    ],
    ""noEngineReferences"": false
}";
            File.WriteAllText(Path.Combine(pluginsFolder, "GaussianSplatting.SplatBox.Combined.asmdef"), runtimeAsmdef);

            // Editor asmdef wrapping Editor + Relight.Editor DLLs
            string editorAsmdef = @"{
    ""name"": ""GaussianSplatting.SplatBox.Combined.Editor"",
    ""rootNamespace"": ""GaussianSplatting.Editor"",
    ""references"": [
        ""GaussianSplatting.SplatBox.Combined"",
        ""Unity.Mathematics"",
        ""Unity.Collections"",
        ""Unity.Burst""
    ],
    ""includePlatforms"": [ ""Editor"" ],
    ""excludePlatforms"": [],
    ""allowUnsafeCode"": true,
    ""overrideReferences"": true,
    ""precompiledReferences"": [
        ""GaussianSplatting.SplatBox.Editor.dll"",
        ""GaussianSplatting.SplatBox.Relight.Editor.dll""
    ],
    ""autoReferenced"": true,
    ""defineConstraints"": [],
    ""versionDefines"": [],
    ""noEngineReferences"": false
}";
            File.WriteAllText(Path.Combine(editorFolder, "GaussianSplatting.SplatBox.Combined.Editor.asmdef"), editorAsmdef);

            Debug.Log("[Combined Builder] Created combined assembly definitions");
        }

        static void CreateReadme(string outputPath)
        {
#if GS_ENABLE_URP
            string urpStatus = "YES - GaussianSplatURPFeature included";
#else
            string urpStatus = "NO - GaussianSplatURPFeature NOT included (rebuild with URP for full support)";
#endif
            string readme = $@"# SplatBox Combined Plugin (Render + Relight)

All-in-one precompiled package: SplatBox Gaussian Splat editing tools **and** the Relight lighting add-on.

**Build Info:**
- Unity Version: {Application.unityVersion}
- URP Support: {urpStatus}
- Build Date: {System.DateTime.Now:yyyy-MM-dd HH:mm}

## Installation

### Option 1: Unity Package Manager
1. Open Unity Package Manager (Window > Package Manager)
2. Click '+' and select 'Add package from disk...'
3. Navigate to this folder and select `package.json`

### Option 2: Manual
1. Copy this folder into your project's `Packages/` directory.
2. Rename to `{kPackageName}`.

## Requirements

- **Unity 6** (6000.0+) — compiled with Unity {Application.unityVersion}
- Universal Render Pipeline (URP) for splat rendering
- Auto-installed dependencies: Mathematics, Collections, Burst

**IMPORTANT:** Use with the same major Unity version it was built with.

## URP Setup

The **Gaussian Splat URP Feature** is automatically added to all URP renderers when the editor loads.
If needed, you can re-run it manually via **SplatBox > Setup URP Renderer Features**.

(Optional) Add **Gaussian Tilt Shift Renderer Feature** manually to your URP Renderer Asset for tilt-shift effects.

## PC VR (Stereo Rendering)

PCVR stereo rendering is supported via **Multi-Pass** mode:

1. In **Project Settings > XR Plug-in Management**, enable your headset plug-in (OpenXR, Oculus, etc.)
2. In your **URP Renderer Asset**, set **Rendering Path** to **Multi-Pass**
3. Splats will render correctly to both eyes automatically

> **Note:** Single Pass Instanced is not currently supported for Gaussian Splats. Use Multi-Pass.

## Android / Quest 3 Standalone

The GPU sort (`BoxUtilSort.compute` / `DeviceRadixSort.hlsl`) uses HLSL wave
intrinsics that require Vulkan. OpenGL ES does not support them, so you MUST
build with Vulkan:

1. **Edit > Project Settings > Player > Android > Other Settings**
2. Uncheck **Auto Graphics API**
3. Make **Vulkan** the first (and ideally only) Graphics API — remove OpenGLES3
4. Set **Minimum API Level** to **Android 10 (API 29)** or higher
5. Set **Scripting Backend** to **IL2CPP** and **Target Architectures** to **ARM64**
6. Quest 3 / Quest Pro supports Vulkan subgroup ops natively — no extra setup

If you leave OpenGLES3 in the Graphics API list, the build will fail while
compiling the sort compute shader because wave intrinsics cannot be translated
to GLSL ES.

## Contents

- **Plugins/** — Precompiled DLLs
  - `GaussianSplatting.SplatBox.Core.dll` — Core rendering and data structures
  - `GaussianSplatting.SplatBox.Runtime.dll` — Runtime components, brushes, URP features
  - `GaussianSplatting.SplatBox.Relight.dll` — Relight runtime (custom lights)
  - **Editor/**
    - `GaussianSplatting.SplatBox.Editor.dll` — Editor tools and inspectors
    - `GaussianSplatting.SplatBox.Relight.Editor.dll` — Relight editor (Relight window, custom inspectors)
- **Editor/Icons/** — Editor icon assets
- **Shaders/** — All shader and compute files (SplatBox + Relight)
- **Resources/** — Runtime-loadable assets

## Relight Usage

- Menu: **SplatToolbox > Relight > Relight Editor**
- In Splat Editor, enable the Relight toggle and 'Use Relight shader'.
- Add **Custom Light Manager** to the scene, then add Point, Spot, Directional, or Planar lights as children.
- Adjust intensity, range, attenuation, etc. in each light's inspector.
";
            File.WriteAllText(Path.Combine(outputPath, "README.md"), readme);
            Debug.Log("[Combined Builder] Created README.md");
        }
    }
}
