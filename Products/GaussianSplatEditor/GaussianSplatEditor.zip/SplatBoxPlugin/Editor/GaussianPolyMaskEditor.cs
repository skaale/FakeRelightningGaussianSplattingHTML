// SPDX-License-Identifier: MIT

using System;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEditor;
using UnityEditor.EditorTools;
using GaussianSplatting.Runtime;
using Unity.Collections.LowLevel.Unsafe;

namespace GaussianSplatting.Editor
{
    [CustomEditor(typeof(GaussianPolyMask))]
    public class GaussianPolyMaskEditor : UnityEditor.Editor
    {
        private GaussianPolyMask m_Target;
        private bool m_DrawMode = false;
        private Vector3 m_LastMousePos;
        private double m_LastClickTime = 0;

        private void OnEnable()
        {
            m_Target = target as GaussianPolyMask;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Polygon Mask Settings", EditorStyles.boldLabel);
            
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ShapeType"), new GUIContent("Shape Type"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Invert"), new GUIContent("Invert"));
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Cutout Area Expansion", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ExpansionX"), new GUIContent("Expansion X"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ExpansionY"), new GUIContent("Expansion Y"));
            if (EditorGUI.EndChangeCheck())
            {
                serializedObject.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.HelpBox("Expansion multiplier for cutout area (real-time).\n\n" +
                "1.0 = exact green rectangle\n" +
                "2.0 = 2x larger deletion area\n" +
                "3.0 = 3x larger deletion area", MessageType.Info);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Cutout Area Offset", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_OffsetX"), new GUIContent("Offset X"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_OffsetY"), new GUIContent("Offset Y"));
            if (EditorGUI.EndChangeCheck())
            {
                serializedObject.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.HelpBox("Shift cutout area position (real-time).\n\n" +
                "0.0 = centered on green rectangle\n" +
                "±1.0 = shift by 1 unit\n" +
                "±2.0 = shift by 2 units", MessageType.Info);
            
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Extrusion Settings", EditorStyles.boldLabel);
            
            EditorGUI.BeginChangeCheck();
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_ExtrusionAxis"), new GUIContent("Extrusion Axis"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("m_CutDepth"), new GUIContent("Cut Depth (meters)"));
            if (EditorGUI.EndChangeCheck())
            {
                serializedObject.ApplyModifiedProperties();
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUILayout.HelpBox("Extrusion Axis:\n" +
                "• Auto = detect from polygon orientation\n" +
                "• X/Y/Z = force specific direction\n\n" +
                "Cut Depth: 1m=shallow, 10m=medium, 100m=deep", MessageType.Info);
            
            EditorGUILayout.Space();

            // Shape-specific settings
            if (m_Target.m_ShapeType == GaussianPolyMask.ShapeType.Circle)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("m_CircleSegments"), new GUIContent("Segments"));
            }
            else if (m_Target.m_ShapeType == GaussianPolyMask.ShapeType.Star)
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("m_StarPoints"), new GUIContent("Points"));
                EditorGUILayout.PropertyField(serializedObject.FindProperty("m_StarInnerRadius"), new GUIContent("Inner Radius"));
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField($"Vertices: {m_Target.GetDisplayVertices().Count}");
            
            // Show bounds info (not transform - transform is not modified)
            if (m_Target.IsClosed)
            {
                Vector3 boundsCenter = m_Target.BoundsCenter;
                Vector3 boundsSize = m_Target.BoundsSize;
                
                EditorGUILayout.LabelField("Cutout Bounds:", EditorStyles.boldLabel);
                EditorGUILayout.LabelField($"  Center: ({boundsCenter.x:F2}, {boundsCenter.y:F2}, {boundsCenter.z:F2})");
                
                // Determine polygon plane and show correct dimensions
                float area1, area2;
                string planeLabel;
                
                if (boundsSize.z < boundsSize.x && boundsSize.z < boundsSize.y)
                {
                    // XY plane
                    area1 = boundsSize.x; area2 = boundsSize.y; planeLabel = "XY Size";
                }
                else if (boundsSize.y < boundsSize.x && boundsSize.y < boundsSize.z)
                {
                    // XZ plane
                    area1 = boundsSize.x; area2 = boundsSize.z; planeLabel = "XZ Size";
                }
                else
                {
                    // YZ plane
                    area1 = boundsSize.y; area2 = boundsSize.z; planeLabel = "YZ Size";
                }
                
                GUIStyle sizeStyle = new GUIStyle(EditorStyles.label);
                if (area1 < 0.1f || area2 < 0.1f)
                {
                    sizeStyle.normal.textColor = Color.red;
                    EditorGUILayout.LabelField($"  ⚠️ {planeLabel}: {area1:F3}m x {area2:F3}m (TOO SMALL!)", sizeStyle);
                    EditorGUILayout.HelpBox("Cutout area is very small. Redraw a larger polygon.", MessageType.Warning);
                }
                else
                {
                    sizeStyle.normal.textColor = Color.green;
                    EditorGUILayout.LabelField($"  {planeLabel}: {area1:F2}m x {area2:F2}m", sizeStyle);
                    EditorGUILayout.LabelField($"  Depth: {serializedObject.FindProperty("m_CutDepth").floatValue:F1}m");
                    EditorGUILayout.LabelField($"  Area: ~{area1 * area2:F1} m²");
                }
            }
            
            GUIStyle statusStyle = new GUIStyle(EditorStyles.label);
            statusStyle.fontStyle = FontStyle.Bold;
            if (m_Target.IsClosed)
            {
                statusStyle.normal.textColor = Color.green;
                EditorGUILayout.LabelField("Status: ✓ CLOSED (Ready to apply)", statusStyle);
            }
            else if (m_Target.m_IsDrawing)
            {
                statusStyle.normal.textColor = Color.yellow;
                EditorGUILayout.LabelField("Status: Drawing... (Double-click/Enter to close)", statusStyle);
            }
            else
            {
                statusStyle.normal.textColor = Color.gray;
                EditorGUILayout.LabelField("Status: Not started", statusStyle);
            }
            
            EditorGUILayout.Space();

            // Predefined shapes generation
            if (m_Target.m_ShapeType != GaussianPolyMask.ShapeType.Custom)
            {
                float shapeSize = EditorGUILayout.FloatField("Size", serializedObject.FindProperty("m_ShapeSize").floatValue);
                serializedObject.FindProperty("m_ShapeSize").floatValue = shapeSize;
                
                if (GUILayout.Button($"Generate {m_Target.m_ShapeType}", GUILayout.Height(30)))
                {
                    Undo.RecordObject(m_Target, $"Generate {m_Target.m_ShapeType}");
                    m_Target.GenerateShape(m_Target.transform.position, Vector3.up, shapeSize);
                    EditorUtility.SetDirty(m_Target);
                }
                EditorGUILayout.Space();
            }

            // Custom drawing controls
            if (m_Target.m_ShapeType == GaussianPolyMask.ShapeType.Custom)
            {
                EditorGUILayout.HelpBox("⚠️ POLYGON CUTOUTS USE SIMPLIFIED BOUNDS\n\n" +
                    "• Uses 2D bounding box (not precise point-in-polygon)\n" +
                    "• Auto-detects polygon plane (XY/XZ/YZ)\n" +
                    "• Extrudes through selected axis with adjustable depth\n" +
                    "• Expansion sliders control coverage area\n\n" +
                    "Left-click: Add vertices | Enter/Double-click: Close | Esc: Cancel", MessageType.Warning);
                
                EditorGUI.BeginDisabledGroup(m_Target.m_IsDrawing);
                if (GUILayout.Button("Start Drawing", GUILayout.Height(30)))
                {
                    StartDrawMode();
                }
                EditorGUI.EndDisabledGroup();

                if (GUILayout.Button(m_Target.IsClosed ? "Stop Editing (Hide Lines)" : "Finish Drawing", GUILayout.Height(30)))
                {
                    FinishDrawMode();
                }
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Apply Cutout", EditorStyles.boldLabel);
            
            EditorGUI.BeginDisabledGroup(!m_Target.IsClosed);
            if (GUILayout.Button("Apply Cutout & Delete Area", GUILayout.Height(35)))
            {
                ApplyCutoutToRenderers();
            }
            
            EditorGUILayout.Space(5);
            
            if (GUILayout.Button("Apply & Export to PLY", GUILayout.Height(30)))
            {
                ApplyCutoutToRenderers();
                ExportRenderersWithCutout();
            }
            EditorGUI.EndDisabledGroup();
            
            EditorGUILayout.HelpBox("Export creates new PLY file with cutout applied (deleted splats removed permanently)", MessageType.Info);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Clear", GUILayout.Height(25)))
            {
                Undo.RecordObject(m_Target, "Clear Polygon");
                m_Target.Clear();
                m_DrawMode = false;
                EditorUtility.SetDirty(m_Target);
            }
            
            EditorGUI.BeginDisabledGroup(!m_Target.IsClosed);
            if (GUILayout.Button("Rebuild Cutout", GUILayout.Height(25)))
            {
                Undo.RecordObject(m_Target, "Rebuild Polygon");
                System.Reflection.MethodInfo method = m_Target.GetType().GetMethod("NormalizeToBounds", 
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                method?.Invoke(m_Target, null);
                EditorUtility.SetDirty(m_Target);
                Repaint();
            }
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.EndHorizontal();

            serializedObject.ApplyModifiedProperties();
        }

        private void ApplyCutoutToRenderers()
        {
            SplatBoxRenderer[] renderers = FindObjectsByType<SplatBoxRenderer>();
            int appliedCount = 0;
            
            foreach (var renderer in renderers)
            {
                Undo.RecordObject(renderer, "Apply Cutout");
                
                if (renderer.m_Cutouts == null)
                {
                    renderer.m_Cutouts = new GaussianCutout[] { m_Target };
                }
                else
                {
                    bool alreadyHas = false;
                    foreach (var cutout in renderer.m_Cutouts)
                    {
                        if (cutout == m_Target)
                        {
                            alreadyHas = true;
                            break;
                        }
                    }
                    
                    if (!alreadyHas)
                    {
                        GaussianCutout[] newCutouts = new GaussianCutout[renderer.m_Cutouts.Length + 1];
                        for (int i = 0; i < renderer.m_Cutouts.Length; i++)
                        {
                            newCutouts[i] = renderer.m_Cutouts[i];
                        }
                        newCutouts[renderer.m_Cutouts.Length] = m_Target;
                        renderer.m_Cutouts = newCutouts;
                    }
                }
                
                EditorUtility.SetDirty(renderer);
                appliedCount++;
            }
            
            // Force renderers to update
            foreach (var renderer in renderers)
            {
                renderer.enabled = false;
                renderer.enabled = true;
            }
            
            // DON'T clear the polygon - it needs to stay for the cutout to work!
            // Users can manually click "Clear" button if they want to remove it
            
            Debug.Log($"✓ Applied cutout to {appliedCount} Gaussian Splat Renderer(s) - Polygon remains active for cutout");
        }

        // Static version for use by EditorTool
        public static void ApplyCutoutToAllRenderers(GaussianPolyMask polyMask)
        {
            if (polyMask == null || !polyMask.IsClosed) return;
            
            SplatBoxRenderer[] renderers = FindObjectsByType<SplatBoxRenderer>();
            int appliedCount = 0;
            
            foreach (var renderer in renderers)
            {
                Undo.RecordObject(renderer, "Apply Cutout");
                
                if (renderer.m_Cutouts == null)
                {
                    renderer.m_Cutouts = new GaussianCutout[] { polyMask };
                }
                else
                {
                    bool alreadyHas = false;
                    foreach (var cutout in renderer.m_Cutouts)
                    {
                        if (cutout == polyMask)
                        {
                            alreadyHas = true;
                            break;
                        }
                    }
                    
                    if (!alreadyHas)
                    {
                        GaussianCutout[] newCutouts = new GaussianCutout[renderer.m_Cutouts.Length + 1];
                        for (int i = 0; i < renderer.m_Cutouts.Length; i++)
                        {
                            newCutouts[i] = renderer.m_Cutouts[i];
                        }
                        newCutouts[renderer.m_Cutouts.Length] = polyMask;
                        renderer.m_Cutouts = newCutouts;
                    }
                }
                
                EditorUtility.SetDirty(renderer);
                appliedCount++;
            }
            
            // Force renderers to update
            foreach (var renderer in renderers)
            {
                renderer.enabled = false;
                renderer.enabled = true;
            }
        }

        private void ExportRenderersWithCutout()
        {
            SplatBoxRenderer[] renderers = FindObjectsByType<SplatBoxRenderer>();
            
            foreach (var renderer in renderers)
            {
                // Check if this renderer has our cutout
                bool hasOurCutout = false;
                if (renderer.m_Cutouts != null)
                {
                    foreach (var cutout in renderer.m_Cutouts)
                    {
                        if (cutout == m_Target)
                        {
                            hasOurCutout = true;
                            break;
                        }
                    }
                }
                
                if (hasOurCutout)
                {
                    ExportRendererToPLY(renderer);
                }
            }
        }

        private unsafe void ExportRendererToPLY(SplatBoxRenderer gs)
        {
            var path = EditorUtility.SaveFilePanel(
                "Export Gaussian Splat PLY (with cutout)", "", $"{gs.asset.name}-cutout.ply", "ply");
            if (string.IsNullOrWhiteSpace(path))
                return;

            int kSplatSize = UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>();
            using var gpuData = new GraphicsBuffer(GraphicsBuffer.Target.Structured, gs.splatCount, kSplatSize);

            if (!gs.EditExportData(gpuData, false))
            {
                Debug.LogError("Failed to export data from renderer");
                return;
            }

            GaussianSplatAssetCreator.InputSplatData[] data = new GaussianSplatAssetCreator.InputSplatData[gpuData.count];
            gpuData.GetData(data);

            var gpuDeleted = gs.GpuEditDeleted;
            uint[] deleted = new uint[gpuDeleted.count];
            gpuDeleted.GetData(deleted);

            // Count non-deleted splats
            int aliveCount = 0;
            for (int i = 0; i < data.Length; ++i)
            {
                int wordIdx = i >> 5;
                int bitIdx = i & 31;
                bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                bool isCutout = data[i].nor.sqrMagnitude > 0;
                if (!isDeleted && !isCutout)
                    ++aliveCount;
            }

            using FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write);
            var header = $"ply\nformat binary_little_endian 1.0\nelement vertex {aliveCount}\nproperty float x\nproperty float y\nproperty float z\nproperty float nx\nproperty float ny\nproperty float nz\nproperty float f_dc_0\nproperty float f_dc_1\nproperty float f_dc_2\nproperty float f_rest_0\nproperty float f_rest_1\nproperty float f_rest_2\nproperty float f_rest_3\nproperty float f_rest_4\nproperty float f_rest_5\nproperty float f_rest_6\nproperty float f_rest_7\nproperty float f_rest_8\nproperty float f_rest_9\nproperty float f_rest_10\nproperty float f_rest_11\nproperty float f_rest_12\nproperty float f_rest_13\nproperty float f_rest_14\nproperty float f_rest_15\nproperty float f_rest_16\nproperty float f_rest_17\nproperty float f_rest_18\nproperty float f_rest_19\nproperty float f_rest_20\nproperty float f_rest_21\nproperty float f_rest_22\nproperty float f_rest_23\nproperty float f_rest_24\nproperty float f_rest_25\nproperty float f_rest_26\nproperty float f_rest_27\nproperty float f_rest_28\nproperty float f_rest_29\nproperty float f_rest_30\nproperty float f_rest_31\nproperty float f_rest_32\nproperty float f_rest_33\nproperty float f_rest_34\nproperty float f_rest_35\nproperty float f_rest_36\nproperty float f_rest_37\nproperty float f_rest_38\nproperty float f_rest_39\nproperty float f_rest_40\nproperty float f_rest_41\nproperty float f_rest_42\nproperty float f_rest_43\nproperty float f_rest_44\nproperty float opacity\nproperty float scale_0\nproperty float scale_1\nproperty float scale_2\nproperty float rot_0\nproperty float rot_1\nproperty float rot_2\nproperty float rot_3\nend_header\n";
            fs.Write(Encoding.UTF8.GetBytes(header));
            
            for (int i = 0; i < data.Length; ++i)
            {
                int wordIdx = i >> 5;
                int bitIdx = i & 31;
                bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                bool isCutout = data[i].nor.sqrMagnitude > 0;
                if (!isDeleted && !isCutout)
                {
                    var splat = data[i];
                    byte* ptr = (byte*)&splat;
                    fs.Write(new ReadOnlySpan<byte>(ptr, kSplatSize));
                }
            }

            Debug.Log($"✓ Exported PLY: {Path.GetFileName(path)} with {aliveCount:N0} splats (cutout applied)");
        }

        private void StartDrawMode()
        {
            m_DrawMode = true;
            SceneView.duringSceneGui += OnSceneGUI;
            Tools.current = Tool.None;
            
            // Focus the scene view to ensure keyboard/mouse events work
            if (SceneView.lastActiveSceneView != null)
            {
                SceneView.lastActiveSceneView.Focus();
            }
            
            SceneView.RepaintAll();
            Debug.Log("🎯 Polygon Drawing Mode: Click in scene view to add vertices. Double-click or press Enter to close.");
        }

        private void FinishDrawMode()
        {
            if (m_Target.m_IsDrawing)
            {
                Undo.RecordObject(m_Target, "Finish Polygon");
                m_Target.ClosePath();
                EditorUtility.SetDirty(m_Target);
            }
            m_DrawMode = false;
            SceneView.duringSceneGui -= OnSceneGUI;
            SceneView.RepaintAll();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!m_DrawMode || m_Target == null) return;

            Event e = Event.current;
            
            // CRITICAL: Capture control at the START to prevent scene view from consuming mouse events
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            if (e.type == EventType.Layout)
            {
                HandleUtility.AddDefaultControl(controlID);
            }
            
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            
            // Try 3D raycast first (note: Gaussian Splat scenes often have no colliders)
            bool hasHit = false;
            Vector3 hitPoint = Vector3.zero;
            
            if (Physics.Raycast(ray, out RaycastHit hit, 1000f))
            {
                hitPoint = hit.point;
                hasHit = true;
            }
            
            // Always use plane fallback if no physics hit - critical for Gaussian Splat scenes
            if (!hasHit)
            {
                // Use camera-facing plane at appropriate depth
                Vector3 planeNormal = -sceneView.camera.transform.forward;
                Vector3 planePoint;
                float defaultDistance = 5f;

                if (m_Target.m_Vertices.Count > 0)
                {
                    // Use first vertex position for plane
                    planePoint = m_Target.transform.TransformPoint(m_Target.m_Vertices[0]);
                }
                else
                {
                    // Use object position, or a point in front of camera
                    planePoint = m_Target.transform.position;
                    
                    // If object is at origin or behind camera, use a point in front
                    Vector3 toObject = planePoint - sceneView.camera.transform.position;
                    if (Vector3.Dot(toObject, sceneView.camera.transform.forward) < 0.5f)
                    {
                        planePoint = sceneView.camera.transform.position + sceneView.camera.transform.forward * defaultDistance;
                    }
                }
                
                Plane drawPlane = new Plane(planeNormal, planePoint);

                if (drawPlane.Raycast(ray, out float enter))
                {
                    hitPoint = ray.GetPoint(enter);
                    hasHit = true;
                }
            }

            if (hasHit)
            {
                m_LastMousePos = hitPoint;

                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = Color.yellow;
                Handles.DrawWireCube(hitPoint, Vector3.one * 0.1f);
                Handles.DrawLine(hitPoint, hitPoint + Vector3.up * 0.2f);
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;

                if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
                {
                    double currentTime = EditorApplication.timeSinceStartup;
                    bool isDoubleClick = (currentTime - m_LastClickTime) < 0.3;
                    m_LastClickTime = currentTime;
                    
                    if (!m_Target.m_IsDrawing)
                    {
                        Undo.RecordObject(m_Target, "Start Drawing Polygon");
                        m_Target.StartDrawing(hitPoint, Vector3.up);
                        EditorUtility.SetDirty(m_Target);
                    }
                    else if (isDoubleClick && m_Target.m_Vertices.Count >= 3)
                    {
                        Undo.RecordObject(m_Target, "Close Polygon (Double-Click)");
                        m_Target.ClosePath();
                        EditorUtility.SetDirty(m_Target);
                        
                        // Auto-apply cutout immediately
                        ApplyCutoutToRenderers();
                        Debug.Log("✓ Polygon closed and cutout applied automatically!");
                    }
                    else
                    {
                        Undo.RecordObject(m_Target, "Add Vertex 3D");
                        m_Target.AddVertex3D(hitPoint);
                        EditorUtility.SetDirty(m_Target);
                    }
                    
                    e.Use();
                    sceneView.Repaint();
                }
                
                // Keyboard shortcuts
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Return && m_Target.m_IsDrawing && m_Target.m_Vertices.Count >= 3)
                {
                    Undo.RecordObject(m_Target, "Close Polygon");
                    m_Target.ClosePath();
                    EditorUtility.SetDirty(m_Target);
                    
                    // Auto-apply cutout immediately
                    ApplyCutoutToRenderers();
                    Debug.Log("✓ Polygon closed and cutout applied automatically!");
                    e.Use();
                }
                
                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape && m_Target.m_IsDrawing)
                {
                    Undo.RecordObject(m_Target, "Cancel Drawing");
                    m_Target.Clear();
                    FinishDrawMode();
                    EditorUtility.SetDirty(m_Target);
                    e.Use();
                }
            }

            // Get vertices for display (visual vertices after normalization)
            var displayVerts = m_Target.GetDisplayVertices();
            
            // Draw existing polygon edges
            if (displayVerts.Count > 1)
            {
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = m_Target.IsClosed ? Color.green : Color.cyan;
                for (int i = 0; i < displayVerts.Count - 1; i++)
                {
                    Vector3 p1 = m_Target.transform.TransformPoint(displayVerts[i]);
                    Vector3 p2 = m_Target.transform.TransformPoint(displayVerts[i + 1]);
                    Handles.DrawLine(p1, p2, 3f);
                }
                
                // Draw closing edge if closed
                if (m_Target.IsClosed && displayVerts.Count > 2)
                {
                    Handles.color = Color.green;
                    Vector3 first = m_Target.transform.TransformPoint(displayVerts[0]);
                    Vector3 last = m_Target.transform.TransformPoint(displayVerts[displayVerts.Count - 1]);
                    Handles.DrawLine(last, first, 3f);
                }
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
            }
            
            // Draw preview line to mouse
            if (m_Target.m_IsDrawing && displayVerts.Count > 0)
            {
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = Color.yellow;
                Vector3 lastVertex = m_Target.transform.TransformPoint(
                    displayVerts[displayVerts.Count - 1]);
                Handles.DrawDottedLine(lastVertex, m_LastMousePos, 2f);
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
            }
            
            // Draw vertex points
            if (displayVerts.Count > 0)
            {
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = Color.cyan;
                for (int i = 0; i < displayVerts.Count; i++)
                {
                    Vector3 worldPos = m_Target.transform.TransformPoint(displayVerts[i]);
                    Handles.SphereHandleCap(0, worldPos, Quaternion.identity, 0.05f, EventType.Repaint);
                }
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
            }

            // Draw instructions overlay
            Handles.BeginGUI();
            GUILayout.BeginArea(new Rect(10, 10, 400, 100));
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            GUILayout.Label("🎯 POLYGON DRAWING MODE ACTIVE", EditorStyles.boldLabel);
            GUILayout.Label("Left-click: Add vertex", EditorStyles.miniLabel);
            GUILayout.Label("Double-click or Enter: Close polygon | Esc: Cancel", EditorStyles.miniLabel);
            
            GUIStyle statusStyle = new GUIStyle(EditorStyles.miniLabel);
            statusStyle.fontStyle = FontStyle.Bold;
            int vertCount = m_Target.m_Vertices.Count;
            if (m_Target.IsClosed)
            {
                statusStyle.normal.textColor = Color.green;
                GUILayout.Label($"Vertices: {vertCount} | ✓ CLOSED", statusStyle);
            }
            else if (m_Target.m_IsDrawing)
            {
                statusStyle.normal.textColor = Color.yellow;
                GUILayout.Label($"Vertices: {vertCount} | Drawing... (need {Mathf.Max(0, 3 - vertCount)} more to close)", statusStyle);
            }
            else
            {
                statusStyle.normal.textColor = Color.cyan;
                GUILayout.Label("Click in scene to start drawing", statusStyle);
            }
            EditorGUILayout.EndVertical();
            GUILayout.EndArea();
            Handles.EndGUI();

            // Also add control on repaint to ensure we keep capturing events
            HandleUtility.AddDefaultControl(controlID);
            sceneView.Repaint();
        }
    }

    [EditorTool("Polygon Mask Draw", typeof(GaussianPolyMask))]
    public class GaussianPolyMaskTool : EditorTool
    {
        private GaussianPolyMask m_PolyMask;
        private Vector3 m_PreviewPoint;
        private double m_LastClickTime = 0;

        public override GUIContent toolbarIcon
        {
            get
            {
                return new GUIContent(
                    EditorGUIUtility.IconContent("EditCollider").image,
                    "Draw Polygon Mask");
            }
        }

        private void OnEnable()
        {
            m_PolyMask = target as GaussianPolyMask;
        }

        public override void OnToolGUI(EditorWindow window)
        {
            if (!(window is SceneView sceneView) || m_PolyMask == null)
                return;

            // Only work in Custom shape mode
            if (m_PolyMask.m_ShapeType != GaussianPolyMask.ShapeType.Custom)
            {
                Handles.BeginGUI();
                GUILayout.BeginArea(new Rect(10, 10, 300, 50));
                GUILayout.Label("Set Shape Type to 'Custom' to use drawing tool", EditorStyles.helpBox);
                GUILayout.EndArea();
                Handles.EndGUI();
                return;
            }

            Event e = Event.current;
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            
            // Try to raycast against scene geometry for 3D placement
            bool hasHit = false;
            Vector3 planeNormal = sceneView.camera.transform.forward;
            
            if (Physics.Raycast(ray, out RaycastHit hit, 100f))
            {
                m_PreviewPoint = hit.point;
                hasHit = true;
            }
            else
            {
                // Fallback: use plane at last vertex or object position
                Plane drawPlane;

                if (m_PolyMask.m_Vertices.Count > 0)
                {
                    Vector3 lastPoint = m_PolyMask.transform.TransformPoint(m_PolyMask.m_Vertices[m_PolyMask.m_Vertices.Count - 1]);
                    drawPlane = new Plane(planeNormal, lastPoint);
                }
                else
                {
                    drawPlane = new Plane(planeNormal, m_PolyMask.transform.position);
                }

                if (drawPlane.Raycast(ray, out float enter))
                {
                    m_PreviewPoint = ray.GetPoint(enter);
                    hasHit = true;
                }
            }

            if (hasHit)
            {
                // Draw preview cursor
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = new Color(0, 1, 1, 0.8f);
                Handles.DrawWireCube(m_PreviewPoint, Vector3.one * 0.15f);
                Handles.DrawLine(m_PreviewPoint, m_PreviewPoint + Vector3.up * 0.3f);
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;

                if (e.type == EventType.MouseDown && e.button == 0 && !e.alt)
                {
                    double currentTime = EditorApplication.timeSinceStartup;
                    bool isDoubleClick = (currentTime - m_LastClickTime) < 0.3;
                    m_LastClickTime = currentTime;
                    
                    if (!m_PolyMask.m_IsDrawing)
                    {
                        Undo.RecordObject(m_PolyMask, "Start Drawing");
                        m_PolyMask.StartDrawing(m_PreviewPoint, Vector3.up);
                    }
                    else if (isDoubleClick && m_PolyMask.m_Vertices.Count >= 3)
                    {
                        Undo.RecordObject(m_PolyMask, "Close Polygon (Double-Click)");
                        m_PolyMask.ClosePath();
                        EditorUtility.SetDirty(m_PolyMask);
                        // Auto-apply cutout immediately
                        GaussianPolyMaskEditor.ApplyCutoutToAllRenderers(m_PolyMask);
                        Debug.Log("✓ Polygon closed and cutout applied automatically!");
                    }
                    else if (m_PolyMask.m_Vertices.Count > 0)
                    {
                        Undo.RecordObject(m_PolyMask, "Add Vertex (3D)");
                        m_PolyMask.AddVertex3D(m_PreviewPoint);
                    }
                    
                    EditorUtility.SetDirty(m_PolyMask);
                    e.Use();
                    sceneView.Repaint();
                }

                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Return && m_PolyMask.m_IsDrawing && m_PolyMask.m_Vertices.Count >= 3)
                {
                    Undo.RecordObject(m_PolyMask, "Close Polygon");
                    m_PolyMask.ClosePath();
                    EditorUtility.SetDirty(m_PolyMask);
                    
                    // Auto-apply cutout immediately
                    GaussianPolyMaskEditor.ApplyCutoutToAllRenderers(m_PolyMask);
                    Debug.Log("✓ Polygon closed and cutout applied automatically!");
                    e.Use();
                }

                if (e.type == EventType.KeyDown && e.keyCode == KeyCode.Escape)
                {
                    Undo.RecordObject(m_PolyMask, "Cancel Drawing");
                    m_PolyMask.Clear();
                    EditorUtility.SetDirty(m_PolyMask);
                    e.Use();
                }
            }

            // Get vertices for display (visual vertices after normalization)
            var displayVerts = m_PolyMask.GetDisplayVertices();
            
            // Draw existing polygon edges
            if (displayVerts.Count > 1)
            {
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = m_PolyMask.IsClosed ? Color.green : Color.cyan;
                for (int i = 0; i < displayVerts.Count - 1; i++)
                {
                    Vector3 p1 = m_PolyMask.transform.TransformPoint(displayVerts[i]);
                    Vector3 p2 = m_PolyMask.transform.TransformPoint(displayVerts[i + 1]);
                    Handles.DrawLine(p1, p2, 3f);
                }
                
                // Draw closing edge if closed
                if (m_PolyMask.IsClosed && displayVerts.Count > 2)
                {
                    Handles.color = Color.green;
                    Vector3 first = m_PolyMask.transform.TransformPoint(displayVerts[0]);
                    Vector3 last = m_PolyMask.transform.TransformPoint(displayVerts[displayVerts.Count - 1]);
                    Handles.DrawLine(last, first, 3f);
                }
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
            }
            
            // Preview line to mouse
            if (m_PolyMask.m_IsDrawing && displayVerts.Count > 0)
            {
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = Color.yellow;
                Vector3 lastVertex = m_PolyMask.transform.TransformPoint(
                    displayVerts[displayVerts.Count - 1]);
                Handles.DrawDottedLine(lastVertex, m_PreviewPoint, 2f);

                // Closing hint
                if (displayVerts.Count >= 3)
                {
                    Vector3 firstPoint = m_PolyMask.transform.TransformPoint(displayVerts[0]);
                    if (Vector3.Distance(m_PreviewPoint, firstPoint) < 0.3f)
                    {
                        Handles.color = Color.green;
                        Handles.DrawWireDisc(firstPoint, planeNormal, 0.3f);
                    }
                }
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
            }
            
            // Draw vertex points
            if (displayVerts.Count > 0)
            {
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                Handles.color = Color.cyan;
                for (int i = 0; i < displayVerts.Count; i++)
                {
                    Vector3 worldPos = m_PolyMask.transform.TransformPoint(displayVerts[i]);
                    Handles.SphereHandleCap(0, worldPos, Quaternion.identity, 0.05f, EventType.Repaint);
                }
                Handles.zTest = UnityEngine.Rendering.CompareFunction.LessEqual;
            }

            // Instructions overlay
            Handles.BeginGUI();
            GUILayout.BeginArea(new Rect(10, 10, 450, 110));
            GUILayout.Label("3D Polygon Drawing Tool", EditorStyles.boldLabel);
            GUILayout.Label("Left-click: Add vertex (raycasts to scene geometry)", EditorStyles.miniLabel);
            GUILayout.Label("Double-click or Enter: Close | Esc: Cancel", EditorStyles.miniLabel);
            
            GUIStyle statusStyle = new GUIStyle(EditorStyles.miniLabel);
            statusStyle.fontStyle = FontStyle.Bold;
            int vertCount = m_PolyMask.GetDisplayVertices().Count;
            if (m_PolyMask.IsClosed)
            {
                statusStyle.normal.textColor = Color.green;
                GUILayout.Label($"Vertices: {vertCount} | ✓ CLOSED (Ready to apply)", statusStyle);
            }
            else
            {
                statusStyle.normal.textColor = Color.yellow;
                GUILayout.Label($"Vertices: {vertCount} | Drawing...", statusStyle);
            }
            GUILayout.EndArea();
            Handles.EndGUI();

            // Force scene view to process events
            int controlID = GUIUtility.GetControlID(FocusType.Passive);
            HandleUtility.AddDefaultControl(controlID);
            
            // Ensure we get layout events
            if (e.type == EventType.Layout)
            {
                HandleUtility.AddDefaultControl(controlID);
            }
            
            sceneView.Repaint();
        }
    }
}

