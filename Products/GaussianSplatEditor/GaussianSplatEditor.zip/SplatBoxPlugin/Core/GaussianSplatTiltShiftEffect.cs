// SPDX-License-Identifier: MIT
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Global settings holder for tilt-shift effect.
    /// Used by both Editor Window and URP Renderer Feature.
    /// </summary>
    public static class GaussianTiltShiftGlobalSettings
    {
        // True only while the Editor Window is driving these values (edit/play mode in the editor).
        // In a player build nothing sets this, so the renderer feature falls back to its own SERIALIZED
        // settings (which persist into the build) instead of these editor-only defaults.
        public static bool Active = false;

        public static bool Enabled = false;
        public static int BlurMode = 0; // 0=TiltShift, 1=DoF, 2=Both
        public static float FocusPosition = 0.58f;
        public static float FocusWidth = 0.05f;
        public static float TiltAngle = 0f;
        public static float FocusDistance = 10f;
        public static float FocusRange = 5f;
        public static float NearBlurStrength = 0.5f;
        public static float FarBlurStrength = 0.8f;
        public static float BlurStrength = 10f;
        public static float TopBlurStrength = 1f;
        public static float BottomBlurStrength = 1f;
        // Shift the top / bottom edge of the sharp focus band independently (>0 = blur edge pushed
        // away from center, <0 = pulled toward center). Used to align the band in VR.
        public static float TopBlurOffset = 0f;
        public static float BottomBlurOffset = 0f;
        public static int BlurSamples = 8;
        public static float BokehShape = 0.5f;
        public static float SaturationBoost = 1f;
        public static float ContrastBoost = 1f;
        public static float VignetteStrength = 0.58f;
        public static bool HighQualityBlur = true;
        
        /// <summary>
        /// Push current globals onto a camera effect (adds component if missing and effect is enabled).
        /// Used by the VR settings menu so tilt-shift updates apply in player builds.
        /// </summary>
        public static void SyncToCamera(Camera cam)
        {
            if (cam == null)
                return;

            var effect = cam.GetComponent<GaussianSplatTiltShiftEffect>();
            if (effect == null && Enabled)
                effect = cam.gameObject.AddComponent<GaussianSplatTiltShiftEffect>();

            if (effect == null)
                return;

            effect.effectEnabled = Enabled;
            effect.blurMode = (GaussianSplatTiltShiftEffect.BlurMode)BlurMode;
            effect.focusPosition = FocusPosition;
            effect.focusWidth = FocusWidth;
            effect.tiltAngle = TiltAngle;
            effect.focusDistance = FocusDistance;
            effect.focusRange = FocusRange;
            effect.nearBlurStrength = NearBlurStrength;
            effect.farBlurStrength = FarBlurStrength;
            effect.blurStrength = BlurStrength;
            effect.topBlurStrength = TopBlurStrength;
            effect.bottomBlurStrength = BottomBlurStrength;
            effect.topBlurOffset = TopBlurOffset;
            effect.bottomBlurOffset = BottomBlurOffset;
            effect.blurSamples = BlurSamples;
            effect.bokehShape = BokehShape;
            effect.saturationBoost = SaturationBoost;
            effect.contrastBoost = ContrastBoost;
            effect.vignetteStrength = VignetteStrength;
            effect.highQualityBlur = HighQualityBlur;
        }

        public static void Reset()
        {
            Active = false;
            Enabled = false;
            BlurMode = 0;
            FocusPosition = 0.58f;
            FocusWidth = 0.05f;
            TiltAngle = 0f;
            FocusDistance = 10f;
            FocusRange = 5f;
            NearBlurStrength = 0.5f;
            FarBlurStrength = 0.8f;
            BlurStrength = 10f;
            TopBlurStrength = 1f;
            BottomBlurStrength = 1f;
            TopBlurOffset = 0f;
            BottomBlurOffset = 0f;
            BlurSamples = 8;
            BokehShape = 0.5f;
            SaturationBoost = 1f;
            ContrastBoost = 1f;
            VignetteStrength = 0.58f;
            HighQualityBlur = true;
        }
    }
    
    /// <summary>
    /// Tilt-shift miniature effect for Gaussian Splats.
    /// Creates a diorama/toy-like appearance by simulating tilt-shift photography.
    /// Works with both Built-in and URP pipelines (for URP, prefer using the Renderer Feature).
    /// </summary>
    [ExecuteInEditMode]
    [RequireComponent(typeof(Camera))]
    [ImageEffectAllowedInSceneView]
    public class GaussianSplatTiltShiftEffect : MonoBehaviour
    {
        public enum BlurMode
        {
            TiltShift,      // Horizontal band focus (miniature effect)
            DepthOfField,   // Near/far camera blur
            Both            // Combined effects
        }
        
        [Header("Blur Mode")]
        [Tooltip("Type of blur effect to apply")]
        public BlurMode blurMode = BlurMode.TiltShift;
        
        [Header("Tilt-Shift Focus (Miniature Effect)")]
        [Range(0f, 1f)]
        [Tooltip("Vertical position of the focus band (0=bottom, 1=top)")]
        public float focusPosition = 0.58f;
        
        [Range(0.001f, 0.8f)]
        [Tooltip("Width of the focus band (larger = more in focus)")]
        public float focusWidth = 0.05f;
        
        [Range(-45f, 45f)]
        [Tooltip("Rotation angle of the focus plane")]
        public float tiltAngle = 0f;
        
        [Header("Depth of Field (Camera Blur)")]
        [Tooltip("Distance from camera where focus begins")]
        public float focusDistance = 10f;
        
        [Range(0.1f, 50f)]
        [Tooltip("Range around focus distance that stays sharp")]
        public float focusRange = 5f;
        
        [Range(0f, 1f)]
        [Tooltip("Blur strength for objects closer than focus")]
        public float nearBlurStrength = 0.5f;
        
        [Range(0f, 1f)]
        [Tooltip("Blur strength for objects farther than focus")]
        public float farBlurStrength = 0.8f;
        
        [Header("Blur Settings")]
        [Range(0f, 25f)]
        [Tooltip("Strength of the blur in virtual 720p pixels. It is scaled automatically for high-resolution XR eye textures.")]
        public float blurStrength = 10f;

        [Range(0f, 2f)]
        [Tooltip("Multiplier for blur above the focus band")]
        public float topBlurStrength = 1f;

        [Range(0f, 2f)]
        [Tooltip("Multiplier for blur below the focus band")]
        public float bottomBlurStrength = 1f;

        [Range(-0.5f, 0.5f)]
        [Tooltip("Moves the top blur edge up (+) or down (-) independently of the focus band, to align the sharp band in VR.")]
        public float topBlurOffset = 0f;

        [Range(-0.5f, 0.5f)]
        [Tooltip("Moves the bottom blur edge down (+) or up (-) independently of the focus band, to align the sharp band in VR.")]
        public float bottomBlurOffset = 0f;
        
        [Range(3, 16)]
        [Tooltip("Number of blur samples (higher = smoother but slower)")]
        public int blurSamples = 8;
        
        [Range(0f, 1f)]
        [Tooltip("Bokeh shape intensity (0=uniform, 1=ring-shaped)")]
        public float bokehShape = 0.5f;
        
        [Header("Miniature Color Enhancement")]
        [Range(0.5f, 2f)]
        [Tooltip("Boost color saturation for toy-like appearance")]
        public float saturationBoost = 1f;
        
        [Range(0.5f, 2f)]
        [Tooltip("Boost contrast for sharper miniature look")]
        public float contrastBoost = 1f;
        
        [Range(0f, 1f)]
        [Tooltip("Vignette darkening at edges")]
        public float vignetteStrength = 0.58f;
        
        [Header("Quality")]
        [Tooltip("Use high-quality multi-pass blur (slower but better)")]
        public bool highQualityBlur = true;
        
        [Tooltip("Enable/disable the effect")]
        public bool effectEnabled = true;

        // Serialized so the shader reference is saved with the component and included in builds.
        [SerializeField, HideInInspector] private Shader m_TiltShiftShader;
        private Material m_Material;
        private Camera m_Camera;
        private bool m_IsURP;
        
        private static readonly int PropFocusPosition = Shader.PropertyToID("_FocusPosition");
        private static readonly int PropFocusWidth = Shader.PropertyToID("_FocusWidth");
        private static readonly int PropBlurStrength = Shader.PropertyToID("_BlurStrength");
        private static readonly int PropTopBlurStrength = Shader.PropertyToID("_TopBlurStrength");
        private static readonly int PropBottomBlurStrength = Shader.PropertyToID("_BottomBlurStrength");
        private static readonly int PropTopBlurOffset = Shader.PropertyToID("_TopBlurOffset");
        private static readonly int PropBottomBlurOffset = Shader.PropertyToID("_BottomBlurOffset");
        private static readonly int PropBlurSamples = Shader.PropertyToID("_BlurSamples");
        private static readonly int PropTiltAngle = Shader.PropertyToID("_TiltAngle");
        private static readonly int PropSaturationBoost = Shader.PropertyToID("_SaturationBoost");
        private static readonly int PropContrastBoost = Shader.PropertyToID("_ContrastBoost");
        private static readonly int PropVignetteStrength = Shader.PropertyToID("_VignetteStrength");
        private static readonly int PropBokehShape = Shader.PropertyToID("_BokehShape");
        private static readonly int PropBlurMode = Shader.PropertyToID("_BlurMode");
        private static readonly int PropFocusDistance = Shader.PropertyToID("_FocusDistance");
        private static readonly int PropFocusRange = Shader.PropertyToID("_FocusRange");
        private static readonly int PropNearBlurStrength = Shader.PropertyToID("_NearBlurStrength");
        private static readonly int PropFarBlurStrength = Shader.PropertyToID("_FarBlurStrength");

        private void OnEnable()
        {
            m_Camera = GetComponent<Camera>();
            m_IsURP = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null;
            CreateMaterial();
        }

        private void OnDisable()
        {
            CleanupResources();
        }

        private void OnDestroy()
        {
            CleanupResources();
        }

        private void FindTiltShiftShader()
        {
            if (m_TiltShiftShader == null)
                m_TiltShiftShader = Shader.Find("Hidden/Gaussian Splatting/TiltShift");
        }

#if UNITY_EDITOR
        private void OnValidate() => FindTiltShiftShader();
        private void Reset() => FindTiltShiftShader();
#endif

        private void CreateMaterial()
        {
            if (m_Material != null) return;
            
            // Use serialized reference first; fall back to Shader.Find
            FindTiltShiftShader();
            if (m_TiltShiftShader == null)
            {
                Debug.LogWarning("GaussianSplatTiltShiftEffect: TiltShift shader not found!");
                return;
            }
            
            if (!m_TiltShiftShader.isSupported)
            {
                Debug.LogWarning("GaussianSplatTiltShiftEffect: TiltShift shader not supported!");
                return;
            }
            
            m_Material = new Material(m_TiltShiftShader);
            m_Material.hideFlags = HideFlags.HideAndDontSave;
        }

        private void CleanupResources()
        {
            if (m_Material != null)
            {
                if (Application.isPlaying)
                    Destroy(m_Material);
                else
                    DestroyImmediate(m_Material);
                m_Material = null;
            }
        }

        private void UpdateMaterialProperties()
        {
            if (m_Material == null) return;
            
            m_Material.SetFloat(PropFocusPosition, focusPosition);
            m_Material.SetFloat(PropFocusWidth, focusWidth);
            m_Material.SetFloat(PropBlurStrength, blurStrength);
            m_Material.SetFloat(PropTopBlurStrength, topBlurStrength);
            m_Material.SetFloat(PropBottomBlurStrength, bottomBlurStrength);
            m_Material.SetFloat(PropTopBlurOffset, topBlurOffset);
            m_Material.SetFloat(PropBottomBlurOffset, bottomBlurOffset);
            m_Material.SetFloat(PropBlurSamples, blurSamples);
            m_Material.SetFloat(PropTiltAngle, tiltAngle);
            m_Material.SetFloat(PropSaturationBoost, saturationBoost);
            m_Material.SetFloat(PropContrastBoost, contrastBoost);
            m_Material.SetFloat(PropVignetteStrength, vignetteStrength);
            m_Material.SetFloat(PropBokehShape, bokehShape);
            m_Material.SetFloat(PropBlurMode, (float)blurMode);
            m_Material.SetFloat(PropFocusDistance, focusDistance);
            m_Material.SetFloat(PropFocusRange, focusRange);
            m_Material.SetFloat(PropNearBlurStrength, nearBlurStrength);
            m_Material.SetFloat(PropFarBlurStrength, farBlurStrength);
        }

        // This is the key method for built-in render pipeline
        // In URP, the GaussianTiltShiftRendererFeature reads settings from this component
        [ImageEffectOpaque]
        private void OnRenderImage(RenderTexture source, RenderTexture destination)
        {
            // In URP, the Renderer Feature handles rendering - this component just provides settings
            if (m_IsURP)
            {
                Graphics.Blit(source, destination);
                return;
            }
            
            if (!effectEnabled || m_Material == null || blurStrength < 0.01f)
            {
                Graphics.Blit(source, destination);
                return;
            }
            
            if (m_Material == null)
            {
                CreateMaterial();
                if (m_Material == null)
                {
                    Graphics.Blit(source, destination);
                    return;
                }
            }
            
            UpdateMaterialProperties();
            
            // Use the built-in fallback subshader (pass 0 in second SubShader)
            // For built-in pipeline, we use the combined pass
            Graphics.Blit(source, destination, m_Material, 0);
        }

        /// <summary>
        /// Get the tilt-shift material for external use
        /// </summary>
        public Material GetMaterial()
        {
            if (m_Material == null)
                CreateMaterial();
            UpdateMaterialProperties();
            return m_Material;
        }

        /// <summary>
        /// Set focus position from world space point
        /// </summary>
        public void SetFocusFromWorldPoint(Vector3 worldPoint)
        {
            if (m_Camera == null) return;
            
            Vector3 viewportPos = m_Camera.WorldToViewportPoint(worldPoint);
            focusPosition = Mathf.Clamp01(viewportPos.y);
        }

        /// <summary>
        /// Reset to default miniature effect settings
        /// </summary>
        public void ResetToDefaults()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.5f;
            focusWidth = 0.05f;
            tiltAngle = 0f;
            focusDistance = 10f;
            focusRange = 5f;
            nearBlurStrength = 0.5f;
            farBlurStrength = 0.8f;
            blurStrength = 10f;
            topBlurOffset = 0f;
            bottomBlurOffset = 0f;
            blurSamples = 8;
            bokehShape = 0.5f;
            saturationBoost = 1f;
            contrastBoost = 1f;
            vignetteStrength = 0.58f;
            highQualityBlur = true;
            effectEnabled = true;
        }

        /// <summary>
        /// Apply a preset for extreme miniature look
        /// </summary>
        public void ApplyMiniaturePreset()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.35f;
            focusWidth = 0.15f;
            tiltAngle = 0f;
            blurStrength = 6f;
            blurSamples = 10;
            bokehShape = 0.6f;
            saturationBoost = 1.5f;
            contrastBoost = 1.25f;
            vignetteStrength = 0.35f;
        }

        /// <summary>
        /// Apply a preset for subtle tilt effect
        /// </summary>
        public void ApplySubtlePreset()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.45f;
            focusWidth = 0.35f;
            tiltAngle = 0f;
            blurStrength = 2.5f;
            blurSamples = 6;
            bokehShape = 0.3f;
            saturationBoost = 1.15f;
            contrastBoost = 1.08f;
            vignetteStrength = 0.15f;
        }

        /// <summary>
        /// Apply a preset for diagonal tilt
        /// </summary>
        public void ApplyDiagonalPreset()
        {
            blurMode = BlurMode.TiltShift;
            focusPosition = 0.5f;
            focusWidth = 0.2f;
            tiltAngle = 30f;
            blurStrength = 5f;
            blurSamples = 8;
            bokehShape = 0.5f;
            saturationBoost = 1.35f;
            contrastBoost = 1.2f;
            vignetteStrength = 0.3f;
        }

        /// <summary>
        /// Apply depth of field preset - portrait style (shallow DoF)
        /// </summary>
        public void ApplyPortraitDoFPreset()
        {
            blurMode = BlurMode.DepthOfField;
            focusDistance = 5f;
            focusRange = 2f;
            nearBlurStrength = 0.3f;
            farBlurStrength = 0.9f;
            blurStrength = 5f;
            blurSamples = 8;
            bokehShape = 0.7f;
            saturationBoost = 1.1f;
            contrastBoost = 1.05f;
            vignetteStrength = 0.2f;
        }

        /// <summary>
        /// Apply depth of field preset - landscape style (deep focus far)
        /// </summary>
        public void ApplyLandscapeDoFPreset()
        {
            blurMode = BlurMode.DepthOfField;
            focusDistance = 20f;
            focusRange = 15f;
            nearBlurStrength = 0.7f;
            farBlurStrength = 0.2f;
            blurStrength = 4f;
            blurSamples = 8;
            bokehShape = 0.4f;
            saturationBoost = 1.2f;
            contrastBoost = 1.1f;
            vignetteStrength = 0.15f;
        }

        /// <summary>
        /// Apply combined tilt-shift + DoF preset
        /// </summary>
        public void ApplyCinematicPreset()
        {
            blurMode = BlurMode.Both;
            focusPosition = 0.45f;
            focusWidth = 0.3f;
            tiltAngle = 0f;
            focusDistance = 8f;
            focusRange = 4f;
            nearBlurStrength = 0.4f;
            farBlurStrength = 0.6f;
            blurStrength = 4f;
            blurSamples = 10;
            bokehShape = 0.5f;
            saturationBoost = 1.25f;
            contrastBoost = 1.15f;
            vignetteStrength = 0.3f;
        }
    }
}
