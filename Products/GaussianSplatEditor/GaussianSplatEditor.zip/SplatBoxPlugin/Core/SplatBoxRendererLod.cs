// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    public partial class SplatBoxRenderer
    {
        [Header("Paged LoD Streaming (Quest)")]
        [Tooltip("When set, splats are streamed by spatial page and rendered up to a configurable maximum LoD budget.")]
        [SerializeField] GaussianSplatPagedScene m_PagedScene;
        [SerializeField] SplatBoxLodStreamer m_LodStreamer;
        [Tooltip("Simple derives every LoD quality setting from one Quality slider. Advanced exposes " +
                 "the individual knobs; use it only when the slider cannot express what you need.")]
        [SerializeField] bool m_LodSimpleMode = true;
        [Tooltip("How much detail the scene keeps into the distance. Raising it grows the splat " +
                 "budget and lets refinement continue to finer screen sizes; lowering it is faster.")]
        [Range(0f, 1f)] [SerializeField] float m_LodQuality = 0.5f;
        [Tooltip("Maximum splats drawn at once. Detail is spent on whatever is largest on screen.")]
        [Range(50_000, 2_000_000)] [SerializeField] int m_LodSplatBudget = 500_000;
        [Tooltip("Use the standard Gaussian shader for paged LoD while editing. The relight shader " +
                 "evaluates scene lighting six times per splat (once per quad vertex), which is very " +
                 "expensive for large previews. Play mode and builds still use the configured shader.")]
        [SerializeField] bool m_LodFastEditorPreview = true;
        [Tooltip("Stop refining a node once it covers fewer than this many screen pixels. " +
                 "0 = tune automatically to fit the budget, which is usually what you want.")]
        [Range(0f, 8f)] [SerializeField] float m_LodPixelScaleLimit = 0f;
        [Tooltip("Quality multiplier. Below 1 the scene is treated as smaller on screen, so less of " +
                 "the budget is spent on detail. Does not change the budget itself.")]
        [Range(0.1f, 2f)] [SerializeField] float m_LodDetailScale = 1f;
        [Tooltip("Skip LoD nodes outside the camera frustum so the budget is spent on what you can see.")]
        [SerializeField] bool m_LodFrustumCull = true;
        [Tooltip("Draw the merged stand-in splats that represent pages held at coarse detail. Turn " +
                 "this off to draw only real splats: the scene gets holes where detail is missing, " +
                 "but nothing is approximated. Useful for pages built by an older, broken merge.")]
        [SerializeField] bool m_LodDrawCoarseStandIns = true;
        [Tooltip("Drop a coarse stand-in once it would cover more than this many screen pixels. Blend " +
                 "cost grows with area while the splat budget only counts splats, so one huge stand-in " +
                 "costs thousands of refined splats and represents almost nothing. Lower is faster and " +
                 "leaves holes until detail streams in; raise it if holes bother you more than speed.")]
        [Range(0f, 512f)] [SerializeField] float m_LodMaxStandInPixels =
            SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels;
        [Tooltip("Extra degrees of field of view used when culling. Guards against splats popping at " +
                 "the edge of the view; stereo cameras get an additional margin automatically.")]
        [Range(0f, 45f)] [SerializeField] float m_LodCullPaddingDeg = 10f;
        [Tooltip("GPU memory ceiling for the resident page atlas. Fewer pages are held at full detail " +
                 "when the budget is tight. Keep this well below total VRAM (256 MB or less on Quest).")]
        [Range(64, 4096)] [SerializeField] int m_LodAtlasBudgetMB = 1024;
        [Range(0.05f, 1f)] [SerializeField] float m_OutsideFoveate = 0.4f;
        [Range(0.05f, 1f)] [SerializeField] float m_BehindFoveate = 0.2f;

        int m_ActiveSplatCount;
        int m_LodAllocatedBudget;
        int m_UnifiedAtlasSplatCount;
        int m_LodAtlasCapacity;
        GraphicsBuffer m_GpuLodAtlasIndices;
        GraphicsBuffer m_GpuLodUnifiedPos;
        GraphicsBuffer m_GpuLodUnifiedOther;
        GraphicsBuffer m_GpuLodUnifiedSh;
        Texture2D m_GpuLodUnifiedColor;
        GraphicsBuffer m_GpuLodUnifiedChunks;
        int m_LodUnifiedChunkCount;
        LodActiveSplatRef[] m_LodActiveScratch;
        uint[] m_LodAtlasIndexScratch;
        bool m_LodAtlasDirty = true;
        bool m_LodSelectionDirty = true;
        int m_LodPosWordsPerSplat;
        int m_LodOtherWordsPerSplat;
        int m_LodShWordsPerSplat;
        GaussianSplatAsset m_LodFormatAsset;
        GaussianSplatPagedScene m_PrevPagedScene;

        public bool UsesPagedLod => m_PagedScene != null && m_PagedScene.pageCount > 0;
        public int activeSplatCount => UsesPagedLod ? m_ActiveSplatCount : m_SplatCount;
        public GaussianSplatPagedScene pagedScene => m_PagedScene;
        public SplatBoxLodStreamer lodStreamer => m_LodStreamer;

        /// <summary>
        /// Screen size below which refinement stops; 0 spends the whole budget. Reports the value
        /// actually in effect, which in Simple mode is derived from the Quality slider.
        /// </summary>
        public float lodPixelScaleLimit => EffectivePixelScaleLimit;

        /// <summary>Quality multiplier applied to on-screen size during LoD traversal.</summary>
        public float lodDetailScale => m_LodDetailScale;

        /// <summary>
        /// Whether merged stand-in splats are drawn for pages held at coarse detail. Always true in
        /// Simple mode, where the whole scene staying visible is part of the contract.
        /// </summary>
        public bool drawsCoarseStandIns => EffectiveDrawCoarseStandIns;

        /// <summary>Full-detail page slots the atlas currently provides.</summary>
        public int lodAtlasDetailSlots => m_AtlasDetailSlots;

        /// <summary>
        /// Splats each detail slot reserves. Slots are uniform and sized for the largest page in the
        /// scene, so one oversized page inflates the cost of every slot.
        /// </summary>
        public int lodAtlasSlotSplats => m_AtlasDetailStride;

        /// <summary>Names of the LoD quality fields, for editor tooling that writes them.</summary>
        public const string kPropLodPixelScaleLimit = "m_LodPixelScaleLimit";
        public const string kPropLodDetailScale = "m_LodDetailScale";
        public const string kPropLodDrawCoarseStandIns = "m_LodDrawCoarseStandIns";
        public const string kPropLodSimpleMode = "m_LodSimpleMode";
        public const string kPropLodQuality = "m_LodQuality";

        /// <summary>Total splats across every page of the paged scene (all LoD levels included).</summary>
        public int pagedSceneSplatCount
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return 0;
                int total = 0;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                    total += m_PagedScene.pages[i].splatCount;
                return total;
            }
        }

        /// <summary>
        /// True when any page still uses the depth-first LoD layout, which cannot supply a coarse
        /// prefix — those pages fall back to a single splat when they are outside the detail radius.
        /// </summary>
        public bool hasLegacyLodPages
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return false;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                {
                    var asset = m_PagedScene.pages[i].pageAsset;
                    if (asset != null && !asset.hasLevelOrderLodTree)
                        return true;
                }
                return false;
            }
        }

        /// <summary>
        /// True for page assets exported before tree and payload ordering were kept in sync.
        /// Those assets cannot render correctly because a selected node addresses another splat.
        /// </summary>
        public bool hasMismatchedLodSplatOrder
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return false;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                {
                    var asset = m_PagedScene.pages[i].pageAsset;
                    if (asset != null && !asset.hasMatchingLodSplatOrder)
                        return true;
                }
                return false;
            }
        }

        /// <summary>Pages currently held at full detail (the rest keep a coarse LoD prefix).</summary>
        public int detailPageCount
        {
            get
            {
                if (m_LodStreamer == null)
                    return 0;
                var pages = m_LodStreamer.loadedPages;
                int count = 0;
                for (int i = 0; i < pages.Count; i++)
                {
                    if (pages[i] != null && !pages[i].isCoarseStub)
                        count++;
                }
                return count;
            }
        }

        // ---- Simple quality mode ----------------------------------------------------------------
        // One Quality slider stands in for the detailed knobs. The mappings are public statics so
        // the inspector and the VR settings menu can show the numbers a quality value stands for.
        // In Simple mode the detailed fields are ignored, not overwritten: switching back to
        // Advanced finds them exactly as they were left.

        /// <summary>Smallest splat budget the Quality slider will ask for.</summary>
        public const int kLodQualityMinBudget = 100_000;
        /// <summary>Largest splat budget the Quality slider will ask for.</summary>
        public const int kLodQualityMaxBudget = 2_000_000;

        /// <summary>
        /// Splat budget for a Quality value. Log-spaced so the slider feels even: every step scales
        /// the budget by the same factor instead of adding a fixed amount. Rounded to 25k steps so a
        /// drag crosses a handful of buffer reallocations rather than one per slider pixel.
        /// </summary>
        public static int LodQualityToBudget(float quality)
        {
            float t = Mathf.Clamp01(quality);
            float budget = Mathf.Exp(Mathf.Lerp(
                Mathf.Log(kLodQualityMinBudget), Mathf.Log(kLodQualityMaxBudget), t));
            return Mathf.RoundToInt(budget / 25_000f) * 25_000;
        }

        /// <summary>Quality value whose budget mapping is nearest to <paramref name="budget"/>.</summary>
        public static float LodQualityFromBudget(int budget)
        {
            float clamped = Mathf.Clamp(budget, kLodQualityMinBudget, kLodQualityMaxBudget);
            return Mathf.InverseLerp(
                Mathf.Log(kLodQualityMinBudget), Mathf.Log(kLodQualityMaxBudget), Mathf.Log(clamped));
        }

        /// <summary>
        /// Screen size (pixels) below which refinement stops, for a Quality value: 6 px at 0 down to
        /// the 1 px automatic floor at 1, exponential so the middle of the slider looks balanced.
        /// </summary>
        public static float LodQualityToPixelCutoff(float quality) =>
            Mathf.Pow(6f, 1f - Mathf.Clamp01(quality));

        /// <summary>Foveation factor for nodes outside the view frustum, for a Quality value.</summary>
        public static float LodQualityToOutsideFoveate(float quality) =>
            Mathf.Lerp(0.25f, 0.55f, Mathf.Clamp01(quality));

        /// <summary>Foveation factor for nodes behind the camera, for a Quality value.</summary>
        public static float LodQualityToBehindFoveate(float quality) =>
            Mathf.Lerp(0.1f, 0.3f, Mathf.Clamp01(quality));

        // Detail Scale is deliberately not derived from Quality: it stays a live multiplier in both
        // modes (default 1) because the VR settings menu drives it at runtime.
        float EffectivePixelScaleLimit => m_LodSimpleMode
            ? LodQualityToPixelCutoff(m_LodQuality)
            : m_LodPixelScaleLimit;
        float EffectiveOutsideFoveate => m_LodSimpleMode
            ? LodQualityToOutsideFoveate(m_LodQuality)
            : m_OutsideFoveate;
        float EffectiveBehindFoveate => m_LodSimpleMode
            ? LodQualityToBehindFoveate(m_LodQuality)
            : m_BehindFoveate;
        // Keep the whole scene filled: coarse stand-ins are what cover pages that have not yet
        // taken a detail slot. Simple mode always uses the full slider so the first frame is not a
        // sea of holes or tiny blobs.
        float EffectiveMaxStandInPixels => m_LodSimpleMode
            ? SplatBoxLodTraverser.ViewContext.kDefaultMaxStandInPixels
            : m_LodMaxStandInPixels;
        // Padding must absorb the view rotation that can happen between two selection refreshes
        // (20 Hz in the editor), or turning the camera briefly shows the un-padded cull boundary.
        float EffectiveCullPaddingDeg => m_LodSimpleMode ? 15f : m_LodCullPaddingDeg;
        bool EffectiveFrustumCull => m_LodSimpleMode || m_LodFrustumCull;
        bool EffectiveDrawCoarseStandIns => m_LodSimpleMode || m_LodDrawCoarseStandIns;

        /// <summary>Whether the one-slider Simple quality mode is active.</summary>
        public bool lodSimpleMode
        {
            get => m_LodSimpleMode;
            set
            {
                if (m_LodSimpleMode == value)
                    return;
                m_LodSimpleMode = value;
                m_LodSelectionDirty = true;
            }
        }

        /// <summary>Simple-mode quality, 0 = fastest, 1 = best. Ignored in Advanced mode.</summary>
        public float lodQuality
        {
            get => m_LodQuality;
            set => SetLodQuality(value);
        }

        public void SetLodQuality(float quality)
        {
            float clamped = Mathf.Clamp01(quality);
            if (Mathf.Approximately(m_LodQuality, clamped))
                return;

            m_LodQuality = clamped;
            m_LodSelectionDirty = true;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            UnityEditor.SceneView.RepaintAll();
#endif
        }

        /// <summary>
        /// Splats the LoD system may draw. Quality is traded through <see cref="m_LodDetailScale"/>
        /// and the pixel cutoff rather than by shrinking this, so the GPU buffers sized from it stay
        /// valid when quality settings change at runtime.
        /// </summary>
        public int EffectiveLodBudget => Mathf.Clamp(
            m_LodSimpleMode ? LodQualityToBudget(m_LodQuality) : m_LodSplatBudget,
            10_000, 2_000_000);

        /// <summary>
        /// On-screen size (pixels) at which refinement actually stopped last selection, exposed for
        /// the inspector. 0 means the budget covered every leaf in view.
        /// </summary>
        public float currentLodPixelScaleLimit => m_LastEffectiveCutoff;

        /// <summary>Real leaf splats in the last LoD selection (diagnostic).</summary>
        public int lastLodLeafCount => m_LodWorkspace?.emittedLeaves ?? 0;

        /// <summary>Merged stand-in splats in the last LoD selection (diagnostic).</summary>
        public int lastLodMergedCount => m_LodWorkspace?.emittedMerged ?? 0;

        /// <summary>Merged stand-in splats dropped from the last LoD selection (diagnostic).</summary>
        public int lastLodMergedDropCount => m_LodWorkspace?.droppedMerged ?? 0;

        void EnsureLodStreamer()
        {
            if (!UsesPagedLod)
                return;
            if (m_LodStreamer == null)
                m_LodStreamer = GetComponent<SplatBoxLodStreamer>();
            if (m_LodStreamer == null)
                m_LodStreamer = gameObject.AddComponent<SplatBoxLodStreamer>();
            if (m_LodStreamer.pagedScene != m_PagedScene)
                m_LodStreamer.Configure(m_PagedScene, transform);
            m_LodStreamer.OnPagesChanged -= OnLodPagesChanged;
            m_LodStreamer.OnPagesChanged += OnLodPagesChanged;
        }

        void OnLodPagesChanged()
        {
            SplatBoxLodDiagnostics.RecordPageEvent();
            m_LodAtlasDirty = true;
            m_LodLastPageEventTime = Time.realtimeSinceStartup;

            // Cold start still needs an immediate selection.
            if (m_ActiveSplatCount <= 0)
            {
                m_LodSelectionDirty = true;
                m_LodPendingSettledReselect = true;
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    UnityEditor.SceneView.RepaintAll();
#endif
                return;
            }

            // Full-detail upgrades/downgrades change what leaf data exists and must reselect soon.
            // Pure coarse stub arrivals used to dirty selection every frame while 100+ pages streamed
            // in, re-splitting the budget each time and flickering near surfaces between leaf and
            // giant stand-in sizes. Fold those into one settled refresh after the burst quietens.
            int fullPages = 0;
            var loaded = m_LodStreamer?.loadedPages;
            if (loaded != null)
            {
                for (int i = 0; i < loaded.Count; i++)
                {
                    if (loaded[i] != null && !loaded[i].isCoarseStub)
                        fullPages++;
                }
            }

            if (fullPages != m_LodLastFullPageCount)
            {
                m_LodLastFullPageCount = fullPages;
                m_LodSelectionDirty = true;
                m_LodPendingSettledReselect = true;
            }
            else
            {
                m_LodPendingSettledReselect = true;
            }
#if UNITY_EDITOR
            if (!Application.isPlaying)
                UnityEditor.SceneView.RepaintAll();
#endif
        }

        int m_LodLastFullPageCount = -1;

        void InitPagedLodResources()
        {
            if (!UsesPagedLod)
                return;

            EnsureLodStreamer();

            if (hasMismatchedLodSplatOrder)
            {
                m_ActiveSplatCount = 0;
                Debug.LogError(
                    "SplatBoxRenderer: this paged LoD scene was built with mismatched tree and splat " +
                    "ordering. It cannot render correctly and can select unexpectedly huge splats. " +
                    "Rebuild it with Tools > Gaussian Splatting > Create Paged LoD Scene.");
                return;
            }

            var firstPage = m_PagedScene.pages[0].pageAsset;
            m_LodFormatAsset = firstPage != null ? firstPage.splatData : null;
            if (m_LodFormatAsset == null)
            {
                Debug.LogError("SplatBoxRenderer: Paged scene has no valid page assets.");
                return;
            }

            if (m_LodFormatAsset.chunkData != null && m_LodFormatAsset.chunkData.dataSize != 0)
            {
                Debug.LogWarning(
                    "SplatBoxRenderer: Paged LoD pages use chunk-compressed quality. " +
                    "Rebuild with Tools > Create Paged LoD Scene using Quality = Very High for reliable rendering.");
            }

            m_SplatCount = EffectiveLodBudget;
            m_LodPosWordsPerSplat = Mathf.Max(1, (int)(m_LodFormatAsset.posData.dataSize / m_LodFormatAsset.splatCount / 4));
            m_LodOtherWordsPerSplat = Mathf.Max(1, (int)(m_LodFormatAsset.otherData.dataSize / m_LodFormatAsset.splatCount / 4));
            m_LodShWordsPerSplat = Mathf.Max(1, (int)(m_LodFormatAsset.shData.dataSize / m_LodFormatAsset.splatCount / 4));

            int maxAtlasSplats = EstimateMaxAtlasSplats();
            AllocateLodAtlasBuffers(maxAtlasSplats);
            AllocateActiveRenderBuffers(EffectiveLodBudget);

            m_LodActiveScratch = new LodActiveSplatRef[EffectiveLodBudget];
            m_LodAtlasIndexScratch = new uint[EffectiveLodBudget];
            m_LodAllocatedBudget = EffectiveLodBudget;
            m_LodAtlasDirty = true;
            m_LodSelectionDirty = true;
            m_ActiveSplatCount = 0;
            m_LodLastFullPageCount = -1;
            SyncPagedLodChunkBindings(false);

            PreloadPagedLodPages(ResolvePagedLodCamera());
#if UNITY_EDITOR
            // OnEnable often runs before any Scene view camera exists. Preload then only sees the
            // object pivot and may leave activeSplatCount at 0 until something (historically: enter
            // and exit Play mode) re-inits with a real view. Schedule a follow-up once the editor
            // has a camera so the Scene view fills without that Play-mode dance.
            if (!Application.isPlaying)
                ScheduleEditorPagedLodWarmup();
#endif
        }

        /// <summary>
        /// Camera that drives streaming and LoD selection. Prefer the tagged Main Camera so Game
        /// view / Play / VR focus matches the camera the user positions near the splats. Scene view
        /// is only a fallback when no Main Camera exists yet.
        /// </summary>
        static Camera ResolvePagedLodCamera()
        {
            var main = Camera.main;
            if (main != null)
                return main;
#if UNITY_EDITOR
            if (!Application.isPlaying && UnityEditor.SceneView.lastActiveSceneView != null)
                return UnityEditor.SceneView.lastActiveSceneView.camera;
#endif
            return null;
        }

        void SyncPagedLodChunkBindings(bool chunksPopulated = false)
        {
            if (!UsesPagedLod)
                return;
            if (chunksPopulated && m_GpuLodUnifiedChunks != null && m_LodUnifiedChunkCount > 0)
            {
                m_GpuChunks = m_GpuLodUnifiedChunks;
                m_GpuChunksValid = true;
            }
            else
            {
                m_GpuChunks ??= new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = "LodDummyChunks" };
                m_GpuChunksValid = false;
            }
        }

        struct PagedLodGpuBindings
        {
            public GraphicsBuffer pos;
            public GraphicsBuffer other;
            public GraphicsBuffer sh;
            public GraphicsBuffer chunks;
            public Texture color;
            public int chunkCount;
        }

        void GetSplatComputeBindings(
            out GraphicsBuffer posBuf,
            out GraphicsBuffer otherBuf,
            out GraphicsBuffer shBuf,
            out Texture colorTex,
            out GraphicsBuffer chunkBuf,
            out int chunkCount,
            out GraphicsBuffer remapBuf,
            out int useRemap)
        {
            posBuf = m_GpuPosData;
            otherBuf = m_GpuOtherData;
            shBuf = m_GpuSHData;
            colorTex = m_GpuColorData;
            chunkBuf = m_GpuChunks;
            chunkCount = m_GpuChunksValid ? m_GpuChunks.count : 0;
            remapBuf = m_GpuSortKeys;
            useRemap = 0;

            if (TryGetPagedLodGpuBindings(out var paged))
            {
                posBuf = paged.pos;
                otherBuf = paged.other;
                shBuf = paged.sh;
                colorTex = paged.color;
                chunkBuf = paged.chunks;
                chunkCount = paged.chunkCount;
                remapBuf = m_GpuLodAtlasIndices;
                useRemap = 1;
            }
        }

        bool TryGetPagedLodGpuBindings(out PagedLodGpuBindings bindings)
        {
            bindings = default;
            if (!UsesPagedLod || m_GpuLodUnifiedPos == null || m_GpuLodAtlasIndices == null ||
                m_UnifiedAtlasSplatCount <= 0)
                return false;
            bindings.pos = m_GpuLodUnifiedPos;
            bindings.other = m_GpuLodUnifiedOther;
            bindings.sh = m_GpuLodUnifiedSh;
            bindings.color = m_GpuLodUnifiedColor;
            bindings.chunks = m_GpuLodUnifiedChunks ?? m_GpuChunks;
            bindings.chunkCount = m_GpuChunksValid && m_LodUnifiedChunkCount > 0
                ? m_LodUnifiedChunkCount
                : 0;
            return true;
        }

        // Row alignment (a multiple of the 256-splat chunk size) lets each page's colour data move
        // in a single full-width CopyTexture instead of one call per texture row, and keeps every
        // page's chunk-compressed data aligned to its own ChunkInfo entries.
        const int kAtlasSplatAlignment = GaussianSplatAsset.kTextureWidth;

        static int AlignAtlasSplatOffset(int splatOffset) =>
            (splatOffset + kAtlasSplatAlignment - 1) / kAtlasSplatAlignment * kAtlasSplatAlignment;

        // Fixed atlas addressing. Each page owns a permanent region big enough for its coarse tier,
        // and full-detail pages additionally borrow one of a small pool of equally sized detail
        // slots. Because a page's address never depends on what else is loaded, streaming one page
        // in or out no longer shifts — and therefore no longer re-copies — every other page.
        readonly Dictionary<int, int> m_AtlasPageIndex = new Dictionary<int, int>();
        int[] m_AtlasPageOffset;
        int[] m_AtlasPageReserve;
        int m_AtlasDetailStart;
        int m_AtlasDetailStride;
        int m_AtlasDetailSlots;
        int m_AtlasRequestedDetailSlots = -1;
        int m_AtlasLayoutBudgetMB = -1;
        int m_AtlasLayoutTotal;
        bool m_AtlasLayoutIsPerPage;
        bool m_AtlasWantedPerPage;

        int EstimateMaxAtlasSplats()
        {
            EnsureAtlasLayout();
            return Mathf.Max(m_AtlasLayoutTotal, 1);
        }

        void EnsureAtlasLayout()
        {
            if (m_PagedScene?.pages == null || m_PagedScene.pages.Length == 0)
            {
                m_AtlasPageOffset = null;
                m_AtlasPageReserve = null;
                m_AtlasLayoutTotal = 0;
                return;
            }

            // Keyed on what was asked for rather than what the budget allowed: the layout can
            // legitimately return less than was requested, and comparing against the result would
            // rebuild every frame — or latch a reduced layout in place after the budget is raised.
            bool wantsPerPage = m_LodStreamer != null && m_LodStreamer.wantsFullSceneResidency;
            int requestedSlots = m_LodStreamer != null
                ? m_LodStreamer.requestedDetailSlots
                : Mathf.Clamp(m_PagedScene.maxLoadedPages, 1, m_PagedScene.pages.Length);

            if (m_AtlasPageOffset != null &&
                m_AtlasPageOffset.Length == m_PagedScene.pages.Length &&
                m_AtlasWantedPerPage == wantsPerPage &&
                m_AtlasRequestedDetailSlots == requestedSlots &&
                m_AtlasLayoutBudgetMB == m_LodAtlasBudgetMB)
                return;

            m_AtlasWantedPerPage = wantsPerPage;
            m_AtlasRequestedDetailSlots = requestedSlots;
            m_AtlasLayoutBudgetMB = m_LodAtlasBudgetMB;
            BuildAtlasLayout(wantsPerPage, requestedSlots);

            // The layout may have had to shrink the detail pool, or drop full-scene residency
            // entirely, to fit in memory. The streamer has to agree, or it will load pages the atlas
            // has nowhere to put.
            m_LodStreamer?.SetAtlasLimits(
                m_AtlasLayoutIsPerPage ? int.MaxValue : m_AtlasDetailSlots,
                m_AtlasLayoutIsPerPage);
        }

        /// <summary>
        /// Splats the atlas may hold. Every resident splat costs position, rotation/scale, SH and
        /// colour, and SH alone can be 192 bytes, so an unbounded layout runs straight past the
        /// graphics buffer size limit.
        /// </summary>
        int MaxAtlasSplatCapacity()
        {
            long colorBytes = m_LodFormatAsset != null
                ? GaussianSplatAsset.GetColorSize(m_LodFormatAsset.colorFormat)
                : 4;
            long bytesPerSplat = Math.Max(1,
                (long)(m_LodPosWordsPerSplat + m_LodOtherWordsPerSplat + m_LodShWordsPerSplat) * 4 + colorBytes);

            long budgetBytes = (long)Mathf.Max(64, m_LodAtlasBudgetMB) * 1024 * 1024;
            long capacity = budgetBytes / bytesPerSplat;

            // No single buffer may exceed the driver limit either, and the colour texture is bounded
            // by the maximum texture height.
            long maxBufferBytes = SystemInfo.maxGraphicsBufferSize > 0
                ? SystemInfo.maxGraphicsBufferSize
                : 2L * 1024 * 1024 * 1024;
            capacity = Math.Min(capacity, maxBufferBytes / Math.Max(4, m_LodShWordsPerSplat * 4));
            capacity = Math.Min(capacity, (long)SystemInfo.maxTextureSize * GaussianSplatAsset.kTextureWidth);
            capacity = Math.Min(capacity, GaussianSplatAsset.kMaxSplats);

            return (int)Math.Max(kAtlasSplatAlignment, capacity);
        }

        void BuildAtlasLayout(bool perPage, int requestedDetailSlots)
        {
            var pages = m_PagedScene.pages;
            int capacity = MaxAtlasSplatCapacity();

            m_AtlasPageOffset = new int[pages.Length];
            m_AtlasPageReserve = new int[pages.Length];
            m_AtlasPageIndex.Clear();

            int largestPage = 1;
            for (int i = 0; i < pages.Length; i++)
            {
                m_AtlasPageIndex[pages[i].pageId] = i;
                largestPage = Mathf.Max(largestPage, Mathf.Max(1, pages[i].splatCount));
            }

            // Full-scene residency is all or nothing: truncating pages here would leave the streamer
            // loading data the layout has no room for, so if it does not fit we stream instead.
            int permanentTotal = 0;
            if (perPage)
            {
                permanentTotal = LayOutPermanentRegions(pages, int.MaxValue, capacity, out long needed);
                if (needed > capacity)
                    perPage = false;
            }

            if (!perPage)
            {
                // Permanent regions hold the coarse tiers, which are what keep the whole model
                // visible, so they only shrink when they would crowd out full detail entirely.
                int coarseCap = Mathf.Max(1, m_PagedScene.coarsePageSplats);
                permanentTotal = LayOutPermanentRegions(pages, coarseCap, capacity, out long needed);
                while (needed > capacity / 2 && coarseCap > GaussianSplatAsset.kChunkSize)
                {
                    coarseCap = Mathf.Max(GaussianSplatAsset.kChunkSize, coarseCap / 2);
                    permanentTotal = LayOutPermanentRegions(pages, coarseCap, capacity, out needed);
                }

                if (needed > capacity)
                {
                    Debug.LogWarning(
                        $"SplatBoxRenderer: the LoD atlas budget ({m_LodAtlasBudgetMB} MB) cannot hold a " +
                        "coarse tier for every page, so part of the model will not be drawn. Raise LoD " +
                        "Atlas Budget or rebuild the scene with fewer, larger pages.");
                }
            }

            m_AtlasLayoutIsPerPage = perPage;
            m_AtlasDetailStart = permanentTotal;
            m_AtlasDetailStride = perPage ? 0 : AlignAtlasSplatOffset(largestPage);

            int detailSlots = 0;
            if (!perPage && m_AtlasDetailStride > 0)
            {
                int roomForSlots = Mathf.Max(0, capacity - permanentTotal) / m_AtlasDetailStride;
                detailSlots = Mathf.Clamp(roomForSlots, 0, Mathf.Max(0, requestedDetailSlots));
                // Off-by-one on a large max-page setting is normal (budget math vs alignment). Only
                // warn when the cut meaningfully changes streaming behaviour.
                if (detailSlots == 0 ||
                    (requestedDetailSlots >= 4 && detailSlots * 2 < requestedDetailSlots))
                {
                    Debug.LogWarning(
                        $"SplatBoxRenderer: the LoD atlas budget ({m_LodAtlasBudgetMB} MB) only fits " +
                        $"{detailSlots} of the requested {requestedDetailSlots} full-detail pages. " +
                        "Raise LoD Atlas Budget, lower Max Loaded Pages, or rebuild the scene with " +
                        "smaller pages.");
                }
            }

            m_AtlasDetailSlots = detailSlots;
            m_AtlasLayoutTotal = Mathf.Max(kAtlasSplatAlignment, permanentTotal + m_AtlasDetailStride * detailSlots);
        }

        /// <summary>
        /// Assigns each page its permanent region and returns the total splats they take. Pages that
        /// would run past <paramref name="capacity"/> get a zero-size reserve, which leaves them
        /// unplaced rather than writing outside the atlas.
        /// </summary>
        int LayOutPermanentRegions(GaussianSplatPageEntry[] pages, int coarseCap, int capacity,
            out long requiredTotal)
        {
            int alignedCap = coarseCap == int.MaxValue ? int.MaxValue : AlignAtlasSplatOffset(coarseCap);
            int offset = 0;
            requiredTotal = 0;
            for (int i = 0; i < pages.Length; i++)
            {
                int splats = Mathf.Max(1, pages[i].splatCount);
                // Small pages fit their whole payload here and never need a detail slot.
                int reserve = AlignAtlasSplatOffset(Mathf.Min(splats, alignedCap));
                requiredTotal += reserve;

                if (offset + reserve > capacity)
                {
                    m_AtlasPageOffset[i] = 0;
                    m_AtlasPageReserve[i] = 0;
                    continue;
                }
                m_AtlasPageOffset[i] = offset;
                m_AtlasPageReserve[i] = reserve;
                offset += reserve;
            }
            return offset;
        }

        /// <summary>Fixed address of a page in the atlas, or -1 if it has nowhere to live.</summary>
        int ResolveAtlasOffset(SplatBoxPageGpuState page)
        {
            if (m_AtlasPageOffset == null || !m_AtlasPageIndex.TryGetValue(page.pageId, out int index))
                return -1;
            if (page.splatCount <= m_AtlasPageReserve[index])
                return m_AtlasPageOffset[index];
            if (page.detailSlot < 0 || page.detailSlot >= m_AtlasDetailSlots)
                return -1;
            return m_AtlasDetailStart + page.detailSlot * m_AtlasDetailStride;
        }

        void EnsureLodAtlasCapacity(int requiredSplats)
        {
            if (!EnsureLodFormatAsset())
                return;
            if (m_GpuLodUnifiedColor != null && requiredSplats <= m_LodAtlasCapacity)
                return;
            AllocateLodAtlasBuffers(Mathf.Max(requiredSplats, EstimateMaxAtlasSplats()));
        }

        /// <summary>
        /// Format metadata comes from the first valid page asset. Editor streaming can preload
        /// before InitPagedLodResources finishes (or after a rebuild clears the field), so resolve
        /// it lazily instead of NRE-ing in AllocateLodAtlasBuffers.
        /// </summary>
        bool EnsureLodFormatAsset()
        {
            if (m_LodFormatAsset != null && m_LodFormatAsset.splatCount > 0 &&
                m_LodFormatAsset.posData != null && m_LodFormatAsset.otherData != null &&
                m_LodFormatAsset.shData != null)
                return true;

            if (!UsesPagedLod || m_PagedScene?.pages == null)
                return false;

            for (int i = 0; i < m_PagedScene.pages.Length; i++)
            {
                var pageAsset = m_PagedScene.pages[i].pageAsset;
                var splatData = pageAsset != null ? pageAsset.splatData : null;
                if (splatData == null || splatData.splatCount <= 0 ||
                    splatData.posData == null || splatData.otherData == null || splatData.shData == null)
                    continue;

                m_LodFormatAsset = splatData;
                m_LodPosWordsPerSplat = Mathf.Max(1, (int)(splatData.posData.dataSize / splatData.splatCount / 4));
                m_LodOtherWordsPerSplat = Mathf.Max(1, (int)(splatData.otherData.dataSize / splatData.splatCount / 4));
                m_LodShWordsPerSplat = Mathf.Max(1, (int)(splatData.shData.dataSize / splatData.splatCount / 4));
                return true;
            }

            return false;
        }

        void AllocateLodAtlasBuffers(int atlasSplatCapacity)
        {
            if (!EnsureLodFormatAsset())
            {
                Debug.LogError("SplatBoxRenderer: cannot allocate LoD atlas — no page splat asset with valid format data.");
                return;
            }

            // Last line of defence: an oversized capacity would throw out of the GraphicsBuffer
            // constructor and leave the renderer with no atlas at all.
            atlasSplatCapacity = Mathf.Clamp(atlasSplatCapacity, kAtlasSplatAlignment, MaxAtlasSplatCapacity());

            DisposeLodAtlasBuffers();
            m_LodAtlasCapacity = atlasSplatCapacity;
            m_UnifiedAtlasSplatCount = 0;
            InvalidateUploadedAtlasOffsets();
            int posCount = atlasSplatCapacity * m_LodPosWordsPerSplat;
            int otherCount = atlasSplatCapacity * m_LodOtherWordsPerSplat;
            int shCount = atlasSplatCapacity * m_LodShWordsPerSplat;
            m_GpuLodUnifiedPos = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, posCount), 4) { name = "LodUnifiedPos" };
            m_GpuLodUnifiedOther = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, otherCount), 4) { name = "LodUnifiedOther" };
            m_GpuLodUnifiedSh = new GraphicsBuffer(GraphicsBuffer.Target.Raw,
                Mathf.Max(1, shCount), 4) { name = "LodUnifiedSh" };
            m_GpuLodAtlasIndices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, EffectiveLodBudget, 4)
                { name = "LodGatherIndices" };
            var (texW, texH) = GaussianSplatAsset.CalcTextureSize(atlasSplatCapacity);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(m_LodFormatAsset.colorFormat);
            m_GpuLodUnifiedColor = new Texture2D(texW, texH, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
            { name = "LodUnifiedColor" };

            m_GpuLodUnifiedChunks?.Dispose();
            m_LodUnifiedChunkCount = (atlasSplatCapacity + GaussianSplatAsset.kChunkSize - 1) / GaussianSplatAsset.kChunkSize;
            if (m_LodFormatAsset.chunkData != null && m_LodFormatAsset.chunkData.dataSize != 0)
            {
                m_GpuLodUnifiedChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_LodUnifiedChunkCount,
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) { name = "LodUnifiedChunks" };
            }
            else
            {
                m_GpuLodUnifiedChunks = null;
                m_LodUnifiedChunkCount = 0;
            }
        }

        void AllocateActiveRenderBuffers(int budget)
        {
            if (!EnsureLodFormatAsset())
                return;

            m_GpuPosData?.Dispose();
            m_GpuOtherData?.Dispose();
            m_GpuSHData?.Dispose();
            if (m_GpuColorData != null)
            {
                if (Application.isPlaying) Destroy(m_GpuColorData);
                else DestroyImmediate(m_GpuColorData);
            }

            // Paged rendering reads selected splats directly from the unified atlas through
            // m_GpuLodAtlasIndices. These legacy active-data buffers are only non-null fallbacks
            // required by shared renderer bindings; allocating a second full copy of every selected
            // splat wastes well over 100 MB at a 500k Very High budget.
            int posCount = m_LodPosWordsPerSplat;
            int otherCount = m_LodOtherWordsPerSplat;
            int shCount = m_LodShWordsPerSplat;
            m_GpuPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, posCount), 4) { name = "LodActivePos" };
            m_GpuOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource,
                Mathf.Max(1, otherCount), 4) { name = "LodActiveOther" };
            m_GpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, Mathf.Max(1, shCount), 4)
                { name = "LodActiveSH" };
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(m_LodFormatAsset.colorFormat);
            m_GpuColorData = new Texture2D(4, 4, texFormat,
                TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate)
                { name = "LodActiveColorFallback" };

            if (m_GpuView == null || m_GpuView.count != budget)
            {
                m_GpuView?.Dispose();
                m_GpuView = new GraphicsBuffer(GraphicsBuffer.Target.Structured, budget, kGpuViewDataSize);
            }
            if (m_GpuIndexBuffer == null)
            {
                m_GpuIndexBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Index, 36, 2);
                m_GpuIndexBuffer.SetData(new ushort[]
                {
                    0, 1, 2, 1, 3, 2, 4, 6, 5, 5, 6, 7, 0, 2, 4, 4, 2, 6,
                    1, 5, 3, 5, 7, 3, 0, 4, 1, 4, 5, 1, 2, 3, 6, 3, 7, 6
                });
            }
            InitSortBuffers(budget);
        }

        /// <summary>
        /// The LoD budget is editable at runtime, but it also sizes the view, sort, remap and CPU
        /// selection buffers. Keep those capacities synchronized so raising the budget genuinely
        /// allows a close view to refine beyond the old limit instead of silently clamping to it.
        /// The unified page atlas is independent and is deliberately retained.
        /// </summary>
        void EnsureLodBudgetCapacity()
        {
            int budget = EffectiveLodBudget;
            bool valid =
                m_LodAllocatedBudget == budget &&
                m_LodActiveScratch != null && m_LodActiveScratch.Length == budget &&
                m_LodAtlasIndexScratch != null && m_LodAtlasIndexScratch.Length == budget &&
                m_GpuLodAtlasIndices != null && m_GpuLodAtlasIndices.count == budget &&
                m_GpuView != null && m_GpuView.count == budget &&
                m_GpuSortKeys != null && m_GpuSortKeys.count == budget;
            if (valid)
                return;

            SplatBoxLodDiagnostics.RecordBudgetRealloc();
            AllocateActiveRenderBuffers(budget);

            m_GpuLodAtlasIndices?.Dispose();
            m_GpuLodAtlasIndices = new GraphicsBuffer(GraphicsBuffer.Target.Structured, budget, 4)
                { name = "LodGatherIndices" };
            m_LodActiveScratch = new LodActiveSplatRef[budget];
            m_LodAtlasIndexScratch = new uint[budget];
            m_LodAllocatedBudget = budget;
            m_SplatCount = budget;
            m_ActiveSplatCount = 0;
            m_LodSelectionDirty = true;
            m_LodSortKeysNeedReset = false;
            m_HasLastLodView = false;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            m_HasEditorLodSortObservation = false;
#endif
        }

        /// <summary>Fresh atlas buffers hold no page data, so every page has to be copied again.</summary>
        void InvalidateUploadedAtlasOffsets() => m_LodStreamer?.InvalidateAtlasResidency();

        void DisposeLodAtlasBuffers()
        {
            m_GpuLodUnifiedPos?.Dispose();
            m_GpuLodUnifiedOther?.Dispose();
            m_GpuLodUnifiedSh?.Dispose();
            m_GpuLodAtlasIndices?.Dispose();
            m_GpuLodUnifiedPos = null;
            m_GpuLodUnifiedOther = null;
            m_GpuLodUnifiedSh = null;
            m_GpuLodAtlasIndices = null;
            if (m_GpuLodUnifiedColor != null)
            {
                if (Application.isPlaying) Destroy(m_GpuLodUnifiedColor);
                else DestroyImmediate(m_GpuLodUnifiedColor);
                m_GpuLodUnifiedColor = null;
            }
            m_LodAtlasCapacity = 0;
            m_UnifiedAtlasSplatCount = 0;
            m_LodUnifiedChunkCount = 0;
            m_GpuLodUnifiedChunks?.Dispose();
            m_GpuLodUnifiedChunks = null;
        }

        void DisposePagedLodResources()
        {
            if (m_LodStreamer != null)
            {
                m_LodStreamer.OnPagesChanged -= OnLodPagesChanged;
                m_LodStreamer.UnloadAll();
            }
            DisposeLodAtlasBuffers();
            m_LodPageContextScratch = null;
            m_LodActiveScratch = null;
            m_LodAtlasIndexScratch = null;
            m_LodAllocatedBudget = 0;
        }

        SplatBoxLodTraverser.PageContext[] m_LodPageContextScratch;
        SplatBoxLodTraverser.Workspace m_LodWorkspace;
        Vector3 m_LastLodViewPos;
        Quaternion m_LastLodViewRot = Quaternion.identity;
        bool m_HasLastLodView;
        uint m_LodSelectionRevision;
        bool m_LodSortKeysNeedReset;

        public void UpdatePagedLod(Camera cam, CommandBuffer cmd)
        {
            if (!UsesPagedLod || m_LodStreamer == null || m_CSBoxUtil == null || cam == null)
                return;
            if (hasMismatchedLodSplatOrder)
            {
                m_ActiveSplatCount = 0;
                return;
            }

            // This runs once per camera that renders the splats, but streaming and the selection
            // are single global states. Only the driving camera's view may shape them: when every
            // camera re-selected for its own frustum, the Scene view, Game view and previews took
            // turns culling the selection for themselves, and each view flickered between "built
            // for me" and "built for another view" — more violently the larger the budget, since
            // a bigger budget concentrates more of the scene inside one frustum.
            Camera driver = ResolvePagedLodCamera();
            if (driver != null)
                cam = driver;

            EnsureLodBudgetCapacity();
            EnsureLodStreamer();
            m_LodStreamer.UpdateStreaming(cam, transform);

            // A selection can also be rebuilt by an editor command that has no render command
            // buffer. Restore a valid identity permutation before this camera draws it.
            if (m_LodSortKeysNeedReset && cmd != null)
                ResetLodSortKeys(cmd);

            bool rebuildAtlas = m_LodAtlasDirty;
            if (rebuildAtlas)
            {
                m_LodTimer.Restart();
                RebuildLodUnifiedAtlas(cmd);
                m_LastLodAtlasMs = (float)m_LodTimer.Elapsed.TotalMilliseconds;
            }

            bool wasDirty = m_LodSelectionDirty;
            bool viewChanged = HasLodViewChanged(cam);
            bool ranSelection = false;
            if (ShouldRefreshLodSelection(cam))
            {
                SelectAndGatherLodSplats(cam, cmd);
                ranSelection = true;
            }
            else if (m_ActiveSplatCount <= 0 && m_LodStreamer.loadedPages.Count > 0)
            {
                SelectAndGatherLodSplats(cam, cmd);
                ranSelection = true;
            }

            if (ranSelection)
            {
                SplatBoxLodDiagnostics.RecordSelection(m_ActiveSplatCount, wasDirty, viewChanged,
                    ramping: false, m_LodWorkspace?.budgetExhausted ?? false,
                    m_LodWorkspace?.droppedMerged ?? 0);
            }
            SplatBoxLodDiagnostics.Heartbeat(m_ActiveSplatCount);
        }

        readonly System.Diagnostics.Stopwatch m_LodTimer = new System.Diagnostics.Stopwatch();
        float m_LastLodSelectMs;
        float m_LastLodAtlasMs;

        /// <summary>
        /// Main-thread milliseconds the last LoD selection took: tree traversal, atlas index gather and
        /// the index upload. Runs on whatever thread drives rendering, so it is felt directly as frame
        /// time whenever the view moves.
        /// </summary>
        public float lastLodSelectMs => m_LastLodSelectMs;

        /// <summary>Main-thread milliseconds the last atlas rebuild took.</summary>
        public float lastLodAtlasMs => m_LastLodAtlasMs;

        /// <summary>
        /// Re-selecting walks the whole LoD budget. Both editor and play use a steady cadence so
        /// orbit/look-around updates frustum selection without freezing until the camera stops
        /// (that lag left missing splats in the new view direction).
        /// </summary>
        bool ShouldRefreshLodSelection(Camera cam)
        {
            float now = Time.realtimeSinceStartup;
            bool dueByInterval = now - m_LastPlayLodSelectTime >= EffectiveLodSelectInterval;

            if (m_LodSelectionDirty)
                return dueByInterval || m_ActiveSplatCount <= 0;

            if (ShouldApplyPendingSettledReselect())
                return dueByInterval;

            if (!HasLodViewChanged(cam))
                return false;

            return dueByInterval;
        }

        Vector3 m_LodMotionPos;
        Quaternion m_LodMotionRot = Quaternion.identity;
        float m_LodLastMotionTime = -999f;
        bool m_HasLodMotionSample;
        bool m_LodPendingSettledReselect;
        float m_LodLastPageEventTime = -999f;
        float m_LastPlayLodSelectTime = -999f;
        // ~12 Hz. Fast enough that orbiting does not show empty frustum sides; slow enough that
        // traverse+upload+sort cannot run every Scene View repaint.
        const float kLodSelectInterval = 0.08f;

        float EffectiveLodSelectInterval => kLodSelectInterval;

        /// <summary>
        /// True while the driving camera has moved or rotated recently (diagnostics / page defer).
        /// </summary>
        bool IsLodCameraMoving(Camera cam)
        {
            if (cam == null)
                return false;

            var xf = cam.transform;
            float now = Time.realtimeSinceStartup;
            if (!m_HasLodMotionSample)
            {
                m_LodMotionPos = xf.position;
                m_LodMotionRot = xf.rotation;
                m_LodLastMotionTime = now;
                m_HasLodMotionSample = true;
                return false;
            }

            const float kMoveThreshold = 0.01f;
            const float kRotateThresholdDeg = 0.25f;
            bool moved =
                (xf.position - m_LodMotionPos).sqrMagnitude > kMoveThreshold * kMoveThreshold ||
                Quaternion.Angle(xf.rotation, m_LodMotionRot) > kRotateThresholdDeg;
            m_LodMotionPos = xf.position;
            m_LodMotionRot = xf.rotation;
            if (moved)
                m_LodLastMotionTime = now;

            return now - m_LodLastMotionTime < kLodSelectInterval;
        }

#if UNITY_EDITOR
        bool IsEditorLodCameraMoving(Camera cam) => IsLodCameraMoving(cam);
#endif

        /// <summary>
        /// True when streaming finished a burst of page swaps and enough quiet time passed to fold
        /// them into one rate-limited reselection.
        /// </summary>
        bool ShouldApplyPendingSettledReselect()
        {
            if (!m_LodPendingSettledReselect || m_ActiveSplatCount <= 0)
                return false;
            // Longer than the select interval so a burst of coarse uploads (one per frame) collapses
            // into a single refresh after streaming quiets, instead of reselecting on every arrival.
            return Time.realtimeSinceStartup - m_LodLastPageEventTime >= 0.25f;
        }

        float m_LastLodSelectTime;

        /// <summary>Changes whenever the active atlas-index list changes.</summary>
        internal uint lodSelectionRevision => m_LodSelectionRevision;

        bool HasLodViewChanged(Camera cam)
        {
            if (cam == null)
                return false;
            if (!m_HasLastLodView)
                return true;

            const float kMoveThreshold = 0.02f;
            const float kRotateThresholdDeg = 0.5f;
            var xf = cam.transform;
            return (xf.position - m_LastLodViewPos).sqrMagnitude > kMoveThreshold * kMoveThreshold ||
                   Quaternion.Angle(xf.rotation, m_LastLodViewRot) > kRotateThresholdDeg;
        }

        void RecordLodViewpoint(Camera cam)
        {
            if (cam == null)
                return;
            var xf = cam.transform;
            m_LastLodViewPos = xf.position;
            m_LastLodViewRot = xf.rotation;
            m_HasLastLodView = true;
        }

        void RebuildLodUnifiedAtlas(CommandBuffer cmd)
        {
            SplatBoxLodDiagnostics.RecordAtlasRebuild();
            m_LodAtlasDirty = false;
            EnsureAtlasLayout();
            var pages = m_LodStreamer.loadedPages;
            if (m_AtlasLayoutTotal <= 0 || pages.Count == 0)
            {
                m_UnifiedAtlasSplatCount = 0;
                SyncPagedLodChunkBindings(false);
                return;
            }

            EnsureLodAtlasCapacity(m_AtlasLayoutTotal);

            int copyKernel = GetKernelIndex(KernelIndices.CopyBufferRange);
            bool copiedChunks = false;
            int resident = 0;
            for (int p = 0; p < pages.Count; p++)
            {
                var page = pages[p];
                if (page == null || !page.IsReady)
                    continue;

                int atlasOffset = ResolveAtlasOffset(page);
                page.atlasOffset = atlasOffset;
                if (atlasOffset < 0)
                    continue;

                // A page's address is fixed, so anything already sitting in the right place is left
                // alone and only genuinely new data is copied.
                if (page.uploadedAtlasOffset != atlasOffset)
                {
                    CopyPageToAtlasGpu(cmd, copyKernel, page, atlasOffset);
                    page.uploadedAtlasOffset = atlasOffset;
                }
                copiedChunks = copiedChunks || (page.gpuChunksValid && page.chunkInfos != null);
                resident++;
            }

            m_UnifiedAtlasSplatCount = resident > 0 ? m_AtlasLayoutTotal : 0;
            SyncPagedLodChunkBindings(copiedChunks);
            // Fixed atlas addresses mean an existing selection stays valid when a far coarse page
            // is merely copied in. Selection is dirtied by OnLodPagesChanged when full-detail
            // residency changes, or by the settled-reselect path after a quiet burst.
            m_LodLastPageEventTime = Time.realtimeSinceStartup;
            if (m_ActiveSplatCount <= 0)
            {
                m_LodSelectionDirty = true;
                m_LodPendingSettledReselect = true;
            }
            else if (!m_LodSelectionDirty)
            {
                m_LodPendingSettledReselect = true;
            }
        }

        bool CopyPageToAtlasGpu(CommandBuffer cmd, int copyKernel, SplatBoxPageGpuState page, int atlasOffset)
        {
            if (page.splatCount <= 0)
                return false;

            bool copiedGpu = false;
            if (copyKernel >= 0)
            {
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodCopyCount, page.splatCount);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodCopyDstOffset, atlasOffset);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodPosWordsPerSplat, m_LodPosWordsPerSplat);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodOtherWordsPerSplat, m_LodOtherWordsPerSplat);
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.LodShWordsPerSplat, m_LodShWordsPerSplat);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopySrcPos, page.gpuPosData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopySrcOther, page.gpuOtherData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopySrcSh, page.gpuSHData);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopyDstPos, m_GpuLodUnifiedPos);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopyDstOther, m_GpuLodUnifiedOther);
                cmd.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.LodCopyDstSh, m_GpuLodUnifiedSh);

                uint gsX = 64;
                m_CSBoxUtil.GetKernelThreadGroupSizes(copyKernel, out gsX, out _, out _);
                if (gsX > 0)
                {
                    int groups = (page.splatCount + (int)gsX - 1) / (int)gsX;
                    if (groups > 0)
                    {
                        cmd.DispatchCompute(m_CSBoxUtil, copyKernel, groups, 1, 1);
                        copiedGpu = true;
                    }
                }
            }

            if (!copiedGpu)
                CopyPageToAtlasCpu(page, atlasOffset);

            if (page.gpuColorData is Texture2D pageTex && m_GpuLodUnifiedColor != null)
                CopySplatColorRange(pageTex, m_GpuLodUnifiedColor, 0, atlasOffset, page.splatCount);

            if (page.gpuChunksValid && m_GpuLodUnifiedChunks != null && page.chunkInfos != null)
            {
                int dstChunk = atlasOffset / GaussianSplatAsset.kChunkSize;
                int chunkCount = page.chunkInfos.Length;
                if (dstChunk + chunkCount <= m_LodUnifiedChunkCount)
                    m_GpuLodUnifiedChunks.SetData(page.chunkInfos, 0, dstChunk, chunkCount);
            }

            return true;
        }

        void CopyPageToAtlasCpu(SplatBoxPageGpuState page, int atlasOffset)
        {
            var asset = page.source != null ? page.source.splatData : null;
            if (asset == null || page.splatCount <= 0)
                return;

            int posWords = page.splatCount * m_LodPosWordsPerSplat;
            int otherWords = page.splatCount * m_LodOtherWordsPerSplat;
            int shWords = page.splatCount * m_LodShWordsPerSplat;
            int dstPosBase = atlasOffset * m_LodPosWordsPerSplat;
            int dstOtherBase = atlasOffset * m_LodOtherWordsPerSplat;
            int dstShBase = atlasOffset * m_LodShWordsPerSplat;

            m_GpuLodUnifiedPos.SetData(asset.posData.GetData<uint>(), 0, dstPosBase, posWords);
            m_GpuLodUnifiedOther.SetData(asset.otherData.GetData<uint>(), 0, dstOtherBase, otherWords);
            m_GpuLodUnifiedSh.SetData(asset.shData.GetData<uint>(), 0, dstShBase, shWords);
        }

        /// <summary>
        /// Copies a range of splat colours between textures that use the shader's 16x16 Morton-tile
        /// layout. A splat offset is not a row-major pixel offset: for example splat 2048 starts at
        /// pixel (128,0), not (0,1). Treating it as row-major was placing every page's colours at the
        /// wrong atlas coordinates.
        /// </summary>
        static void CopySplatColorRange(
            Texture2D src, Texture2D dst, int srcSplatStart, int dstSplatStart, int splatCount)
        {
            if (src == null || dst == null || splatCount <= 0)
                return;

            const int tileSize = 16;
            const int splatsPerTile = tileSize * tileSize;

            // Atlas regions are chunk aligned. Copy whole Morton tiles, batching adjacent tiles into
            // a single CopyTexture region. The final tile may contain padding, which is safe because
            // every atlas region is padded to kAtlasSplatAlignment.
            if (srcSplatStart % splatsPerTile == 0 && dstSplatStart % splatsPerTile == 0)
            {
                int srcTilesPerRow = src.width / tileSize;
                int dstTilesPerRow = dst.width / tileSize;
                int srcTile = srcSplatStart / splatsPerTile;
                int dstTile = dstSplatStart / splatsPerTile;
                int tilesLeft = (splatCount + splatsPerTile - 1) / splatsPerTile;

                while (tilesLeft > 0)
                {
                    int srcTileX = srcTile % srcTilesPerRow;
                    int srcTileY = srcTile / srcTilesPerRow;
                    int dstTileX = dstTile % dstTilesPerRow;
                    int dstTileY = dstTile / dstTilesPerRow;
                    int run = Mathf.Min(
                        tilesLeft,
                        srcTilesPerRow - srcTileX,
                        dstTilesPerRow - dstTileX);
                    if (run <= 0 ||
                        (srcTileY + 1) * tileSize > src.height ||
                        (dstTileY + 1) * tileSize > dst.height)
                        break;

                    Graphics.CopyTexture(
                        src, 0, 0, srcTileX * tileSize, srcTileY * tileSize, run * tileSize, tileSize,
                        dst, 0, 0, dstTileX * tileSize, dstTileY * tileSize);
                    srcTile += run;
                    dstTile += run;
                    tilesLeft -= run;
                }
                return;
            }

            // Defensive slow path for a future caller that supplies an unaligned range.
            for (int i = 0; i < splatCount; i++)
            {
                Vector2Int srcPixel = SplatIndexToColorPixel(srcSplatStart + i, src.width);
                Vector2Int dstPixel = SplatIndexToColorPixel(dstSplatStart + i, dst.width);
                if (srcPixel.y >= src.height || dstPixel.y >= dst.height)
                    break;
                Graphics.CopyTexture(
                    src, 0, 0, srcPixel.x, srcPixel.y, 1, 1,
                    dst, 0, 0, dstPixel.x, dstPixel.y);
            }
        }

        static Vector2Int SplatIndexToColorPixel(int index, int textureWidth)
        {
            uint t = (uint)(index & 0xFF);
            t = (t & 0xFF) | ((t & 0xFE) << 7);
            t &= 0x5555;
            t = (t ^ (t >> 1)) & 0x3333;
            t = (t ^ (t >> 2)) & 0x0F0F;

            int tile = index >> 8;
            int tilesPerRow = textureWidth / 16;
            return new Vector2Int(
                (tile % tilesPerRow) * 16 + (int)(t & 0xF),
                (tile / tilesPerRow) * 16 + (int)(t >> 8));
        }

        void SelectAndGatherLodSplats(Camera cam, CommandBuffer cmd)
        {
            m_LodTimer.Restart();
            SelectAndGatherLodSplatsCore(cam, cmd);
            m_LastLodSelectMs = (float)m_LodTimer.Elapsed.TotalMilliseconds;
        }

        void SelectAndGatherLodSplatsCore(Camera cam, CommandBuffer cmd)
        {
            var pages = m_LodStreamer.loadedPages;
            if (pages.Count == 0)
            {
                m_ActiveSplatCount = 0;
                return;
            }

            m_LastLodSelectTime = Time.realtimeSinceStartup;

            // Every selection runs at the full budget. Editor navigation used to select at
            // budget/16 and settle to full afterwards, but once the budget grew past a few hundred
            // thousand splats that swing read as the whole scene flickering between low and high
            // detail whenever anything re-triggered selection. Editor cost is bounded by the rate
            // limit in ShouldRefreshLodSelection instead.
            int budget = EffectiveLodBudget;

            int selected = SelectLoadedSplatsWithLod(cam, pages, budget, m_LodActiveScratch);
            if (m_LodAtlasIndexScratch != null && selected > m_LodAtlasIndexScratch.Length)
                selected = m_LodAtlasIndexScratch.Length;
            RecordLodViewpoint(cam);

            // Resolving each selected splat's page by scanning the page list would be hundreds of
            // thousands of scans per selection, so the offsets are gathered into a slot table first.
            int[] slotAtlasBase = BuildSlotAtlasBaseTable(pages);
            for (int i = 0; i < selected; i++)
            {
                uint slot = m_LodActiveScratch[i].pageSlot;
                int atlasBase = slot < (uint)slotAtlasBase.Length ? slotAtlasBase[slot] : 0;
                m_LodAtlasIndexScratch[i] = (uint)(atlasBase + m_LodActiveScratch[i].splatIndex);
            }

            m_ActiveSplatCount = selected;
            m_LodPendingSettledReselect = false;
            m_LastPlayLodSelectTime = Time.realtimeSinceStartup;
            if (selected <= 0)
            {
                MarkLodSelectionChanged();
                m_LodSelectionDirty = false;
                return;
            }

            m_GpuLodAtlasIndices.SetData(m_LodAtlasIndexScratch, 0, 0, selected);
            MarkLodSelectionChanged();
            if (cmd != null)
                ResetLodSortKeys(cmd);
            m_LodSelectionDirty = false;
        }

        void MarkLodSelectionChanged()
        {
            unchecked { m_LodSelectionRevision++; }
            m_LodSortKeysNeedReset = true;
        }

        /// <summary>
        /// Selection indices address a new logical array after every LoD pass, so the old draw
        /// permutation is meaningless. Reset it to identity; the depth sort that runs later in the
        /// same command buffer (same frame for a selection change) restores correct ordering.
        /// </summary>
        void ResetLodSortKeys(CommandBuffer cmd)
        {
            if (cmd == null || m_GpuSortKeys == null || m_ActiveSplatCount <= 0)
                return;

            SplatBoxLodDiagnostics.RecordKeyReset();
            int kernel = GetKernelIndex(KernelIndices.SetIndices);
            if (kernel < 0)
                return;

            m_CSBoxUtil.GetKernelThreadGroupSizes(kernel, out uint groupSize, out _, out _);
            if (groupSize == 0)
                return;

            cmd.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatSortKeys, m_GpuSortKeys);
            cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_ActiveSplatCount);
            cmd.DispatchCompute(m_CSBoxUtil, kernel,
                (m_ActiveSplatCount + (int)groupSize - 1) / (int)groupSize, 1, 1);
            m_LodSortKeysNeedReset = false;
        }

        int[] m_LodSlotAtlasBase;

        int[] BuildSlotAtlasBaseTable(IReadOnlyList<SplatBoxPageGpuState> pages)
        {
            int maxSlot = 0;
            for (int i = 0; i < pages.Count; i++)
            {
                if (pages[i] != null)
                    maxSlot = Mathf.Max(maxSlot, pages[i].pageSlot);
            }

            if (m_LodSlotAtlasBase == null || m_LodSlotAtlasBase.Length <= maxSlot)
                m_LodSlotAtlasBase = new int[maxSlot + 1];
            else
                Array.Clear(m_LodSlotAtlasBase, 0, m_LodSlotAtlasBase.Length);

            for (int i = 0; i < pages.Count; i++)
            {
                var p = pages[i];
                if (p != null && p.atlasOffset >= 0 && p.pageSlot >= 0 && p.pageSlot < m_LodSlotAtlasBase.Length)
                    m_LodSlotAtlasBase[p.pageSlot] = p.atlasOffset;
            }
            return m_LodSlotAtlasBase;
        }

        int SelectLoadedSplatsWithLod(Camera cam, IReadOnlyList<SplatBoxPageGpuState> pages, int maxSplats,
            LodActiveSplatRef[] output)
        {
            if (output == null || output.Length == 0 || maxSplats <= 0)
                return 0;

            maxSplats = Mathf.Min(maxSplats, output.Length);
            int pageCount = pages.Count;
            if (m_LodPageContextScratch == null || m_LodPageContextScratch.Length < pageCount)
                m_LodPageContextScratch = new SplatBoxLodTraverser.PageContext[pageCount];

            var localToWorld = transform.localToWorldMatrix;
            float outsideFoveate = EffectiveOutsideFoveate;
            float behindFoveate = EffectiveBehindFoveate;
            // Near pages must out-compete distant ones for the shared splat budget. The boost is
            // sharp inside the last couple of metres so a walk-up (< 0.5 m) can spend almost the
            // entire budget on the surface in front of the camera.
            Vector3 focus = cam != null
                ? GaussianSplatRenderSystem.GetStreamingFocusPosition(cam)
                : transform.position;
            const float kHighestDetailDistance = 0.5f;
            const float kProximityBoostRange = 4f;
            const float kMaxProximityBoost = 8f;
            float nearestPageDist = float.MaxValue;
            int contextCount = 0;
            for (int i = 0; i < pageCount; i++)
            {
                var p = pages[i];
                var tree = p?.lodTree;
                if (tree == null || tree.nodeCount == 0)
                    continue;
                if (p.atlasOffset < 0)
                    continue; // Not placed in the atlas, so its splats cannot be addressed yet.

                float pageDist = m_LodStreamer != null
                    ? m_LodStreamer.DistanceToLoadedPage(focus, p, transform)
                    : 0f;
                nearestPageDist = Mathf.Min(nearestPageDist, pageDist);
                float lodScale;
                if (pageDist <= kHighestDetailDistance)
                {
                    // Contact range: full boost so leaf nodes win the budget race.
                    lodScale = m_LodDetailScale * kMaxProximityBoost;
                }
                else
                {
                    float t = Mathf.Clamp01(pageDist / kProximityBoostRange);
                    // Quadratic falloff: ~8x at contact, ~4.5x at 0.5 m, ~1.5x at 2 m, 1x beyond 4 m.
                    lodScale = m_LodDetailScale * Mathf.Lerp(kMaxProximityBoost, 1f, t * t);
                }

                // Coarse stubs / prefixes use large merged feature sizes (often whole-page extent).
                // At full lodScale they dominate the heap and steal budget from nearby full-detail
                // pages, which reads as flickering between giant blobs and fine splats. Keep them
                // as cheap background fill unless they are in the contact range.
                if (p.isCoarseStub && pageDist > kHighestDetailDistance)
                    lodScale *= 0.08f;

                m_LodPageContextScratch[contextCount++] = new SplatBoxLodTraverser.PageContext
                {
                    pageSlot = p.pageSlot,
                    nodes = tree.nodes,
                    childTable = tree.childTable,
                    childTableStart = tree.childTableStart,
                    localToWorld = localToWorld,
                    lodScale = lodScale,
                    outsideFoveate = outsideFoveate,
                    behindFoveate = behindFoveate
                };
            }

            if (contextCount == 0)
                return 0;

            // No camera yet (first preload before any view exists): show a flat slice of every page.
            if (cam == null)
            {
                return SplatBoxLodTraverser.FillLeafFallback(
                    m_LodPageContextScratch, contextCount, maxSplats, output);
            }

            m_LodWorkspace ??= new SplatBoxLodTraverser.Workspace();
            bool frustumCull = EffectiveFrustumCull;
            float cullPadding = EffectiveCullPaddingDeg;
            float maxStandInPixels = EffectiveMaxStandInPixels;
            bool skipMerged = !EffectiveDrawCoarseStandIns;
            var view = SplatBoxLodTraverser.ViewContext.FromCamera(
                cam, frustumCull, m_LodWorkspace, cullPadding, skipMerged,
                maxStandInPixels, m_SplatScale);

            m_LodNearestPageDist = nearestPageDist;
            int selected = TraverseWithinBudget(view, contextCount, maxSplats, output);

            // Frustum culling can empty the selection when the camera looks away from the scene.
            if (selected <= 0 && frustumCull)
            {
                var noCull = SplatBoxLodTraverser.ViewContext.FromCamera(
                    cam, false, m_LodWorkspace, 0f, skipMerged, maxStandInPixels,
                    m_SplatScale);
                selected = TraverseWithinBudget(noCull, contextCount, maxSplats, output);
            }

            // Drawing nothing at all is worse than drawing approximations, so both stand-in filters
            // give way if it turns out they emptied the selection between them.
            if (selected <= 0)
            {
                var withStandIns = SplatBoxLodTraverser.ViewContext.FromCamera(
                    cam, frustumCull, m_LodWorkspace, cullPadding,
                    skipMergedSplats: false, maxStandInPixels: 0f, splatScale: m_SplatScale);
                selected = TraverseWithinBudget(withStandIns, contextCount, maxSplats, output);
            }

            if (selected <= 0)
            {
                selected = SplatBoxLodTraverser.FillLeafFallback(
                    m_LodPageContextScratch, contextCount, maxSplats, output);
            }

            return selected;
        }

        float m_LastEffectiveCutoff;
        float m_LodNearestPageDist = float.MaxValue;
        const float kAutomaticPixelScaleLimit = 1f;
        const float kCloseUpPixelScaleLimit = 0.25f;
        /// <summary>Within this distance of a page AABB, force leaf-capable refinement.</summary>
        const float kHighestDetailDistance = 0.5f;
        const float kHighestDetailPixelScaleLimit = 0.1f;

        /// <summary>
        /// One globally best-first traversal. A zero inspector value means the automatic one-pixel
        /// floor, not unlimited refinement: nodes below a pixel cannot add useful image detail, but
        /// projecting and sorting their descendants is still expensive. Detail Scale multiplies the
        /// measured node size before this floor, which makes that quality control effective even when
        /// the explicit Pixel Scale Limit is left at zero.
        /// </summary>
        int TraverseWithinBudget(in SplatBoxLodTraverser.ViewContext view, int contextCount, int maxSplats,
            LodActiveSplatRef[] output)
        {
            float requestedLimit = EffectivePixelScaleLimit;
            float effectiveLimit = requestedLimit > 0f
                ? requestedLimit
                : kAutomaticPixelScaleLimit;
            // Within half a metre the 1 px floor still leaves arm's-length surfaces soft. Drop to a
            // finer floor so the budget can reach leaf splats on the near page.
            if (m_LodNearestPageDist <= kHighestDetailDistance)
                effectiveLimit = Mathf.Min(effectiveLimit, kHighestDetailPixelScaleLimit);
            else if (m_LodNearestPageDist <= 2f)
                effectiveLimit = Mathf.Min(effectiveLimit, kCloseUpPixelScaleLimit);

            int selected = SplatBoxLodTraverser.Traverse(
                m_LodPageContextScratch, contextCount, view, maxSplats, effectiveLimit, output,
                m_LodWorkspace);

            // The traversal measures in lodScale-multiplied pixels; undo that so the stat reads in
            // real screen pixels no matter where the Detail Scale slider sits.
            float toRealPixels = 1f / Mathf.Max(0.01f, m_LodDetailScale);
            m_LastEffectiveCutoff = (m_LodWorkspace.budgetExhausted
                ? m_LodWorkspace.exhaustedPixelScale
                : effectiveLimit) * toRealPixels;
            return selected;
        }

        public void PreloadPagedLodPages(Camera cam)
        {
            if (!UsesPagedLod)
                return;
            if (!EnsureLodFormatAsset())
                return;
            EnsureLodStreamer();
            m_LodStreamer.UpdateStreaming(cam != null ? cam : ResolvePagedLodCamera(), transform, force: true);
            m_LodAtlasDirty = true;
            // First view must select immediately — deferred streaming reselection is only for
            // mid-navigation page swaps, not the cold start.
            m_LodPendingSettledReselect = false;
            m_LodSelectionDirty = true;

            if (m_CSBoxUtil == null || m_LodStreamer.loadedPages.Count == 0)
                return;

            // While coarse stubs are still streaming in, skip the synchronous atlas rebuild. Combining
            // SetData uploads with a full atlas ExecuteCommandBuffer in the same call overflows the
            // graphics ring buffer on large paged scenes. The render path rebuilds when dirty.
            if (m_LodStreamer.hasPendingCoarseLoads)
                return;

            var cmd = new CommandBuffer { name = "PreloadPagedLodAtlas" };
            RebuildLodUnifiedAtlas(cmd);
            Graphics.ExecuteCommandBuffer(cmd);
            cmd.Release();
            SelectAndGatherLodSplats(cam != null ? cam : ResolvePagedLodCamera(), null);
        }

        public void SetLodDetailScale(float scale)
        {
            float clamped = Mathf.Clamp(scale, 0.1f, 2f);
            if (Mathf.Approximately(m_LodDetailScale, clamped))
                return;

            m_LodDetailScale = clamped;
            m_LodSelectionDirty = true;
#if UNITY_EDITOR
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            UnityEditor.SceneView.RepaintAll();
#endif
        }

#if UNITY_EDITOR
        bool m_EditorLodWarmupScheduled;

        void ScheduleEditorPagedLodWarmup()
        {
            if (m_EditorLodWarmupScheduled)
                return;
            m_EditorLodWarmupScheduled = true;
            UnityEditor.EditorApplication.delayCall += EditorPagedLodWarmup;
        }

        void EditorPagedLodWarmup()
        {
            m_EditorLodWarmupScheduled = false;
            if (this == null || Application.isPlaying || !UsesPagedLod || !isActiveAndEnabled)
                return;
            if (m_CSBoxUtil == null)
            {
                ScheduleEditorPagedLodWarmup();
                return;
            }

            var cam = ResolvePagedLodCamera();
            // Keep retrying until a Scene/Game camera exists so the first selection is view-aware.
            if (cam == null)
            {
                ScheduleEditorPagedLodWarmup();
                return;
            }

            PreloadPagedLodPages(cam);
            // Coarse uploads are paced across frames; keep warmups going until every page has a stub.
            if (m_LodStreamer != null && m_LodStreamer.hasPendingCoarseLoads)
                ScheduleEditorPagedLodWarmup();
            UnityEditor.SceneView.RepaintAll();
        }

        /// <summary>
        /// Keeps page streaming and LoD selection in sync with the Scene view while not in Play mode.
        /// The URP render pass also calls UpdatePagedLod, but this keeps streaming responsive between repaints.
        /// </summary>
        internal void EditorTickPagedLodStreaming()
        {
            if (!UsesPagedLod || Application.isPlaying || m_LodStreamer == null || m_CSBoxUtil == null)
                return;

            EnsureLodStreamer();
            var cam = ResolvePagedLodCamera();

            // Cold start / paced coarse upload: keep ticking until every page has a coarse stub.
            // Uploading all pages in one Preload blows the graphics ring buffer on large scenes.
            if (m_ActiveSplatCount <= 0 || m_LodStreamer.loadedPages.Count == 0 ||
                m_LodStreamer.hasPendingCoarseLoads)
            {
                PreloadPagedLodPages(cam);
                if (m_ActiveSplatCount <= 0 || m_LodStreamer.hasPendingCoarseLoads)
                    ScheduleEditorPagedLodWarmup();
                UnityEditor.SceneView.RepaintAll();
                return;
            }

            if (cam == null)
                return;

            // Prefetch pages even while moving; the render path freezes reselection so this cannot
            // pulse density. Repaint when there is atlas/selection work for the next settled frame.
            m_LodStreamer.UpdateStreaming(cam, transform);

            if (m_LodSelectionDirty || m_LodAtlasDirty || m_LodPendingSettledReselect)
                UnityEditor.SceneView.RepaintAll();
        }
#endif
    }
}
