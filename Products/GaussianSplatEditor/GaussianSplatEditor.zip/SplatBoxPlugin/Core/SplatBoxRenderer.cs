// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Mathematics;
using Unity.Profiling;
using Unity.Profiling.LowLevel;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatRenderSystem
    {
        // Used by HDRP/URP features in separate assemblies - must be public
        public static readonly ProfilerMarker s_ProfDraw = new(ProfilerCategory.Render, "GaussianSplat.Draw", MarkerFlags.SampleGPU);
        public static readonly ProfilerMarker s_ProfCompose = new(ProfilerCategory.Render, "GaussianSplat.Compose", MarkerFlags.SampleGPU);
        public static readonly ProfilerMarker s_ProfCalcView = new(ProfilerCategory.Render, "GaussianSplat.CalcView", MarkerFlags.SampleGPU);

        public static GaussianSplatRenderSystem instance => ms_Instance ??= new GaussianSplatRenderSystem();
        static GaussianSplatRenderSystem ms_Instance;

        /// <summary>Fired when a SplatBoxRenderer (re)creates relight materials. Relight plugin uses this to re-bind light buffers.</summary>
        public static event Action OnRelightRendererReady;

        /// <summary>Fired immediately before each splat draw. Relight uses this to bind light buffers on the CommandBuffer/MPB.</summary>
        public static event Action<CommandBuffer, MaterialPropertyBlock> OnBeforeDrawSplats;

        internal static void NotifyRelightRendererReady()
        {
            OnRelightRendererReady?.Invoke();
        }

        static void InvokeBeforeDrawSplats(CommandBuffer cmb, MaterialPropertyBlock mpb)
        {
            OnBeforeDrawSplats?.Invoke(cmb, mpb);
        }

        // ── XR multi-pass matrix handling ──────────────────────────────────────────
        //
        // In XR multi-pass, camera.worldToCameraMatrix / projectionMatrix return MONO
        // matrices, not per-eye. That causes both eyes to project splats to identical
        // screen positions, producing the "warped / swimmy" stereo look on Quest 3.
        //
        // Sources of per-eye matrices:
        //   1. URP + XR Plugin Management (OpenXR / Oculus) stores them in
        //      renderingData.cameraData.GetViewMatrix() / GetProjectionMatrix(), not on
        //      the Camera. The URP feature sets them via SetOverrideMatrices() below
        //      before calling into the render system.
        //   2. Built-in RP + legacy VR still uses Camera.stereoActiveEye +
        //      Camera.GetStereoViewMatrix / GetStereoProjectionMatrix.
        //   3. Non-stereo camera: fall through to the camera's mono matrices.
        public static Matrix4x4 s_OverrideView;
        public static Matrix4x4 s_OverrideProj;
        public static bool s_OverrideActive;
        static Vector2Int s_OverrideRenderTargetSize;
        static bool s_OverrideRenderTargetSizeActive;

        public static void SetOverrideMatrices(Matrix4x4 view, Matrix4x4 proj)
        {
            s_OverrideView = view;
            s_OverrideProj = proj;
            s_OverrideActive = true;
        }

        public static void ClearOverrideMatrices()
        {
            s_OverrideActive = false;
        }

        /// <summary>
        /// Supplies the exact offscreen splat target dimensions for the current URP pass. Using the
        /// descriptor size here (rather than reconstructing it from XRSettings) also accounts for the
        /// URP asset render scale and dynamic XR eye dimensions.
        /// </summary>
        public static void SetOverrideRenderTargetSize(int width, int height)
        {
            s_OverrideRenderTargetSize = new Vector2Int(Mathf.Max(1, width), Mathf.Max(1, height));
            s_OverrideRenderTargetSizeActive = true;
        }

        public static void ClearOverrideRenderTargetSize()
        {
            s_OverrideRenderTargetSizeActive = false;
        }

        /// <summary>True after GaussianSplatURPFeature.Execute runs at least once (player diagnostic).</summary>
        public static bool URPFeatureExecuted { get; private set; }

        /// <summary>Which URP code path last ran: "RenderGraph", "Compatibility", or "none" (diagnostic).</summary>
        public static string URPExecPath { get; private set; } = "none";

        /// <summary>Last exception message thrown inside the draw loop, surfaced on the device HUD.</summary>
        public static string LastRenderError = "none";

        /// <summary>Resolution scale for the offscreen splat render target, 0.1..1. Values below 1 render
        /// the splats at a fraction of the screen / per-eye resolution (big VR perf win on Quest, which
        /// is ~4K per eye) and the composite bilinearly upscales the result. 1 = full resolution. Set via
        /// <c>SplatBoxRenderManager</c>; defaults to 1 so behaviour is unchanged unless a manager exists.</summary>
        public static float SplatRenderScale = 1f;

        /// <summary>Apply <see cref="SplatRenderScale"/> to an offscreen splat RT descriptor's width/height
        /// (clamped, min 1 pixel).</summary>
        public static void ApplySplatRenderScale(ref RenderTextureDescriptor desc)
        {
            float scale = Mathf.Clamp(SplatRenderScale, 0.1f, 1f);
            if (scale >= 0.999f)
                return;
            desc.width = Mathf.Max(1, Mathf.RoundToInt(desc.width * scale));
            desc.height = Mathf.Max(1, Mathf.RoundToInt(desc.height * scale));
        }

        /// <summary>Screen size used by CalcViewData and the splat draw shader. Must match the actual
        /// splat render-target size (including <see cref="SplatRenderScale"/>), otherwise axis sizing in
        /// compute and <c>_ScreenParams</c> in the vertex shader disagree and splats look skewed / swim.</summary>
        public static Vector4 GetSplatScreenParams(Camera cam)
        {
            if (s_OverrideRenderTargetSizeActive)
            {
                return new Vector4(
                    s_OverrideRenderTargetSize.x,
                    s_OverrideRenderTargetSize.y,
                    0f,
                    0f);
            }

            int screenW = cam.pixelWidth, screenH = cam.pixelHeight;
            int eyeW = UnityEngine.XR.XRSettings.eyeTextureWidth, eyeH = UnityEngine.XR.XRSettings.eyeTextureHeight;
            // XRSettings keeps the headset eye size populated while editing, even when this is the
            // ordinary mono Scene View camera. Using that much larger size for Scene View covariance
            // projection makes compute generate axes for the headset RT, then the vertex shader
            // divides them by the smaller Scene View RT. The result is oversized splats, gaps that
            // invite misleading Size tuning, and severe overdraw. Only use the eye dimensions for an
            // actual stereo/XR pass; URP marks those passes with the matrix override.
            bool renderingXrEye = cam.stereoEnabled || s_OverrideActive;
            if (renderingXrEye && eyeW > 0 && eyeH > 0)
            {
                screenW = eyeW;
                screenH = eyeH;
            }

            float scale = Mathf.Clamp(SplatRenderScale, 0.1f, 1f);
            if (scale < 0.999f)
            {
                screenW = Mathf.Max(1, Mathf.RoundToInt(screenW * scale));
                screenH = Mathf.Max(1, Mathf.RoundToInt(screenH * scale));
            }

            return new Vector4(screenW, screenH, 0, 0);
        }

        public static void MarkURPFeatureExecuted() => URPFeatureExecuted = true;

        public static void MarkURPExecPath(string path)
        {
            URPFeatureExecuted = true;
            URPExecPath = path;
        }

        /// <summary>Number of SplatBoxRenderers currently registered with the render system (diagnostic).</summary>
        public int RegisteredSplatCount => m_Splats.Count;

        /// <summary>Count of valid splats found in the most recent GatherSplatsForCamera call (diagnostic).</summary>
        public static int LastGatheredSplatCount { get; private set; }

        public static void GetCameraViewProj(Camera cam, out Matrix4x4 view, out Matrix4x4 proj)
        {
            // Path 1: explicit per-eye matrices supplied by the URP feature (XR Plugin)
            if (s_OverrideActive)
            {
                view = s_OverrideView;
                proj = s_OverrideProj;
                return;
            }

            // Path 2: legacy built-in stereo (stereoActiveEye works here)
            if (cam.stereoEnabled)
            {
                var activeEye = cam.stereoActiveEye;
                if (activeEye == Camera.MonoOrStereoscopicEye.Left)
                {
                    view = cam.GetStereoViewMatrix(Camera.StereoscopicEye.Left);
                    proj = cam.GetStereoProjectionMatrix(Camera.StereoscopicEye.Left);
                    return;
                }
                if (activeEye == Camera.MonoOrStereoscopicEye.Right)
                {
                    view = cam.GetStereoViewMatrix(Camera.StereoscopicEye.Right);
                    proj = cam.GetStereoProjectionMatrix(Camera.StereoscopicEye.Right);
                    return;
                }
            }

            // Path 3: non-stereo / unknown — fall back to mono camera matrices.
            view = cam.worldToCameraMatrix;
            proj = cam.projectionMatrix;
        }

        /// <summary>
        /// World-space focus for page streaming. Uses the same view matrix path as splat sorting so
        /// OpenXR / URP per-eye matrices match head movement (Camera.transform alone can lag on XR rigs).
        /// </summary>
        public static Vector3 GetStreamingFocusPosition(Camera cam)
        {
            if (cam == null)
                return Vector3.zero;

            GetCameraViewProj(cam, out Matrix4x4 view, out _);
            view.m20 *= -1f;
            view.m21 *= -1f;
            view.m22 *= -1f;
            return view.inverse.GetColumn(3);
        }

        readonly Dictionary<SplatBoxRenderer, MaterialPropertyBlock> m_Splats = new();
        readonly HashSet<Camera> m_CameraCommandBuffersDone = new();
        readonly List<(SplatBoxRenderer, MaterialPropertyBlock)> m_ActiveSplats = new();

        /// <summary>True when any splat gathered for the current camera wants scene-depth occlusion, so the
        /// render feature must ask URP for the camera depth texture before the splat pass runs.</summary>
        public bool SceneDepthOcclusionRequested { get; private set; }

        CommandBuffer m_CommandBuffer;

        public void RegisterSplat(SplatBoxRenderer r)
        {
            Debug.Log($"RegisterSplat: {r.name}, RenderPipeline={GraphicsSettings.currentRenderPipeline?.GetType().Name ?? "null (Built-in)"}");
            if (m_Splats.Count == 0)
            {
                if (GraphicsSettings.currentRenderPipeline == null)
                {
                    Camera.onPreCull += OnPreCullCamera;
                    Debug.Log("Registered OnPreCullCamera callback for Built-in RP");
                }
                else
                {
                    // SRP (URP/HDRP) handles rendering via custom render features - no callback needed
                }
            }

            m_Splats.Add(r, new MaterialPropertyBlock());
            Debug.Log($"Registered splat, total count: {m_Splats.Count}");
        }

        public bool IsRegistered(SplatBoxRenderer r) => r != null && m_Splats.ContainsKey(r);

        public void UnregisterSplat(SplatBoxRenderer r)
        {
            if (!m_Splats.ContainsKey(r))
                return;
            m_Splats.Remove(r);
            if (m_Splats.Count == 0)
            {
                if (m_CameraCommandBuffersDone != null)
                {
                    if (m_CommandBuffer != null)
                    {
                        foreach (var cam in m_CameraCommandBuffersDone)
                        {
                            if (cam)
                                cam.RemoveCommandBuffer(CameraEvent.BeforeForwardAlpha, m_CommandBuffer);
                        }
                    }
                    m_CameraCommandBuffersDone.Clear();
                }

                m_ActiveSplats.Clear();
                m_CommandBuffer?.Dispose();
                m_CommandBuffer = null;
                Camera.onPreCull -= OnPreCullCamera;
            }
        }

        /// <summary>
        /// Sets a custom material property for a specific splat renderer
        /// </summary>
        public void SetMaterialProperty(SplatBoxRenderer renderer, string propertyName, UnityEngine.Color value)
        {
            if (m_Splats.TryGetValue(renderer, out var mpb))
            {
                mpb.SetColor(propertyName, value);
            }
        }

        /// <summary>
        /// Sets the audio color tint material property for a specific splat renderer
        /// </summary>
        public void SetAudioColorTint(SplatBoxRenderer renderer, UnityEngine.Color color)
        {
            if (m_Splats.TryGetValue(renderer, out var mpb))
            {
                mpb.SetColor(SplatBoxRenderer.Props.AudioColorTint, color);
            }
        }

        /// <summary>
        /// Sets a custom material property for a specific splat renderer
        /// </summary>
        public void SetMaterialProperty(SplatBoxRenderer renderer, string propertyName, float value)
        {
            if (m_Splats.TryGetValue(renderer, out var mpb))
            {
                mpb.SetFloat(propertyName, value);
            }
        }

        /// <summary>
        /// Sets a custom material property for a specific splat renderer
        /// </summary>
        public void SetMaterialProperty(SplatBoxRenderer renderer, string propertyName, UnityEngine.Vector4 value)
        {
            if (m_Splats.TryGetValue(renderer, out var mpb))
            {
                mpb.SetVector(propertyName, value);
            }
        }

        /// <summary>
        /// Gets the MaterialPropertyBlock for a specific splat renderer
        /// </summary>
        public MaterialPropertyBlock GetMaterialPropertyBlock(SplatBoxRenderer renderer)
        {
            if (m_Splats.TryGetValue(renderer, out var mpb))
                return mpb;
            return null;
        }

        // ReSharper disable once MemberCanBePrivate.Global - used by HDRP/URP features that are not always compiled
        public bool GatherSplatsForCamera(Camera cam)
        {
            if (cam.cameraType == CameraType.Preview)
                return false;
            // gather all active & valid splat objects
            m_ActiveSplats.Clear();
            foreach (var kvp in m_Splats)
            {
                var gs = kvp.Key;
                if (gs == null || !gs.isActiveAndEnabled || !gs.HasValidAsset || !gs.HasValidRenderSetup)
                    continue;
                m_ActiveSplats.Add((kvp.Key, kvp.Value));
            }
            LastGatheredSplatCount = m_ActiveSplats.Count;
            SceneDepthOcclusionRequested = false;
            foreach (var active in m_ActiveSplats)
            {
                if (active.Item1.m_OccludeBySceneDepth)
                {
                    SceneDepthOcclusionRequested = true;
                    break;
                }
            }
            if (m_ActiveSplats.Count == 0)
                return false;

            // sort them by order and depth from camera (back to front for proper alpha blending)
            var camTr = cam.transform;
            m_ActiveSplats.Sort((a, b) =>
            {
                var orderA = a.Item1.m_RenderOrder;
                var orderB = b.Item1.m_RenderOrder;
                if (orderA != orderB)
                    return orderB.CompareTo(orderA);
                
                var trA = a.Item1.transform;
                var trB = b.Item1.transform;

                // Calculate more accurate depths considering bounds and splat distribution
                var posA = camTr.InverseTransformPoint(trA.position);
                var posB = camTr.InverseTransformPoint(trB.position);

                // For more accurate sorting, consider that splats extend from the transform
                // Use the transform position but account for typical splat cloud size
                // This provides better sorting when renderers are at similar depths
                float depthA = posA.z; // - (estimated bounds radius for back-to-front)
                float depthB = posB.z; // - (estimated bounds radius for back-to-front)

                return depthA.CompareTo(depthB);
            });

            return true;
        }

        // ReSharper disable once MemberCanBePrivate.Global - used by HDRP/URP features that are not always compiled
        public Material SortAndRenderSplats(Camera cam, CommandBuffer cmb)
        {
            // Use improved depth sorting for multiple renderers
            return SortAndRenderSplatsWithDepthSorting(cam, cmb);
        }

        private Material SortAndRenderSplatsOriginal(Camera cam, CommandBuffer cmb)
        {
            Material matComposite = null;
            foreach (var kvp in m_ActiveSplats)
            {
                var gs = kvp.Item1;
                matComposite = gs.m_MatComposite;
                var mpb = kvp.Item2;

                // sort (once per frame per camera; reused across stereo eyes)
                var matrix = gs.transform.localToWorldMatrix;
                if (gs.UsesPagedLod)
                    gs.UpdatePagedLod(cam, cmb);
                if (gs.ShouldSortThisFrame(cam))
                    gs.SortPoints(cmb, cam, matrix);
                ++gs.m_FrameCounter;

                // cache view
                kvp.Item2.Clear();
                Material displayMat = gs.m_MatSplats;
                if (displayMat == null)
                    continue;

                gs.SetAssetDataOnMaterial(mpb);
                mpb.SetBuffer(SplatBoxRenderer.Props.SplatChunks, gs.m_GpuChunks);

                mpb.SetBuffer(SplatBoxRenderer.Props.SplatViewData, gs.m_GpuView);

                mpb.SetBuffer(SplatBoxRenderer.Props.OrderBuffer, gs.m_GpuSortKeys);
                mpb.SetFloat(SplatBoxRenderer.Props.SplatScale, gs.m_SplatScale);
                mpb.SetFloat(SplatBoxRenderer.Props.SplatOpacityScale, gs.m_OpacityScale);
                mpb.SetFloat(SplatBoxRenderer.Props.SplatSize, gs.m_PointDisplaySize);
                gs.SetSceneDepthOcclusionOnMaterial(mpb);
                mpb.SetInteger(SplatBoxRenderer.Props.SHOrder, 3); // Fixed SH order
                mpb.SetInteger(SplatBoxRenderer.Props.SHOnly, 0); // Fixed SH only off
                mpb.SetInteger(SplatBoxRenderer.Props.DisplayIndex, 0);
                mpb.SetInteger(SplatBoxRenderer.Props.DisplayChunks, 0);

                if (gs.ShouldCalculateEditorLodView(cam))
                {
                    cmb.BeginSample(s_ProfCalcView);
                    gs.CalcViewData(cmb, cam, matrix);
                    cmb.EndSample(s_ProfCalcView);
                }

                // draw
                int indexCount = 6;
                int instanceCount = gs.activeSplatCount;
                MeshTopology topology = MeshTopology.Triangles;

                gs.ConfigureRelightDraw(mpb, cmb);
                InvokeBeforeDrawSplats(cmb, mpb);

                gs.LogDrawBindingsOnce(instanceCount);
                cmb.BeginSample(s_ProfDraw);
                cmb.DrawProcedural(gs.m_GpuIndexBuffer, matrix, displayMat, 0, topology, indexCount, instanceCount, mpb);
                cmb.EndSample(s_ProfDraw);
            }
            return matComposite;
        }

        private Material SortAndRenderSplatsWithDepthSorting(Camera cam, CommandBuffer cmb)
        {
            // For single renderer, use original implementation
            if (m_ActiveSplats.Count <= 1)
            {
                return SortAndRenderSplatsOriginal(cam, cmb);
            }

            // Multiple renderers - use improved sorting and rendering
            return SortAndRenderSplatsMultiRenderer(cam, cmb);
        }

        private Material SortAndRenderSplatsMultiRenderer(Camera cam, CommandBuffer cmb)
        {
            var camTr = cam.transform;
            GetCameraViewProj(cam, out Matrix4x4 viewMatrix, out _);

            // Pre-calculate depths and sort renderers by their splat distribution
            List<(SplatBoxRenderer renderer, MaterialPropertyBlock mpb, float depth, int originalIndex)> sortedRenderers =
                new List<(SplatBoxRenderer, MaterialPropertyBlock, float, int)>();

            // Calculate depth for each renderer considering splat distribution
            for (int i = 0; i < m_ActiveSplats.Count; i++)
            {
                var kvp = m_ActiveSplats[i];
                var gs = kvp.Item1;
                var matrix = gs.transform.localToWorldMatrix;

                if (gs.UsesPagedLod)
                    gs.UpdatePagedLod(cam, cmb);

                // Calculate view data to get splat positions
                kvp.Item2.Clear();
                gs.SetAssetDataOnMaterial(kvp.Item2);
                if (gs.ShouldCalculateEditorLodView(cam))
                {
                    cmb.BeginSample(s_ProfCalcView);
                    gs.CalcViewData(cmb, cam, matrix);
                    cmb.EndSample(s_ProfCalcView);
                }

                // Sort splats within this renderer (once per frame per camera; reused across stereo eyes)
                if (gs.ShouldSortThisFrame(cam))
                    gs.SortPoints(cmb, cam, matrix);
                ++gs.m_FrameCounter;

                // Calculate representative depth for this renderer
                // Use the average depth of splats, considering the renderer's transform and bounds
                Vector3 rendererViewPos = viewMatrix.MultiplyPoint(gs.transform.position);

                // For better accuracy, consider that splats are distributed around the transform
                // Use the transform position as the representative depth (this matches the original sorting but is more explicit)
                float representativeDepth = rendererViewPos.z;

                sortedRenderers.Add((gs, kvp.Item2, representativeDepth, i));
            }

            // Sort renderers by render order first, then by depth (back to front) - this ensures proper layering
            sortedRenderers.Sort((a, b) =>
            {
                var orderA = a.renderer.m_RenderOrder;
                var orderB = b.renderer.m_RenderOrder;
                if (orderA != orderB)
                    return orderB.CompareTo(orderA); // Higher order renders on top
                return a.depth.CompareTo(b.depth); // Same order: sort by depth
            });

            // Render each renderer in sorted order
            Material lastMatComposite = null;
            foreach (var (renderer, mpb, depth, originalIndex) in sortedRenderers)
            {
                var gs = renderer;
                lastMatComposite = gs.m_MatComposite;

                Material displayMat = gs.m_MatSplats;
                if (displayMat == null)
                    continue;

                var matrix = gs.transform.localToWorldMatrix;

                // Set up material properties for this renderer
                mpb.SetBuffer(SplatBoxRenderer.Props.SplatChunks, gs.m_GpuChunks);
                mpb.SetBuffer(SplatBoxRenderer.Props.SplatViewData, gs.m_GpuView);
                mpb.SetBuffer(SplatBoxRenderer.Props.OrderBuffer, gs.m_GpuSortKeys);
                mpb.SetFloat(SplatBoxRenderer.Props.SplatScale, gs.m_SplatScale);
                mpb.SetFloat(SplatBoxRenderer.Props.SplatOpacityScale, gs.m_OpacityScale);
                mpb.SetFloat(SplatBoxRenderer.Props.SplatSize, gs.m_PointDisplaySize);
                gs.SetSceneDepthOcclusionOnMaterial(mpb);
                mpb.SetInteger(SplatBoxRenderer.Props.SHOrder, 3); // Fixed SH order
                mpb.SetInteger(SplatBoxRenderer.Props.SHOnly, 0); // Fixed SH only off
                mpb.SetInteger(SplatBoxRenderer.Props.DisplayIndex, 0);
                mpb.SetInteger(SplatBoxRenderer.Props.DisplayChunks, 0);

                // Draw all splats in this renderer (with internal sorting already applied)
                int indexCount = 6;
                int instanceCount = gs.activeSplatCount;
                MeshTopology topology = MeshTopology.Triangles;

                gs.ConfigureRelightDraw(mpb, cmb);
                InvokeBeforeDrawSplats(cmb, mpb);

                gs.LogDrawBindingsOnce(instanceCount);
                cmb.BeginSample(s_ProfDraw);
                cmb.DrawProcedural(gs.m_GpuIndexBuffer, matrix, displayMat, 0, topology, indexCount, instanceCount, mpb);
                cmb.EndSample(s_ProfDraw);
            }

            return lastMatComposite;
        }

        // ReSharper disable once MemberCanBePrivate.Global - used by HDRP/URP features that are not always compiled
        // ReSharper disable once UnusedMethodReturnValue.Global - used by HDRP/URP features that are not always compiled
        public CommandBuffer InitialClearCmdBuffer(Camera cam)
        {
            m_CommandBuffer ??= new CommandBuffer {name = "RenderGaussianSplats"};
            if (GraphicsSettings.currentRenderPipeline == null && cam != null && !m_CameraCommandBuffersDone.Contains(cam))
            {
                cam.AddCommandBuffer(CameraEvent.BeforeForwardAlpha, m_CommandBuffer);
                m_CameraCommandBuffersDone.Add(cam);
            }
            // Built-in pipeline only publishes _CameraDepthTexture when the camera asks for it (URP is handled
            // by ConfigureInput in the render feature).
            if (GraphicsSettings.currentRenderPipeline == null && cam != null && SceneDepthOcclusionRequested)
                cam.depthTextureMode |= DepthTextureMode.Depth;

            // get render target for all splats
            m_CommandBuffer.Clear();
            return m_CommandBuffer;
        }

        void OnPreCullCamera(Camera cam)
        {
            if (!GatherSplatsForCamera(cam))
            {
                // Debug: log why no splats gathered
                int validCount = 0;
                foreach (var kvp in m_Splats)
                {
                    var gs = kvp.Key;
                    if (gs != null)
                        Debug.Log($"Splat '{gs.name}': Active={gs.isActiveAndEnabled}, ValidAsset={gs.HasValidAsset}, ValidRender={gs.HasValidRenderSetup}");
                    if (gs != null && gs.isActiveAndEnabled && gs.HasValidAsset && gs.HasValidRenderSetup)
                        validCount++;
                }
                if (m_Splats.Count > 0)
                    Debug.LogWarning($"GatherSplatsForCamera failed: {m_Splats.Count} registered, {validCount} valid");
                return;
            }

            InitialClearCmdBuffer(cam);

            m_CommandBuffer.GetTemporaryRT(SplatBoxRenderer.Props.GaussianSplatRT, -1, -1, 0, FilterMode.Point, GraphicsFormat.R16G16B16A16_SFloat);
            m_CommandBuffer.SetRenderTarget(SplatBoxRenderer.Props.GaussianSplatRT, BuiltinRenderTextureType.CurrentActive);
            m_CommandBuffer.ClearRenderTarget(RTClearFlags.Color, new Color(0, 0, 0, 0), 0, 0);

            // add sorting, view calc and drawing commands for each splat object
            Material matComposite = SortAndRenderSplats(cam, m_CommandBuffer);

            // compose
            m_CommandBuffer.BeginSample(s_ProfCompose);
            m_CommandBuffer.SetRenderTarget(BuiltinRenderTextureType.CameraTarget);
            m_CommandBuffer.DrawProcedural(Matrix4x4.identity, matComposite, 1, MeshTopology.Triangles, 3, 1); // Pass 1 = BlitToScreen
            m_CommandBuffer.EndSample(s_ProfCompose);
            m_CommandBuffer.ReleaseTemporaryRT(SplatBoxRenderer.Props.GaussianSplatRT);
        }
    }

    [ExecuteInEditMode]
    public partial class SplatBoxRenderer : MonoBehaviour
    {
        public enum RenderMode
        {
            Splats,
        }
        const int GROUP_SIZE = 64;
        public GaussianSplatAsset m_Asset;

        [Range(0.01f, 5.0f)] [Tooltip("Additional scaling factor for the splats")]
        public float m_SplatScale = 1.0f;
        [Range(0.1f, 1.0f)]
        [Tooltip("Resolution scale for the shared offscreen splat render target. Lower values render fewer " +
            "pixels per eye and bilinearly upscale the result. This does not reduce the splat count or GPU sort " +
            "work. 0.6-0.75 is a good Quest starting range. The setting is shared by all active splat renderers.")]
        public float m_RenderScale = 0.7f;
        [Range(0.05f, 20.0f)]
        [Tooltip("Additional scaling factor for opacity")]
        public float m_OpacityScale = 1.0f;
        [Tooltip("Rendering order compared to other splats. Within same order splats are sorted by distance. Higher order splats render 'on top of' lower order splats.")]
        public int m_RenderOrder;
        [Tooltip("Hide splats that are behind opaque scene geometry (meshes, primitives). The splats draw into " +
            "their own colour-only target, so this tests each splat fragment against URP's camera depth texture " +
            "instead of the depth buffer. Costs one depth sample per splat fragment and makes URP produce a depth " +
            "texture, so turn it off on Quest if the scene has no meshes that need to occlude the splats.")]
        public bool m_OccludeBySceneDepth = true;
        [Range(0.001f, 1f)] [Tooltip("Meters over which a splat fades out as it passes behind geometry. Small values give a crisp intersection, larger values a softer edge that hides depth-precision shimmer.")]
        public float m_SceneDepthFade = 0.02f;
        [Range(1,30)] [Tooltip("Sort splats only every N frames")]
        public int m_SortNthFrame = 1;
        [Tooltip("VR only: reuse a single depth sort for BOTH eyes (one sort/frame instead of two). Faster, " +
            "but each eye's transparency order is only approximate, which can shimmer slightly as the head moves. " +
            "Off (default) = sort each eye independently (most correct).")]
        public bool m_ReuseSortAcrossEyes = false;
        [Tooltip("Quest/Android: sort by distance from the camera instead of view-space Z. This is a little less exact for transparency, but it is more stable during pure head rotation.")]
        public bool m_SortByCameraDistanceOnMobile = true;
        [Tooltip("Quest/Android: build a deterministic sort key (quantized depth + splat index) so equal-depth splats never swap order between frames. Rarely needed - the radix sort is already stable - and it forces a 4-pass 32-bit sort, so Fast Sort 16 Bit On Mobile overrides it.")]
        public bool m_StableDeterministicSortOnMobile = true;
        [Tooltip("Auto-fit the deterministic sort depth to this asset's world-space size every frame, so the depth buckets always use the full precision for the actual cloud. Turn off to set the depth manually below.")]
        public bool m_AutoStableSortDepth = true;
        [Tooltip("Meters of depth covered by the deterministic sort. Splats farther than this share the last depth bucket. Keep just above your scene's front-to-back depth for the best precision. Ignored when Auto Stable Sort Depth is on.")]
        [Range(2f, 200f)]
        public float m_StableSortMaxDistance = 50f;
        [Tooltip("Quest/Android: keep the existing sort order while only rotating the head. NOTE: this can paint an 'extra layer' of splats on top during rotation because the order goes stale while splats reproject. Leave OFF for correct transparency; sorting every frame with camera-distance sort is usually more stable.")]
        public bool m_StableSortWhileRotatingOnMobile = false;
        [Tooltip("Meters the headset must move before Quest stable sort refreshes. Raise this if splats still blink when only rotating.")]
        [Range(0.001f, 0.25f)]
        public float m_MobileSortMoveThreshold = 0.035f;
        [Tooltip("Meters of head movement between frames that counts as walking. While moving, Quest refreshes sort every frame instead of in large steps. Set high enough that the small translation a head turn produces (the head pivots around the neck) is not mistaken for walking, or the sort refreshes every frame while you rotate and flickers.")]
        [Range(0.0005f, 0.05f)]
        public float m_MobileSortMovingThreshold = 0.015f;
        [Tooltip("Quest/Android: use a 16-bit quantized depth sort key so the GPU radix sort runs 2 passes " +
            "instead of 4 (~2x faster sort). 65536 depth buckets is finer than any visible transparency error. " +
            "Takes priority over the deterministic stable sort, which needs a slower full 32-bit key.")]
        public bool m_FastSort16BitOnMobile = true;
        [Tooltip("Escape hatch: bypass the GPU radix sort on Vulkan and draw unsorted identity order. Only " +
            "useful for isolating a driver bug - transparency will be visibly wrong with this on.")]
        public bool m_DisableGpuRadixSortOnMobile = false;

        [Header("Color Adjustments")]
        [Range(-2.0f, 5.0f)] [Tooltip("Exposure adjustment. Positive values brighten, negative values darken.")]
        public float m_Exposure = 0.0f;
        [Range(0.0f, 2.0f)] [Tooltip("Contrast adjustment. 1.0 is neutral, higher values increase contrast.")]
        public float m_Contrast = 1.0f;
        [Tooltip("Color filter tint applied to splats")]
        public Color m_ColorFilter = Color.white;
        [Range(-180.0f, 180.0f)] [Tooltip("Hue shift in degrees. Rotates the color wheel.")]
        public float m_HueShift = 0.0f;
        [Range(0.0f, 2.0f)] [Tooltip("Saturation adjustment. 1.0 is neutral, 0.0 is grayscale, higher values increase saturation.")]
        public float m_Saturation = 1.0f;

        public RenderMode m_RenderMode = RenderMode.Splats;
        [Range(1.0f,15.0f)] public float m_PointDisplaySize = 3.0f;

        public GaussianCutout[] m_Cutouts;

        // Shaders are auto-found in editor via OnValidate and serialized for builds
        [SerializeField, HideInInspector] private Shader m_ShaderSplats;
        [SerializeField, HideInInspector] private ComputeShader m_CSBoxUtil;
        [SerializeField, HideInInspector] private ComputeShader m_CSBoxUtilSort; // Separate sort shader (requires wavebasic/DX12)
        [SerializeField, HideInInspector] private bool m_UseRelightShader;

        int m_SplatCount; // initially same as asset splat count, but editing can change this
        // Runtime GPU resources — never serialized (recreated on enable).
        [System.NonSerialized] public GraphicsBuffer m_GpuSortDistances;
        [System.NonSerialized] public GraphicsBuffer m_GpuSortKeys;
        [System.NonSerialized] public GraphicsBuffer m_GpuPosData;
        [System.NonSerialized] public GraphicsBuffer m_GpuOtherData;
        [System.NonSerialized] public GraphicsBuffer m_GpuSHData;
        [System.NonSerialized] bool m_GpuSHDataContainsCoefficients;
        [System.NonSerialized] public Texture m_GpuColorData;
        [System.NonSerialized] public GraphicsBuffer m_GpuChunks;
        [System.NonSerialized] public bool m_GpuChunksValid;
        [System.NonSerialized] public GraphicsBuffer m_GpuView;
        [System.NonSerialized] public GraphicsBuffer m_GpuIndexBuffer;

        // these buffers are only for splat editing, and are lazily created
        GraphicsBuffer m_GpuEditCutouts;
        GraphicsBuffer m_GpuEditCountsBounds;
        GraphicsBuffer m_GpuEditSelected;
        GraphicsBuffer m_GpuEditTargetSelected; // second selection buffer for target region (paint target)
        GraphicsBuffer m_GpuEditDeleted;
        GraphicsBuffer m_GpuEditSelectMinDepth; // 1x uint, used for "visible only" paint selection
        GraphicsBuffer m_GpuEditSelectedMouseDown; // selection state at start of operation
        GraphicsBuffer m_GpuEditPosMouseDown; // position state at start of operation
        GraphicsBuffer m_GpuEditOtherMouseDown; // rotation/scale state at start of operation

        // Physics system buffers
        GraphicsBuffer m_GpuSplatVelocities;
        GraphicsBuffer m_GpuSplatPrevPositions;
        GraphicsBuffer m_GpuSphereColliders;
        GraphicsBuffer m_GpuSplatAnimFlags; // Per-splat animation flags (bit 0: no gravity)
        GraphicsBuffer m_GpuSplatPersistentVelocities; // Persistent velocities for continuous animation

        // Wind system buffers
        GraphicsBuffer m_GpuWindBoxes;
        
        // Attractor system buffers
        GraphicsBuffer m_GpuAttractors;
        GraphicsBuffer m_GpuSplatOriginalPositions; // Store original positions for restoration

        // Physics settings
        [Header("Physics Settings")]
        [SerializeField] private bool m_EnablePhysics = false;
        [SerializeField] private float m_Gravity = 2.0f;      // Reduced gravity
        [SerializeField] private float m_Damping = 0.95f;     // More damping
        [SerializeField] private float m_SplatMass = 1.0f;
        [SerializeField] private float m_MinVelocity = 0.05f; // Higher threshold to stop movement sooner
        [Space]
        [SerializeField] private bool m_DebugPhysics = false; // Debug option to see what's happening
        
        // Tracking for external physics components
        private int m_ActiveSphereColliderCount = 0;
        private int m_ActiveWindBoxCount = 0;
        private int m_ActiveAttractorCount = 0;

        [Header("Distance Culling")]
        [SerializeField] private bool m_EnableDistanceCulling = false;
        [SerializeField] private float m_KillRadius = 20.0f;  // Distance in meters to delete splats
        [SerializeField] private Transform m_CullOrigin;      // Origin point for distance culling (if null, uses camera)
        [SerializeField] private bool m_AutoDistanceCull = true;  // Automatically perform distance culling every frame
        [SerializeField] private int m_CullEveryNthFrame = 60;    // Perform culling every N frames for performance

        [Header("Wind System")]
        [SerializeField] private bool m_EnableWind = false;
        [SerializeField] private int m_WindUpdateEveryNthFrame = 1; // Update wind forces every N frames for performance
        [SerializeField] private float m_WindGravity = 0.5f;     // Reduced gravity for wind effects
        [SerializeField] private float m_WindDamping = 0.8f;     // Damping for wind movement
        [SerializeField] private float m_WindMinVelocity = 0.01f; // Minimum velocity threshold for wind

        GpuSorting m_Sorter;
        GpuSorting.Args m_SorterArgs;
        // SortPoints runs per camera per frame, so the "no usable sorter" warning is logged only once.
        static bool s_LoggedSorterUnavailable;
        static bool s_LoggedSortBypass;

        internal Material m_MatSplats;
        internal Material m_MatComposite;

        internal int m_FrameCounter;
        // Depth-sort dedup across stereo eyes. Multi-pass VR renders the same Camera twice per frame; the
        // eye separation (~IPD) is negligible vs scene depth, so one back-to-front order is correct for
        // both eyes. We sort at most once per (frame, camera) and reuse m_GpuSortKeys for the second eye.
        int m_LastSortFrame = -1;
        EntityId m_LastSortCamId;
        int m_SortIntervalTick;
        bool m_HasMobileStableSortPosition;
        Vector3 m_LastMobileStableSortPosition;
        bool m_HasMobileStableFramePosition;
        Vector3 m_LastMobileStableFramePosition;
        bool m_HasMobileStableFrameRotation;
        Quaternion m_LastMobileStableFrameRotation;
        int m_MobileMovingSortFramesLeft;
        // Selection revision covered by the last mobile stable sort. A fresh LoD selection resets
        // draw order to identity, and the stable-rotation hold must not keep that on screen.
        uint m_LastMobileSortedSelectionRevision;
#if UNITY_EDITOR
        struct EditorLodViewSignature
        {
            public EntityId cameraId;
            public Vector3 cameraPosition;
            public Quaternion cameraRotation;
            public float fieldOfView;
            public float orthographicSize;
            public float aspect;
            public float nearClip;
            public float farClip;
            public int pixelWidth;
            public int pixelHeight;
            public Matrix4x4 localToWorld;
            public uint selectionRevision;
            public float splatScale;
            public float opacityScale;
        }

        bool m_HasEditorLodSortObservation;
        EditorLodViewSignature m_LastEditorLodSortObservation;
        double m_LastEditorLodSortMotionTime;
        bool m_HasEditorLodSortedView;
        EditorLodViewSignature m_LastEditorLodSortedView;
        bool m_HasEditorLodCalculatedView;
        EditorLodViewSignature m_LastEditorLodCalculatedView;
#endif
        GaussianSplatAsset m_PrevAsset;
        Hash128 m_PrevHash;

        static readonly ProfilerMarker s_ProfSort = new(ProfilerCategory.Render, "GaussianSplat.Sort", MarkerFlags.SampleGPU);

        public static class Props
        {
            public static readonly int SplatPos = Shader.PropertyToID("_SplatPos");
            public static readonly int SplatOther = Shader.PropertyToID("_SplatOther");
            public static readonly int SplatSH = Shader.PropertyToID("_SplatSH");
            public static readonly int SplatSHDataValid = Shader.PropertyToID("_SplatSHDataValid");
            public static readonly int SplatColor = Shader.PropertyToID("_SplatColor");
            public static readonly int SplatSelectedBits = Shader.PropertyToID("_SplatSelectedBits");
            public static readonly int SplatTargetSelectedBits = Shader.PropertyToID("_SplatTargetSelectedBits");
            public static readonly int SplatDeletedBits = Shader.PropertyToID("_SplatDeletedBits");
            public static readonly int SplatBitsValid = Shader.PropertyToID("_SplatBitsValid");
            public static readonly int TargetSelectionColor = Shader.PropertyToID("_TargetSelectionColor");
            public static readonly int SplatFormat = Shader.PropertyToID("_SplatFormat");
            public static readonly int SplatChunks = Shader.PropertyToID("_SplatChunks");
            public static readonly int SplatChunkCount = Shader.PropertyToID("_SplatChunkCount");
            public static readonly int SplatViewData = Shader.PropertyToID("_SplatViewData");
            public static readonly int OrderBuffer = Shader.PropertyToID("_OrderBuffer");
            public static readonly int SplatScale = Shader.PropertyToID("_SplatScale");
            public static readonly int SplatOpacityScale = Shader.PropertyToID("_SplatOpacityScale");
            public static readonly int SplatSize = Shader.PropertyToID("_SplatSize");
            public static readonly int DepthOffset = Shader.PropertyToID("_DepthOffset");
            public static readonly int SceneDepthOcclusion = Shader.PropertyToID("_SceneDepthOcclusion");
            public static readonly int SceneDepthFade = Shader.PropertyToID("_SceneDepthFade");
            public static readonly int SplatCount = Shader.PropertyToID("_SplatCount");
            public static readonly int SHOrder = Shader.PropertyToID("_SHOrder");
            public static readonly int SHOnly = Shader.PropertyToID("_SHOnly");
            public static readonly int AlbedoOnly = Shader.PropertyToID("_AlbedoOnly");
            public static readonly int DisplayIndex = Shader.PropertyToID("_DisplayIndex");
            public static readonly int DisplayChunks = Shader.PropertyToID("_DisplayChunks");
            public static readonly int GaussianSplatRT = Shader.PropertyToID("_GaussianSplatRT");
            public static readonly int SplatSortKeys = Shader.PropertyToID("_SplatSortKeys");
            public static readonly int SplatSortDistances = Shader.PropertyToID("_SplatSortDistances");
            public static readonly int SortByCameraDistance = Shader.PropertyToID("_SortByCameraDistance");
            public static readonly int StableSort = Shader.PropertyToID("_StableSort");
            public static readonly int SortIndexBits = Shader.PropertyToID("_SortIndexBits");
            public static readonly int SortDepthScale = Shader.PropertyToID("_SortDepthScale");
            public static readonly int SortKeyBits = Shader.PropertyToID("_SortKeyBits");
            public static readonly int LodCopyCount = Shader.PropertyToID("_LodCopyCount");
            public static readonly int LodCopyDstOffset = Shader.PropertyToID("_LodCopyDstOffset");
            public static readonly int LodPosWordsPerSplat = Shader.PropertyToID("_LodPosWordsPerSplat");
            public static readonly int LodOtherWordsPerSplat = Shader.PropertyToID("_LodOtherWordsPerSplat");
            public static readonly int LodShWordsPerSplat = Shader.PropertyToID("_LodShWordsPerSplat");
            public static readonly int LodActiveCount = Shader.PropertyToID("_LodActiveCount");
            public static readonly int LodCopySrcPos = Shader.PropertyToID("_LodCopySrcPos");
            public static readonly int LodCopySrcOther = Shader.PropertyToID("_LodCopySrcOther");
            public static readonly int LodCopySrcSh = Shader.PropertyToID("_LodCopySrcSh");
            public static readonly int LodCopyDstPos = Shader.PropertyToID("_LodCopyDstPos");
            public static readonly int LodCopyDstOther = Shader.PropertyToID("_LodCopyDstOther");
            public static readonly int LodCopyDstSh = Shader.PropertyToID("_LodCopyDstSh");
            public static readonly int LodGatherAtlasIndices = Shader.PropertyToID("_LodGatherAtlasIndices");
            public static readonly int SplatIndexRemap = Shader.PropertyToID("_SplatIndexRemap");
            public static readonly int UseSplatIndexRemap = Shader.PropertyToID("_UseSplatIndexRemap");
            public static readonly int LodUnifiedPos = Shader.PropertyToID("_LodUnifiedPos");
            public static readonly int LodUnifiedOther = Shader.PropertyToID("_LodUnifiedOther");
            public static readonly int LodUnifiedSh = Shader.PropertyToID("_LodUnifiedSh");
            public static readonly int LodOutPos = Shader.PropertyToID("_LodOutPos");
            public static readonly int LodOutOther = Shader.PropertyToID("_LodOutOther");
            public static readonly int LodOutSh = Shader.PropertyToID("_LodOutSh");
            public static readonly int SrcBuffer = Shader.PropertyToID("_SrcBuffer");
            public static readonly int DstBuffer = Shader.PropertyToID("_DstBuffer");
            public static readonly int BufferSize = Shader.PropertyToID("_BufferSize");
            public static readonly int MatrixVP = Shader.PropertyToID("_MatrixVP");
            public static readonly int MatrixMV = Shader.PropertyToID("_MatrixMV");
            public static readonly int MatrixP = Shader.PropertyToID("_MatrixP");
            public static readonly int MatrixObjectToWorld = Shader.PropertyToID("_MatrixObjectToWorld");
            public static readonly int MatrixWorldToObject = Shader.PropertyToID("_MatrixWorldToObject");
            public static readonly int VecScreenParams = Shader.PropertyToID("_VecScreenParams");
            public static readonly int VecWorldSpaceCameraPos = Shader.PropertyToID("_VecWorldSpaceCameraPos");
            public static readonly int SelectionCenter = Shader.PropertyToID("_SelectionCenter");
            public static readonly int SelectionDelta = Shader.PropertyToID("_SelectionDelta");
            public static readonly int SelectionDeltaRot = Shader.PropertyToID("_SelectionDeltaRot");
            public static readonly int SplatCutoutsCount = Shader.PropertyToID("_SplatCutoutsCount");
            public static readonly int SplatCutouts = Shader.PropertyToID("_SplatCutouts");
            public static readonly int SelectionMode = Shader.PropertyToID("_SelectionMode");
            public static readonly int SplatPosMouseDown = Shader.PropertyToID("_SplatPosMouseDown");
            public static readonly int SplatOtherMouseDown = Shader.PropertyToID("_SplatOtherMouseDown");
            
            // Physics properties
            public static readonly int SplatVelocities = Shader.PropertyToID("_SplatVelocities");
            public static readonly int SplatPrevPositions = Shader.PropertyToID("_SplatPrevPositions");
            public static readonly int SplatPersistentVelocities = Shader.PropertyToID("_SplatPersistentVelocities");
            public static readonly int SphereColliders = Shader.PropertyToID("_SphereColliders");
            public static readonly int SphereColliderCount = Shader.PropertyToID("_SphereColliderCount");
            public static readonly int DeltaTime = Shader.PropertyToID("_DeltaTime");
            public static readonly int Gravity = Shader.PropertyToID("_Gravity");
            public static readonly int Damping = Shader.PropertyToID("_Damping");
            public static readonly int SplatMass = Shader.PropertyToID("_SplatMass");
            public static readonly int MinVelocity = Shader.PropertyToID("_MinVelocity");
            public static readonly int Time = Shader.PropertyToID("_CustomTime");
            
            // Distance culling properties
            public static readonly int EnableDistanceCulling = Shader.PropertyToID("_EnableDistanceCulling");
            public static readonly int KillRadius = Shader.PropertyToID("_KillRadius");
            public static readonly int CullOrigin = Shader.PropertyToID("_CullOrigin");
            
            // Wind system properties
            public static readonly int WindBoxes = Shader.PropertyToID("_WindBoxes");
            public static readonly int WindBoxCount = Shader.PropertyToID("_WindBoxCount");
            public static readonly int WindTime = Shader.PropertyToID("_WindTime");
            
            // Attractor properties
            public static readonly int Attractors = Shader.PropertyToID("_Attractors");
            public static readonly int AttractorCount = Shader.PropertyToID("_AttractorCount");
            
            // Deletion color filtering
            public static readonly int DeletionColorFilter = Shader.PropertyToID("_DeletionColorFilter");
            public static readonly int DeletionColorThreshold = Shader.PropertyToID("_DeletionColorThreshold");
            public static readonly int UseColorFilter = Shader.PropertyToID("_UseColorFilter");

            public static readonly int WindGravity = Shader.PropertyToID("_WindGravity");
            public static readonly int WindDamping = Shader.PropertyToID("_WindDamping");
            public static readonly int WindMinVelocity = Shader.PropertyToID("_WindMinVelocity");
            public static readonly int SplatOriginalPositions = Shader.PropertyToID("_SplatOriginalPositions");
            public static readonly int SplatAnimFlags = Shader.PropertyToID("_SplatAnimFlags");
            public static readonly int AudioColorTint = Shader.PropertyToID("_AudioColorTint");
            
            // Color adjustment properties
            public static readonly int ColorExposure = Shader.PropertyToID("_ColorExposure");
            public static readonly int ColorContrast = Shader.PropertyToID("_ColorContrast");
            public static readonly int ColorFilter = Shader.PropertyToID("_ColorFilter");
            public static readonly int ColorHueShift = Shader.PropertyToID("_ColorHueShift");
            public static readonly int ColorSaturation = Shader.PropertyToID("_ColorSaturation");
            
            // Selection color property
            public static readonly int SelectionColor = Shader.PropertyToID("_SelectionColor");
        }

        private bool m_EditModified;

        public bool editModified 
        { 
            get => m_EditModified;
            set => m_EditModified = value;
        }
        [field: NonSerialized] public uint editSelectedSplats { get; private set; }
        [field: NonSerialized] public uint editTargetSelectedSplats { get; private set; }
        [field: NonSerialized] public uint editDeletedSplats { get; private set; }
        [field: NonSerialized] public uint editCutSplats { get; private set; }
        [field: NonSerialized] public Bounds editSelectedBounds { get; private set; }
        
        [SerializeField] private Color m_SelectionColor = new Color(1f, 0.5f, 0f, 1f); // Orange default
        public Color SelectionColor
        {
            get => m_SelectionColor;
            set => m_SelectionColor = value;
        }
        
        [SerializeField] private Color m_TargetSelectionColor = new Color(0f, 0.8f, 1f, 1f); // Cyan default
        public Color TargetSelectionColor
        {
            get => m_TargetSelectionColor;
            set => m_TargetSelectionColor = value;
        }

        public GaussianSplatAsset asset => UsesPagedLod ? m_LodFormatAsset : m_Asset;
        public int splatCount => m_SplatCount;

        // Animation support methods
        public GraphicsBuffer GetSplatChunksBuffer() => m_GpuChunks;

        public enum KernelIndices
        {
            SetIndices,
            CalcDistances,
            CalcViewData,
            UpdateEditData,
            InitEditData,
            ClearBuffer,
            InvertSelection,
            SelectAll,
            OrBuffers,
            SelectionUpdate,
            SelectSplatsInScreenCircle,
            FindMinDepthInScreenCircle,
            TranslateSelection,
            RotateSelection,
            ScaleSelection,
            ExportData,
            ComputeDecimationScores,
            CopySplats,
            UpdatePhysics,
            ApplyCollisions,
            InitPhysics,
            DistanceCull,
            ApplyWindForces,
            UpdateWindPhysics,
            InitOriginalPositions,
            DirectRestorePositions,
            MarkSphereForDeletion,
            RestoreSphereFromDeletion,
            MarkCylinderForDeletion,
            RestoreCylinderFromDeletion,
            SelectSplatsInSphere,
            CloneSplatsInSphere,
            CopySplatsWithOffset,
            PaintSplat,
            PaintSplatBatch,
            PaintSplatsGPU,
            PaintSplatsFromTexture,
            ApplyEquirectangularProjection,
            AdjustColorsInBox,
            ColorizeInSphere,
            SmudgeSplats,
            PinchSplats,
            FlattenSplats,
            RelaxSplats,
            RestorePositionsInSphere,
            ApplyVelocityInSphere,
            ApplyPersistentVelocities,
            DeleteSplatsInScreenCircleWithDepth,
            // Collision and chunk breaking kernels
            DetectRigidbodyCollisions,
            MarkChunkBoundaries,
            ApplyChunkForces,
            SelfCollision,
            BreakIntoChunks,
            CopyBufferRange,
            GatherLodSplats
        }

        // Add this dictionary to store kernel indices
        private Dictionary<KernelIndices, int> m_KernelIndices;

        // Initialize the kernel indices in OnEnable
        void InitializeKernels()
        {
            if (m_CSBoxUtil == null)
            {
                Debug.LogError("Compute shader is null during kernel initialization");
                return;
            }

            m_KernelIndices = new Dictionary<KernelIndices, int>();
            
            // Helper to safely find kernel without logging errors for optional kernels
            int SafeFindKernel(string name, bool silent = false)
            {
                if (silent)
                {
                    // For optional kernels, suppress Unity's error log
                    var prevLogType = Debug.unityLogger.filterLogType;
                    Debug.unityLogger.filterLogType = LogType.Exception;
                    try { return m_CSBoxUtil.FindKernel(name); }
                    catch { return -1; }
                    finally { Debug.unityLogger.filterLogType = prevLogType; }
                }
                else
                {
                    try { return m_CSBoxUtil.FindKernel(name); }
                    catch { return -1; }
                }
            }
            
            try
            {
                // Map enum values to actual kernel indices using safe lookup
                m_KernelIndices[KernelIndices.SetIndices] = SafeFindKernel("CSSetIndices");
                m_KernelIndices[KernelIndices.CalcDistances] = SafeFindKernel("CSCalcDistances");
                m_KernelIndices[KernelIndices.CalcViewData] = SafeFindKernel("CSCalcViewData");
                m_KernelIndices[KernelIndices.UpdateEditData] = SafeFindKernel("CSUpdateEditData");
                m_KernelIndices[KernelIndices.InitEditData] = SafeFindKernel("CSInitEditData");
                m_KernelIndices[KernelIndices.ClearBuffer] = SafeFindKernel("CSClearBuffer");
                m_KernelIndices[KernelIndices.InvertSelection] = SafeFindKernel("CSInvertSelection");
                m_KernelIndices[KernelIndices.SelectAll] = SafeFindKernel("CSSelectAll");
                m_KernelIndices[KernelIndices.OrBuffers] = SafeFindKernel("CSOrBuffers");
                m_KernelIndices[KernelIndices.SelectionUpdate] = SafeFindKernel("CSSelectionUpdate");
                m_KernelIndices[KernelIndices.SelectSplatsInScreenCircle] = SafeFindKernel("CSSelectSplatsInScreenCircle");
                m_KernelIndices[KernelIndices.FindMinDepthInScreenCircle] = SafeFindKernel("CSFindMinDepthInScreenCircle");
                m_KernelIndices[KernelIndices.TranslateSelection] = SafeFindKernel("CSTranslateSelection");
                m_KernelIndices[KernelIndices.RotateSelection] = SafeFindKernel("CSRotateSelection");
                m_KernelIndices[KernelIndices.ScaleSelection] = SafeFindKernel("CSScaleSelection");
                m_KernelIndices[KernelIndices.ExportData] = SafeFindKernel("CSExportData");
                m_KernelIndices[KernelIndices.ComputeDecimationScores] = SafeFindKernel("CSComputeDecimationScores");
                m_KernelIndices[KernelIndices.CopySplats] = SafeFindKernel("CSCopySplats");
                m_KernelIndices[KernelIndices.UpdatePhysics] = SafeFindKernel("CSUpdatePhysics");
                m_KernelIndices[KernelIndices.ApplyCollisions] = SafeFindKernel("CSApplyCollisions");
                m_KernelIndices[KernelIndices.InitPhysics] = SafeFindKernel("CSInitPhysics");
                m_KernelIndices[KernelIndices.DistanceCull] = SafeFindKernel("CSDistanceCull");
                m_KernelIndices[KernelIndices.ApplyWindForces] = SafeFindKernel("CSApplyWindForces");
                m_KernelIndices[KernelIndices.UpdateWindPhysics] = SafeFindKernel("CSUpdateWindPhysics");
                m_KernelIndices[KernelIndices.InitOriginalPositions] = SafeFindKernel("CSInitOriginalPositions");
                
                // Use SafeFindKernel for all remaining kernels
                m_KernelIndices[KernelIndices.DirectRestorePositions] = SafeFindKernel("CSDirectRestorePositions");
                m_KernelIndices[KernelIndices.MarkSphereForDeletion] = SafeFindKernel("CSMarkSphereForDeletion");
                m_KernelIndices[KernelIndices.RestoreSphereFromDeletion] = SafeFindKernel("CSRestoreSphereFromDeletion");
                m_KernelIndices[KernelIndices.MarkCylinderForDeletion] = SafeFindKernel("CSMarkCylinderForDeletion");
                m_KernelIndices[KernelIndices.RestoreCylinderFromDeletion] = SafeFindKernel("CSRestoreCylinderFromDeletion");
                m_KernelIndices[KernelIndices.SelectSplatsInSphere] = SafeFindKernel("CSSelectSplatsInSphere");
                m_KernelIndices[KernelIndices.CloneSplatsInSphere] = SafeFindKernel("CSCloneSplatsInSphere");
                m_KernelIndices[KernelIndices.CopySplatsWithOffset] = SafeFindKernel("CSCopySplatsWithOffset");
                m_KernelIndices[KernelIndices.PaintSplat] = SafeFindKernel("CSPaintSplat");
                m_KernelIndices[KernelIndices.PaintSplatBatch] = SafeFindKernel("CSPaintSplatBatch");
                m_KernelIndices[KernelIndices.PaintSplatsGPU] = SafeFindKernel("CSPaintSplatsGPU");
                m_KernelIndices[KernelIndices.PaintSplatsFromTexture] = SafeFindKernel("CSPaintSplatsFromTexture");
                
                m_KernelIndices[KernelIndices.ApplyEquirectangularProjection] = SafeFindKernel("CSApplyEquirectangularProjection");
                m_KernelIndices[KernelIndices.AdjustColorsInBox] = SafeFindKernel("CSAdjustColorsInBox");
                m_KernelIndices[KernelIndices.ColorizeInSphere] = SafeFindKernel("CSColorizeInSphere");
                m_KernelIndices[KernelIndices.SmudgeSplats] = SafeFindKernel("CSSmudgeSplats");
                m_KernelIndices[KernelIndices.PinchSplats] = SafeFindKernel("CSPinchSplats");
                m_KernelIndices[KernelIndices.FlattenSplats] = SafeFindKernel("CSFlattenSplats");
                m_KernelIndices[KernelIndices.RelaxSplats] = SafeFindKernel("CSRelaxSplats");
                m_KernelIndices[KernelIndices.RestorePositionsInSphere] = SafeFindKernel("CSRestorePositionsInSphere");
                m_KernelIndices[KernelIndices.ApplyVelocityInSphere] = SafeFindKernel("CSApplyVelocityInSphere");
                m_KernelIndices[KernelIndices.ApplyPersistentVelocities] = SafeFindKernel("CSApplyPersistentVelocities");
                m_KernelIndices[KernelIndices.DeleteSplatsInScreenCircleWithDepth] = SafeFindKernel("CSDeleteSplatsInScreenCircleWithDepth");
                
                // Collision and chunk breaking kernels (optional - silent mode to avoid log spam)
                m_KernelIndices[KernelIndices.DetectRigidbodyCollisions] = SafeFindKernel("CSDetectRigidbodyCollisions", true);
                m_KernelIndices[KernelIndices.MarkChunkBoundaries] = SafeFindKernel("CSMarkChunkBoundaries", true);
                m_KernelIndices[KernelIndices.ApplyChunkForces] = SafeFindKernel("CSApplyChunkForces", true);
                m_KernelIndices[KernelIndices.SelfCollision] = SafeFindKernel("CSSelfCollision", true);
                m_KernelIndices[KernelIndices.BreakIntoChunks] = SafeFindKernel("CSBreakIntoChunks", true);
                m_KernelIndices[KernelIndices.CopyBufferRange] = SafeFindKernel("CSCopyBufferRange");
                m_KernelIndices[KernelIndices.GatherLodSplats] = SafeFindKernel("CSGatherLodSplats");

                // Validate critical kernel indices only - skip optional kernels
                var criticalKernels = new[] {
                    KernelIndices.SetIndices,
                    KernelIndices.CalcDistances,
                    KernelIndices.CalcViewData
                };
                foreach (var kernel in criticalKernels)
                {
                    if (m_KernelIndices.TryGetValue(kernel, out int idx) && idx < 0)
                    {
                        Debug.LogError($"Failed to find critical kernel for {kernel}. Please reimport BoxUtil.compute.");
                    }
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error initializing kernels: {e.Message}\n{e.StackTrace}");
            }
        }

        public bool HasValidAsset =>
            UsesPagedLod
                ? m_PagedScene != null && m_PagedScene.pageCount > 0
                : m_Asset != null &&
                  asset.splatCount > 0 &&
                  asset.formatVersion == GaussianSplatAsset.kCurrentVersion &&
                  asset.posData != null &&
                  asset.otherData != null &&
                  asset.shData != null &&
                  asset.colorData != null;
        public bool HasValidRenderSetup => m_ShaderSplats != null && m_CSBoxUtil != null && m_GpuPosData != null && m_GpuOtherData != null && m_GpuSHData != null && m_GpuChunks != null && m_GpuSortDistances != null && m_GpuSortKeys != null;

        /// <summary>Per-renderer state for the on-device diagnostic HUD, split into short narrow lines.</summary>
        public string DiagnosticLine()
        {
            string shaderName = m_ShaderSplats != null ? m_ShaderSplats.name : "<null>";
            int cutoutCount = m_Cutouts?.Length ?? 0;
            return $"{name}\n" +
                   $"  active={isActiveAndEnabled} asset={HasValidAsset}\n" +
                   $"  gpu={HasValidRenderSetup} cs={(m_CSBoxUtil != null)}\n" +
                   $"  count={m_SplatCount} relight={m_UseRelightShader}\n" +
                   // Splat-loss diagnostics: if 'del' climbs over time a delete-bit system (distance
                   // cull / brush / cutout) is firing; if 'del' stays 0 but splats vanish then a
                   // positional system (phys/wind/attractor) is drifting them out of view.
                   $"  del={editDeletedSplats} phys={m_EnablePhysics} wind={m_EnableWind} cull={m_EnableDistanceCulling} cut={cutoutCount}\n" +
                   $"  shader={shaderName}";
        }
        
        /// <summary>
        /// Whether this asset supports cloning/copy-paste. Only VeryHigh quality (Float32, no chunk data) supports cloning.
        /// </summary>
        public bool SupportsCloning => HasValidAsset && asset.chunkData == null && asset.posFormat == GaussianSplatAsset.VectorFormat.Float32;

        const int kGpuViewDataSize = 48; // SplatViewData: float4 pos + uint*2 packed axes + uint2 color + float4 worldPos (16-byte aligned for Vulkan/Adreno)

        void CreateResourcesForAsset()
        {
            if (UsesPagedLod)
            {
                InitPagedLodResources();
                return;
            }

            if (!HasValidAsset)
            {
                if (m_Asset != null)
                    Debug.LogWarning($"SplatBoxRenderer: Asset not valid - Count:{asset.splatCount}, Version:{asset.formatVersion}=={GaussianSplatAsset.kCurrentVersion}, PosData:{asset.posData != null}");
                return;
            }

            m_SplatCount = asset.splatCount;
            m_GpuPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource, (int) (asset.posData.dataSize / 4), 4) { name = "GaussianPosData" };
            m_GpuPosData.SetData(asset.posData.GetData<uint>());
            m_GpuOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource, (int) (asset.otherData.dataSize / 4), 4) { name = "GaussianOtherData" };
            m_GpuOtherData.SetData(asset.otherData.GetData<uint>());
            long maxBufferBytes = SystemInfo.maxGraphicsBufferSize > 0
                ? SystemInfo.maxGraphicsBufferSize
                : 2L * 1024 * 1024 * 1024;
            if (asset.shData.dataSize > maxBufferBytes)
            {
                // Relight uses the base colour texture and does not evaluate the captured SH coefficients.
                // Keep a valid descriptor bound on Vulkan, but avoid creating a buffer the device rejects.
                m_GpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, 1, 4) { name = "GaussianSHDataDummy" };
                m_GpuSHData.SetData(new uint[] { 0 });
                m_GpuSHDataContainsCoefficients = false;
                Debug.LogWarning(
                    $"[{name}] SH data ({asset.shData.dataSize:N0} bytes) exceeds this device's " +
                    $"{maxBufferBytes:N0}-byte graphics-buffer limit. Rendering base colour without view-dependent SH.");
            }
            else
            {
                m_GpuSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, (int) (asset.shData.dataSize / 4), 4) { name = "GaussianSHData" };
                m_GpuSHData.SetData(asset.shData.GetData<uint>());
                m_GpuSHDataContainsCoefficients = true;
            }
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(asset.splatCount);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
            var tex = new Texture2D(texWidth, texHeight, texFormat, TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate) { name = "GaussianColorData" };
            tex.SetPixelData(asset.colorData.GetData<byte>(), 0);
            tex.Apply(false, true);
            m_GpuColorData = tex;
            if (asset.chunkData != null && asset.chunkData.dataSize != 0)
            {
                m_GpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured,
                    (int) (asset.chunkData.dataSize / UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()),
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) {name = "GaussianChunkData"};
                m_GpuChunks.SetData(asset.chunkData.GetData<GaussianSplatAsset.ChunkInfo>());
                m_GpuChunksValid = true;
            }
            else
            {
                // just a dummy chunk buffer
                m_GpuChunks = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 1,
                    UnsafeUtility.SizeOf<GaussianSplatAsset.ChunkInfo>()) {name = "GaussianChunkData"};
                m_GpuChunksValid = false;
            }

            m_GpuView = new GraphicsBuffer(GraphicsBuffer.Target.Structured, asset.splatCount, kGpuViewDataSize);
            m_GpuIndexBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Index, 36, 2);
            
            // Only create physics buffers if physics is explicitly enabled
            if (m_EnablePhysics)
            {
                CreatePhysicsBuffers();
            }
            // cube indices, most often we use only the first quad
            m_GpuIndexBuffer.SetData(new ushort[]
            {
                0, 1, 2, 1, 3, 2,
                4, 6, 5, 5, 6, 7,
                0, 2, 4, 4, 2, 6,
                1, 5, 3, 5, 7, 3,
                0, 4, 1, 4, 5, 1,
                2, 3, 6, 3, 7, 6
            });

            InitSortBuffers(splatCount);
        }

        bool ShouldBypassGpuRadixSort()
        {
            return m_DisableGpuRadixSortOnMobile &&
                (Application.platform == RuntimePlatform.Android ||
                 SystemInfo.graphicsDeviceType == GraphicsDeviceType.Vulkan);
        }

        void InitSortBuffers(int count)
        {
            m_GpuSortDistances?.Dispose();
            m_GpuSortKeys?.Dispose();
            m_SorterArgs.resources.Dispose();

            m_GpuSortDistances = new GraphicsBuffer(GraphicsBuffer.Target.Structured, count, 4) { name = "GaussianSplatSortDistances" };
            m_GpuSortKeys = new GraphicsBuffer(GraphicsBuffer.Target.Structured, count, 4) { name = "GaussianSplatSortIndices" };

            // Get the correct kernel index
            int kernelIndex = GetKernelIndex(KernelIndices.SetIndices);
            if (kernelIndex < 0)
            {
                Debug.LogWarning("SetIndices kernel not found - sort buffers not initialized properly. Please reimport BoxUtil.compute");
                return;
            }

            // init keys buffer to splat indices
            if (m_CSBoxUtil != null && m_GpuSortKeys != null && m_GpuSortDistances != null)
            {
                try
                {
                    m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatSortKeys, m_GpuSortKeys);
                    m_CSBoxUtil.SetInt(Props.SplatCount, m_GpuSortDistances.count);
                    m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
                    m_CSBoxUtil.Dispatch(kernelIndex, (m_GpuSortDistances.count + (int)gsX - 1)/(int)gsX, 1, 1);
                }
                catch (System.Exception e)
                {
                    Debug.LogWarning($"Failed to initialize sort buffers: {e.Message}. Please reimport BoxUtil.compute");
                }
            }

            if (m_GpuSortDistances != null && m_GpuSortKeys != null)
            {
                m_SorterArgs.inputKeys = m_GpuSortDistances;
                m_SorterArgs.inputValues = m_GpuSortKeys;
                m_SorterArgs.count = (uint)count;
                if (m_Sorter != null && m_Sorter.Valid && !ShouldBypassGpuRadixSort())
                    m_SorterArgs.resources = GpuSorting.SupportResources.Load((uint)count);
            }
        }

        /// <summary>
        /// Editor-only: Auto-find and assign shader references via AssetDatabase.
        /// Called by OnValidate, Reset, and OnEnable to ensure shaders are serialized for builds.
        /// </summary>
        void EditorAutoFindShaders()
        {
            #if UNITY_EDITOR
            bool configuredRelight =
                UnityEditor.EditorPrefs.GetBool("SplatBox.Relight.UseRelight", true);
            bool useRelight = configuredRelight;
            // Relight evaluates its full lighting path once per quad vertex. For a large paged
            // selection that means six identical lighting evaluations per splat on every repaint.
            // Keep the editor preview lightweight; player setup restores the configured relight path.
            if (!Application.isPlaying && UsesPagedLod && m_LodFastEditorPreview)
                useRelight = false;
            Shader relightShader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Resources/RenderSplatsRelight.shader");
            if (relightShader == null)
                relightShader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Shaders/Relight/RenderGaussianSplats.shader");
            Shader defaultShader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Resources/RenderSplats.shader");
            var shaderGuids = UnityEditor.AssetDatabase.FindAssets("RenderGaussianSplats t:Shader");
            if (shaderGuids.Length > 0)
            {
                string relightPath = null;
                string fallbackPath = null;
                for (int i = 0; i < shaderGuids.Length; i++)
                {
                    var path = UnityEditor.AssetDatabase.GUIDToAssetPath(shaderGuids[i]);
                    if (path != null && path.IndexOf("Relight", System.StringComparison.OrdinalIgnoreCase) >= 0)
                        relightPath = path;
                    else if (fallbackPath == null)
                        fallbackPath = path;
                }
                if (relightShader == null && relightPath != null)
                    relightShader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>(relightPath);
                if (defaultShader == null && fallbackPath != null)
                    defaultShader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>(fallbackPath);
                bool currentlyRelight = IsRelightShader(m_ShaderSplats);
                if (!useRelight && currentlyRelight && defaultShader != null)
                {
                    m_ShaderSplats = defaultShader;
                    m_UseRelightShader = configuredRelight;
                }
                else if (useRelight && relightShader != null && (m_ShaderSplats == null || !currentlyRelight))
                {
                    m_ShaderSplats = relightShader;
                    m_UseRelightShader = true;
                }
                else if (m_ShaderSplats == null && fallbackPath != null)
                    m_ShaderSplats = defaultShader;
                else if (useRelight && currentlyRelight)
                    m_UseRelightShader = true;
                else if (!useRelight && m_ShaderSplats != null && !currentlyRelight)
                    m_UseRelightShader = configuredRelight;
            }
            else if (useRelight && relightShader != null &&
                     (m_ShaderSplats == null || !IsRelightShader(m_ShaderSplats)))
            {
                m_ShaderSplats = relightShader;
                m_UseRelightShader = true;
            }
            else if (!useRelight && defaultShader != null &&
                     (m_ShaderSplats == null || IsRelightShader(m_ShaderSplats)))
            {
                m_ShaderSplats = defaultShader;
                m_UseRelightShader = configuredRelight;
            }
            if (m_CSBoxUtil == null)
            {
                // Try multiple search patterns to find the compute shader
                var guids = UnityEditor.AssetDatabase.FindAssets("BoxUtil t:ComputeShader");
                if (guids.Length == 0)
                    guids = UnityEditor.AssetDatabase.FindAssets("BoxUtil.compute t:ComputeShader");
                if (guids.Length == 0)
                    guids = UnityEditor.AssetDatabase.FindAssets("BoxUtil");
                
                if (guids.Length > 0)
                {
                    foreach (var guid in guids)
                    {
                        var path = UnityEditor.AssetDatabase.GUIDToAssetPath(guid);
                        var asset = UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                        if (asset != null)
                        {
                            m_CSBoxUtil = asset;
                            break;
                        }
                    }
                }
                
                // Fallback: try direct paths (package and Assets folder)
                if (m_CSBoxUtil == null)
                {
                    var directPaths = new[]
                    {
                        "Packages/com.gaussiansplatting.splatbox/Shaders/BoxUtil.compute",
                        "Assets/Shaders/BoxUtil.compute",
                        "Shaders/BoxUtil.compute",
                        "Assets/SplatBox/Shaders/BoxUtil.compute"
                    };
                    foreach (var directPath in directPaths)
                    {
                        var asset = UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>(directPath);
                        if (asset != null)
                        {
                            m_CSBoxUtil = asset;
                            break;
                        }
                    }
                }
                
                if (m_CSBoxUtil == null)
                {
                    Debug.LogWarning("BoxUtil compute shader not found. Please ensure BoxUtil.compute exists in the Shaders folder and Unity has imported it. Try refreshing the Asset Database (Assets > Refresh).");
                }
            }
            if (m_CSBoxUtilSort == null)
            {
                // Find the separate sort compute shader (requires wavebasic/DX12)
                var guids = UnityEditor.AssetDatabase.FindAssets("BoxUtilSort t:ComputeShader");
                if (guids.Length > 0)
                {
                    foreach (var guid in guids)
                    {
                        var path = UnityEditor.AssetDatabase.GUIDToAssetPath(guid);
                        var asset = UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>(path);
                        if (asset != null)
                        {
                            m_CSBoxUtilSort = asset;
                            break;
                        }
                    }
                }
                
                if (m_CSBoxUtilSort == null)
                {
                    var directPaths = new[]
                    {
                        "Packages/com.gaussiansplatting.splatbox/Shaders/BoxUtilSort.compute",
                        "Assets/Shaders/BoxUtilSort.compute",
                        "Shaders/BoxUtilSort.compute",
                        "Assets/SplatBox/Shaders/BoxUtilSort.compute"
                    };
                    foreach (var directPath in directPaths)
                    {
                        var asset = UnityEditor.AssetDatabase.LoadAssetAtPath<ComputeShader>(directPath);
                        if (asset != null)
                        {
                            m_CSBoxUtilSort = asset;
                            break;
                        }
                    }
                }
            }
            #endif
        }

#if UNITY_EDITOR
        /// <summary>
        /// Auto-assign shaders when the component is modified or script is reloaded in the editor.
        /// This ensures the [SerializeField] references are populated and saved with the scene,
        /// so they are available in standalone builds.
        /// </summary>
        void OnValidate()
        {
            m_RenderScale = Mathf.Clamp(m_RenderScale, 0.1f, 1f);
            GaussianSplatRenderSystem.SplatRenderScale = m_RenderScale;

            // Serialized render settings can affect projected covariance, visibility or sort order.
            // Do not retain editor GPU caches across an inspector change.
            m_HasEditorLodCalculatedView = false;
            m_HasEditorLodSortedView = false;
            m_HasEditorLodSortObservation = false;

            // LoD quality edits (the Quality slider or the advanced knobs) must show up without
            // waiting for the camera to move. The atlas rebuild is a no-op when its layout key is
            // unchanged, so re-checking it here is cheap.
            m_LodSelectionDirty = true;
            m_LodAtlasDirty = true;

            EditorAutoFindShaders();
            if (m_PagedScene != null && m_PagedScene.pageCount > 0 && m_Asset != null)
                m_Asset = null;
            if (m_MatSplats != null && m_ShaderSplats != null && m_MatSplats.shader != m_ShaderSplats)
            {
                DestroyImmediate(m_MatSplats);
                DestroyImmediate(m_MatComposite);
                m_MatSplats = new Material(m_ShaderSplats) {name = "GaussianSplats"};
                m_MatComposite = new Material(m_ShaderSplats) {name = "GaussianComposite"};
                ConfigureRelightMaterialsIfNeeded();
            }
        }

        /// <summary>
        /// Auto-assign shaders when the component is first added to a GameObject.
        /// </summary>
        void Reset()
        {
            EditorAutoFindShaders();
        }
#endif

        public void OnEnable()
        {
            m_FrameCounter = 0;
            m_RenderScale = Mathf.Clamp(m_RenderScale, 0.1f, 1f);
            GaussianSplatRenderSystem.SplatRenderScale = m_RenderScale;
            
            // In editor: auto-find shaders (also populates serialized fields for builds)
            EditorAutoFindShaders();

            // Player builds: Resources.Load guarantees inclusion (Shader.Find strips unreferenced shaders on Android).
            #if !UNITY_EDITOR
            ResolvePlayerShaderReferences();
            #endif
            
            if (m_ShaderSplats == null || m_CSBoxUtil == null)
            {
                Debug.LogError($"SplatBoxRenderer.OnEnable FAILED: Missing shaders - Splats:{m_ShaderSplats != null}, Compute:{m_CSBoxUtil != null}. " +
                    "Ensure Resources/RenderSplatsRelight.shader and Resources/BoxUtil.compute are in the build.");
                return;
            }
            
            Debug.Log($"SplatBoxRenderer.OnEnable: Shaders found, initializing...");
            if (!SystemInfo.supportsComputeShaders)
                return;

            InitializeKernels();

            m_MatSplats = new Material(m_ShaderSplats) {name = "GaussianSplats"};
            m_MatComposite = new Material(m_ShaderSplats) {name = "GaussianComposite"};
            ConfigureRelightMaterialsIfNeeded();

            // Use the separate sort compute shader (wave intrinsics, DX12/Vulkan only).
            // Falls back to main compute shader if sort shader is unavailable.
            var sortCS = m_CSBoxUtilSort != null ? m_CSBoxUtilSort : m_CSBoxUtil;
            m_Sorter = new GpuSorting(sortCS);
            GaussianSplatRenderSystem.instance.RegisterSplat(this);

            CreateResourcesForAsset();

#if UNITY_EDITOR
            // Ensure continuous updates in editor mode
            UnityEditor.EditorApplication.update += EditorUpdate;
#endif
        }

        const string kRelightShaderName = "Gaussian Splatting/Render Splats Relight";
        const string kRelightShaderResource = "RenderSplatsRelight";
        const string kDefaultSplatsShaderName = "Gaussian Splatting/Render Splats";

        static bool IsRelightShader(Shader shader)
        {
            // Name-agnostic: matches both the canonical "...Render Splats Relight" and the
            // unique-named Resources copy "...Render Splats Relight (Player)" used in builds.
            return shader != null && shader.name.IndexOf("Relight", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        /// <summary>
        /// Resolve splat/compute shaders on device. Resources assets are always included in builds;
        /// serialized references and Shader.Find alone are unreliable on Android/Quest.
        /// </summary>
        void ResolvePlayerShaderReferences()
        {
            // Always prefer Resources on device — serialized ComputeShader refs often break in IL2CPP/Android builds.
            var boxUtil = Resources.Load<ComputeShader>("BoxUtil");
            if (boxUtil != null)
                m_CSBoxUtil = boxUtil;
            var boxUtilSort = Resources.Load<ComputeShader>("BoxUtilSort");
            if (boxUtilSort != null)
                m_CSBoxUtilSort = boxUtilSort;

            Shader relightFromResources = Resources.Load<Shader>(kRelightShaderResource);
            Shader defaultFromResources = Resources.Load<Shader>("RenderSplats");
            bool serializedIsRelight = IsRelightShader(m_ShaderSplats);

            // m_UseRelightShader is saved with the scene; EditorPrefs do not exist on Quest.
            if (!serializedIsRelight && (m_UseRelightShader || SceneUsesRelight()))
            {
                if (relightFromResources != null)
                    m_ShaderSplats = relightFromResources;
                else
                    m_ShaderSplats = Shader.Find(kRelightShaderName);
            }

            if (m_ShaderSplats == null)
            {
                if (m_UseRelightShader || SceneUsesRelight())
                {
                    m_ShaderSplats = relightFromResources;
                    if (m_ShaderSplats == null)
                        m_ShaderSplats = Shader.Find(kRelightShaderName);
                }
                if (m_ShaderSplats == null)
                {
                    m_ShaderSplats = defaultFromResources;
                    if (m_ShaderSplats == null)
                        m_ShaderSplats = Shader.Find(kDefaultSplatsShaderName);
                }
            }

            if (IsRelightShader(m_ShaderSplats) && relightFromResources != null && m_ShaderSplats != relightFromResources)
                m_ShaderSplats = relightFromResources;
        }

        /// <summary>
        /// Re-initialize render registration on device when OnEnable bailed early or shader refs were stale.
        /// </summary>
        public void EnsurePlayerRenderReady()
        {
#if UNITY_EDITOR
            return;
#else
            ResolvePlayerShaderReferences();

            if (m_ShaderSplats == null || m_CSBoxUtil == null)
            {
                Debug.LogError(
                    $"[{name}] SplatBoxRenderer: missing player shaders (Splats={m_ShaderSplats != null}, BoxUtil={m_CSBoxUtil != null}). " +
                    "Ensure Resources/RenderSplatsRelight.shader and Resources/BoxUtil.compute ship in the build.");
                return;
            }

            if (!SystemInfo.supportsComputeShaders)
            {
                Debug.LogError($"[{name}] SplatBoxRenderer: compute shaders not supported on this device.");
                return;
            }

            var system = GaussianSplatRenderSystem.instance;
            bool registered = system.IsRegistered(this);
            bool gpuReady = m_GpuView != null && HasValidRenderSetup;
            bool shaderChanged = m_MatSplats != null && m_MatSplats.shader != m_ShaderSplats;

            if (registered && gpuReady && !shaderChanged)
                return;

            Debug.Log(
                $"[{name}] SplatBoxRenderer EnsurePlayerRenderReady: registered={registered}, gpuReady={gpuReady}, " +
                $"shaderChanged={shaderChanged}, useRelight={m_UseRelightShader}, validAsset={HasValidAsset}, shader={m_ShaderSplats.name}");

            if (m_MatSplats != null)
            {
                Destroy(m_MatSplats);
                Destroy(m_MatComposite);
                m_MatSplats = null;
                m_MatComposite = null;
            }

            if (registered)
                system.UnregisterSplat(this);

            InitializeKernels();
            m_MatSplats = new Material(m_ShaderSplats) { name = "GaussianSplats" };
            m_MatComposite = new Material(m_ShaderSplats) { name = "GaussianComposite" };
            ConfigureRelightMaterialsIfNeeded();

            var sortCS = m_CSBoxUtilSort != null ? m_CSBoxUtilSort : m_CSBoxUtil;
            m_Sorter = new GpuSorting(sortCS);
            system.RegisterSplat(this);
            CreateResourcesForAsset();

            if (!HasValidAsset)
                Debug.LogWarning($"[{name}] SplatBoxRenderer: no valid GaussianSplatAsset assigned.");
            else if (!HasValidRenderSetup)
                Debug.LogWarning($"[{name}] SplatBoxRenderer: GPU buffers not ready after init.");
#endif
        }

        /// <summary>
        /// Pre-warm this renderer's GPU buffers/materials so the first visible frame does not allocate while
        /// the player is moving. In player builds this also repairs stale Android shader references.
        /// </summary>
        public void PreloadToGpuMemory()
        {
#if UNITY_EDITOR
            if (!Application.isPlaying)
                return;
#endif
            EnsurePlayerRenderReady();
        }

        /// <summary>
        /// Release this renderer's GPU memory and unregister it from the render system. Call
        /// <see cref="PreloadToGpuMemory"/> to load it again.
        /// </summary>
        public void UnloadFromGpuMemory()
        {
            GaussianSplatRenderSystem.instance.UnregisterSplat(this);
            DisposeResourcesForAsset();
            DestroyRenderMaterials();
        }

        void DestroyRenderMaterials()
        {
            if (m_MatSplats != null)
            {
                if (Application.isPlaying)
                    Destroy(m_MatSplats);
                else
                    DestroyImmediate(m_MatSplats);
                m_MatSplats = null;
            }

            if (m_MatComposite != null)
            {
                if (Application.isPlaying)
                    Destroy(m_MatComposite);
                else
                    DestroyImmediate(m_MatComposite);
                m_MatComposite = null;
            }
        }

        static bool SceneUsesRelight()
        {
            var mgrType = Type.GetType("GaussianSplatting.Relight.CustomLightManager, GaussianSplatting.SplatBox.Relight");
            if (mgrType == null)
                return false;

            var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            if (!scene.IsValid())
                return false;

            var roots = scene.GetRootGameObjects();
            for (int i = 0; i < roots.Length; i++)
            {
                if (roots[i].GetComponentInChildren(mgrType, true) != null)
                    return true;
            }
            return false;
        }

        static void ConfigureRelightMaterial(Material mat)
        {
            if (mat == null)
                return;
            // No SSAO provider is wired up in this project. Keep the slot valid and disable
            // the strength multiplier — otherwise an unbound sampler returns 0 and every splat
            // goes black when toggling the relight shader.
            if (mat.HasProperty("_GaussianSSAO"))
                mat.SetTexture("_GaussianSSAO", Texture2D.whiteTexture);
            if (mat.HasProperty("_SSAOStrength"))
                mat.SetFloat("_SSAOStrength", 0f);
            // Ambient = 1 (neutral white fill) keeps splats at their original albedo when unlit.
            // Directional = 0 so the editor/scene main light does NOT tint the splats; the intended
            // illumination comes from the relight (custom) lights, which use their own buffers.
            if (mat.HasProperty("_AmbientIntensity"))
                mat.SetFloat("_AmbientIntensity", 1f);
            if (mat.HasProperty("_DirectionalIntensity"))
                mat.SetFloat("_DirectionalIntensity", 0f);
        }

        void ConfigureRelightMaterialsIfNeeded()
        {
            if (!IsRelightShader(m_ShaderSplats))
                return;
            ConfigureRelightMaterial(m_MatSplats);
            ConfigureRelightMaterial(m_MatComposite);
            Shader.SetGlobalTexture("_GaussianSSAO", Texture2D.whiteTexture);
            GaussianSplatRenderSystem.NotifyRelightRendererReady();
        }

        /// <summary>Per-draw scene-depth occlusion inputs for the splat shaders (both relight and default).</summary>
        internal void SetSceneDepthOcclusionOnMaterial(MaterialPropertyBlock mpb)
        {
            if (mpb == null)
                return;
            mpb.SetInteger(Props.SceneDepthOcclusion, m_OccludeBySceneDepth ? 1 : 0);
            mpb.SetFloat(Props.SceneDepthFade, Mathf.Max(0.001f, m_SceneDepthFade));
        }

        internal void ConfigureRelightDraw(MaterialPropertyBlock mpb, CommandBuffer cmd)
        {
            if (!IsRelightShader(m_ShaderSplats))
                return;
            ConfigureRelightMaterial(m_MatSplats);
            if (mpb == null)
                return;
            mpb.SetTexture("_GaussianSSAO", Texture2D.whiteTexture);
            mpb.SetFloat("_SSAOStrength", 0f);
            // Neutral baseline: ambient fills to original albedo, scene directional off (relight lights
            // provide the actual illumination). See ConfigureRelightMaterial for rationale.
            mpb.SetFloat("_AmbientIntensity", 1f);
            mpb.SetFloat("_DirectionalIntensity", 0f);
        }

        // Helper method to get kernel index
        private int GetKernelIndex(KernelIndices kernel)
        {
            if (m_KernelIndices == null)
            {
                // Try to reinitialize kernels if dictionary is null
                InitializeKernels();
                if (m_KernelIndices == null)
                {
                    Debug.LogError($"BoxUtil.compute: Kernel dictionary not initialized for {kernel}");
                    return -1;
                }
            }
            
            if (m_KernelIndices.TryGetValue(kernel, out int index))
            {
                if (index < 0)
                {
                    // Silent return for kernels that were already marked as unavailable during init
                    return -1;
                }
                return index;
            }
            Debug.LogError($"BoxUtil.compute: Kernel index not found for {kernel}");
            return -1;
        }

        // Safe wrapper for GetKernelThreadGroupSizes that handles invalid kernels
        private bool TryGetKernelThreadGroupSize(int kernelIndex, out uint groupSize, KernelIndices kernelType = KernelIndices.SetIndices)
        {
            groupSize = 0;
            if (kernelIndex < 0 || m_CSBoxUtil == null)
                return false;
            
            try
            {
                m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out groupSize, out _, out _);
                return groupSize > 0;
            }
            catch (System.Exception)
            {
                // Mark this kernel as broken to prevent repeated errors
                if (m_KernelIndices != null && m_KernelIndices.ContainsKey(kernelType))
                    m_KernelIndices[kernelType] = -1;
                return false;
            }
        }

        public void SetAssetDataOnCS(CommandBuffer cmb, KernelIndices kernel)
        {
            ComputeShader cs = m_CSBoxUtil;
            int kernelIndex = GetKernelIndex(kernel);
            if (kernelIndex < 0) return;

            GetSplatComputeBindings(out var posBuf, out var otherBuf, out var shBuf, out var colorTex,
                out var chunkBuf, out var chunkCount, out var remapBuf, out var useRemap);

            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatPos, posBuf);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatChunks, chunkBuf);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatOther, otherBuf);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatSH, shBuf);
            cmb.SetComputeIntParam(cs, Props.SplatSHDataValid,
                UsesPagedLod || m_GpuSHDataContainsCoefficients ? 1 : 0);
            cmb.SetComputeTextureParam(cs, kernelIndex, Props.SplatColor, colorTex);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatSelectedBits, m_GpuEditSelected ?? posBuf);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatDeletedBits, m_GpuEditDeleted ?? posBuf);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatViewData, m_GpuView);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.OrderBuffer, m_GpuSortKeys);
            cmb.SetComputeIntParam(cs, Props.UseSplatIndexRemap, useRemap);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatIndexRemap, remapBuf);

            cmb.SetComputeIntParam(cs, Props.SplatBitsValid, m_GpuEditSelected != null && m_GpuEditDeleted != null ? 1 : 0);
            uint format = (uint)asset.posFormat | ((uint)asset.scaleFormat << 8) | ((uint)asset.shFormat << 16);
            cmb.SetComputeIntParam(cs, Props.SplatFormat, (int)format);
            cmb.SetComputeIntParam(cs, Props.SplatCount, activeSplatCount);
            cmb.SetComputeIntParam(cs, Props.SplatChunkCount, chunkCount);

            UpdateCutoutsBuffer();
            cmb.SetComputeIntParam(cs, Props.SplatCutoutsCount, m_Cutouts?.Length ?? 0);
            cmb.SetComputeBufferParam(cs, kernelIndex, Props.SplatCutouts, m_GpuEditCutouts);
        }

        internal void SetAssetDataOnMaterial(MaterialPropertyBlock mat)
        {
            GetSplatComputeBindings(out var posBuf, out var otherBuf, out var shBuf, out var colorTex,
                out _, out var chunkCount, out var remapBuf, out var useRemap);

            mat.SetBuffer(Props.SplatPos, posBuf);
            mat.SetBuffer(Props.SplatOther, otherBuf);
            mat.SetBuffer(Props.SplatSH, shBuf);
            mat.SetTexture(Props.SplatColor, colorTex);
            mat.SetInt(Props.UseSplatIndexRemap, useRemap);
            mat.SetBuffer(Props.SplatIndexRemap, remapBuf);
            mat.SetBuffer(Props.SplatSelectedBits, m_GpuEditSelected ?? m_GpuPosData);
            mat.SetBuffer(Props.SplatTargetSelectedBits, m_GpuEditTargetSelected ?? m_GpuPosData);
            mat.SetBuffer(Props.SplatDeletedBits, m_GpuEditDeleted ?? m_GpuPosData);
            mat.SetInt(Props.SplatBitsValid, m_GpuEditSelected != null && m_GpuEditDeleted != null ? 1 : 0);
            uint format = (uint)asset.posFormat | ((uint)asset.scaleFormat << 8) | ((uint)asset.shFormat << 16);
            mat.SetInteger(Props.SplatFormat, (int)format);
            mat.SetInteger(Props.SplatCount, activeSplatCount);
            mat.SetInteger(Props.SplatChunkCount, chunkCount);

            // Set color adjustment properties
            mat.SetFloat(Props.ColorExposure, m_Exposure);
            mat.SetFloat(Props.ColorContrast, m_Contrast);
            mat.SetColor(Props.ColorFilter, m_ColorFilter);
            mat.SetFloat(Props.ColorHueShift, m_HueShift);
            mat.SetFloat(Props.ColorSaturation, m_Saturation);
            
            // Set selection colors
            mat.SetColor(Props.SelectionColor, m_SelectionColor);
            mat.SetColor(Props.TargetSelectionColor, m_TargetSelectionColor);
        }

        static void DisposeBuffer(ref GraphicsBuffer buf)
        {
            buf?.Dispose();
            buf = null;
        }

        /// <summary>
        /// Sets a custom material property for audio reactions and other effects
        /// </summary>
        public static void SetMaterialProperty(SplatBoxRenderer renderer, string propertyName, Color value)
        {
            GaussianSplatRenderSystem.instance?.SetMaterialProperty(renderer, propertyName, value);
        }

        /// <summary>
        /// Sets the audio color tint material property
        /// </summary>
        public static void SetAudioColorTint(SplatBoxRenderer renderer, Color color)
        {
            GaussianSplatRenderSystem.instance?.SetAudioColorTint(renderer, color);
        }

        /// <summary>
        /// Sets a custom material property for audio reactions and other effects
        /// </summary>
        public static void SetMaterialProperty(SplatBoxRenderer renderer, string propertyName, float value)
        {
            GaussianSplatRenderSystem.instance?.SetMaterialProperty(renderer, propertyName, value);
        }

        /// <summary>
        /// Sets a custom material property for audio reactions and other effects
        /// </summary>
        public static void SetMaterialProperty(SplatBoxRenderer renderer, string propertyName, Vector4 value)
        {
            GaussianSplatRenderSystem.instance?.SetMaterialProperty(renderer, propertyName, value);
        }

        void CreatePhysicsBuffers()
        {
            if (m_SplatCount <= 0) return;
            
            if (m_DebugPhysics)
                Debug.Log($"CreatePhysicsBuffers: Creating buffers for {m_SplatCount} splats");
            
            // Create velocity and position buffers only if they don't exist
            if (m_GpuSplatVelocities == null)
            {
                m_GpuSplatVelocities = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatVelocities" };
            }
            if (m_GpuSplatPrevPositions == null)
            {
                m_GpuSplatPrevPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatPrevPositions" };
            }
            
            // Create sphere colliders buffer (start with capacity for 10 colliders)
            // SphereColliderData: Vector3 pos (12) + Vector3 vel (12) + float radius (4) + float mass (4) + float restitution (4) = 36 bytes
            if (m_GpuSphereColliders == null)
            {
                m_GpuSphereColliders = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 10, 36) { name = "SphereColliders" };
            }
            
            // Create animation flags buffer (1 bit per splat, stored as uint32 words)
            if (m_GpuSplatAnimFlags == null)
            {
                int flagWordCount = (m_SplatCount + 31) / 32;
                m_GpuSplatAnimFlags = new GraphicsBuffer(GraphicsBuffer.Target.Raw, flagWordCount, 4) { name = "SplatAnimFlags" };
                // Initialize to zero (all splats have gravity enabled by default)
                uint[] zeroFlags = new uint[flagWordCount];
                m_GpuSplatAnimFlags.SetData(zeroFlags);
            }
            
            // Create persistent velocities buffer for continuous animation
            if (m_GpuSplatPersistentVelocities == null)
            {
                m_GpuSplatPersistentVelocities = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatPersistentVelocities" };
                Vector3[] zeroVelocities = new Vector3[m_SplatCount];
                m_GpuSplatPersistentVelocities.SetData(zeroVelocities);
            }
            
            // Create wind boxes buffer (start with capacity for 10 wind boxes)
            if (m_GpuWindBoxes == null)
            {
                CreateWindBuffers();
            }

            // Ensure original positions buffer exists for restoration
            if (m_GpuSplatOriginalPositions == null && m_SplatCount > 0)
            {
                m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
                InitializeOriginalPositions();
            }
            
            // Always initialize physics buffers to prevent undefined behavior
            // This just sets up the initial state but doesn't cause movement
            InitializePhysics();
        }

        void CreateWindBuffers()
        {
            // WindBoxData struct size calculation using Unity's SizeOf
            int windBoxDataSize = System.Runtime.InteropServices.Marshal.SizeOf<WindBoxData>();
            m_GpuWindBoxes = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 10, windBoxDataSize) { name = "WindBoxes" };
            
            // Create buffer to store original splat positions for restoration
            if (m_SplatCount > 0)
            {
                if (m_GpuSplatOriginalPositions == null)
                {
                    m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
                }
                InitializeOriginalPositions();
            }
        }
        
        void CreateAttractorBuffers()
        {
            if (m_GpuAttractors != null) return;
            
            // AttractorData struct size calculation using Unity's SizeOf
            int attractorDataSize = System.Runtime.InteropServices.Marshal.SizeOf<AttractorData>();
            m_GpuAttractors = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 32, attractorDataSize) { name = "Attractors" };
        }

        void InitializeOriginalPositions()
        {
            if (m_GpuSplatOriginalPositions == null) return;
            
            int initKernel = GetKernelIndex(KernelIndices.InitOriginalPositions);
            if (initKernel < 0)
            {
                Debug.LogWarning("InitOriginalPositions kernel not found - skipping initialization");
                return;
            }
            
            // Validate kernel index is within valid range
            try
            {
                // Copy current splat positions to original positions buffer
                using var cmb = new CommandBuffer { name = "InitOriginalPositions" };
                
                // Use the proper SetAssetDataOnCS method to ensure all required buffers are set
                SetAssetDataOnCS(cmb, KernelIndices.InitOriginalPositions);
                
                // Set the original positions buffer specifically for this kernel
                cmb.SetComputeBufferParam(m_CSBoxUtil, initKernel, Props.SplatOriginalPositions, m_GpuSplatOriginalPositions);
                
                m_CSBoxUtil.GetKernelThreadGroupSizes(initKernel, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, initKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
                Graphics.ExecuteCommandBuffer(cmb);
                
                if (m_DebugPhysics)
                    Debug.Log("Original positions initialized for wind restoration");
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Failed to initialize original positions: {e.Message}. Please reimport BoxUtil.compute");
            }
        }

        void InitializePhysics()
        {
            if (m_GpuSplatVelocities == null || m_GpuSplatPrevPositions == null) return;
            
            int kernelIndex = GetKernelIndex(KernelIndices.InitPhysics);
            if (kernelIndex < 0) 
            {
                Debug.LogWarning("InitPhysics kernel not found - skipping physics initialization");
                return;
            }
            
            try
            {
                if (m_DebugPhysics)
                    Debug.Log("InitializePhysics: Initializing physics buffers");
                
                // Clear velocity buffer to ensure it starts with zeros
                Vector3[] zeroVelocities = new Vector3[m_SplatCount];
                m_GpuSplatVelocities.SetData(zeroVelocities);
                
                using var cmb = new CommandBuffer { name = "InitPhysics" };
                
                if (m_DebugPhysics)
                    Debug.Log($"InitPhysics kernel index: {kernelIndex}");
                
                // Set the required buffers for physics initialization
                cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatVelocities, m_GpuSplatVelocities);
                cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPrevPositions, m_GpuSplatPrevPositions);
                cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPos, m_GpuPosData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatChunks, m_GpuChunks);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
                
                // Physics kernels don't need all the asset data, so dispatch directly
                m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
                Graphics.ExecuteCommandBuffer(cmb);
                
                if (m_DebugPhysics)
                    Debug.Log("InitializePhysics: Physics initialization completed");
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Failed to initialize physics: {e.Message}. Please reimport BoxUtil.compute");
            }
        }

        void DisposeResourcesForAsset()
        {
            DisposePagedLodResources();
            m_LodStreamer?.UnloadAll();
            DestroyImmediate(m_GpuColorData);

            DisposeBuffer(ref m_GpuPosData);
            DisposeBuffer(ref m_GpuOtherData);
            DisposeBuffer(ref m_GpuSHData);
            m_GpuSHDataContainsCoefficients = false;
            DisposeBuffer(ref m_GpuChunks);

            DisposeBuffer(ref m_GpuView);
            DisposeBuffer(ref m_GpuIndexBuffer);
            DisposeBuffer(ref m_GpuSortDistances);
            DisposeBuffer(ref m_GpuSortKeys);

            DisposeBuffer(ref m_GpuEditSelectedMouseDown);
            DisposeBuffer(ref m_GpuEditPosMouseDown);
            DisposeBuffer(ref m_GpuEditOtherMouseDown);
            DisposeBuffer(ref m_GpuEditSelected);
            DisposeBuffer(ref m_GpuEditTargetSelected);
            DisposeBuffer(ref m_GpuEditDeleted);
            DisposeBuffer(ref m_GpuEditCountsBounds);
            DisposeBuffer(ref m_GpuEditCutouts);
            DisposeBuffer(ref m_GpuEditSelectMinDepth);

            // Dispose physics buffers
            DisposeBuffer(ref m_GpuSplatVelocities);
            DisposeBuffer(ref m_GpuSplatPrevPositions);
            DisposeBuffer(ref m_GpuSphereColliders);
            DisposeBuffer(ref m_GpuSplatAnimFlags);
            DisposeBuffer(ref m_GpuSplatPersistentVelocities);
            
            // Dispose wind buffers
            DisposeBuffer(ref m_GpuWindBoxes);
            
            // Dispose attractor buffers
            DisposeBuffer(ref m_GpuAttractors);
            DisposeBuffer(ref m_GpuSplatOriginalPositions);
            DisposeBuffer(ref m_CloneCountBuffer);

            m_SorterArgs.resources.Dispose();

            m_SplatCount = 0;
            m_GpuChunksValid = false;

            editSelectedSplats = 0;
            editDeletedSplats = 0;
            editCutSplats = 0;
            editModified = false;
            editSelectedBounds = default;
        }

        public void OnDisable()
        {
#if UNITY_EDITOR
            // Remove editor update callback
            UnityEditor.EditorApplication.update -= EditorUpdate;
#endif

            DisposeResourcesForAsset();
            GaussianSplatRenderSystem.instance.UnregisterSplat(this);
            CleanupPaintBatchBuffers();

            DestroyImmediate(m_MatSplats);
            DestroyImmediate(m_MatComposite);
        }

        internal void CalcViewData(CommandBuffer cmb, Camera cam, Matrix4x4 matrix)
        {
            if (cam.cameraType == CameraType.Preview)
                return;

            var tr = transform;

            GaussianSplatRenderSystem.GetCameraViewProj(cam, out Matrix4x4 matView, out Matrix4x4 matProjRaw);
            Matrix4x4 matProj = GL.GetGPUProjectionMatrix(matProjRaw, true);
            Matrix4x4 matO2W = tr.localToWorldMatrix;
            Matrix4x4 matW2O = tr.worldToLocalMatrix;
            // Must match the bound splat RT size (eye texture * SplatRenderScale) so compute axis sizing
            // agrees with _ScreenParams during DrawProcedural.
            Vector4 screenPar = GaussianSplatRenderSystem.GetSplatScreenParams(cam);
            // Per-eye camera position (for view-dependent SH); falls back to head position in mono.
            Vector4 camPos = cam.stereoEnabled
                ? (Vector4)(Vector3)matView.inverse.GetColumn(3)
                : (Vector4)cam.transform.position;

            // Get the correct kernel index using our dictionary
            int kernelIndex = GetKernelIndex(KernelIndices.CalcViewData);
            if (kernelIndex < 0)
            {
                Debug.LogError("Failed to find CalcViewData kernel");
                return;
            }

            // calculate view dependent data for each splat
            SetAssetDataOnCS(cmb, KernelIndices.CalcViewData);

            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.SplatScale, m_SplatScale);
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.SplatOpacityScale, m_OpacityScale);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SHOrder, 3);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SHOnly, 0); // Fixed SH only off
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.AlbedoOnly, IsRelightShader(m_ShaderSplats) ? 1 : 0);

            // Distance culling parameters
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.EnableDistanceCulling, m_EnableDistanceCulling ? 1 : 0);
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.KillRadius, m_KillRadius);
            Vector3 cullOrigin = m_CullOrigin != null ? m_CullOrigin.position : cam.transform.position;
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.CullOrigin, cullOrigin);

            int viewCount = UsesPagedLod ? m_ActiveSplatCount : m_GpuView.count;
            if (viewCount <= 0)
                return;
            if (UsesPagedLod)
                SplatBoxLodDiagnostics.RecordViewCalc();

            try
            {
                uint gsX;
                m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out gsX, out _, out _);
                if (gsX <= 0)
                {
                    Debug.LogError($"Invalid thread group size: {gsX}");
                    return;
                }

                int dispatchSize = (viewCount + (int)gsX - 1) / (int)gsX;
                if (dispatchSize <= 0)
                    return;
                cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, dispatchSize, 1, 1);
            }
            catch (Exception e)
            {
                // Mark kernel as broken to prevent repeated errors
                if (m_KernelIndices != null)
                    m_KernelIndices[KernelIndices.CalcViewData] = -1;
                Debug.LogError($"Error in CalcViewData: {e.Message}");
            }
        }

#if UNITY_EDITOR
        EditorLodViewSignature CaptureEditorLodView(Camera cam)
        {
            var tr = cam.transform;
            return new EditorLodViewSignature
            {
                cameraId = cam.GetEntityId(),
                cameraPosition = tr.position,
                cameraRotation = tr.rotation,
                fieldOfView = cam.fieldOfView,
                orthographicSize = cam.orthographicSize,
                aspect = cam.aspect,
                nearClip = cam.nearClipPlane,
                farClip = cam.farClipPlane,
                pixelWidth = cam.pixelWidth,
                pixelHeight = cam.pixelHeight,
                localToWorld = transform.localToWorldMatrix,
                selectionRevision = m_LodSelectionRevision,
                splatScale = m_SplatScale,
                opacityScale = m_OpacityScale
            };
        }

        static bool SameEditorLodCameraAndObject(
            in EditorLodViewSignature a,
            in EditorLodViewSignature b)
        {
            return a.cameraId == b.cameraId &&
                   (a.cameraPosition - b.cameraPosition).sqrMagnitude < 1e-8f &&
                   Quaternion.Angle(a.cameraRotation, b.cameraRotation) < 0.01f &&
                   Mathf.Abs(a.fieldOfView - b.fieldOfView) < 1e-4f &&
                   Mathf.Abs(a.orthographicSize - b.orthographicSize) < 1e-4f &&
                   Mathf.Abs(a.aspect - b.aspect) < 1e-5f &&
                   Mathf.Abs(a.nearClip - b.nearClip) < 1e-5f &&
                   Mathf.Abs(a.farClip - b.farClip) < 1e-3f &&
                   a.pixelWidth == b.pixelWidth &&
                   a.pixelHeight == b.pixelHeight &&
                   a.localToWorld == b.localToWorld;
        }

        static bool SameEditorLodSortState(
            in EditorLodViewSignature a,
            in EditorLodViewSignature b) =>
            SameEditorLodCameraAndObject(a, b) &&
            a.selectionRevision == b.selectionRevision;

        static bool SameEditorLodCalculatedState(
            in EditorLodViewSignature a,
            in EditorLodViewSignature b) =>
            SameEditorLodSortState(a, b) &&
            Mathf.Abs(a.splatScale - b.splatScale) < 1e-5f &&
            Mathf.Abs(a.opacityScale - b.opacityScale) < 1e-5f;

        /// <summary>
        /// Covariance projection and SH evaluation are the dominant editor cost for large paged
        /// selections. Their output remains valid while camera, object, selection and appearance are
        /// unchanged, so retain the GPU view buffer instead of regenerating it every repaint.
        /// </summary>
        internal bool ShouldCalculateEditorLodView(Camera cam)
        {
            if (Application.isPlaying || !UsesPagedLod || cam == null)
                return true;

            EditorLodViewSignature current = CaptureEditorLodView(cam);
            if (m_HasEditorLodCalculatedView &&
                SameEditorLodCalculatedState(current, m_LastEditorLodCalculatedView))
                return false;

            m_LastEditorLodCalculatedView = current;
            m_HasEditorLodCalculatedView = true;
            return true;
        }

        /// <summary>
        /// Sorts a paged LoD selection at the right moments in the editor. A fresh selection must
        /// sort in the same frame: its keys were just reset to identity, and identity order
        /// mis-composites the entire scene — the larger the budget, the more it reads as the scene
        /// flashing down to low detail. (The old behaviour of waiting for streaming to go quiet is
        /// what made the view pulse once a second while pages streamed.) Pure camera motion keeps
        /// the previous order, which stays approximately correct, and re-sorts once settled.
        /// </summary>
        bool ShouldSortEditorPagedLod(Camera cam)
        {
            EditorLodViewSignature current = CaptureEditorLodView(cam);
            double now = EditorApplication.timeSinceStartup;

            if (!m_HasEditorLodSortObservation)
            {
                m_LastEditorLodSortObservation = current;
                m_LastEditorLodSortMotionTime = now;
                m_HasEditorLodSortObservation = true;
                // First observation used to return false, which left a freshly reset identity
                // order on screen until the next selection change.
                m_LastEditorLodSortedView = current;
                m_HasEditorLodSortedView = true;
                return true;
            }

            if (!SameEditorLodCameraAndObject(current, m_LastEditorLodSortObservation))
                m_LastEditorLodSortMotionTime = now;
            m_LastEditorLodSortObservation = current;

            if (m_HasEditorLodSortedView &&
                SameEditorLodSortState(current, m_LastEditorLodSortedView))
                return false;

            // New selection: sort now. Identity keys were just written and must not be drawn.
            if (!m_HasEditorLodSortedView ||
                current.selectionRevision != m_LastEditorLodSortedView.selectionRevision)
            {
                m_LastEditorLodSortedView = current;
                m_HasEditorLodSortedView = true;
                return true;
            }

            // Same selection, moving view: keep the previous order through the drag and re-sort
            // once settled. Selection itself is also frozen while moving, so this only covers the
            // post-settle camera tweak with an unchanged splat list.
            const double kSettleSeconds = 0.2;
            if (now - m_LastEditorLodSortMotionTime < kSettleSeconds)
                return false;

            m_LastEditorLodSortedView = current;
            m_HasEditorLodSortedView = true;
            return true;
        }
#else
        internal bool ShouldCalculateEditorLodView(Camera cam) => true;
#endif

        /// <summary>
        /// Returns true at most once per (frame, camera). Multi-pass VR renders the same Camera twice per
        /// frame (one pass per eye); the second eye reuses the order computed for the first, which halves
        /// sort cost. Different Camera instances (e.g. Scene vs Game view) each get their own sort so their
        /// orders stay correct. Also honors m_SortNthFrame as a per-camera frame interval.
        /// </summary>
        internal bool ShouldSortThisFrame(Camera cam)
        {
            int interval = Mathf.Max(1, m_SortNthFrame);
#if UNITY_EDITOR
            if (!Application.isPlaying && UsesPagedLod)
            {
                // The sort keys are one global permutation. Only the camera driving LoD selection
                // re-sorts them; if every editor camera (Game view, previews) sorted for its own
                // view, alternating repaints would flip the draw order back and forth and each
                // view would shimmer. Non-driver cameras draw the existing order, which is stable.
                if (UnityEditor.SceneView.lastActiveSceneView != null &&
                    cam != UnityEditor.SceneView.lastActiveSceneView.camera)
                    return false;
                return ShouldSortEditorPagedLod(cam);
            }
#endif
            if (ShouldUseMobileStableSort())
                return ShouldRefreshMobileStableSort(cam, interval);

            // Paged LoD play: keep sorting on the normal interval while moving. Hard-skipping
            // sorts during motion then sorting on settle caused FPS sawtooth / camera stutter.
            // Prefer raising Sort Interval (2–3) over freezing sorts.
            if (Application.isPlaying && UsesPagedLod)
                interval = Mathf.Max(interval, 2);

            // Default: sort on every render. In multi-pass VR each eye then sorts with its OWN view
            // matrix, so each eye's back-to-front transparency order is correct (no per-eye shimmer).
            // m_FrameCounter is incremented by the caller immediately after this call, so this matches
            // the original "m_FrameCounter % m_SortNthFrame == 0" gate.
            if (!m_ReuseSortAcrossEyes)
                return (m_FrameCounter % interval) == 0;

            // Opt-in: reuse one sort across both stereo eyes. Multi-pass VR renders the same Camera twice;
            // the second eye reuses the first eye's order. Saves ~half the sort cost but each eye's order
            // is only approximate, which can shimmer slightly in VR.
            int frame = Time.frameCount;
            EntityId camId = cam != null ? cam.GetEntityId() : EntityId.None;
            if (m_LastSortFrame == frame && m_LastSortCamId == camId)
                return false;

            m_LastSortFrame = frame;
            m_LastSortCamId = camId;
            bool due = (m_SortIntervalTick % interval) == 0;
            m_SortIntervalTick++;
            return due;
        }

        bool ShouldUseMobileStableSort()
        {
            if (!m_StableSortWhileRotatingOnMobile)
                return false;

            if (m_EnablePhysics || m_EnableWind)
                return false;

            return Application.platform == RuntimePlatform.Android || SystemInfo.graphicsDeviceType == GraphicsDeviceType.Vulkan;
        }

        bool ShouldRefreshMobileStableSort(Camera cam, int interval)
        {
            // Avoid per-eye duplicate sorts in VR. Camera.transform.position is the XR head-center position,
            // so pure head rotation does not cause sort reshuffling. While walking, sort every frame so
            // the order changes smoothly instead of popping in large threshold-sized steps.
            int frame = Time.frameCount;
            EntityId camId = cam != null ? cam.GetEntityId() : EntityId.None;
            if (m_LastSortFrame == frame && m_LastSortCamId == camId)
                return false;

            Vector3 camPos = cam != null ? cam.transform.position : Vector3.zero;
            Quaternion camRot = cam != null ? cam.transform.rotation : Quaternion.identity;
            float movingThreshold = Mathf.Max(0.0005f, m_MobileSortMovingThreshold);

            // In VR the head pivots around the neck/spine, so a pure head turn still translates the tracked
            // camera point by a few mm-cm. Treating that as "walking" re-arms the every-frame sort and brings
            // back the rotation flicker. Detect rotation and, while the head is mostly just turning, require a
            // much larger translation before we call it movement. The camera-distance sort key is rotation-
            // invariant, so freezing the order through a turn stays correct.
            float rotationDeltaDeg = !m_HasMobileStableFrameRotation
                ? 0f
                : Quaternion.Angle(camRot, m_LastMobileStableFrameRotation);
            const float kRotatingDegPerFrame = 0.25f; // above this the frame is dominated by a head turn
            const float kRotatingMoveMultiplier = 6f;  // how much more translation a turn needs to count as walking
            bool rotatingThisFrame = rotationDeltaDeg >= kRotatingDegPerFrame;
            float effectiveMoveThreshold = rotatingThisFrame
                ? movingThreshold * kRotatingMoveMultiplier
                : movingThreshold;

            bool movingThisFrame = !m_HasMobileStableFramePosition ||
                (camPos - m_LastMobileStableFramePosition).sqrMagnitude >= effectiveMoveThreshold * effectiveMoveThreshold;

            m_HasMobileStableFramePosition = true;
            m_LastMobileStableFramePosition = camPos;
            m_HasMobileStableFrameRotation = true;
            m_LastMobileStableFrameRotation = camRot;

            // A new paged LoD selection just reset the draw order to identity; re-sort immediately
            // instead of waiting for the head to move, or the scene stays mis-composited through
            // every streaming update while the user only looks around.
            if (UsesPagedLod && m_LastMobileSortedSelectionRevision != m_LodSelectionRevision)
            {
                m_LastMobileSortedSelectionRevision = m_LodSelectionRevision;
                m_HasMobileStableSortPosition = true;
                m_LastMobileStableSortPosition = camPos;
                m_LastSortFrame = frame;
                m_LastSortCamId = camId;
                m_SortIntervalTick++;
                return true;
            }

            bool intervalDue = (m_SortIntervalTick % interval) == 0;
            if (movingThisFrame)
                m_MobileMovingSortFramesLeft = 6;

            if (m_MobileMovingSortFramesLeft > 0)
            {
                m_MobileMovingSortFramesLeft--;
                if (!intervalDue)
                {
                    m_SortIntervalTick++;
                    return false;
                }

                m_HasMobileStableSortPosition = true;
                m_LastMobileStableSortPosition = camPos;
                m_LastSortFrame = frame;
                m_LastSortCamId = camId;
                m_LastMobileSortedSelectionRevision = m_LodSelectionRevision;
                m_SortIntervalTick++;
                return true;
            }

            float threshold = Mathf.Max(0.001f, m_MobileSortMoveThreshold);
            bool driftedEnough = !m_HasMobileStableSortPosition ||
                (camPos - m_LastMobileStableSortPosition).sqrMagnitude >= threshold * threshold;

            if (!driftedEnough || !intervalDue)
            {
                m_SortIntervalTick++;
                return false;
            }

            m_HasMobileStableSortPosition = true;
            m_LastMobileStableSortPosition = camPos;
            m_LastSortFrame = frame;
            m_LastSortCamId = camId;
            m_LastMobileSortedSelectionRevision = m_LodSelectionRevision;
            m_SortIntervalTick++;
            return true;
        }

internal void SortPoints(CommandBuffer cmd, Camera cam, Matrix4x4 matrix)
{
    if (cam.cameraType == CameraType.Preview)
        return;

    // Validate compute shader
    if (m_CSBoxUtil == null)
    {
        Debug.LogError("Compute shader is null");
        return;
    }

    GaussianSplatRenderSystem.GetCameraViewProj(cam, out Matrix4x4 worldToCamMatrix, out _);
    Vector4 camPos = cam.stereoEnabled
        ? (Vector4)(Vector3)worldToCamMatrix.inverse.GetColumn(3)
        : (Vector4)cam.transform.position;
    worldToCamMatrix.m20 *= -1;
    worldToCamMatrix.m21 *= -1;
    worldToCamMatrix.m22 *= -1;

    // calculate distance to the camera for each splat
    cmd.BeginSample(s_ProfSort);

    int sortCount = UsesPagedLod ? m_ActiveSplatCount : m_SplatCount;
    if (sortCount <= 0)
    {
        cmd.EndSample(s_ProfSort);
        return;
    }
    if (UsesPagedLod)
        SplatBoxLodDiagnostics.RecordSort();
    m_SorterArgs.count = (uint)sortCount;
    
    // Get the correct kernel index using our dictionary
    int calcDistancesKernel = GetKernelIndex(KernelIndices.CalcDistances);
    if (calcDistancesKernel < 0)
    {
        Debug.LogError($"Failed to find CalcDistances kernel");
        return;
    }

    try
    {
        // Validate buffers before setting them
        if (m_GpuSortDistances == null)
        {
            Debug.LogError("Sort distances buffer is null");
            return;
        }
        if (m_GpuSortKeys == null)
        {
            Debug.LogError("Sort keys buffer is null");
            return;
        }
        if (m_GpuPosData == null && !UsesPagedLod)
        {
            Debug.LogError("Position data buffer is null");
            return;
        }

        GetSplatComputeBindings(out var sortPosBuf, out _, out _, out _,
            out var sortChunkBuf, out var sortChunkCount, out var sortRemapBuf, out var sortUseRemap);

        if (sortPosBuf == null)
        {
            Debug.LogError("Position data buffer is null");
            return;
        }

        cmd.SetComputeBufferParam(m_CSBoxUtil, calcDistancesKernel, Props.SplatSortDistances, m_GpuSortDistances);
        cmd.SetComputeBufferParam(m_CSBoxUtil, calcDistancesKernel, Props.SplatSortKeys, m_GpuSortKeys);
        cmd.SetComputeBufferParam(m_CSBoxUtil, calcDistancesKernel, Props.SplatChunks, sortChunkBuf);
        cmd.SetComputeBufferParam(m_CSBoxUtil, calcDistancesKernel, Props.SplatPos, sortPosBuf);
        cmd.SetComputeIntParam(m_CSBoxUtil, Props.UseSplatIndexRemap, sortUseRemap);
        cmd.SetComputeBufferParam(m_CSBoxUtil, calcDistancesKernel, Props.SplatIndexRemap, sortRemapBuf);
        cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
        cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, worldToCamMatrix * matrix);
        cmd.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matrix);
        cmd.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);
        cmd.SetComputeIntParam(m_CSBoxUtil, Props.SortByCameraDistance,
            m_SortByCameraDistanceOnMobile && Application.platform == RuntimePlatform.Android ? 1 : 0);

        // Fast 16-bit sort (mobile only): a quantized depth key in the low 16 bits lets the radix sorter
        // run 2 passes instead of 4, halving the sort cost. Desktop always uses the full 32-bit float
        // key (4 passes), so its behavior is unchanged.
        bool isAndroid = Application.platform == RuntimePlatform.Android;
        bool fastSort16 = m_FastSort16BitOnMobile && isAndroid;

        // Deterministic composite-key sort (mobile only): pack quantized depth + index so equal-depth
        // splats can never swap order between frames. This is redundant with a correct sorter - LSD radix
        // is stable, and CSCalcDistances re-seeds the payloads to identity every frame, so ties already
        // resolve the same way every time. It also forces the full 32-bit key, so 16-bit takes priority.
        bool stableSort = !fastSort16 && m_StableDeterministicSortOnMobile && isAndroid;
        cmd.SetComputeIntParam(m_CSBoxUtil, Props.StableSort, stableSort ? 1 : 0);
        cmd.SetComputeIntParam(m_CSBoxUtil, Props.SortKeyBits, fastSort16 ? 16 : 32);
        m_SorterArgs.keyBits = fastSort16 ? 16 : 32;

        // Both quantized paths (stable composite key and 16-bit depth key) map metric camera depth into
        // [0,1] via _SortDepthScale before quantizing, so compute the shared depth range once.
        if (stableSort || fastSort16)
        {
            float maxDist = Mathf.Max(0.01f, m_StableSortMaxDistance);
            if (m_AutoStableSortDepth && (m_Asset != null || m_PagedScene != null))
            {
                // Fit the depth range to the cloud's actual world-space diagonal so the quantization
                // buckets span exactly the splats that exist (object bounds -> world via the render matrix,
                // which carries this transform's scale/rotation). Distance-from-camera ranges roughly
                // [0, diagonal] when the head is inside/near the cloud, so this maximizes bucket precision.
                Vector3 boundsSize = UsesPagedLod
                    ? m_PagedScene.worldBoundsMax - m_PagedScene.worldBoundsMin
                    : asset.boundsMax - asset.boundsMin;
                Vector3 worldSize = matrix.MultiplyVector(boundsSize);
                float diagonal = worldSize.magnitude;
                if (diagonal > 0.01f)
                    maxDist = diagonal;
            }
            cmd.SetComputeFloatParam(m_CSBoxUtil, Props.SortDepthScale, 1f / maxDist);

            if (stableSort)
            {
                // Reserve just enough low bits to hold every splat index uniquely; the rest encode depth.
                int indexBits = 1;
                while (indexBits < 31 && (1 << indexBits) < sortCount)
                    indexBits++;
                indexBits = Mathf.Clamp(indexBits, 1, 27); // keep >=5 depth bits even for huge clouds
                cmd.SetComputeIntParam(m_CSBoxUtil, Props.SortIndexBits, indexBits);
            }
        }

        cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, sortCount);
        cmd.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, sortChunkCount);
        
        // Default thread group size
        uint gsX = 64; 
        bool threadSizeValid = false;

        try
        {
            m_CSBoxUtil.GetKernelThreadGroupSizes(calcDistancesKernel, out gsX, out _, out _);
            threadSizeValid = gsX > 0;
            
            if (!threadSizeValid)
            {
                Debug.LogWarning($"Invalid thread group size: {gsX}, using default size of 64");
                gsX = 64;
            }
            else
            {
               // Debug.Log($"Thread group size: {gsX}"); // Debug log to see the actual size
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning($"Failed to get kernel thread group sizes: {e.Message}. Using default size of 64.");
            gsX = 64;
        }

        // Log values before calculation
       // Debug.Log($"Buffer count: {m_GpuSortDistances.count}, Thread group size: {gsX}");

        // Ensure we have valid values before calculation
        if (m_GpuSortDistances.count <= 0)
        {
            Debug.LogError($"Invalid buffer count: {m_GpuSortDistances.count}");
            return;
        }

        if (gsX <= 0)
        {
            Debug.LogError($"Invalid thread group size: {gsX}");
            return;
        }

        // Calculate dispatch size with additional safety checks
        int numerator = sortCount + (int)gsX - 1;
        int denominator = (int)gsX;

        if (denominator <= 0)
        {
            Debug.LogError($"Division by zero prevented. Denominator: {denominator}");
            return;
        }

        int dispatchSize = Mathf.Max(1, numerator / denominator);
        //Debug.Log($"Dispatch size calculated: {dispatchSize}"); // Debug log to see the final dispatch size

        cmd.DispatchCompute(m_CSBoxUtil, calcDistancesKernel, dispatchSize, 1, 1);

        bool bypassRadixSort = ShouldBypassGpuRadixSort();

        if (bypassRadixSort && !s_LoggedSortBypass)
        {
            s_LoggedSortBypass = true;
            Debug.LogWarning(
                "[SplatBox] GPU radix sort bypassed by Disable Gpu Radix Sort On Mobile. Splats draw in identity " +
                "order, so transparency will be wrong. Turn the option off to restore depth sorting.");
        }

        // sort the splats. CSCalcDistances above always re-seeds _SplatSortKeys to identity first, so when
        // bypassing the wave radix sorter we get a stable no-sort order instead of potentially corrupt payloads.
        if (!bypassRadixSort && m_Sorter != null && m_Sorter.Valid)
        {
            // InitSortBuffers skips the sorter's scratch buffers while the bypass toggle is on, so allocate
            // them here if the toggle was switched off after this renderer initialized.
            if (!m_SorterArgs.resources.Valid && m_SorterArgs.count > 0)
                m_SorterArgs.resources = GpuSorting.SupportResources.Load(m_SorterArgs.count);

            if (m_SorterArgs.resources.Valid)
                m_Sorter.Dispatch(cmd, m_SorterArgs);
        }
        else if (!bypassRadixSort && !s_LoggedSorterUnavailable)
        {
            s_LoggedSorterUnavailable = true;
            var sortCS = m_CSBoxUtilSort != null ? m_CSBoxUtilSort : m_CSBoxUtil;
            if (sortCS == null || sortCS == m_CSBoxUtil)
            {
                Debug.LogWarning(
                    "GPU radix sorter unavailable: BoxUtilSort.compute was not found, so splats render unsorted. " +
                    "Reimport the package shaders (Assets > Reimport) and check that BoxUtilSort.compute is in the project.");
            }
            else
            {
                Debug.LogWarning(
                    $"GPU radix sorter unavailable on {SystemInfo.graphicsDeviceType}: BoxUtilSort.compute needs SM6 wave " +
                    "intrinsics, which only Direct3D12, Vulkan and Metal provide. Splats will render unsorted (wrong blend " +
                    "order). Set Project Settings > Player > Other Settings > Graphics APIs to Direct3D12 or Vulkan and " +
                    "restart the editor.");
            }
        }
    }
    catch (Exception e)
    {
        Debug.LogError($"Error in SortPoints: {e.Message}\n{e.StackTrace}");
    }
    finally
    {
        cmd.EndSample(s_ProfSort);
    }
}



        public void Update()
        {
            if (UsesPagedLod)
            {
                if (m_PrevPagedScene != m_PagedScene)
                {
                    m_PrevPagedScene = m_PagedScene;
                    m_PrevAsset = null;
                    m_PrevHash = default;
                    DisposeResourcesForAsset();
                    CreateResourcesForAsset();
                }
            }
            else
            {
                m_PrevPagedScene = null;
                var curHash = m_Asset ? asset.dataHash : new Hash128();
                if (m_PrevAsset != m_Asset || m_PrevHash != curHash)
                {
                    m_PrevAsset = m_Asset;
                    m_PrevHash = curHash;
                    DisposeResourcesForAsset();
                    CreateResourcesForAsset();
                }
            }

            // Attractors and physics colliders are handled by Runtime components
            // They register themselves and call into the renderer as needed
            
            // Update physics (works in both play mode and edit mode)
            // Only run if physics is enabled AND we have the physics buffers
            if (m_EnablePhysics && HasValidAsset && HasValidRenderSetup && m_GpuSplatVelocities != null)
            {
                if (m_DebugPhysics && m_FrameCounter % 60 == 0) // Log every 60 frames to avoid spam
                {
                    Debug.Log($"Physics Update: Frame {m_FrameCounter}, Splats: {m_SplatCount}");
                }
                UpdatePhysics();
            }
            else if (m_DebugPhysics && m_FrameCounter % 120 == 0)
            {
                Debug.Log($"Physics SKIPPED - EnablePhysics: {m_EnablePhysics}, ValidAsset: {HasValidAsset}, ValidRender: {HasValidRenderSetup}, VelocityBuffer: {m_GpuSplatVelocities != null}");
            }

            // Update wind effects - run every frame for continuous effect
            if (m_EnableWind && HasValidAsset && HasValidRenderSetup && m_GpuSplatVelocities != null)
            {
                // Apply wind forces every frame for continuous effect
                if (m_FrameCounter % m_WindUpdateEveryNthFrame == 0)
                {
                    if (m_DebugPhysics)
                    {
                        Debug.Log($"Wind Update: Frame {m_FrameCounter}");
                    }
                    UpdateWindEffects();
                }
            }
            else
            {
                // Debug why wind effects are not running
                if (m_DebugPhysics && m_EnableWind && m_FrameCounter % 60 == 0)
                {
                    Debug.Log($"Wind effects NOT running - EnableWind: {m_EnableWind}, ValidAsset: {HasValidAsset}, ValidRenderSetup: {HasValidRenderSetup}, VelocityBuffer: {m_GpuSplatVelocities != null}");
                }
            }

            // Perform automatic distance culling
            if (m_AutoDistanceCull && m_EnableDistanceCulling && m_FrameCounter % m_CullEveryNthFrame == 0)
            {
                PerformDistanceCulling();
            }
        }

#if UNITY_EDITOR
        void EditorUpdate()
        {
            // Only update in edit mode, not play mode (to avoid double updates)
            if (Application.isPlaying)
                return;

            // Do not gate on HasValidRenderSetup alone: a cold edit-mode enable can leave the
            // streamer ready before every shared buffer flag is true, and skipping the tick here
            // was why pages only appeared after a Play mode bounce.
            if (UsesPagedLod && m_CSBoxUtil != null)
                EditorTickPagedLodStreaming();

            if (m_EnablePhysics && HasValidAsset && HasValidRenderSetup)
            {
                UpdatePhysics();
                // Repaint scene view to show physics updates
                UnityEditor.SceneView.RepaintAll();
            }
        }
#endif

        void UpdatePhysics()
        {
            // Don't run physics if not enabled or buffers don't exist
            if (!m_EnablePhysics || m_GpuSplatVelocities == null || m_GpuSplatPrevPositions == null) 
            {
                if (m_DebugPhysics && m_EnablePhysics)
                    Debug.Log("Physics enabled but buffers not available");
                return;
            }
            
            try
            {
                UpdatePhysicsInternal();
            }
            catch (System.Exception e)
            {
                if (m_DebugPhysics)
                    Debug.LogWarning($"Physics update failed: {e.Message}");
            }
        }
        
        // Ensures the per-splat animation-flags buffer exists (each bit: 0 = gravity enabled, the default).
        // The physics kernels (CSUpdatePhysics / CSUpdateWindPhysics / CSApplyCollisions) always read
        // _SplatAnimFlags, so it must be bound even before any velocity painting has allocated it, otherwise
        // Unity logs "Property (_SplatAnimFlags) at kernel index (N) is not set" and the kernel reads garbage.
        void EnsureAnimFlagsBuffer()
        {
            if (m_GpuSplatAnimFlags != null || m_SplatCount <= 0)
                return;
            int flagWordCount = (m_SplatCount + 31) / 32;
            m_GpuSplatAnimFlags = new GraphicsBuffer(GraphicsBuffer.Target.Raw, flagWordCount, 4) { name = "SplatAnimFlags" };
            m_GpuSplatAnimFlags.SetData(new uint[flagWordCount]); // zero = all splats have gravity
        }

        void UpdatePhysicsInternal()
        {
            // Physics collider components update themselves via public API
            
            // Check if there are active sphere colliders (tracked via m_ActiveSphereColliderCount)
            int activeColliders = m_ActiveSphereColliderCount;
            
            if (m_DebugPhysics)
                Debug.Log($"Physics Update: {activeColliders} active sphere colliders");
            
            // Only run sphere physics if there are active colliders
            if (activeColliders == 0)
            {
                if (m_DebugPhysics)
                    Debug.Log("Physics Update: No active sphere colliders, skipping sphere physics");
                
                // Still run the physics integration kernel for wind effects
                int windPhysicsKernel = GetKernelIndex(KernelIndices.UpdatePhysics);
                if (windPhysicsKernel >= 0)
                {
                    if (!TryGetKernelThreadGroupSize(windPhysicsKernel, out uint gsX, KernelIndices.UpdatePhysics))
                        return;
                        
                    using var windCmb = new CommandBuffer { name = "UpdateWindPhysics" };
                    
                    // Set required buffers for physics update (wind velocity integration)
                    windCmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatPos, m_GpuPosData);
                    windCmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatChunks, m_GpuChunks);
                    windCmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                    windCmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatPrevPositions, m_GpuSplatPrevPositions);
                    EnsureAnimFlagsBuffer();
                    windCmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatAnimFlags, m_GpuSplatAnimFlags);
                    windCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                    windCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
                    windCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
                    
                    // Use fixed delta time in editor mode for consistent behavior
                    float deltaTime = Time.deltaTime;
#if UNITY_EDITOR
                    if (!Application.isPlaying)
                        deltaTime = 0.016f; // ~60fps for smooth editor updates
#endif
                    windCmb.SetComputeFloatParam(m_CSBoxUtil, Props.DeltaTime, deltaTime);
                    // Use dedicated wind physics settings instead of sphere physics settings
                    windCmb.SetComputeFloatParam(m_CSBoxUtil, Props.Gravity, m_WindGravity);
                    windCmb.SetComputeFloatParam(m_CSBoxUtil, Props.Damping, m_WindDamping);
                    windCmb.SetComputeFloatParam(m_CSBoxUtil, Props.MinVelocity, m_WindMinVelocity);
                    
                    windCmb.DispatchCompute(m_CSBoxUtil, windPhysicsKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
                    
                    // Apply persistent velocities for continuous animation
                    int persistKernel = GetKernelIndex(KernelIndices.ApplyPersistentVelocities);
                    if (persistKernel >= 0 && m_GpuSplatPersistentVelocities != null && m_GpuSplatVelocities != null)
                    {
                        if (TryGetKernelThreadGroupSize(persistKernel, out uint persistGsX, KernelIndices.ApplyPersistentVelocities))
                        {
                            windCmb.SetComputeBufferParam(m_CSBoxUtil, persistKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                            windCmb.SetComputeBufferParam(m_CSBoxUtil, persistKernel, Props.SplatPersistentVelocities, m_GpuSplatPersistentVelocities);
                            windCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                            windCmb.DispatchCompute(m_CSBoxUtil, persistKernel, (m_SplatCount + (int)persistGsX - 1) / (int)persistGsX, 1, 1);
                        }
                    }
                    
                    Graphics.ExecuteCommandBuffer(windCmb);
                }
                return; // No sphere colliders, but still integrated wind velocities
            }
            
            using var cmb = new CommandBuffer { name = "UpdatePhysics" };
            
            // First apply collisions
            int collisionKernel = GetKernelIndex(KernelIndices.ApplyCollisions);
            if (collisionKernel >= 0)
            {
                // Set required buffers for collision detection
                cmb.SetComputeBufferParam(m_CSBoxUtil, collisionKernel, Props.SplatPos, m_GpuPosData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, collisionKernel, Props.SplatChunks, m_GpuChunks);
                cmb.SetComputeBufferParam(m_CSBoxUtil, collisionKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                cmb.SetComputeBufferParam(m_CSBoxUtil, collisionKernel, Props.SplatPrevPositions, m_GpuSplatPrevPositions);
                cmb.SetComputeBufferParam(m_CSBoxUtil, collisionKernel, Props.SphereColliders, m_GpuSphereColliders);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SphereColliderCount, m_ActiveSphereColliderCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.SplatMass, m_SplatMass);
                
                // Add transform matrices for coordinate space conversion
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, transform.worldToLocalMatrix);
                // Use editor-friendly time
                float currentTime = Time.time;
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    currentTime = (float)UnityEditor.EditorApplication.timeSinceStartup;
#endif
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.Time, currentTime);
                
                m_CSBoxUtil.GetKernelThreadGroupSizes(collisionKernel, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, collisionKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
            }
            
            // Then update physics (velocity integration)
            int physicsKernel = GetKernelIndex(KernelIndices.UpdatePhysics);
            if (physicsKernel >= 0)
            {
                // Set required buffers for physics update
                cmb.SetComputeBufferParam(m_CSBoxUtil, physicsKernel, Props.SplatPos, m_GpuPosData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, physicsKernel, Props.SplatChunks, m_GpuChunks);
                cmb.SetComputeBufferParam(m_CSBoxUtil, physicsKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                cmb.SetComputeBufferParam(m_CSBoxUtil, physicsKernel, Props.SplatPrevPositions, m_GpuSplatPrevPositions);
                EnsureAnimFlagsBuffer();
                cmb.SetComputeBufferParam(m_CSBoxUtil, physicsKernel, Props.SplatAnimFlags, m_GpuSplatAnimFlags);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
                
                // Use fixed delta time in editor mode for consistent behavior
                float deltaTime = Time.deltaTime;
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    deltaTime = 0.016f; // ~60fps for smooth editor updates
#endif
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.DeltaTime, deltaTime);
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.Gravity, m_Gravity);
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.Damping, m_Damping);
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.MinVelocity, m_MinVelocity);
                
                m_CSBoxUtil.GetKernelThreadGroupSizes(physicsKernel, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, physicsKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
                
                // Apply persistent velocities for continuous animation
                int persistKernel = GetKernelIndex(KernelIndices.ApplyPersistentVelocities);
                if (persistKernel >= 0 && m_GpuSplatPersistentVelocities != null && m_GpuSplatVelocities != null)
                {
                    cmb.SetComputeBufferParam(m_CSBoxUtil, persistKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                    cmb.SetComputeBufferParam(m_CSBoxUtil, persistKernel, Props.SplatPersistentVelocities, m_GpuSplatPersistentVelocities);
                    cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                    m_CSBoxUtil.GetKernelThreadGroupSizes(persistKernel, out uint persistGsX, out _, out _);
                    cmb.DispatchCompute(m_CSBoxUtil, persistKernel, (m_SplatCount + (int)persistGsX - 1) / (int)persistGsX, 1, 1);
                }
            }
            
            Graphics.ExecuteCommandBuffer(cmb);
        }

        void UpdateWindEffects()
        {
            // Debug logging to help troubleshoot
            if (m_DebugPhysics)
            {
                Debug.Log($"Wind Update Check - EnableWind: {m_EnableWind}, VelocityBuffer: {m_GpuSplatVelocities != null}, WindBuffer: {m_GpuWindBoxes != null}");
            }

            // Create wind buffers if wind is enabled but buffers don't exist
            if (m_EnableWind && (m_GpuSplatVelocities == null || m_GpuWindBoxes == null))
            {
                if (m_GpuWindBoxes == null)
                    CreateWindBuffers();
                if (m_GpuSplatVelocities == null)
                    CreatePhysicsBuffers();
            }

            // Ensure original positions buffer exists for restoration when attractors are present
            if (m_GpuSplatOriginalPositions == null && m_SplatCount > 0 && m_ActiveAttractorCount > 0)
            {
                m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
                InitializeOriginalPositions();
            }

            // Don't run wind if not enabled or physics buffers don't exist
            if (!m_EnableWind || m_GpuSplatVelocities == null || m_GpuWindBoxes == null)
            {
                if (m_DebugPhysics)
                    Debug.Log("Wind effects skipped - requirements not met");
                return;
            }
            
            // Wind boxes and attractors update themselves via public API
            
            // Create attractor buffers if needed (always create when wind is enabled, even if empty)
            if (m_GpuAttractors == null)
            {
                CreateAttractorBuffers();
            }
            
            // Only run wind if there are active wind boxes or attractors
            int activeWindBoxes = m_ActiveWindBoxCount;
            int activeAttractors = m_ActiveAttractorCount;
            if (m_DebugPhysics)
            {
                Debug.Log($"Active wind boxes: {activeWindBoxes}, Active attractors: {activeAttractors}");
                Debug.Log($"Wind enabled: {m_EnableWind}, Attractor buffer exists: {m_GpuAttractors != null}");
            }
            
            if (activeWindBoxes == 0 && activeAttractors == 0)
            {
                if (m_DebugPhysics)
                    Debug.Log("No active wind boxes or attractors found");
                return; // No wind boxes or attractors = no updates needed
            }
            
            using var cmb = new CommandBuffer { name = "UpdateWind" };
            
            int windKernel = GetKernelIndex(KernelIndices.ApplyWindForces);
            if (windKernel >= 0)
            {
                if (m_DebugPhysics)
                    Debug.Log($"Executing wind kernel with {activeWindBoxes} wind boxes affecting {m_SplatCount} splats");

                // Set required buffers for wind effects
                cmb.SetComputeBufferParam(m_CSBoxUtil, windKernel, Props.SplatPos, m_GpuPosData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, windKernel, Props.SplatChunks, m_GpuChunks);
                cmb.SetComputeBufferParam(m_CSBoxUtil, windKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                cmb.SetComputeBufferParam(m_CSBoxUtil, windKernel, Props.WindBoxes, m_GpuWindBoxes);
                cmb.SetComputeBufferParam(m_CSBoxUtil, windKernel, Props.SplatOriginalPositions, m_GpuSplatOriginalPositions);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.WindBoxCount, activeWindBoxes);
                
                // Set attractor data - always set buffer (required by compute shader), even if empty
                if (activeAttractors > 0 && m_GpuAttractors != null)
                {
                    UpdateAttractorData();
                }
                // Always set the attractor buffer (compute shader requires it)
                if (m_GpuAttractors != null)
                {
                    cmb.SetComputeBufferParam(m_CSBoxUtil, windKernel, Props.Attractors, m_GpuAttractors);
                    cmb.SetComputeIntParam(m_CSBoxUtil, Props.AttractorCount, activeAttractors);
                    if (m_DebugPhysics)
                    {
                        Debug.Log($"Setting {activeAttractors} attractors for wind kernel");
                        Debug.Log($"Wind kernel dispatch size: {m_SplatCount} splats, thread groups: {(m_SplatCount + 1023) / 1024}");
                    }
                }
                else
                {
                    cmb.SetComputeIntParam(m_CSBoxUtil, Props.AttractorCount, 0);
                    if (m_DebugPhysics)
                        Debug.Log("No attractors to set for wind kernel");
                }
                
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
                
                // Add transform matrices for coordinate space conversion
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, transform.worldToLocalMatrix);
                
                // Use editor-friendly time for wind animation
                float currentTime = Time.time;
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    currentTime = (float)UnityEditor.EditorApplication.timeSinceStartup;
#endif
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.WindTime, currentTime);
                
                m_CSBoxUtil.GetKernelThreadGroupSizes(windKernel, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, windKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
            }
            else
            {
                Debug.LogError("Wind kernel not found!");
            }
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            // After applying wind forces, run direct restoration for splats outside wind boxes
            RunDirectRestoration();
        }
        
        void UpdateAttractorData()
        {
            // Attractors now update via public API: SetAttractorData()
        }
        
        /// <summary>
        /// Set attractor data from external components. Called by GaussianSplatAttractor.
        /// </summary>
        public void SetAttractorData(AttractorData[] attractorData)
        {
            if (attractorData == null || attractorData.Length == 0)
            {
                m_ActiveAttractorCount = 0;
                return;
            }
            
            m_ActiveAttractorCount = attractorData.Length;
            
            if (m_GpuAttractors == null)
                CreateAttractorBuffers();
            
            // Resize buffer if needed
            if (attractorData.Length > m_GpuAttractors.count)
            {
                m_GpuAttractors?.Dispose();
                int attractorDataSize = System.Runtime.InteropServices.Marshal.SizeOf<AttractorData>();
                m_GpuAttractors = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 
                    Mathf.Max(attractorData.Length, 32), attractorDataSize) { name = "Attractors" };
            }
            
            m_GpuAttractors.SetData(attractorData);
        }
        
        /// <summary>
        /// Set sphere collider count for physics updates. Called by GaussianSplatPhysicsCollider.
        /// </summary>
        public void SetSphereColliderCount(int count)
        {
            m_ActiveSphereColliderCount = count;
        }
        
        /// <summary>
        /// Set wind box count for wind updates. Called by GaussianSplatWindBox.
        /// </summary>
        public void SetWindBoxCount(int count)
        {
            m_ActiveWindBoxCount = count;
        }

        void RunDirectRestoration()
        {
            // Run direct position restoration for splats outside wind boxes
            if (m_GpuSplatOriginalPositions == null) return;
            
            int restoreKernel = GetKernelIndex(KernelIndices.DirectRestorePositions);
            if (restoreKernel < 0)
            {
                // Fallback: The enhanced force-based restoration should still work
                // The compute shader already has improved restoration logic in CSApplyWindForces
                if (m_DebugPhysics)
                    Debug.Log("Direct restoration kernel not available, using force-based restoration");
                return;
            }
            
            using var cmb = new CommandBuffer { name = "DirectRestoration" };
            
            // Set required buffers for direct restoration
            SetAssetDataOnCS(cmb, KernelIndices.DirectRestorePositions);
            cmb.SetComputeBufferParam(m_CSBoxUtil, restoreKernel, Props.SplatOriginalPositions, m_GpuSplatOriginalPositions);
            cmb.SetComputeBufferParam(m_CSBoxUtil, restoreKernel, Props.SplatVelocities, m_GpuSplatVelocities);
            cmb.SetComputeBufferParam(m_CSBoxUtil, restoreKernel, Props.WindBoxes, m_GpuWindBoxes);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.WindBoxCount, m_ActiveWindBoxCount);
            
            // Add transform matrices for coordinate space conversion
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, transform.worldToLocalMatrix);
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(restoreKernel, out uint gsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, restoreKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
        }

        void RunPhysicsIntegration()
        {
            // This method runs the dedicated CSUpdateWindPhysics kernel for wind effects
            // It uses separate wind physics settings, independent of sphere collider physics
            
            if (m_GpuSplatVelocities == null || m_GpuSplatPrevPositions == null) return;
            
            using var cmb = new CommandBuffer { name = "WindPhysicsIntegration" };
            
            int windPhysicsKernel = GetKernelIndex(KernelIndices.UpdateWindPhysics);
            if (windPhysicsKernel >= 0)
            {
                if (m_DebugPhysics)
                    Debug.Log("Running dedicated wind physics integration with wind-specific settings");

                // Set required buffers for wind physics integration using the existing SetAssetDataOnCS method
                SetAssetDataOnCS(cmb, KernelIndices.UpdateWindPhysics);
                
                // Set additional wind-specific parameters
                cmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatVelocities, m_GpuSplatVelocities);
                cmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatPrevPositions, m_GpuSplatPrevPositions);
                EnsureAnimFlagsBuffer();
                cmb.SetComputeBufferParam(m_CSBoxUtil, windPhysicsKernel, Props.SplatAnimFlags, m_GpuSplatAnimFlags);
                
                // Use fixed delta time in editor mode for consistent behavior
                float deltaTime = Time.deltaTime;
#if UNITY_EDITOR
                if (!Application.isPlaying)
                    deltaTime = 0.016f; // ~60fps for smooth editor updates
#endif
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.DeltaTime, deltaTime);
                // Use dedicated wind physics settings (completely separate from sphere physics)
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.WindGravity, m_WindGravity); 
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.WindDamping, m_WindDamping); 
                cmb.SetComputeFloatParam(m_CSBoxUtil, Props.WindMinVelocity, m_WindMinVelocity);
                
                m_CSBoxUtil.GetKernelThreadGroupSizes(windPhysicsKernel, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, windPhysicsKernel, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
                
                Graphics.ExecuteCommandBuffer(cmb);
            }
            else
            {
                Debug.LogError("Wind physics integration kernel not found!");
            }
        }

        public void ActivateCamera(int index)
        {
            Camera mainCam = Camera.main;
            if (!mainCam)
                return;
            if (!m_Asset || asset.cameras == null)
                return;

            var selfTr = transform;
            var camTr = mainCam.transform;
            var prevParent = camTr.parent;
            var cam = asset.cameras[index];
            camTr.parent = selfTr;
            camTr.localPosition = cam.pos;
            camTr.localRotation = Quaternion.LookRotation(cam.axisZ, cam.axisY);
            camTr.parent = prevParent;
            camTr.localScale = Vector3.one;
#if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(camTr);
#endif
        }

        void ClearGraphicsBuffer(GraphicsBuffer buf)
        {
            int kernelIndex = GetKernelIndex(KernelIndices.ClearBuffer);
            if (kernelIndex < 0 || m_CSBoxUtil == null) return;
            try
            {
                m_CSBoxUtil.SetBuffer(kernelIndex, Props.DstBuffer, buf);
                m_CSBoxUtil.SetInt(Props.BufferSize, buf.count);
                m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
                m_CSBoxUtil.Dispatch(kernelIndex, (int)((buf.count+gsX-1)/gsX), 1, 1);
            }
            catch (System.Exception)
            {
                Debug.LogWarning($"BoxUtil.compute: Kernel index ({kernelIndex}) out of range");
                // Mark this kernel as broken
                if (m_KernelIndices != null)
                    m_KernelIndices[KernelIndices.ClearBuffer] = -1;
            }
        }

        void UnionGraphicsBuffers(GraphicsBuffer dst, GraphicsBuffer src)
        {
            int kernelIndex = GetKernelIndex(KernelIndices.OrBuffers);
            if (kernelIndex < 0 || m_CSBoxUtil == null) return;
            try
            {
                m_CSBoxUtil.SetBuffer(kernelIndex, Props.SrcBuffer, src);
                m_CSBoxUtil.SetBuffer(kernelIndex, Props.DstBuffer, dst);
                m_CSBoxUtil.SetInt(Props.BufferSize, dst.count);
                m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
                m_CSBoxUtil.Dispatch(kernelIndex, (int)((dst.count+gsX-1)/gsX), 1, 1);
            }
            catch (System.Exception)
            {
                Debug.LogWarning($"BoxUtil.compute: Kernel index ({kernelIndex}) out of range");
                if (m_KernelIndices != null)
                    m_KernelIndices[KernelIndices.OrBuffers] = -1;
            }
        }

        static float SortableUintToFloat(uint v)
        {
            uint mask = ((v >> 31) - 1) | 0x80000000u;
            return math.asfloat(v ^ mask);
        }

        public void UpdateEditCountsAndBounds()
        {
            if (m_GpuEditSelected == null || m_GpuEditCountsBounds == null)
            {
                editSelectedSplats = 0;
                editDeletedSplats = 0;
                editCutSplats = 0;
                editModified = false;
                editSelectedBounds = default;
                return;
            }

            int initKernel = GetKernelIndex(KernelIndices.InitEditData);
            if (initKernel < 0) return;
            m_CSBoxUtil.SetBuffer(initKernel, Props.DstBuffer, m_GpuEditCountsBounds);
            m_CSBoxUtil.Dispatch(initKernel, 1, 1, 1);

            using CommandBuffer cmb = new CommandBuffer();
            SetAssetDataOnCS(cmb, KernelIndices.UpdateEditData);
            int updateKernel = GetKernelIndex(KernelIndices.UpdateEditData);
            if (updateKernel < 0) return;
            cmb.SetComputeBufferParam(m_CSBoxUtil, updateKernel, Props.DstBuffer, m_GpuEditCountsBounds);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.BufferSize, m_GpuEditSelected.count);
            m_CSBoxUtil.GetKernelThreadGroupSizes(updateKernel, out uint gsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, updateKernel, (int)((m_GpuEditSelected.count+gsX-1)/gsX), 1, 1);
            Graphics.ExecuteCommandBuffer(cmb);

            uint[] res = new uint[m_GpuEditCountsBounds.count];
            m_GpuEditCountsBounds.GetData(res);
            editSelectedSplats = res[0];
            editDeletedSplats = res[1];
            editCutSplats = res[2];
            Vector3 min = new Vector3(SortableUintToFloat(res[3]), SortableUintToFloat(res[4]), SortableUintToFloat(res[5]));
            Vector3 max = new Vector3(SortableUintToFloat(res[6]), SortableUintToFloat(res[7]), SortableUintToFloat(res[8]));
            Bounds bounds = default;
            bounds.SetMinMax(min, max);
            if (bounds.extents.sqrMagnitude < 0.01)
                bounds.extents = new Vector3(0.1f,0.1f,0.1f);
            editSelectedBounds = bounds;
        }

        /// <summary>
        /// Force re-sort on next frame - call after adding/modifying splats to finalize them
        /// </summary>
        public void ForceResort()
        {
            m_FrameCounter = 0;
            editModified = false; // Clear modified flag to stop continuous gizmo drawing
        }

        void UpdateCutoutsBuffer()
        {
            int bufferSize = m_Cutouts?.Length ?? 0;
            if (bufferSize == 0)
                bufferSize = 1;
            if (m_GpuEditCutouts == null || m_GpuEditCutouts.count != bufferSize)
            {
                m_GpuEditCutouts?.Dispose();
                m_GpuEditCutouts = new GraphicsBuffer(GraphicsBuffer.Target.Structured, bufferSize, UnsafeUtility.SizeOf<GaussianCutout.ShaderData>()) { name = "GaussianCutouts" };
            }

            NativeArray<GaussianCutout.ShaderData> data = new(bufferSize, Allocator.Temp);
            if (m_Cutouts != null)
            {
                var matrix = transform.localToWorldMatrix;
                for (var i = 0; i < m_Cutouts.Length; ++i)
                {
                        data[i] = GaussianCutout.GetShaderData(m_Cutouts[i], matrix);
                }
            }

            m_GpuEditCutouts.SetData(data);
            data.Dispose();
        }

        bool EnsureEditingBuffers()
        {
            if (!HasValidAsset || !HasValidRenderSetup)
                return false;

            var target = GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource | GraphicsBuffer.Target.CopyDestination;
            var size = (m_SplatCount + 31) / 32;

            if (m_GpuEditDeleted == null)
            {
                m_GpuEditDeleted = new GraphicsBuffer(target, size, 4) { name = "GaussianSplatDeleted" };
                ClearGraphicsBuffer(m_GpuEditDeleted);
            }

            if (m_GpuEditSelected == null)
            {
                m_GpuEditSelected = new GraphicsBuffer(target, size, 4) { name = "GaussianSplatSelected" };
                ClearGraphicsBuffer(m_GpuEditSelected);
            }
            
            if (m_GpuEditTargetSelected == null)
            {
                m_GpuEditTargetSelected = new GraphicsBuffer(target, size, 4) { name = "GaussianSplatTargetSelected" };
                ClearGraphicsBuffer(m_GpuEditTargetSelected);
            }

            if (m_GpuEditCountsBounds == null)
            {
                // Buffer for counts and bounds (9 uints: selected, deleted, cut, minX, minY, minZ, maxX, maxY, maxZ)
                m_GpuEditCountsBounds = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 9, 4) { name = "GaussianSplatCountsBounds" };
            }

            if (m_GpuEditSelectMinDepth == null)
            {
                // 1 uint value used as an atomic min accumulator (sortable float encoding)
                m_GpuEditSelectMinDepth = new GraphicsBuffer(target, 1, 4) { name = "GaussianSplatSelectMinDepth" };
                // Initialize to a very large sortable float so InterlockedMin works
                uint init = FloatToSortableUint(1.0e38f);
                m_GpuEditSelectMinDepth.SetData(new[] { init });
            }

            return m_GpuEditSelected != null && m_GpuEditDeleted != null && m_GpuEditCountsBounds != null && m_GpuEditSelectMinDepth != null;
        }

        public void EditStoreSelectionMouseDown()
        {
            if (!EnsureEditingBuffers()) return;
            Graphics.CopyBuffer(m_GpuEditSelected, m_GpuEditSelectedMouseDown);
        }

        public void EditStorePosMouseDown()
        {
            if (m_GpuEditPosMouseDown == null)
            {
                m_GpuEditPosMouseDown = new GraphicsBuffer(m_GpuPosData.target | GraphicsBuffer.Target.CopyDestination, m_GpuPosData.count, m_GpuPosData.stride) {name = "GaussianSplatEditPosMouseDown"};
            }
            Graphics.CopyBuffer(m_GpuPosData, m_GpuEditPosMouseDown);
        }
        public void EditStoreOtherMouseDown()
        {
            if (m_GpuEditOtherMouseDown == null)
            {
                m_GpuEditOtherMouseDown = new GraphicsBuffer(m_GpuOtherData.target | GraphicsBuffer.Target.CopyDestination, m_GpuOtherData.count, m_GpuOtherData.stride) {name = "GaussianSplatEditOtherMouseDown"};
            }
            Graphics.CopyBuffer(m_GpuOtherData, m_GpuEditOtherMouseDown);
        }

        public void EditUpdateSelection(Vector2 rectMin, Vector2 rectMax, Camera cam, bool subtract)
        {
            if (!EnsureEditingBuffers()) return;

            Graphics.CopyBuffer(m_GpuEditSelectedMouseDown, m_GpuEditSelected);

            var tr = transform;
            Matrix4x4 matView = cam.worldToCameraMatrix;
            Matrix4x4 matProj = GL.GetGPUProjectionMatrix(cam.projectionMatrix, true);
            Matrix4x4 matO2W = tr.localToWorldMatrix;
            Matrix4x4 matW2O = tr.worldToLocalMatrix;
            int screenW = cam.pixelWidth, screenH = cam.pixelHeight;
            Vector4 screenPar = new Vector4(screenW, screenH, 0, 0);
            Vector4 camPos = cam.transform.position;

            using var cmb = new CommandBuffer { name = "SplatSelectionUpdate" };
            SetAssetDataOnCS(cmb, KernelIndices.SelectionUpdate);

            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

            cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionRect", new Vector4(rectMin.x, rectMax.y, rectMax.x, rectMin.y));
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SelectionMode, subtract ? 0 : 1);

            DispatchUtilsAndExecute(cmb, KernelIndices.SelectionUpdate, m_SplatCount);
            UpdateEditCountsAndBounds();
        }

        public void EditSelectSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam, bool subtract)
        {
            EditSelectSplatsInScreenCircle(centerPx, radiusPx, cam, subtract, false);
        }
        
        public void EditSelectSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam, bool subtract, bool backfaceCulling)
        {
            if (!EnsureEditingBuffers()) return;

            var tr = transform;
            Matrix4x4 matView = cam.worldToCameraMatrix;
            // Use false for renderIntoTexture to get standard screen coordinates
            Matrix4x4 matProj = GL.GetGPUProjectionMatrix(cam.projectionMatrix, false);
            Matrix4x4 matO2W = tr.localToWorldMatrix;
            Matrix4x4 matW2O = tr.worldToLocalMatrix;
            int screenW = cam.pixelWidth, screenH = cam.pixelHeight;
            Vector4 screenPar = new Vector4(screenW, screenH, 0, 0);
            Vector4 camPos = cam.transform.position;

            // If "BackfaceCulling" is enabled in UI, we actually do "visible-only" selection:
            // find the closest splat depth under the brush, then only select splats within a small depth epsilon.
            if (backfaceCulling)
            {
                uint init = FloatToSortableUint(1.0e38f);
                m_GpuEditSelectMinDepth.SetData(new[] { init });
            }

            int selectKernelIndex = GetKernelIndex(KernelIndices.SelectSplatsInScreenCircle);
            int findKernelIndex = backfaceCulling ? GetKernelIndex(KernelIndices.FindMinDepthInScreenCircle) : -1;
            if (selectKernelIndex < 0) return;
            if (backfaceCulling && findKernelIndex < 0) return;

            using var cmb = new CommandBuffer { name = "SplatSelectScreenCircle" };

            // Pass 1: find min depth in circle
            if (backfaceCulling)
            {
                SetAssetDataOnCS(cmb, KernelIndices.FindMinDepthInScreenCircle);
                cmb.SetComputeBufferParam(m_CSBoxUtil, findKernelIndex, "_SelectionMinDepth", m_GpuEditSelectMinDepth);

                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

                cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
                cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

                cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", new Vector4(centerPx.x, centerPx.y, 0, 0));
                cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);

                m_CSBoxUtil.GetKernelThreadGroupSizes(findKernelIndex, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, findKernelIndex, (int)((m_SplatCount + gsX - 1) / gsX), 1, 1);
            }

            // Pass 2: select splats in circle (optionally depth-filtered)
            SetAssetDataOnCS(cmb, KernelIndices.SelectSplatsInScreenCircle);
            cmb.SetComputeBufferParam(m_CSBoxUtil, selectKernelIndex, "_SelectionMinDepth", m_GpuEditSelectMinDepth);

            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

            cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", new Vector4(centerPx.x, centerPx.y, 0, 0));
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SelectionMode, subtract ? 0 : 1);

            cmb.SetComputeIntParam(m_CSBoxUtil, "_BackfaceCulling", backfaceCulling ? 1 : 0);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionDepthEpsilon", 0.05f);

            m_CSBoxUtil.GetKernelThreadGroupSizes(selectKernelIndex, out uint selGsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, selectKernelIndex, (int)((m_SplatCount + selGsX - 1) / selGsX), 1, 1);

            Graphics.ExecuteCommandBuffer(cmb);
            UpdateEditCountsAndBounds();
        }
        
        /// <summary>
        /// Select splats in a screen-space circle for the TARGET selection (paint target area).
        /// Uses a separate buffer from the source selection.
        /// </summary>
        public void EditSelectTargetSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam, bool subtract)
        {
            EditSelectTargetSplatsInScreenCircle(centerPx, radiusPx, cam, subtract, false);
        }
        
        public void EditSelectTargetSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam, bool subtract, bool backfaceCulling)
        {
            if (!EnsureEditingBuffers()) return;

            var tr = transform;
            Matrix4x4 matView = cam.worldToCameraMatrix;
            Matrix4x4 matProj = GL.GetGPUProjectionMatrix(cam.projectionMatrix, false);
            Matrix4x4 matO2W = tr.localToWorldMatrix;
            Matrix4x4 matW2O = tr.worldToLocalMatrix;
            int screenW = cam.pixelWidth, screenH = cam.pixelHeight;
            Vector4 screenPar = new Vector4(screenW, screenH, 0, 0);
            Vector4 camPos = cam.transform.position;
            int kernelIndex = GetKernelIndex(KernelIndices.SelectSplatsInScreenCircle);
            int findKernelIndex = backfaceCulling ? GetKernelIndex(KernelIndices.FindMinDepthInScreenCircle) : -1;
            if (kernelIndex < 0) return;
            if (backfaceCulling && findKernelIndex < 0) return;

            using var cmb = new CommandBuffer { name = "SplatSelectTargetScreenCircle" };

            if (backfaceCulling)
            {
                uint init = FloatToSortableUint(1.0e38f);
                m_GpuEditSelectMinDepth.SetData(new[] { init });

                // Min depth pass (doesn't depend on which selection buffer is used)
                SetAssetDataOnCS(cmb, KernelIndices.FindMinDepthInScreenCircle);
                cmb.SetComputeBufferParam(m_CSBoxUtil, findKernelIndex, "_SelectionMinDepth", m_GpuEditSelectMinDepth);

                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

                cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
                cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

                cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", new Vector4(centerPx.x, centerPx.y, 0, 0));
                cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);

                m_CSBoxUtil.GetKernelThreadGroupSizes(findKernelIndex, out uint fgsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, findKernelIndex, (int)((m_SplatCount + fgsX - 1) / fgsX), 1, 1);
            }
            
            // Set common parameters
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatOther, m_GpuOtherData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatDeletedBits, m_GpuEditDeleted ?? m_GpuPosData);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatBitsValid, m_GpuEditSelected != null && m_GpuEditDeleted != null ? 1 : 0);
            uint format = (uint)asset.posFormat | ((uint)asset.scaleFormat << 8) | ((uint)asset.shFormat << 16);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)format);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            
            // Set target buffer instead of source buffer
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatSelectedBits, m_GpuEditTargetSelected);

            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

            cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", new Vector4(centerPx.x, centerPx.y, 0, 0));
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SelectionMode, subtract ? 0 : 1);
            
            cmb.SetComputeIntParam(m_CSBoxUtil, "_BackfaceCulling", backfaceCulling ? 1 : 0);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionDepthEpsilon", 0.05f);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_SelectionMinDepth", m_GpuEditSelectMinDepth);

            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, (int)((m_SplatCount + gsX - 1) / gsX), 1, 1);
            Graphics.ExecuteCommandBuffer(cmb);
            
            UpdateTargetSelectionCount();
        }
        
        /// <summary>
        /// Clear the target selection (for paint target mode)
        /// </summary>
        public void EditDeselectAllTarget()
        {
            if (!EnsureEditingBuffers()) return;
            ClearGraphicsBuffer(m_GpuEditTargetSelected);
            editTargetSelectedSplats = 0;
        }
        
        void UpdateTargetSelectionCount()
        {
            if (m_GpuEditTargetSelected == null)
            {
                editTargetSelectedSplats = 0;
                return;
            }
            
            // Count selected bits in target buffer
            int bufferCount = m_GpuEditTargetSelected.count;
            uint[] bits = new uint[bufferCount];
            m_GpuEditTargetSelected.GetData(bits);
            
            uint count = 0;
            for (int i = 0; i < bufferCount; i++)
            {
                uint word = bits[i];
                while (word != 0)
                {
                    count += word & 1;
                    word >>= 1;
                }
            }
            editTargetSelectedSplats = count;
        }
        
        /// <summary>
        /// Get the center of the target selection area
        /// </summary>
        public Vector3 GetTargetSelectedSplatsCenter()
        {
            if (!HasValidAsset || !HasValidRenderSetup || editTargetSelectedSplats == 0)
                return transform.position;
            
            var indices = GetTargetSelectedSplatIndices();
            return GetCenterOfSplats(indices);
        }
        
        /// <summary>
        /// Get the indices of target-selected splats from the GPU buffer
        /// </summary>
        public List<int> GetTargetSelectedSplatIndices()
        {
            var result = new List<int>();
            if (m_GpuEditTargetSelected == null || editTargetSelectedSplats == 0)
                return result;
            
            int bufferCount = m_GpuEditTargetSelected.count;
            uint[] selectionBits = new uint[bufferCount];
            m_GpuEditTargetSelected.GetData(selectionBits);
            
            for (int wordIdx = 0; wordIdx < bufferCount; wordIdx++)
            {
                uint word = selectionBits[wordIdx];
                if (word == 0) continue;
                
                for (int bit = 0; bit < 32; bit++)
                {
                    if ((word & (1u << bit)) != 0)
                    {
                        int splatIndex = wordIdx * 32 + bit;
                        if (splatIndex < m_SplatCount)
                            result.Add(splatIndex);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Select or deselect splats within a sphere (for paint brush selection)
        /// </summary>
        public void EditSelectSplatsInSphere(Vector3 worldCenter, float radius, bool addToSelection)
        {
            if (!EnsureEditingBuffers()) return;

            var tr = transform;
            Matrix4x4 matO2W = tr.localToWorldMatrix;

            using var cmb = new CommandBuffer { name = "SplatSelectInSphere" };
            SetAssetDataOnCS(cmb, KernelIndices.SelectSplatsInSphere);

            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionSphereCenter", worldCenter);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionSphereRadius", radius);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_SelectionSphereMode", addToSelection ? 1 : 0);

            DispatchUtilsAndExecute(cmb, KernelIndices.SelectSplatsInSphere, m_SplatCount);
            UpdateEditCountsAndBounds();
        }
        
        /// <summary>
        /// Select or deselect splats within a sphere with backface culling (only splats facing camera)
        /// </summary>
        public void EditSelectSplatsInSphere(Vector3 worldCenter, float radius, bool addToSelection, Vector3 cameraForward)
        {
            if (!EnsureEditingBuffers()) return;
            if (m_GpuPosData == null || m_GpuOtherData == null) return;
            
            var tr = transform;
            float radiusSq = radius * radius;
            
            // Read current position and rotation data
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData);
            
            uint[] otherData = new uint[m_SplatCount * 4];
            m_GpuOtherData.GetData(otherData);
            
            // Read current selection state
            uint[] selectionData = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditSelected.GetData(selectionData);
            
            // Convert camera forward to local space
            Vector3 localCameraForward = tr.InverseTransformDirection(cameraForward).normalized;
            
            int modifiedCount = 0;
            
            for (int i = 0; i < m_SplatCount; i++)
            {
                // Get world position of splat
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = tr.TransformPoint(localPos);
                
                // Check if within sphere
                float distSq = (worldPos - worldCenter).sqrMagnitude;
                if (distSq > radiusSq) continue;
                
                // Backface culling: check if splat is facing camera
                Quaternion splatRot = UnpackRotation(otherData[i * 4]);
                // Splat's local Z axis (forward) in local space, then transform to check against camera
                Vector3 splatForward = splatRot * Vector3.forward;
                
                // If splat is facing away from camera (dot product > 0 means facing same direction as camera looks)
                float dot = Vector3.Dot(splatForward, localCameraForward);
                if (dot > 0) continue; // Skip splats facing away from camera
                
                // Update selection
                int wordIdx = i / 32;
                int bitIdx = i % 32;
                uint mask = 1u << bitIdx;
                
                if (addToSelection)
                    selectionData[wordIdx] |= mask;
                else
                    selectionData[wordIdx] &= ~mask;
                    
                modifiedCount++;
            }
            
            if (modifiedCount > 0)
            {
                m_GpuEditSelected.SetData(selectionData);
                UpdateEditCountsAndBounds();
            }
        }

        public void EditTranslateSelection(Vector3 localSpacePosDelta)
        {
            if (!EnsureEditingBuffers()) return;

            using var cmb = new CommandBuffer { name = "SplatTranslateSelection" };
            SetAssetDataOnCS(cmb, KernelIndices.TranslateSelection);

            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.SelectionDelta, localSpacePosDelta);

            DispatchUtilsAndExecute(cmb, KernelIndices.TranslateSelection, m_SplatCount);
            UpdateEditCountsAndBounds();
            editModified = true;
        }

        public void EditRotateSelection(Vector3 localSpaceCenter, Matrix4x4 localToWorld, Matrix4x4 worldToLocal, Quaternion rotation)
        {
            if (!EnsureEditingBuffers()) return;
            if (m_GpuEditPosMouseDown == null || m_GpuEditOtherMouseDown == null) return; // should have captured initial state

            using var cmb = new CommandBuffer { name = "SplatRotateSelection" };
            SetAssetDataOnCS(cmb, KernelIndices.RotateSelection);

            int kernelIndex = GetKernelIndex(KernelIndices.RotateSelection);
            if (kernelIndex < 0) return;
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPosMouseDown, m_GpuEditPosMouseDown);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatOtherMouseDown, m_GpuEditOtherMouseDown);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.SelectionCenter, localSpaceCenter);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, localToWorld);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, worldToLocal);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.SelectionDeltaRot, new Vector4(rotation.x, rotation.y, rotation.z, rotation.w));

            DispatchUtilsAndExecute(cmb, KernelIndices.RotateSelection, m_SplatCount);
            UpdateEditCountsAndBounds();
            editModified = true;
        }


        public void EditScaleSelection(Vector3 localSpaceCenter, Matrix4x4 localToWorld, Matrix4x4 worldToLocal, Vector3 scale)
        {
            if (!EnsureEditingBuffers()) return;
            if (m_GpuEditPosMouseDown == null) return; // should have captured initial state

            using var cmb = new CommandBuffer { name = "SplatScaleSelection" };
            SetAssetDataOnCS(cmb, KernelIndices.ScaleSelection);

            int kernelIndex = GetKernelIndex(KernelIndices.ScaleSelection);
            if (kernelIndex < 0) return;
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPosMouseDown, m_GpuEditPosMouseDown);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.SelectionCenter, localSpaceCenter);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, localToWorld);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, worldToLocal);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.SelectionDelta, scale);

            DispatchUtilsAndExecute(cmb, KernelIndices.ScaleSelection, m_SplatCount);
            UpdateEditCountsAndBounds();
            editModified = true;
        }

        public void EditDeleteSelected()
        {
            if (!EnsureEditingBuffers()) return;
            UnionGraphicsBuffers(m_GpuEditDeleted, m_GpuEditSelected);
            EditDeselectAll();
            UpdateEditCountsAndBounds();
            if (editDeletedSplats != 0)
                editModified = true;
        }

        public void EditSelectAll()
        {
            if (!EnsureEditingBuffers()) return;
            using var cmb = new CommandBuffer { name = "SplatSelectAll" };
            SetAssetDataOnCS(cmb, KernelIndices.SelectAll);
            int kernelIndex = GetKernelIndex(KernelIndices.SelectAll);
            if (kernelIndex < 0) return;
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.DstBuffer, m_GpuEditSelected);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.BufferSize, m_GpuEditSelected.count);
            DispatchUtilsAndExecute(cmb, KernelIndices.SelectAll, m_GpuEditSelected.count);
            UpdateEditCountsAndBounds();
        }

        public void EditDeselectAll()
        {
            if (!EnsureEditingBuffers()) return;
            ClearGraphicsBuffer(m_GpuEditSelected);
            UpdateEditCountsAndBounds();
        }

        public void EditInvertSelection()
        {
            if (!EnsureEditingBuffers()) return;

            using var cmb = new CommandBuffer { name = "SplatInvertSelection" };
            SetAssetDataOnCS(cmb, KernelIndices.InvertSelection);
            int kernelIndex = GetKernelIndex(KernelIndices.InvertSelection);
            if (kernelIndex < 0) return;
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.DstBuffer, m_GpuEditSelected);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.BufferSize, m_GpuEditSelected.count);
            DispatchUtilsAndExecute(cmb, KernelIndices.InvertSelection, m_GpuEditSelected.count);
            UpdateEditCountsAndBounds();
        }

        /// <summary>
        /// Get the indices of selected splats from the GPU selection buffer.
        /// This reads from GPU to CPU, so it's not ideal for every-frame use.
        /// </summary>
        public List<int> GetSelectedSplatIndices()
        {
            var result = new List<int>();
            if (m_GpuEditSelected == null || editSelectedSplats == 0)
                return result;
            
            int bufferCount = m_GpuEditSelected.count;
            uint[] selectionBits = new uint[bufferCount];
            m_GpuEditSelected.GetData(selectionBits);
            
            for (int wordIdx = 0; wordIdx < bufferCount; wordIdx++)
            {
                uint word = selectionBits[wordIdx];
                if (word == 0) continue;
                
                for (int bit = 0; bit < 32; bit++)
                {
                    if ((word & (1u << bit)) != 0)
                    {
                        int splatIndex = wordIdx * 32 + bit;
                        if (splatIndex < m_SplatCount)
                            result.Add(splatIndex);
                    }
                }
            }
            return result;
        }
        
        /// <summary>
        /// Clone splats from the current GPU selection with an offset.
        /// </summary>
        public void CloneFromSelection(Vector3 worldOffset)
        {
            if (!HasValidAsset || !HasValidRenderSetup || editSelectedSplats == 0)
                return;
            
            var indices = GetSelectedSplatIndices();
            if (indices.Count == 0) return;
            
            CloneSplatsFromIndices(indices, worldOffset);
        }
        
        /// <summary>
        /// Clone splats from the current GPU selection with transform and color adjustments.
        /// </summary>
        public void CloneFromSelectionTransformed(Vector3 worldOffset, Quaternion rotation, Vector3 scale, Vector3 pivotWorld, ColorAdjustments colorAdj)
        {
            if (!HasValidAsset || !HasValidRenderSetup || editSelectedSplats == 0)
                return;
            
            var indices = GetSelectedSplatIndices();
            if (indices.Count == 0) return;
            
            CloneSplatsFromIndicesTransformed(indices, worldOffset, rotation, scale, pivotWorld, colorAdj);
        }
        
        /// <summary>
        /// Get the center position of currently selected splats.
        /// </summary>
        public Vector3 GetSelectedSplatsCenter()
        {
            if (!HasValidAsset || !HasValidRenderSetup || editSelectedSplats == 0)
                return transform.position;
            
            // Use editSelectedBounds which is calculated on GPU and works with all formats
            Vector3 localCenter = editSelectedBounds.center;
            return transform.TransformPoint(localCenter);
        }

        /// <summary>
        /// Exports edited splat data into <paramref name="dstData"/>.
        /// </summary>
        /// <param name="maxExportScale">Max allowed per-axis world-space splat scale. Splats larger than this
        /// (degenerate floaters the renderer hides) are skipped to avoid spikes in external viewers.
        /// Pass &lt;= 0 to disable the size filter (non-finite splats are always skipped).</param>
        public bool EditExportData(GraphicsBuffer dstData, bool bakeTransform, float maxExportScale = 0f)
        {
            if (!EnsureEditingBuffers()) return false;

            int flags = 0;
            var tr = transform;
            Quaternion bakeRot = tr.localRotation;
            Vector3 bakeScale = tr.localScale;

            if (bakeTransform)
                flags = 1;

            using var cmb = new CommandBuffer { name = "SplatExportData" };
            SetAssetDataOnCS(cmb, KernelIndices.ExportData);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_ExportTransformFlags", flags);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_ExportTransformRotation", new Vector4(bakeRot.x, bakeRot.y, bakeRot.z, bakeRot.w));
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_ExportTransformScale", bakeScale);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_ExportMaxScale", maxExportScale);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, tr.localToWorldMatrix);
            int kernelIndex = GetKernelIndex(KernelIndices.ExportData);
            if (kernelIndex < 0) return false;
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_ExportBuffer", dstData);

            DispatchUtilsAndExecute(cmb, KernelIndices.ExportData, m_SplatCount);
            return true;
        }

        /// <summary>
        /// Scores splats by visual importance (opacity, size, anisotropy) and removes the least
        /// important fraction. Low-opacity, tiny, and needle-like splats go first — suited for VR.
        /// </summary>
        /// <returns>Number of splats marked deleted.</returns>
        public int SmartDecimate(DecimationSettings settings)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return 0;
            if (!EnsureEditingBuffers())
                return 0;
            if (settings.removalRatio <= 0f)
                return 0;

            int kernelIndex = GetKernelIndex(KernelIndices.ComputeDecimationScores);
            if (kernelIndex < 0)
            {
                Debug.LogError("CSComputeDecimationScores kernel not found. Reimport BoxUtil.compute.");
                return 0;
            }

            float maxScale = settings.maxScale;
            if (maxScale <= 0f)
            {
                float diagonal = (asset.boundsMax - asset.boundsMin).magnitude;
                if (diagonal > 0f)
                    maxScale = diagonal * 0.25f;
            }

            using var scoreBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, sizeof(float));

            using var cmb = new CommandBuffer { name = "ComputeDecimationScores" };
            SetAssetDataOnCS(cmb, KernelIndices.ComputeDecimationScores);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_DecimationScores", scoreBuffer);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DecimationOpacityWeight", settings.opacityWeight);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DecimationSizeWeight", settings.sizeWeight);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DecimationAnisotropyPenalty", settings.anisotropyPenalty);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DecimationMaxScale", maxScale);
            DispatchUtilsAndExecute(cmb, KernelIndices.ComputeDecimationScores, m_SplatCount);

            float[] scores = new float[m_SplatCount];
            scoreBuffer.GetData(scores);

            uint[] deletedBits = new uint[m_GpuEditDeleted.count];
            m_GpuEditDeleted.GetData(deletedBits);

            var ranked = new List<(float score, int index)>(m_SplatCount);
            for (int i = 0; i < m_SplatCount; i++)
            {
                int wordIdx = i >> 5;
                int bitIdx = i & 31;
                if ((deletedBits[wordIdx] & (1u << bitIdx)) != 0)
                    continue;
                ranked.Add((scores[i], i));
            }

            if (ranked.Count <= 1)
                return 0;

            ranked.Sort((a, b) => a.score.CompareTo(b.score));
            int removeCount = Mathf.Clamp(Mathf.RoundToInt(ranked.Count * settings.removalRatio), 0, ranked.Count - 1);
            if (removeCount <= 0)
                return 0;

            for (int i = 0; i < removeCount; i++)
            {
                int splatIdx = ranked[i].index;
                int wordIdx = splatIdx >> 5;
                int bitIdx = splatIdx & 31;
                deletedBits[wordIdx] |= (1u << bitIdx);
            }

            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            return removeCount;
        }

        public void EditSetSplatCount(int newSplatCount)
        {
            if (newSplatCount <= 0 || newSplatCount > GaussianSplatAsset.kMaxSplats)
            {
                Debug.LogError($"Invalid new splat count: {newSplatCount}");
                return;
            }
            if (asset.chunkData != null)
            {
                Debug.LogError("Only splats with VeryHigh quality can be resized");
                return;
            }
            if (newSplatCount == splatCount)
                return;

            // CSCopySplats always outputs in Float32 format:
            // - Position: 12 bytes (3 floats)
            // - Other: 16 bytes (4 bytes rot + 12 bytes scale as 3 floats)
            // - SH: keep original stride (48 bytes for Float16 SH)
            int posStride32F = 12;
            int otherStride32F = 16;
            int shStride = (int) (asset.shData.dataSize / asset.splatCount);

            // create new GPU buffers sized for 32F output format
            var newPosData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource, newSplatCount * posStride32F / 4, 4) { name = "GaussianPosData" };
            var newOtherData = new GraphicsBuffer(GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource, newSplatCount * otherStride32F / 4, 4) { name = "GaussianOtherData" };
            var newSHData = new GraphicsBuffer(GraphicsBuffer.Target.Raw, newSplatCount * shStride / 4, 4) { name = "GaussianSHData" };

            // new texture is a RenderTexture so we can write to it from a compute shader
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(newSplatCount);
            var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
            var newColorData = new RenderTexture(texWidth, texHeight, texFormat, GraphicsFormat.None) { name = "GaussianColorData", enableRandomWrite = true };
            newColorData.Create();

            // selected/deleted buffers
            var selTarget = GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource | GraphicsBuffer.Target.CopyDestination;
            var selSize = (newSplatCount + 31) / 32;
            var newEditSelected = new GraphicsBuffer(selTarget, selSize, 4) {name = "GaussianSplatSelected"};
            var newEditSelectedMouseDown = new GraphicsBuffer(selTarget, selSize, 4) {name = "GaussianSplatSelectedInit"};
            var newEditDeleted = new GraphicsBuffer(selTarget, selSize, 4) {name = "GaussianSplatDeleted"};
            ClearGraphicsBuffer(newEditSelected);
            ClearGraphicsBuffer(newEditSelectedMouseDown);
            ClearGraphicsBuffer(newEditDeleted);

            var newGpuView = new GraphicsBuffer(GraphicsBuffer.Target.Structured, newSplatCount, kGpuViewDataSize);
            InitSortBuffers(newSplatCount);

            // copy existing data over into new buffers
            EditCopySplats(transform, newPosData, newOtherData, newSHData, newColorData, newEditDeleted, newSplatCount, 0, 0, m_SplatCount);

            // use the new buffers and the new splat count
            m_GpuPosData.Dispose();
            m_GpuOtherData.Dispose();
            m_GpuSHData.Dispose();
            if (m_GpuColorData != null)
            {
                if (RenderTexture.active == m_GpuColorData)
                {
                    RenderTexture.active = null;
                }
                DestroyImmediate(m_GpuColorData);
            }
            m_GpuView.Dispose();

            m_GpuEditSelected?.Dispose();
            m_GpuEditSelectedMouseDown?.Dispose();
            m_GpuEditDeleted?.Dispose();

            m_GpuPosData = newPosData;
            m_GpuOtherData = newOtherData;
            m_GpuSHData = newSHData;
            m_GpuSHDataContainsCoefficients = true;
            m_GpuColorData = newColorData;
            m_GpuView = newGpuView;
            m_GpuEditSelected = newEditSelected;
            m_GpuEditSelectedMouseDown = newEditSelectedMouseDown;
            m_GpuEditDeleted = newEditDeleted;

            DisposeBuffer(ref m_GpuEditPosMouseDown);
            DisposeBuffer(ref m_GpuEditOtherMouseDown);

            m_SplatCount = newSplatCount;
            editModified = true;

            // Reinitialize sort buffers for the new count
            InitSortBuffers(newSplatCount);
        }

        public void EditCopySplatsInto(SplatBoxRenderer dst, int copySrcStartIndex, int copyDstStartIndex, int copyCount)
        {
            EditCopySplats(
                dst.transform,
                dst.m_GpuPosData, dst.m_GpuOtherData, dst.m_GpuSHData, dst.m_GpuColorData, dst.m_GpuEditDeleted,
                dst.splatCount,
                copySrcStartIndex, copyDstStartIndex, copyCount);
            dst.editModified = true;
        }

        public void EditCopySplats(
            Transform dstTransform,
            GraphicsBuffer dstPos, GraphicsBuffer dstOther, GraphicsBuffer dstSH, Texture dstColor,
            GraphicsBuffer dstEditDeleted,
            int dstSize,
            int copySrcStartIndex, int copyDstStartIndex, int copyCount)
        {
            if (!EnsureEditingBuffers()) return;

            using var cmb = new CommandBuffer { name = "SplatCopy" };
            
            int kernelIndex = GetKernelIndex(KernelIndices.CopySplats);
            if (kernelIndex < 0)
            {
                Debug.LogError("CopySplats kernel not found");
                return;
            }
            
            // Manually set ONLY the buffers CSCopySplats actually needs to avoid UAV limit (max 8)
            // READ buffers (ByteAddressBuffer - not UAVs, to avoid counting against UAV limit):
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopySrcPos", m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopySrcOther", m_GpuOtherData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopySrcSH", m_GpuSHData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatChunks, m_GpuChunks);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernelIndex, Props.SplatColor, m_GpuColorData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopySrcDeletedBits", m_GpuEditDeleted ?? m_GpuPosData);
            
            // WRITE buffers (UAVs - total of 5 UAVs now):
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopyDstPos", dstPos);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopyDstOther", dstOther);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopyDstSH", dstSH);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernelIndex, "_CopyDstColor", dstColor);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, "_CopyDstEditDeleted", dstEditDeleted ?? dstPos);

            // Set required constants
            uint format = (uint)asset.posFormat | ((uint)asset.scaleFormat << 8) | ((uint)asset.shFormat << 16);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)format);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
            
            // Set copy parameters
            cmb.SetComputeIntParam(m_CSBoxUtil, "_CopyDstSize", dstSize);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_CopySrcStartIndex", copySrcStartIndex);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_CopyDstStartIndex", copyDstStartIndex);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_CopyCount", copyCount);

            // Set transform parameters
            Matrix4x4 copyMatrix = dstTransform.worldToLocalMatrix * transform.localToWorldMatrix;
            Quaternion copyRot = copyMatrix.rotation;
            Vector3 copyScale = copyMatrix.lossyScale;

            cmb.SetComputeVectorParam(m_CSBoxUtil, "_CopyTransformRotation", new Vector4(copyRot.x, copyRot.y, copyRot.z, copyRot.w));
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_CopyTransformScale", copyScale);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, "_CopyTransformMatrix", copyMatrix);

            DispatchUtilsAndExecute(cmb, KernelIndices.CopySplats, copyCount);
        }

        void DispatchUtilsAndExecute(CommandBuffer cmb, KernelIndices kernel, int count)
        {
            int kernelIndex = GetKernelIndex(kernel);
            if (kernelIndex < 0) return;
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, (int)((count + gsX - 1)/gsX), 1, 1);
            Graphics.ExecuteCommandBuffer(cmb);
        }

        public GraphicsBuffer GpuEditDeleted => m_GpuEditDeleted;

        // Add this struct to store splat data
        public struct SplatData
        {
            public Vector3 position;
            public Vector3 scale;
            public Quaternion rotation;
            public Color color;
            public float opacity;
        }

        /// <summary>
        /// Ensures the color texture is writable by compute shaders (converts to RenderTexture if needed)
        /// </summary>
        private void EnsureColorTextureIsWritable()
        {
            // If it's already a RenderTexture with random write enabled, we're good
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt != null && rt.enableRandomWrite)
                return;

            // Need to convert Texture2D to RenderTexture
            Texture2D tex2D = m_GpuColorData as Texture2D;
            if (tex2D != null)
            {
                var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
                var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
                
                // Create new RenderTexture with random write enabled
                rt = new RenderTexture(texWidth, texHeight, 0, texFormat)
                {
                    name = "GaussianColorData",
                    enableRandomWrite = true,
                    useMipMap = false,
                    filterMode = FilterMode.Point
                };
                rt.Create();

                // Copy existing texture data to RenderTexture
                Graphics.Blit(tex2D, rt);

                // Dispose old texture and use new RenderTexture
                DestroyImmediate(tex2D);
                m_GpuColorData = rt;
            }
        }

        /// <summary>
        /// Paints new splats at the specified position (auto-expands buffer, may cause jitter)
        /// </summary>
        public void PaintSplats(Vector3 position, Quaternion rotation, float size, float density, int count, Color color)
        {
            PaintSplatsAt(m_SplatCount, position, rotation, size, density, count, color);
        }
        
        /// <summary>
        /// Paints splat at specific index - use with EnsureCapacity to avoid buffer expansion jitter
        /// </summary>
        public void PaintSplatsAt(int startIndex, Vector3 position, Quaternion rotation, float size, float density, int count, Color color)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
            {
                Debug.LogWarning("Cannot paint splats - invalid asset or render setup");
                return;
            }

            int paintKernel = GetKernelIndex(KernelIndices.PaintSplat);
            if (paintKernel < 0)
            {
                Debug.LogError("PaintSplat kernel not found");
                return;
            }

            EnsureColorTextureIsWritable();

            // Only expand if needed
            int requiredCount = startIndex + count;
            if (requiredCount > m_SplatCount)
            {
                int newSize = ((requiredCount / 500) + 1) * 500;
                try { EditSetSplatCount(newSize); }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                    return;
                }
            }

            using var cmb = new CommandBuffer { name = "PaintSplats" };
            
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintKernel, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintKernel, Props.SplatOther, m_GpuOtherData);
            cmb.SetComputeTextureParam(m_CSBoxUtil, paintKernel, "_PaintColorTexture", m_GpuColorData);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            // After EditSetSplatCount, data is always converted to 32F format (posFormat=0)
            // Use 0 (VECTOR_FMT_32F) to ensure the shader writes data correctly
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            
            for (int i = 0; i < count; i++)
            {
                uint splatIdx = (uint)(startIndex + i);
                
                Vector3 offset = new Vector3(
                    UnityEngine.Random.Range(-size * 0.3f, size * 0.3f),
                    UnityEngine.Random.Range(-size * 0.3f, size * 0.3f),
                    UnityEngine.Random.Range(-size * 0.3f, size * 0.3f)
                );
                
                cmb.SetComputeIntParam(m_CSBoxUtil, "_PaintSplatIndex", (int)splatIdx);
                cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintPosition", position + offset);
                cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintRotation", new Vector4(rotation.x, rotation.y, rotation.z, rotation.w));
                cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintScale", Vector3.one * size);
                // Use actual color alpha scaled by density for proper opacity
                float alpha = Mathf.Clamp01(color.a * density);
                cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintColor", new Vector4(color.r, color.g, color.b, alpha));
                cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintOpacity", density);
                
                cmb.DispatchCompute(m_CSBoxUtil, paintKernel, 1, 1, 1);
            }
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            m_LastAddedSplatPosition = position;
            editModified = true;
        }
        
        // Cached batch buffers for fast painting
        private ComputeBuffer m_PaintBatchPosBuffer;
        private ComputeBuffer m_PaintBatchColorBuffer;
        private ComputeBuffer m_PaintBatchSizeBuffer;
        private int m_PaintBatchBufferSize = 0;
        
        /// <summary>
        /// Fast batched painting - paints multiple splats in one GPU call
        /// </summary>
        public void PaintSplatsBatch(int startIndex, Vector3[] positions, float[] sizes, Color[] colors, int count, float density)
        {
            if (!HasValidAsset || !HasValidRenderSetup || count <= 0)
                return;

            int paintBatchKernel = GetKernelIndex(KernelIndices.PaintSplatBatch);
            if (paintBatchKernel < 0)
            {
                // Fallback to non-batched if kernel not available
                for (int i = 0; i < count; i++)
                    PaintSplatsAt(startIndex + i, positions[i], Quaternion.identity, sizes[i], density, 1, colors[i]);
                return;
            }

            EnsureColorTextureIsWritable();

            // Expand splat buffer if needed
            int requiredCount = startIndex + count;
            if (requiredCount > m_SplatCount)
            {
                int newSize = ((requiredCount / 500) + 1) * 500;
                try { EditSetSplatCount(newSize); }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                    return;
                }
            }
            
            // Ensure batch buffers are sized correctly (reuse to avoid allocation)
            if (m_PaintBatchBufferSize < count)
            {
                int newSize = Mathf.Max(count, 100); // Min 100 to reduce reallocation
                m_PaintBatchPosBuffer?.Release();
                m_PaintBatchColorBuffer?.Release();
                m_PaintBatchSizeBuffer?.Release();
                m_PaintBatchPosBuffer = new ComputeBuffer(newSize, sizeof(float) * 3);
                m_PaintBatchColorBuffer = new ComputeBuffer(newSize, sizeof(float) * 4);
                m_PaintBatchSizeBuffer = new ComputeBuffer(newSize, sizeof(float));
                m_PaintBatchBufferSize = newSize;
            }
            
            // Upload batch data (fast bulk upload)
            m_PaintBatchPosBuffer.SetData(positions, 0, 0, count);
            m_PaintBatchColorBuffer.SetData(colors, 0, 0, count);
            m_PaintBatchSizeBuffer.SetData(sizes, 0, 0, count);
            
            using var cmb = new CommandBuffer { name = "PaintSplatsBatch" };
            
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintBatchKernel, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintBatchKernel, Props.SplatOther, m_GpuOtherData);
            cmb.SetComputeTextureParam(m_CSBoxUtil, paintBatchKernel, "_PaintColorTexture", m_GpuColorData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintBatchKernel, "_PaintBatchPositions", m_PaintBatchPosBuffer);
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintBatchKernel, "_PaintBatchColors", m_PaintBatchColorBuffer);
            cmb.SetComputeBufferParam(m_CSBoxUtil, paintBatchKernel, "_PaintBatchSizes", m_PaintBatchSizeBuffer);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_PaintBatchStartIndex", startIndex);
            cmb.SetComputeIntParam(m_CSBoxUtil, "_PaintBatchCount", count);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintOpacity", density);
            
            // Dispatch once for all splats (thread groups = ceil(count/64))
            int threadGroups = (count + 63) / 64;
            cmb.DispatchCompute(m_CSBoxUtil, paintBatchKernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            if (count > 0)
                m_LastAddedSplatPosition = positions[0];
            editModified = true;
        }
        
        /// <summary>
        /// Cleanup batch buffers
        /// </summary>
        private void CleanupPaintBatchBuffers()
        {
            m_PaintBatchPosBuffer?.Release();
            m_PaintBatchColorBuffer?.Release();
            m_PaintBatchSizeBuffer?.Release();
            m_PaintBatchPosBuffer = null;
            m_PaintBatchColorBuffer = null;
            m_PaintBatchSizeBuffer = null;
            m_PaintBatchBufferSize = 0;
        }
        
        /// <summary>
        /// GPU-only paint - generates random splats entirely on GPU (zero CPU allocation)
        /// </summary>
        public void PaintSplatsGPU(int startIndex, Vector3 localCenter, float scatterRadius, float splatSize,
            Color baseColor, float colorVariation, Vector3 localRight, Vector3 localUp, int count, float density)
        {
            if (!HasValidAsset || !HasValidRenderSetup || count <= 0)
                return;

            int kernel = GetKernelIndex(KernelIndices.PaintSplatsGPU);
            if (kernel < 0)
            {
                // Fallback to batch paint
                var positions = new Vector3[count];
                var sizes = new float[count];
                var colors = new Color[count];
                for (int i = 0; i < count; i++)
                {
                    float angle = UnityEngine.Random.Range(0f, Mathf.PI * 2f);
                    float dist = Mathf.Sqrt(UnityEngine.Random.Range(0f, 1f)) * scatterRadius;
                    positions[i] = localCenter + localRight * (Mathf.Cos(angle) * dist) + localUp * (Mathf.Sin(angle) * dist);
                    sizes[i] = splatSize;
                    colors[i] = baseColor;
                }
                PaintSplatsBatch(startIndex, positions, sizes, colors, count, density);
                return;
            }

            EnsureColorTextureIsWritable();

            // Expand splat buffer if needed
            int requiredCount = startIndex + count;
            if (requiredCount > m_SplatCount)
            {
                int newSize = ((requiredCount / 500) + 1) * 500;
                try { EditSetSplatCount(newSize); }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                    return;
                }
            }

            using var cmb = new CommandBuffer { name = "PaintSplatsGPU" };
            
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatOther, m_GpuOtherData);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernel, "_PaintColorTexture", m_GpuColorData);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintCenter", localCenter);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintScatterRadius", scatterRadius);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintSplatSize", splatSize);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintBaseColor", baseColor);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintColorVariation", colorVariation);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintRightDir", localRight);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintUpDir", localUp);
            m_CSBoxUtil.SetInt("_PaintSeed", (int)((uint)(Time.realtimeSinceStartup * 1000000f) % 0x7FFFFFFF));
            m_CSBoxUtil.SetInt("_PaintStartIndex", startIndex);
            m_CSBoxUtil.SetInt("_PaintSplatCount", count);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintOpacity", density);

            int threadGroups = (count + 63) / 64;
            cmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            editModified = true;
        }
        
        /// <summary>
        /// GPU paint from texture - samples colors from provided texture
        /// </summary>
        public void PaintSplatsFromTextureGPU(int startIndex, Vector3 localCenter, float scatterRadius, float splatSize,
            Texture2D sourceTexture, float tileScale, float rotation, float colorVariation,
            Vector3 localRight, Vector3 localUp, int count, float density)
        {
            if (!HasValidAsset || !HasValidRenderSetup || count <= 0 || sourceTexture == null)
                return;

            int kernel = GetKernelIndex(KernelIndices.PaintSplatsFromTexture);
            if (kernel < 0)
            {
                // Fallback to regular GPU paint with center color
                Color centerColor = sourceTexture.GetPixelBilinear(0.5f, 0.5f);
                PaintSplatsGPU(startIndex, localCenter, scatterRadius, splatSize, centerColor, colorVariation, localRight, localUp, count, density);
                return;
            }

            EnsureColorTextureIsWritable();

            int requiredCount = startIndex + count;
            if (requiredCount > m_SplatCount)
            {
                int newSize = ((requiredCount / 500) + 1) * 500;
                try { EditSetSplatCount(newSize); }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                    return;
                }
            }

            using var cmb = new CommandBuffer { name = "PaintSplatsFromTexture" };
            
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatOther, m_GpuOtherData);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernel, "_PaintColorTexture", m_GpuColorData);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernel, "_PaintSourceTexture", sourceTexture);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintCenter", localCenter);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintScatterRadius", scatterRadius);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintSplatSize", splatSize);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintTextureTileScale", tileScale);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintTextureRotation", rotation * Mathf.Deg2Rad);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintColorVariation", colorVariation);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintRightDir", localRight);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_PaintUpDir", localUp);
            m_CSBoxUtil.SetInt("_PaintSeed", (int)((uint)(Time.realtimeSinceStartup * 1000000f) % 0x7FFFFFFF));
            m_CSBoxUtil.SetInt("_PaintStartIndex", startIndex);
            m_CSBoxUtil.SetInt("_PaintSplatCount", count);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_PaintOpacity", density);

            int threadGroups = (count + 63) / 64;
            cmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            editModified = true;
        }

        /// <summary>
        /// <summary>
        /// Ensures original positions are captured for restore functionality
        /// Call this before starting sculpting operations
        /// </summary>
        public void EnsureOriginalPositionsCaptured()
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            
            if (m_GpuSplatOriginalPositions == null)
            {
                m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
                InitializeOriginalPositions();
                Debug.Log($"Original positions captured for {m_SplatCount} splats");
            }
        }
        
        /// GPU-based smudge brush - moves splats in a direction with falloff
        /// Optimized: reuses command buffer, pre-computes radius squared
        /// </summary>
        private static CommandBuffer s_SmudgeCmb;
        
        public void SmudgeSplatsGPU(Vector3 localCenter, Vector3 localDelta, float localRadius, float falloff, float strength, bool blendColors = false)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
                return;

            int kernel = GetKernelIndex(KernelIndices.SmudgeSplats);
            
            // Try to find kernel if not cached
            if (kernel < 0 && m_CSBoxUtil != null)
            {
                try
                {
                    kernel = m_CSBoxUtil.FindKernel("CSSmudgeSplats");
                    m_KernelIndices[KernelIndices.SmudgeSplats] = kernel;
                }
                catch { }
            }
            
            if (kernel < 0)
            {
                Debug.LogWarning("SmudgeSplats kernel not available - try reimporting BoxUtil.compute");
                return;
            }

            // Reuse command buffer to avoid allocation
            if (s_SmudgeCmb == null)
                s_SmudgeCmb = new CommandBuffer { name = "SmudgeSplats" };
            else
                s_SmudgeCmb.Clear();
            
            s_SmudgeCmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            s_SmudgeCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            s_SmudgeCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            s_SmudgeCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            
            s_SmudgeCmb.SetComputeVectorParam(m_CSBoxUtil, "_SmudgeCenter", localCenter);
            s_SmudgeCmb.SetComputeVectorParam(m_CSBoxUtil, "_SmudgeDelta", localDelta);
            s_SmudgeCmb.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeRadius", localRadius);
            s_SmudgeCmb.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeRadiusSq", localRadius * localRadius);
            s_SmudgeCmb.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeFalloff", falloff);
            s_SmudgeCmb.SetComputeFloatParam(m_CSBoxUtil, "_SmudgeStrength", strength);
            s_SmudgeCmb.SetComputeIntParam(m_CSBoxUtil, "_SmudgeBlendColors", blendColors ? 1 : 0);

            int threadGroups = (m_SplatCount + 255) / 256;
            s_SmudgeCmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(s_SmudgeCmb);
            editModified = true;
        }

        /// <summary>
        /// GPU-based pinch brush - pulls splats toward or pushes away from center
        /// </summary>
        private static CommandBuffer s_PinchCmb;
        
        public void PinchSplatsGPU(Vector3 localCenter, float localRadius, float falloff, float strength)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
                return;

            int kernel = GetKernelIndex(KernelIndices.PinchSplats);
            
            if (kernel < 0 && m_CSBoxUtil != null)
            {
                try
                {
                    kernel = m_CSBoxUtil.FindKernel("CSPinchSplats");
                    m_KernelIndices[KernelIndices.PinchSplats] = kernel;
                }
                catch { }
            }
            
            if (kernel < 0)
            {
                Debug.LogWarning("PinchSplats kernel not available - try reimporting BoxUtil.compute");
                return;
            }

            if (s_PinchCmb == null)
                s_PinchCmb = new CommandBuffer { name = "PinchSplats" };
            else
                s_PinchCmb.Clear();
            
            s_PinchCmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            s_PinchCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            s_PinchCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            s_PinchCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            
            s_PinchCmb.SetComputeVectorParam(m_CSBoxUtil, "_PinchCenter", localCenter);
            s_PinchCmb.SetComputeFloatParam(m_CSBoxUtil, "_PinchRadius", localRadius);
            s_PinchCmb.SetComputeFloatParam(m_CSBoxUtil, "_PinchRadiusSq", localRadius * localRadius);
            s_PinchCmb.SetComputeFloatParam(m_CSBoxUtil, "_PinchFalloff", falloff);
            s_PinchCmb.SetComputeFloatParam(m_CSBoxUtil, "_PinchStrength", strength);

            int threadGroups = (m_SplatCount + 255) / 256;
            s_PinchCmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(s_PinchCmb);
            editModified = true;
        }

        /// <summary>
        /// GPU-based flatten brush - projects splats onto a plane
        /// </summary>
        private static CommandBuffer s_FlattenCmb;
        
        public void FlattenSplatsGPU(Vector3 localPlanePoint, Vector3 localPlaneNormal, float localRadius, float falloff, float strength)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
                return;

            int kernel = GetKernelIndex(KernelIndices.FlattenSplats);
            
            if (kernel < 0 && m_CSBoxUtil != null)
            {
                try
                {
                    kernel = m_CSBoxUtil.FindKernel("CSFlattenSplats");
                    m_KernelIndices[KernelIndices.FlattenSplats] = kernel;
                }
                catch { }
            }
            
            if (kernel < 0)
            {
                Debug.LogWarning("FlattenSplats kernel not available - try reimporting BoxUtil.compute");
                return;
            }

            if (s_FlattenCmb == null)
                s_FlattenCmb = new CommandBuffer { name = "FlattenSplats" };
            else
                s_FlattenCmb.Clear();
            
            s_FlattenCmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            s_FlattenCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            s_FlattenCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            s_FlattenCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            
            s_FlattenCmb.SetComputeVectorParam(m_CSBoxUtil, "_FlattenPlanePoint", localPlanePoint);
            s_FlattenCmb.SetComputeVectorParam(m_CSBoxUtil, "_FlattenPlaneNormal", localPlaneNormal.normalized);
            s_FlattenCmb.SetComputeFloatParam(m_CSBoxUtil, "_FlattenRadius", localRadius);
            s_FlattenCmb.SetComputeFloatParam(m_CSBoxUtil, "_FlattenRadiusSq", localRadius * localRadius);
            s_FlattenCmb.SetComputeFloatParam(m_CSBoxUtil, "_FlattenFalloff", falloff);
            s_FlattenCmb.SetComputeFloatParam(m_CSBoxUtil, "_FlattenStrength", strength);

            int threadGroups = (m_SplatCount + 255) / 256;
            s_FlattenCmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(s_FlattenCmb);
            editModified = true;
        }

        /// <summary>
        /// GPU-based relax brush - smooths splats by averaging positions with neighbors
        /// </summary>
        private static CommandBuffer s_RelaxCmb;
        
        public void RelaxSplatsGPU(Vector3 localCenter, float localRadius, float falloff, float strength, float neighborRadius, bool invert = false)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
                return;

            int kernel = GetKernelIndex(KernelIndices.RelaxSplats);
            
            if (kernel < 0 && m_CSBoxUtil != null)
            {
                try
                {
                    kernel = m_CSBoxUtil.FindKernel("CSRelaxSplats");
                    m_KernelIndices[KernelIndices.RelaxSplats] = kernel;
                }
                catch { }
            }
            
            if (kernel < 0)
            {
                Debug.LogWarning("RelaxSplats kernel not available - try reimporting BoxUtil.compute");
                return;
            }

            if (s_RelaxCmb == null)
                s_RelaxCmb = new CommandBuffer { name = "RelaxSplats" };
            else
                s_RelaxCmb.Clear();
            
            s_RelaxCmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            s_RelaxCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            s_RelaxCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            s_RelaxCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            
            s_RelaxCmb.SetComputeVectorParam(m_CSBoxUtil, "_RelaxCenter", localCenter);
            s_RelaxCmb.SetComputeFloatParam(m_CSBoxUtil, "_RelaxRadius", localRadius);
            s_RelaxCmb.SetComputeFloatParam(m_CSBoxUtil, "_RelaxRadiusSq", localRadius * localRadius);
            s_RelaxCmb.SetComputeFloatParam(m_CSBoxUtil, "_RelaxFalloff", falloff);
            s_RelaxCmb.SetComputeFloatParam(m_CSBoxUtil, "_RelaxStrength", strength);
            s_RelaxCmb.SetComputeFloatParam(m_CSBoxUtil, "_RelaxNeighborRadius", neighborRadius);
            s_RelaxCmb.SetComputeIntParam(m_CSBoxUtil, "_RelaxInvert", invert ? 1 : 0);

            int threadGroups = (m_SplatCount + 255) / 256;
            s_RelaxCmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(s_RelaxCmb);
            editModified = true;
        }

        private static CommandBuffer s_RestorePosCmb;
        
        /// <summary>
        /// Restores splat positions to their original positions within a sphere (for sculpt brush ALT mode)
        /// </summary>
        public void RestorePositionsInSphereGPU(Vector3 localCenter, float localRadius, float falloff, float strength)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
                return;
            
            // Ensure original positions buffer exists - create and initialize if needed
            if (m_GpuSplatOriginalPositions == null && m_SplatCount > 0)
            {
                m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
                InitializeOriginalPositions();
                Debug.Log("Original positions buffer created for restore functionality");
            }
            
            if (m_GpuSplatOriginalPositions == null)
            {
                Debug.LogWarning("Original positions buffer not available - cannot restore");
                return;
            }

            int kernel = GetKernelIndex(KernelIndices.RestorePositionsInSphere);
            
            if (kernel < 0 && m_CSBoxUtil != null)
            {
                try
                {
                    kernel = m_CSBoxUtil.FindKernel("CSRestorePositionsInSphere");
                    m_KernelIndices[KernelIndices.RestorePositionsInSphere] = kernel;
                }
                catch { }
            }
            
            if (kernel < 0)
            {
                Debug.LogWarning("RestorePositionsInSphere kernel not available - try reimporting BoxUtil.compute");
                return;
            }

            if (s_RestorePosCmb == null)
                s_RestorePosCmb = new CommandBuffer { name = "RestorePositionsInSphere" };
            else
                s_RestorePosCmb.Clear();
            
            s_RestorePosCmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatPos, m_GpuPosData);
            s_RestorePosCmb.SetComputeBufferParam(m_CSBoxUtil, kernel, Props.SplatOriginalPositions, m_GpuSplatOriginalPositions);
            s_RestorePosCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            s_RestorePosCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, 0);
            s_RestorePosCmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0);
            
            s_RestorePosCmb.SetComputeVectorParam(m_CSBoxUtil, "_RestorePosCenter", localCenter);
            s_RestorePosCmb.SetComputeFloatParam(m_CSBoxUtil, "_RestorePosRadius", localRadius);
            s_RestorePosCmb.SetComputeFloatParam(m_CSBoxUtil, "_RestorePosRadiusSq", localRadius * localRadius);
            s_RestorePosCmb.SetComputeFloatParam(m_CSBoxUtil, "_RestorePosFalloff", falloff);
            s_RestorePosCmb.SetComputeFloatParam(m_CSBoxUtil, "_RestorePosStrength", strength);

            int threadGroups = (m_SplatCount + 255) / 256;
            s_RestorePosCmb.DispatchCompute(m_CSBoxUtil, kernel, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(s_RestorePosCmb);
            editModified = true;
        }

        // Helper methods for quaternion packing
        private uint EncodeQuatToNorm10(quaternion q)
        {
            // Pack to 10 bits per component
            const uint mask = (1u << 10) - 1u;
            uint x = (uint)(math.saturate((q.value.x + 1f) * 0.5f) * mask);
            uint y = (uint)(math.saturate((q.value.y + 1f) * 0.5f) * mask);
            uint z = (uint)(math.saturate((q.value.z + 1f) * 0.5f) * mask);
            return (x << 20) | (y << 10) | z;
        }

        private quaternion PackSmallest3Rotation(Quaternion q)
        {
            // Find smallest component
            float x = math.abs(q.x), y = math.abs(q.y);
            float z = math.abs(q.z), w = math.abs(q.w);
            int idx = 0;
            float min = x;
            if (y < min) { min = y; idx = 1; }
            if (z < min) { min = z; idx = 2; }
            if (w < min) { idx = 3; }

            // Pack to 3 components, dropping smallest
            quaternion result = quaternion.identity;
            switch (idx)
            {
                case 0: result.value = new float4(0, q.y, q.z, q.w); break;
                case 1: result.value = new float4(q.x, 0, q.z, q.w); break;
                case 2: result.value = new float4(q.x, q.y, 0, q.w); break;
                case 3: result.value = new float4(q.x, q.y, q.z, 0); break;
            }
            return result;
        }

        // Helper to reinterpret float as uint (compatible with older Unity versions)
        private static unsafe uint FloatAsUInt(float f)
        {
            return *(uint*)&f;
        }
        
        private static uint FloatToSortableUint(float f)
        {
            // Matches shader FloatToSortableUint (see http://stereopsis.com/radix.html)
            uint fu = FloatAsUInt(f);
            uint mask = (uint)(-(int)(fu >> 31)) | 0x80000000u;
            return fu ^ mask;
        }

        public GraphicsBuffer GpuPosData => m_GpuPosData;
        public GraphicsBuffer GpuOtherData => m_GpuOtherData;
        public GraphicsBuffer GpuSHData => m_GpuSHData;
        public Texture GpuColorData => m_GpuColorData;
        public GraphicsBuffer GpuChunks => m_GpuChunks;
        public GraphicsBuffer GpuView => m_GpuView;
        public GraphicsBuffer GpuSortKeys => m_GpuSortKeys;
        public ComputeShader ComputeShader => m_CSBoxUtil;
        public bool GpuChunksValid => m_GpuChunksValid;
        public GraphicsBuffer GpuVelocities => m_GpuSplatVelocities;

        // Track last added splat position for debug visualization
        private Vector3 m_LastAddedSplatPosition;

#if UNITY_EDITOR
        public Vector3 LastAddedSplatPosition => m_LastAddedSplatPosition;

    
void OnDrawGizmos()
{
    if (editModified)
    {
        // Draw the last added splat
        Vector3 worldPos = transform.TransformPoint(m_LastAddedSplatPosition);
        
        // Draw a large sphere
        Gizmos.color = new Color(1f, 0.5f, 0f, 0.8f);
        Gizmos.DrawWireSphere(worldPos, 1.0f);
        
        // Draw axes
        Gizmos.color = Color.red;
        Gizmos.DrawRay(worldPos, Vector3.right);
        Gizmos.color = Color.green;
        Gizmos.DrawRay(worldPos, Vector3.up);
        Gizmos.color = Color.blue;
        Gizmos.DrawRay(worldPos, Vector3.forward);
        
        // Draw debug info
        UnityEditor.Handles.color = Color.white;
        UnityEditor.Handles.Label(worldPos + Vector3.up, 
            $"Splat Count: {m_SplatCount}\n" +
            $"World Pos: {worldPos}\n" +
            $"Local Pos: {m_LastAddedSplatPosition}\n" +
            $"Valid Setup: {HasValidRenderSetup}\n" +
            $"Valid Asset: {HasValidAsset}");
    }
}
#endif

        public void UpdateSphereColliders(SphereColliderData[] colliders)
        {
            if (m_GpuSphereColliders == null || colliders == null) return;
            
            // Resize buffer if needed
            if (colliders.Length > m_GpuSphereColliders.count)
            {
                m_GpuSphereColliders?.Dispose();
                m_GpuSphereColliders = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 
                    Mathf.Max(colliders.Length, 10), 36) { name = "SphereColliders" };
            }
            
            if (colliders.Length > 0)
            {
                m_GpuSphereColliders.SetData(colliders);
            }
        }

        /// <summary>
        /// Deletes splats that are inside the specified sphere (GPU-optimized for VR)
        /// Note: Does NOT require physics to be enabled - works independently of physics system
        /// </summary>
        /// <param name="sphereCenter">Center of the sphere in world space</param>
        /// <param name="sphereRadius">Radius of the sphere</param>
        public void DeleteSplatsInSphere(Vector3 sphereCenter, float sphereRadius)
        {
            DeleteSplatsInSphereWithFalloff(sphereCenter, sphereRadius, 0f, 0f, 1f, 0f);
        }

        /// <summary>
        /// Deletes splats within a sphere with falloff and noise for organic deletion patterns
        /// </summary>
        /// <param name="sphereCenter">Center of the sphere in world space</param>
        /// <param name="sphereRadius">Radius of the sphere</param>
        /// <param name="falloff">Falloff strength (0 = hard edge, 1 = smooth gradient)</param>
        /// <param name="noiseStrength">Amount of noise (0 = none, 1 = maximum)</param>
        /// <param name="noiseScale">Scale of noise pattern</param>
        /// <param name="noiseTime">Time offset for animated noise</param>
        public void DeleteSplatsInSphereWithFalloff(Vector3 sphereCenter, float sphereRadius, 
            float falloff, float noiseStrength, float noiseScale, float noiseTime, bool useColorFilter = false, Color colorFilter = default, float colorThreshold = 0.1f)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
            {
                Debug.LogWarning($"DeleteSplats: Invalid state - HasValidAsset={HasValidAsset}, HasValidRenderSetup={HasValidRenderSetup}, splatCount={m_SplatCount}");
                return;
            }

            // Ensure editing buffers exist
            if (!EnsureEditingBuffers())
            {
                Debug.LogWarning("Cannot delete splats: Editing buffers not available");
                return;
            }
            
            // Debug: Show brush position vs asset bounds
            Vector3 localCenter = (asset.boundsMin + asset.boundsMax) * 0.5f;
            Vector3 worldCenter = transform.TransformPoint(localCenter);
            int chunkCount = m_GpuChunksValid ? m_GpuChunks.count : 0;
            
            // Debug logging removed - was too verbose for production use

            // Get the actual kernel index
            int kernelIndex = GetKernelIndex(KernelIndices.MarkSphereForDeletion);
            if (kernelIndex < 0)
            {
                Debug.LogError("Failed to find MarkSphereForDeletion kernel");
                return;
            }

            // GPU-based deletion - no CPU readback needed!
            using var cmb = new CommandBuffer { name = "DeleteSplatsInSphere" };
            
            // Set deletion sphere parameters
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_DeletionSphereCenter", sphereCenter);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionSphereRadius", sphereRadius);
            
            // Set falloff and noise parameters
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionFalloff", falloff);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseStrength", noiseStrength);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseScale", noiseScale);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseTime", noiseTime);

            // Color filtering
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.UseColorFilter, useColorFilter ? 1 : 0);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.DeletionColorFilter, new Vector4(colorFilter.r, colorFilter.g, colorFilter.b, colorFilter.a));
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.DeletionColorThreshold, colorThreshold);
            
            // Set required buffers and parameters
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatChunks, m_GpuChunks);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatDeletedBits, m_GpuEditDeleted);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernelIndex, Props.SplatColor, m_GpuColorData);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
            
            // Dispatch compute shader
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
            int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
            cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            editModified = true;
            UpdateEditCountsAndBounds();
        }
        
        /// <summary>
        /// Reset all deleted splats, restoring them to visible state
        /// </summary>
        public void ResetDeletedSplats()
        {
            if (m_GpuEditDeleted == null)
            {
                Debug.LogWarning("No deleted splats buffer to reset");
                return;
            }
            
            ClearGraphicsBuffer(m_GpuEditDeleted);
            editModified = true;
            UpdateEditCountsAndBounds();
            Debug.Log($"[SplatBoxRenderer] Reset all deleted splats - now visible: {m_SplatCount - editDeletedSplats}");
        }
        
        /// <summary>
        /// Sample average color from splat color texture at a world position
        /// </summary>
        public Color SampleColorAtPosition(Vector3 worldPosition)
        {
            if (!HasValidAsset || m_GpuColorData == null)
                return Color.gray;
            
            // Convert world to local position
            Vector3 localPos = transform.InverseTransformPoint(worldPosition);
            
            // Normalize to 0-1 range within bounds
            Vector3 boundsSize = asset.boundsMax - asset.boundsMin;
            if (boundsSize.x < 0.001f || boundsSize.y < 0.001f || boundsSize.z < 0.001f)
                return Color.gray;
            
            Vector3 normalizedPos = new Vector3(
                (localPos.x - asset.boundsMin.x) / boundsSize.x,
                (localPos.y - asset.boundsMin.y) / boundsSize.y,
                (localPos.z - asset.boundsMin.z) / boundsSize.z
            );
            
            // Clamp to valid range
            normalizedPos.x = Mathf.Clamp01(normalizedPos.x);
            normalizedPos.y = Mathf.Clamp01(normalizedPos.y);
            normalizedPos.z = Mathf.Clamp01(normalizedPos.z);
            
            // Try to read from texture (only if readable)
            if (m_GpuColorData is Texture2D tex2D && tex2D.isReadable)
            {
                try
                {
                    // Use normalized X as U, combine Y and Z for V
                    float u = normalizedPos.x;
                    float v = (normalizedPos.y + normalizedPos.z) * 0.5f;
                    return tex2D.GetPixelBilinear(u, v);
                }
                catch
                {
                    // Texture not readable - fall through to procedural color
                }
            }
            
            // Fallback: generate color based on position
            return GenerateColorFromPosition(normalizedPos);
        }
        
        /// <summary>
        /// Sample multiple colors near a world position and return array
        /// </summary>
        public Color[] SampleColorsNearPosition(Vector3 worldPosition, float radius, int sampleCount)
        {
            Color[] colors = new Color[sampleCount];
            
            for (int i = 0; i < sampleCount; i++)
            {
                Vector3 offset = UnityEngine.Random.insideUnitSphere * radius;
                colors[i] = SampleColorAtPosition(worldPosition + offset);
            }
            
            return colors;
        }
        
        /// <summary>
        /// Get average color near a world position
        /// </summary>
        public Color GetAverageColorNearPosition(Vector3 worldPosition, float radius)
        {
            Color[] samples = SampleColorsNearPosition(worldPosition, radius, 5);
            
            float r = 0, g = 0, b = 0, a = 0;
            foreach (var c in samples)
            {
                r += c.r;
                g += c.g;
                b += c.b;
                a += c.a;
            }
            
            int count = samples.Length;
            return new Color(r / count, g / count, b / count, a / count);
        }
        
        private Color GenerateColorFromPosition(Vector3 normalizedPos)
        {
            // Generate a plausible color based on position
            // This is a fallback when we can't read the actual texture
            float hue = normalizedPos.x * 0.3f + 0.1f; // Warm tones
            float sat = 0.3f + normalizedPos.y * 0.4f;
            float val = 0.5f + normalizedPos.z * 0.4f;
            return Color.HSVToRGB(hue, sat, val);
        }
        
        /// <summary>
        /// Debug: Read back a sample of splat positions to verify chunk decoding
        /// </summary>
        public void DebugReadSplatPositions()
        {
            if (!HasValidAsset || m_GpuPosData == null)
            {
                Debug.LogError("No valid asset or position data");
                return;
            }
            
            // Read raw position data
            int stride = 4; // Norm11 is 4 bytes per position
            if (asset.posFormat == GaussianSplatAsset.VectorFormat.Float32) stride = 12;
            else if (asset.posFormat == GaussianSplatAsset.VectorFormat.Norm16) stride = 6;
            else if (asset.posFormat == GaussianSplatAsset.VectorFormat.Norm6) stride = 2;
            
            int sampleCount = Mathf.Min(5, m_SplatCount);
            byte[] rawData = new byte[stride * sampleCount];
            m_GpuPosData.GetData(rawData, 0, 0, stride * sampleCount);
            
            Debug.Log($"[DEBUG POSITIONS] Format={asset.posFormat}, stride={stride}, samples={sampleCount}");
            Debug.Log($"[DEBUG POSITIONS] Asset bounds: min={asset.boundsMin}, max={asset.boundsMax}");
            Debug.Log($"[DEBUG POSITIONS] ChunksValid={m_GpuChunksValid}, ChunkCount={(m_GpuChunks != null ? m_GpuChunks.count : 0)}");
            
            // Read chunk data for first chunk
            // SplatChunkInfo struct: 4 uints (color) + 3 float2s (pos) + 3 uints (scale) + 3 uints (sh) = 16 floats = 64 bytes
            if (m_GpuChunks != null && m_GpuChunks.count > 0)
            {
                // Read full chunk struct (64 bytes = 16 uints)
                uint[] chunkRaw = new uint[16];
                m_GpuChunks.GetData(chunkRaw, 0, 0, 16);
                
                // Extract position bounds (floats at indices 4-9, corresponding to posX.xy, posY.xy, posZ.xy)
                float posXMin = System.BitConverter.ToSingle(System.BitConverter.GetBytes(chunkRaw[4]), 0);
                float posXMax = System.BitConverter.ToSingle(System.BitConverter.GetBytes(chunkRaw[5]), 0);
                float posYMin = System.BitConverter.ToSingle(System.BitConverter.GetBytes(chunkRaw[6]), 0);
                float posYMax = System.BitConverter.ToSingle(System.BitConverter.GetBytes(chunkRaw[7]), 0);
                float posZMin = System.BitConverter.ToSingle(System.BitConverter.GetBytes(chunkRaw[8]), 0);
                float posZMax = System.BitConverter.ToSingle(System.BitConverter.GetBytes(chunkRaw[9]), 0);
                
                Debug.Log($"[DEBUG POSITIONS] Chunk[0] position bounds: X=[{posXMin:F4},{posXMax:F4}], Y=[{posYMin:F4},{posYMax:F4}], Z=[{posZMin:F4},{posZMax:F4}]");
                
                // Calculate what a splat at [0.5,0.5,0.5] would decode to
                float midX = Mathf.Lerp(posXMin, posXMax, 0.5f);
                float midY = Mathf.Lerp(posYMin, posYMax, 0.5f);
                float midZ = Mathf.Lerp(posZMin, posZMax, 0.5f);
                Debug.Log($"[DEBUG POSITIONS] Chunk[0] midpoint (local): ({midX:F4}, {midY:F4}, {midZ:F4})");
                
                // Transform to world
                Vector3 worldMid = transform.TransformPoint(new Vector3(midX, midY, midZ));
                Debug.Log($"[DEBUG POSITIONS] Chunk[0] midpoint (world): ({worldMid.x:F2}, {worldMid.y:F2}, {worldMid.z:F2})");
            }
            
            // For Norm11, decode raw positions
            if (asset.posFormat == GaussianSplatAsset.VectorFormat.Norm11)
            {
                for (int i = 0; i < sampleCount; i++)
                {
                    int offset = i * 4;
                    uint packed = System.BitConverter.ToUInt32(rawData, offset);
                    uint x = packed & 0x7FF;
                    uint y = (packed >> 11) & 0x3FF;
                    uint z = (packed >> 21) & 0x7FF;
                    
                    // Decode to [0,1] range
                    float fx = x / 2047.0f;
                    float fy = y / 1023.0f;
                    float fz = z / 2047.0f;
                    
                    Debug.Log($"[DEBUG POSITIONS] Splat[{i}] raw=[{fx:F4},{fy:F4},{fz:F4}] (needs chunk lerp)");
                }
            }
        }

        /// <summary>
        /// Restores previously deleted splats within a sphere
        /// </summary>
        /// <param name="sphereCenter">Center of the sphere in world space</param>
        /// <param name="sphereRadius">Radius of the sphere</param>
        public void RestoreSplatsInSphere(Vector3 sphereCenter, float sphereRadius)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;

            // Ensure editing buffers exist
            if (!EnsureEditingBuffers())
            {
                Debug.LogWarning("Cannot restore splats: Editing buffers not available");
                return;
            }

            // Get the actual kernel index
            int kernelIndex = GetKernelIndex(KernelIndices.RestoreSphereFromDeletion);
            if (kernelIndex < 0)
            {
                Debug.LogError("Failed to find RestoreSphereFromDeletion kernel");
                return;
            }

            // GPU-based restoration
            using var cmb = new CommandBuffer { name = "RestoreSplatsInSphere" };
            
            // Set restoration sphere parameters (reusing deletion variables)
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_DeletionSphereCenter", sphereCenter);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionSphereRadius", sphereRadius);
            
            // Set required buffers and parameters
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatChunks, m_GpuChunks);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatDeletedBits, m_GpuEditDeleted);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
            
            // Dispatch compute shader
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
            int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
            cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            editModified = true;
        }

        // Cached buffer for clone operations
        private GraphicsBuffer m_CloneCountBuffer;
        private const int kMaxClonePerOperation = 500000;

        /// <summary>
        /// Clones splats from a source sphere to a target position (GPU-optimized)
        /// </summary>
        /// <param name="sourcePosition">World-space center of the source sphere</param>
        /// <param name="targetPosition">World-space center where cloned splats will be placed</param>
        /// <param name="radius">Radius of the clone brush</param>
        /// <param name="falloff">Falloff at the edge of the brush (0-1)</param>
        public void CloneSplatsInSphere(Vector3 sourcePosition, Vector3 targetPosition, float radius, float falloff)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;

            // Check if cloning is supported (only VeryHigh quality without chunks)
            if (asset.chunkData != null)
            {
                Debug.LogWarning("Clone not supported: Only VeryHigh quality splats can be cloned. Please re-import the asset with VeryHigh quality.");
                return;
            }

            int countKernel = GetKernelIndex(KernelIndices.CloneSplatsInSphere);
            int copyKernel = GetKernelIndex(KernelIndices.CopySplatsWithOffset);
            
            if (countKernel < 0 || copyKernel < 0)
            {
                Debug.LogWarning("Clone kernels not available");
                return;
            }

            // Calculate offset for cloning (Target - Source)
            Vector3 offset = targetPosition - sourcePosition;

            // Get bounds info for debugging
            Bounds worldBounds = GetWorldBounds();
            
            bool insideBounds = worldBounds.Contains(sourcePosition);

            // Create or ensure clone count buffer exists
            if (m_CloneCountBuffer == null || m_CloneCountBuffer.count < kMaxClonePerOperation + 1)
            {
                m_CloneCountBuffer?.Dispose();
                m_CloneCountBuffer = new GraphicsBuffer(GraphicsBuffer.Target.Structured, kMaxClonePerOperation + 1, 4) { name = "CloneCountBuffer" };
            }

            // Clear count buffer
            uint[] clearData = new uint[1] { 0 };
            m_CloneCountBuffer.SetData(clearData, 0, 0, 1);

            // Pass 1: Count splats in source sphere and store their indices
            try
            {
                using (var cmb = new CommandBuffer { name = "CloneCount" })
                {
                    cmb.SetComputeBufferParam(m_CSBoxUtil, countKernel, Props.SplatPos, m_GpuPosData);
                    cmb.SetComputeBufferParam(m_CSBoxUtil, countKernel, Props.SplatChunks, m_GpuChunks);
                    cmb.SetComputeBufferParam(m_CSBoxUtil, countKernel, "_CloneCountBuffer", m_CloneCountBuffer);
                    cmb.SetComputeVectorParam(m_CSBoxUtil, "_CloneSourceCenter", sourcePosition);
                    cmb.SetComputeVectorParam(m_CSBoxUtil, "_CloneTargetCenter", targetPosition);
                    cmb.SetComputeFloatParam(m_CSBoxUtil, "_CloneRadius", radius);
                    cmb.SetComputeFloatParam(m_CSBoxUtil, "_CloneFalloff", falloff);
                    cmb.SetComputeIntParam(m_CSBoxUtil, "_CloneMaxCount", kMaxClonePerOperation);
                    cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
                    cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                    cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
                    // Pass the full format (pos, scale, sh) for LoadSplatPos to work correctly
                    uint countFormat = (uint)asset.posFormat | ((uint)asset.scaleFormat << 8) | ((uint)asset.shFormat << 16);
                    cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)countFormat);

                    m_CSBoxUtil.GetKernelThreadGroupSizes(countKernel, out uint gsX, out _, out _);
                    int threadGroups = (m_SplatCount + (int)gsX - 1) / (int)gsX;
                    cmb.DispatchCompute(m_CSBoxUtil, countKernel, threadGroups, 1, 1);
                    Graphics.ExecuteCommandBuffer(cmb);
                }
            }
            catch (System.Exception e)
            {
                Debug.LogError($"CLONE: Count pass failed: {e.Message}");
                return;
            }

            // Read back count
            uint[] countData = new uint[1];
            m_CloneCountBuffer.GetData(countData, 0, 0, 1);
            int cloneCount = (int)Mathf.Min(countData[0], kMaxClonePerOperation);


            if (cloneCount == 0)
            {
                // Calculate world scale to help with radius sizing
                float avgScale = (transform.lossyScale.x + transform.lossyScale.y + transform.lossyScale.z) / 3f;
                Debug.LogWarning($"CLONE: No splats found at source ({sourcePosition.x:F2},{sourcePosition.y:F2},{sourcePosition.z:F2}). " +
                    $"Radius={radius:F2}, Transform scale={avgScale:F2}. " +
                    $"Try radius={Mathf.Max(radius * 2f, 1f):F1} or higher.");
                return;
            }

            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;

            // Expand buffers
            try
            {
                EditSetSplatCount(newCount);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer for cloning: {e.Message}");
                return;
            }

            // Pass 2: Copy splat data with offset (GPU-based)
            // After EditSetSplatCount, data is converted to 32F format (VECTOR_FMT_32F = 0)
            // CSCopySplats outputs: pos=32F (stride 12), scale=32F (stride 16 total), SH=32F (stride 192)
            uint cloneFormat = 0 | (0 << 8) | (0 << 16); // All 32F after resize
            
            using (var cmb = new CommandBuffer { name = "CloneCopy" })
            {
                cmb.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.SplatPos, m_GpuPosData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.SplatOther, m_GpuOtherData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.SplatSH, m_GpuSHData);
                cmb.SetComputeBufferParam(m_CSBoxUtil, copyKernel, Props.SplatChunks, m_GpuChunks);
                cmb.SetComputeBufferParam(m_CSBoxUtil, copyKernel, "_CloneCountBuffer", m_CloneCountBuffer);
                cmb.SetComputeVectorParam(m_CSBoxUtil, "_CloneSourceCenter", sourcePosition);
                cmb.SetComputeVectorParam(m_CSBoxUtil, "_CloneTargetCenter", targetPosition);
                cmb.SetComputeIntParam(m_CSBoxUtil, "_CloneDestStartIndex", oldCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, "_CloneMaxCount", kMaxClonePerOperation);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, transform.worldToLocalMatrix);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, 0); // No chunks after resize
                cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)cloneFormat);

                m_CSBoxUtil.GetKernelThreadGroupSizes(copyKernel, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, copyKernel, (cloneCount + (int)gsX - 1) / (int)gsX, 1, 1);
                Graphics.ExecuteCommandBuffer(cmb);
            }
            
            // Copy color data on GPU
            CopyColorDataForClonedSplatsGPU(oldCount, cloneCount);

            Debug.Log($"CLONE: Copied {cloneCount} splats with offset ({offset.x:F2},{offset.y:F2},{offset.z:F2})");

            editModified = true;
            
            // Force update to refresh rendering - this updates counts and bounds
            UpdateEditCountsAndBounds();
            
            // Force re-sort on next frame by resetting frame counter
            m_FrameCounter = 0;
            
            // Force renderer to refresh
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }

        /// <summary>
        /// Clones splats from a source box to a target position
        /// </summary>
        /// <param name="sourcePosition">World-space center of the source box</param>
        /// <param name="targetPosition">World-space center where cloned splats will be placed</param>
        /// <param name="boxSize">Size of the box (width, height, depth)</param>
        public void CloneSplatsInBox(Vector3 sourcePosition, Vector3 targetPosition, Vector3 boxSize)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;

            // Check if cloning is supported (only VeryHigh quality without chunks)
            if (asset.chunkData != null)
            {
                Debug.LogWarning("Clone not supported: Only VeryHigh quality splats can be cloned.");
                return;
            }

            // Convert box to local space for bounds checking
            Vector3 localSourceCenter = transform.InverseTransformPoint(sourcePosition);
            Vector3 localBoxSize = Vector3.Scale(boxSize, new Vector3(
                1f / transform.lossyScale.x,
                1f / transform.lossyScale.y,
                1f / transform.lossyScale.z
            ));
            
            Bounds localBounds = new Bounds(localSourceCenter, localBoxSize);
            
            // Find splats within the box (CPU-based for accuracy)
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("Clone only supports Float32 position format");
                return;
            }
            
            // Read all positions
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            // Find splats in box
            List<int> splatsInBox = new List<int>();
            for (int i = 0; i < m_SplatCount && splatsInBox.Count < kMaxClonePerOperation; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                if (localBounds.Contains(localPos))
                {
                    splatsInBox.Add(i);
                }
            }
            
            int cloneCount = splatsInBox.Count;
            if (cloneCount == 0)
            {
                Debug.LogWarning($"CLONE: No splats found in box at ({sourcePosition.x:F2},{sourcePosition.y:F2},{sourcePosition.z:F2}). " +
                    $"Box size=({boxSize.x:F2},{boxSize.y:F2},{boxSize.z:F2}). Try larger size.");
                return;
            }
            
            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;
            
            // Expand buffers
            try
            {
                EditSetSplatCount(newCount);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer for cloning: {e.Message}");
                return;
            }
            
            // Calculate offset in local space
            Vector3 localTargetCenter = transform.InverseTransformPoint(targetPosition);
            Vector3 localOffset = localTargetCenter - localSourceCenter;
            
            // Copy splat data with offset (CPU-based)
            // Re-read position data after resize (it's been converted to 32F)
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            float[] otherData = new float[newCount * 4]; // rot(1) + scale(3)
            m_GpuOtherData.GetData(otherData, 0, 0, oldCount * 4);
            
            // Copy splats with offset
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInBox[i];
                int dstIdx = oldCount + i;
                
                // Copy position with offset
                newPosData[dstIdx * 3 + 0] = newPosData[srcIdx * 3 + 0] + localOffset.x;
                newPosData[dstIdx * 3 + 1] = newPosData[srcIdx * 3 + 1] + localOffset.y;
                newPosData[dstIdx * 3 + 2] = newPosData[srcIdx * 3 + 2] + localOffset.z;
                
                // Copy rotation and scale
                otherData[dstIdx * 4 + 0] = otherData[srcIdx * 4 + 0];
                otherData[dstIdx * 4 + 1] = otherData[srcIdx * 4 + 1];
                otherData[dstIdx * 4 + 2] = otherData[srcIdx * 4 + 2];
                otherData[dstIdx * 4 + 3] = otherData[srcIdx * 4 + 3];
            }
            
            // Write back to GPU
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(otherData);
            
            // Copy SH data
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInBox[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            // Copy color data
            CopyColorDataForClonedSplatsInBox(oldCount, splatsInBox);
            
            Vector3 offset = targetPosition - sourcePosition;
            Debug.Log($"CLONE: Copied {cloneCount} splats with offset ({offset.x:F2},{offset.y:F2},{offset.z:F2})");
            
            editModified = true;
            
            // Force update to refresh rendering
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Clones splats from source box to target position with color adjustments
        /// </summary>
        public void CloneSplatsInBox(Vector3 sourcePosition, Vector3 targetPosition, Vector3 boxSize, ColorAdjustments colorAdj)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;

            if (asset.chunkData != null)
            {
                Debug.LogWarning("Clone not supported: Only VeryHigh quality splats can be cloned.");
                return;
            }

            Vector3 localSourceCenter = transform.InverseTransformPoint(sourcePosition);
            Vector3 localBoxSize = Vector3.Scale(boxSize, new Vector3(
                1f / transform.lossyScale.x,
                1f / transform.lossyScale.y,
                1f / transform.lossyScale.z
            ));
            
            Bounds localBounds = new Bounds(localSourceCenter, localBoxSize);
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("Clone only supports Float32 position format");
                return;
            }
            
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            List<int> splatsInBox = new List<int>();
            for (int i = 0; i < m_SplatCount && splatsInBox.Count < kMaxClonePerOperation; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                if (localBounds.Contains(localPos))
                    splatsInBox.Add(i);
            }
            
            int cloneCount = splatsInBox.Count;
            if (cloneCount == 0)
            {
                Debug.LogWarning($"CLONE: No splats found in box. Try larger size.");
                return;
            }
            
            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;
            
            try { EditSetSplatCount(newCount); }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                return;
            }
            
            Vector3 localTargetCenter = transform.InverseTransformPoint(targetPosition);
            Vector3 localOffset = localTargetCenter - localSourceCenter;
            
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            float[] otherData = new float[newCount * 4];
            m_GpuOtherData.GetData(otherData, 0, 0, oldCount * 4);
            
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInBox[i];
                int dstIdx = oldCount + i;
                
                newPosData[dstIdx * 3 + 0] = newPosData[srcIdx * 3 + 0] + localOffset.x;
                newPosData[dstIdx * 3 + 1] = newPosData[srcIdx * 3 + 1] + localOffset.y;
                newPosData[dstIdx * 3 + 2] = newPosData[srcIdx * 3 + 2] + localOffset.z;
                
                otherData[dstIdx * 4 + 0] = otherData[srcIdx * 4 + 0];
                otherData[dstIdx * 4 + 1] = otherData[srcIdx * 4 + 1];
                otherData[dstIdx * 4 + 2] = otherData[srcIdx * 4 + 2];
                otherData[dstIdx * 4 + 3] = otherData[srcIdx * 4 + 3];
            }
            
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(otherData);
            
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInBox[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            // Copy color data with adjustments
            CopyColorDataForClonedSplatsInBox(oldCount, splatsInBox, colorAdj);
            
            Debug.Log($"CLONE: Copied {cloneCount} splats with color adjustments (Exp:{colorAdj.exposure:F2} Con:{colorAdj.contrast:F2} Hue:{colorAdj.hueShift:F0} Sat:{colorAdj.saturation:F2})");
            
            editModified = true;
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Clones splats from source box to target with rotation, scale and color adjustments
        /// </summary>
        public void CloneSplatsInBoxTransformed(Vector3 sourcePosition, Vector3 targetPosition, Vector3 boxSize, Quaternion rotation, Vector3 scale, ColorAdjustments colorAdj)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;

            if (asset.chunkData != null)
            {
                Debug.LogWarning("Clone not supported: Only VeryHigh quality splats can be cloned.");
                return;
            }

            Vector3 localSourceCenter = transform.InverseTransformPoint(sourcePosition);
            Vector3 localBoxSize = Vector3.Scale(boxSize, new Vector3(
                1f / transform.lossyScale.x,
                1f / transform.lossyScale.y,
                1f / transform.lossyScale.z
            ));
            
            Bounds localBounds = new Bounds(localSourceCenter, localBoxSize);
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("Clone only supports Float32 position format");
                return;
            }
            
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            List<int> splatsInBox = new List<int>();
            for (int i = 0; i < m_SplatCount && splatsInBox.Count < kMaxClonePerOperation; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                if (localBounds.Contains(localPos))
                    splatsInBox.Add(i);
            }
            
            int cloneCount = splatsInBox.Count;
            if (cloneCount == 0)
            {
                Debug.LogWarning($"CLONE: No splats found in box. Try larger size.");
                return;
            }
            
            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;
            
            try { EditSetSplatCount(newCount); }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                return;
            }
            
            Vector3 localTargetCenter = transform.InverseTransformPoint(targetPosition);
            
            // The rotation is already in world space, we just need to apply it to positions
            // For positions: rotate relative position around the center
            // For splat rotations: apply the rotation to each splat's orientation
            
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            // Read other data as uint to properly handle packed rotation
            uint[] otherDataUint = new uint[newCount * 4];
            m_GpuOtherData.GetData(otherDataUint, 0, 0, oldCount * 4);
            
            // Check if we have significant rotation to apply
            bool hasSignificantRotation = Mathf.Abs(Quaternion.Dot(rotation, Quaternion.identity)) < 0.9999f;
            
            // Convert world rotation to local space for splat orientation transform
            Quaternion localRotation = Quaternion.identity;
            if (hasSignificantRotation)
            {
                // The rotation is in world space, convert to local for splat orientations
                Quaternion worldToLocal = Quaternion.Inverse(transform.rotation);
                localRotation = worldToLocal * rotation * transform.rotation;
            }
            
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInBox[i];
                int dstIdx = oldCount + i;
                
                // Get source position relative to source center
                Vector3 srcLocalPos = new Vector3(
                    newPosData[srcIdx * 3 + 0],
                    newPosData[srcIdx * 3 + 1],
                    newPosData[srcIdx * 3 + 2]
                );
                Vector3 relativePos = srcLocalPos - localSourceCenter;
                
                // Apply scale (includes flip)
                relativePos = Vector3.Scale(relativePos, scale);
                
                // Apply rotation around center (rotation is in world space, so we need to transform)
                // Convert relative position to world, rotate, convert back
                Vector3 worldRelative = transform.TransformVector(relativePos);
                worldRelative = rotation * worldRelative;
                relativePos = transform.InverseTransformVector(worldRelative);
                
                // Move to target position
                Vector3 dstLocalPos = localTargetCenter + relativePos;
                
                newPosData[dstIdx * 3 + 0] = dstLocalPos.x;
                newPosData[dstIdx * 3 + 1] = dstLocalPos.y;
                newPosData[dstIdx * 3 + 2] = dstLocalPos.z;
                
                // Transform splat rotation if we have significant box rotation
                if (hasSignificantRotation)
                {
                    // Unpack source rotation, apply transform, repack
                    uint packedSrcRot = otherDataUint[srcIdx * 4 + 0];
                    Quaternion srcSplatRot = UnpackRotation(packedSrcRot);
                    Quaternion dstSplatRot = localRotation * srcSplatRot;
                    otherDataUint[dstIdx * 4 + 0] = PackRotation(dstSplatRot);
                }
                else
                {
                    // No rotation, just copy
                    otherDataUint[dstIdx * 4 + 0] = otherDataUint[srcIdx * 4 + 0];
                }
                
                // Copy splat scale (apply user scale factor uniformly to preserve shape)
                float uniformScale = (Mathf.Abs(scale.x) + Mathf.Abs(scale.y) + Mathf.Abs(scale.z)) / 3f;
                float scaleX = BitConverter.ToSingle(BitConverter.GetBytes(otherDataUint[srcIdx * 4 + 1]), 0);
                float scaleY = BitConverter.ToSingle(BitConverter.GetBytes(otherDataUint[srcIdx * 4 + 2]), 0);
                float scaleZ = BitConverter.ToSingle(BitConverter.GetBytes(otherDataUint[srcIdx * 4 + 3]), 0);
                
                otherDataUint[dstIdx * 4 + 1] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleX * uniformScale), 0);
                otherDataUint[dstIdx * 4 + 2] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleY * uniformScale), 0);
                otherDataUint[dstIdx * 4 + 3] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleZ * uniformScale), 0);
            }
            
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(otherDataUint);
            
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInBox[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            // Copy color data with adjustments
            if (colorAdj.HasAdjustments)
                CopyColorDataForClonedSplatsInBox(oldCount, splatsInBox, colorAdj);
            else
                CopyColorDataForClonedSplatsInBox(oldCount, splatsInBox);
            
            string transformInfo = $"Rot:({rotation.eulerAngles.x:F0},{rotation.eulerAngles.y:F0},{rotation.eulerAngles.z:F0}) Scale:({scale.x:F2},{scale.y:F2},{scale.z:F2})";
            Debug.Log($"CLONE TRANSFORMED: Copied {cloneCount} splats with {transformInfo}");
            
            editModified = true;
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Get the world position of a single splat by index
        /// </summary>
        public Vector3 GetSplatWorldPosition(int index)
        {
            if (!HasValidAsset || !HasValidRenderSetup || index < 0 || index >= m_SplatCount)
                return Vector3.zero;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return Vector3.zero;
            
            float[] posData = new float[3];
            m_GpuPosData.GetData(posData, 0, index * 3, 3);
            
            Vector3 localPos = new Vector3(posData[0], posData[1], posData[2]);
            return transform.TransformPoint(localPos);
        }
        
        /// <summary>
        /// Get indices of splats within a sphere
        /// </summary>
        public List<int> GetSplatsInSphere(Vector3 worldCenter, float radius)
        {
            var result = new List<int>();
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return result;
            
            Vector3 localCenter = transform.InverseTransformPoint(worldCenter);
            float localRadius = radius / transform.lossyScale.x; // approximate
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return result;
            
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            float radiusSq = localRadius * localRadius;
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 pos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                if ((pos - localCenter).sqrMagnitude <= radiusSq)
                    result.Add(i);
            }
            
            return result;
        }
        
        /// <summary>
        /// Get the world-space center of a list of splats
        /// </summary>
        public Vector3 GetCenterOfSplats(List<int> indices)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0 || indices.Count == 0)
                return Vector3.zero;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return Vector3.zero;
            
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            Vector3 sum = Vector3.zero;
            int count = 0;
            foreach (int idx in indices)
            {
                if (idx >= 0 && idx < m_SplatCount)
                {
                    sum += new Vector3(posData[idx * 3], posData[idx * 3 + 1], posData[idx * 3 + 2]);
                    count++;
                }
            }
            
            if (count == 0)
                return Vector3.zero;
            
            Vector3 localCenter = sum / count;
            return transform.TransformPoint(localCenter);
        }
        
        /// <summary>
        /// Clone splats by their indices with an offset
        /// </summary>
        public void CloneSplatsFromIndices(List<int> indices, Vector3 worldOffset)
        {
            try
            {
                if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0 || indices.Count == 0)
                {
                    Debug.LogError($"Clone failed: Invalid state - HasValidAsset={HasValidAsset}, splatCount={m_SplatCount}, indices={indices.Count}");
                    return;
                }
                
                if (asset.chunkData != null)
                {
                    Debug.LogError("PASTE FAILED: Asset uses chunked data. Please use VeryHigh quality splats for copy/paste.");
                    return;
                }
                
                if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                {
                    Debug.LogError($"PASTE FAILED: Asset uses {asset.posFormat} format. Please use VeryHigh quality (Float32) splats for copy/paste.");
                    return;
                }
            
            int cloneCount = Mathf.Min(indices.Count, kMaxClonePerOperation);
            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;
            
            try { EditSetSplatCount(newCount); }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                return;
            }
            
            Vector3 localOffset = transform.InverseTransformVector(worldOffset);
            
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            float[] otherData = new float[newCount * 4];
            m_GpuOtherData.GetData(otherData, 0, 0, oldCount * 4);
            
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = indices[i];
                int dstIdx = oldCount + i;
                
                newPosData[dstIdx * 3 + 0] = newPosData[srcIdx * 3 + 0] + localOffset.x;
                newPosData[dstIdx * 3 + 1] = newPosData[srcIdx * 3 + 1] + localOffset.y;
                newPosData[dstIdx * 3 + 2] = newPosData[srcIdx * 3 + 2] + localOffset.z;
                
                otherData[dstIdx * 4 + 0] = otherData[srcIdx * 4 + 0];
                otherData[dstIdx * 4 + 1] = otherData[srcIdx * 4 + 1];
                otherData[dstIdx * 4 + 2] = otherData[srcIdx * 4 + 2];
                otherData[dstIdx * 4 + 3] = otherData[srcIdx * 4 + 3];
            }
            
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(otherData);
            
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = indices[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            CopyColorDataForClonedSplatsInBox(oldCount, indices);
            
            Debug.Log($"CLONE: Copied {cloneCount} splats from selection");
            
            editModified = true;
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"CloneSplatsFromIndices EXCEPTION: {ex.Message}\n{ex.StackTrace}");
            }
        }
        
        /// <summary>
        /// Clone splats by indices with rotation, scale and color adjustments
        /// </summary>
        public void CloneSplatsFromIndicesTransformed(List<int> indices, Vector3 worldOffset, Quaternion rotation, Vector3 scale, Vector3 pivotWorld, ColorAdjustments colorAdj)
        {
            Debug.Log($"CloneSplatsFromIndicesTransformed: indices={indices.Count}, offset={worldOffset}");
            
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0 || indices.Count == 0)
            {
                Debug.LogWarning($"Clone failed: HasValidAsset={HasValidAsset}, HasValidRenderSetup={HasValidRenderSetup}, splatCount={m_SplatCount}, indices={indices.Count}");
                return;
            }
            
            if (asset.chunkData != null)
            {
                Debug.LogWarning("Clone not supported: Only VeryHigh quality splats can be cloned (chunkData is set).");
                return;
            }
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning($"Clone only supports Float32 position format. Current format: {asset.posFormat}");
                return;
            }
            
            int cloneCount = Mathf.Min(indices.Count, kMaxClonePerOperation);
            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;
            
            try { EditSetSplatCount(newCount); }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer: {e.Message}");
                return;
            }
            
            Vector3 localPivot = transform.InverseTransformPoint(pivotWorld);
            Vector3 localOffset = transform.InverseTransformVector(worldOffset);
            
            // Convert world rotation to local rotation for splat orientation
            Quaternion localRotation = Quaternion.Inverse(transform.rotation) * rotation * transform.rotation;
            bool hasSignificantRotation = Mathf.Abs(Quaternion.Dot(rotation, Quaternion.identity)) < 0.9999f;
            
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            // Read as uint for proper rotation handling
            uint[] otherDataUint = new uint[newCount * 4];
            m_GpuOtherData.GetData(otherDataUint, 0, 0, oldCount * 4);
            
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = indices[i];
                int dstIdx = oldCount + i;
                
                Vector3 srcLocalPos = new Vector3(
                    newPosData[srcIdx * 3 + 0],
                    newPosData[srcIdx * 3 + 1],
                    newPosData[srcIdx * 3 + 2]
                );
                
                Vector3 relativePos = srcLocalPos - localPivot;
                relativePos = Vector3.Scale(relativePos, scale);
                
                Vector3 worldRelative = transform.TransformVector(relativePos);
                worldRelative = rotation * worldRelative;
                relativePos = transform.InverseTransformVector(worldRelative);
                
                Vector3 dstLocalPos = localPivot + relativePos + localOffset;
                
                newPosData[dstIdx * 3 + 0] = dstLocalPos.x;
                newPosData[dstIdx * 3 + 1] = dstLocalPos.y;
                newPosData[dstIdx * 3 + 2] = dstLocalPos.z;
                
                // Transform splat rotation if we have significant rotation
                if (hasSignificantRotation)
                {
                    // Unpack source rotation, apply transform, repack
                    uint packedSrcRot = otherDataUint[srcIdx * 4 + 0];
                    Quaternion srcSplatRot = UnpackRotation(packedSrcRot);
                    Quaternion dstSplatRot = localRotation * srcSplatRot;
                    otherDataUint[dstIdx * 4 + 0] = PackRotation(dstSplatRot);
                }
                else
                {
                    // No rotation, just copy
                    otherDataUint[dstIdx * 4 + 0] = otherDataUint[srcIdx * 4 + 0];
                }
                
                // Copy splat scale (apply user scale factor uniformly to preserve shape)
                float uniformScale = (Mathf.Abs(scale.x) + Mathf.Abs(scale.y) + Mathf.Abs(scale.z)) / 3f;
                float scaleX = BitConverter.ToSingle(BitConverter.GetBytes(otherDataUint[srcIdx * 4 + 1]), 0);
                float scaleY = BitConverter.ToSingle(BitConverter.GetBytes(otherDataUint[srcIdx * 4 + 2]), 0);
                float scaleZ = BitConverter.ToSingle(BitConverter.GetBytes(otherDataUint[srcIdx * 4 + 3]), 0);
                
                otherDataUint[dstIdx * 4 + 1] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleX * uniformScale), 0);
                otherDataUint[dstIdx * 4 + 2] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleY * uniformScale), 0);
                otherDataUint[dstIdx * 4 + 3] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleZ * uniformScale), 0);
            }
            
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(otherDataUint);
            
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = indices[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            if (colorAdj.HasAdjustments)
                CopyColorDataForClonedSplatsInBox(oldCount, indices, colorAdj);
            else
                CopyColorDataForClonedSplatsInBox(oldCount, indices);
            
            Debug.Log($"CLONE TRANSFORMED: Copied {cloneCount} splats from selection");
            
            editModified = true;
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Move splats in a range by a world offset (for real-time adjustment)
        /// </summary>
        public void MoveSplatsInRange(int startIndex, int count, Vector3 worldOffset)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            
            if (startIndex < 0 || startIndex >= m_SplatCount || count <= 0)
                return;
            
            int endIndex = Mathf.Min(startIndex + count, m_SplatCount);
            int actualCount = endIndex - startIndex;
            
            if (actualCount <= 0) return;
            
            // Convert world offset to local offset
            Vector3 localOffset = transform.InverseTransformVector(worldOffset);
            
            // Read position data
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData);
            
            // Apply offset to splats in range
            for (int i = startIndex; i < endIndex; i++)
            {
                posData[i * 3 + 0] += localOffset.x;
                posData[i * 3 + 1] += localOffset.y;
                posData[i * 3 + 2] += localOffset.z;
            }
            
            // Write back
            m_GpuPosData.SetData(posData);
            
            editModified = true;
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Transform splats in a range with rotation and scale around a world pivot
        /// </summary>
        public void TransformSplatsInRange(int startIndex, int count, Vector3 worldPivot, Quaternion rotation, float scale)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            
            if (startIndex < 0 || startIndex >= m_SplatCount || count <= 0)
                return;
            
            int endIndex = Mathf.Min(startIndex + count, m_SplatCount);
            int actualCount = endIndex - startIndex;
            
            if (actualCount <= 0) return;
            
            // Convert world pivot to local
            Vector3 localPivot = transform.InverseTransformPoint(worldPivot);
            
            // Convert world rotation to local rotation for splat orientation
            Quaternion localRotation = Quaternion.Inverse(transform.rotation) * rotation * transform.rotation;
            bool hasRotation = Mathf.Abs(Quaternion.Dot(rotation, Quaternion.identity)) < 0.9999f;
            bool hasScale = Mathf.Abs(scale - 1f) > 0.001f;
            
            if (!hasRotation && !hasScale) return;
            
            // Read position data
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData);
            
            // Read other data (rotation + scale) as uint
            uint[] otherData = new uint[m_SplatCount * 4];
            m_GpuOtherData.GetData(otherData);
            
            for (int i = startIndex; i < endIndex; i++)
            {
                // Get current position
                Vector3 localPos = new Vector3(
                    posData[i * 3 + 0],
                    posData[i * 3 + 1],
                    posData[i * 3 + 2]
                );
                
                // Transform position around pivot
                Vector3 relativePos = localPos - localPivot;
                
                if (hasScale)
                    relativePos *= scale;
                
                if (hasRotation)
                {
                    Vector3 worldRelative = transform.TransformVector(relativePos);
                    worldRelative = rotation * worldRelative;
                    relativePos = transform.InverseTransformVector(worldRelative);
                }
                
                Vector3 newPos = localPivot + relativePos;
                posData[i * 3 + 0] = newPos.x;
                posData[i * 3 + 1] = newPos.y;
                posData[i * 3 + 2] = newPos.z;
                
                // Transform splat rotation
                if (hasRotation)
                {
                    uint packedRot = otherData[i * 4 + 0];
                    Quaternion splatRot = UnpackRotation(packedRot);
                    Quaternion newRot = localRotation * splatRot;
                    otherData[i * 4 + 0] = PackRotation(newRot);
                }
                
                // Transform splat scale
                if (hasScale)
                {
                    float scaleX = BitConverter.ToSingle(BitConverter.GetBytes(otherData[i * 4 + 1]), 0);
                    float scaleY = BitConverter.ToSingle(BitConverter.GetBytes(otherData[i * 4 + 2]), 0);
                    float scaleZ = BitConverter.ToSingle(BitConverter.GetBytes(otherData[i * 4 + 3]), 0);
                    
                    otherData[i * 4 + 1] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleX * scale), 0);
                    otherData[i * 4 + 2] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleY * scale), 0);
                    otherData[i * 4 + 3] = BitConverter.ToUInt32(BitConverter.GetBytes(scaleZ * scale), 0);
                }
            }
            
            m_GpuPosData.SetData(posData);
            m_GpuOtherData.SetData(otherData);
            
            editModified = true;
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Delete splats by their indices
        /// </summary>
        public void DeleteSplatsByIndices(List<int> indices)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0 || indices.Count == 0)
                return;
            
            if (!EnsureEditingBuffers())
                return;
            
            uint[] deletedBits = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditDeleted.GetData(deletedBits);
            
            int deletedCount = 0;
            foreach (int idx in indices)
            {
                if (idx >= 0 && idx < m_SplatCount)
                {
                    int wordIdx = idx / 32;
                    int bitIdx = idx % 32;
                    deletedBits[wordIdx] |= (1u << bitIdx);
                    deletedCount++;
                }
            }
            
            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            
            Debug.Log($"DELETE: Marked {deletedCount} splats for deletion");
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        // Matches shader: DecodePacked_10_10_10_2 then DecodeRotation
        private static Quaternion UnpackRotation(uint packed)
        {
            // DecodePacked_10_10_10_2: extract as 0..1 floats
            float px = (packed & 1023) / 1023.0f;
            float py = ((packed >> 10) & 1023) / 1023.0f;
            float pz = ((packed >> 20) & 1023) / 1023.0f;
            float pw = ((packed >> 30) & 3) / 3.0f;
            
            // DecodeRotation: convert from packed format to quaternion
            int idx = Mathf.RoundToInt(pw * 3.0f);
            float sqrt2 = Mathf.Sqrt(2.0f);
            float invSqrt2 = 1.0f / sqrt2;
            
            float qx = px * sqrt2 - invSqrt2;
            float qy = py * sqrt2 - invSqrt2;
            float qz = pz * sqrt2 - invSqrt2;
            float qw = Mathf.Sqrt(Mathf.Max(0, 1.0f - (qx*qx + qy*qy + qz*qz)));
            
            // Swizzle based on which component was largest
            // Must reverse the swizzle done in PackRotation
            switch (idx)
            {
                case 0: return new Quaternion(qw, qx, qy, qz); // x was largest: stored (y,z,w), reconstruct x
                case 1: return new Quaternion(qx, qw, qy, qz); // y was largest: stored (x,z,w), reconstruct y
                case 2: return new Quaternion(qx, qy, qw, qz); // z was largest: stored (x,y,w), reconstruct z
                default: return new Quaternion(qx, qy, qz, qw); // w was largest: stored (x,y,z), reconstruct w
            }
        }
        
        // Matches shader: PackSmallest3Rotation then EncodeQuatToNorm10
        private static uint PackRotation(Quaternion q)
        {
            q.Normalize();
            
            // Find largest absolute component
            float[] absQ = { Mathf.Abs(q.x), Mathf.Abs(q.y), Mathf.Abs(q.z), Mathf.Abs(q.w) };
            int index = 0;
            float maxV = absQ[0];
            for (int i = 1; i < 4; i++)
            {
                if (absQ[i] > maxV)
                {
                    index = i;
                    maxV = absQ[i];
                }
            }
            
            // Swizzle to put smallest 3 in xyz, largest in w position
            float x, y, z, w;
            switch (index)
            {
                case 0: x = q.y; y = q.z; z = q.w; w = q.x; break; // yzwx
                case 1: x = q.x; y = q.z; z = q.w; w = q.y; break; // xzwy
                case 2: x = q.x; y = q.y; z = q.w; w = q.z; break; // xywz
                default: x = q.x; y = q.y; z = q.z; w = q.w; break; // xyzw
            }
            
            // Ensure w (the largest) is positive, flip signs if needed
            float sign = w >= 0 ? 1f : -1f;
            x *= sign;
            y *= sign;
            z *= sign;
            
            // Scale xyz from [-1/sqrt2, 1/sqrt2] to [0, 1]
            float sqrt2 = Mathf.Sqrt(2.0f);
            float px = (x * sqrt2) * 0.5f + 0.5f;
            float py = (y * sqrt2) * 0.5f + 0.5f;
            float pz = (z * sqrt2) * 0.5f + 0.5f;
            float pw = index / 3.0f;
            
            // EncodeQuatToNorm10: pack to 10.10.10.2
            uint enc = (uint)(px * 1023.5f) | 
                       ((uint)(py * 1023.5f) << 10) | 
                       ((uint)(pz * 1023.5f) << 20) | 
                       ((uint)(pw * 3.5f) << 30);
            return enc;
        }
        
        /// <summary>
        /// Copy color data for box-cloned splats
        /// </summary>
        private void CopyColorDataForClonedSplatsInBox(int destStartIndex, List<int> sourceIndices)
        {
            if (sourceIndices == null || sourceIndices.Count == 0)
                return;

            EnsureColorTextureIsWritable();
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt == null)
            {
                Debug.LogWarning("FILL COLOR: RenderTexture is null");
                return;
            }

            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
            
            // Verify RT size matches expected size
            if (rt.width != texWidth || rt.height != texHeight)
            {
                Debug.LogWarning($"FILL COLOR: RT size mismatch! RT=({rt.width},{rt.height}) expected=({texWidth},{texHeight})");
            }
            
            RenderTexture.active = rt;
            Texture2D tempTex = new Texture2D(texWidth, texHeight, rt.graphicsFormat, TextureCreationFlags.None);
            tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
            tempTex.Apply();
            Color[] colors = tempTex.GetPixels();
            RenderTexture.active = null;

            int copiedCount = 0;
            Color sampleSrc = Color.clear;
            for (int i = 0; i < sourceIndices.Count; i++)
            {
                int srcIdx = sourceIndices[i];
                int dstIdx = destStartIndex + i;

                var (srcX, srcY) = SplatIndexToTextureCoords(srcIdx, texWidth);
                var (dstX, dstY) = SplatIndexToTextureCoords(dstIdx, texWidth);

                int srcPixelIdx = srcY * texWidth + srcX;
                int dstPixelIdx = dstY * texWidth + dstX;

                if (srcPixelIdx >= 0 && srcPixelIdx < colors.Length && 
                    dstPixelIdx >= 0 && dstPixelIdx < colors.Length)
                {
                    if (i == 0) sampleSrc = colors[srcPixelIdx];
                    colors[dstPixelIdx] = colors[srcPixelIdx];
                    copiedCount++;
                }
            }

            tempTex.SetPixels(colors);
            tempTex.Apply();
            Graphics.Blit(tempTex, rt);
            DestroyImmediate(tempTex);
            
            Debug.Log($"FILL COLOR: Copied {copiedCount}/{sourceIndices.Count} colors. Sample src color: R={sampleSrc.r:F3} G={sampleSrc.g:F3} B={sampleSrc.b:F3} A={sampleSrc.a:F3}");
        }
        
        /// <summary>
        /// Copy color data with color adjustments applied
        /// </summary>
        private void CopyColorDataForClonedSplatsInBox(int destStartIndex, List<int> sourceIndices, ColorAdjustments adj)
        {
            if (sourceIndices == null || sourceIndices.Count == 0)
                return;

            EnsureColorTextureIsWritable();
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt == null)
            {
                Debug.LogWarning("Color adjustment: RenderTexture is null");
                return;
            }

            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
            RenderTexture.active = rt;
            Texture2D tempTex = new Texture2D(texWidth, texHeight, rt.graphicsFormat, TextureCreationFlags.None);
            tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
            tempTex.Apply();
            Color[] colors = tempTex.GetPixels();
            RenderTexture.active = null;

            int adjustedCount = 0;
            Color sampleBefore = Color.clear;
            Color sampleAfter = Color.clear;
            
            for (int i = 0; i < sourceIndices.Count; i++)
            {
                int srcIdx = sourceIndices[i];
                int dstIdx = destStartIndex + i;

                var (srcX, srcY) = SplatIndexToTextureCoords(srcIdx, texWidth);
                var (dstX, dstY) = SplatIndexToTextureCoords(dstIdx, texWidth);

                int srcPixelIdx = srcY * texWidth + srcX;
                int dstPixelIdx = dstY * texWidth + dstX;

                if (srcPixelIdx >= 0 && srcPixelIdx < colors.Length && 
                    dstPixelIdx >= 0 && dstPixelIdx < colors.Length)
                {
                    Color c = colors[srcPixelIdx];
                    if (i == 0) sampleBefore = c;
                    c = ApplyColorAdjustments(c, adj);
                    if (i == 0) sampleAfter = c;
                    colors[dstPixelIdx] = c;
                    adjustedCount++;
                }
            }

            tempTex.SetPixels(colors);
            tempTex.Apply();
            Graphics.Blit(tempTex, rt);
            DestroyImmediate(tempTex);
            
            Debug.Log($"Color adjustment applied to {adjustedCount} splats. Sample: {sampleBefore} -> {sampleAfter}");
        }
        
        /// <summary>
        /// Apply color adjustments to a color (supports HDR)
        /// </summary>
        private Color ApplyColorAdjustments(Color c, ColorAdjustments adj)
        {
            float originalAlpha = c.a;
            
            // Apply exposure (works with HDR)
            float exposure = Mathf.Pow(2f, adj.exposure);
            c.r *= exposure;
            c.g *= exposure;
            c.b *= exposure;
            
            // Apply contrast around mid-gray
            float midPoint = 0.5f;
            c.r = (c.r - midPoint) * adj.contrast + midPoint;
            c.g = (c.g - midPoint) * adj.contrast + midPoint;
            c.b = (c.b - midPoint) * adj.contrast + midPoint;
            
            // Apply color tint
            c.r *= adj.colorTint.r;
            c.g *= adj.colorTint.g;
            c.b *= adj.colorTint.b;
            
            // Apply hue shift and saturation
            if (Mathf.Abs(adj.hueShift) > 0.1f || Mathf.Abs(adj.saturation - 1f) > 0.001f)
            {
                // For HDR, normalize before HSV conversion
                float maxVal = Mathf.Max(c.r, Mathf.Max(c.g, c.b));
                float scale = maxVal > 1f ? maxVal : 1f;
                Color normalized = new Color(c.r / scale, c.g / scale, c.b / scale);
                
                float h, s, v;
                Color.RGBToHSV(normalized, out h, out s, out v);
                h = (h + adj.hueShift / 360f) % 1f;
                if (h < 0) h += 1f;
                s = Mathf.Clamp01(s * adj.saturation);
                Color adjusted = Color.HSVToRGB(h, s, v);
                
                // Restore HDR scale
                c.r = adjusted.r * scale;
                c.g = adjusted.g * scale;
                c.b = adjusted.b * scale;
            }
            
            // Clamp negative values only, preserve HDR
            c.r = Mathf.Max(0f, c.r);
            c.g = Mathf.Max(0f, c.g);
            c.b = Mathf.Max(0f, c.b);
            c.a = originalAlpha;
            
            return c;
        }
        
        /// <summary>
        /// Apply fill color to splats by blending with existing colors
        /// </summary>
        private void ApplyFillColorToSplats(int startIndex, int count, Color fillColor, float blend)
        {
            if (count <= 0 || blend <= 0.001f) return;
            
            EnsureColorTextureIsWritable();
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt == null) return;
            
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
            RenderTexture.active = rt;
            Texture2D tempTex = new Texture2D(texWidth, texHeight, rt.graphicsFormat, TextureCreationFlags.None);
            tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
            tempTex.Apply();
            Color[] colors = tempTex.GetPixels();
            RenderTexture.active = null;
            
            for (int i = 0; i < count; i++)
            {
                int idx = startIndex + i;
                var (x, y) = SplatIndexToTextureCoords(idx, texWidth);
                int pixelIdx = y * texWidth + x;
                
                if (pixelIdx >= 0 && pixelIdx < colors.Length)
                {
                    Color existing = colors[pixelIdx];
                    // Blend fill color with existing, preserving alpha
                    Color blended = Color.Lerp(existing, new Color(fillColor.r, fillColor.g, fillColor.b, existing.a), blend);
                    colors[pixelIdx] = blended;
                }
            }
            
            tempTex.SetPixels(colors);
            tempTex.Apply();
            Graphics.Blit(tempTex, rt);
            DestroyImmediate(tempTex);
        }

        /// <summary>
        /// Clones splats from a source polygon to a target position
        /// </summary>
        public void CloneSplatsInPolygon(List<Vector3> polygonVertices, Vector3 sourceCenter, Vector3 targetPosition, float selectionDepth, float depthOffset = 0f)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;

            if (polygonVertices == null || polygonVertices.Count < 3)
            {
                Debug.LogWarning("CLONE: Need at least 3 polygon vertices");
                return;
            }

            if (asset.chunkData != null)
            {
                Debug.LogWarning("Clone not supported: Only VeryHigh quality splats can be cloned.");
                return;
            }

            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("Clone only supports Float32 position format");
                return;
            }
            
            // Get the scene view camera for screen-space selection
            Camera sceneCamera = null;
            #if UNITY_EDITOR
            if (UnityEditor.SceneView.lastActiveSceneView != null)
                sceneCamera = UnityEditor.SceneView.lastActiveSceneView.camera;
            #endif
            
            if (sceneCamera == null)
            {
                sceneCamera = Camera.main;
            }
            
            if (sceneCamera == null)
            {
                Debug.LogWarning("CLONE: No camera found for screen-space selection");
                return;
            }
            
            // Convert polygon vertices to screen space
            List<Vector2> screenPolygon = new List<Vector2>();
            foreach (var v in polygonVertices)
            {
                Vector3 screenPos = sceneCamera.WorldToScreenPoint(v);
                screenPolygon.Add(new Vector2(screenPos.x, screenPos.y));
            }
            
            // Calculate screen-space bounding box for quick rejection
            Vector2 screenMin = screenPolygon[0];
            Vector2 screenMax = screenPolygon[0];
            foreach (var sp in screenPolygon)
            {
                screenMin = Vector2.Min(screenMin, sp);
                screenMax = Vector2.Max(screenMax, sp);
            }
            
            Debug.Log($"CLONE: Screen-space selection box=({screenMax.x-screenMin.x:F0}x{screenMax.y-screenMin.y:F0} pixels)");
            
            // Read all positions
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            // Find splats that project inside the screen-space polygon
            List<int> splatsInPolygon = new List<int>();
            for (int i = 0; i < m_SplatCount && splatsInPolygon.Count < kMaxClonePerOperation; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = transform.TransformPoint(localPos);
                Vector3 screenPos = sceneCamera.WorldToScreenPoint(worldPos);
                
                // Skip if behind camera
                if (screenPos.z < 0) continue;
                
                Vector2 sp2d = new Vector2(screenPos.x, screenPos.y);
                
                // Quick bounding box rejection
                if (sp2d.x < screenMin.x || sp2d.x > screenMax.x ||
                    sp2d.y < screenMin.y || sp2d.y > screenMax.y)
                    continue;
                
                // Detailed polygon containment test (ray casting algorithm)
                if (IsPointInScreenPolygon(sp2d, screenPolygon))
                {
                    splatsInPolygon.Add(i);
                }
            }
            
            int cloneCount = splatsInPolygon.Count;
            if (cloneCount == 0)
            {
                Debug.LogWarning($"CLONE: No splats found in polygon. Depth={selectionDepth:F2}m. Try increasing depth.");
                return;
            }
            
            // Calculate screen-space offset for accurate positioning
            Vector3 sourceScreen = sceneCamera.WorldToScreenPoint(sourceCenter);
            Vector3 targetScreen = sceneCamera.WorldToScreenPoint(targetPosition);
            Vector2 screenOffset = new Vector2(targetScreen.x - sourceScreen.x, targetScreen.y - sourceScreen.y);
            
            Debug.Log($"CLONE: {cloneCount} splats, screen offset=({screenOffset.x:F1}, {screenOffset.y:F1})px, depth offset={depthOffset:F2}");
            
            int oldCount = m_SplatCount;
            int newCount = oldCount + cloneCount;
            
            try
            {
                EditSetSplatCount(newCount);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer for cloning: {e.Message}");
                return;
            }
            
            // Re-read position data after resize
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            float[] otherData = new float[newCount * 4];
            m_GpuOtherData.GetData(otherData, 0, 0, oldCount * 4);
            
            // Camera vectors for depth offset
            Vector3 camForward = sceneCamera.transform.forward;
            
            // Copy splats with per-splat screen-space offset
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInPolygon[i];
                int dstIdx = oldCount + i;
                
                // Get source splat world position
                Vector3 srcLocalPos = new Vector3(newPosData[srcIdx * 3], newPosData[srcIdx * 3 + 1], newPosData[srcIdx * 3 + 2]);
                Vector3 srcWorldPos = transform.TransformPoint(srcLocalPos);
                
                // Project to screen, apply offset, project back at same depth
                Vector3 srcScreen = sceneCamera.WorldToScreenPoint(srcWorldPos);
                Vector3 dstScreen = new Vector3(srcScreen.x + screenOffset.x, srcScreen.y + screenOffset.y, srcScreen.z);
                Vector3 dstWorldPos = sceneCamera.ScreenToWorldPoint(dstScreen);
                
                // Apply user depth offset
                dstWorldPos += camForward * depthOffset;
                
                // Convert back to local space
                Vector3 dstLocalPos = transform.InverseTransformPoint(dstWorldPos);
                
                newPosData[dstIdx * 3 + 0] = dstLocalPos.x;
                newPosData[dstIdx * 3 + 1] = dstLocalPos.y;
                newPosData[dstIdx * 3 + 2] = dstLocalPos.z;
                
                otherData[dstIdx * 4 + 0] = otherData[srcIdx * 4 + 0];
                otherData[dstIdx * 4 + 1] = otherData[srcIdx * 4 + 1];
                otherData[dstIdx * 4 + 2] = otherData[srcIdx * 4 + 2];
                otherData[dstIdx * 4 + 3] = otherData[srcIdx * 4 + 3];
            }
            
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(otherData);
            
            // Copy SH data
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = splatsInPolygon[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            // Copy color data
            CopyColorDataForClonedSplatsInBox(oldCount, splatsInPolygon);
            
            // Debug: check first cloned splat position
            if (cloneCount > 0)
            {
                int firstDst = oldCount;
                Vector3 firstLocalPos = new Vector3(newPosData[firstDst * 3], newPosData[firstDst * 3 + 1], newPosData[firstDst * 3 + 2]);
                Vector3 firstWorldPos = transform.TransformPoint(firstLocalPos);
                Debug.Log($"CLONE: First cloned splat world pos: ({firstWorldPos.x:F2},{firstWorldPos.y:F2},{firstWorldPos.z:F2})");
            }
            
            Debug.Log($"CLONE: Copied {cloneCount} splats. Total now: {newCount}. Screen offset: ({screenOffset.x:F1},{screenOffset.y:F1})px");
            
            editModified = true;
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        /// <summary>
        /// Test if a 2D point is inside a screen-space polygon using ray casting
        /// </summary>
        private bool IsPointInScreenPolygon(Vector2 point, List<Vector2> polygon)
        {
            int count = polygon.Count;
            if (count < 3) return false;
            
            bool inside = false;
            for (int i = 0, j = count - 1; i < count; j = i++)
            {
                if (((polygon[i].y > point.y) != (polygon[j].y > point.y)) &&
                    (point.x < (polygon[j].x - polygon[i].x) * (point.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x))
                {
                    inside = !inside;
                }
            }
            return inside;
        }
        
        /// <summary>
        /// Calculate distance from a point to a line segment
        /// </summary>
        private float DistanceToLineSegment(Vector2 point, Vector2 lineStart, Vector2 lineEnd)
        {
            Vector2 line = lineEnd - lineStart;
            float len2 = line.sqrMagnitude;
            
            if (len2 < 0.0001f)
                return Vector2.Distance(point, lineStart);
            
            float t = Mathf.Clamp01(Vector2.Dot(point - lineStart, line) / len2);
            Vector2 projection = lineStart + t * line;
            return Vector2.Distance(point, projection);
        }
        
        /// <summary>
        /// Test if a 3D point is inside a polygon (assumes point is already on the polygon plane)
        /// </summary>
        private bool IsPointInPolygon(Vector3 point, List<Vector3> polygonVertices, Vector3 planeNormal)
        {
            int count = polygonVertices.Count;
            if (count < 3) return false;
            
            // Use winding number algorithm
            int windingNumber = 0;
            
            // Calculate a consistent "up" direction for 2D projection
            Vector3 tangent = (polygonVertices[1] - polygonVertices[0]).normalized;
            Vector3 bitangent = Vector3.Cross(planeNormal, tangent).normalized;
            
            // Project point and polygon to 2D
            Vector2 p2d = new Vector2(Vector3.Dot(point, tangent), Vector3.Dot(point, bitangent));
            
            for (int i = 0; i < count; i++)
            {
                Vector3 v1 = polygonVertices[i];
                Vector3 v2 = polygonVertices[(i + 1) % count];
                
                Vector2 v1_2d = new Vector2(Vector3.Dot(v1, tangent), Vector3.Dot(v1, bitangent));
                Vector2 v2_2d = new Vector2(Vector3.Dot(v2, tangent), Vector3.Dot(v2, bitangent));
                
                if (v1_2d.y <= p2d.y)
                {
                    if (v2_2d.y > p2d.y)
                    {
                        float cross = (v2_2d.x - v1_2d.x) * (p2d.y - v1_2d.y) - (p2d.x - v1_2d.x) * (v2_2d.y - v1_2d.y);
                        if (cross > 0)
                            windingNumber++;
                    }
                }
                else
                {
                    if (v2_2d.y <= p2d.y)
                    {
                        float cross = (v2_2d.x - v1_2d.x) * (p2d.y - v1_2d.y) - (p2d.x - v1_2d.x) * (v2_2d.y - v1_2d.y);
                        if (cross < 0)
                            windingNumber--;
                    }
                }
            }
            
            return windingNumber != 0;
        }
        
        /// <summary>
        /// Deletes splats within a screen-space polygon
        /// </summary>
        public void DeleteSplatsInPolygon(List<Vector3> polygonVertices, float selectionDepth)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (polygonVertices == null || polygonVertices.Count < 3)
                return;
            if (!EnsureEditingBuffers())
                return;
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("Delete polygon only supports Float32 position format");
                return;
            }
            
            Camera sceneCamera = null;
            #if UNITY_EDITOR
            if (UnityEditor.SceneView.lastActiveSceneView != null)
                sceneCamera = UnityEditor.SceneView.lastActiveSceneView.camera;
            #endif
            if (sceneCamera == null)
                sceneCamera = Camera.main;
            if (sceneCamera == null)
                return;
            
            // Convert polygon to screen space
            List<Vector2> screenPolygon = new List<Vector2>();
            foreach (var v in polygonVertices)
            {
                Vector3 screenPos = sceneCamera.WorldToScreenPoint(v);
                screenPolygon.Add(new Vector2(screenPos.x, screenPos.y));
            }
            
            // Screen-space bounding box
            Vector2 screenMin = screenPolygon[0];
            Vector2 screenMax = screenPolygon[0];
            foreach (var sp in screenPolygon)
            {
                screenMin = Vector2.Min(screenMin, sp);
                screenMax = Vector2.Max(screenMax, sp);
            }
            
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            // First pass: sample actual surface depth from splats inside polygon
            List<float> splatDepths = new List<float>();
            for (int i = 0; i < m_SplatCount && splatDepths.Count < 1000; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = transform.TransformPoint(localPos);
                Vector3 screenPos = sceneCamera.WorldToScreenPoint(worldPos);
                
                if (screenPos.z <= 0) continue;
                
                Vector2 sp2d = new Vector2(screenPos.x, screenPos.y);
                if (sp2d.x < screenMin.x || sp2d.x > screenMax.x ||
                    sp2d.y < screenMin.y || sp2d.y > screenMax.y)
                    continue;
                
                if (IsPointInScreenPolygon(sp2d, screenPolygon))
                {
                    splatDepths.Add(screenPos.z);
                }
            }
            
            // Calculate depth range from actual splats, not polygon vertices
            float minZ, maxZ;
            if (splatDepths.Count > 0)
            {
                splatDepths.Sort();
                // Use 10th and 90th percentile to exclude outliers
                int lowIdx = Mathf.Max(0, splatDepths.Count / 10);
                int highIdx = Mathf.Min(splatDepths.Count - 1, splatDepths.Count * 9 / 10);
                minZ = splatDepths[lowIdx];
                maxZ = splatDepths[highIdx];
            }
            else
            {
                // Fallback to polygon vertices if no splats found in first pass
                minZ = float.MaxValue;
                maxZ = float.MinValue;
                foreach (var v in polygonVertices)
                {
                    float z = sceneCamera.WorldToScreenPoint(v).z;
                    minZ = Mathf.Min(minZ, z);
                    maxZ = Mathf.Max(maxZ, z);
                }
            }
            
            float depthTolerance = selectionDepth * 10f;
            
            uint[] deletedBits = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditDeleted.GetData(deletedBits);
            
            int deletedCount = 0;
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = transform.TransformPoint(localPos);
                Vector3 screenPos = sceneCamera.WorldToScreenPoint(worldPos);
                
                if (screenPos.z < 0) continue;
                if (screenPos.z < minZ - depthTolerance || screenPos.z > maxZ + depthTolerance) continue;
                
                Vector2 sp2d = new Vector2(screenPos.x, screenPos.y);
                
                if (sp2d.x < screenMin.x || sp2d.x > screenMax.x ||
                    sp2d.y < screenMin.y || sp2d.y > screenMax.y)
                    continue;
                
                if (IsPointInScreenPolygon(sp2d, screenPolygon))
                {
                    int wordIdx = i / 32;
                    int bitIdx = i % 32;
                    deletedBits[wordIdx] |= (1u << bitIdx);
                    deletedCount++;
                }
            }
            
            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            Debug.Log($"FILL: Deleted {deletedCount} splats in polygon");
        }
        
        /// <summary>
        /// Fills a polygon area with splats sampled from the polygon edges
        /// </summary>
        public void FillPolygonWithSplats(List<Vector3> polygonVertices, Vector3 polygonCenter,
            float selectionDepth, float edgeSampleWidth, float fillDensity, float positionJitter,
            ColorAdjustments colorAdj)
        {
            FillPolygonWithSplats(polygonVertices, polygonCenter, selectionDepth, edgeSampleWidth, 
                fillDensity, positionJitter, colorAdj, false, Color.white, 1f);
        }
        
        public void FillPolygonWithSplats(List<Vector3> polygonVertices, Vector3 polygonCenter,
            float selectionDepth, float edgeSampleWidth, float fillDensity, float positionJitter,
            ColorAdjustments colorAdj, bool useFillColor, Color fillColor, float fillColorBlend)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (polygonVertices == null || polygonVertices.Count < 3)
                return;
            if (asset.chunkData != null)
            {
                Debug.LogWarning("Fill polygon: Only VeryHigh quality splats can be used");
                return;
            }
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("Fill polygon only supports Float32 position format");
                return;
            }
            
            Camera sceneCamera = null;
            #if UNITY_EDITOR
            if (UnityEditor.SceneView.lastActiveSceneView != null)
                sceneCamera = UnityEditor.SceneView.lastActiveSceneView.camera;
            #endif
            if (sceneCamera == null)
                sceneCamera = Camera.main;
            if (sceneCamera == null)
                return;
            
            // Calculate world-space bounding box from polygon vertices
            Vector3 worldMin = polygonVertices[0];
            Vector3 worldMax = polygonVertices[0];
            foreach (var v in polygonVertices)
            {
                worldMin = Vector3.Min(worldMin, v);
                worldMax = Vector3.Max(worldMax, v);
            }
            
            // Sample nearby splats to get average scale and color reference
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            float[] otherData = new float[m_SplatCount * 4];
            m_GpuOtherData.GetData(otherData, 0, 0, m_SplatCount * 4);
            
            List<int> nearbySplats = new List<int>();
            float searchRadius = edgeSampleWidth * 2f;
            
            // Find splats near polygon edges for color/scale reference
            for (int i = 0; i < m_SplatCount && nearbySplats.Count < 1000; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = transform.TransformPoint(localPos);
                
                // Check distance to any polygon edge
                float minDist = float.MaxValue;
                for (int j = 0; j < polygonVertices.Count; j++)
                {
                    Vector3 p1 = polygonVertices[j];
                    Vector3 p2 = polygonVertices[(j + 1) % polygonVertices.Count];
                    float dist = DistancePointToLineSegment3D(worldPos, p1, p2);
                    minDist = Mathf.Min(minDist, dist);
                }
                
                if (minDist < searchRadius)
                    nearbySplats.Add(i);
            }
            
            // Calculate average scale from nearby splats
            float avgScale = 0.05f; // Default fallback
            float avgOpacity = 1f;
            if (nearbySplats.Count > 0)
            {
                avgScale = 0f;
                avgOpacity = 0f;
                foreach (int idx in nearbySplats)
                {
                    avgScale += (Mathf.Abs(otherData[idx * 4 + 1]) + Mathf.Abs(otherData[idx * 4 + 2]) + Mathf.Abs(otherData[idx * 4 + 3])) / 3f;
                    avgOpacity += otherData[idx * 4 + 0];
                }
                avgScale /= nearbySplats.Count;
                avgOpacity /= nearbySplats.Count;
            }
            
            // Use camera-relative coordinates for fill
            Vector3 camForward = sceneCamera.transform.forward;
            Vector3 camRight = sceneCamera.transform.right;
            Vector3 camUp = sceneCamera.transform.up;
            
            // Project polygon vertices onto camera plane to get 2D bounds
            List<Vector2> polygon2D = new List<Vector2>();
            Vector2 min2D = new Vector2(float.MaxValue, float.MaxValue);
            Vector2 max2D = new Vector2(float.MinValue, float.MinValue);
            
            foreach (var v in polygonVertices)
            {
                Vector3 toVertex = v - polygonCenter;
                float px = Vector3.Dot(toVertex, camRight);
                float py = Vector3.Dot(toVertex, camUp);
                Vector2 p2d = new Vector2(px, py);
                polygon2D.Add(p2d);
                min2D = Vector2.Min(min2D, p2d);
                max2D = Vector2.Max(max2D, p2d);
            }
            
            Vector2 size2D = max2D - min2D;
            
            // Grid spacing based on average splat scale and density
            float baseSpacing = avgScale * 2f / fillDensity;
            baseSpacing = Mathf.Max(0.001f, baseSpacing);
            
            int gridU = Mathf.Max(2, Mathf.CeilToInt(size2D.x / baseSpacing));
            int gridV = Mathf.Max(2, Mathf.CeilToInt(size2D.y / baseSpacing));
            int gridD = Mathf.Max(1, Mathf.CeilToInt(selectionDepth / baseSpacing)); // Depth layers
            
            // Cap grid size to avoid memory issues
            int maxGrid = 100;
            gridU = Mathf.Min(gridU, maxGrid);
            gridV = Mathf.Min(gridV, maxGrid);
            gridD = Mathf.Min(gridD, maxGrid);
            
            List<Vector3> fillPositions = new List<Vector3>();
            
            // Generate grid positions in camera-relative space
            for (int d = 0; d < gridD; d++)
            {
                float td = gridD > 1 ? (float)d / (gridD - 1) : 0.5f;
                float depthOffset = Mathf.Lerp(-selectionDepth * 0.5f, selectionDepth * 0.5f, td);
                
                for (int v = 0; v <= gridV; v++)
                {
                    for (int u = 0; u <= gridU; u++)
                    {
                        float tu = gridU > 0 ? (float)u / gridU : 0.5f;
                        float tv = gridV > 0 ? (float)v / gridV : 0.5f;
                        
                        // Position in camera-plane coordinates
                        float localU = Mathf.Lerp(min2D.x, max2D.x, tu);
                        float localV = Mathf.Lerp(min2D.y, max2D.y, tv);
                        
                        // Check if inside polygon (in 2D camera space)
                        Vector2 testPoint = new Vector2(localU, localV);
                        if (IsPointInPolygon2D(testPoint, polygon2D))
                        {
                            // Convert back to world space
                            Vector3 worldPos = polygonCenter 
                                + camRight * localU 
                                + camUp * localV 
                                + camForward * depthOffset; // Depth along camera forward
                            
                            // Add jitter for natural look
                            float jitter = positionJitter * baseSpacing;
                            worldPos += camRight * UnityEngine.Random.Range(-jitter, jitter);
                            worldPos += camUp * UnityEngine.Random.Range(-jitter, jitter);
                            worldPos += camForward * UnityEngine.Random.Range(-jitter, jitter);
                            
                            fillPositions.Add(worldPos);
                        }
                    }
                }
            }
            
            int fillCount = Mathf.Min(fillPositions.Count, kMaxClonePerOperation);
            if (fillCount == 0)
            {
                Debug.LogWarning("FILL: No fill positions inside polygon");
                return;
            }
            
            int oldCount = m_SplatCount;
            int newCount = oldCount + fillCount;
            
            try
            {
                EditSetSplatCount(newCount);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"Failed to expand splat buffer for fill: {e.Message}");
                return;
            }
            
            // Re-read data after resize
            float[] newPosData = new float[newCount * 3];
            m_GpuPosData.GetData(newPosData, 0, 0, oldCount * 3);
            
            float[] newOtherData = new float[newCount * 4];
            m_GpuOtherData.GetData(newOtherData, 0, 0, oldCount * 4);
            
            // Scale for overlapping coverage
            float splatScale = avgScale * (1.5f / fillDensity + 0.5f);
            
            // Create fill splats with uniform properties
            List<int> sourceSplatIndices = new List<int>();
            for (int i = 0; i < fillCount; i++)
            {
                int dstIdx = oldCount + i;
                Vector3 worldPos = fillPositions[i];
                Vector3 localPos = transform.InverseTransformPoint(worldPos);
                
                newPosData[dstIdx * 3 + 0] = localPos.x;
                newPosData[dstIdx * 3 + 1] = localPos.y;
                newPosData[dstIdx * 3 + 2] = localPos.z;
                
                // Set uniform scale and opacity for solid fill
                newOtherData[dstIdx * 4 + 0] = avgOpacity;
                newOtherData[dstIdx * 4 + 1] = splatScale;
                newOtherData[dstIdx * 4 + 2] = splatScale;
                newOtherData[dstIdx * 4 + 3] = splatScale;
                
                // Track source for color copying
                if (nearbySplats.Count > 0)
                    sourceSplatIndices.Add(nearbySplats[i % nearbySplats.Count]);
                else
                    sourceSplatIndices.Add(0);
            }
            
            m_GpuPosData.SetData(newPosData);
            m_GpuOtherData.SetData(newOtherData);
            
            // Copy SH data from reference splats
            int shStride = (int)(asset.shData.dataSize / asset.splatCount);
            byte[] shData = new byte[newCount * shStride];
            m_GpuSHData.GetData(shData, 0, 0, oldCount * shStride);
            for (int i = 0; i < fillCount; i++)
            {
                int srcIdx = sourceSplatIndices[i];
                int dstIdx = oldCount + i;
                System.Array.Copy(shData, srcIdx * shStride, shData, dstIdx * shStride, shStride);
            }
            m_GpuSHData.SetData(shData);
            
            // Copy color data from reference splats
            CopyColorDataForClonedSplatsInBox(oldCount, sourceSplatIndices);
            
            // Apply fill color if enabled
            if (useFillColor && fillColorBlend > 0.001f)
            {
                ApplyFillColorToSplats(oldCount, fillCount, fillColor, fillColorBlend);
            }
            
            // Apply color adjustments if any
            if (colorAdj.HasAdjustments)
            {
                Vector3 boxCenter = polygonCenter;
                // Calculate box size from 2D bounds and depth
                float boxWidth = size2D.x + 0.1f;
                float boxHeight = size2D.y + 0.1f;
                Vector3 boxSize = camRight * boxWidth + camUp * boxHeight + camForward * (selectionDepth + 0.1f);
                AdjustColorsInBox(boxCenter, boxSize, colorAdj);
            }
            
            Debug.Log($"FILL: Created {fillCount} new splats in {gridU}x{gridV}x{gridD} grid (scale={splatScale:F4})");
            
            editModified = true;
            UpdateEditCountsAndBounds();
            m_FrameCounter = 0;
            
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(this);
            UnityEditor.SceneView.RepaintAll();
            #endif
        }
        
        private float DistancePointToLineSegment3D(Vector3 point, Vector3 lineStart, Vector3 lineEnd)
        {
            Vector3 line = lineEnd - lineStart;
            float len = line.magnitude;
            if (len < 0.0001f) return Vector3.Distance(point, lineStart);
            
            Vector3 lineDir = line / len;
            float t = Mathf.Clamp(Vector3.Dot(point - lineStart, lineDir), 0f, len);
            Vector3 closest = lineStart + lineDir * t;
            return Vector3.Distance(point, closest);
        }
        
        private bool IsPointInPolygon2D(Vector2 point, List<Vector2> polygon)
        {
            int count = polygon.Count;
            bool inside = false;
            
            for (int i = 0, j = count - 1; i < count; j = i++)
            {
                if (((polygon[i].y > point.y) != (polygon[j].y > point.y)) &&
                    (point.x < (polygon[j].x - polygon[i].x) * (point.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x))
                {
                    inside = !inside;
                }
            }
            
            return inside;
        }
        
        /// <summary>
        /// Convert splat index to texture pixel coordinates using 16x16 block morton encoding
        /// </summary>
        private (int x, int y) SplatIndexToTextureCoords(int splatIndex, int texWidth)
        {
            int blocksPerRow = texWidth / 16;
            int blockIndex = splatIndex / 256;
            int localIndex = splatIndex % 256;
            
            int blockX = blockIndex % blocksPerRow;
            int blockY = blockIndex / blocksPerRow;
            
            // Morton decode the local index within the 16x16 block
            var localCoords = GaussianUtils.DecodeMorton2D_16x16((uint)localIndex);
            
            int x = blockX * 16 + (int)localCoords.x;
            int y = blockY * 16 + (int)localCoords.y;
            
            return (x, y);
        }
        
        /// <summary>
        /// GPU-based color copy for cloned splats
        /// </summary>
        private void CopyColorDataForClonedSplatsGPU(int destStartIndex, int cloneCount)
        {
            if (m_CloneCountBuffer == null || cloneCount == 0)
                return;

            EnsureColorTextureIsWritable();
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt == null)
                return;

            // Read source indices from buffer
            uint[] indices = new uint[cloneCount + 1];
            m_CloneCountBuffer.GetData(indices, 0, 0, cloneCount + 1);

            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
            RenderTexture.active = rt;
            Texture2D tempTex = new Texture2D(texWidth, texHeight, rt.graphicsFormat, TextureCreationFlags.None);
            tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
            tempTex.Apply();
            Color[] colors = tempTex.GetPixels();
            RenderTexture.active = null;

            int copiedCount = 0;
            for (int i = 0; i < cloneCount; i++)
            {
                int srcIdx = (int)indices[i + 1];
                int dstIdx = destStartIndex + i;

                var (srcX, srcY) = SplatIndexToTextureCoords(srcIdx, texWidth);
                var (dstX, dstY) = SplatIndexToTextureCoords(dstIdx, texWidth);

                int srcPixelIdx = srcY * texWidth + srcX;
                int dstPixelIdx = dstY * texWidth + dstX;

                if (srcPixelIdx >= 0 && srcPixelIdx < colors.Length && 
                    dstPixelIdx >= 0 && dstPixelIdx < colors.Length)
                {
                    colors[dstPixelIdx] = colors[srcPixelIdx];
                    copiedCount++;
                }
            }

            tempTex.SetPixels(colors);
            tempTex.Apply();
            Graphics.Blit(tempTex, rt);
            DestroyImmediate(tempTex);
            
        }

        /// <summary>
        /// Find the nearest splat position to a given world point (for brush snapping)
        /// Uses sparse sampling for performance - samples every Nth splat
        /// </summary>
        /// <param name="worldPoint">World position to search from</param>
        /// <param name="maxSamples">Maximum number of samples to check</param>
        /// <returns>World position of the nearest splat</returns>
        public Vector3 FindNearestSplatPosition(Vector3 worldPoint, int maxSamples = 5000)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return worldPoint;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return worldPoint;
            
            // Sparse sampling: read every Nth splat for speed
            int step = Mathf.Max(1, m_SplatCount / maxSamples);
            int actualSamples = (m_SplatCount + step - 1) / step;
            
            // Read all position data at once (faster than individual reads)
            float[] allPosData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(allPosData, 0, 0, Mathf.Min(m_SplatCount * 3, allPosData.Length));
            
            float minDist = float.MaxValue;
            Vector3 nearestWorld = worldPoint;
            
            for (int i = 0; i < m_SplatCount; i += step)
            {
                Vector3 localPos = new Vector3(allPosData[i * 3], allPosData[i * 3 + 1], allPosData[i * 3 + 2]);
                Vector3 worldPos = transform.TransformPoint(localPos);
                float dist = Vector3.Distance(worldPos, worldPoint);
                if (dist < minDist)
                {
                    minDist = dist;
                    nearestWorld = worldPos;
                }
            }
            
            return nearestWorld;
        }
        
        /// <summary>
        /// Find the nearest splat in screen space using fast sparse sampling
        /// </summary>
        public Vector3 FindNearestSplatInScreenSpace(Vector3 worldPoint, Camera cam, float searchRadiusPixels)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0 || cam == null)
                return worldPoint;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return worldPoint;
            
            Vector3 targetScreen = cam.WorldToScreenPoint(worldPoint);
            if (targetScreen.z <= 0) return worldPoint;
            
            // Sparse sampling - check max 50k splats for good coverage with speed
            int maxSamples = 50000;
            int step = Mathf.Max(1, m_SplatCount / maxSamples);
            
            float[] posData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(posData, 0, 0, m_SplatCount * 3);
            
            float searchRadiusSq = searchRadiusPixels * searchRadiusPixels;
            float minScreenDist = float.MaxValue;
            Vector3 nearestWorld = worldPoint;
            
            for (int i = 0; i < m_SplatCount; i += step)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 worldPos = transform.TransformPoint(localPos);
                Vector3 screenPos = cam.WorldToScreenPoint(worldPos);
                
                if (screenPos.z <= 0) continue;
                
                float dx = screenPos.x - targetScreen.x;
                float dy = screenPos.y - targetScreen.y;
                float screenDistSq = dx * dx + dy * dy;
                
                if (screenDistSq < searchRadiusSq && screenDistSq < minScreenDist)
                {
                    minScreenDist = screenDistSq;
                    nearestWorld = worldPos;
                }
            }
            
            return nearestWorld;
        }

        /// <summary>
        /// Get the world-space bounds of the splat asset
        /// </summary>
        public Bounds GetWorldBounds()
        {
            Vector3 boundsMin;
            Vector3 boundsMax;
            if (UsesPagedLod && m_PagedScene != null)
            {
                boundsMin = m_PagedScene.worldBoundsMin;
                boundsMax = m_PagedScene.worldBoundsMax;
            }
            else if (m_Asset != null)
            {
                boundsMin = asset.boundsMin;
                boundsMax = asset.boundsMax;
            }
            else
            {
                return new Bounds(transform.position, Vector3.zero);
            }

            Vector3 localCenter = (boundsMin + boundsMax) * 0.5f;
            Vector3 localSize = boundsMax - boundsMin;
            Vector3 worldCenter = transform.TransformPoint(localCenter);
            Vector3 worldSize = Vector3.Scale(localSize, transform.lossyScale);
            return new Bounds(worldCenter, worldSize);
        }
        
        /// <summary>
        /// Convenience method for brush tool - deletes splats using brush settings
        /// </summary>
        public void EditDeleteSphere(Vector3 worldPosition, float radius, float falloff = 0f, float noiseStrength = 0f, float noiseScale = 1f)
        {
            DeleteSplatsInSphereWithFalloff(worldPosition, radius, falloff, noiseStrength, noiseScale, Time.time);
        }

        /// <summary>
        /// Convenience method for brush tool - restores splats within a sphere
        /// </summary>
        public void EditRestoreSphere(Vector3 worldPosition, float radius)
        {
            RestoreSplatsInSphere(worldPosition, radius);
        }

        /// <summary>
        /// Deletes splats within a cylinder along view direction (screen-space brush)
        /// </summary>
        public void EditDeleteCylinder(Vector3 worldPosition, float radius, Vector3 viewDirection, float falloff = 0f, float noiseStrength = 0f, float noiseScale = 1f, bool useColorFilter = false, Color colorFilter = default, float colorThreshold = 0.1f)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!EnsureEditingBuffers())
                return;

            int kernelIndex = GetKernelIndex(KernelIndices.MarkCylinderForDeletion);
            if (kernelIndex < 0)
                return;
            
            // Ensure buffer size matches current splat count
            var requiredSize = (m_SplatCount + 31) / 32;
            if (m_GpuEditDeleted != null && m_GpuEditDeleted.count != requiredSize)
            {
                m_GpuEditDeleted?.Dispose();
                var target = GraphicsBuffer.Target.Raw | GraphicsBuffer.Target.CopySource | GraphicsBuffer.Target.CopyDestination;
                m_GpuEditDeleted = new GraphicsBuffer(target, requiredSize, 4) { name = "GaussianSplatDeleted" };
                ClearGraphicsBuffer(m_GpuEditDeleted);
            }

            using var cmb = new CommandBuffer { name = "DeleteSplatsInCylinder" };
            
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_DeletionSphereCenter", worldPosition);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionSphereRadius", radius);
            // View direction: camera ray direction (from camera toward scene) - shader expects this direction
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_DeletionCameraDir", viewDirection.normalized);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionFalloff", falloff);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseStrength", noiseStrength);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseScale", noiseScale);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseTime", Time.time);
            
            // Color filtering
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.UseColorFilter, useColorFilter ? 1 : 0);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.DeletionColorFilter, new Vector4(colorFilter.r, colorFilter.g, colorFilter.b, colorFilter.a));
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.DeletionColorThreshold, colorThreshold);
            
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatPos, m_GpuPosData);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatChunks, m_GpuChunks);
            cmb.SetComputeBufferParam(m_CSBoxUtil, kernelIndex, Props.SplatDeletedBits, m_GpuEditDeleted);
            cmb.SetComputeTextureParam(m_CSBoxUtil, kernelIndex, Props.SplatColor, m_GpuColorData);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatCount, m_SplatCount);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatChunkCount, m_GpuChunksValid ? m_GpuChunks.count : 0);
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.SplatFormat, (int)asset.posFormat);
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
            int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
            cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, threadGroups, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            editModified = true;
            UpdateEditCountsAndBounds();
        }
        
        /// <summary>
        /// Deletes splats within a screen-space circle with backface culling - only deletes visible splats (front layer)
        /// Uses the same approach as EditSelectSplatsInScreenCircle with backface culling
        /// </summary>
        /// <param name="centerPx">Screen-space center in GUI coordinates (from e.mousePosition)</param>
        /// <param name="radiusPx">Screen-space radius in pixels</param>
        public void EditDeleteSplatsInScreenCircle(Vector2 centerPx, float radiusPx, Camera cam, bool backfaceCulling, float falloff = 0f, float noiseStrength = 0f, float noiseScale = 1f, bool useColorFilter = false, Color colorFilter = default, float colorThreshold = 0.1f)
        {
            if (!EnsureEditingBuffers()) return;

            var tr = transform;
            Matrix4x4 matView = cam.worldToCameraMatrix;
            Matrix4x4 matProj = GL.GetGPUProjectionMatrix(cam.projectionMatrix, false);
            Matrix4x4 matO2W = tr.localToWorldMatrix;
            Matrix4x4 matW2O = tr.worldToLocalMatrix;
            int screenW = cam.pixelWidth, screenH = cam.pixelHeight;
            Vector4 screenPar = new Vector4(screenW, screenH, 0, 0);
            Vector4 camPos = cam.transform.position;

            // If backface culling is enabled, find the closest splat depth first
            if (backfaceCulling)
            {
                uint init = FloatToSortableUint(1.0e38f);
                m_GpuEditSelectMinDepth.SetData(new[] { init });
            }

            int deleteKernelIndex = GetKernelIndex(KernelIndices.DeleteSplatsInScreenCircleWithDepth);
            int findKernelIndex = backfaceCulling ? GetKernelIndex(KernelIndices.FindMinDepthInScreenCircle) : -1;
            
            if (deleteKernelIndex < 0) return;
            if (backfaceCulling && findKernelIndex < 0) return;

            using var cmb = new CommandBuffer { name = "DeleteSplatsInScreenCircle" };

            // Pass 1: find min depth in circle (if backface culling enabled)
            if (backfaceCulling)
            {
                SetAssetDataOnCS(cmb, KernelIndices.FindMinDepthInScreenCircle);
                cmb.SetComputeBufferParam(m_CSBoxUtil, findKernelIndex, "_SelectionMinDepth", m_GpuEditSelectMinDepth);

                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
                cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

                cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
                cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

                cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", new Vector4(centerPx.x, centerPx.y, 0, 0));
                cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);

                m_CSBoxUtil.GetKernelThreadGroupSizes(findKernelIndex, out uint gsX, out _, out _);
                cmb.DispatchCompute(m_CSBoxUtil, findKernelIndex, (int)((m_SplatCount + gsX - 1) / gsX), 1, 1);
            }

            // Pass 2: delete splats in circle (optionally depth-filtered)
            SetAssetDataOnCS(cmb, KernelIndices.DeleteSplatsInScreenCircleWithDepth);
            cmb.SetComputeBufferParam(m_CSBoxUtil, deleteKernelIndex, "_SelectionMinDepth", m_GpuEditSelectMinDepth);
            cmb.SetComputeBufferParam(m_CSBoxUtil, deleteKernelIndex, Props.SplatDeletedBits, m_GpuEditDeleted);
            cmb.SetComputeTextureParam(m_CSBoxUtil, deleteKernelIndex, Props.SplatColor, m_GpuColorData);

            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixVP, matProj * matView);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixMV, matView * matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixP, matProj);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, matO2W);
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixWorldToObject, matW2O);

            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecScreenParams, screenPar);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.VecWorldSpaceCameraPos, camPos);

            cmb.SetComputeVectorParam(m_CSBoxUtil, "_SelectionCircleCenterPx", new Vector4(centerPx.x, centerPx.y, 0, 0));
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionCircleRadiusPx", radiusPx);
            
            cmb.SetComputeIntParam(m_CSBoxUtil, "_BackfaceCulling", backfaceCulling ? 1 : 0);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_SelectionDepthEpsilon", 0.05f);
            
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionFalloff", falloff);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseStrength", noiseStrength);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseScale", noiseScale);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionNoiseTime", Time.time);

            // Color filtering
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.UseColorFilter, useColorFilter ? 1 : 0);
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.DeletionColorFilter, new Vector4(colorFilter.r, colorFilter.g, colorFilter.b, colorFilter.a));
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.DeletionColorThreshold, colorThreshold);

            m_CSBoxUtil.GetKernelThreadGroupSizes(deleteKernelIndex, out uint delGsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, deleteKernelIndex, (int)((m_SplatCount + delGsX - 1) / delGsX), 1, 1);

            Graphics.ExecuteCommandBuffer(cmb);
            
            editModified = true;
            UpdateEditCountsAndBounds();
        }
        
        /// <summary>
        /// Legacy wrapper - converts world position to screen position for backface culling delete
        /// </summary>
        public void EditDeleteCylinderWithBackfaceCulling(Vector3 worldPosition, float radius, Vector3 viewDirection, Camera cam, float falloff = 0f, float noiseStrength = 0f, float noiseScale = 1f, bool useColorFilter = false, Color colorFilter = default, float colorThreshold = 0.1f)
        {
            if (cam == null)
            {
                EditDeleteCylinder(worldPosition, radius, viewDirection, falloff, noiseStrength, noiseScale, useColorFilter, colorFilter, colorThreshold);
                return;
            }
            
            // Convert world position to screen position
            Vector3 screenPos = cam.WorldToScreenPoint(worldPosition);
            if (screenPos.z <= 0)
            {
                // Behind camera, fall back to regular deletion
                EditDeleteCylinder(worldPosition, radius, viewDirection, falloff, noiseStrength, noiseScale, useColorFilter, colorFilter, colorThreshold);
                return;
            }
            
            // Convert to GUI coordinates (Y flipped)
            Vector2 centerPx = new Vector2(screenPos.x, cam.pixelHeight - screenPos.y);
            
            // Calculate screen-space radius
            float distance = screenPos.z;
            float radiusPx = (radius / distance) * cam.pixelHeight * 0.5f / Mathf.Tan(cam.fieldOfView * 0.5f * Mathf.Deg2Rad);
            
            EditDeleteSplatsInScreenCircle(centerPx, radiusPx, cam, true, falloff, noiseStrength, noiseScale, useColorFilter, colorFilter, colorThreshold);
        }

        /// <summary>
        /// Restores splats within a cylinder along view direction
        /// </summary>
        public void EditRestoreCylinder(Vector3 worldPosition, float radius, Vector3 viewDirection)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!EnsureEditingBuffers())
                return;

            int kernelIndex = GetKernelIndex(KernelIndices.RestoreCylinderFromDeletion);
            if (kernelIndex < 0)
                return;

            using var cmb = new CommandBuffer { name = "RestoreSplatsInCylinder" };

            // Bind through the shared asset path so every resource declared by LoadSplatPos is
            // provided on strict APIs such as Vulkan. In particular, _SplatIndexRemap must still
            // have a valid fallback buffer even when _UseSplatIndexRemap is zero.
            SetAssetDataOnCS(cmb, KernelIndices.RestoreCylinderFromDeletion);
            
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_DeletionSphereCenter", worldPosition);
            cmb.SetComputeFloatParam(m_CSBoxUtil, "_DeletionSphereRadius", radius);
            cmb.SetComputeVectorParam(m_CSBoxUtil, "_DeletionCameraDir", viewDirection.normalized);
            
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            
            try
            {
                m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
                int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
                cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, threadGroups, 1, 1);
                
                Graphics.ExecuteCommandBuffer(cmb);
                
                editModified = true;
                UpdateEditCountsAndBounds();
            }
            catch (System.Exception)
            {
                if (m_KernelIndices != null)
                    m_KernelIndices[KernelIndices.RestoreCylinderFromDeletion] = -1;
            }
        }

        /// <summary>
        /// Deletes splats within a box region (CPU-based for accuracy)
        /// </summary>
        public void DeleteSplatsInBox(Vector3 boxCenter, Vector3 boxSize)
        {
            DeleteSplatsInBox(boxCenter, boxSize, Quaternion.identity);
        }

        /// <summary>
        /// Deletes splats within a rotated box region (CPU-based for accuracy)
        /// </summary>
        public void DeleteSplatsInBox(Vector3 boxCenter, Vector3 boxSize, Quaternion boxRotation)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!EnsureEditingBuffers())
                return;

            Vector3 halfExtents = boxSize * 0.5f;
            Quaternion invBoxRotation = Quaternion.Inverse(boxRotation);

            Vector3[] localPositions = GetDecodedLocalPositions();
            if (localPositions == null)
                return;

            uint[] deletedBits = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditDeleted.GetData(deletedBits);

            int deletedCount = 0;
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 worldPos = transform.TransformPoint(localPositions[i]);
                
                // Transform point into box's local space
                Vector3 boxLocalPos = invBoxRotation * (worldPos - boxCenter);
                
                // Check if point is inside the box
                if (Mathf.Abs(boxLocalPos.x) <= halfExtents.x &&
                    Mathf.Abs(boxLocalPos.y) <= halfExtents.y &&
                    Mathf.Abs(boxLocalPos.z) <= halfExtents.z)
                {
                    int wordIdx = i / 32;
                    int bitIdx = i % 32;
                    deletedBits[wordIdx] |= (1u << bitIdx);
                    deletedCount++;
                }
            }

            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            Debug.Log($"Deleted {deletedCount} splats in box");
        }

        /// <summary>
        /// Restores previously deleted splats within a box region (CPU-based for accuracy)
        /// </summary>
        public void RestoreSplatsInBox(Vector3 boxCenter, Vector3 boxSize)
        {
            RestoreSplatsInBox(boxCenter, boxSize, Quaternion.identity);
        }

        /// <summary>
        /// Restores previously deleted splats within a rotated box region (CPU-based for accuracy)
        /// </summary>
        public void RestoreSplatsInBox(Vector3 boxCenter, Vector3 boxSize, Quaternion boxRotation)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!EnsureEditingBuffers())
                return;

            Vector3 halfExtents = boxSize * 0.5f;
            Quaternion invBoxRotation = Quaternion.Inverse(boxRotation);

            Vector3[] localPositions = GetDecodedLocalPositions();
            if (localPositions == null)
                return;

            uint[] deletedBits = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditDeleted.GetData(deletedBits);

            int restoredCount = 0;
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 worldPos = transform.TransformPoint(localPositions[i]);
                
                // Transform point into box's local space
                Vector3 boxLocalPos = invBoxRotation * (worldPos - boxCenter);
                
                // Check if point is inside the box
                if (Mathf.Abs(boxLocalPos.x) <= halfExtents.x &&
                    Mathf.Abs(boxLocalPos.y) <= halfExtents.y &&
                    Mathf.Abs(boxLocalPos.z) <= halfExtents.z)
                {
                    int wordIdx = i / 32;
                    int bitIdx = i % 32;
                    if ((deletedBits[wordIdx] & (1u << bitIdx)) != 0)
                    {
                        deletedBits[wordIdx] &= ~(1u << bitIdx);
                        restoredCount++;
                    }
                }
            }

            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            Debug.Log($"Restored {restoredCount} splats in box");
        }

        /// <summary>
        /// Deletes splats within a bounded cylinder (CPU-based for accuracy)
        /// </summary>
        /// <param name="center">Center of the cylinder in world space</param>
        /// <param name="radius">Radius of the cylinder</param>
        /// <param name="height">Total height of the cylinder</param>
        /// <param name="axis">Axis direction of the cylinder (normalized)</param>
        public void DeleteSplatsInCylinderBounded(Vector3 center, float radius, float height, Vector3 axis)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!EnsureEditingBuffers())
                return;

            axis = axis.normalized;
            float halfHeight = height * 0.5f;
            float radiusSq = radius * radius;

            Vector3[] localPositions = GetDecodedLocalPositions();
            if (localPositions == null)
                return;

            uint[] deletedBits = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditDeleted.GetData(deletedBits);

            int deletedCount = 0;
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 worldPos = transform.TransformPoint(localPositions[i]);
                
                // Vector from cylinder center to point
                Vector3 toPoint = worldPos - center;
                
                // Project onto cylinder axis
                float axisProj = Vector3.Dot(toPoint, axis);
                
                // Check height bounds
                if (Mathf.Abs(axisProj) > halfHeight)
                    continue;
                
                // Get perpendicular distance to axis
                Vector3 axisPoint = center + axis * axisProj;
                float perpDistSq = (worldPos - axisPoint).sqrMagnitude;
                
                // Check radius
                if (perpDistSq <= radiusSq)
                {
                    int wordIdx = i / 32;
                    int bitIdx = i % 32;
                    deletedBits[wordIdx] |= (1u << bitIdx);
                    deletedCount++;
                }
            }

            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            Debug.Log($"Deleted {deletedCount} splats in cylinder");
        }

        /// <summary>
        /// Restores splats within a bounded cylinder (CPU-based for accuracy)
        /// </summary>
        public void RestoreSplatsInCylinderBounded(Vector3 center, float radius, float height, Vector3 axis)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!EnsureEditingBuffers())
                return;

            axis = axis.normalized;
            float halfHeight = height * 0.5f;
            float radiusSq = radius * radius;

            Vector3[] localPositions = GetDecodedLocalPositions();
            if (localPositions == null)
                return;

            uint[] deletedBits = new uint[(m_SplatCount + 31) / 32];
            m_GpuEditDeleted.GetData(deletedBits);

            int restoredCount = 0;
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 worldPos = transform.TransformPoint(localPositions[i]);
                
                Vector3 toPoint = worldPos - center;
                float axisProj = Vector3.Dot(toPoint, axis);
                
                if (Mathf.Abs(axisProj) > halfHeight)
                    continue;
                
                Vector3 axisPoint = center + axis * axisProj;
                float perpDistSq = (worldPos - axisPoint).sqrMagnitude;
                
                if (perpDistSq <= radiusSq)
                {
                    int wordIdx = i / 32;
                    int bitIdx = i % 32;
                    if ((deletedBits[wordIdx] & (1u << bitIdx)) != 0)
                    {
                        deletedBits[wordIdx] &= ~(1u << bitIdx);
                        restoredCount++;
                    }
                }
            }

            m_GpuEditDeleted.SetData(deletedBits);
            editModified = true;
            UpdateEditCountsAndBounds();
            Debug.Log($"Restored {restoredCount} splats in cylinder");
        }

        /// <summary>
        /// Adjusts colors of splats within a box region in-place (GPU accelerated)
        /// Only affects splats inside the box
        /// </summary>
        public void AdjustColorsInBox(Vector3 boxCenter, Vector3 boxSize, ColorAdjustments adj)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            if (!adj.HasAdjustments)
            {
                Debug.LogWarning("No color adjustments to bake");
                return;
            }
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
            {
                Debug.LogWarning("ColorBrush: Only Float32 position format is supported for GPU color baking");
                return;
            }

            EnsureColorTextureIsWritable();
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt == null)
            {
                Debug.LogWarning("Color baking: RenderTexture is null");
                return;
            }

            int kernelIndex = GetKernelIndex(KernelIndices.AdjustColorsInBox);
            if (kernelIndex < 0)
            {
                Debug.LogError("CSAdjustColorsInBox kernel not found");
                return;
            }
            
            // Direct dispatch - force SplatChunkCount=0 and SplatFormat=0 (Float32) since we've verified Float32 format above
            // and the shader reads positions directly from flat buffer without chunk decoding
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatPos, m_GpuPosData);
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatChunks, m_GpuChunks);
            m_CSBoxUtil.SetTexture(kernelIndex, "_ColorAdjustTexture", rt);
            m_CSBoxUtil.SetMatrix(Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            m_CSBoxUtil.SetInt(Props.SplatCount, m_SplatCount);
            m_CSBoxUtil.SetInt(Props.SplatChunkCount, 0);
            m_CSBoxUtil.SetInt(Props.SplatFormat, 0);
            m_CSBoxUtil.SetVector("_ColorAdjustBoxCenter", boxCenter);
            m_CSBoxUtil.SetVector("_ColorAdjustBoxSize", boxSize);
            m_CSBoxUtil.SetFloat("_ColorAdjustExposure", adj.exposure);
            m_CSBoxUtil.SetFloat("_ColorAdjustContrast", adj.contrast);
            m_CSBoxUtil.SetFloat("_ColorAdjustHueShift", adj.hueShift);
            m_CSBoxUtil.SetFloat("_ColorAdjustSaturation", adj.saturation);
            m_CSBoxUtil.SetVector("_ColorAdjustTint", new Vector4(adj.colorTint.r, adj.colorTint.g, adj.colorTint.b, adj.colorTint.a));
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
            int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
            m_CSBoxUtil.Dispatch(kernelIndex, threadGroups, 1, 1);
            
            editModified = true;
            m_FrameCounter = 0;
        }

        /// <summary>
        /// Colorize splats within a sphere by blending toward target color (GPU accelerated)
        /// </summary>
        /// <param name="blendMode">0=Normal, 1=Multiply, 2=Screen, 3=Overlay, 4=Darken, 5=Lighten, 6=SoftLight, 7=HardLight, 8=ColorDodge, 9=ColorBurn</param>
        /// <param name="blendModeIntensity">How much the blend mode effect is applied (0-1)</param>
        public void ColorizeInSphere(Vector3 worldCenter, float worldRadius, Color targetColor, float blendStrength, float falloff = 0.5f, int blendMode = 0, float blendModeIntensity = 1f, float noiseStrength = 0f, float noiseScale = 1f)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return;

            EnsureColorTextureIsWritable();
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt == null)
                return;

            int kernelIndex = GetKernelIndex(KernelIndices.ColorizeInSphere);
            if (kernelIndex < 0)
                return;
            
            // Force SplatChunkCount=0 and SplatFormat=0 (Float32) since we've verified Float32 format above
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatPos, m_GpuPosData);
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatChunks, m_GpuChunks);
            m_CSBoxUtil.SetTexture(kernelIndex, "_ColorAdjustTexture", rt);
            m_CSBoxUtil.SetMatrix(Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            m_CSBoxUtil.SetInt(Props.SplatCount, m_SplatCount);
            m_CSBoxUtil.SetInt(Props.SplatChunkCount, 0);
            m_CSBoxUtil.SetInt(Props.SplatFormat, 0);
            m_CSBoxUtil.SetVector("_ColorizeSphereCenter", worldCenter);
            m_CSBoxUtil.SetFloat("_ColorizeSphereRadius", worldRadius);
            m_CSBoxUtil.SetVector("_ColorizeTargetColor", new Vector4(targetColor.r, targetColor.g, targetColor.b, targetColor.a));
            m_CSBoxUtil.SetFloat("_ColorizeBlendStrength", blendStrength);
            m_CSBoxUtil.SetFloat("_ColorizeFalloff", falloff);
            m_CSBoxUtil.SetInt("_ColorizeBlendMode", blendMode);
            m_CSBoxUtil.SetFloat("_ColorizeBlendModeIntensity", blendModeIntensity);
            m_CSBoxUtil.SetFloat("_ColorizeNoiseStrength", noiseStrength);
            m_CSBoxUtil.SetFloat("_ColorizeNoiseScale", noiseScale);
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
            int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
            m_CSBoxUtil.Dispatch(kernelIndex, threadGroups, 1, 1);
            
            editModified = true;
            m_FrameCounter = 0;
        }
        
        /// <summary>
        /// Apply velocity to splats in a sphere region for animation effects
        /// </summary>
        /// <param name="animStyle">0=River, 1=Whirlpool, 2=Wave, 3=RandomLeaves</param>
        /// <param name="disableGravity">If true, zero out Y velocity to prevent falling</param>
        public void ApplyVelocityInSphere(Vector3 worldCenter, float worldRadius, Vector3 velocity, int animStyle = 0, float noiseStrength = 0f, float noiseScale = 1f, bool disableGravity = true)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return;
            
            // Ensure velocity buffer exists
            if (m_GpuSplatVelocities == null)
                CreatePhysicsBuffers();
            
            if (m_GpuSplatVelocities == null)
                return;
            
            int kernelIndex = GetKernelIndex(KernelIndices.ApplyVelocityInSphere);
            if (kernelIndex < 0)
                return;
            
            // Force SplatChunkCount=0 and SplatFormat=0 (Float32) since we've verified Float32 format above
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatPos, m_GpuPosData);
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatChunks, m_GpuChunks);
            m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatVelocities, m_GpuSplatVelocities);
            EnsureAnimFlagsBuffer();
            if (m_GpuSplatAnimFlags != null)
                m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatAnimFlags, m_GpuSplatAnimFlags);
            if (m_GpuSplatPersistentVelocities != null)
                m_CSBoxUtil.SetBuffer(kernelIndex, Props.SplatPersistentVelocities, m_GpuSplatPersistentVelocities);
            m_CSBoxUtil.SetMatrix(Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            m_CSBoxUtil.SetInt(Props.SplatCount, m_SplatCount);
            m_CSBoxUtil.SetInt(Props.SplatChunkCount, 0);
            m_CSBoxUtil.SetInt(Props.SplatFormat, 0);
            m_CSBoxUtil.SetVector("_VelocitySphereCenter", worldCenter);
            m_CSBoxUtil.SetFloat("_VelocitySphereRadius", worldRadius);
            m_CSBoxUtil.SetVector("_VelocityDirection", velocity);
            m_CSBoxUtil.SetInt("_VelocityAnimStyle", animStyle);
            m_CSBoxUtil.SetFloat("_VelocityNoiseStrength", noiseStrength);
            m_CSBoxUtil.SetFloat("_VelocityNoiseScale", noiseScale);
            m_CSBoxUtil.SetFloat("_CustomTime", Time.time);
            m_CSBoxUtil.SetInt("_VelocityDisableGravity", disableGravity ? 1 : 0);
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint groupSizeX, out _, out _);
            int threadGroups = (m_SplatCount + (int)groupSizeX - 1) / (int)groupSizeX;
            m_CSBoxUtil.Dispatch(kernelIndex, threadGroups, 1, 1);
            
            // Enable physics to process the velocities
            if (!m_EnablePhysics)
            {
                m_EnablePhysics = true;
                InitializePhysics();
            }
            
            // Per-splat no-gravity flags are now set in the compute shader
            // so we don't need to modify m_Gravity anymore
            
            editModified = true;
            m_FrameCounter = 0;
        }
        
        /// <summary>
        /// Clear all splat velocities to zero (stops all animation)
        /// </summary>
        public void ClearAllVelocities()
        {
            if (m_SplatCount <= 0)
                return;
            
            Vector3[] zeroVelocities = new Vector3[m_SplatCount];
            
            // Clear current velocities
            if (m_GpuSplatVelocities != null)
                m_GpuSplatVelocities.SetData(zeroVelocities);
            
            // Clear persistent velocities to stop continuous animation
            if (m_GpuSplatPersistentVelocities != null)
                m_GpuSplatPersistentVelocities.SetData(zeroVelocities);
        }
        
        /// <summary>
        /// Clear all per-splat animation flags (re-enables gravity for all splats)
        /// </summary>
        public void ClearAllAnimationFlags()
        {
            if (m_GpuSplatAnimFlags == null || m_SplatCount <= 0)
                return;
            
            int flagWordCount = (m_SplatCount + 31) / 32;
            uint[] zeroFlags = new uint[flagWordCount];
            m_GpuSplatAnimFlags.SetData(zeroFlags);
        }
        
        /// <summary>
        /// Read all splat positions from GPU to CPU buffer (for animation recording)
        /// </summary>
        public bool ReadSplatPositions(Vector3[] buffer)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return false;
            
            if (buffer == null || buffer.Length < m_SplatCount)
                return false;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return false;
            
            if (m_GpuPosData == null)
                return false;
            
            // Read position data from GPU
            float[] rawData = new float[m_SplatCount * 3];
            m_GpuPosData.GetData(rawData);
            
            // Convert to Vector3 array
            for (int i = 0; i < m_SplatCount; i++)
            {
                buffer[i] = new Vector3(
                    rawData[i * 3],
                    rawData[i * 3 + 1],
                    rawData[i * 3 + 2]
                );
            }
            
            return true;
        }
        
        /// <summary>
        /// Write splat positions from CPU buffer to GPU (for animation playback)
        /// </summary>
        public bool WriteSplatPositions(Vector3[] buffer)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return false;
            
            if (buffer == null || buffer.Length < m_SplatCount)
                return false;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return false;
            
            if (m_GpuPosData == null)
                return false;
            
            // Convert Vector3 array to float array
            float[] rawData = new float[m_SplatCount * 3];
            for (int i = 0; i < m_SplatCount; i++)
            {
                rawData[i * 3] = buffer[i].x;
                rawData[i * 3 + 1] = buffer[i].y;
                rawData[i * 3 + 2] = buffer[i].z;
            }
            
            // Write to GPU
            m_GpuPosData.SetData(rawData);
            
            editModified = true;
            m_FrameCounter = 0;
            
            return true;
        }

        /// <summary>
        /// Sample the average color of splats at a world position within a radius
        /// </summary>
        public Color SampleSplatColorAtPosition(Vector3 worldPosition, float worldRadius, Camera cam)
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return Color.gray;
            
            if (asset.posFormat != GaussianSplatAsset.VectorFormat.Float32)
                return Color.gray;
            
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
            Texture colorTex = GpuColorData;
            Color[] colors = null;
            
            if (colorTex is Texture2D tex2D)
            {
                try { colors = tex2D.GetPixels(); }
                catch { return Color.gray; }
            }
            else if (colorTex is RenderTexture rt)
            {
                var prevActive = RenderTexture.active;
                try
                {
                    RenderTexture.active = rt;
                    var tempTex = new Texture2D(texWidth, texHeight, TextureFormat.RGBAHalf, false);
                    tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
                    tempTex.Apply();
                    colors = tempTex.GetPixels();
                    DestroyImmediate(tempTex);
                }
                catch { return Color.gray; }
                finally { RenderTexture.active = prevActive; }
            }
            
            if (colors == null || colors.Length == 0) return Color.gray;
            
            var posBuffer = GpuPosData;
            if (posBuffer == null) return Color.gray;
            
            // Sample ALL splats for accuracy (up to buffer size)
            int splatCount = m_SplatCount;
            float[] posData = new float[splatCount * 3];
            posBuffer.GetData(posData, 0, 0, splatCount * 3);
            
            Transform t = transform;
            Vector3 localCenter = t.InverseTransformPoint(worldPosition);
            float localRadius = worldRadius / Mathf.Max(0.001f, t.lossyScale.x);
            float localRadiusSq = localRadius * localRadius;
            
            Vector3 colorSum = Vector3.zero;
            float weightSum = 0f;
            int count = 0;
            
            // Sample splats in world-space sphere
            for (int i = 0; i < splatCount && count < 500; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                float distSq = (localPos - localCenter).sqrMagnitude;
                
                if (distSq < localRadiusSq)
                {
                    // Use Morton-coded pixel index (matching shader's SplatIndexToPixelIndex)
                    var (texX, texY) = SplatIndexToPixelCoord(i, texWidth);
                    if (texY < texHeight && texX < texWidth)
                    {
                        int colorIdx = texY * texWidth + texX;
                        if (colorIdx < colors.Length)
                        {
                            Color col = colors[colorIdx];
                            // Skip invalid/zero alpha splats
                            if (col.a < 0.01f) continue;
                            
                            // Weight by distance and alpha (closer + more opaque = more influence)
                            float dist = Mathf.Sqrt(distSq);
                            float distWeight = 1f - (dist / localRadius);
                            float weight = distWeight * col.a;
                            
                            colorSum += new Vector3(col.r, col.g, col.b) * weight;
                            weightSum += weight;
                            count++;
                        }
                    }
                }
            }
            
            if (count == 0 || weightSum < 0.001f) return Color.gray;
            
            // Normalize by total weight
            colorSum /= weightSum;
            
            // Return as opaque color
            return new Color(
                Mathf.Clamp01(colorSum.x), 
                Mathf.Clamp01(colorSum.y), 
                Mathf.Clamp01(colorSum.z), 
                1f);
        }
        
        /// <summary>
        /// Convert splat index to texture pixel coordinates (matching shader's SplatIndexToPixelIndex with Morton coding)
        /// </summary>
        private static (int x, int y) SplatIndexToPixelCoord(int idx, int texWidth)
        {
            // Decode Morton 2D 16x16 block
            uint t = (uint)(idx & 0xFF);
            t = (t & 0xFF) | ((t & 0xFE) << 7);
            t &= 0x5555;
            t = (t ^ (t >> 1)) & 0x3333;
            t = (t ^ (t >> 2)) & 0x0f0f;
            int localX = (int)(t & 0xF);
            int localY = (int)(t >> 8);
            
            // Calculate block position
            int blockWidth = texWidth / 16;
            int blockIdx = idx >> 8;
            int blockX = blockIdx % blockWidth;
            int blockY = blockIdx / blockWidth;
            
            return (blockX * 16 + localX, blockY * 16 + localY);
        }

        public void UpdateWindBoxes(WindBoxData[] windBoxes)
        {
            if (m_GpuWindBoxes == null || windBoxes == null) return;
            
            // Resize buffer if needed
            if (windBoxes.Length > m_GpuWindBoxes.count)
            {
                m_GpuWindBoxes?.Dispose();
                int windBoxDataSize = System.Runtime.InteropServices.Marshal.SizeOf<WindBoxData>();
                m_GpuWindBoxes = new GraphicsBuffer(GraphicsBuffer.Target.Structured, 
                    Mathf.Max(windBoxes.Length, 10), windBoxDataSize) { name = "WindBoxes" };
            }
            
            if (windBoxes.Length > 0)
            {
                m_GpuWindBoxes.SetData(windBoxes);
            }
        }

        public bool enablePhysics
        {
            get => m_EnablePhysics;
            set
            {
                if (m_EnablePhysics != value)
                {
                    m_EnablePhysics = value;
                    if (value && HasValidAsset && HasValidRenderSetup)
                    {
                        // Create physics buffers when enabling physics
                        CreatePhysicsBuffers();
                        if (m_DebugPhysics)
                            Debug.Log("Physics enabled and buffers created");
                    }
                    else if (!value)
                    {
                        // Dispose physics buffers when disabling physics
                        DisposeBuffer(ref m_GpuSplatVelocities);
                        DisposeBuffer(ref m_GpuSplatPrevPositions);
                        DisposeBuffer(ref m_GpuSphereColliders);
                        DisposeBuffer(ref m_GpuSplatPersistentVelocities);
                        if (m_DebugPhysics)
                            Debug.Log("Physics disabled and buffers disposed");
                    }
                }
            }
        }

        /// <summary>
        /// Enable/disable distance-based culling of splats
        /// </summary>
        public bool enableDistanceCulling
        {
            get => m_EnableDistanceCulling;
            set => m_EnableDistanceCulling = value;
        }

        /// <summary>
        /// Distance in meters beyond which splats are culled
        /// </summary>
        public float killRadius
        {
            get => m_KillRadius;
            set => m_KillRadius = Mathf.Max(0.1f, value);
        }

        /// <summary>
        /// Origin point for distance culling. If null, uses camera position.
        /// </summary>
        public Transform cullOrigin
        {
            get => m_CullOrigin;
            set => m_CullOrigin = value;
        }

        /// <summary>
        /// Automatically perform distance culling periodically
        /// </summary>
        public bool autoDistanceCull
        {
            get => m_AutoDistanceCull;
            set => m_AutoDistanceCull = value;
        }

        /// <summary>
        /// Perform distance culling every N frames (for performance)
        /// </summary>
        public int cullEveryNthFrame
        {
            get => m_CullEveryNthFrame;
            set => m_CullEveryNthFrame = Mathf.Max(1, value);
        }

        /// <summary>
        /// Perform distance-based culling of splats beyond the kill radius
        /// </summary>
        /// <param name="camera">Camera to use as origin if no cullOrigin is set</param>
        public void PerformDistanceCulling(Camera camera = null)
        {
            if (!m_EnableDistanceCulling || !HasValidAsset || !HasValidRenderSetup)
                return;

            if (!EnsureEditingBuffers())
                return;

            camera ??= Camera.main;
            if (camera == null)
                return;

            using var cmb = new CommandBuffer { name = "DistanceCull" };
            
            int kernelIndex = GetKernelIndex(KernelIndices.DistanceCull);
            if (kernelIndex < 0) return;

            // Set required buffers and parameters
            SetAssetDataOnCS(cmb, KernelIndices.DistanceCull);
            
            // Set distance culling parameters
            cmb.SetComputeIntParam(m_CSBoxUtil, Props.EnableDistanceCulling, m_EnableDistanceCulling ? 1 : 0);
            cmb.SetComputeFloatParam(m_CSBoxUtil, Props.KillRadius, m_KillRadius);
            Vector3 cullOriginPos = m_CullOrigin != null ? m_CullOrigin.position : camera.transform.position;
            cmb.SetComputeVectorParam(m_CSBoxUtil, Props.CullOrigin, cullOriginPos);
            
            cmb.SetComputeMatrixParam(m_CSBoxUtil, Props.MatrixObjectToWorld, transform.localToWorldMatrix);
            
            m_CSBoxUtil.GetKernelThreadGroupSizes(kernelIndex, out uint gsX, out _, out _);
            cmb.DispatchCompute(m_CSBoxUtil, kernelIndex, (m_SplatCount + (int)gsX - 1) / (int)gsX, 1, 1);
            
            Graphics.ExecuteCommandBuffer(cmb);
            
            // Update edit counts and bounds after culling
            UpdateEditCountsAndBounds();
            editModified = true;
        }

        /// <summary>
        /// Get the number of splats that have been culled by distance
        /// </summary>
        /// <returns>Number of culled splats</returns>
        public uint GetCulledSplatsCount()
        {
            return editDeletedSplats;
        }

        /// <summary>
        /// Reset physics state - clears all velocities and resets positions
        /// </summary>
        public void ResetPhysics()
        {
            if (m_EnablePhysics && HasValidAsset && HasValidRenderSetup)
            {
                // Recreate physics buffers to reset all velocities to zero
                DisposeBuffer(ref m_GpuSplatVelocities);
                DisposeBuffer(ref m_GpuSplatPrevPositions);
                DisposeBuffer(ref m_GpuSplatPersistentVelocities);
                
                // Recreate the buffers
                m_GpuSplatVelocities = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatVelocities" };
                m_GpuSplatPrevPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatPrevPositions" };
                m_GpuSplatPersistentVelocities = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatPersistentVelocities" };
                
                // Initialize persistent velocities to zero
                Vector3[] zeroVelocities = new Vector3[m_SplatCount];
                m_GpuSplatPersistentVelocities.SetData(zeroVelocities);
                
                // Reinitialize
                InitializePhysics();
                
                Debug.Log("Physics reset completed");
            }
        }

        /// <summary>
        /// Capture current splat positions as the new "original" positions for restoration
        /// </summary>
        public void CaptureOriginalPositions()
        {
            if (!HasValidAsset || !HasValidRenderSetup)
            {
                Debug.LogWarning("Cannot capture original positions - invalid asset or render setup");
                return;
            }

            // Ensure original positions buffer exists
            if (m_GpuSplatOriginalPositions == null && m_SplatCount > 0)
            {
                m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
            }

            if (m_GpuSplatOriginalPositions != null)
            {
                InitializeOriginalPositions();
                Debug.Log("Original positions captured for restoration");
            }
        }


        /// <summary>
        /// Enable/disable wind effects on splats
        /// </summary>
        public bool enableWind
        {
            get => m_EnableWind;
            set
            {
                if (m_EnableWind != value)
                {
                    m_EnableWind = value;
                    if (value && HasValidAsset && HasValidRenderSetup)
                    {
                        // Create wind buffers when enabling wind
                        if (m_GpuWindBoxes == null)
                            CreateWindBuffers();
                        
                        // Enable physics if not already enabled (wind needs physics buffers)
                        if (!m_EnablePhysics)
                        {
                            m_EnablePhysics = true;
                            CreatePhysicsBuffers();
                        }
                        
                        // Ensure original positions buffer exists for restoration
                        if (m_GpuSplatOriginalPositions == null && m_SplatCount > 0)
                        {
                            m_GpuSplatOriginalPositions = new GraphicsBuffer(GraphicsBuffer.Target.Structured, m_SplatCount, 12) { name = "SplatOriginalPositions" };
                            InitializeOriginalPositions();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Update wind forces every N frames for performance
        /// </summary>
        public int windUpdateEveryNthFrame
        {
            get => m_WindUpdateEveryNthFrame;
            set => m_WindUpdateEveryNthFrame = Mathf.Max(1, value);
        }

        /// <summary>
        /// Gravity applied to wind-affected splats
        /// </summary>
        public float windGravity
        {
            get => m_WindGravity;
            set => m_WindGravity = value;
        }

        /// <summary>
        /// Damping applied to wind movement
        /// </summary>
        public float windDamping
        {
            get => m_WindDamping;
            set => m_WindDamping = Mathf.Clamp01(value);
        }

        /// <summary>
        /// Minimum velocity threshold for wind effects
        /// </summary>
        public float windMinVelocity
        {
            get => m_WindMinVelocity;
            set => m_WindMinVelocity = Mathf.Max(0f, value);
        }

        public void DebugPhysicsCoordinates()
        {
            if (!HasValidAsset) return;
            
            Debug.Log("=== Physics Coordinate Debug ===");
            Debug.Log($"Splat Renderer Transform Position: {transform.position}");
            Debug.Log($"Splat Renderer Transform Rotation: {transform.rotation.eulerAngles}");
            Debug.Log($"Asset Bounds Min: {asset.boundsMin}");
            Debug.Log($"Asset Bounds Max: {asset.boundsMax}");
            
            var localCenter = (asset.boundsMax + asset.boundsMin) * 0.5f;
            var worldCenter = transform.TransformPoint(localCenter);
            Debug.Log($"Local Center: {localCenter}");
            Debug.Log($"World Center: {worldCenter}");
            Debug.Log($"Active Sphere Colliders: {m_ActiveSphereColliderCount}");
        }

        public void DebugWindSystem()
        {
            Debug.Log("=== Wind System Debug ===");
            Debug.Log($"Wind Enabled: {m_EnableWind}");
            Debug.Log($"Physics Enabled: {m_EnablePhysics}");
            Debug.Log($"Has Valid Asset: {HasValidAsset}");
            Debug.Log($"Has Valid Render Setup: {HasValidRenderSetup}");
            Debug.Log($"Velocity Buffer Exists: {m_GpuSplatVelocities != null}");
            Debug.Log($"Wind Buffer Exists: {m_GpuWindBoxes != null}");
            Debug.Log($"Original Positions Buffer Exists: {m_GpuSplatOriginalPositions != null}");
            Debug.Log($"Splat Count: {m_SplatCount}");
            
            Debug.Log($"=== PHYSICS CONFLICT CHECK ===");
            Debug.Log($"Sphere Colliders: {m_ActiveSphereColliderCount}");
            Debug.Log($"Wind Boxes: {m_ActiveWindBoxCount}");
            Debug.Log($"Attractors: {m_ActiveAttractorCount}");
            
            if (m_ActiveSphereColliderCount > 0 && m_ActiveWindBoxCount > 0)
            {
                Debug.LogWarning("CONFLICT: Both sphere colliders AND wind boxes are active! They may interfere with each other.");
                Debug.LogWarning("Recommendation: Disable sphere colliders when using wind effects, or vice versa.");
            }
            
            // Check kernel availability
            if (m_KernelIndices != null && m_KernelIndices.ContainsKey(KernelIndices.ApplyWindForces))
            {
                int windKernel = m_KernelIndices[KernelIndices.ApplyWindForces];
                Debug.Log($"Wind kernel index: {windKernel}");
            }
            else
            {
                Debug.LogError("Wind kernel not found in kernel indices!");
            }
        }

        // One-shot diagnostic for the "Vulkan: Shader requires a compute buffer X, but none provided"
        // messages. Vulkan skips a draw whose descriptor set is incomplete; D3D11 silently tolerates it.
        // Logs the state of every buffer the relight ForwardLit pass consumes at the moment we draw.
        static bool s_LoggedDrawBindings;

        internal void LogDrawBindingsOnce(int instanceCount)
        {
            if (s_LoggedDrawBindings)
                return;
            s_LoggedDrawBindings = true;

            static string Describe(GraphicsBuffer b) =>
                b == null ? "NULL" : !b.IsValid() ? "INVALID" : $"ok(count={b.count})";

            Debug.Log(
                $"[SplatBox] first splat draw on {SystemInfo.graphicsDeviceType}: shader=" +
                $"{(m_MatSplats != null && m_MatSplats.shader != null ? m_MatSplats.shader.name : "NULL")}, " +
                $"instances={instanceCount}, indexBuffer={Describe(m_GpuIndexBuffer)}\n" +
                $"  _OrderBuffer <- m_GpuSortKeys            : {Describe(m_GpuSortKeys)}\n" +
                $"  _SplatViewData <- m_GpuView              : {Describe(m_GpuView)}\n" +
                $"  _SplatSelectedBits <- editSel ?? pos     : {Describe(m_GpuEditSelected)} ?? {Describe(m_GpuPosData)}\n" +
                $"  _SplatTargetSelectedBits <- tgtSel ?? pos: {Describe(m_GpuEditTargetSelected)} ?? {Describe(m_GpuPosData)}");
        }

        public void CheckShaderBindings()
{
    Debug.Log($"Checking shader bindings:");
    Debug.Log($"Material valid: {m_MatSplats != null}");
    if (m_MatSplats != null)
    {
        Debug.Log($"Shader valid: {m_MatSplats.shader != null}");
        Debug.Log($"_OrderBuffer bound: {m_MatSplats.HasProperty("_OrderBuffer")}");
        Debug.Log($"_SplatViewData bound: {m_MatSplats.HasProperty("_SplatViewData")}");
        Debug.Log($"_SplatSelectedBits bound: {m_MatSplats.HasProperty("_SplatSelectedBits")}");
    }
    
    Debug.Log($"GPU Buffers:");
    Debug.Log($"PosData: {m_GpuPosData != null}");
    Debug.Log($"OtherData: {m_GpuOtherData != null}");
    Debug.Log($"SHData: {m_GpuSHData != null}");
    Debug.Log($"ColorData: {m_GpuColorData != null}");
    Debug.Log($"View: {m_GpuView != null}");
    Debug.Log($"SortKeys: {m_GpuSortKeys != null}");
}

        /// <summary>
        /// Samples the average color of splats within a radius around a world-space position
        /// </summary>
        /// <param name="worldPosition">World-space position to sample around</param>
        /// <param name="radius">Radius to search for splats</param>
        /// <returns>Average color of splats found, or Color.clear if none found</returns>
        public Color SampleColorAtPosition(Vector3 worldPosition, float radius)
        {
            if (!HasValidAsset || !HasValidRenderSetup)
            {
                Debug.LogWarning("Cannot sample color - invalid asset or render setup");
                return Color.clear;
            }

            // Convert world position to local space
            Vector3 localPosition = transform.InverseTransformPoint(worldPosition);
            
            // Read position and color data from GPU
            int posStride = (int)(asset.posData.dataSize / asset.splatCount);
            int posInts = posStride / 4;
            uint[] posData = new uint[m_SplatCount * posInts];
            m_GpuPosData.GetData(posData);
            
            // Read color data from texture
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
            Texture2D colorTex = m_GpuColorData as Texture2D;
            Color[] colors = null;
            
            if (colorTex == null)
            {
                // If it's a RenderTexture, we need to read it differently
                RenderTexture rt = m_GpuColorData as RenderTexture;
                if (rt != null)
                {
                    RenderTexture.active = rt;
                    colorTex = new Texture2D(texWidth, texHeight, rt.graphicsFormat, TextureCreationFlags.None);
                    colorTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
                    colorTex.Apply();
                    RenderTexture.active = null;
                    colors = colorTex.GetPixels();
                    DestroyImmediate(colorTex);
                }
            }
            else
            {
                try
                {
                    colors = colorTex.GetPixels();
                }
                catch
                {
                    Debug.LogWarning("Cannot read color texture - it may not be readable");
                    return Color.clear;
                }
            }
            
            if (colors == null)
            {
                Debug.LogWarning("Failed to read color data");
                return Color.clear;
            }

            // Find splats within radius and accumulate their colors
            Color accumulatedColor = Color.clear;
            int splatCount = 0;
            float radiusSqr = radius * radius;
            
            for (int i = 0; i < m_SplatCount; i++)
            {
                // Decode position based on format
                Vector3 splatPos = DecodeSplatPosition(posData, i, posInts);
                
                // Check if within radius
                float distSqr = (splatPos - localPosition).sqrMagnitude;
                if (distSqr <= radiusSqr)
                {
                    // Get color from texture
                    var coords = GaussianUtils.DecodeMorton2D_16x16((uint)i);
                    int x = (int)coords.x;
                    int y = (int)coords.y;
                    int index = y * texWidth + x;
                    
                    if (index < colors.Length)
                    {
                        accumulatedColor += colors[index];
                        splatCount++;
                    }
                }
            }
            
            // Return average color
            if (splatCount > 0)
            {
                accumulatedColor /= splatCount;
                accumulatedColor.a = 1.0f; // Set alpha to 1 to indicate valid color
                return accumulatedColor;
            }
            
            return Color.clear; // No splats found
        }

        /// <summary>
        /// Clears equirectangular projection by restoring original colors from the asset
        /// </summary>
        public void ClearEquirectangularProjection()
        {
            if (!HasValidAsset || !HasValidRenderSetup)
            {
                Debug.LogWarning("Cannot clear equirectangular projection - invalid asset or render setup");
                return;
            }

            // Check if color data is a RenderTexture (meaning it was modified)
            RenderTexture rt = m_GpuColorData as RenderTexture;
            if (rt != null)
            {
                // Reload original colors from asset
                var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(m_SplatCount);
                var texFormat = GaussianSplatAsset.ColorFormatToGraphics(asset.colorFormat);
                
                Texture2D originalTex = new Texture2D(texWidth, texHeight, texFormat, TextureCreationFlags.DontInitializePixels | TextureCreationFlags.DontUploadUponCreate) { name = "OriginalColorData" };
                originalTex.SetPixelData(asset.colorData.GetData<byte>(), 0);
                originalTex.Apply(false, false);
                
                // Blit original colors back to RenderTexture
                Graphics.Blit(originalTex, rt);
                
                // Clean up temporary texture
                DestroyImmediate(originalTex);
                
                editModified = true;
            }
            // If it's still a Texture2D, colors haven't been modified yet - nothing to clear
        }

        /// <summary>
        /// Decodes all splat local positions from the GPU position buffer, supporting every
        /// VectorFormat (Float32/Norm16/Norm11/Norm6) and applying chunk lerp where present.
        /// Mirrors LoadSplatPos in BoxUtil.compute so CPU-based edits match GPU decoding.
        /// </summary>
        private Vector3[] GetDecodedLocalPositions()
        {
            if (!HasValidAsset || m_GpuPosData == null || m_SplatCount <= 0)
                return null;

            int posSize = GaussianSplatAsset.GetVectorSize(asset.posFormat);
            byte[] raw = new byte[posSize * m_SplatCount];
            m_GpuPosData.GetData(raw, 0, 0, posSize * m_SplatCount);

            bool useChunks = m_GpuChunksValid && m_GpuChunks != null && m_GpuChunks.count > 0;
            GaussianSplatAsset.ChunkInfo[] chunks = null;
            if (useChunks)
            {
                chunks = new GaussianSplatAsset.ChunkInfo[m_GpuChunks.count];
                m_GpuChunks.GetData(chunks);
            }

            Vector3[] result = new Vector3[m_SplatCount];
            for (int i = 0; i < m_SplatCount; i++)
            {
                Vector3 p = DecodeRawPosition(raw, i * posSize, asset.posFormat);
                if (useChunks)
                {
                    int chunkIdx = i / GaussianSplatAsset.kChunkSize;
                    if (chunkIdx < chunks.Length)
                    {
                        var c = chunks[chunkIdx];
                        p = new Vector3(
                            Mathf.Lerp(c.posX.x, c.posX.y, p.x),
                            Mathf.Lerp(c.posY.x, c.posY.y, p.y),
                            Mathf.Lerp(c.posZ.x, c.posZ.y, p.z));
                    }
                }
                result[i] = p;
            }
            return result;
        }

        /// <summary>
        /// Decodes a single packed position from a raw byte buffer at the given byte offset.
        /// Matches LoadAndDecodeVector / DecodePacked_* in BoxUtil.compute.
        /// </summary>
        private static Vector3 DecodeRawPosition(byte[] raw, int byteOffset, GaussianSplatAsset.VectorFormat fmt)
        {
            switch (fmt)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    return new Vector3(
                        BitConverter.ToSingle(raw, byteOffset),
                        BitConverter.ToSingle(raw, byteOffset + 4),
                        BitConverter.ToSingle(raw, byteOffset + 8));

                case GaussianSplatAsset.VectorFormat.Norm16:
                {
                    ushort x = BitConverter.ToUInt16(raw, byteOffset);
                    ushort y = BitConverter.ToUInt16(raw, byteOffset + 2);
                    ushort z = BitConverter.ToUInt16(raw, byteOffset + 4);
                    return new Vector3(x / 65535.0f, y / 65535.0f, z / 65535.0f);
                }

                case GaussianSplatAsset.VectorFormat.Norm11:
                {
                    uint enc = BitConverter.ToUInt32(raw, byteOffset);
                    return new Vector3(
                        (enc & 2047) / 2047.0f,
                        ((enc >> 11) & 1023) / 1023.0f,
                        ((enc >> 21) & 2047) / 2047.0f);
                }

                case GaussianSplatAsset.VectorFormat.Norm6:
                {
                    uint enc = BitConverter.ToUInt16(raw, byteOffset);
                    return new Vector3(
                        (enc & 63) / 63.0f,
                        ((enc >> 6) & 31) / 31.0f,
                        ((enc >> 11) & 31) / 31.0f);
                }

                default:
                    return Vector3.zero;
            }
        }

        /// <summary>
        /// Decodes a splat position from GPU data based on the asset's position format
        /// </summary>
        private Vector3 DecodeSplatPosition(uint[] posData, int splatIndex, int posInts)
        {
            int offset = splatIndex * posInts;
            
            // Handle different position formats
            switch (asset.posFormat)
            {
                case GaussianSplatAsset.VectorFormat.Float32:
                    // 3 floats (12 bytes)
                    return new Vector3(
                        BitConverter.ToSingle(BitConverter.GetBytes(posData[offset]), 0),
                        BitConverter.ToSingle(BitConverter.GetBytes(posData[offset + 1]), 0),
                        BitConverter.ToSingle(BitConverter.GetBytes(posData[offset + 2]), 0)
                    );
                    
                case GaussianSplatAsset.VectorFormat.Norm16:
                    // Packed in fewer bytes - need to unpack
                    // For simplicity, approximate as normalized values
                    ushort x = (ushort)(posData[offset] & 0xFFFF);
                    ushort y = (ushort)((posData[offset] >> 16) & 0xFFFF);
                    ushort z = (ushort)(posData[offset + 1] & 0xFFFF);
                    
                    // Convert from normalized 16-bit to world coordinates using asset bounds
                    Vector3 boundsMin = asset.boundsMin;
                    Vector3 boundsMax = asset.boundsMax;
                    
                    return new Vector3(
                        Mathf.Lerp(boundsMin.x, boundsMax.x, x / 65535.0f),
                        Mathf.Lerp(boundsMin.y, boundsMax.y, y / 65535.0f),
                        Mathf.Lerp(boundsMin.z, boundsMax.z, z / 65535.0f)
                    );
                    
                default:
                    // Unsupported format
                    return Vector3.zero;
            }
        }
        
        /// <summary>
        /// Creates a snapshot of the current color texture for undo purposes
        /// </summary>
        public RenderTexture CreateColorSnapshot()
        {
            if (!HasValidAsset || !HasValidRenderSetup || m_SplatCount <= 0)
                return null;
            
            EnsureColorTextureIsWritable();
            RenderTexture srcRT = m_GpuColorData as RenderTexture;
            if (srcRT == null) return null;
            
            RenderTexture snapshot = new RenderTexture(srcRT.width, srcRT.height, 0, srcRT.graphicsFormat);
            snapshot.enableRandomWrite = true;
            snapshot.name = "ColorUndoSnapshot";
            snapshot.Create();
            
            Graphics.Blit(srcRT, snapshot);
            return snapshot;
        }
        
        /// <summary>
        /// Restores color texture from a snapshot
        /// </summary>
        public void RestoreColorSnapshot(RenderTexture snapshot)
        {
            if (snapshot == null || !HasValidAsset || !HasValidRenderSetup)
                return;
            
            EnsureColorTextureIsWritable();
            RenderTexture dstRT = m_GpuColorData as RenderTexture;
            if (dstRT == null) return;
            
            Graphics.Blit(snapshot, dstRT);
            editModified = true;
            m_FrameCounter = 0;
        }
    }
    
    /// <summary>
    /// Settings for smart splat decimation (VR / memory reduction).
    /// </summary>
    [System.Serializable]
    public struct DecimationSettings
    {
        [Range(0f, 0.95f)] public float removalRatio;
        [Range(0f, 2f)] public float opacityWeight;
        [Range(0f, 2f)] public float sizeWeight;
        [Range(0f, 2f)] public float anisotropyPenalty;
        /// <summary>Max object-space scale axis; splats above this are penalized. 0 = auto (25% of bounds diagonal).</summary>
        public float maxScale;

        public static DecimationSettings DefaultVR => new DecimationSettings
        {
            removalRatio = 0.5f,
            opacityWeight = 1f,
            sizeWeight = 0.6f,
            anisotropyPenalty = 0.5f,
            maxScale = 0f
        };
    }

    /// <summary>
    /// Data for sphere colliders used in physics simulation
    /// </summary>
    [System.Serializable]
    public struct SphereColliderData
    {
        public Vector3 position;
        public Vector3 velocity;
        public float radius;
        public float mass;
        public float restitution;
    }
    
    /// <summary>
    /// Data for wind box volumes
    /// </summary>
    [System.Serializable]
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct WindBoxData
    {
        public Matrix4x4 worldToBox;
        public Vector3 windDirection;
        public float windStrength;
        public float noiseStrength;
        public float noiseScale;
        public float noiseSpeed;
        public uint flags;
        public Vector3 boxCenter;
        public float restoreSpeed;
        public float restoreStrength;
        public float individualVariation;
        public float windStrengthThreshold;
        public float turbulenceSpread;
    }
    
    /// <summary>
    /// Color adjustments for splat operations
    /// </summary>
    [System.Serializable]
    public struct ColorAdjustments
    {
        [Range(-2f, 5f)] public float exposure;
        [Range(0f, 2f)] public float contrast;
        [Range(-180f, 180f)] public float hueShift;
        [Range(0f, 2f)] public float saturation;
        public Color colorTint;
        
        public static ColorAdjustments Default => new ColorAdjustments
        {
            exposure = 0f,
            contrast = 1f,
            hueShift = 0f,
            saturation = 1f,
            colorTint = Color.white
        };
        
        public bool HasAdjustments => 
            Mathf.Abs(exposure) > 0.001f || 
            Mathf.Abs(contrast - 1f) > 0.001f || 
            Mathf.Abs(hueShift) > 0.1f || 
            Mathf.Abs(saturation - 1f) > 0.001f ||
            colorTint != Color.white;
    }
    
    /// <summary>
    /// Attractor data for compute shader - must match BoxUtil.compute
    /// </summary>
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct AttractorData
    {
        public Vector3 position;
        public float strength;
        public float range;
        public float falloff;
        public int mode;
        public float enabled;
        public float vortexHeight;
        public float waveFrequency;
        public float waveAmplitude;
        public float waveSpeed;
        public int waveAxis;
        public float curlStrength;
        public float secondaryFrequency;
        public Quaternion rotation;
        public Vector3 scale;
        public float scalePadding;
    }
}
 