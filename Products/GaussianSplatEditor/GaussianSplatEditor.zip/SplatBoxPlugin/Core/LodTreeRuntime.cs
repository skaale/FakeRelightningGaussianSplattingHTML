// SPDX-License-Identifier: MIT

using System;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Runtime-usable form of a page LoD tree.
    ///
    /// LoD screen-size tests need every node's featureSize to be the spatial diameter of its whole
    /// subtree. Level-order trees (page asset v2) are built that way and address children directly
    /// through childStart, so they need no work beyond a bounds check. Legacy depth-first trees (v1)
    /// store the merged Gaussian's own scale and only link their first child, so they get an
    /// explicit child table and a recomputed set of extents.
    /// </summary>
    public sealed class LodTreeRuntime
    {
        public LodTreeNode[] nodes;
        public int[] childTable;
        public int[] childTableStart;
        public int leafCount;
        public float rootExtent;
        public bool levelOrder;

        public int nodeCount => nodes?.Length ?? 0;

        /// <summary>Takes ownership of <paramref name="source"/>; the caller must not reuse it.</summary>
        public static LodTreeRuntime Build(LodTreeNode[] source, bool levelOrder)
        {
            if (source == null || source.Length == 0)
                return null;
            return levelOrder ? BuildLevelOrder(source) : BuildFromPreOrder(source);
        }

        /// <summary>
        /// Coarse form of a level-order page, built from a prefix of its nodes. Children that fall
        /// past the end of the prefix are dropped, which turns the last level into leaves while
        /// leaving their subtree extents intact so they still measure correctly on screen.
        /// </summary>
        public static LodTreeRuntime BuildPrefix(LodTreeNode[] prefix) =>
            prefix == null || prefix.Length == 0 ? null : BuildLevelOrder(prefix);

        /// <summary>
        /// Level order needs no child table (siblings sit at [childStart, childStart+count)) and no
        /// extent pass, because the builder already stores subtree diameters. All that is left is
        /// clamping child ranges to the array, which also does the prefix truncation for free.
        /// </summary>
        static LodTreeRuntime BuildLevelOrder(LodTreeNode[] nodes)
        {
            int n = nodes.Length;
            int leaves = 0;
            for (int i = 0; i < n; i++)
            {
                nodes[i].featureSize = math.max(nodes[i].featureSize, 1e-4f);

                long start = nodes[i].childStart;
                if (nodes[i].childCount != 0)
                {
                    // Mark before clamping: a prefix cut may zero childCount below, but the node is
                    // still a merged stand-in, not real scene content.
                    nodes[i].flags |= LodTreeNode.kFlagMerged;

                    if (start <= i || start >= n)
                        nodes[i].childCount = 0;
                    else if (start + nodes[i].childCount > n)
                        nodes[i].childCount = (ushort)Mathf.Max(0, (int)(n - start));
                }

                if (nodes[i].childCount == 0)
                    leaves++;
            }

            return new LodTreeRuntime
            {
                nodes = nodes,
                childTable = null,
                childTableStart = null,
                leafCount = leaves,
                rootExtent = nodes[0].featureSize,
                levelOrder = true
            };
        }

        /// <summary>
        /// Legacy depth-first pages: only the first child sits at childStart, so recover the real
        /// links from the pre-order walk and store them in an explicit table.
        /// </summary>
        static LodTreeRuntime BuildFromPreOrder(LodTreeNode[] source)
        {
            int n = source.Length;
            var nodes = new LodTreeNode[n];
            Array.Copy(source, nodes, n);

            var parent = ResolveParentsFromPreOrder(nodes);
            var childTableStart = new int[n];
            int totalChildren = 0;
            for (int i = 0; i < n; i++)
            {
                if (nodes[i].childCount != 0)
                    nodes[i].flags |= LodTreeNode.kFlagMerged;
                childTableStart[i] = totalChildren;
                totalChildren += nodes[i].childCount;
            }

            var childTable = new int[Mathf.Max(1, totalChildren)];
            var fill = new int[n];
            Array.Copy(childTableStart, fill, n);
            for (int i = 1; i < n; i++)
            {
                int p = parent[i];
                if (p < 0)
                    continue;
                int slot = fill[p];
                if (slot < childTableStart[p] + nodes[p].childCount && slot < childTable.Length)
                {
                    childTable[slot] = i;
                    fill[p] = slot + 1;
                }
            }

            // Trailing unfilled slots would alias node 0; clamp childCount to what was actually linked.
            for (int i = 0; i < n; i++)
            {
                int linked = fill[i] - childTableStart[i];
                if (linked < nodes[i].childCount)
                    nodes[i].childCount = (ushort)Mathf.Max(0, linked);
            }

            int leaves = ComputeExtentsWithTable(nodes, childTable, childTableStart);
            return new LodTreeRuntime
            {
                nodes = nodes,
                childTable = childTable,
                childTableStart = childTableStart,
                leafCount = leaves,
                rootExtent = nodes[0].featureSize,
                levelOrder = false
            };
        }

        /// <summary>
        /// Walks depth-first pre-order using each node's childCount to recover parent links.
        /// </summary>
        static int[] ResolveParentsFromPreOrder(LodTreeNode[] nodes)
        {
            int n = nodes.Length;
            var parent = new int[n];
            var stackNode = new int[n];
            var stackRemaining = new int[n];
            int depth = 0;

            for (int i = 0; i < n; i++)
            {
                if (depth > 0)
                {
                    parent[i] = stackNode[depth - 1];
                    stackRemaining[depth - 1]--;
                }
                else
                {
                    parent[i] = -1;
                }

                if (nodes[i].childCount > 0 && depth < n)
                {
                    stackNode[depth] = i;
                    stackRemaining[depth] = nodes[i].childCount;
                    depth++;
                }
                else
                {
                    while (depth > 0 && stackRemaining[depth - 1] <= 0)
                        depth--;
                }
            }

            return parent;
        }

        // Pre-order places a parent before its children, so one reverse pass resolves the tree.
        static int ComputeExtentsWithTable(LodTreeNode[] nodes, int[] childTable, int[] childTableStart)
        {
            int leaves = 0;
            for (int i = nodes.Length - 1; i >= 0; i--)
            {
                int count = nodes[i].childCount;
                if (count == 0)
                {
                    leaves++;
                    nodes[i].featureSize = math.max(nodes[i].featureSize, 1e-4f);
                    continue;
                }

                float3 center = nodes[i].center;
                float radius = nodes[i].featureSize * 0.5f;
                int start = childTableStart[i];
                for (int c = 0; c < count; c++)
                    radius = math.max(radius, ChildReach(nodes, center, childTable[start + c], i));
                nodes[i].featureSize = math.max(radius * 2f, 1e-4f);
            }
            return leaves;
        }

        static float ChildReach(LodTreeNode[] nodes, float3 center, int childIdx, int parentIdx)
        {
            if (childIdx <= parentIdx || childIdx >= nodes.Length)
                return 0f;
            return math.distance(center, nodes[childIdx].center) + nodes[childIdx].featureSize * 0.5f;
        }
    }
}
