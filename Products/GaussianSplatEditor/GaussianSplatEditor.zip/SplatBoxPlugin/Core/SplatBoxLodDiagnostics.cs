// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Opt-in activity log for the paged LoD pipeline. When enabled it prints one summary line
    /// per second describing everything that can visibly change the image — selections (and why
    /// they ran), sorts, atlas rebuilds, buffer reallocations, page swaps and the drawn splat
    /// count range — so a flicker can be attributed to the subsystem that is actually pulsing.
    /// Toggle from "Tools/Splat Box/Log LoD Activity". Costs nothing while disabled.
    /// </summary>
    public static class SplatBoxLodDiagnostics
    {
        public static bool enabled;

        static float s_WindowStart;
        static int s_Selections;
        static int s_SelectionsDirty;
        static int s_SelectionsView;
        static int s_SelectionsRamp;
        static int s_Sorts;
        static int s_KeyResets;
        static int s_AtlasRebuilds;
        static int s_BudgetReallocs;
        static int s_PageEvents;
        static int s_ViewCalcs;
        static int s_MinActive = int.MaxValue;
        static int s_MaxActive = int.MinValue;
        static int s_LastSelected;
        static int s_ExhaustedSelections;
        static int s_DroppedStandIns;

        public static void RecordSelection(int selected, bool dirty, bool viewChanged, bool ramping,
            bool budgetExhausted, int droppedStandIns)
        {
            if (!enabled) return;
            s_Selections++;
            if (dirty) s_SelectionsDirty++;
            if (viewChanged) s_SelectionsView++;
            if (ramping) s_SelectionsRamp++;
            if (budgetExhausted) s_ExhaustedSelections++;
            s_DroppedStandIns += droppedStandIns;
            s_LastSelected = selected;
        }

        public static void RecordSort() { if (enabled) s_Sorts++; }
        public static void RecordKeyReset() { if (enabled) s_KeyResets++; }
        public static void RecordAtlasRebuild() { if (enabled) s_AtlasRebuilds++; }
        public static void RecordBudgetRealloc() { if (enabled) s_BudgetReallocs++; }
        public static void RecordPageEvent() { if (enabled) s_PageEvents++; }
        public static void RecordViewCalc() { if (enabled) s_ViewCalcs++; }

        /// <summary>Call once per LoD update with the current drawn splat count; emits the report.</summary>
        public static void Heartbeat(int activeSplatCount)
        {
            if (!enabled) return;
            s_MinActive = Mathf.Min(s_MinActive, activeSplatCount);
            s_MaxActive = Mathf.Max(s_MaxActive, activeSplatCount);

            float now = Time.realtimeSinceStartup;
            if (s_WindowStart <= 0f)
            {
                s_WindowStart = now;
                return;
            }
            float span = now - s_WindowStart;
            if (span < 1f)
                return;

            Debug.Log(
                $"[SplatBox LoD] {span:F1}s | selections {s_Selections} " +
                $"(dirty {s_SelectionsDirty}, view {s_SelectionsView}, ramp {s_SelectionsRamp}, " +
                $"budget-bound {s_ExhaustedSelections}, last {s_LastSelected:N0} splats) | " +
                $"drawn min {(s_MinActive == int.MaxValue ? 0 : s_MinActive):N0} " +
                $"max {(s_MaxActive == int.MinValue ? 0 : s_MaxActive):N0} | " +
                $"sorts {s_Sorts} | key resets {s_KeyResets} | atlas rebuilds {s_AtlasRebuilds} | " +
                $"buffer reallocs {s_BudgetReallocs} | page swaps {s_PageEvents} | " +
                $"view calcs {s_ViewCalcs} | dropped stand-ins {s_DroppedStandIns}");

            s_WindowStart = now;
            s_Selections = s_SelectionsDirty = s_SelectionsView = s_SelectionsRamp = 0;
            s_Sorts = s_KeyResets = s_AtlasRebuilds = s_BudgetReallocs = 0;
            s_PageEvents = s_ViewCalcs = s_ExhaustedSelections = s_DroppedStandIns = 0;
            s_MinActive = int.MaxValue;
            s_MaxActive = int.MinValue;
        }
    }
}
