// SPDX-License-Identifier: MIT

using System;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    [Serializable]
    public struct GaussianSplatPageEntry
    {
        public int pageId;
        public Vector3Int gridCoord;
        public Vector3 boundsMin;
        public Vector3 boundsMax;
        public GaussianSplatPageAsset pageAsset;
        public int splatCount;
        public int lodNodeCount;
    }

    /// <summary>
    /// Manifest for a spatially paged splat scene with offline LoD trees per page.
    /// </summary>
    [CreateAssetMenu(fileName = "SplatPagedScene", menuName = "Gaussian Splatting/Paged Scene")]
    public class GaussianSplatPagedScene : ScriptableObject
    {
        public const int kFormatVersion = 1;

        [SerializeField] int m_FormatVersion = kFormatVersion;
        [SerializeField] Vector3 m_WorldBoundsMin;
        [SerializeField] Vector3 m_WorldBoundsMax;
        [SerializeField] float m_PageCellSize = 64f;
        [SerializeField] GaussianSplatPageEntry[] m_Pages = Array.Empty<GaussianSplatPageEntry>();

        [Header("Quest defaults")]
        [SerializeField] int m_DefaultLodBudget = 500_000;
        [Tooltip("Distance from the camera to the nearest edge of a page at which it becomes a " +
                 "candidate for one of the full-detail slots.")]
        [SerializeField] float m_LoadRadius = 48f;
        [Tooltip("Distance to the nearest edge of a page beyond which it always drops back to its " +
                 "coarse tier. Keep it above Load Radius so pages do not thrash at the boundary.")]
        [SerializeField] float m_UnloadRadius = 58f;
        [SerializeField] int m_MaxLoadedPages = 16;
        [Tooltip("Splats kept resident for every page outside the detail radius, so distant parts of the scene stay visible at low quality.")]
        [SerializeField] int m_CoarsePageSplats = 8192;
        [SerializeField] float m_DefaultOutsideFoveate = 0.4f;
        [SerializeField] float m_DefaultBehindFoveate = 0.2f;
        [SerializeField] float m_DefaultLodPixelScaleLimit;

        public int formatVersion => m_FormatVersion;
        public Vector3 worldBoundsMin => m_WorldBoundsMin;
        public Vector3 worldBoundsMax => m_WorldBoundsMax;
        public float pageCellSize => m_PageCellSize;
        public GaussianSplatPageEntry[] pages => m_Pages;
        public int pageCount => m_Pages != null ? m_Pages.Length : 0;
        public int defaultLodBudget => m_DefaultLodBudget;
        public float loadRadius => m_LoadRadius;
        public float unloadRadius => m_UnloadRadius;
        public int maxLoadedPages => m_MaxLoadedPages;
        public int coarsePageSplats => Mathf.Max(1, m_CoarsePageSplats);
        public float defaultOutsideFoveate => m_DefaultOutsideFoveate;
        public float defaultBehindFoveate => m_DefaultBehindFoveate;
        public float defaultLodPixelScaleLimit => m_DefaultLodPixelScaleLimit;

        public void Initialize(
            Vector3 worldMin,
            Vector3 worldMax,
            float cellSize,
            GaussianSplatPageEntry[] pages,
            int lodBudget = 500_000)
        {
            m_FormatVersion = kFormatVersion;
            m_WorldBoundsMin = worldMin;
            m_WorldBoundsMax = worldMax;
            m_PageCellSize = cellSize;
            m_Pages = pages ?? Array.Empty<GaussianSplatPageEntry>();
            m_DefaultLodBudget = lodBudget;
            m_UnloadRadius = m_LoadRadius * 1.2f;
        }

        public GaussianSplatPageEntry? FindPage(int pageId)
        {
            if (m_Pages == null) return null;
            for (int i = 0; i < m_Pages.Length; i++)
            {
                if (m_Pages[i].pageId == pageId)
                    return m_Pages[i];
            }
            return null;
        }
    }
}
