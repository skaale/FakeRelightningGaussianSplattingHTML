// SPDX-License-Identifier: MIT

using System;
using Unity.Mathematics;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Spark-inspired LoD tree traversal.
    ///
    /// The splat budget is the primary driver: page roots seed a max-heap ordered by on-screen
    /// size, and the largest node is refined repeatedly until the budget is spent. That keeps the
    /// whole scene represented while detail concentrates where it is actually visible.
    /// </summary>
    public static class SplatBoxLodTraverser
    {
        internal struct QueueEntry
        {
            public float pixelScale;
            public int pageIndex;
            public uint nodeIndex;
        }

        public struct PageContext
        {
            public int pageSlot;
            public LodTreeNode[] nodes;
            public int[] childTable;
            public int[] childTableStart;
            public float4x4 localToWorld;
            public float lodScale;
            public float outsideFoveate;
            public float behindFoveate;

            /// <summary>
            /// World units per local unit, derived from <see cref="localToWorld"/> by
            /// <see cref="Traverse"/> once per page. Node centres are transformed to world space but
            /// featureSize stays in the page's own space, so scaling the renderer's transform used to
            /// grow every splat on screen while the traversal kept measuring the original sizes
            /// against the new, larger distances.
            /// </summary>
            internal float featureScale;
        }

        public struct ViewContext
        {
            public float3 cameraWorld;
            public float3 cameraForward;
            public float screenHeight;
            public bool frustumCull;

            /// <summary>
            /// Drop merged stand-in splats instead of drawing them, leaving only real scene splats.
            /// The scene then has holes wherever detail is not resident, but everything drawn is
            /// genuine — useful when a scene was built with a bad merge baked into its pages.
            /// </summary>
            public bool skipMergedSplats;

            /// <summary>
            /// Pixels a one-unit object spans one unit from the camera. Precomputed so the stand-in
            /// coverage test costs a divide instead of a tangent per node.
            /// </summary>
            public float pixelsPerUnitAtUnitDistance;

            /// <summary>
            /// Scale that turns angular size into the pixel domain the traversal orders and thresholds
            /// by. Twice <see cref="pixelsPerUnitAtUnitDistance"/>, which is how this measure has always
            /// been defined, so saved Pixel Scale Limit values keep their meaning.
            /// </summary>
            public float pixelScaleFactor;

            /// <summary>Cosine of the half vertical FOV, for the off-centre foveation test.</summary>
            public float cosHalfFovY;

            /// <summary>
            /// On-screen size in pixels above which a merged stand-in is dropped instead of drawn.
            /// Zero disables the check.
            /// </summary>
            public float maxStandInPixels;

            /// <summary>Global renderer scale applied to every Gaussian covariance.</summary>
            public float splatScale;

            /// <summary>
            /// Cull planes as (normal.xyz, distance). Kept in this form because the per-node test then
            /// costs one dot product, where <see cref="Plane"/> makes it a managed call per plane.
            /// </summary>
            public float4[] cullPlanes;

            /// <summary>
            /// Default cap for merged stand-ins. Paged scenes keep the whole model filled with
            /// coarse tiers, so the renderer default is the top of the slider (512). Lower values
            /// drop large stand-ins and leave holes until detail streams in.
            /// </summary>
            public const float kDefaultMaxStandInPixels = 512f;

            public static ViewContext FromCamera(Camera camera, bool frustumCull, Workspace workspace,
                float cullPaddingDeg = 0f, bool skipMergedSplats = false,
                float maxStandInPixels = kDefaultMaxStandInPixels, float splatScale = 1f)
            {
                float fovY = Mathf.Clamp(camera.fieldOfView, 1f, 179f);
                float screenHeight = camera.pixelHeight > 0 ? camera.pixelHeight : 1080f;
                float halfFovRad = Mathf.Deg2Rad * fovY * 0.5f;
                float pixelsPerUnit = screenHeight / (2f * Mathf.Tan(halfFovRad));
                var ctx = new ViewContext
                {
                    // Match streaming focus (view-matrix origin) so page distance and node projection
                    // agree — important for XR and for Main Camera–driven LoD in the Game view.
                    cameraWorld = GaussianSplatRenderSystem.GetStreamingFocusPosition(camera),
                    cameraForward = camera.transform.forward,
                    screenHeight = screenHeight,
                    frustumCull = frustumCull,
                    skipMergedSplats = skipMergedSplats,
                    pixelsPerUnitAtUnitDistance = pixelsPerUnit,
                    pixelScaleFactor = 2f * pixelsPerUnit,
                    cosHalfFovY = Mathf.Cos(halfFovRad),
                    maxStandInPixels = maxStandInPixels,
                    splatScale = Mathf.Max(0.01f, Mathf.Abs(splatScale)),
                    cullPlanes = null
                };

                if (frustumCull && workspace != null)
                {
                    CalculatePaddedFrustum(camera, cullPaddingDeg, workspace.planeScratch);
                    for (int i = 0; i < 6; i++)
                    {
                        Plane p = workspace.planeScratch[i];
                        workspace.cullPlanes[i] = new float4(p.normal.x, p.normal.y, p.normal.z, p.distance);
                    }
                    ctx.cullPlanes = workspace.cullPlanes;
                }
                return ctx;
            }

            /// <summary>
            /// A camera's own frustum is too tight to cull against in VR: it describes the mono view,
            /// while the headset actually shows the union of two off-axis eye frusta. Widening the
            /// frustum before culling costs a few extra splats and avoids geometry disappearing from
            /// the edges of the view.
            /// </summary>
            static void CalculatePaddedFrustum(Camera camera, float paddingDeg, Plane[] planes)
            {
                if (camera.stereoEnabled)
                    paddingDeg += 15f;

                if (paddingDeg < 0.01f || camera.orthographic)
                {
                    GeometryUtility.CalculateFrustumPlanes(camera, planes);
                    return;
                }

                float fov = Mathf.Clamp(camera.fieldOfView + paddingDeg, 1f, 179f);
                float aspect = Mathf.Max(0.01f, camera.aspect) * (1f + paddingDeg / 90f);
                var proj = Matrix4x4.Perspective(fov, aspect,
                    camera.nearClipPlane, Mathf.Max(camera.nearClipPlane + 1f, camera.farClipPlane));
                GeometryUtility.CalculateFrustumPlanes(proj * camera.worldToCameraMatrix, planes);
            }
        }

        /// <summary>Reusable scratch so per-frame traversal does not allocate.</summary>
        public sealed class Workspace
        {
            internal QueueEntry[] heap = new QueueEntry[1024];
            internal int heapCount;
            internal readonly Plane[] planeScratch = new Plane[6];
            internal readonly float4[] cullPlanes = new float4[6];

            /// <summary>
            /// Set when the last traversal ran out of budget before it ran out of detail worth
            /// adding. Because refinement is globally best-first this is the normal end state for a
            /// scene bigger than the budget, not a failure.
            /// </summary>
            public bool budgetExhausted;

            /// <summary>
            /// On-screen size (pixels) of the largest node left unrefined when the budget ran out.
            /// Purely diagnostic: it tells you how coarse the survivors are. Measured in the same
            /// scaled domain the traversal orders by (featureSize × lodScale × foveation).
            /// </summary>
            public float exhaustedPixelScale;

            /// <summary>Selection composition from the last traversal, for diagnostics.</summary>
            public int emittedLeaves;
            public int emittedMerged;
            public int droppedMerged;
        }

        /// <summary>
        /// Closest a node is ever treated as being. Only reached by nodes the camera sits inside,
        /// which are exactly the ones that must refine first.
        /// </summary>
        const float kMinNodeDistance = 0.05f;

        /// <summary>
        /// On-screen size of a node in the scaled pixel domain the traversal orders and thresholds by.
        /// Runs once per visited node, so everything that only depends on the camera is precomputed in
        /// <see cref="ViewContext"/>. <paramref name="worldFeatureSize"/> is the node diameter already
        /// brought into world units by <see cref="PageContext.featureScale"/>.
        /// </summary>
        public static float ComputePixelScale(
            in ViewContext view,
            float3 centerWorld,
            float worldFeatureSize,
            float lodScale,
            float outsideFoveate,
            float behindFoveate)
        {
            float3 toCenter = centerWorld - view.cameraWorld;
            float dist = math.length(toCenter);

            // Measured from the near face of the node rather than its centre. A node's own extent is
            // most of its distance once you are close to it, so the centre measure reports a
            // room-sized subtree with its front edge in your face as being half a room away and
            // leaves it unrefined — the reason close-ups stalled at coarse detail. This is also how
            // CoversTooMuchScreen measures, so refinement order and the stand-in cull now agree.
            float radius = worldFeatureSize * 0.5f;
            float near = math.max(dist - radius, kMinNodeDistance);
            float angularSize = worldFeatureSize * math.max(0.01f, lodScale) / near;

            // Foveation only means anything for a node the camera is outside of: once you are inside
            // one, part of it is in front of you wherever its centre happens to lie.
            if (dist > radius)
            {
                // Cosine of the angle off the view axis. Unity view space looks down -Z, so a node's
                // view-space direction is this same quantity: comparing cosines against the half-FOV
                // gives the identical off-centre test as measuring the angle, without the arc-cosine.
                float facing = math.dot(view.cameraForward, toCenter) / dist;
                if (facing < 0f)
                    angularSize *= math.max(0.05f, behindFoveate);
                else if (facing < view.cosHalfFovY)
                    angularSize *= math.max(0.05f, outsideFoveate);
            }

            return angularSize * view.pixelScaleFactor;
        }

        /// <summary>
        /// World units per local unit for a page transform. The largest axis, so an anisotropic scale
        /// refines against the axis that grows splats the most on screen.
        /// </summary>
        static float ComputeFeatureScale(in float4x4 localToWorld)
        {
            float sx = math.length(localToWorld.c0.xyz);
            float sy = math.length(localToWorld.c1.xyz);
            float sz = math.length(localToWorld.c2.xyz);
            return math.max(math.max(sx, sy), math.max(sz, 1e-6f));
        }

        static bool IsVisible(in ViewContext view, float3 centerWorld, float worldFeatureSize)
        {
            float4[] planes = view.cullPlanes;
            if (!view.frustumCull || planes == null)
                return true;

            // Test the full diameter rather than the radius: popping at the screen edge is worse
            // than carrying a few extra splats.
            float radius = math.max(worldFeatureSize, 1e-3f);
            for (int i = 0; i < planes.Length; i++)
            {
                float4 p = planes[i];
                if (math.dot(p.xyz, centerWorld) + p.w < -radius)
                    return false;
            }
            return true;
        }

        public static int Traverse(
            PageContext[] pages,
            int pageCount,
            in ViewContext view,
            int maxSplats,
            float pixelScaleLimit,
            LodActiveSplatRef[] output,
            Workspace workspace)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0 || workspace == null)
                return 0;

            maxSplats = Mathf.Min(maxSplats, output.Length);
            if (maxSplats <= 0)
                return 0;

            workspace.heapCount = 0;
            workspace.budgetExhausted = false;
            workspace.exhaustedPixelScale = 0f;
            workspace.emittedLeaves = 0;
            workspace.emittedMerged = 0;
            workspace.droppedMerged = 0;
            int outCount = 0;

            for (int p = 0; p < pageCount; p++)
            {
                ref PageContext ctx = ref pages[p];
                if (ctx.nodes == null || ctx.nodes.Length == 0)
                    continue;

                ctx.featureScale = ComputeFeatureScale(ctx.localToWorld);

                float3 centerWorld = math.mul(ctx.localToWorld, new float4(ctx.nodes[0].center, 1f)).xyz;
                float feature = ctx.nodes[0].featureSize * ctx.featureScale;
                // Visibility uses the true extent; lodScale is a quality knob and must not shrink bounds.
                if (!IsVisible(view, centerWorld, feature))
                    continue;

                float ps = ComputePixelScale(view, centerWorld, feature, ctx.lodScale,
                    ctx.outsideFoveate, ctx.behindFoveate);
                HeapPush(workspace, new QueueEntry { pixelScale = ps, pageIndex = p, nodeIndex = 0 });
            }

            while (workspace.heapCount > 0)
            {
                // Every remaining node would be emitted into a full output array, so stop walking
                // the tree for them. Refinement is largest-first, so the top of the heap is the
                // coarsest thing the budget could not pay for.
                if (outCount >= maxSplats)
                {
                    if (!workspace.budgetExhausted)
                    {
                        workspace.budgetExhausted = true;
                        workspace.exhaustedPixelScale = workspace.heap[0].pixelScale;
                    }
                    break;
                }

                QueueEntry top = HeapPop(workspace);

                ref PageContext page = ref pages[top.pageIndex];
                if (page.nodes == null || top.nodeIndex >= page.nodes.Length)
                    continue;

                int childCount = page.nodes[top.nodeIndex].childCount;
                if (childCount == 0)
                {
                    // Coarse prefix trees bottom out in truncated merged nodes that look like
                    // leaves, so even this path has to reject blobs the camera is inside of.
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    continue;
                }

                // Nodes come out largest-first, so once the top is under the detail floor every
                // remaining node is too: keep them all as coarse merged splats.
                if (pixelScaleLimit > 0f && top.pixelScale < pixelScaleLimit)
                {
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    break;
                }

                // Refining swaps this node for its children; everything still queued also has to fit.
                if (outCount + workspace.heapCount + childCount > maxSplats)
                {
                    if (!workspace.budgetExhausted)
                    {
                        workspace.budgetExhausted = true;
                        workspace.exhaustedPixelScale = top.pixelScale;
                    }
                    EmitUnlessEngulfing(ref page, top.nodeIndex, view, output, ref outCount, maxSplats, workspace);
                    continue;
                }

                ExpandChildren(ref page, top, view, pixelScaleLimit, output, ref outCount, maxSplats,
                    workspace);
            }

            for (int i = 0; i < workspace.heapCount && outCount < maxSplats; i++)
            {
                ref readonly QueueEntry entry = ref workspace.heap[i];
                ref PageContext entryPage = ref pages[entry.pageIndex];
                if (entryPage.nodes == null || entry.nodeIndex >= entryPage.nodes.Length)
                    continue;
                EmitUnlessEngulfing(ref entryPage, entry.nodeIndex, view, output, ref outCount, maxSplats, workspace);
            }
            workspace.heapCount = 0;

            if (outCount == 0)
                outCount = FillLeafFallback(pages, pageCount, maxSplats, output);

            return outCount;
        }

        static void ExpandChildren(
            ref PageContext page,
            in QueueEntry parent,
            in ViewContext view,
            float pixelScaleLimit,
            LodActiveSplatRef[] output,
            ref int outCount,
            int maxSplats,
            Workspace workspace)
        {
            LodTreeNode node = page.nodes[parent.nodeIndex];
            int childCount = node.childCount;
            int tableStart = page.childTableStart != null && parent.nodeIndex < page.childTableStart.Length
                ? page.childTableStart[parent.nodeIndex]
                : -1;

            for (int c = 0; c < childCount; c++)
            {
                int childIdx;
                if (tableStart >= 0 && page.childTable != null && tableStart + c < page.childTable.Length)
                    childIdx = page.childTable[tableStart + c];
                else
                    childIdx = (int)node.childStart + c;

                if (childIdx <= 0 || childIdx >= page.nodes.Length)
                    continue;

                LodTreeNode child = page.nodes[childIdx];
                float3 childWorld = math.mul(page.localToWorld, new float4(child.center, 1f)).xyz;
                float childFeature = child.featureSize * page.featureScale;
                if (!IsVisible(view, childWorld, childFeature))
                    continue;

                float childPs = ComputePixelScale(view, childWorld, childFeature, page.lodScale,
                    page.outsideFoveate, page.behindFoveate);

                // A child under the detail floor can never be refined further, so emit it now
                // instead of paying a heap insert to have it popped straight back out. In a settled
                // view most children take this path, which is where the traversal spent its time.
                if (pixelScaleLimit > 0f && childPs < pixelScaleLimit)
                {
                    EmitUnlessEngulfing(ref page, (uint)childIdx, view, output, ref outCount,
                        maxSplats, workspace);
                    continue;
                }

                HeapPush(workspace, new QueueEntry
                {
                    pixelScale = childPs,
                    pageIndex = parent.pageIndex,
                    nodeIndex = (uint)childIdx
                });
            }
        }

        /// <summary>
        /// Emits a node, dropping merged stand-ins that cannot usefully represent their subtree: any
        /// blob smeared across a large part of the view, and all of them when
        /// <see cref="ViewContext.skipMergedSplats"/> is set. Leaves are genuine scene content and
        /// always render.
        /// </summary>
        static void EmitUnlessEngulfing(
            ref PageContext page,
            uint nodeIndex,
            in ViewContext view,
            LodActiveSplatRef[] output,
            ref int outCount,
            int maxSplats,
            Workspace workspace)
        {
            LodTreeNode node = page.nodes[nodeIndex];
            if (node.IsMergedSplat)
            {
                if (view.skipMergedSplats)
                {
                    workspace.droppedMerged++;
                    return;
                }

                float3 world = math.mul(page.localToWorld, new float4(node.center, 1f)).xyz;
                if (CoversTooMuchScreen(view, world, node.featureSize * page.featureScale))
                {
                    workspace.droppedMerged++;
                    return;
                }
                workspace.emittedMerged++;
            }
            else
            {
                workspace.emittedLeaves++;
            }
            Emit(output, ref outCount, maxSplats, page.pageSlot, nodeIndex);
        }

        /// <summary>
        /// True when a stand-in would cover too much of the screen to be worth drawing. Refinement is
        /// best-first, so a blob this big only survives when the page has no finer data resident or the
        /// budget ran out — either way it is the average of a subtree the camera is nearly inside, so it
        /// hides the real geometry behind a flat wash. It is also ruinously expensive: blend cost grows
        /// with area, while the budget it spends is counted in splats, so one of these displaces
        /// thousands of refined splats it cannot come close to representing. Leaving a hole reads better
        /// and lets the streamer bring in the detail that belongs there.
        /// </summary>
        static bool CoversTooMuchScreen(in ViewContext view, float3 centerWorld, float worldFeatureSize)
        {
            if (view.maxStandInPixels <= 0f)
                return false;

            // Measured from the near side of the blob, so containing the camera falls out as the
            // limit case rather than needing its own test.
            float radius = worldFeatureSize * 0.5f;
            float dist = math.length(centerWorld - view.cameraWorld) - radius;
            if (dist <= 0f)
                return true;

            // The compute shader applies _SplatScale to the covariance before projection. Include
            // that same linear scale here so "Max Stand-in Size" means final rendered pixels.
            float pixels = worldFeatureSize * view.splatScale * view.pixelsPerUnitAtUnitDistance / dist;
            return pixels > view.maxStandInPixels;
        }

        static void Emit(LodActiveSplatRef[] output, ref int outCount, int maxSplats, int pageSlot, uint splatIndex)
        {
            if (outCount >= maxSplats)
                return;
            output[outCount++] = new LodActiveSplatRef
            {
                pageSlot = (uint)pageSlot,
                splatIndex = splatIndex
            };
        }

        static void HeapPush(Workspace ws, in QueueEntry entry)
        {
            if (ws.heapCount == ws.heap.Length)
                Array.Resize(ref ws.heap, ws.heap.Length * 2);

            int i = ws.heapCount++;
            ws.heap[i] = entry;
            while (i > 0)
            {
                int parent = (i - 1) >> 1;
                if (ws.heap[parent].pixelScale >= ws.heap[i].pixelScale)
                    break;
                (ws.heap[parent], ws.heap[i]) = (ws.heap[i], ws.heap[parent]);
                i = parent;
            }
        }

        static QueueEntry HeapPop(Workspace ws)
        {
            QueueEntry top = ws.heap[0];
            int count = --ws.heapCount;
            if (count > 0)
            {
                ws.heap[0] = ws.heap[count];
                int i = 0;
                while (true)
                {
                    int left = 2 * i + 1;
                    int right = left + 1;
                    int largest = i;
                    if (left < count && ws.heap[left].pixelScale > ws.heap[largest].pixelScale)
                        largest = left;
                    if (right < count && ws.heap[right].pixelScale > ws.heap[largest].pixelScale)
                        largest = right;
                    if (largest == i)
                        break;
                    (ws.heap[largest], ws.heap[i]) = (ws.heap[i], ws.heap[largest]);
                    i = largest;
                }
            }
            return top;
        }

        public static int FillLeafFallback(
            PageContext[] pages,
            int pageCount,
            int maxSplats,
            LodActiveSplatRef[] output)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0)
                return 0;

            int limit = Mathf.Min(maxSplats, output.Length);
            pageCount = Mathf.Min(pageCount, pages.Length);
            if (limit <= 0 || pageCount <= 0)
                return 0;

            int perPage = Mathf.Max(1, limit / pageCount);
            int outCount = 0;
            for (int p = 0; p < pageCount && outCount < limit; p++)
            {
                ref readonly PageContext ctx = ref pages[p];
                if (ctx.nodes == null || ctx.nodes.Length == 0)
                    continue;
                int added = 0;
                for (uint i = 0; i < ctx.nodes.Length && added < perPage && outCount < limit; i++)
                {
                    if (!ctx.nodes[i].IsLeaf)
                        continue;
                    output[outCount++] = new LodActiveSplatRef
                    {
                        pageSlot = (uint)ctx.pageSlot,
                        splatIndex = i
                    };
                    added++;
                }
            }
            return outCount;
        }

        /// <summary>
        /// Select splats 0..N-1 from each loaded page when LoD traversal finds nothing visible.
        /// </summary>
        public static int FillSequentialFallback(
            PageContext[] pages,
            int pageCount,
            int maxSplats,
            LodActiveSplatRef[] output)
        {
            if (pages == null || pageCount <= 0 || output == null || maxSplats <= 0)
                return 0;

            int outCount = 0;
            for (int p = 0; p < pageCount && outCount < maxSplats; p++)
            {
                ref readonly PageContext ctx = ref pages[p];
                int splatCount = ctx.nodes?.Length ?? 0;
                if (splatCount <= 0)
                    continue;
                for (uint i = 0; i < splatCount && outCount < maxSplats; i++)
                {
                    output[outCount++] = new LodActiveSplatRef
                    {
                        pageSlot = (uint)ctx.pageSlot,
                        splatIndex = i
                    };
                }
            }
            return outCount;
        }
    }
}
