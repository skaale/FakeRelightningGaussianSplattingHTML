// SPDX-License-Identifier: MIT

using System;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Mathematics;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Packed LoD tree node (Spark-style). Root is always index 0 and nodes are stored in
    /// depth-first pre-order, so childStart points at the first child only — the remaining
    /// siblings sit after that child's subtree. Use <see cref="LodTreeRuntime"/> to get an
    /// explicit child table plus subtree extents before traversing.
    ///
    /// featureSize is the spatial diameter the node represents: the Gaussian size for a leaf,
    /// the diameter of the whole subtree for an internal node.
    /// </summary>
    [Serializable]
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential, Pack = 4)]
    public struct LodTreeNode
    {
        public float3 center;
        public float featureSize;
        public ushort childCount;
        /// <summary>Runtime-only flags; serialized as zero. See <see cref="kFlagMerged"/>.</summary>
        public ushort flags;
        public uint childStart;

        public const int kByteSize = 24;

        /// <summary>
        /// Set by <see cref="LodTreeRuntime"/> on nodes that stand in for a subtree, so a merged
        /// splat stays recognizable even after a coarse prefix cut drops its children and zeroes
        /// childCount.
        /// </summary>
        public const ushort kFlagMerged = 1;

        public bool IsLeaf => childCount == 0;
        public bool IsMergedSplat => childCount != 0 || (flags & kFlagMerged) != 0;

        public static byte[] ToBytes(LodTreeNode[] nodes)
        {
            if (nodes == null || nodes.Length == 0)
                return Array.Empty<byte>();
            var bytes = new byte[nodes.Length * kByteSize];
            unsafe
            {
                fixed (byte* dst = bytes)
                {
                    for (int i = 0; i < nodes.Length; i++)
                        UnsafeUtility.CopyStructureToPtr(ref nodes[i], dst + i * kByteSize);
                }
            }
            return bytes;
        }

        public static LodTreeNode[] FromBytes(byte[] bytes, int nodeCount)
        {
            if (bytes == null || nodeCount <= 0 || bytes.Length < nodeCount * kByteSize)
                return Array.Empty<LodTreeNode>();
            var nodes = new LodTreeNode[nodeCount];
            unsafe
            {
                fixed (byte* src = bytes)
                {
                    for (int i = 0; i < nodeCount; i++)
                        UnsafeUtility.CopyPtrToStructure(src + i * kByteSize, out nodes[i]);
                }
            }
            return nodes;
        }

        /// <summary>
        /// Reads the first <paramref name="nodeCount"/> nodes straight out of asset memory. Unlike
        /// TextAsset.bytes this makes no full-size managed copy, which matters because a page's tree
        /// runs to tens of megabytes while the streamer usually wants only a short coarse prefix.
        /// </summary>
        public static LodTreeNode[] FromData(NativeArray<byte> data, int nodeCount)
        {
            if (!data.IsCreated || nodeCount <= 0)
                return Array.Empty<LodTreeNode>();
            nodeCount = math.min(nodeCount, data.Length / kByteSize);
            if (nodeCount <= 0)
                return Array.Empty<LodTreeNode>();

            var nodes = new LodTreeNode[nodeCount];
            unsafe
            {
                void* src = data.GetUnsafeReadOnlyPtr();
                fixed (LodTreeNode* dst = nodes)
                    UnsafeUtility.MemCpy(dst, src, (long)nodeCount * kByteSize);
            }
            return nodes;
        }
    }
}
