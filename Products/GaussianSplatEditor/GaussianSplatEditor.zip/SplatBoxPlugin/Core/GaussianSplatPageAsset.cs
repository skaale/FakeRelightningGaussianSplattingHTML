// SPDX-License-Identifier: MIT

using System;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// One spatial page of a paged splat scene: splat payload plus a pre-built LoD tree.
    /// </summary>
    [CreateAssetMenu(fileName = "SplatPage", menuName = "Gaussian Splatting/Splat Page Asset")]
    public class GaussianSplatPageAsset : ScriptableObject
    {
        /// <summary>
        /// v2 stores LoD nodes in level order: siblings are contiguous and any prefix of the array
        /// is a complete coarse LoD level. v3 also preserves that exact order in the splat payload;
        /// older exporters Morton-sorted the payload after building the tree, breaking node indices.
        /// </summary>
        public const int kFormatVersion = 3;

        [SerializeField] int m_FormatVersion = kFormatVersion;
        [SerializeField] int m_PageId;
        [SerializeField] Vector3Int m_GridCoord;
        [SerializeField] Vector3 m_BoundsMin;
        [SerializeField] Vector3 m_BoundsMax;
        [SerializeField] GaussianSplatAsset m_SplatData;
        [SerializeField] TextAsset m_LodTreeData;
        [SerializeField] int m_LodNodeCount;
        [SerializeField] int m_LeafCount;

        public int formatVersion => m_FormatVersion;

        /// <summary>True when siblings are contiguous and coarse LoD levels can be read as a prefix.</summary>
        public bool hasLevelOrderLodTree => m_FormatVersion >= 2;

        /// <summary>True when tree node N addresses splat payload N.</summary>
        public bool hasMatchingLodSplatOrder => m_FormatVersion >= 3;

        public int pageId => m_PageId;
        public Vector3Int gridCoord => m_GridCoord;
        public Vector3 boundsMin => m_BoundsMin;
        public Vector3 boundsMax => m_BoundsMax;
        public Bounds bounds => new Bounds((m_BoundsMin + m_BoundsMax) * 0.5f, m_BoundsMax - m_BoundsMin);
        public GaussianSplatAsset splatData => m_SplatData;
        public TextAsset lodTreeData => m_LodTreeData;
        public int lodNodeCount => m_LodNodeCount;
        public int leafCount => m_LeafCount;
        public int splatCount => m_SplatData != null ? m_SplatData.splatCount : 0;

        public bool IsValid =>
            m_SplatData != null &&
            m_SplatData.splatCount > 0 &&
            m_LodTreeData != null &&
            m_LodNodeCount > 0;

        public void Initialize(
            int pageId,
            Vector3Int gridCoord,
            Vector3 boundsMin,
            Vector3 boundsMax,
            GaussianSplatAsset splatData,
            TextAsset lodTreeData,
            int lodNodeCount,
            int leafCount)
        {
            m_FormatVersion = kFormatVersion;
            m_PageId = pageId;
            m_GridCoord = gridCoord;
            m_BoundsMin = boundsMin;
            m_BoundsMax = boundsMax;
            m_SplatData = splatData;
            m_LodTreeData = lodTreeData;
            m_LodNodeCount = lodNodeCount;
            m_LeafCount = leafCount;
        }

        public LodTreeNode[] GetLodTreeNodes() => GetLodTreeNodes(int.MaxValue);

        /// <summary>
        /// Reads at most <paramref name="maxNodes"/> nodes from the front of the tree. Level-order
        /// pages (v2) store the coarsest LoD levels first, so a short prefix is a complete low-detail
        /// version of the page — reading the whole tree just to keep a few thousand nodes is what
        /// used to stall the editor whenever a page streamed in or out.
        /// </summary>
        public LodTreeNode[] GetLodTreeNodes(int maxNodes)
        {
            if (m_LodTreeData == null || m_LodNodeCount <= 0 || maxNodes <= 0)
                return Array.Empty<LodTreeNode>();
            int count = Mathf.Min(maxNodes, m_LodNodeCount);
            return LodTreeNode.FromData(m_LodTreeData.GetData<byte>(), count);
        }
    }
}
