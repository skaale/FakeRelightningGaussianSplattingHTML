// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Loads spatial pages for a GaussianSplatPagedScene.
    /// Every page keeps a coarse tier resident so the whole scene stays visible at distance; the
    /// nearest pages within the load radius borrow one of maxLoadedPages full-detail slots.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class SplatBoxLodStreamer : MonoBehaviour
    {
        [SerializeField] GaussianSplatPagedScene m_PagedScene;
        [SerializeField] Transform m_SplatTransform;
        [Tooltip("Distance from the camera to the nearest edge of a page at which it becomes a " +
                 "candidate for one of the full-detail slots.")]
        [SerializeField] float m_LoadRadius = 48f;
        [Tooltip("Distance to the nearest edge of a page beyond which it always drops back to its " +
                 "coarse tier. Keep it above Load Radius so pages do not thrash at the boundary.")]
        [SerializeField] float m_UnloadRadius = 58f;
        [SerializeField] int m_MaxLoadedPages = 16;
        [Tooltip("Splats kept resident for pages outside the detail radius so the whole scene stays visible.")]
        [SerializeField] int m_CoarsePageSplats = 8192;
        [SerializeField] float m_StreamUpdateInterval = 0.25f;
        [SerializeField] float m_StreamMoveThreshold = 0.5f;

        readonly Dictionary<int, SplatBoxPageGpuState> m_Loaded = new Dictionary<int, SplatBoxPageGpuState>();
        readonly List<int> m_LoadOrder = new List<int>();
        readonly List<SplatBoxPageGpuState> m_LoadedList = new List<SplatBoxPageGpuState>();
        // Coarse tiers are small and every page needs one sooner or later, so parked copies are
        // kept alive rather than rebuilt each time a page leaves the detail radius.
        readonly Dictionary<int, SplatBoxPageGpuState> m_ParkedCoarse = new Dictionary<int, SplatBoxPageGpuState>();
        readonly Stack<int> m_FreeDetailSlots = new Stack<int>();
        readonly HashSet<int> m_HeldDetailSlots = new HashSet<int>();
        readonly List<(GaussianSplatPageEntry entry, float dist, float rank)> m_RankedScratch = new List<(GaussianSplatPageEntry, float, float)>();
        readonly List<int> m_ToDowngradeScratch = new List<int>();
        readonly List<(int pageId, float rank)> m_DowngradeCandidateScratch = new List<(int, float)>();
        readonly HashSet<int> m_DetailPageScratch = new HashSet<int>();

        int m_NextPageSlot;
        int m_DetailSlotCapacity;
        int m_DetailSlotLimit = int.MaxValue;
        bool m_AllowFullSceneResidency = true;
        float m_LastStreamTime = -999f;
        Vector3 m_LastStreamFocus;
        Vector3 m_LastStreamViewDir = Vector3.forward;
        bool m_HasLastStreamFocus;
        int m_LastCoarseUploadFrame = -1;
        // Pure rotation used to be ignored (skip only checked focus position), so looking around
        // left detail slots aimed at the old view and the new direction showed coarse holes.
        const float kStreamRotateThresholdDeg = 8f;
        const float kStreamRotateInterval = 0.08f;

        /// <summary>
        /// Coarse GPU uploads (SetData + Texture.Apply) blow Unity's graphics ring buffer if many
        /// pages land in one UpdateStreaming call after a large build. One page per call is safe;
        /// the editor warmup / tick loops continue until every page has a stub.
        /// </summary>
        const int kMaxNewCoarseUploadsPerUpdate = 1;

        /// <summary>Above this total the Scene view falls back to runtime streaming instead of loading everything.</summary>
        public const int kEditorFullDetailSplatCap = 4_000_000;

        /// <summary>
        /// Minimum time a page keeps a detail slot before rank churn may evict it. The wanted set
        /// is view-dependent, so without this a small camera drift swaps borderline pages between
        /// full detail and coarse on every streaming update.
        /// </summary>
        const float kDetailSlotHoldSeconds = 2f;

        /// <summary>
        /// Within this distance of a page, load full leaf data immediately (edit + play) and give
        /// the page absolute priority for a detail slot.
        /// </summary>
        const float kHighestDetailDistance = 0.5f;

        /// <summary>
        /// Pages closer than this always take a full-detail slot. Standing inside a coarse prefix
        /// (merged stand-ins only) cannot refine past a few thousand blobs.
        /// </summary>
        const float kCloseDetailDistance = 2f;

        /// <summary>
        /// Coarse pages inside this radius force an immediate streaming update even if the normal
        /// interval has not elapsed.
        /// </summary>
        const float kUrgentCoarseDistance = 0.5f;

        public GaussianSplatPagedScene pagedScene => m_PagedScene;
        public IReadOnlyList<SplatBoxPageGpuState> loadedPages => m_LoadedList;
        public int coarsePageSplats => Mathf.Max(1, m_CoarsePageSplats);
        public float loadRadius => Mathf.Max(1f, m_LoadRadius);
        public event Action OnPagesChanged;

        /// <summary>True while at least one page still needs its coarse GPU upload.</summary>
        public bool hasPendingCoarseLoads
        {
            get
            {
                if (m_PagedScene?.pages == null)
                    return false;
                int expected = 0;
                for (int i = 0; i < m_PagedScene.pages.Length; i++)
                {
                    if (m_PagedScene.pages[i].pageAsset != null)
                        expected++;
                }
                return m_Loaded.Count < expected;
            }
        }

        /// <summary>Number of pages that can be held at full detail at once, after any atlas limit.</summary>
        public int detailSlotCapacity => m_DetailSlotCapacity;

        /// <summary>
        /// Detail slots this streamer wants, before the atlas gets a say. Independent of the current
        /// limit, so the renderer can use it as a stable input when sizing the atlas.
        /// </summary>
        public int requestedDetailSlots
        {
            get
            {
                int pageCount = m_PagedScene?.pageCount ?? 0;
                return pageCount > 0 ? Mathf.Clamp(m_MaxLoadedPages, 1, pageCount) : 0;
            }
        }

        /// <summary>
        /// Authoring convenience: while the scene is small enough, the Scene view would rather keep
        /// every page at full detail than stream, so nothing pops while you work. Whether the atlas
        /// can afford that is a separate question — see <see cref="loadsEveryPageAtFullDetail"/>.
        /// </summary>
        public bool wantsFullSceneResidency
        {
            get
            {
#if UNITY_EDITOR
                return !Application.isPlaying && CanEditorLoadAllPages(m_PagedScene);
#else
                return false;
#endif
            }
        }

        /// <summary>True when full-scene residency is both wanted and affordable.</summary>
        public bool loadsEveryPageAtFullDetail => m_AllowFullSceneResidency && wantsFullSceneResidency;

        public static bool CanEditorLoadAllPages(GaussianSplatPagedScene scene)
        {
            if (scene?.pages == null)
                return false;
            long total = 0;
            for (int i = 0; i < scene.pages.Length; i++)
                total += scene.pages[i].splatCount;
            return total <= kEditorFullDetailSplatCap;
        }

        public void Configure(GaussianSplatPagedScene scene, Transform splatTransform)
        {
            // Anything already loaded belongs to the previous scene, and its detail slots are about
            // to be handed out again, so it has to go before the slot pool is rebuilt.
            if (!ReferenceEquals(m_PagedScene, scene) && (m_Loaded.Count > 0 || m_ParkedCoarse.Count > 0))
                UnloadAll();

            m_PagedScene = scene;
            m_SplatTransform = splatTransform != null ? splatTransform : transform;
            if (scene != null)
            {
                m_LoadRadius = scene.loadRadius;
                m_UnloadRadius = scene.unloadRadius;
                m_MaxLoadedPages = scene.maxLoadedPages;
                m_CoarsePageSplats = scene.coarsePageSplats;
            }
            m_HasLastStreamFocus = false;
            ResetDetailSlots();
        }

        /// <summary>
        /// Tells the streamer what the atlas can actually accommodate, so it never asks for a slot
        /// or a residency mode the renderer has no memory for. Set by the renderer after it lays the
        /// atlas out.
        /// </summary>
        public void SetAtlasLimits(int detailSlotLimit, bool allowFullSceneResidency)
        {
            detailSlotLimit = Mathf.Max(0, detailSlotLimit);
            if (detailSlotLimit == m_DetailSlotLimit && allowFullSceneResidency == m_AllowFullSceneResidency)
                return;
            m_DetailSlotLimit = detailSlotLimit;
            m_AllowFullSceneResidency = allowFullSceneResidency;
            ResetDetailSlots();
        }

        void ResetDetailSlots()
        {
            m_DetailSlotCapacity = Mathf.Min(requestedDetailSlots, m_DetailSlotLimit);

            // Slots already held stay held; pages left holding one outside the new capacity are
            // downgraded by ReleaseDetailSlots on the next streaming update.
            m_HeldDetailSlots.Clear();
            foreach (var kv in m_Loaded)
            {
                if (kv.Value != null && kv.Value.detailSlot >= 0)
                    m_HeldDetailSlots.Add(kv.Value.detailSlot);
            }

            m_FreeDetailSlots.Clear();
            for (int i = m_DetailSlotCapacity - 1; i >= 0; i--)
            {
                if (!m_HeldDetailSlots.Contains(i))
                    m_FreeDetailSlots.Push(i);
            }
        }

        void OnDestroy()
        {
            UnloadAll();
        }

        public void UnloadAll()
        {
            foreach (var kv in m_Loaded)
                kv.Value.Dispose();
            m_Loaded.Clear();
            foreach (var kv in m_ParkedCoarse)
                kv.Value.Dispose();
            m_ParkedCoarse.Clear();
            m_LoadOrder.Clear();
            m_LoadedList.Clear();
            m_NextPageSlot = 0;
            m_HasLastStreamFocus = false;
            ResetDetailSlots();
            OnPagesChanged?.Invoke();
        }

        public void UpdateStreaming(Camera camera, Transform splatTransform, bool force = false)
        {
            if (m_PagedScene == null || m_PagedScene.pageCount == 0)
                return;
            if (m_DetailSlotCapacity <= 0)
                ResetDetailSlots();

            Transform xf = splatTransform != null ? splatTransform : m_SplatTransform;
            if (xf == null)
                xf = transform;

            Vector3 focus = camera != null
                ? GaussianSplatRenderSystem.GetStreamingFocusPosition(camera)
                : xf.position;
            Vector3 viewDir = camera != null ? camera.transform.forward : xf.forward;

            // Close-up: a coarse page under the nose has no leaf data to refine, so never wait
            // on the stream interval when one is that close (edit mode and play).
            if (!force && HasCoarsePageWithin(focus, xf, kUrgentCoarseDistance))
                force = true;

            if (!force && ShouldSkipStreamingUpdate(focus, viewDir))
                return;

            m_LastStreamFocus = focus;
            m_HasLastStreamFocus = true;
            m_LastStreamTime = Time.realtimeSinceStartup;
            m_LastStreamViewDir = viewDir;

            m_RankedScratch.Clear();
            var pages = m_PagedScene.pages;
            for (int i = 0; i < pages.Length; i++)
            {
                ref GaussianSplatPageEntry entry = ref pages[i];
                if (entry.pageAsset == null)
                    continue;
                float dist = DistanceToPage(focus, entry, xf);
                m_RankedScratch.Add((entry, dist, DetailRank(focus, viewDir, entry, xf, dist)));
            }
            m_RankedScratch.Sort((a, b) => a.rank.CompareTo(b.rank));

            bool changed = false;
            int newCoarseUploads = 0;
            bool alreadyUploadedThisFrame = m_LastCoarseUploadFrame == Time.frameCount;

            // Load coarse stubs nearest-first so the Main Camera's page is resident before far cells.
            for (int i = 0; i < m_RankedScratch.Count; i++)
            {
                var (entry, _, _) = m_RankedScratch[i];
                if (entry.pageAsset == null || m_Loaded.ContainsKey(entry.pageId))
                    continue;
                if (alreadyUploadedThisFrame || newCoarseUploads >= kMaxNewCoarseUploadsPerUpdate)
                    break;
                LoadCoarseStub(entry);
                newCoarseUploads++;
                m_LastCoarseUploadFrame = Time.frameCount;
                alreadyUploadedThisFrame = true;
                changed = true;
            }

            bool hasPendingCoarse = false;
            for (int i = 0; i < m_RankedScratch.Count; i++)
            {
                if (!m_Loaded.ContainsKey(m_RankedScratch[i].entry.pageId))
                {
                    hasPendingCoarse = true;
                    break;
                }
            }

            // Authoring wants the whole model visible, so load every page at full detail while the
            // scene is small enough to fit comfortably in the atlas. Every page keeps its own atlas
            // region in that mode, so no detail slots are handed out.
            if (loadsEveryPageAtFullDetail && !hasPendingCoarse)
            {
                for (int i = 0; i < m_RankedScratch.Count; i++)
                {
                    if (EnsureFullPage(m_RankedScratch[i].entry, useDetailSlot: false))
                        changed = true;
                }

                if (changed)
                    OnPagesChanged?.Invoke();
                return;
            }

            // Pick the pages that deserve full detail, then release slots, then hand them out.
            // Highest-detail range (< 0.5 m) is reserved first, then other close pages, then the
            // remaining slots fill by view rank inside the load radius.
            m_DetailPageScratch.Clear();
            for (int i = 0; i < m_RankedScratch.Count && m_DetailPageScratch.Count < m_DetailSlotCapacity; i++)
            {
                var (entry, dist, _) = m_RankedScratch[i];
                if (dist > kHighestDetailDistance)
                    continue;
                m_DetailPageScratch.Add(entry.pageId);
            }
            for (int i = 0; i < m_RankedScratch.Count && m_DetailPageScratch.Count < m_DetailSlotCapacity; i++)
            {
                var (entry, dist, _) = m_RankedScratch[i];
                if (dist > kCloseDetailDistance || m_DetailPageScratch.Contains(entry.pageId))
                    continue;
                m_DetailPageScratch.Add(entry.pageId);
            }
            for (int i = 0; i < m_RankedScratch.Count && m_DetailPageScratch.Count < m_DetailSlotCapacity; i++)
            {
                var (entry, dist, _) = m_RankedScratch[i];
                if (dist > m_LoadRadius || m_DetailPageScratch.Contains(entry.pageId))
                    continue;
                m_DetailPageScratch.Add(entry.pageId);
            }

            if (ReleaseDetailSlots(focus, viewDir, xf))
                changed = true;

            // Full-page uploads are heavy. Never mix them with a new coarse SetData in the same
            // frame (graphics ring buffer). Pages within 0.5 m still upgrade as soon as that page
            // already has a coarse stub — do not wait for every far page to finish streaming in.
            int pacedCap = Application.isPlaying ? 2 : 1;
            int nonUrgentUpgrades = 0;
            bool canUploadFull = newCoarseUploads == 0;
            for (int i = 0; i < m_RankedScratch.Count && canUploadFull; i++)
            {
                var (entry, dist, _) = m_RankedScratch[i];
                if (!m_DetailPageScratch.Contains(entry.pageId))
                    continue;
                if (!m_Loaded.ContainsKey(entry.pageId))
                    continue; // Coarse not resident yet; nearest-first loop will get it next.
                bool urgentClose = dist <= kHighestDetailDistance
                    || (Application.isPlaying && dist <= kCloseDetailDistance);
                // While far coarse pages are still pending, only spend bandwidth on contact range.
                if (hasPendingCoarse && dist > kHighestDetailDistance)
                    continue;
                if (!urgentClose && nonUrgentUpgrades >= pacedCap)
                    continue;
                if (EnsureFullPage(entry, useDetailSlot: true))
                {
                    changed = true;
                    if (!urgentClose)
                        nonUrgentUpgrades++;
                }
            }

            if (changed)
                OnPagesChanged?.Invoke();
        }

        bool HasCoarsePageWithin(Vector3 focus, Transform xf, float radius)
        {
            foreach (var kv in m_Loaded)
            {
                if (kv.Value == null || !kv.Value.isCoarseStub)
                    continue;
                var entry = m_PagedScene.FindPage(kv.Key);
                if (!entry.HasValue)
                    continue;
                if (DistanceToPage(focus, entry.Value, xf) <= radius)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Detail slots are scarce and the view frustum is where their quality is actually seen, so
        /// pages behind the camera rank as if they were farther away. Very close pages keep their
        /// plain distance, so turning around never faces a coarse wall.
        /// </summary>
        float DetailRank(Vector3 focus, Vector3 viewDir, in GaussianSplatPageEntry entry, Transform xf, float dist)
        {
            // Contact range always wins the slot race — close-ups need their full trees.
            if (dist <= kHighestDetailDistance)
                return dist * 0.001f;
            if (dist <= kCloseDetailDistance)
                return dist * 0.01f;

            if (dist <= m_LoadRadius * 0.3f)
                return dist;

            Vector3 localCenter = (entry.boundsMin + entry.boundsMax) * 0.5f;
            Vector3 worldCenter = xf != null ? xf.TransformPoint(localCenter) : localCenter;
            Vector3 toPage = worldCenter - focus;
            float len = toPage.magnitude;
            if (len < 1e-3f)
                return dist;

            float facing = Vector3.Dot(toPage / len, viewDir);
            return dist * (1f + Mathf.Max(0f, -facing) * 1.5f);
        }

        /// <summary>
        /// Drops full-detail pages back to their coarse tier: anything past the unload radius, plus
        /// however many of the remaining stragglers it takes to free a slot for every wanted page.
        /// Hysteresis keeps recently-left pages at detail only while there are slots to spare.
        /// </summary>
        bool ReleaseDetailSlots(Vector3 focus, Vector3 viewDir, Transform xf)
        {
            m_ToDowngradeScratch.Clear();
            m_DowngradeCandidateScratch.Clear();

            int wantedAlreadyFull = 0;
            foreach (var kv in m_Loaded)
            {
                if (kv.Value.isCoarseStub)
                    continue;

                var entryOpt = m_PagedScene.FindPage(kv.Key);
                if (!entryOpt.HasValue)
                {
                    m_ToDowngradeScratch.Add(kv.Key);
                    continue;
                }

                // Full pages too big for their permanent atlas region need a slot to be addressable.
                // A page without one, or holding a slot that the atlas has since dropped, cannot be
                // drawn at all, so send it back to its coarse tier.
                bool needsSlot = kv.Value.splatCount > coarsePageSplats;
                if (kv.Value.detailSlot >= m_DetailSlotCapacity ||
                    (needsSlot && kv.Value.detailSlot < 0))
                {
                    m_ToDowngradeScratch.Add(kv.Key);
                    continue;
                }

                bool isWanted = m_DetailPageScratch.Contains(kv.Key);
                if (isWanted)
                {
                    wantedAlreadyFull++;
                    continue;
                }

                float dist = DistanceToPage(focus, entryOpt.Value, xf);
                if (dist > m_UnloadRadius)
                    m_ToDowngradeScratch.Add(kv.Key);
                else
                    m_DowngradeCandidateScratch.Add((kv.Key, DetailRank(focus, viewDir, entryOpt.Value, xf, dist)));
            }

            int shortfall = (m_DetailPageScratch.Count - wantedAlreadyFull) - m_FreeDetailSlots.Count;
#if UNITY_EDITOR
            // Rank eviction swaps a visible full-detail page for a coarse stand-in so another page
            // can upgrade. In the Scene view that reads as the whole image thinning out whenever
            // the camera moves and streaming catches up. Keep every detail slot until the page
            // leaves the unload radius; new pages wait for a free slot instead.
            if (!Application.isPlaying)
                shortfall = 0;
#endif
            if (shortfall > 0 && m_DowngradeCandidateScratch.Count > 0)
            {
                m_DowngradeCandidateScratch.Sort((a, b) => b.rank.CompareTo(a.rank));
                float now = Time.realtimeSinceStartup;
                for (int i = 0; i < m_DowngradeCandidateScratch.Count && shortfall > 0; i++)
                {
                    int pageId = m_DowngradeCandidateScratch[i].pageId;
                    // Rank-based eviction is what lets borderline pages ping-pong between full
                    // detail and coarse as the view drifts, which shows up as the scene pulsing
                    // once a second. A page keeps its slot for a minimum time; whatever outranks
                    // it can wait that long, drawing its stand-ins meanwhile. Pages that left the
                    // unload radius or lost their slot to a layout change still drop immediately.
                    if (m_Loaded.TryGetValue(pageId, out var held) &&
                        now - held.detailAcquiredTime < kDetailSlotHoldSeconds)
                        continue;
                    m_ToDowngradeScratch.Add(pageId);
                    shortfall--;
                }
            }

            bool changed = false;
            for (int i = 0; i < m_ToDowngradeScratch.Count; i++)
            {
                int pageId = m_ToDowngradeScratch[i];
                if (!m_Loaded.ContainsKey(pageId))
                    continue;

                var entryOpt = m_PagedScene.FindPage(pageId);
                if (!entryOpt.HasValue)
                    RemovePage(pageId);
                else
                    ReplaceWithCoarseStub(entryOpt.Value);
                changed = true;
            }
            return changed;
        }

        bool ShouldSkipStreamingUpdate(Vector3 focus, Vector3 viewDir)
        {
            if (!m_HasLastStreamFocus)
                return false;

            float moved = Vector3.Distance(focus, m_LastStreamFocus);
            float turnedDeg = Vector3.Angle(viewDir, m_LastStreamViewDir);
            float elapsed = Time.realtimeSinceStartup - m_LastStreamTime;

            // Rotation-only looks (Scene View orbit, VR look-around) must re-rank detail slots.
            // Position-only skip left the old view's pages loaded and the new facing direction empty.
            if (turnedDeg >= kStreamRotateThresholdDeg)
            {
                float rotInterval = Mathf.Min(m_StreamUpdateInterval, kStreamRotateInterval);
                return elapsed < rotInterval;
            }

            // In play/VR the headset translates continuously, so once it has moved meaningfully
            // use a shorter interval so pages underfoot upgrade before the user walks past them.
            float interval = m_StreamUpdateInterval;
            if (Application.isPlaying && moved >= m_StreamMoveThreshold * 0.25f)
                interval = Mathf.Min(interval, 0.1f);

            if (elapsed < interval)
                return true;

            return moved < m_StreamMoveThreshold;
        }

        /// <summary>
        /// Distance from a world-space focus to the nearest edge of a loaded page (0 inside it).
        /// Used by the renderer to boost LoD priority for pages the viewer is standing in or near.
        /// </summary>
        public float DistanceToLoadedPage(Vector3 worldFocus, SplatBoxPageGpuState page, Transform splatTransform)
        {
            if (page == null || m_PagedScene == null)
                return float.MaxValue;
            var entry = m_PagedScene.FindPage(page.pageId);
            if (!entry.HasValue)
                return float.MaxValue;
            return DistanceToPage(worldFocus, entry.Value, splatTransform);
        }

        /// <summary>
        /// Distance from the focus point to the nearest part of a page, zero while standing inside it.
        /// Pages are grid cells many metres across, so their centres say little about how close their
        /// content is: measured centre to centre, the page under your feet reports the distance to its
        /// far side and loses its detail slot to smaller neighbours you are only looking past.
        /// </summary>
        static float DistanceToPage(Vector3 worldFocus, GaussianSplatPageEntry entry, Transform splatTransform)
        {
            if (splatTransform == null)
                return DistanceToBounds(worldFocus, entry.boundsMin, entry.boundsMax);

            // Bounds are axis aligned in the splat's own space, so the test runs there and the
            // resulting distance is converted back. Exact for the usual uniform scale; a non-uniform
            // one has no single conversion, and the mean keeps it between the per-axis extremes.
            Vector3 local = splatTransform.InverseTransformPoint(worldFocus);
            Vector3 scale = splatTransform.lossyScale;
            float unitsPerLocal = (Mathf.Abs(scale.x) + Mathf.Abs(scale.y) + Mathf.Abs(scale.z)) / 3f;
            return DistanceToBounds(local, entry.boundsMin, entry.boundsMax) * unitsPerLocal;
        }

        static float DistanceToBounds(Vector3 p, Vector3 min, Vector3 max)
        {
            float dx = Mathf.Max(Mathf.Max(min.x - p.x, 0f), p.x - max.x);
            float dy = Mathf.Max(Mathf.Max(min.y - p.y, 0f), p.y - max.y);
            float dz = Mathf.Max(Mathf.Max(min.z - p.z, 0f), p.z - max.z);
            return Mathf.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        void LoadCoarseStub(GaussianSplatPageEntry entry)
        {
            var state = TakeParkedCoarse(entry.pageId);
            if (state == null)
            {
                state = SplatBoxPageGpuState.UploadCoarseLevel(entry.pageAsset, m_NextPageSlot, coarsePageSplats);
                if (state == null)
                    return;
                m_NextPageSlot++;
            }

            m_Loaded[entry.pageId] = state;
            m_LoadedList.Add(state);
            m_LoadOrder.Add(entry.pageId);
        }

        /// <summary>
        /// Takes a page's coarse tier out of the parked set. Coarse tiers are cheap to keep and
        /// expensive to rebuild, so they survive the round trip through full detail.
        /// </summary>
        SplatBoxPageGpuState TakeParkedCoarse(int pageId)
        {
            if (!m_ParkedCoarse.TryGetValue(pageId, out var state))
                return null;
            m_ParkedCoarse.Remove(pageId);
            if (state == null || !state.IsReady)
            {
                state?.Dispose();
                return null;
            }
            return state;
        }

        void ParkCoarse(int pageId, SplatBoxPageGpuState coarse)
        {
            if (coarse == null)
                return;
            if (m_ParkedCoarse.TryGetValue(pageId, out var previous) && !ReferenceEquals(previous, coarse))
                previous?.Dispose();
            m_ParkedCoarse[pageId] = coarse;
        }

        bool EnsureFullPage(GaussianSplatPageEntry entry, bool useDetailSlot)
        {
            if (m_Loaded.TryGetValue(entry.pageId, out var existing) && !existing.isCoarseStub)
                return false;

            int detailSlot = -1;
            if (useDetailSlot)
            {
                if (m_FreeDetailSlots.Count == 0)
                    return false; // No atlas room right now; the page stays coarse until one frees up.
                detailSlot = m_FreeDetailSlots.Pop();
            }

            int slot = existing?.pageSlot ?? m_NextPageSlot++;
            var state = SplatBoxPageGpuState.Upload(entry.pageAsset, slot);
            if (state == null)
            {
                if (detailSlot >= 0)
                    m_FreeDetailSlots.Push(detailSlot);
                return false;
            }
            state.detailSlot = detailSlot;
            state.detailAcquiredTime = Time.realtimeSinceStartup;

            int listIndex = existing != null ? m_LoadedList.IndexOf(existing) : -1;
            ParkCoarse(entry.pageId, existing);

            m_Loaded[entry.pageId] = state;
            // Replace in place so page ordering — and therefore every other page's atlas address —
            // stays put.
            if (listIndex >= 0)
            {
                m_LoadedList[listIndex] = state;
            }
            else
            {
                m_LoadedList.Add(state);
                m_LoadOrder.Add(entry.pageId);
            }
            return true;
        }

        void ReplaceWithCoarseStub(GaussianSplatPageEntry entry)
        {
            if (!m_Loaded.TryGetValue(entry.pageId, out var existing) || existing.isCoarseStub)
                return;

            int slot = existing.pageSlot;
            int listIndex = m_LoadedList.IndexOf(existing);
            if (existing.detailSlot >= 0)
                m_FreeDetailSlots.Push(existing.detailSlot);
            existing.Dispose();

            var state = TakeParkedCoarse(entry.pageId)
                        ?? SplatBoxPageGpuState.UploadCoarseLevel(entry.pageAsset, slot, coarsePageSplats);
            if (state == null)
            {
                if (listIndex >= 0)
                    m_LoadedList.RemoveAt(listIndex);
                m_Loaded.Remove(entry.pageId);
                m_LoadOrder.Remove(entry.pageId);
                return;
            }

            state.pageSlot = slot;
            m_Loaded[entry.pageId] = state;
            if (listIndex >= 0)
                m_LoadedList[listIndex] = state;
            else
                m_LoadedList.Add(state);
        }

        void RemovePage(int pageId)
        {
            if (!m_Loaded.TryGetValue(pageId, out var state))
                return;
            if (state.detailSlot >= 0)
                m_FreeDetailSlots.Push(state.detailSlot);
            state.Dispose();
            m_Loaded.Remove(pageId);
            m_LoadedList.Remove(state);
            m_LoadOrder.Remove(pageId);
        }

        /// <summary>
        /// Marks every page as needing a fresh copy into the atlas. Parked coarse tiers are included:
        /// they still believe their data is resident, which stops being true once the atlas is
        /// reallocated underneath them.
        /// </summary>
        public void InvalidateAtlasResidency()
        {
            for (int i = 0; i < m_LoadedList.Count; i++)
            {
                if (m_LoadedList[i] != null)
                    m_LoadedList[i].uploadedAtlasOffset = -1;
            }
            foreach (var kv in m_ParkedCoarse)
            {
                if (kv.Value != null)
                    kv.Value.uploadedAtlasOffset = -1;
            }
        }

        public bool TryGetPageState(int pageId, out SplatBoxPageGpuState state) =>
            m_Loaded.TryGetValue(pageId, out state);

        public SplatBoxPageGpuState GetPageBySlot(int pageSlot)
        {
            for (int i = 0; i < m_LoadedList.Count; i++)
            {
                if (m_LoadedList[i].pageSlot == pageSlot)
                    return m_LoadedList[i];
            }
            return null;
        }
    }
}
