// SPDX-License-Identifier: MIT

using System;
using Unity.Mathematics;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Reference to one splat selected by LoD traversal. pageSlot indexes the loaded-page
    /// table on GPU; splatIndex is the index within that page's splat array.
    /// </summary>
    [Serializable]
    public struct LodActiveSplatRef
    {
        public uint pageSlot;
        public uint splatIndex;

        public static uint Pack(uint pageSlot, uint splatIndex) => (pageSlot << 20) | (splatIndex & 0xFFFFF);
        public static void Unpack(uint packed, out uint pageSlot, out uint splatIndex)
        {
            pageSlot = packed >> 20;
            splatIndex = packed & 0xFFFFF;
        }
    }

    /// <summary>Per loaded page metadata uploaded for gather + traversal.</summary>
    public struct LodPageGpuMeta
    {
        public float4x4 objectToView;
        public float4 boundsMin;
        public float4 boundsMax;
        public uint atlasOffset;
        public uint splatCount;
        public uint lodNodeCount;
        public uint pageSlot;
        public float lodScale;
        public float outsideFoveate;
        public float behindFoveate;
        public float padding0;
    }
}
