# SplatBox Plugin (Precompiled)

Precompiled DLL version of SplatBox - Gaussian Splat editing tools for Unity.

**Build Info:**
- Unity Version: 6000.3.4f1
- URP Support: NO - GaussianSplatURPFeature NOT included (rebuild with URP for full support)
- Build Date: 2026-02-11 10:38

## Installation

### Option 1: Unity Package Manager
1. Open Unity Package Manager (Window > Package Manager)
2. Click '+' and select 'Add package from disk...'
3. Navigate to this folder and select `package.json`

### Option 2: Manual Installation
1. Copy this entire folder to your Unity project's `Packages/` folder
2. Rename the folder to `com.gaussiansplatting.splatbox.plugin`

## Requirements

- **Unity 6** (6000.0+) - this plugin was compiled with Unity 6000.3.4f1
- Universal Render Pipeline (URP) required for splat rendering
- Required packages (auto-installed via dependencies):
  - com.unity.mathematics
  - com.unity.collections
  - com.unity.burst
  - com.unity.render-pipelines.universal

**IMPORTANT:** Use this plugin with the same major Unity version it was built with.
Mixing Unity versions may cause Burst/TypeCache compatibility errors.

## URP Setup

After installation:
1. Select your URP Renderer Asset (usually in Settings folder)
2. Click 'Add Renderer Feature'
3. Add 'Gaussian Splat URP Feature' for splat rendering
4. (Optional) Add 'Gaussian Tilt Shift Renderer Feature' for tilt-shift effects

## Contents

- `Plugins/` - Precompiled DLL files
  - `GaussianSplatting.SplatBox.Core.dll` - Core rendering and data structures
  - `GaussianSplatting.SplatBox.Runtime.dll` - Runtime components, brushes, and URP features
  - `Editor/GaussianSplatting.SplatBox.Editor.dll` - Editor tools and inspectors
- `Editor/Icons/` - Editor icon assets
- `Shaders/` - Shader and compute shader files (required for rendering)
- `Resources/` - Runtime-loadable assets (required for Windows standalone builds)

## Usage

After installation, the SplatBox tools will be available in the Unity Editor.
Look for 'SplatBox' in the menu bar and component menus.
