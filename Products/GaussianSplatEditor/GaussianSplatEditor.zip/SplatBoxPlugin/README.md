# SplatBox Plugin (Precompiled)

Precompiled DLL version of SplatBox - Gaussian Splat editing tools for Unity.

 
- Build Date: 2026-02-04 11:00

## Installation

### Option 1: Unity Package Manager
1. Open Unity Package Manager (Window > Package Manager)
2. Click '+' and select 'Add package from disk...'
3. Navigate to this folder and select `package.json`

### Option 2: Manual Installation
1. Copy this entire folder to your Unity project's `Packages/` folder
2. Rename the folder to `com.gaussiansplatting.splatbox.plugin`

## Requirements

- Unity 2021.3 or later
- Universal Render Pipeline (URP) required for splat rendering
- Required packages (auto-installed via dependencies):
  - com.unity.mathematics
  - com.unity.collections
  - com.unity.burst
  - com.unity.render-pipelines.universal

## URP Setup

After installation:
1. Select your URP Renderer Asset (usually in Settings folder)
2. Click 'Add Renderer Feature'
3. Add 'Gaussian Splat URP Feature' for splat rendering
4. (Optional) Add 'Gaussian Tilt Shift Renderer Feature' for tilt-shift effects

## Contents

- `Plugins/` - Precompiled DLL files
  - `GaussianSplatting.SplatBox.Core.dll` - Core rendering and data structures
  - `GaussianSplatting.SplatBox.Runtime.dll` - Runtime components, brushes, and URP features
  - `Editor/GaussianSplatting.SplatBox.Editor.dll` - Editor tools and inspectors
- `Shaders/` - Shader and compute shader files (required for rendering)

## Usage

After installation, the SplatBox tools will be available in the Unity Editor.
Look for 'SplatBox' in the menu bar and component menus.
