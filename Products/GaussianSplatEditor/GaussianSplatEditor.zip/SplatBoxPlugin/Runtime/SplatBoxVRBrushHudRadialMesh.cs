// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Procedural donut-wedge meshes for the VR radial tool HUD.
    /// </summary>
    static class SplatBoxVRBrushHudRadialMesh
    {
        public static Mesh CreateWedge(float innerRadius, float outerRadius, float startDeg, float endDeg, int arcSegments = 12)
        {
            innerRadius = Mathf.Max(0f, innerRadius);
            outerRadius = Mathf.Max(innerRadius + 0.001f, outerRadius);
            arcSegments = Mathf.Max(3, arcSegments);

            float start = startDeg * Mathf.Deg2Rad;
            float end = endDeg * Mathf.Deg2Rad;
            int vertCount = (arcSegments + 1) * 2;
            var verts = new Vector3[vertCount];
            var uvs = new Vector2[vertCount];
            var tris = new int[arcSegments * 6];

            for (int i = 0; i <= arcSegments; i++)
            {
                float t = i / (float)arcSegments;
                float angle = Mathf.Lerp(start, end, t);
                float cos = Mathf.Cos(angle);
                float sin = Mathf.Sin(angle);
                int innerIdx = i * 2;
                int outerIdx = i * 2 + 1;
                verts[innerIdx] = new Vector3(cos * innerRadius, sin * innerRadius, 0f);
                verts[outerIdx] = new Vector3(cos * outerRadius, sin * outerRadius, 0f);
                uvs[innerIdx] = new Vector2(t, 0f);
                uvs[outerIdx] = new Vector2(t, 1f);
            }

            int tri = 0;
            for (int i = 0; i < arcSegments; i++)
            {
                int i0 = i * 2;
                int i1 = i * 2 + 1;
                int i2 = i * 2 + 2;
                int i3 = i * 2 + 3;
                tris[tri++] = i0;
                tris[tri++] = i2;
                tris[tri++] = i1;
                tris[tri++] = i1;
                tris[tri++] = i2;
                tris[tri++] = i3;
            }

            var mesh = new Mesh { name = "RadialWedge" };
            mesh.vertices = verts;
            mesh.uv = uvs;
            mesh.triangles = tris;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        public static Mesh CreateRing(float innerRadius, float outerRadius, int segments = 48)
        {
            return CreateWedge(innerRadius, outerRadius, 0f, 360f, segments);
        }

        public static Mesh CreateDisc(float radius, int segments = 20)
        {
            radius = Mathf.Max(0.001f, radius);
            segments = Mathf.Max(8, segments);
            var verts = new Vector3[segments + 1];
            var tris = new int[segments * 3];
            verts[0] = Vector3.zero;
            for (int i = 0; i < segments; i++)
            {
                float angle = i / (float)segments * Mathf.PI * 2f;
                verts[i + 1] = new Vector3(Mathf.Cos(angle) * radius, Mathf.Sin(angle) * radius, 0f);
            }

            int tri = 0;
            for (int i = 0; i < segments; i++)
            {
                tris[tri++] = 0;
                tris[tri++] = i + 1;
                tris[tri++] = i == segments - 1 ? 1 : i + 2;
            }

            var mesh = new Mesh { name = "RadialDisc" };
            mesh.vertices = verts;
            mesh.triangles = tris;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        public static Vector2 WedgeLabelPosition(float innerRadius, float outerRadius, float startDeg, float endDeg)
        {
            float mid = (startDeg + endDeg) * 0.5f * Mathf.Deg2Rad;
            float radius = (innerRadius + outerRadius) * 0.5f;
            return new Vector2(Mathf.Cos(mid) * radius, Mathf.Sin(mid) * radius);
        }

        public static Material CreateHudMaterial(string name, Color color, bool additive = false)
        {
            var shader = Shader.Find("Sprites/Default")
                ?? Shader.Find("Unlit/Color")
                ?? Shader.Find("UI/Default")
                ?? Shader.Find("Universal Render Pipeline/Unlit");
            var mat = new Material(shader) { name = name };
            ApplyHudColor(mat, color);

            mat.SetInt("_ZWrite", 0);
            mat.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Always);
            if (mat.HasProperty("unity_GUIZTestMode"))
                mat.SetInt("unity_GUIZTestMode", (int)UnityEngine.Rendering.CompareFunction.Always);
            if (mat.HasProperty("_Cull"))
                mat.SetInt("_Cull", (int)UnityEngine.Rendering.CullMode.Off);

            if (shader.name.Contains("Universal Render Pipeline"))
            {
                mat.SetFloat("_Surface", 1f);
                mat.SetFloat("_Blend", additive ? 1f : 0f);
                mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
                mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            }

            if (additive)
            {
                mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.One);
            }
            else
            {
                mat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
                mat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            }

            mat.renderQueue = additive ? 3200 : 3000;
            return mat;
        }

        public static void ApplyHudColor(Material mat, Color color)
        {
            if (mat == null)
                return;
            if (mat.HasProperty("_BaseColor"))
                mat.SetColor("_BaseColor", color);
            if (mat.HasProperty("_Color"))
                mat.SetColor("_Color", color);
            mat.color = color;
        }
    }
}
