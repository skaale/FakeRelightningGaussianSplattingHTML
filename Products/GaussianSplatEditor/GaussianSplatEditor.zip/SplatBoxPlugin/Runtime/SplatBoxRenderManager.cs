using UnityEngine;
using UnityEngine.UI;
using System;
using System.Collections;
using System.Collections.Generic;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Scene-level manager that controls the resolution the Gaussian splats are rendered at.
    ///
    /// On Quest the per-eye render target is roughly 4K, and rasterizing every splat at that
    /// resolution is the dominant cost. This manager renders the splats into a smaller offscreen
    /// target (<see cref="renderScale"/> of the screen / per-eye size) and the composite pass
    /// bilinearly upscales the result back to full resolution. CalcViewData uses the same scaled size so
    /// splat sizing stays locked to the world (no skew / head-swim).
    ///
    /// Add one to your scene (e.g. on the same object as the camera rig) and tune <see cref="renderScale"/>.
    /// 1.0 = full resolution (no change); ~0.6-0.75 is usually a good quality/perf balance in VR.
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [AddComponentMenu("SplatBox/SplatBox Render Manager")]
    public class SplatBoxRenderManager : MonoBehaviour
    {
        [Tooltip("Resolution scale for the splat render target. 1 = full screen/eye resolution; lower " +
                 "values render the splats at a fraction of the resolution and bilinearly upscale " +
                 "(big VR performance win). 0.6-0.75 is a good starting point on Quest.")]
        [Range(0.1f, 1f)]
        public float renderScale = 0.7f;

        [Header("Splat Loader")]
        [Tooltip("Preload splat renderers into GPU memory when this manager starts.")]
        public bool preloadOnStart = true;

        [Tooltip("Automatically collect SplatBoxRenderer components in the scene if the explicit list is empty.")]
        public bool autoFindRenderers = true;

        [Tooltip("Include inactive renderers when auto-finding. Useful if you want to preload before revealing them.")]
        public bool includeInactiveRenderers = true;

        [Tooltip("Unload GPU buffers/materials when this manager is disabled or destroyed.")]
        public bool unloadOnDisable = false;

        [Tooltip("Optional explicit list. Leave empty to auto-find renderers in the scene.")]
        public SplatBoxRenderer[] preloadRenderers;

        [Header("Loading Screen")]
        [Tooltip("Show a loading bar while splats are uploaded to GPU memory.")]
        public bool showLoadingScreen = true;

        [Tooltip("Disable locomotion / movement behaviours until preloading finishes.")]
        public bool blockMovementWhileLoading = true;

        [Tooltip("Extra behaviours to disable during load (e.g. custom movement scripts).")]
        public Behaviour[] behavioursToDisableWhileLoading;

        [Tooltip("Also auto-disable XR Interaction Toolkit LocomotionProvider components in the scene.")]
        public bool autoFindLocomotionProviders = true;

        [Tooltip("Camera used to position a world-space loading panel. Falls back to Camera.main.")]
        public Camera loadingCamera;

        [Tooltip("World-space offset from the loading camera (meters).")]
        public Vector3 loadingPanelLocalOffset = new Vector3(0f, -0.05f, 1.4f);

        [Tooltip("Minimum time the loading screen stays visible so it does not flash on fast loads.")]
        [Min(0f)]
        public float minLoadingScreenSeconds = 0.75f;

        [Tooltip("Keep splats out of the render pass while GPU memory is being prepared. This avoids low FPS during the first 10-15 seconds on Quest.")]
        public bool holdSplatRenderingUntilLoaded = true;

        [Tooltip("After GPU upload, render the splats behind the loading screen for this many frames before allowing movement. Lets sort/view buffers and scene rendering settle first.")]
        [Min(0)]
        public int postLoadWarmupFrames = 60;

        [Tooltip("Minimum extra real time to keep warming up after GPU upload. Use this if Quest still has a short low-FPS moment after the bar completes.")]
        [Min(0f)]
        public float postLoadWarmupSeconds = 1f;

        [Tooltip("Keep the loading screen up until frame timing actually settles, instead of using only a fixed frame/second budget. This hides the GPU upload + first-frame sort + shader-compile spike (the flickery low-FPS moment) behind the panel.")]
        public bool warmupUntilFrameTimeStable = true;

        [Tooltip("A frame counts as 'settled' once its time drops below this many milliseconds. 72Hz Quest = ~13.9ms; leave a little headroom. Raise it if the panel never hides; lower it to demand a smoother result before revealing the scene.")]
        [Min(1f)]
        public float warmupStableFrameMs = 18f;

        [Tooltip("Number of consecutive settled frames required before the loading screen is allowed to hide.")]
        [Min(1)]
        public int warmupStableFrameCount = 30;

        [Tooltip("Hard cap on warmup time so the loading screen can never hang forever on slow devices, even if frame timing never fully settles.")]
        [Min(0f)]
        public float postLoadWarmupMaxSeconds = 8f;

        public string loadingTitle = "Loading splats";
        public string loadingWarmupText = "Preparing scene";
        public string loadingReadyText = "Ready — you can walk";

        [Header("Tilt-Shift VR Defaults")]
        [Tooltip("Apply tilt-shift focus settings to the loading camera on start. Useful in VR where the visual center can sit above the render texture center.")]
        public bool applyTiltShiftDefaultsOnStart = true;

        [Tooltip("Enable tilt-shift when applying the startup VR defaults.")]
        public bool tiltShiftEnabledOnStart = true;

        [Tooltip("Moves the sharp focus band upward. If only the top is blurred in VR, raise this value until bottom blur appears too.")]
        [Range(0f, 1f)]
        public float tiltShiftFocusPosition = 0.58f;

        [Tooltip("VR-friendly focus band width. Wider than desktop so the center of the headset stays readable.")]
        [Range(0.001f, 0.8f)]
        public float tiltShiftFocusWidth = 0.25f;

        /// <summary>True while GPU preload is running.</summary>
        public static bool IsLoading { get; private set; }

        /// <summary>True after the latest preload finished successfully.</summary>
        public static bool SplatsReady { get; private set; }

        /// <summary>0–1 progress of the current preload.</summary>
        public static float LoadProgress { get; private set; }

        /// <summary>Invoked when preloading completes and movement is re-enabled.</summary>
        public static event Action OnSplatsReady;

        Coroutine m_PreloadRoutine;
        GameObject m_LoadingRoot;
        RectTransform m_LoadingPanelRect;
        Image m_LoadingFillImage;
        Text m_LoadingStatusText;
        Text m_LoadingTitleText;
        readonly List<Behaviour> m_DisabledDuringLoad = new List<Behaviour>();
        readonly List<SplatBoxRenderer> m_HeldRenderers = new List<SplatBoxRenderer>();

        void OnEnable() => Apply();

        void OnDisable()
        {
            GaussianSplatRenderSystem.SplatRenderScale = 1f;
            if (unloadOnDisable)
                UnloadAllSplats();
            else
                RestoreHeldSplatRendering();
            HideLoadingScreen();
            RestoreMovement();
            IsLoading = false;
        }

        void Start()
        {
            if (Application.isPlaying && applyTiltShiftDefaultsOnStart)
                ApplyTiltShiftDefaults();

            if (preloadOnStart && Application.isPlaying)
                PreloadAllSplats();
        }

        void OnValidate() => Apply();

        void Update()
        {
            Apply();
            UpdateLoadingPanelPose();
        }

        void Apply()
        {
            GaussianSplatRenderSystem.SplatRenderScale = Mathf.Clamp(renderScale, 0.1f, 1f);
        }

        [ContextMenu("Apply Tilt-Shift Defaults")]
        public void ApplyTiltShiftDefaults()
        {
            var cam = ResolveLoadingCamera();
            if (cam == null)
                return;

            GaussianTiltShiftGlobalSettings.Active = true;
            GaussianTiltShiftGlobalSettings.Enabled = tiltShiftEnabledOnStart;
            GaussianTiltShiftGlobalSettings.FocusPosition = Mathf.Clamp01(tiltShiftFocusPosition);
            GaussianTiltShiftGlobalSettings.FocusWidth = Mathf.Clamp(tiltShiftFocusWidth, 0.001f, 0.8f);
            GaussianTiltShiftGlobalSettings.SyncToCamera(cam);
        }

        [ContextMenu("Preload All Splats")]
        public void PreloadAllSplats()
        {
            if (m_PreloadRoutine != null)
                StopCoroutine(m_PreloadRoutine);

            if (Application.isPlaying)
                m_PreloadRoutine = StartCoroutine(PreloadAllSplatsRoutine());
            else
                PreloadAllSplatsImmediate();
        }

        [ContextMenu("Unload All Splats")]
        public void UnloadAllSplats()
        {
            if (m_PreloadRoutine != null)
            {
                StopCoroutine(m_PreloadRoutine);
                m_PreloadRoutine = null;
            }

            foreach (var r in GetTargetRenderers())
            {
                if (r != null)
                    r.UnloadFromGpuMemory();
            }

            SplatsReady = false;
            LoadProgress = 0f;
            IsLoading = false;
            HideLoadingScreen();
            RestoreMovement();
            m_HeldRenderers.Clear();
        }

        IEnumerator PreloadAllSplatsRoutine()
        {
            var targets = BuildTargetList();
            int total = targets.Count;

            IsLoading = true;
            SplatsReady = false;
            LoadProgress = 0f;

            if (holdSplatRenderingUntilLoaded)
                HoldSplatRendering(targets);

            if (showLoadingScreen)
                ShowLoadingScreen();

            if (blockMovementWhileLoading)
                BlockMovement();

            float loadStartTime = Time.unscaledTime;

            if (total == 0)
            {
                LoadProgress = 1f;
            }
            else
            {
                for (int i = 0; i < total; i++)
                {
                    var r = targets[i];
                    if (r != null)
                    {
                        r.PreloadToGpuMemory();
                        if (r.UsesPagedLod)
                            r.PreloadPagedLodPages(ResolveLoadingCamera());
                    }

                    LoadProgress = Mathf.Lerp(0f, 0.9f, (i + 1) / (float)total);
                    SetLoadingProgress(LoadProgress, $"{loadingTitle}… {Mathf.RoundToInt(LoadProgress * 100f)}%");
                    yield return null;
                }
            }

            if (total > 0)
            {
                RestoreHeldSplatRendering();
                yield return WarmupLoadedScene();
            }

            if (minLoadingScreenSeconds > 0f)
            {
                float elapsed = Time.unscaledTime - loadStartTime;
                if (elapsed < minLoadingScreenSeconds)
                    yield return new WaitForSecondsRealtime(minLoadingScreenSeconds - elapsed);
            }

            LoadProgress = 1f;
            SplatsReady = true;
            IsLoading = false;
            SetLoadingProgress(1f, loadingReadyText, ready: true);

            if (showLoadingScreen)
            {
                yield return new WaitForSecondsRealtime(0.6f);
                HideLoadingScreen();
            }

            RestoreMovement();
            OnSplatsReady?.Invoke();
            m_PreloadRoutine = null;
        }

        IEnumerator WarmupLoadedScene()
        {
            int minFrames = Mathf.Max(0, postLoadWarmupFrames);
            float minSeconds = Mathf.Max(0f, postLoadWarmupSeconds);
            float maxSeconds = Mathf.Max(minSeconds, postLoadWarmupMaxSeconds);
            float stableMs = Mathf.Max(1f, warmupStableFrameMs);
            int stableNeeded = Mathf.Max(1, warmupStableFrameCount);

            // The splats were re-registered just before this coroutine, so they now render behind the
            // loading panel. The first frame's delta time includes the GPU upload / pipeline stall, so
            // skip it before we start measuring frame stability.
            yield return null;

            float startTime = Time.unscaledTime;
            int frame = 0;
            int stableRun = 0;

            while (true)
            {
                float elapsed = Time.unscaledTime - startTime;
                float frameMs = Time.unscaledDeltaTime * 1000f;

                if (frameMs <= stableMs)
                    stableRun++;
                else
                    stableRun = 0;

                bool minDone = frame >= minFrames && elapsed >= minSeconds;
                bool stableEnough = !warmupUntilFrameTimeStable || stableRun >= stableNeeded;

                float frameProgress = minFrames > 0 ? Mathf.Clamp01((frame + 1f) / minFrames) : 1f;
                float timeProgress = minSeconds > 0f ? Mathf.Clamp01(elapsed / minSeconds) : 1f;
                float stableProgress = warmupUntilFrameTimeStable ? Mathf.Clamp01(stableRun / (float)stableNeeded) : 1f;
                float warmupProgress = Mathf.Min(Mathf.Min(frameProgress, timeProgress), stableProgress);
                LoadProgress = Mathf.Lerp(0.9f, 0.99f, warmupProgress);
                SetLoadingProgress(LoadProgress, $"{loadingWarmupText}… {Mathf.RoundToInt(LoadProgress * 100f)}%");

                if ((minDone && stableEnough) || elapsed >= maxSeconds)
                    break;

                frame++;
                yield return null;
            }
        }

        void PreloadAllSplatsImmediate()
        {
            foreach (var r in GetTargetRenderers())
            {
                if (r != null)
                    r.PreloadToGpuMemory();
            }

            SplatsReady = true;
            LoadProgress = 1f;
            IsLoading = false;
        }

        List<SplatBoxRenderer> BuildTargetList()
        {
            var list = new List<SplatBoxRenderer>();
            foreach (var r in GetTargetRenderers())
            {
                if (r != null)
                    list.Add(r);
            }
            return list;
        }

        void HoldSplatRendering(List<SplatBoxRenderer> renderers)
        {
            for (int i = 0; i < renderers.Count; i++)
                HoldSplatRendering(renderers[i]);
        }

        void HoldSplatRendering(SplatBoxRenderer renderer)
        {
            if (renderer == null)
                return;

            var system = GaussianSplatRenderSystem.instance;
            if (!system.IsRegistered(renderer))
                return;

            system.UnregisterSplat(renderer);
            if (!m_HeldRenderers.Contains(renderer))
                m_HeldRenderers.Add(renderer);
        }

        void RestoreHeldSplatRendering()
        {
            var system = GaussianSplatRenderSystem.instance;
            for (int i = 0; i < m_HeldRenderers.Count; i++)
            {
                var renderer = m_HeldRenderers[i];
                if (renderer == null || !renderer.isActiveAndEnabled || !renderer.HasValidRenderSetup || system.IsRegistered(renderer))
                    continue;

                system.RegisterSplat(renderer);
            }

            m_HeldRenderers.Clear();
        }

        IEnumerable<SplatBoxRenderer> GetTargetRenderers()
        {
            if (preloadRenderers != null && preloadRenderers.Length > 0)
            {
                foreach (var r in preloadRenderers)
                    if (r != null)
                        yield return r;
                yield break;
            }

            if (!autoFindRenderers)
                yield break;

            var mode = includeInactiveRenderers ? FindObjectsInactive.Include : FindObjectsInactive.Exclude;
            foreach (var r in FindObjectsByType<SplatBoxRenderer>(mode))
                if (r != null)
                    yield return r;
        }

        void BlockMovement()
        {
            RestoreMovement();
            m_DisabledDuringLoad.Clear();

            if (behavioursToDisableWhileLoading != null)
            {
                foreach (var b in behavioursToDisableWhileLoading)
                {
                    if (b == null || !b.enabled)
                        continue;
                    b.enabled = false;
                    m_DisabledDuringLoad.Add(b);
                }
            }

            if (autoFindLocomotionProviders)
                DisableLocomotionProviders(m_DisabledDuringLoad);
        }

        void RestoreMovement()
        {
            for (int i = 0; i < m_DisabledDuringLoad.Count; i++)
            {
                var b = m_DisabledDuringLoad[i];
                if (b != null)
                    b.enabled = true;
            }

            m_DisabledDuringLoad.Clear();
        }

        static void DisableLocomotionProviders(List<Behaviour> disabled)
        {
            var providerType = FindLocomotionProviderType();
            if (providerType == null)
                return;

            var providers = FindObjectsByType<MonoBehaviour>(FindObjectsInactive.Include);
            foreach (var mb in providers)
            {
                if (mb == null || !providerType.IsInstanceOfType(mb) || !mb.enabled)
                    continue;
                mb.enabled = false;
                disabled.Add(mb);
            }
        }

        static Type FindLocomotionProviderType()
        {
            const string assembly = "Unity.XR.Interaction.Toolkit";
            var type = Type.GetType($"UnityEngine.XR.Interaction.Toolkit.Locomotion.LocomotionProvider, {assembly}");
            if (type == null)
                type = Type.GetType($"UnityEngine.XR.Interaction.Toolkit.LocomotionProvider, {assembly}");
            return type;
        }

        void ShowLoadingScreen()
        {
            if (m_LoadingRoot != null)
            {
                m_LoadingRoot.SetActive(true);
                SetLoadingProgress(LoadProgress, $"{loadingTitle}… {Mathf.RoundToInt(LoadProgress * 100f)}%");
                return;
            }

            BuildLoadingScreen();
            SetLoadingProgress(0f, $"{loadingTitle}… 0%");
        }

        void HideLoadingScreen()
        {
            if (m_LoadingRoot != null)
                m_LoadingRoot.SetActive(false);
        }

        void SetLoadingProgress(float progress, string status, bool ready = false)
        {
            if (m_LoadingFillImage != null)
                m_LoadingFillImage.fillAmount = Mathf.Clamp01(progress);

            if (m_LoadingStatusText != null)
                m_LoadingStatusText.text = status;

            if (m_LoadingTitleText != null)
                m_LoadingTitleText.text = ready ? loadingReadyText : loadingTitle;
        }

        void UpdateLoadingPanelPose()
        {
            if (m_LoadingRoot == null || !m_LoadingRoot.activeSelf || m_LoadingPanelRect == null)
                return;

            var cam = ResolveLoadingCamera();
            if (cam == null)
                return;

            var t = m_LoadingRoot.transform;
            t.position = cam.transform.TransformPoint(loadingPanelLocalOffset);
            t.rotation = Quaternion.LookRotation(t.position - cam.transform.position, cam.transform.up);
        }

        Camera ResolveLoadingCamera()
        {
            if (loadingCamera != null)
                return loadingCamera;
            if (Camera.main != null)
                return Camera.main;
            var cams = Camera.allCameras;
            return cams != null && cams.Length > 0 ? cams[0] : null;
        }

        void BuildLoadingScreen()
        {
            var cam = ResolveLoadingCamera();

            m_LoadingRoot = new GameObject("SplatBoxLoadingScreen");
            m_LoadingRoot.transform.SetParent(transform, false);

            var canvasGo = new GameObject("Canvas");
            canvasGo.transform.SetParent(m_LoadingRoot.transform, false);

            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvas.worldCamera = cam;
            canvas.overrideSorting = true;
            canvas.sortingOrder = 32750;

            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.dynamicPixelsPerUnit = 10f;
            scaler.referencePixelsPerUnit = 100f;

            var canvasRect = canvasGo.GetComponent<RectTransform>();
            canvasRect.sizeDelta = new Vector2(520f, 200f);
            canvasRect.localScale = Vector3.one * 0.001f;

            m_LoadingPanelRect = CreateRect("Panel", canvasRect);
            m_LoadingPanelRect.anchorMin = Vector2.zero;
            m_LoadingPanelRect.anchorMax = Vector2.one;
            m_LoadingPanelRect.offsetMin = Vector2.zero;
            m_LoadingPanelRect.offsetMax = Vector2.zero;

            var panelBg = m_LoadingPanelRect.gameObject.AddComponent<Image>();
            panelBg.color = new Color(0.04f, 0.05f, 0.08f, 0.94f);

            m_LoadingTitleText = CreateText(m_LoadingPanelRect, "Title", loadingTitle, 28, FontStyle.Bold, TextAnchor.UpperCenter);
            var titleRt = m_LoadingTitleText.rectTransform;
            titleRt.anchorMin = new Vector2(0.05f, 0.62f);
            titleRt.anchorMax = new Vector2(0.95f, 0.95f);
            titleRt.offsetMin = Vector2.zero;
            titleRt.offsetMax = Vector2.zero;

            var trackRt = CreateRect("ProgressTrack", m_LoadingPanelRect);
            trackRt.anchorMin = new Vector2(0.08f, 0.38f);
            trackRt.anchorMax = new Vector2(0.92f, 0.52f);
            trackRt.offsetMin = Vector2.zero;
            trackRt.offsetMax = Vector2.zero;
            var trackImg = trackRt.gameObject.AddComponent<Image>();
            trackImg.color = new Color(0.15f, 0.17f, 0.22f, 1f);

            var fillRt = CreateRect("ProgressFill", trackRt);
            fillRt.anchorMin = Vector2.zero;
            fillRt.anchorMax = Vector2.one;
            fillRt.offsetMin = Vector2.zero;
            fillRt.offsetMax = Vector2.zero;
            m_LoadingFillImage = fillRt.gameObject.AddComponent<Image>();
            m_LoadingFillImage.color = new Color(0.25f, 0.72f, 1f, 1f);
            m_LoadingFillImage.type = Image.Type.Filled;
            m_LoadingFillImage.fillMethod = Image.FillMethod.Horizontal;
            m_LoadingFillImage.fillOrigin = (int)Image.OriginHorizontal.Left;
            m_LoadingFillImage.fillAmount = 0f;

            m_LoadingStatusText = CreateText(m_LoadingPanelRect, "Status", loadingTitle, 20, FontStyle.Normal, TextAnchor.MiddleCenter);
            var statusRt = m_LoadingStatusText.rectTransform;
            statusRt.anchorMin = new Vector2(0.05f, 0.08f);
            statusRt.anchorMax = new Vector2(0.95f, 0.34f);
            statusRt.offsetMin = Vector2.zero;
            statusRt.offsetMax = Vector2.zero;

            UpdateLoadingPanelPose();
        }

        static RectTransform CreateRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return go.GetComponent<RectTransform>();
        }

        static Text CreateText(RectTransform parent, string name, string content, int fontSize, FontStyle style, TextAnchor align)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var text = go.AddComponent<Text>();
            text.text = content;
            text.font = GetUiFont();
            text.fontSize = fontSize;
            text.fontStyle = style;
            text.color = Color.white;
            text.alignment = align;
            text.supportRichText = false;
            text.raycastTarget = false;
            return text;
        }

        static Font s_UiFont;

        static Font GetUiFont()
        {
            if (s_UiFont != null)
                return s_UiFont;
            s_UiFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (s_UiFont == null)
                s_UiFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (s_UiFont == null)
                s_UiFont = Font.CreateDynamicFontFromOSFont("Arial", 16);
            return s_UiFont;
        }

        void OnDestroy()
        {
            if (m_LoadingRoot != null)
            {
                if (Application.isPlaying)
                    Destroy(m_LoadingRoot);
                else
                    DestroyImmediate(m_LoadingRoot);
            }
        }
    }
}
