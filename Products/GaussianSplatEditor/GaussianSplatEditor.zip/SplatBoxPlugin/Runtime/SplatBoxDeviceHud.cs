using System.Text;
using GaussianSplatting.Runtime;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.XR;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// On-device diagnostic HUD for player/XR builds (Quest etc.) where logcat/OnGUI are not usable.
    /// Renders a world-space text panel pinned in front of the active camera so the splat-rendering
    /// state is visible directly inside the headset. Reports graphics API, compute support, whether
    /// the URP feature actually executed, how many splats registered/gathered, and per-renderer
    /// asset / GPU-buffer / shader validity — i.e. exactly which reference (if any) is missing.
    ///
    /// Toggle off by setting <see cref="Enabled"/> = false before scene load, or remove this file.
    /// </summary>
    public static class SplatBoxDeviceHud
    {
        /// <summary>Opt-in device diagnostic overlay. Set true (before scene load) to show graphics
        /// API / XR / URP-path / per-renderer state in-headset. Off by default so it never shows in
        /// normal builds.</summary>
        public static bool Enabled = false;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Install()
        {
#if UNITY_EDITOR
            return;
#else
            if (!Enabled)
                return;
            var go = new GameObject("SplatBoxDeviceHud") { hideFlags = HideFlags.HideAndDontSave };
            go.AddComponent<Hud>();
#endif
        }

        sealed class Hud : MonoBehaviour
        {
            TextMesh m_Text;
            float m_NextRefresh;
            readonly StringBuilder m_Sb = new StringBuilder(512);

            void Start()
            {
                var textGo = new GameObject("SplatBoxDeviceHudText");
                textGo.transform.SetParent(transform, false);

                m_Text = textGo.AddComponent<TextMesh>();
                m_Text.anchor = TextAnchor.MiddleCenter;
                m_Text.alignment = TextAlignment.Left;
                m_Text.fontSize = 64;
                // Small glyphs + narrow multi-line layout so the report is readable in the headset.
                m_Text.characterSize = 0.0075f;
                m_Text.lineSpacing = 1.0f;
                m_Text.color = Color.white;

                var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                if (font == null)
                    font = Resources.GetBuiltinResource<Font>("Arial.ttf");
                if (font != null)
                {
                    m_Text.font = font;
                    var mr = textGo.GetComponent<MeshRenderer>();
                    if (mr != null)
                        mr.sharedMaterial = font.material;
                }
            }

            void LateUpdate()
            {
                Camera cam = Camera.main;
                if (cam == null)
                {
                    var cams = Camera.allCameras;
                    if (cams != null && cams.Length > 0)
                        cam = cams[0];
                }
                if (cam == null)
                    return;

                // Pin the panel a comfortable reading distance in front of the camera.
                var camTr = cam.transform;
                transform.position = camTr.position + camTr.forward * 2.5f;
                transform.rotation = Quaternion.LookRotation(camTr.forward, camTr.up);

                if (Time.unscaledTime < m_NextRefresh)
                    return;
                m_NextRefresh = Time.unscaledTime + 0.5f;

                m_Text.text = BuildReport();
            }

            string BuildReport()
            {
                m_Sb.Length = 0;
                m_Sb.Append("SplatBox device diagnostics\n");

                m_Sb.Append("Unity: ").Append(Application.unityVersion).Append('\n');
                var rp = GraphicsSettings.currentRenderPipeline;
                m_Sb.Append("RenderPipeline: ").Append(rp != null ? rp.GetType().Name : "Built-in").Append('\n');
                m_Sb.Append("GfxAPI: ").Append(SystemInfo.graphicsDeviceType).Append('\n');
                m_Sb.Append("ComputeSupport: ").Append(SystemInfo.supportsComputeShaders).Append('\n');
                m_Sb.Append("XR: ").Append(XRSettings.enabled).Append('\n');
                m_Sb.Append("StereoMode: ").Append(XRSettings.enabled ? XRSettings.stereoRenderingMode.ToString() : "n/a").Append('\n');
                m_Sb.Append("URPExecuted: ").Append(GaussianSplatRenderSystem.URPFeatureExecuted).Append('\n');
                m_Sb.Append("Path: ").Append(GaussianSplatRenderSystem.URPExecPath).Append('\n');
                m_Sb.Append("RenderError: ").Append(GaussianSplatRenderSystem.LastRenderError).Append('\n');

                var system = GaussianSplatRenderSystem.instance;
                m_Sb.Append("Registered: ").Append(system.RegisteredSplatCount).Append('\n');
                m_Sb.Append("Gathered: ").Append(GaussianSplatRenderSystem.LastGatheredSplatCount).Append('\n');

#if UNITY_2022_2_OR_NEWER
                var renderers = Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsInactive.Include);
#else
                var renderers = Object.FindObjectsOfType<SplatBoxRenderer>(true);
#endif
                m_Sb.Append("SceneRenderers: ").Append(renderers != null ? renderers.Length : 0).Append('\n');
                if (renderers != null)
                {
                    for (int i = 0; i < renderers.Length; i++)
                    {
                        if (renderers[i] != null)
                            m_Sb.Append("- ").Append(renderers[i].DiagnosticLine()).Append('\n');
                    }
                }

                if (rp != null && !GaussianSplatRenderSystem.URPFeatureExecuted)
                    m_Sb.Append(">> URP feature NOT running:\n   add it to the Android URP Renderer\n   (SplatBox > Setup URP Renderer Features)\n   and disable Compatibility Mode.\n");

                return m_Sb.ToString();
            }
        }
    }
}
