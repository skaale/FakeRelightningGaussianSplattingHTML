// SPDX-License-Identifier: MIT
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR;
#if UNITY_XR_INTERACTION_TOOLKIT
using UnityEngine.XR.Interaction.Toolkit.UI;
#endif

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// World-space VR menu for splat size, render scale, tilt-shift, and splat color grading.
    /// Toggle visibility with the right controller A button (primaryButton on the right hand).
    /// Point the controller at a slider and hold trigger to drag (or use XR UI raycaster when XRI is installed).
    /// </summary>
    [DisallowMultipleComponent]
    public class SplatBoxVRSettingsMenu : MonoBehaviour
    {
        [Header("XR Input")]
        [Tooltip("Controller that opens the menu (Meta Quest A = primaryButton on the right hand).")]
        public XRNode m_MenuController = XRNode.RightHand;

        [Header("Menu Placement")]
        [Tooltip("Local offset from the camera rig (Z = forward). Root stays parented to this camera.")]
        public Vector3 m_MenuLocalOffset = new Vector3(0f, -0.08f, 1f);
        public Vector2 m_PanelSizePixels = new Vector2(420f, 720f);
        public float m_WorldScale = 0.001f;

        [Header("Interaction")]
        public float m_RayMaxDistance = 2.5f;
        [Tooltip("Hold trigger on the menu controller to drag sliders.")]
        public bool m_UseTriggerToDrag = true;
        [Tooltip("How much of each slider row is clickable. Larger values make VR ray/poke aiming easier.")]
        [Range(0.2f, 1f)] public float m_SliderHitWidth = 0.68f;
        [Tooltip("Bypass XRI's XRUIInputModule and drive sliders directly via legacy XR InputDevices " +
                 "(trigger to drag). Enable this if your XRI action assets aren't enabled (no Input Action " +
                 "Manager), so the Near-Far/Ray interactor's UI Press never fires.")]
        public bool m_ForceBuiltInTriggerDrag = false;

        [Header("Defaults")]
        public float m_DefaultSplatScale = 1f;
        [Range(0.1f, 1f)] public float m_DefaultRenderScale = 0.65f;
        public bool m_DefaultTiltShiftEnabled = true;
        [Tooltip("VR focus band position. Slightly above center helps keep both top and bottom blur visible in headset.")]
        [Range(0f, 1f)] public float m_DefaultTiltShiftFocusPosition = 0.58f;
        [Tooltip("Tilt-shift focus band width for VR. Wider than desktop (0.05) so more of the scene stays sharp in headset FOV.")]
        [Range(0.05f, 1f)] public float m_DefaultTiltShiftFocusWidth = 0.25f;
        [Tooltip("If true, the settings panel is shown on start (otherwise it stays hidden until the A button is pressed).")]
        public bool m_StartVisible = true;

        Canvas m_Canvas;
        RectTransform m_CanvasRect;
        RectTransform m_PanelRect;
        GameObject m_MenuPanel;
        Material m_OnTopUiMaterial;
        Camera m_TargetCamera;
        Transform m_MenuRoot;

        bool m_MenuVisible;
        bool m_UsingXrUi;
        bool m_AButtonWasPressed;
        bool m_TriggerWasPressed;
        Slider m_ActiveSlider;
        RectTransform m_ActiveSliderRect;
        Slider m_HoveredSlider;

        readonly List<SplatBoxRenderer> m_SplatRenderers = new List<SplatBoxRenderer>();
        Toggle m_TiltShiftToggle;

        struct SliderBinding
        {
            public Slider slider;
            public System.Action<float> apply;
            public float min;
            public float max;
            public Image trackImage;
            public Image fillImage;
            public Image handleImage;
            public Image hitImage;
        }

        readonly List<SliderBinding> m_SliderBindings = new List<SliderBinding>();

        static Font s_UiFont;
        static readonly InputFeatureUsage<Vector3> s_PointerPositionUsage = new InputFeatureUsage<Vector3>("PointerPosition");
        static readonly InputFeatureUsage<Quaternion> s_PointerRotationUsage = new InputFeatureUsage<Quaternion>("PointerRotation");

        /// <summary>UI children under a canvas already have a RectTransform; AddComponent returns null and causes NRE.</summary>
        static RectTransform RequireRectTransform(GameObject go)
        {
            if (go.TryGetComponent(out RectTransform rt))
                return rt;
            return go.AddComponent<RectTransform>();
        }

#if UNITY_XR_INTERACTION_TOOLKIT
        // Make sure an EventSystem with an XRUIInputModule exists so XR ray/Near-Far interactors can drive
        // the sliders. A plain StandaloneInputModule ignores tracked-device pointer events.
        bool EnsureXrUiInputModule()
        {
            var es = FindAnyObjectByType<UnityEngine.EventSystems.EventSystem>();
            if (es == null)
            {
                var go = new GameObject("EventSystem");
                es = go.AddComponent<UnityEngine.EventSystems.EventSystem>();
            }

            if (es.GetComponent<XRUIInputModule>() == null)
            {
                // A legacy StandaloneInputModule would compete with the XR module for activation; disable it.
                var standalone = es.GetComponent<UnityEngine.EventSystems.StandaloneInputModule>();
                if (standalone != null)
                    standalone.enabled = false;
                es.gameObject.AddComponent<XRUIInputModule>();
            }
            return true;
        }
#endif

        static Font GetUiFont()
        {
            if (s_UiFont != null)
                return s_UiFont;
            s_UiFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (s_UiFont == null)
                s_UiFont = Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (s_UiFont == null)
                s_UiFont = Font.CreateDynamicFontFromOSFont("Arial", 16);
            return s_UiFont;
        }

        static void SetupUiText(Text text, string content, int fontSize, FontStyle style = FontStyle.Normal, TextAnchor align = TextAnchor.MiddleLeft)
        {
            text.text = content;
            text.font = GetUiFont();
            text.fontSize = fontSize;
            text.fontStyle = style;
            text.color = Color.white;
            text.alignment = align;
            text.supportRichText = false;
        }

        void Awake()
        {
            m_TargetCamera = GetComponent<Camera>();
            if (m_TargetCamera == null)
                m_TargetCamera = Camera.main;

            BuildMenuUI();
            LoadFromScene();
            SetMenuVisible(m_StartVisible);
            if (m_StartVisible)
                GaussianTiltShiftGlobalSettings.Active = true;
        }

        void Update()
        {
            if (m_TargetCamera == null)
            {
                m_TargetCamera = Camera.main;
                if (m_TargetCamera == null)
                    return;
            }

            HandleMenuToggle();
            if (!m_MenuVisible)
                return;

            RefreshSplatRendererList();
            HandleSliderInteraction();
        }

        void HandleMenuToggle()
        {
            // Right Touch: A = settings menu. B is reserved for the splat brush tool HUD.
            bool aPressed = IsButtonPressed(CommonUsages.primaryButton);
            if (aPressed && !m_AButtonWasPressed)
            {
                SetMenuVisible(!m_MenuVisible);
                if (m_MenuVisible)
                {
                    GaussianTiltShiftGlobalSettings.Active = true;
                    PushTiltShift();
                }
            }

            m_AButtonWasPressed = aPressed;
        }

        void SetMenuVisible(bool visible)
        {
            m_MenuVisible = visible;
            // Root + Canvas stay active (camera-local Z offset). Only the panel content toggles on A.
            if (m_MenuPanel != null)
                m_MenuPanel.SetActive(visible);
        }

        void OnDestroy()
        {
            if (m_OnTopUiMaterial != null)
            {
                Destroy(m_OnTopUiMaterial);
                m_OnTopUiMaterial = null;
            }
        }

        void BuildMenuUI()
        {
            m_MenuRoot = new GameObject("SplatBoxVRSettingsRoot").transform;
            m_MenuRoot.SetParent(transform, false);
            m_MenuRoot.localPosition = m_MenuLocalOffset;
            m_MenuRoot.localRotation = Quaternion.identity;
            m_MenuRoot.localScale = Vector3.one;
            m_MenuRoot.gameObject.SetActive(true);

            var canvasGo = new GameObject("Canvas");
            canvasGo.transform.SetParent(m_MenuRoot, false);
            m_Canvas = canvasGo.AddComponent<Canvas>();
            m_Canvas.renderMode = RenderMode.WorldSpace;
            m_Canvas.worldCamera = m_TargetCamera;
            // Draw the menu after everything else so the splat cloud / scene cannot sort over it.
            m_Canvas.overrideSorting = true;
            m_Canvas.sortingOrder = 32760;
            canvasGo.SetActive(true);

            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.dynamicPixelsPerUnit = 10f;
            scaler.referencePixelsPerUnit = 100f;

            canvasGo.AddComponent<GraphicRaycaster>();
#if UNITY_XR_INTERACTION_TOOLKIT
            // Ray/Near-Far interactors drive Unity UI through this raycaster + an XRUIInputModule on the
            // EventSystem. Without it the controller ray never reaches the sliders.
            canvasGo.AddComponent<TrackedDeviceGraphicRaycaster>();
            // Unless the user forces the built-in InputDevices drag, hand UI control to the XRUIInputModule.
            m_UsingXrUi = !m_ForceBuiltInTriggerDrag && EnsureXrUiInputModule();
#else
            if (FindAnyObjectByType<UnityEngine.EventSystems.EventSystem>() == null)
            {
                var es = new GameObject("EventSystem");
                es.AddComponent<UnityEngine.EventSystems.EventSystem>();
                es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();
            }
#endif

            m_CanvasRect = canvasGo.GetComponent<RectTransform>();
            m_CanvasRect.sizeDelta = m_PanelSizePixels;
            m_CanvasRect.localScale = Vector3.one * m_WorldScale;

            // Panel background (toggled on/off with A; Canvas stays active)
            var panelGo = new GameObject("Panel", typeof(RectTransform));
            panelGo.transform.SetParent(m_CanvasRect, false);
            m_MenuPanel = panelGo;
            m_PanelRect = RequireRectTransform(panelGo);
            m_PanelRect.anchorMin = Vector2.zero;
            m_PanelRect.anchorMax = Vector2.one;
            m_PanelRect.offsetMin = Vector2.zero;
            m_PanelRect.offsetMax = Vector2.zero;
            var panelImage = panelGo.AddComponent<Image>();
            panelImage.color = new Color(0.06f, 0.07f, 0.1f, 0.92f);

            var layout = panelGo.AddComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(14, 14, 14, 14);
            layout.spacing = 6f;
            layout.childControlHeight = true;
            layout.childControlWidth = true;
            layout.childForceExpandHeight = false;
            layout.childForceExpandWidth = true;

            AddHeader(panelGo.transform, "SplatBox VR Settings");
            AddHint(panelGo.transform, "A = toggle menu | Trigger = drag slider");

            AddSection(panelGo.transform, "Splats");
            AddSlider(panelGo.transform, "Splat Size", m_DefaultSplatScale, 0.01f, 2f, v =>
            {
                foreach (var r in m_SplatRenderers)
                    if (r != null) r.m_SplatScale = v;
            });
            AddSlider(panelGo.transform, "Render Scale", m_DefaultRenderScale, 0.1f, 1f, v =>
            {
                GaussianSplatRenderSystem.SplatRenderScale = v;
            });
            AddSlider(panelGo.transform, "LOD Quality", 0.5f, 0.05f, 1f, v =>
            {
                foreach (var r in m_SplatRenderers)
                {
                    if (r == null || !r.UsesPagedLod)
                        continue;
                    if (r.lodSimpleMode)
                        r.SetLodQuality(v);
                    else
                        r.SetLodDetailScale(v * 2f); // Advanced mode keeps the old detail-scale behaviour.
                }
            });

            AddSection(panelGo.transform, "Tilt-Shift");
            m_TiltShiftToggle = AddToggle(panelGo.transform, "Enable Tilt-Shift", m_DefaultTiltShiftEnabled, on =>
            {
                GaussianTiltShiftGlobalSettings.Enabled = on;
                GaussianTiltShiftGlobalSettings.Active = true;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Focus Position", GaussianTiltShiftGlobalSettings.FocusPosition, 0f, 1f, v =>
            {
                GaussianTiltShiftGlobalSettings.FocusPosition = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Focus Width", m_DefaultTiltShiftFocusWidth, 0.05f, 1f, v =>
            {
                GaussianTiltShiftGlobalSettings.FocusWidth = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Blur Strength", GaussianTiltShiftGlobalSettings.BlurStrength, 0f, 25f, v =>
            {
                GaussianTiltShiftGlobalSettings.BlurStrength = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Top Blur", GaussianTiltShiftGlobalSettings.TopBlurStrength, 0f, 2f, v =>
            {
                GaussianTiltShiftGlobalSettings.TopBlurStrength = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Bottom Blur", GaussianTiltShiftGlobalSettings.BottomBlurStrength, 0f, 2f, v =>
            {
                GaussianTiltShiftGlobalSettings.BottomBlurStrength = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Top Blur Pos", GaussianTiltShiftGlobalSettings.TopBlurOffset, -0.5f, 0.5f, v =>
            {
                GaussianTiltShiftGlobalSettings.TopBlurOffset = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Bottom Blur Pos", GaussianTiltShiftGlobalSettings.BottomBlurOffset, -0.5f, 0.5f, v =>
            {
                GaussianTiltShiftGlobalSettings.BottomBlurOffset = v;
                PushTiltShift();
            });

            AddSection(panelGo.transform, "Tilt Post");
            AddSlider(panelGo.transform, "Tilt Saturation", GaussianTiltShiftGlobalSettings.SaturationBoost, 0.5f, 2f, v =>
            {
                GaussianTiltShiftGlobalSettings.SaturationBoost = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Tilt Contrast", GaussianTiltShiftGlobalSettings.ContrastBoost, 0.5f, 2f, v =>
            {
                GaussianTiltShiftGlobalSettings.ContrastBoost = v;
                PushTiltShift();
            });
            AddSlider(panelGo.transform, "Vignette", GaussianTiltShiftGlobalSettings.VignetteStrength, 0f, 1f, v =>
            {
                GaussianTiltShiftGlobalSettings.VignetteStrength = v;
                PushTiltShift();
            });

            AddSection(panelGo.transform, "Splat Color");
            AddSlider(panelGo.transform, "Exposure", 0f, -2f, 5f, v =>
            {
                foreach (var r in m_SplatRenderers)
                    if (r != null) r.m_Exposure = v;
            });
            AddSlider(panelGo.transform, "Contrast", 1f, 0f, 2f, v =>
            {
                foreach (var r in m_SplatRenderers)
                    if (r != null) r.m_Contrast = v;
            });
            AddSlider(panelGo.transform, "Saturation", 1f, 0f, 2f, v =>
            {
                foreach (var r in m_SplatRenderers)
                    if (r != null) r.m_Saturation = v;
            });

            ApplyAlwaysOnTop();
        }

        // Force every UI graphic to ignore the depth buffer (ZTest Always) so the world-space menu is never
        // occluded by the Gaussian splats or scene geometry — it always renders in the viewport.
        void ApplyAlwaysOnTop()
        {
            if (m_OnTopUiMaterial == null)
            {
                var uiShader = Shader.Find("UI/Default");
                if (uiShader != null)
                {
                    m_OnTopUiMaterial = new Material(uiShader) { name = "SplatBoxVRMenu_OnTop" };
                    // unity_GUIZTestMode drives the UI/Default shader's ZTest; Always = draw over everything.
                    m_OnTopUiMaterial.SetInt("unity_GUIZTestMode", (int)UnityEngine.Rendering.CompareFunction.Always);
                }
            }

            if (m_OnTopUiMaterial == null)
                return;

            var graphics = m_CanvasRect.GetComponentsInChildren<Graphic>(true);
            foreach (var g in graphics)
            {
                g.material = m_OnTopUiMaterial;
                g.SetMaterialDirty();
            }
        }

        void LoadFromScene()
        {
            RefreshSplatRendererList();
            GaussianSplatRenderSystem.SplatRenderScale = m_DefaultRenderScale;

            if (m_SplatRenderers.Count > 0)
            {
                var r = m_SplatRenderers[0];
                m_DefaultSplatScale = r.m_SplatScale;
            }

            GaussianTiltShiftGlobalSettings.Active = true;
            if (!GaussianTiltShiftGlobalSettings.Enabled && m_DefaultTiltShiftEnabled)
                GaussianTiltShiftGlobalSettings.Enabled = true;

            if (Mathf.Approximately(GaussianTiltShiftGlobalSettings.FocusPosition, 0.5f))
                GaussianTiltShiftGlobalSettings.FocusPosition = m_DefaultTiltShiftFocusPosition;

            // Desktop defaults (0.05) are too narrow in VR — apply a wider in-focus band on load.
            if (GaussianTiltShiftGlobalSettings.FocusWidth < m_DefaultTiltShiftFocusWidth)
                GaussianTiltShiftGlobalSettings.FocusWidth = m_DefaultTiltShiftFocusWidth;

            SyncSlidersFromState();
            PushTiltShift();
        }

        void SyncSlidersFromState()
        {
            foreach (var b in m_SliderBindings)
            {
                if (b.slider == null)
                    continue;
                float t = Mathf.InverseLerp(b.min, b.max, ReadSliderState(b));
                b.slider.SetValueWithoutNotify(t);
            }

            if (m_TiltShiftToggle != null)
                m_TiltShiftToggle.SetIsOnWithoutNotify(GaussianTiltShiftGlobalSettings.Enabled);
        }

        float ReadSliderState(SliderBinding b)
        {
            // Match by label order — use stored apply target heuristics via slider name in hierarchy
            var label = b.slider.transform.parent.Find("Label")?.GetComponent<Text>();
            if (label == null)
                return b.min;
            switch (label.text)
            {
                case "Splat Size":
                    return m_SplatRenderers.Count > 0 && m_SplatRenderers[0] != null ? m_SplatRenderers[0].m_SplatScale : m_DefaultSplatScale;
                case "Render Scale":
                    return GaussianSplatRenderSystem.SplatRenderScale;
                case "LOD Quality":
                {
                    var paged = FirstPagedLodRenderer();
                    if (paged == null)
                        return 0.5f;
                    // Advanced mode maps the slider onto Detail Scale as v * 2, so read it back halved.
                    return paged.lodSimpleMode ? paged.lodQuality : paged.lodDetailScale * 0.5f;
                }
                case "Focus Position": return GaussianTiltShiftGlobalSettings.FocusPosition;
                case "Focus Width": return GaussianTiltShiftGlobalSettings.FocusWidth;
                case "Blur Strength": return GaussianTiltShiftGlobalSettings.BlurStrength;
                case "Top Blur": return GaussianTiltShiftGlobalSettings.TopBlurStrength;
                case "Bottom Blur": return GaussianTiltShiftGlobalSettings.BottomBlurStrength;
                case "Top Blur Pos": return GaussianTiltShiftGlobalSettings.TopBlurOffset;
                case "Bottom Blur Pos": return GaussianTiltShiftGlobalSettings.BottomBlurOffset;
                case "Tilt Saturation": return GaussianTiltShiftGlobalSettings.SaturationBoost;
                case "Tilt Contrast": return GaussianTiltShiftGlobalSettings.ContrastBoost;
                case "Saturation":
                    return m_SplatRenderers.Count > 0 && m_SplatRenderers[0] != null ? m_SplatRenderers[0].m_Saturation : 1f;
                case "Contrast":
                    return m_SplatRenderers.Count > 0 && m_SplatRenderers[0] != null ? m_SplatRenderers[0].m_Contrast : 1f;
                case "Vignette": return GaussianTiltShiftGlobalSettings.VignetteStrength;
                case "Exposure":
                    return m_SplatRenderers.Count > 0 && m_SplatRenderers[0] != null ? m_SplatRenderers[0].m_Exposure : 0f;
                default: return b.min;
            }
        }

        /// <summary>First paged-LoD renderer; the LOD Quality slider reads its state from it.</summary>
        SplatBoxRenderer FirstPagedLodRenderer()
        {
            foreach (var r in m_SplatRenderers)
            {
                if (r != null && r.UsesPagedLod)
                    return r;
            }
            return null;
        }

        void RefreshSplatRendererList()
        {
            m_SplatRenderers.Clear();
            var found = FindObjectsByType<SplatBoxRenderer>();
            foreach (var r in found)
            {
                if (r != null && r.isActiveAndEnabled && r.HasValidAsset)
                    m_SplatRenderers.Add(r);
            }
        }

        void PushTiltShift()
        {
            GaussianTiltShiftGlobalSettings.Active = true;
            GaussianTiltShiftGlobalSettings.SyncToCamera(m_TargetCamera);
        }

        void HandleSliderInteraction()
        {
#if UNITY_XR_INTERACTION_TOOLKIT
            // When an XR Ray/Near-Far interactor is driving the UI through XRUIInputModule, let it own the
            // sliders. Running the custom ray-drag too would double-apply and cause jitter.
            if (m_UsingXrUi)
                return;
#endif
            if (!m_UseTriggerToDrag)
                return;

            bool trigger = IsButtonPressed(CommonUsages.triggerButton);
            if (!TryGetControllerRay(out Ray ray))
            {
                m_TriggerWasPressed = trigger;
                m_ActiveSlider = null;
                SetHoveredSlider(null);
                return;
            }

            if (!trigger)
                UpdateHoveredSlider(ray);

            if (trigger)
            {
                if (!m_TriggerWasPressed || m_ActiveSlider == null)
                    TryPickSlider(ray);

                if (m_ActiveSlider != null && m_ActiveSliderRect != null)
                    DragSlider(ray);
            }
            else
            {
                m_ActiveSlider = null;
                m_ActiveSliderRect = null;
            }

            m_TriggerWasPressed = trigger;
        }

        void SetHoveredSlider(Slider slider)
        {
            if (m_HoveredSlider == slider)
                return;

            SetSliderVisualState(m_HoveredSlider, false);
            m_HoveredSlider = slider;
            SetSliderVisualState(m_HoveredSlider, true);
        }

        void SetSliderVisualState(Slider slider, bool hovered)
        {
            if (slider == null)
                return;

            foreach (var b in m_SliderBindings)
            {
                if (b.slider != slider)
                    continue;

                if (b.trackImage != null)
                    b.trackImage.color = hovered ? new Color(0.28f, 0.34f, 0.46f) : new Color(0.2f, 0.22f, 0.28f);
                if (b.fillImage != null)
                    b.fillImage.color = hovered ? new Color(0.45f, 0.7f, 1f) : new Color(0.35f, 0.55f, 0.95f);
                if (b.handleImage != null)
                    b.handleImage.color = hovered ? new Color(1f, 0.92f, 0.35f) : Color.white;
                if (b.hitImage != null)
                    b.hitImage.color = hovered ? new Color(0.35f, 0.55f, 1f, 0.12f) : new Color(0f, 0f, 0f, 0.001f);
                return;
            }
        }

        void TryPickSlider(Ray ray)
        {
            m_ActiveSlider = null;
            m_ActiveSliderRect = null;
            if (TryGetSliderUnderRay(ray, out Slider slider, out RectTransform dragRect))
            {
                m_ActiveSlider = slider;
                m_ActiveSliderRect = dragRect;
                SetHoveredSlider(slider);
            }
        }

        void UpdateHoveredSlider(Ray ray)
        {
            if (TryGetSliderUnderRay(ray, out Slider slider, out _))
                SetHoveredSlider(slider);
            else
                SetHoveredSlider(null);
        }

        bool TryGetSliderUnderRay(Ray ray, out Slider slider, out RectTransform dragRect)
        {
            slider = null;
            dragRect = null;
            if (m_CanvasRect == null)
                return false;

            Plane plane = new Plane(-m_CanvasRect.forward, m_CanvasRect.position);
            if (!plane.Raycast(ray, out float dist) || dist > m_RayMaxDistance)
                return false;

            Vector3 hitWorld = ray.GetPoint(dist);
            Vector2 canvasLocal = m_CanvasRect.InverseTransformPoint(hitWorld);
            if (!m_CanvasRect.rect.Contains(canvasLocal))
                return false;

            float best = float.MaxValue;
            foreach (var b in m_SliderBindings)
            {
                if (b.slider == null)
                    continue;
                var rt = b.slider.GetComponent<RectTransform>();
                Vector2 sliderLocal = rt.InverseTransformPoint(hitWorld);
                if (rt.rect.Contains(sliderLocal))
                {
                    float d = (rt.TransformPoint(rt.rect.center) - hitWorld).sqrMagnitude;
                    if (d < best)
                    {
                        best = d;
                        slider = b.slider;
                        // Pick against the large invisible slider rect, but map values against the handle
                        // slide area. This removes the "offset" feeling when the hit box is wider than the
                        // visible track.
                        dragRect = b.slider.handleRect != null && b.slider.handleRect.parent is RectTransform handleArea
                            ? handleArea
                            : rt;
                    }
                }
            }

            return slider != null && dragRect != null;
        }

        void DragSlider(Ray ray)
        {
            Plane plane = new Plane(-m_CanvasRect.forward, m_CanvasRect.position);
            if (!plane.Raycast(ray, out float dist))
                return;

            Vector3 hitWorld = ray.GetPoint(dist);
            Vector2 local = m_ActiveSliderRect.InverseTransformPoint(hitWorld);

            Rect rect = m_ActiveSliderRect.rect;
            float t = Mathf.InverseLerp(rect.xMin, rect.xMax, local.x);
            m_ActiveSlider.SetValueWithoutNotify(Mathf.Clamp01(t));

            foreach (var b in m_SliderBindings)
            {
                if (b.slider != m_ActiveSlider)
                    continue;
                float v = Mathf.Lerp(b.min, b.max, t);
                b.apply(v);
                if (b.slider.transform.parent.Find("Value")?.GetComponent<Text>() is Text valueText)
                    valueText.text = FormatValue(v);
                break;
            }

            PushTiltShift();
        }

        bool TryGetControllerRay(out Ray ray)
        {
            ray = default;
            if (!TryGetControllerPose(m_MenuController, out Vector3 pos, out Quaternion rot))
                return false;
            ray = new Ray(pos, rot * Vector3.forward);
            return true;
        }

        bool TryGetControllerPose(XRNode node, out Vector3 position, out Quaternion rotation)
        {
            position = Vector3.zero;
            rotation = Quaternion.identity;

            var device = InputDevices.GetDeviceAtXRNode(node);
            if (!device.isValid)
                return false;

            // Prefer the controller's pointer/aim pose. devicePosition/deviceRotation are often the grip pose,
            // which points through the controller body and feels offset from the visible UI ray in Quest/XRI.
            Vector3 localPos = Vector3.zero;
            Quaternion localRot = Quaternion.identity;
            bool hasPose =
                device.TryGetFeatureValue(s_PointerPositionUsage, out localPos) &&
                device.TryGetFeatureValue(s_PointerRotationUsage, out localRot);

            if (!hasPose)
            {
                hasPose =
                    device.TryGetFeatureValue(CommonUsages.devicePosition, out localPos) &&
                    device.TryGetFeatureValue(CommonUsages.deviceRotation, out localRot);
            }

            if (!hasPose)
                return false;

            // InputDevices poses are in XR tracking space (relative to the rig origin), but the menu lives
            // in world space. Convert using the HMD as a reference: we know the camera's world transform
            // (driven by the HMD) AND the HMD's tracking-space pose, so trackingToWorld = camWorld * hmdTracking^-1.
            // This is hierarchy-independent (works no matter how the XR Origin / camera offset is nested).
            if (TryGetTrackingToWorld(out Matrix4x4 trackingToWorld))
            {
                position = trackingToWorld.MultiplyPoint3x4(localPos);
                rotation = trackingToWorld.rotation * localRot;
            }
            else
            {
                position = localPos;
                rotation = localRot;
            }
            return true;
        }

        bool TryGetTrackingToWorld(out Matrix4x4 trackingToWorld)
        {
            trackingToWorld = Matrix4x4.identity;
            if (m_TargetCamera == null)
                return false;

            var head = InputDevices.GetDeviceAtXRNode(XRNode.CenterEye);
            if (!head.isValid ||
                !head.TryGetFeatureValue(CommonUsages.devicePosition, out Vector3 headPos) ||
                !head.TryGetFeatureValue(CommonUsages.deviceRotation, out Quaternion headRot))
                return false;

            Matrix4x4 hmdTracking = Matrix4x4.TRS(headPos, headRot, Vector3.one);
            var camT = m_TargetCamera.transform;
            Matrix4x4 hmdWorld = Matrix4x4.TRS(camT.position, camT.rotation, Vector3.one);
            trackingToWorld = hmdWorld * hmdTracking.inverse;
            return true;
        }

        bool IsButtonPressed(InputFeatureUsage<bool> usage)
        {
            var device = InputDevices.GetDeviceAtXRNode(m_MenuController);
            return device.isValid && device.TryGetFeatureValue(usage, out bool pressed) && pressed;
        }

        void AddHeader(Transform parent, string text)
        {
            var go = new GameObject("Header", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            SetupUiText(t, text, 22, FontStyle.Bold, TextAnchor.MiddleCenter);
            var le = go.AddComponent<LayoutElement>();
            le.preferredHeight = 36f;
        }

        void AddHint(Transform parent, string text)
        {
            var go = new GameObject("Hint", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            SetupUiText(t, text, 14, align: TextAnchor.MiddleCenter);
            t.color = new Color(0.75f, 0.8f, 0.9f);
            var le = go.AddComponent<LayoutElement>();
            le.preferredHeight = 28f;
        }

        void AddSection(Transform parent, string title)
        {
            var go = new GameObject("Section", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var t = go.AddComponent<Text>();
            SetupUiText(t, title, 17, FontStyle.Bold);
            t.color = new Color(0.55f, 0.75f, 1f);
            var le = go.AddComponent<LayoutElement>();
            le.preferredHeight = 26f;
        }

        // Stretch a child rect to a horizontal fraction [xMin,xMax] of its parent row, with vertical inset.
        static RectTransform AnchorInRow(GameObject go, float xMin, float xMax, float yInset)
        {
            var rt = RequireRectTransform(go);
            rt.anchorMin = new Vector2(xMin, 0f);
            rt.anchorMax = new Vector2(xMax, 1f);
            rt.offsetMin = new Vector2(0f, yInset);
            rt.offsetMax = new Vector2(0f, -yInset);
            return rt;
        }

        void AddSlider(Transform parent, string label, float initial, float min, float max, System.Action<float> apply)
        {
            // Plain row controlled by the panel's VerticalLayoutGroup (width stretch + preferred height).
            // Children are positioned by anchor fractions — NO per-row layout group (it fought the anchors).
            var row = new GameObject("Row_" + label, typeof(RectTransform));
            row.transform.SetParent(parent, false);
            var rowLe = row.AddComponent<LayoutElement>();
            rowLe.preferredHeight = 36f;

            var labelGo = new GameObject("Label", typeof(RectTransform));
            labelGo.transform.SetParent(row.transform, false);
            var labelText = labelGo.AddComponent<Text>();
            SetupUiText(labelText, label, 14);
            labelText.raycastTarget = false;
            AnchorInRow(labelGo, 0.02f, 0.40f, 4f);

            var valueGo = new GameObject("Value", typeof(RectTransform));
            valueGo.transform.SetParent(row.transform, false);
            var valueText = valueGo.AddComponent<Text>();
            SetupUiText(valueText, FormatValue(initial), 13, align: TextAnchor.MiddleRight);
            valueText.color = new Color(0.85f, 0.9f, 1f);
            valueText.raycastTarget = false;
            AnchorInRow(valueGo, 0.86f, 0.99f, 4f);

            // Slider hit area: large enough for XR ray / poke UI, while the visible track stays thin.
            // Unity/XRI UI does not need physics colliders here; it raycasts against Graphic rects.
            var sliderGo = new GameObject("Slider", typeof(RectTransform));
            sliderGo.transform.SetParent(row.transform, false);
            float hitMin = Mathf.Clamp01(0.84f - m_SliderHitWidth);
            var sliderRt = AnchorInRow(sliderGo, hitMin, 0.99f, 0f);

            var bg = sliderGo.AddComponent<Image>();
            bg.color = new Color(0f, 0f, 0f, 0.001f);
            bg.raycastTarget = true;
            var slider = sliderGo.AddComponent<Slider>();
            slider.minValue = 0f;
            slider.maxValue = 1f;
            slider.transition = Selectable.Transition.ColorTint;
            var colors = slider.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 0.92f, 0.35f);
            colors.pressedColor = new Color(0.45f, 0.7f, 1f);
            colors.selectedColor = colors.highlightedColor;
            colors.disabledColor = new Color(0.45f, 0.45f, 0.45f);
            colors.colorMultiplier = 1f;
            slider.colors = colors;

            var fillArea = new GameObject("Fill Area", typeof(RectTransform));
            fillArea.transform.SetParent(sliderGo.transform, false);
            var fillAreaRt = RequireRectTransform(fillArea);
            fillAreaRt.anchorMin = Vector2.zero;
            fillAreaRt.anchorMax = Vector2.one;
            // Keep the visual track aligned with the old slider column even though the hit area is wider.
            float panelWidth = Mathf.Max(1f, m_PanelSizePixels.x);
            fillAreaRt.offsetMin = new Vector2(Mathf.Max(2f, (0.42f - hitMin) * panelWidth), 13);
            fillAreaRt.offsetMax = new Vector2(-Mathf.Max(2f, (0.99f - 0.84f) * panelWidth), -13);
            var track = new GameObject("Track", typeof(RectTransform));
            track.transform.SetParent(fillArea.transform, false);
            var trackImg = track.AddComponent<Image>();
            trackImg.color = new Color(0.2f, 0.22f, 0.28f);
            trackImg.raycastTarget = false;
            var trackRt = RequireRectTransform(track);
            trackRt.anchorMin = Vector2.zero;
            trackRt.anchorMax = Vector2.one;
            trackRt.offsetMin = Vector2.zero;
            trackRt.offsetMax = Vector2.zero;
            var fill = new GameObject("Fill", typeof(RectTransform));
            fill.transform.SetParent(fillArea.transform, false);
            var fillImg = fill.AddComponent<Image>();
            fillImg.color = new Color(0.35f, 0.55f, 0.95f);
            fillImg.raycastTarget = false;
            var fillRt = RequireRectTransform(fill);
            fillRt.anchorMin = Vector2.zero;
            fillRt.anchorMax = Vector2.one;
            fillRt.offsetMin = Vector2.zero;
            fillRt.offsetMax = Vector2.zero;
            slider.fillRect = fillRt;

            var handleSlide = new GameObject("Handle Slide Area", typeof(RectTransform));
            handleSlide.transform.SetParent(sliderGo.transform, false);
            var handleSlideRt = RequireRectTransform(handleSlide);
            handleSlideRt.anchorMin = Vector2.zero;
            handleSlideRt.anchorMax = Vector2.one;
            handleSlideRt.offsetMin = fillAreaRt.offsetMin + new Vector2(6, -8);
            handleSlideRt.offsetMax = fillAreaRt.offsetMax + new Vector2(-6, 8);
            var handle = new GameObject("Handle", typeof(RectTransform));
            handle.transform.SetParent(handleSlide.transform, false);
            var handleImg = handle.AddComponent<Image>();
            handleImg.color = Color.white;
            handleImg.raycastTarget = false;
            var handleRt = RequireRectTransform(handle);
            handleRt.anchorMin = Vector2.zero;
            handleRt.anchorMax = Vector2.one;
            handleRt.offsetMin = Vector2.zero;
            handleRt.offsetMax = Vector2.zero;
            handleRt.sizeDelta = new Vector2(12, 0);
            slider.handleRect = handleRt;
            slider.targetGraphic = handleImg;

            // Set value AFTER fill/handle are wired so the first UpdateVisuals lays them out correctly.
            slider.SetValueWithoutNotify(Mathf.InverseLerp(min, max, initial));

            slider.onValueChanged.AddListener(t =>
            {
                float v = Mathf.Lerp(min, max, t);
                apply(v);
                valueText.text = FormatValue(v);
                PushTiltShift();
            });

            m_SliderBindings.Add(new SliderBinding
            {
                slider = slider,
                apply = apply,
                min = min,
                max = max,
                trackImage = trackImg,
                fillImage = fillImg,
                handleImage = handleImg,
                hitImage = bg
            });
        }

        Toggle AddToggle(Transform parent, string label, bool initial, System.Action<bool> onChanged)
        {
            var row = new GameObject("Row_" + label, typeof(RectTransform));
            row.transform.SetParent(parent, false);
            var rowLe = row.AddComponent<LayoutElement>();
            rowLe.preferredHeight = 34f;

            var labelGo = new GameObject("Label", typeof(RectTransform));
            labelGo.transform.SetParent(row.transform, false);
            var labelText = labelGo.AddComponent<Text>();
            SetupUiText(labelText, label, 14);
            AnchorInRow(labelGo, 0.02f, 0.80f, 4f);

            var toggleGo = new GameObject("Toggle", typeof(RectTransform));
            toggleGo.transform.SetParent(row.transform, false);
            var toggleRt = AnchorInRow(toggleGo, 0.84f, 0.99f, 6f);
            var toggleBg = toggleGo.AddComponent<Image>();
            toggleBg.color = new Color(0.25f, 0.28f, 0.35f);
            var toggle = toggleGo.AddComponent<Toggle>();
            toggle.isOn = initial;

            var check = new GameObject("Check", typeof(RectTransform));
            check.transform.SetParent(toggleGo.transform, false);
            var checkImg = check.AddComponent<Image>();
            checkImg.color = new Color(0.4f, 0.85f, 0.5f);
            var checkRt = RequireRectTransform(check);
            checkRt.anchorMin = Vector2.zero;
            checkRt.anchorMax = Vector2.one;
            checkRt.offsetMin = new Vector2(4, 4);
            checkRt.offsetMax = new Vector2(-4, -4);
            toggle.graphic = checkImg;
            toggle.targetGraphic = toggleBg;

            toggle.onValueChanged.AddListener(v => onChanged(v));
            return toggle;
        }

        static string FormatValue(float v)
        {
            if (Mathf.Abs(v) >= 10f)
                return v.ToString("F1");
            if (Mathf.Abs(v) >= 1f)
                return v.ToString("F2");
            return v.ToString("F3");
        }

#if UNITY_EDITOR
        [UnityEditor.MenuItem("SplatBox/VR/Add Settings Menu To Main Camera")]
        static void MenuAddToMainCamera()
        {
            var cam = Camera.main ?? Object.FindAnyObjectByType<Camera>();
            if (cam == null)
            {
                Debug.LogWarning("[SplatBox] No camera found to attach VR settings menu.");
                return;
            }

            if (cam.GetComponent<SplatBoxVRSettingsMenu>() != null)
            {
                Debug.Log("[SplatBox] VR settings menu already on " + cam.name);
                return;
            }

            UnityEditor.Undo.AddComponent<SplatBoxVRSettingsMenu>(cam.gameObject);
            Debug.Log("[SplatBox] Added SplatBoxVRSettingsMenu to " + cam.name + ". Press A (right controller) to toggle in VR.");
        }
#endif
    }
}
