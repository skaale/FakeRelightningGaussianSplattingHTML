// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public enum PrimitiveBrushType
    {
        Cylinder = 0,
        Box = 1,
        Sphere = 2
    }
    
    public class GaussianSplatCylinderBrush : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] private PrimitiveBrushType m_PrimitiveType = PrimitiveBrushType.Cylinder;
        
        [Header("Cylinder Settings")]
        [SerializeField] private float m_Radius = 0.5f;
        [SerializeField] private float m_Height = 1f;
        [SerializeField] private Vector3 m_Position = Vector3.zero;
        [SerializeField] private Quaternion m_Rotation = Quaternion.identity;
        
        [Header("Box Settings")]
        [SerializeField] private Vector3 m_BoxSize = new Vector3(1f, 1f, 1f);
        
        [Header("Sphere Settings")]
        [SerializeField] private float m_SphereRadius = 0.5f;
        
        [Header("Visualization")]
        [SerializeField] private Color m_CylinderColor = new Color(0.8f, 0.3f, 1f, 1f);
        [SerializeField] [Range(0.05f, 0.5f)] private float m_CylinderAlpha = 0.15f;
        [SerializeField] [Range(8, 32)] private int m_CircleSegments = 16;
        
        public float Radius
        {
            get => m_Radius;
            set => m_Radius = Mathf.Max(0.01f, value);
        }
        
        public float Height
        {
            get => m_Height;
            set => m_Height = Mathf.Max(0.01f, value);
        }
        
        public Vector3 Position
        {
            get => m_Position;
            set => m_Position = value;
        }
        
        public Quaternion Rotation
        {
            get => m_Rotation;
            set => m_Rotation = value;
        }
        
        public Color CylinderColor
        {
            get => m_CylinderColor;
            set => m_CylinderColor = value;
        }
        
        public float CylinderAlpha
        {
            get => m_CylinderAlpha;
            set => m_CylinderAlpha = Mathf.Clamp(value, 0.05f, 0.5f);
        }
        
        public int CircleSegments
        {
            get => m_CircleSegments;
            set => m_CircleSegments = Mathf.Clamp(value, 8, 32);
        }
        
        public PrimitiveBrushType PrimitiveType
        {
            get => m_PrimitiveType;
            set => m_PrimitiveType = value;
        }
        
        public Vector3 BoxSize
        {
            get => m_BoxSize;
            set => m_BoxSize = new Vector3(
                Mathf.Max(0.01f, value.x),
                Mathf.Max(0.01f, value.y),
                Mathf.Max(0.01f, value.z));
        }
        
        public float SphereRadius
        {
            get => m_SphereRadius;
            set => m_SphereRadius = Mathf.Max(0.01f, value);
        }
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public static bool IsBrushModeActive { get; set; } = false;
        public static Vector3 LastBrushPosition { get; set; }
        public static bool HasValidBrushPosition { get; set; } = false;
        
        // Axis direction (up vector after rotation)
        public Vector3 AxisDirection => m_Rotation * Vector3.up;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        public void DeleteSplatsInCylinder()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("CylinderBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.DeleteSplatsInCylinderBounded(m_Position, m_Radius, m_Height, AxisDirection);
        }
        
        public void RestoreSplatsInCylinder()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("CylinderBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.RestoreSplatsInCylinderBounded(m_Position, m_Radius, m_Height, AxisDirection);
        }
        
        public void DeleteSplatsInBox()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("CylinderBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.DeleteSplatsInBox(m_Position, m_BoxSize, m_Rotation);
        }
        
        public void RestoreSplatsInBox()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("CylinderBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.RestoreSplatsInBox(m_Position, m_BoxSize, m_Rotation);
        }
        
        public void DeleteSplatsInSphere()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("CylinderBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.DeleteSplatsInSphere(m_Position, m_SphereRadius);
        }
        
        public void RestoreSplatsInSphere()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("CylinderBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.RestoreSplatsInSphere(m_Position, m_SphereRadius);
        }
        
        public void DeleteCurrentPrimitive()
        {
            if (m_PrimitiveType == PrimitiveBrushType.Cylinder)
                DeleteSplatsInCylinder();
            else if (m_PrimitiveType == PrimitiveBrushType.Box)
                DeleteSplatsInBox();
            else
                DeleteSplatsInSphere();
        }
        
        public void RestoreCurrentPrimitive()
        {
            if (m_PrimitiveType == PrimitiveBrushType.Cylinder)
                RestoreSplatsInCylinder();
            else if (m_PrimitiveType == PrimitiveBrushType.Box)
                RestoreSplatsInBox();
            else
                RestoreSplatsInSphere();
        }
        
        public void ResetCylinder()
        {
            m_Radius = 0.5f;
            m_Height = 1f;
            m_Position = Vector3.zero;
            m_Rotation = Quaternion.identity;
        }
        
        public void ResetBox()
        {
            m_BoxSize = Vector3.one;
            m_Position = Vector3.zero;
            m_Rotation = Quaternion.identity;
        }
        
        public void ResetSphere()
        {
            m_SphereRadius = 0.5f;
            m_Position = Vector3.zero;
        }
        
        public void ResetCurrentPrimitive()
        {
            if (m_PrimitiveType == PrimitiveBrushType.Cylinder)
                ResetCylinder();
            else if (m_PrimitiveType == PrimitiveBrushType.Box)
                ResetBox();
            else
                ResetSphere();
        }
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                               m_TargetRenderer.HasValidRenderSetup;

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (IsBrushModeActive || !UnityEditor.Selection.Contains(gameObject))
                return;
            
            DrawCylinderGizmo();
        }
        
        private void OnDrawGizmosSelected()
        {
            DrawCylinderGizmo();
        }
        
        private void DrawCylinderGizmo()
        {
            Gizmos.color = new Color(m_CylinderColor.r, m_CylinderColor.g, m_CylinderColor.b, 0.3f);
            
            Vector3 up = AxisDirection;
            Vector3 halfHeight = up * (m_Height * 0.5f);
            Vector3 topCenter = m_Position + halfHeight;
            Vector3 bottomCenter = m_Position - halfHeight;
            
            // Draw wire circles
            DrawWireCircle(topCenter, up, m_Radius);
            DrawWireCircle(bottomCenter, up, m_Radius);
            
            // Draw connecting lines
            Vector3 right = GetPerpendicular(up) * m_Radius;
            Vector3 forward = Vector3.Cross(up, right).normalized * m_Radius;
            
            Gizmos.DrawLine(topCenter + right, bottomCenter + right);
            Gizmos.DrawLine(topCenter - right, bottomCenter - right);
            Gizmos.DrawLine(topCenter + forward, bottomCenter + forward);
            Gizmos.DrawLine(topCenter - forward, bottomCenter - forward);
        }
        
        private void DrawWireCircle(Vector3 center, Vector3 normal, float radius)
        {
            Vector3 right = GetPerpendicular(normal);
            Vector3 forward = Vector3.Cross(normal, right);
            
            Vector3 prevPoint = center + right * radius;
            for (int i = 1; i <= m_CircleSegments; i++)
            {
                float angle = (i / (float)m_CircleSegments) * Mathf.PI * 2f;
                Vector3 point = center + (right * Mathf.Cos(angle) + forward * Mathf.Sin(angle)) * radius;
                Gizmos.DrawLine(prevPoint, point);
                prevPoint = point;
            }
        }
        
        private Vector3 GetPerpendicular(Vector3 v)
        {
            if (Mathf.Abs(v.x) < 0.9f)
                return Vector3.Cross(v, Vector3.right).normalized;
            return Vector3.Cross(v, Vector3.up).normalized;
        }
#endif
    }
}

