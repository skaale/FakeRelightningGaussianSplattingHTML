// SPDX-License-Identifier: MIT

using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatColorBrush : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] private Vector3 m_BoxSize = new Vector3(1f, 1f, 1f);
        [SerializeField] private Vector3 m_BoxPosition = Vector3.zero;
        
        [Header("Color Adjustments")]
        [SerializeField] private ColorAdjustments m_ColorAdjustments = ColorAdjustments.Default;
        
        public Vector3 BoxSize
        {
            get => m_BoxSize;
            set => m_BoxSize = new Vector3(
                Mathf.Max(0.01f, value.x),
                Mathf.Max(0.01f, value.y),
                Mathf.Max(0.01f, value.z));
        }
        
        public Vector3 BoxPosition
        {
            get => m_BoxPosition;
            set => m_BoxPosition = value;
        }
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public ColorAdjustments ColorAdjust
        {
            get => m_ColorAdjustments;
            set => m_ColorAdjustments = value;
        }
        
        public static bool IsBrushModeActive { get; set; } = false;
        public static Vector3 LastBrushPosition { get; set; }
        public static bool HasValidBrushPosition { get; set; } = false;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        /// <summary>
        /// Apply color adjustments to splats inside the box (GPU accelerated)
        /// </summary>
        public void ApplyColorAdjustments()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("ColorBrush: Invalid renderer state");
                return;
            }
            
            if (!m_ColorAdjustments.HasAdjustments)
            {
                Debug.LogWarning("ColorBrush: No color adjustments to apply");
                return;
            }
            
            m_TargetRenderer.AdjustColorsInBox(m_BoxPosition, m_BoxSize, m_ColorAdjustments);
        }
        
        public void ResetBox()
        {
            m_BoxSize = Vector3.one;
            m_BoxPosition = Vector3.zero;
        }
        
        public void ResetColorAdjustments()
        {
            m_ColorAdjustments = ColorAdjustments.Default;
        }
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                               m_TargetRenderer.HasValidRenderSetup;
        
        public bool HasAdjustments => m_ColorAdjustments.HasAdjustments;

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (IsBrushModeActive || !UnityEditor.Selection.Contains(gameObject))
                return;
            
            DrawBoxGizmo();
        }
        
        private void OnDrawGizmosSelected()
        {
            DrawBoxGizmo();
        }
        
        private void DrawBoxGizmo()
        {
            // Current box - use magenta/purple for color tool
            Gizmos.color = new Color(0.8f, 0.3f, 0.9f, 0.3f);
            Gizmos.DrawCube(m_BoxPosition, m_BoxSize);
            
            Gizmos.color = new Color(0.8f, 0.3f, 0.9f, 0.9f);
            Gizmos.DrawWireCube(m_BoxPosition, m_BoxSize);
        }
#endif
    }
}

