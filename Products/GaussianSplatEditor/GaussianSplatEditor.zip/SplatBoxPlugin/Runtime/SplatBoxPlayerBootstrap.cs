using System.Collections;
using GaussianSplatting.Runtime;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Re-binds SplatBoxRenderer on device when shader refs or render registration were lost during the Android/Quest build.
    /// The Splat Editor window reference is editor-only and is NOT saved with the scene.
    /// </summary>
    public static class SplatBoxPlayerBootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void ScheduleBootstrap()
        {
#if UNITY_EDITOR
            return;
#else
            var go = new GameObject("SplatBoxPlayerBootstrap") { hideFlags = HideFlags.HideAndDontSave };
            go.AddComponent<Runner>();
#endif
        }

        sealed class Runner : MonoBehaviour
        {
            IEnumerator Start()
            {
                yield return null;
                yield return null;

                BootstrapAllRenderers();

                if (GraphicsSettings.currentRenderPipeline != null && !GaussianSplatRenderSystem.URPFeatureExecuted)
                {
                    Debug.LogWarning(
                        "[SplatBox] Gaussian Splat URP Feature did not run after bootstrap. " +
                        "Splats will not draw. Add the feature to your Android/XR URP Renderer (SplatBox > Setup URP Renderer Features).");
                }

                Destroy(gameObject);
            }
        }

        public static void BootstrapAllRenderers()
        {
#if UNITY_EDITOR
            return;
#else
#if UNITY_2022_2_OR_NEWER
            var renderers = Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsInactive.Include);
#else
            var renderers = Object.FindObjectsOfType<SplatBoxRenderer>(true);
#endif
            if (renderers == null || renderers.Length == 0)
            {
                Debug.LogWarning("[SplatBox] No SplatBoxRenderer found in loaded scenes.");
                return;
            }

            for (int i = 0; i < renderers.Length; i++)
            {
                if (renderers[i] != null && renderers[i].isActiveAndEnabled)
                    renderers[i].EnsurePlayerRenderReady();
            }
#endif
        }
    }
}
