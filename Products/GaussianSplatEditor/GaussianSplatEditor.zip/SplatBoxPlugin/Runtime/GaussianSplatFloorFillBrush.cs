// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Floor fill brush for Gaussian splats.
    /// Draw a 2D area on the floor and fill holes by sampling from edges.
    /// </summary>
    public class GaussianSplatFloorFillBrush : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        
        [Header("Fill Region")]
        [SerializeField] private Vector3 m_FillCenter = Vector3.zero;
        [SerializeField] private Vector2 m_FillSize = new Vector2(2f, 2f);
        [SerializeField] private float m_FloorY = 0f;
        [SerializeField] private float m_FloorThickness = 0.3f;
        
        [Header("Sample Settings")]
        [SerializeField] private float m_SampleEdgeWidth = 0.5f;
        [SerializeField] private SampleMode m_SampleMode = SampleMode.AllEdges;
        
        [Header("Fill Settings")]
        [SerializeField] private Vector2 m_TileSize = new Vector2(0.5f, 0.5f);
        [SerializeField] [Range(0f, 0.3f)] private float m_PositionJitter = 0.05f;
        [SerializeField] private bool m_RandomizeTileSelection = true;
        [SerializeField] private bool m_DeleteBeforeFill = true;
        
        public enum SampleMode
        {
            AllEdges,
            NorthSouth,
            EastWest,
            NorthOnly,
            SouthOnly,
            EastOnly,
            WestOnly,
            Custom
        }
        
        // Drawing state
        private List<Vector3> m_DrawPoints = new List<Vector3>();
        private bool m_IsDrawing = false;
        
        // Cached sample regions
        private List<Bounds> m_SampleRegions = new List<Bounds>();
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public Vector3 FillCenter { get => m_FillCenter; set => m_FillCenter = value; }
        public Vector2 FillSize { get => m_FillSize; set => m_FillSize = value; }
        public float FloorY { get => m_FloorY; set => m_FloorY = value; }
        public float FloorThickness { get => m_FloorThickness; set => m_FloorThickness = Mathf.Max(0.01f, value); }
        public float SampleEdgeWidth { get => m_SampleEdgeWidth; set => m_SampleEdgeWidth = Mathf.Max(0.1f, value); }
        public SampleMode CurrentSampleMode { get => m_SampleMode; set => m_SampleMode = value; }
        public Vector2 TileSize { get => m_TileSize; set => m_TileSize = new Vector2(Mathf.Max(0.1f, value.x), Mathf.Max(0.1f, value.y)); }
        public float PositionJitter { get => m_PositionJitter; set => m_PositionJitter = Mathf.Clamp01(value); }
        public bool RandomizeTileSelection { get => m_RandomizeTileSelection; set => m_RandomizeTileSelection = value; }
        public bool DeleteBeforeFill { get => m_DeleteBeforeFill; set => m_DeleteBeforeFill = value; }
        
        public List<Vector3> DrawPoints => m_DrawPoints;
        public bool IsDrawing => m_IsDrawing;
        public List<Bounds> SampleRegions => m_SampleRegions;
        
        public static bool IsBrushModeActive { get; set; } = false;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        public void StartDrawing(Vector3 startPoint)
        {
            m_DrawPoints.Clear();
            m_DrawPoints.Add(startPoint);
            m_IsDrawing = true;
            m_FloorY = startPoint.y;
        }
        
        public void AddDrawPoint(Vector3 point)
        {
            if (!m_IsDrawing) return;
            
            point.y = m_FloorY;
            
            if (m_DrawPoints.Count == 0 || Vector3.Distance(m_DrawPoints[m_DrawPoints.Count - 1], point) > 0.1f)
            {
                m_DrawPoints.Add(point);
            }
        }
        
        public void FinishDrawing()
        {
            if (!m_IsDrawing || m_DrawPoints.Count < 3) 
            {
                m_IsDrawing = false;
                m_DrawPoints.Clear();
                return;
            }
            
            m_IsDrawing = false;
            CalculateFillRegionFromPoints();
            UpdateSampleRegions();
        }
        
        public void CancelDrawing()
        {
            m_IsDrawing = false;
            m_DrawPoints.Clear();
        }
        
        private void CalculateFillRegionFromPoints()
        {
            if (m_DrawPoints.Count < 3) return;
            
            float minX = float.MaxValue, maxX = float.MinValue;
            float minZ = float.MaxValue, maxZ = float.MinValue;
            
            foreach (var pt in m_DrawPoints)
            {
                minX = Mathf.Min(minX, pt.x);
                maxX = Mathf.Max(maxX, pt.x);
                minZ = Mathf.Min(minZ, pt.z);
                maxZ = Mathf.Max(maxZ, pt.z);
            }
            
            m_FillCenter = new Vector3((minX + maxX) * 0.5f, m_FloorY, (minZ + maxZ) * 0.5f);
            m_FillSize = new Vector2(maxX - minX, maxZ - minZ);
        }
        
        public void SetFillRegion(Vector3 center, Vector2 size)
        {
            m_FillCenter = center;
            m_FillSize = size;
            m_FloorY = center.y;
            UpdateSampleRegions();
        }
        
        public void UpdateSampleRegions()
        {
            m_SampleRegions.Clear();
            
            float halfX = m_FillSize.x * 0.5f;
            float halfZ = m_FillSize.y * 0.5f;
            float edgeW = m_SampleEdgeWidth;
            float halfThick = m_FloorThickness * 0.5f;
            
            switch (m_SampleMode)
            {
                case SampleMode.AllEdges:
                    // North edge (positive Z)
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(0, 0, halfZ + edgeW * 0.5f),
                        new Vector3(m_FillSize.x, m_FloorThickness, edgeW)));
                    // South edge (negative Z)
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(0, 0, -halfZ - edgeW * 0.5f),
                        new Vector3(m_FillSize.x, m_FloorThickness, edgeW)));
                    // East edge (positive X)
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(halfX + edgeW * 0.5f, 0, 0),
                        new Vector3(edgeW, m_FloorThickness, m_FillSize.y)));
                    // West edge (negative X)
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(-halfX - edgeW * 0.5f, 0, 0),
                        new Vector3(edgeW, m_FloorThickness, m_FillSize.y)));
                    break;
                    
                case SampleMode.NorthSouth:
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(0, 0, halfZ + edgeW * 0.5f),
                        new Vector3(m_FillSize.x, m_FloorThickness, edgeW)));
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(0, 0, -halfZ - edgeW * 0.5f),
                        new Vector3(m_FillSize.x, m_FloorThickness, edgeW)));
                    break;
                    
                case SampleMode.EastWest:
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(halfX + edgeW * 0.5f, 0, 0),
                        new Vector3(edgeW, m_FloorThickness, m_FillSize.y)));
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(-halfX - edgeW * 0.5f, 0, 0),
                        new Vector3(edgeW, m_FloorThickness, m_FillSize.y)));
                    break;
                    
                case SampleMode.NorthOnly:
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(0, 0, halfZ + edgeW * 0.5f),
                        new Vector3(m_FillSize.x, m_FloorThickness, edgeW)));
                    break;
                    
                case SampleMode.SouthOnly:
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(0, 0, -halfZ - edgeW * 0.5f),
                        new Vector3(m_FillSize.x, m_FloorThickness, edgeW)));
                    break;
                    
                case SampleMode.EastOnly:
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(halfX + edgeW * 0.5f, 0, 0),
                        new Vector3(edgeW, m_FloorThickness, m_FillSize.y)));
                    break;
                    
                case SampleMode.WestOnly:
                    m_SampleRegions.Add(new Bounds(
                        m_FillCenter + new Vector3(-halfX - edgeW * 0.5f, 0, 0),
                        new Vector3(edgeW, m_FloorThickness, m_FillSize.y)));
                    break;
            }
        }
        
        public void AddCustomSampleRegion(Vector3 center, Vector3 size)
        {
            m_SampleMode = SampleMode.Custom;
            m_SampleRegions.Add(new Bounds(center, size));
        }
        
        public void ClearCustomSampleRegions()
        {
            m_SampleRegions.Clear();
        }
        
        public Bounds GetFillBounds()
        {
            return new Bounds(m_FillCenter, new Vector3(m_FillSize.x, m_FloorThickness, m_FillSize.y));
        }
        
        public List<Vector3> GetFillGridPositions()
        {
            var positions = new List<Vector3>();
            
            float halfX = m_FillSize.x * 0.5f;
            float halfZ = m_FillSize.y * 0.5f;
            
            int tilesX = Mathf.CeilToInt(m_FillSize.x / m_TileSize.x);
            int tilesZ = Mathf.CeilToInt(m_FillSize.y / m_TileSize.y);
            
            for (int x = 0; x < tilesX; x++)
            {
                for (int z = 0; z < tilesZ; z++)
                {
                    float posX = m_FillCenter.x - halfX + (x + 0.5f) * m_TileSize.x;
                    float posZ = m_FillCenter.z - halfZ + (z + 0.5f) * m_TileSize.y;
                    
                    positions.Add(new Vector3(posX, m_FloorY, posZ));
                }
            }
            
            return positions;
        }
        
        public void ExecuteFill()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                Debug.LogWarning("FloorFill: No valid renderer");
                return;
            }
            
            if (m_SampleRegions.Count == 0)
            {
                Debug.LogWarning("FloorFill: No sample regions defined");
                UpdateSampleRegions();
                if (m_SampleRegions.Count == 0) return;
            }
            
            // Delete splats in fill region first
            if (m_DeleteBeforeFill)
            {
                var fillBounds = GetFillBounds();
                m_TargetRenderer.DeleteSplatsInBox(fillBounds.center, fillBounds.size);
            }
            
            // Calculate grid
            float halfX = m_FillSize.x * 0.5f;
            float halfZ = m_FillSize.y * 0.5f;
            
            int tilesX = Mathf.CeilToInt(m_FillSize.x / m_TileSize.x);
            int tilesZ = Mathf.CeilToInt(m_FillSize.y / m_TileSize.y);
            
            int placedCount = 0;
            
            for (int x = 0; x < tilesX; x++)
            {
                for (int z = 0; z < tilesZ; z++)
                {
                    float posX = m_FillCenter.x - halfX + (x + 0.5f) * m_TileSize.x;
                    float posZ = m_FillCenter.z - halfZ + (z + 0.5f) * m_TileSize.y;
                    
                    // Add jitter
                    if (m_PositionJitter > 0)
                    {
                        posX += Random.Range(-m_PositionJitter, m_PositionJitter) * m_TileSize.x;
                        posZ += Random.Range(-m_PositionJitter, m_PositionJitter) * m_TileSize.y;
                    }
                    
                    Vector3 targetPos = new Vector3(posX, m_FloorY, posZ);
                    
                    // Select sample region
                    int regionIdx = m_RandomizeTileSelection 
                        ? Random.Range(0, m_SampleRegions.Count) 
                        : placedCount % m_SampleRegions.Count;
                    
                    var sampleBounds = m_SampleRegions[regionIdx];
                    
                    // Clone from sample region to target position
                    m_TargetRenderer.CloneSplatsInBox(
                        sampleBounds.center,
                        targetPos,
                        new Vector3(m_TileSize.x, m_FloorThickness, m_TileSize.y));
                    
                    placedCount++;
                }
            }
            
            Debug.Log($"FloorFill: Placed {placedCount} tiles");
        }
        
        public void DeleteFillRegion()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                Debug.LogWarning("FloorFill: No valid renderer");
                return;
            }
            
            var fillBounds = GetFillBounds();
            m_TargetRenderer.DeleteSplatsInBox(fillBounds.center, fillBounds.size);
        }
        
        public void Reset()
        {
            m_DrawPoints.Clear();
            m_IsDrawing = false;
            m_FillCenter = Vector3.zero;
            m_FillSize = new Vector2(2f, 2f);
            m_SampleRegions.Clear();
        }
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                               m_TargetRenderer.HasValidRenderSetup;

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (IsBrushModeActive) return;
            
            DrawGizmos();
        }
        
        private void DrawGizmos()
        {
            // Draw fill region
            Gizmos.color = new Color(1f, 0.5f, 0f, 0.3f);
            Gizmos.DrawCube(m_FillCenter, new Vector3(m_FillSize.x, m_FloorThickness, m_FillSize.y));
            Gizmos.color = new Color(1f, 0.5f, 0f, 0.9f);
            Gizmos.DrawWireCube(m_FillCenter, new Vector3(m_FillSize.x, m_FloorThickness, m_FillSize.y));
            
            // Draw sample regions
            foreach (var bounds in m_SampleRegions)
            {
                Gizmos.color = new Color(0f, 1f, 0.5f, 0.3f);
                Gizmos.DrawCube(bounds.center, bounds.size);
                Gizmos.color = new Color(0f, 1f, 0.5f, 0.9f);
                Gizmos.DrawWireCube(bounds.center, bounds.size);
            }
            
            // Draw drawing path
            if (m_DrawPoints.Count > 1)
            {
                Gizmos.color = Color.yellow;
                for (int i = 0; i < m_DrawPoints.Count - 1; i++)
                {
                    Gizmos.DrawLine(m_DrawPoints[i], m_DrawPoints[i + 1]);
                }
                if (m_DrawPoints.Count > 2)
                {
                    Gizmos.DrawLine(m_DrawPoints[m_DrawPoints.Count - 1], m_DrawPoints[0]);
                }
            }
        }
#endif
    }
}

