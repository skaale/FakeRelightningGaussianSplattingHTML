// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// VR radial property bindings aligned with <see cref="GaussianSplatting.Editor.GaussianSplatEditorWindow"/> tool settings.
    /// </summary>
    public static class SplatBoxVRBrushToolSettings
    {
        public enum PropertyKind
        {
            Float,
            Int,
            Bool
        }

        public sealed class PropertyDef
        {
            public string label;
            public string shortLabel;
            public PropertyKind kind;
            public float min;
            public float max;
            public float step;
            public Func<SplatBoxVREraseBrush, float> getFloat;
            public Action<SplatBoxVREraseBrush, float> setFloat;
            public Func<SplatBoxVREraseBrush, int> getInt;
            public Action<SplatBoxVREraseBrush, int> setInt;
            public Func<SplatBoxVREraseBrush, bool> getBool;
            public Action<SplatBoxVREraseBrush, bool> setBool;

            public string Format(SplatBoxVREraseBrush host)
            {
                if (host == null)
                    return "-";
                switch (kind)
                {
                    case PropertyKind.Bool:
                        return getBool(host) ? "On" : "Off";
                    case PropertyKind.Int:
                        return getInt(host).ToString();
                    default:
                        float v = getFloat(host);
                        float range = Mathf.Max(max - min, 0.0001f);
                        if (range <= 1.01f && min >= 0f)
                            return v.ToString("0.##");
                        if (Mathf.Abs(max) <= 180f && Mathf.Abs(min) <= 180f && (label.Contains("Hue") || label.Contains("Shift")))
                            return $"{v:0}°";
                        return v.ToString("0.##");
                }
            }

            public void Adjust(SplatBoxVREraseBrush host, float direction)
            {
                if (host == null || Mathf.Abs(direction) < 1e-5f)
                    return;

                switch (kind)
                {
                    case PropertyKind.Bool:
                        if (direction > 0f)
                            setBool(host, true);
                        else if (direction < 0f)
                            setBool(host, false);
                        break;
                    case PropertyKind.Int:
                    {
                        int v = getInt(host);
                        int next = v + (int)Mathf.Sign(direction);
                        setInt(host, next);
                        break;
                    }
                    default:
                    {
                        float span = max - min;
                        float delta = direction * (step > 0f ? step : span * 0.04f);
                        setFloat(host, Mathf.Clamp(getFloat(host) + delta, min, max));
                        break;
                    }
                }
            }
        }

        static readonly Dictionary<SplatBoxVRBrushTool, PropertyDef[]> s_ToolProperties = BuildToolProperties();

        public static IReadOnlyList<PropertyDef> GetProperties(SplatBoxVRBrushTool tool)
        {
            return s_ToolProperties.TryGetValue(tool, out var list) ? list : Array.Empty<PropertyDef>();
        }

        public static bool HasProperties(SplatBoxVRBrushTool tool) => GetProperties(tool).Count > 0;

        static Dictionary<SplatBoxVRBrushTool, PropertyDef[]> BuildToolProperties()
        {
            var map = new Dictionary<SplatBoxVRBrushTool, PropertyDef[]>();

            map[SplatBoxVRBrushTool.EraseBrush] = new[]
            {
                Float("Screen Radius", "Rad", 0.1f, 50f, 0.25f,
                    h => h.EraseBrush != null ? h.EraseBrush.ScreenRadius : h.m_DefaultScreenRadius,
                    (h, v) => { if (h.EraseBrush != null) h.EraseBrush.ScreenRadius = v; }),
                Float("Falloff", "Fall", 0f, 1f, 0.05f,
                    h => h.EraseBrush != null ? h.EraseBrush.BrushFalloff : 0f,
                    (h, v) => { if (h.EraseBrush != null) h.EraseBrush.BrushFalloff = v; }),
                Float("Noise Strength", "Nse", 0f, 1f, 0.05f,
                    h => h.EraseBrush != null ? h.EraseBrush.NoiseStrength : 0f,
                    (h, v) => { if (h.EraseBrush != null) h.EraseBrush.NoiseStrength = v; }),
                Float("Noise Scale", "NSc", 0.1f, 10f, 0.2f,
                    h => h.EraseBrush != null ? h.EraseBrush.NoiseScale : 1f,
                    (h, v) => { if (h.EraseBrush != null) h.EraseBrush.NoiseScale = v; }),
                Bool("Backface Cull", "BkF",
                    h => h.EraseBackfaceCulling,
                    (h, v) => h.EraseBackfaceCulling = v),
            };

            map[SplatBoxVRBrushTool.PaintBrush] = new[]
            {
                Float("Brush Radius", "Rad", 0.1f, 10f, 0.15f,
                    h => h.PaintBrush != null ? h.PaintBrush.ScreenRadius : 1.5f,
                    (h, v) => { if (h.PaintBrush != null) h.PaintBrush.ScreenRadius = v; }),
                Float("Splat Size %", "Sz%", 0.01f, 1f, 0.03f,
                    h => h.PaintBrush != null ? h.PaintBrush.SplatSizeMultiplier : 0.1f,
                    (h, v) => { if (h.PaintBrush != null) h.PaintBrush.SplatSizeMultiplier = v; }),
                Int("Splats/Stroke", "Spl", 1, 50, 1,
                    h => h.PaintBrush != null ? h.PaintBrush.SplatsPerStroke : 5,
                    (h, v) => { if (h.PaintBrush != null) h.PaintBrush.SplatsPerStroke = v; }),
                Float("Density", "Dns", 0.1f, 2f, 0.05f,
                    h => h.PaintBrush != null ? h.PaintBrush.PaintDensity : 1f,
                    (h, v) => { if (h.PaintBrush != null) h.PaintBrush.PaintDensity = v; }),
            };

            map[SplatBoxVRBrushTool.ColorizeBrush] = new[]
            {
                Float("Brush Radius", "Rad", 0.1f, 10f, 0.15f,
                    h => h.ColorizeBrush != null ? h.ColorizeBrush.ScreenRadius : 1.5f,
                    (h, v) => { if (h.ColorizeBrush != null) h.ColorizeBrush.ScreenRadius = v; }),
                Float("Blend Strength", "Bld", 0f, 1f, 0.05f,
                    h => h.ColorizeBrush != null ? h.ColorizeBrush.BlendStrength : 0.5f,
                    (h, v) => { if (h.ColorizeBrush != null) h.ColorizeBrush.BlendStrength = v; }),
                Float("Falloff", "Fall", 0f, 1f, 0.05f,
                    h => h.ColorizeBrush != null ? h.ColorizeBrush.Falloff : 0.5f,
                    (h, v) => { if (h.ColorizeBrush != null) h.ColorizeBrush.Falloff = v; }),
                Float("Noise Strength", "Nse", 0f, 1f, 0.05f,
                    h => h.ColorizeBrush != null ? h.ColorizeBrush.NoiseStrength : 0f,
                    (h, v) => { if (h.ColorizeBrush != null) h.ColorizeBrush.NoiseStrength = v; }),
            };

            map[SplatBoxVRBrushTool.CloneBrush] = new[]
            {
                Float("Clone Offset", "Off", 0.02f, 1f, 0.02f,
                    h => h.CloneOffset,
                    (h, v) => h.CloneOffset = v),
            };

            map[SplatBoxVRBrushTool.ColorBrush] = new[]
            {
                Float("Exposure", "Exp", -2f, 5f, 0.1f,
                    h => h.ColorBrush != null ? h.ColorBrush.ColorAdjust.exposure : 0f,
                    (h, v) => SetColorAdjust(h, a => a.exposure = v)),
                Float("Contrast", "Ctr", 0f, 2f, 0.05f,
                    h => h.ColorBrush != null ? h.ColorBrush.ColorAdjust.contrast : 1f,
                    (h, v) => SetColorAdjust(h, a => a.contrast = v)),
                Float("Hue Shift", "Hue", -180f, 180f, 5f,
                    h => h.ColorBrush != null ? h.ColorBrush.ColorAdjust.hueShift : 0f,
                    (h, v) => SetColorAdjust(h, a => a.hueShift = v)),
                Float("Saturation", "Sat", 0f, 2f, 0.05f,
                    h => h.ColorBrush != null ? h.ColorBrush.ColorAdjust.saturation : 1f,
                    (h, v) => SetColorAdjust(h, a => a.saturation = v)),
            };

            map[SplatBoxVRBrushTool.VortexTool] = new[]
            {
                Float("Strength", "Str", 0.001f, 0.5f, 0.01f,
                    h => h.VortexAttractor != null ? h.VortexAttractor.Strength : 0.02f,
                    (h, v) => { if (h.VortexAttractor != null) h.VortexAttractor.Strength = v; }),
                Float("Range", "Rng", 0.1f, 20f, 0.25f,
                    h => h.VortexAttractor != null ? h.VortexAttractor.Range : 2f,
                    (h, v) => { if (h.VortexAttractor != null) h.VortexAttractor.Range = v; }),
                Float("Falloff", "Fall", 0.1f, 3f, 0.1f,
                    h => h.VortexAttractor != null ? h.VortexAttractor.Falloff : 1f,
                    (h, v) => { if (h.VortexAttractor != null) h.VortexAttractor.Falloff = v; }),
                Float("Scale", "Scl", 0.1f, 10f, 0.15f,
                    h => h.VortexAttractor != null ? h.VortexAttractor.Scale : 1f,
                    (h, v) => { if (h.VortexAttractor != null) h.VortexAttractor.Scale = v; }),
            };

            return map;
        }

        static void SetColorAdjust(SplatBoxVREraseBrush host, Action<ColorAdjustments> mutate)
        {
            if (host?.ColorBrush == null)
                return;
            var adj = host.ColorBrush.ColorAdjust;
            mutate(adj);
            host.ColorBrush.ColorAdjust = adj;
            if (host.ColorBrush.HasAdjustments && host.ColorBrush.IsValid)
                host.ColorBrush.ApplyColorAdjustments();
        }

        static PropertyDef Float(string label, string shortLabel, float min, float max, float step,
            Func<SplatBoxVREraseBrush, float> get, Action<SplatBoxVREraseBrush, float> set)
        {
            return new PropertyDef
            {
                label = label,
                shortLabel = shortLabel,
                kind = PropertyKind.Float,
                min = min,
                max = max,
                step = step,
                getFloat = get,
                setFloat = set
            };
        }

        static PropertyDef Int(string label, string shortLabel, int min, int max, int step,
            Func<SplatBoxVREraseBrush, int> get, Action<SplatBoxVREraseBrush, int> set)
        {
            return new PropertyDef
            {
                label = label,
                shortLabel = shortLabel,
                kind = PropertyKind.Int,
                min = min,
                max = max,
                step = step,
                getInt = get,
                setInt = (h, v) => set(h, Mathf.Clamp(v, (int)min, (int)max))
            };
        }

        static PropertyDef Bool(string label, string shortLabel,
            Func<SplatBoxVREraseBrush, bool> get, Action<SplatBoxVREraseBrush, bool> set)
        {
            return new PropertyDef
            {
                label = label,
                shortLabel = shortLabel,
                kind = PropertyKind.Bool,
                getBool = get,
                setBool = set
            };
        }
    }
}
