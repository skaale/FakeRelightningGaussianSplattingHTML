// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    // ColorAdjustments is defined in Core/GaussianSplatRenderer.cs (now SplatBoxRenderer)
    
    [System.Flags]
    public enum FlipAxis
    {
        None = 0,
        X = 1 << 0,
        Y = 1 << 1,
        Z = 1 << 2
    }
    
    [System.Serializable]
    public struct PasteTransform
    {
        public Vector3 rotation;
        public Vector3 scale;
        public FlipAxis flip;
        
        public static PasteTransform Default => new PasteTransform
        {
            rotation = Vector3.zero,
            scale = Vector3.one,
            flip = FlipAxis.None
        };
        
        public bool HasTransform => 
            rotation != Vector3.zero || 
            scale != Vector3.one || 
            flip != FlipAxis.None;
        
        public Quaternion GetRotation() => Quaternion.Euler(rotation);
        
        public Vector3 GetFlipScale()
        {
            return new Vector3(
                (flip & FlipAxis.X) != 0 ? -1f : 1f,
                (flip & FlipAxis.Y) != 0 ? -1f : 1f,
                (flip & FlipAxis.Z) != 0 ? -1f : 1f
            );
        }
        
        public Vector3 GetCombinedScale()
        {
            Vector3 flipScale = GetFlipScale();
            return new Vector3(scale.x * flipScale.x, scale.y * flipScale.y, scale.z * flipScale.z);
        }
    }
    
    public enum BoxBrushMode
    {
        [UnityEngine.InspectorName("Box Xcopy")]
        Box3D = 0,
        [UnityEngine.InspectorName("Planar Xcopy")]
        Planar = 1,
        [UnityEngine.InspectorName("Paint Xcopy")]
        PaintSelection = 2
    }
    
    public class GaussianSplatBoxBrush : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] private Vector3 m_BoxSize = new Vector3(1f, 1f, 1f);
        [SerializeField] private Vector3 m_BoxPosition = Vector3.zero;
        [SerializeField] private Vector3 m_BoxRotation = Vector3.zero;
        
        [Header("Mode")]
        [SerializeField] private BoxBrushMode m_BrushMode = BoxBrushMode.Box3D;
        
        [Header("Visualization")]
        [SerializeField] private Color m_BoxColor = new Color(0f, 1f, 0.5f, 1f);
        [SerializeField] [Range(0.05f, 0.5f)] private float m_BoxAlpha = 0.15f;
        
        [Header("Planar Mode Settings")]
        [SerializeField] private float m_FloorY = 0f;
        [SerializeField] private float m_FloorThickness = 0.2f;
        [SerializeField] private Vector2 m_PlanarSize = new Vector2(1f, 1f);
        [SerializeField] private Vector2 m_PlanarPosition = Vector2.zero;
        
        [Header("Paint Selection Settings")]
        [SerializeField] private float m_SelectionBrushRadius = 0.2f;
        [SerializeField] private Color m_SelectionColor = new Color(1f, 0.5f, 0f, 0.8f);
        [SerializeField] private Color m_TargetColor = new Color(0f, 0.8f, 1f, 0.8f); // Cyan for target
        [SerializeField] private bool m_SelectionAddMode = true; // true = add, false = subtract
        [SerializeField] private bool m_PaintingTargetMode = false; // true = painting target area
        [SerializeField] private bool m_BackfaceCulling = true; // Only select splats facing camera
        
        [Header("Color Adjustments for Pasted Splats")]
        [SerializeField] private ColorAdjustments m_ColorAdjustments = ColorAdjustments.Default;
        [SerializeField] private bool m_ApplyColorAdjustments = false;
        
        [Header("Paste Transform")]
        [SerializeField] private PasteTransform m_PasteTransform = PasteTransform.Default;
        [SerializeField] private bool m_ApplyPasteTransform = false;
        
        [Header("Paste Offset Adjustment")]
        [SerializeField] private Vector3 m_PasteOffset = Vector3.zero;
        [SerializeField] private float m_PasteDepthOffset = 0f; // Offset along camera view direction
        [SerializeField] private Vector3 m_PasteRotationAdjust = Vector3.zero; // Euler angles adjustment
        [SerializeField] private float m_PasteScaleAdjust = 1f; // Uniform scale adjustment
        
        // Track last pasted splats for real-time adjustment
        private int m_LastPastedStartIndex = -1;
        private int m_LastPastedCount = 0;
        private Vector3 m_LastAppliedOffset = Vector3.zero;
        private Vector3 m_LastAppliedDepthDir = Vector3.forward;
        private float m_LastAppliedDepthOffset = 0f;
        private Vector3 m_LastAppliedRotation = Vector3.zero;
        private float m_LastAppliedScale = 1f;
        private Vector3 m_PastedSplatsPivot = Vector3.zero;
        
        private Vector3 m_CopiedSourcePosition;
        private Vector3 m_CopiedBoxSize;
        private Vector3 m_CopiedBoxRotation;
        private bool m_HasCopiedData = false;
        
        // Planar drawing state
        private bool m_IsDrawingPlanar = false;
        private Vector3 m_PlanarDragStart;
        private Vector2 m_CopiedPlanarPosition;
        private Vector2 m_CopiedPlanarSize;
        
        // Paint selection state
        private HashSet<int> m_SelectedSplatIndices = new HashSet<int>();
        private bool m_IsPaintingSelection = false;
        private List<int> m_CopiedSelectionIndices = new List<int>();
        private Vector3 m_SelectionCenterWhenCopied;
        private Quaternion m_SourceOrientationWhenCopied = Quaternion.identity;
        private Vector3 m_TargetPaintCenter;
        private int m_TargetPaintCount;
        private Quaternion m_TargetPaintOrientation = Quaternion.identity;
        private Vector3 m_LastTargetPaintDirection = Vector3.forward;
        private Vector3 m_TargetCameraForward = Vector3.forward; // For depth offset
        
        public Vector3 BoxSize
        {
            get => m_BoxSize;
            set => m_BoxSize = new Vector3(
                Mathf.Max(0.01f, value.x),
                Mathf.Max(0.01f, value.y),
                Mathf.Max(0.01f, value.z));
        }
        
        public Vector3 BoxPosition
        {
            get => m_BoxPosition;
            set => m_BoxPosition = value;
        }
        
        public Vector3 BoxRotation
        {
            get => m_BoxRotation;
            set => m_BoxRotation = value;
        }
        
        public Quaternion BoxRotationQuat
        {
            get => Quaternion.Euler(m_BoxRotation);
            set => m_BoxRotation = value.eulerAngles;
        }
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public bool HasCopiedData => m_HasCopiedData;
        public Vector3 CopiedSourcePosition => m_CopiedSourcePosition;
        public Vector3 CopiedBoxSize => m_CopiedBoxSize;
        
        public ColorAdjustments ColorAdjust
        {
            get => m_ColorAdjustments;
            set => m_ColorAdjustments = value;
        }
        
        public bool ApplyColorAdjustments
        {
            get => m_ApplyColorAdjustments;
            set => m_ApplyColorAdjustments = value;
        }
        
        public PasteTransform PasteTransformSettings
        {
            get => m_PasteTransform;
            set => m_PasteTransform = value;
        }
        
        public bool ApplyPasteTransform
        {
            get => m_ApplyPasteTransform;
            set => m_ApplyPasteTransform = value;
        }
        
        public Vector3 PasteOffset
        {
            get => m_PasteOffset;
            set
            {
                if (m_PasteOffset != value)
                {
                    m_PasteOffset = value;
                    ApplyPastedSplatOffsetDelta();
                }
            }
        }
        
        public float PasteDepthOffset
        {
            get => m_PasteDepthOffset;
            set
            {
                if (Mathf.Abs(m_PasteDepthOffset - value) > 0.0001f)
                {
                    m_PasteDepthOffset = value;
                    ApplyPastedSplatOffsetDelta();
                }
            }
        }
        
        public bool HasAdjustablePastedSplats => m_LastPastedStartIndex >= 0 && m_LastPastedCount > 0 && m_TargetRenderer != null;
        public int LastPastedCount => m_LastPastedCount;
        public Vector3 PastedSplatsPivot => m_PastedSplatsPivot;
        public Quaternion PastedSplatsRotation => Quaternion.Euler(m_PasteRotationAdjust);
        
        // Transform mode - when true, disables painting and enables transform handles
        private bool m_TransformModeActive = false;
        public bool TransformModeActive
        {
            get => m_TransformModeActive;
            set => m_TransformModeActive = value;
        }
        
        // Returns true if transform handles should be shown (has adjustable splats AND transform mode is active)
        public bool ShowTransformHandles => HasAdjustablePastedSplats && m_TransformModeActive;
        
        public Vector3 PasteRotationAdjust
        {
            get => m_PasteRotationAdjust;
            set
            {
                if (m_PasteRotationAdjust != value)
                {
                    m_PasteRotationAdjust = value;
                    ApplyPastedSplatTransformDelta();
                }
            }
        }
        
        public float PasteScaleAdjust
        {
            get => m_PasteScaleAdjust;
            set
            {
                if (Mathf.Abs(m_PasteScaleAdjust - value) > 0.0001f)
                {
                    m_PasteScaleAdjust = Mathf.Max(0.1f, value);
                    ApplyPastedSplatTransformDelta();
                }
            }
        }
        
        public BoxBrushMode BrushMode
        {
            get => m_BrushMode;
            set
            {
                if (m_BrushMode != value)
                {
                    // Clear paint selections when switching modes
                    if (m_BrushMode == BoxBrushMode.PaintSelection || value == BoxBrushMode.PaintSelection)
                    {
                        ResetPaintSelections();
                    }
                    m_BrushMode = value;
                }
            }
        }
        
        /// <summary>
        /// Reset all paint selection state (source, target, copied data)
        /// </summary>
        public void ResetPaintSelections()
        {
            m_SelectedSplatIndices.Clear();
            m_CopiedSelectionIndices.Clear();
            m_SelectionCenterWhenCopied = Vector3.zero;
            m_SourceOrientationWhenCopied = Quaternion.identity;
            m_PaintingTargetMode = false;
            m_IsPaintingSelection = false;
            m_HasCopiedData = false;
            ClearTargetPaintCenter();
            
            if (m_TargetRenderer != null && m_TargetRenderer.HasValidAsset)
            {
                m_TargetRenderer.EditDeselectAll();
                m_TargetRenderer.EditDeselectAllTarget();
            }
        }
        
        public Color BoxColor
        {
            get => m_BoxColor;
            set => m_BoxColor = value;
        }
        
        public float BoxAlpha
        {
            get => m_BoxAlpha;
            set => m_BoxAlpha = Mathf.Clamp(value, 0.05f, 0.5f);
        }
        
        public float FloorY
        {
            get => m_FloorY;
            set => m_FloorY = value;
        }
        
        public float FloorThickness
        {
            get => m_FloorThickness;
            set => m_FloorThickness = Mathf.Max(0.01f, value);
        }
        
        public Vector2 PlanarSize
        {
            get => m_PlanarSize;
            set => m_PlanarSize = new Vector2(Mathf.Max(0.01f, value.x), Mathf.Max(0.01f, value.y));
        }
        
        public Vector2 PlanarPosition
        {
            get => m_PlanarPosition;
            set => m_PlanarPosition = value;
        }
        
        public bool IsDrawingPlanar
        {
            get => m_IsDrawingPlanar;
            set => m_IsDrawingPlanar = value;
        }
        
        public Vector3 PlanarDragStart
        {
            get => m_PlanarDragStart;
            set => m_PlanarDragStart = value;
        }
        
        public Vector2 CopiedPlanarPosition => m_CopiedPlanarPosition;
        public Vector2 CopiedPlanarSize => m_CopiedPlanarSize;
        
        // Convert planar to 3D box
        public Vector3 PlanarBoxPosition => new Vector3(m_PlanarPosition.x, m_FloorY, m_PlanarPosition.y);
        public Vector3 PlanarBoxSize => new Vector3(m_PlanarSize.x, m_FloorThickness, m_PlanarSize.y);
        
        // Paint selection properties
        public float SelectionBrushRadius
        {
            get => m_SelectionBrushRadius;
            set => m_SelectionBrushRadius = Mathf.Max(0.01f, value);
        }
        
        public Color SelectionColor
        {
            get => m_SelectionColor;
            set => m_SelectionColor = value;
        }
        
        public bool SelectionAddMode
        {
            get => m_SelectionAddMode;
            set => m_SelectionAddMode = value;
        }
        
        public bool BackfaceCulling
        {
            get => m_BackfaceCulling;
            set => m_BackfaceCulling = value;
        }
        
        public Color TargetColor
        {
            get => m_TargetColor;
            set => m_TargetColor = value;
        }
        
        public bool PaintingTargetMode
        {
            get => m_PaintingTargetMode;
            set => m_PaintingTargetMode = value;
        }
        
        public bool IsPaintingSelection
        {
            get => m_IsPaintingSelection;
            set => m_IsPaintingSelection = value;
        }
        
        public int SelectedSplatCount => m_TargetRenderer != null ? (int)m_TargetRenderer.editSelectedSplats : m_SelectedSplatIndices.Count;
        public int TargetSelectedSplatCount => m_TargetRenderer != null ? (int)m_TargetRenderer.editTargetSelectedSplats : 0;
        public HashSet<int> SelectedSplatIndices => m_SelectedSplatIndices;
        public bool HasSelection => SelectedSplatCount > 0;
        public bool HasTargetSelection => TargetSelectedSplatCount > 0;
        public bool HasCopiedSelection => m_CopiedSelectionIndices.Count > 0;
        
        public Vector3 TargetPaintCenter => m_TargetPaintCount > 0 ? m_TargetPaintCenter : m_BoxPosition;
        public bool HasTargetPaintCenter => m_TargetPaintCount > 0;
        public Quaternion TargetPaintOrientation => m_TargetPaintOrientation;
        public Quaternion SourceOrientationWhenCopied => m_SourceOrientationWhenCopied;
        
        public void SetTargetPaintPosition(Vector3 worldPos, Vector3 cameraForward, Vector3 cameraUp)
        {
            if (m_TargetPaintCount == 0)
            {
                // Store first painted position as the target center
                m_TargetPaintCenter = worldPos;
                // Store camera orientation at paint time for alignment
                m_TargetPaintOrientation = Quaternion.LookRotation(-cameraForward, cameraUp);
                m_LastTargetPaintDirection = -cameraForward;
                // Store camera forward for depth offset
                m_TargetCameraForward = cameraForward;
            }
            else
            {
                // Track paint direction for orientation refinement
                Vector3 paintDir = (worldPos - m_TargetPaintCenter).normalized;
                if (paintDir.sqrMagnitude > 0.01f)
                {
                    m_LastTargetPaintDirection = Vector3.Lerp(m_LastTargetPaintDirection, paintDir, 0.3f).normalized;
                }
            }
            m_TargetPaintCount++;
        }
        
        // Overload for backward compatibility
        public void SetTargetPaintPosition(Vector3 worldPos)
        {
            SetTargetPaintPosition(worldPos, Vector3.forward, Vector3.up);
        }
        
        public void ClearTargetPaintCenter()
        {
            m_TargetPaintCenter = Vector3.zero;
            m_TargetPaintCount = 0;
            m_TargetPaintOrientation = Quaternion.identity;
            m_LastTargetPaintDirection = Vector3.forward;
            m_TargetCameraForward = Vector3.forward;
        }
        
        public Vector3 TargetCameraForward => m_TargetCameraForward;
        
        public static bool IsBrushModeActive { get; set; } = false;
        public static Vector3 LastBrushPosition { get; set; }
        public static bool HasValidBrushPosition { get; set; } = false;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        private void OnDisable()
        {
            // Clear paint selections when component is disabled
            ResetPaintSelections();
        }
        
        public void CopySplats()
        {
            if (m_TargetRenderer == null)
            {
                Debug.LogWarning("BoxBrush: No target renderer assigned");
                return;
            }
            
            if (m_BrushMode == BoxBrushMode.Planar)
            {
                m_CopiedSourcePosition = PlanarBoxPosition;
                m_CopiedBoxSize = PlanarBoxSize;
                m_CopiedPlanarPosition = m_PlanarPosition;
                m_CopiedPlanarSize = m_PlanarSize;
            }
            else
            {
                m_CopiedSourcePosition = m_BoxPosition;
                m_CopiedBoxSize = m_BoxSize;
                m_CopiedBoxRotation = m_BoxRotation;
            }
            m_HasCopiedData = true;
            Debug.Log($"BoxBrush: Copied splats from {(m_BrushMode == BoxBrushMode.Planar ? "planar" : "box")} at {m_CopiedSourcePosition} with size {m_CopiedBoxSize}");
        }
        
        public void PasteSplats()
        {
            if (!m_HasCopiedData)
            {
                Debug.LogWarning("BoxBrush: No copied data to paste");
                return;
            }
            
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("BoxBrush: Invalid renderer state");
                return;
            }
            
            Vector3 targetPos = m_BrushMode == BoxBrushMode.Planar ? PlanarBoxPosition : m_BoxPosition;
            
            // Calculate box rotation difference (from copied rotation to current rotation)
            Quaternion copiedRot = Quaternion.Euler(m_CopiedBoxRotation);
            Quaternion currentRot = m_BrushMode == BoxBrushMode.Planar ? Quaternion.identity : BoxRotationQuat;
            Quaternion boxRotationDelta = currentRot * Quaternion.Inverse(copiedRot);
            
            bool hasTransform = m_ApplyPasteTransform && m_PasteTransform.HasTransform;
            bool hasColor = m_ApplyColorAdjustments && m_ColorAdjustments.HasAdjustments;
            // Use dot product to check if rotation is approximately identity (handles floating point)
            bool hasBoxRotation = Mathf.Abs(Quaternion.Dot(boxRotationDelta, Quaternion.identity)) < 0.9999f;
            
            if (hasTransform || hasColor || hasBoxRotation)
            {
                // Combine box rotation with paste transform rotation
                Quaternion finalRotation = boxRotationDelta;
                Vector3 finalScale = Vector3.one;
                
                if (hasTransform)
                {
                    finalRotation = boxRotationDelta * m_PasteTransform.GetRotation();
                    finalScale = m_PasteTransform.GetCombinedScale();
                }
                
                m_TargetRenderer.CloneSplatsInBoxTransformed(
                    m_CopiedSourcePosition, 
                    targetPos, 
                    m_CopiedBoxSize,
                    finalRotation,
                    finalScale,
                    hasColor ? m_ColorAdjustments : ColorAdjustments.Default
                );
            }
            else
            {
                m_TargetRenderer.CloneSplatsInBox(m_CopiedSourcePosition, targetPos, m_CopiedBoxSize);
            }
            Debug.Log($"BoxBrush: Pasted splats to {targetPos}");
        }
        
        public void DeleteSplatsInBox()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("BoxBrush: Invalid renderer state");
                return;
            }
            
            if (m_BrushMode == BoxBrushMode.Planar)
            {
                m_TargetRenderer.DeleteSplatsInBox(PlanarBoxPosition, PlanarBoxSize);
            }
            else
            {
                m_TargetRenderer.DeleteSplatsInBox(m_BoxPosition, m_BoxSize, BoxRotationQuat);
            }
        }
        
        public void DeleteSplatsInBox(Vector3 boxCenter, Vector3 boxSize)
        {
            DeleteSplatsInBox(boxCenter, boxSize, Quaternion.identity);
        }
        
        public void DeleteSplatsInBox(Vector3 boxCenter, Vector3 boxSize, Quaternion boxRotation)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("BoxBrush: Invalid renderer state");
                return;
            }
            
            m_TargetRenderer.DeleteSplatsInBox(boxCenter, boxSize, boxRotation);
        }
        
        public void DeleteAndPaste()
        {
            if (!m_HasCopiedData)
            {
                Debug.LogWarning("BoxBrush: No copied data");
                return;
            }
            
            DeleteSplatsInBox();
            PasteSplats();
        }
        
        public void ClearCopiedData()
        {
            m_HasCopiedData = false;
        }
        
        public void ResetBox()
        {
            m_BoxSize = Vector3.one;
            m_BoxPosition = Vector3.zero;
            m_BoxRotation = Vector3.zero;
            m_PlanarSize = Vector2.one;
            m_PlanarPosition = Vector2.zero;
            m_HasCopiedData = false;
            m_IsDrawingPlanar = false;
        }
        
        public void ResetAll()
        {
            m_BrushMode = BoxBrushMode.Box3D;
            m_BoxSize = Vector3.one;
            m_BoxPosition = Vector3.zero;
            m_BoxRotation = Vector3.zero;
            m_BoxColor = new Color(0f, 1f, 0.5f, 1f);
            m_BoxAlpha = 0.15f;
            m_FloorY = 0f;
            m_FloorThickness = 0.2f;
            m_PlanarSize = Vector2.one;
            m_PlanarPosition = Vector2.zero;
            m_ColorAdjustments = ColorAdjustments.Default;
            m_ApplyColorAdjustments = false;
            m_PasteTransform = PasteTransform.Default;
            m_ApplyPasteTransform = false;
            m_HasCopiedData = false;
            m_IsDrawingPlanar = false;
            
            // Reset selection state
            m_SelectedSplatIndices.Clear();
            m_CopiedSelectionIndices.Clear();
            m_IsPaintingSelection = false;
        }
        
        public void SetPlanarFromDrag(Vector3 startPoint, Vector3 endPoint)
        {
            float minX = Mathf.Min(startPoint.x, endPoint.x);
            float maxX = Mathf.Max(startPoint.x, endPoint.x);
            float minZ = Mathf.Min(startPoint.z, endPoint.z);
            float maxZ = Mathf.Max(startPoint.z, endPoint.z);
            
            m_PlanarSize = new Vector2(maxX - minX, maxZ - minZ);
            m_PlanarPosition = new Vector2((minX + maxX) * 0.5f, (minZ + maxZ) * 0.5f);
            m_FloorY = (startPoint.y + endPoint.y) * 0.5f;
        }
        
        public void StartPlanarDrag(Vector3 point)
        {
            m_IsDrawingPlanar = true;
            m_PlanarDragStart = point;
            m_FloorY = point.y;
        }
        
        public void UpdatePlanarDrag(Vector3 currentPoint)
        {
            if (!m_IsDrawingPlanar) return;
            SetPlanarFromDrag(m_PlanarDragStart, currentPoint);
        }
        
        public void EndPlanarDrag()
        {
            m_IsDrawingPlanar = false;
        }
        
        public void ResetColorAdjustments()
        {
            m_ColorAdjustments = ColorAdjustments.Default;
        }
        
        public void ResetPasteTransform()
        {
            m_PasteTransform = PasteTransform.Default;
        }
        
        // Paint Selection Methods
        public void PaintSelectionAt(Vector3 worldPosition)
        {
            // Overload without camera direction (no backface culling)
            PaintSelectionAt(worldPosition, Vector3.forward);
        }
        
        public void PaintSelectionAt(Vector3 worldPosition, Vector3 cameraForward)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
                return;
            
            // Update selection color on renderer
            m_TargetRenderer.SelectionColor = m_SelectionColor;
            
            // Use GPU-based selection with optional backface culling
            if (m_BackfaceCulling)
            {
                m_TargetRenderer.EditSelectSplatsInSphere(worldPosition, m_SelectionBrushRadius, m_SelectionAddMode, cameraForward);
            }
            else
            {
                m_TargetRenderer.EditSelectSplatsInSphere(worldPosition, m_SelectionBrushRadius, m_SelectionAddMode);
            }
        }
        
        public void ClearSelection()
        {
            m_SelectedSplatIndices.Clear();
            if (m_TargetRenderer != null && m_TargetRenderer.HasValidAsset)
                m_TargetRenderer.EditDeselectAll();
        }
        
        public void ClearTargetSelection()
        {
            if (m_TargetRenderer != null && m_TargetRenderer.HasValidAsset)
                m_TargetRenderer.EditDeselectAllTarget();
        }
        
        public void SelectAll()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;
            
            m_TargetRenderer.EditSelectAll();
        }
        
        public void InvertSelection()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;
            
            m_TargetRenderer.EditInvertSelection();
        }
        
        public void CopySelection()
        {
            CopySelectionWithOrientation(Vector3.forward, Vector3.up);
        }
        
        public void CopySelectionWithOrientation(Vector3 cameraForward, Vector3 cameraUp)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("BoxBrush: Invalid renderer state");
                return;
            }
            
            if (m_TargetRenderer.editSelectedSplats == 0)
            {
                Debug.LogWarning("BoxBrush: No splats selected to copy");
                return;
            }
            
            // Get selected indices from GPU
            m_CopiedSelectionIndices.Clear();
            m_CopiedSelectionIndices.AddRange(m_TargetRenderer.GetSelectedSplatIndices());
            
            if (m_CopiedSelectionIndices.Count == 0)
            {
                Debug.LogWarning("BoxBrush: Failed to read selection from GPU");
                return;
            }
            
            // Calculate center of selection
            m_SelectionCenterWhenCopied = m_TargetRenderer.GetSelectedSplatsCenter();
            // Store camera orientation at copy time for alignment
            m_SourceOrientationWhenCopied = Quaternion.LookRotation(-cameraForward, cameraUp);
            m_HasCopiedData = true;
            
            // Clear target paint data so user can paint fresh target
            ClearTargetPaintCenter();
            if (m_TargetRenderer != null && m_TargetRenderer.HasValidAsset)
                m_TargetRenderer.EditDeselectAllTarget();
            
            Debug.Log($"Copied {m_CopiedSelectionIndices.Count} splats at center {m_SelectionCenterWhenCopied}");
        }
        
        public Vector3 GetSelectionCenter()
        {
            if (m_TargetRenderer == null || m_TargetRenderer.editSelectedSplats == 0)
                return Vector3.zero;
            
            return m_TargetRenderer.GetSelectedSplatsCenter();
        }
        
        public void PasteSelection()
        {
            if (m_CopiedSelectionIndices.Count == 0)
            {
                Debug.LogWarning("No copied selection to paste");
                return;
            }
            
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("Invalid renderer state for paste");
                return;
            }
            
            // Use the CENTER of the actual painted target splats for precise alignment
            Vector3 targetPosition;
            if (m_TargetRenderer.editTargetSelectedSplats > 0)
            {
                // Get the actual center of the painted target splats
                targetPosition = m_TargetRenderer.GetTargetSelectedSplatsCenter();
            }
            else if (HasTargetPaintCenter)
            {
                targetPosition = TargetPaintCenter;
            }
            else
            {
                targetPosition = m_BoxPosition;
            }
            
            // Calculate alignment rotation from source orientation to target orientation
            Quaternion alignmentRotation = Quaternion.identity;
            if (HasTargetPaintCenter && m_SourceOrientationWhenCopied != Quaternion.identity)
            {
                // Compute rotation from source view orientation to target view orientation
                alignmentRotation = m_TargetPaintOrientation * Quaternion.Inverse(m_SourceOrientationWhenCopied);
            }
            
            // Combine with user-specified paste transform
            bool hasTransform = m_ApplyPasteTransform && m_PasteTransform.HasTransform;
            bool hasColor = m_ApplyColorAdjustments && m_ColorAdjustments.HasAdjustments;
            
            Quaternion finalRotation = alignmentRotation;
            Vector3 finalScale = Vector3.one;
            
            if (hasTransform)
            {
                finalRotation = alignmentRotation * m_PasteTransform.GetRotation();
                finalScale = m_PasteTransform.GetCombinedScale();
            }
            
            // Check if we have any rotation to apply
            bool hasRotation = Mathf.Abs(Quaternion.Dot(finalRotation, Quaternion.identity)) < 0.9999f;
            
            // Calculate offset: move source center to target center
            Vector3 offset = targetPosition - m_SelectionCenterWhenCopied;
            
            // Apply user offset adjustments
            offset += m_PasteOffset;
            
            // Apply depth offset along camera view direction
            if (Mathf.Abs(m_PasteDepthOffset) > 0.001f)
            {
                offset += m_TargetCameraForward * m_PasteDepthOffset;
            }
            
            Debug.Log($"Paste: {m_CopiedSelectionIndices.Count} splats to target center {targetPosition}, offset={offset}, rotation={alignmentRotation.eulerAngles}");
            
            // Store current splat count before pasting (new splats will be added after this)
            int startIndex = m_TargetRenderer.splatCount;
            
            if (hasRotation || hasTransform || hasColor)
            {
                m_TargetRenderer.CloneSplatsFromIndicesTransformed(
                    m_CopiedSelectionIndices,
                    offset,
                    finalRotation,
                    finalScale,
                    m_SelectionCenterWhenCopied,
                    hasColor ? m_ColorAdjustments : ColorAdjustments.Default
                );
            }
            else
            {
                m_TargetRenderer.CloneSplatsFromIndices(m_CopiedSelectionIndices, offset);
            }
            
            // Track pasted splats for real-time offset adjustment
            m_LastPastedStartIndex = startIndex;
            m_LastPastedCount = Mathf.Min(m_CopiedSelectionIndices.Count, m_TargetRenderer.splatCount - startIndex);
            m_LastAppliedOffset = m_PasteOffset;
            m_LastAppliedDepthOffset = m_PasteDepthOffset;
            m_LastAppliedDepthDir = m_TargetCameraForward;
            m_LastAppliedRotation = Vector3.zero;
            m_LastAppliedScale = 1f;
            m_PastedSplatsPivot = targetPosition;
            
            // Reset adjustment values for new paste
            m_PasteRotationAdjust = Vector3.zero;
            m_PasteScaleAdjust = 1f;
            
            Debug.Log($"Tracked pasted splats: start={m_LastPastedStartIndex}, count={m_LastPastedCount}");
        }
        
        /// <summary>
        /// Apply offset delta to the last pasted splats for real-time adjustment
        /// </summary>
        private void ApplyPastedSplatOffsetDelta()
        {
            if (!HasAdjustablePastedSplats) return;
            if (!m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup) return;
            
            // Calculate delta from last applied offset
            Vector3 offsetDelta = m_PasteOffset - m_LastAppliedOffset;
            float depthDelta = m_PasteDepthOffset - m_LastAppliedDepthOffset;
            
            // Add depth delta along camera forward
            if (Mathf.Abs(depthDelta) > 0.0001f)
            {
                offsetDelta += m_LastAppliedDepthDir * depthDelta;
            }
            
            // Only apply if there's actual change
            if (offsetDelta.sqrMagnitude < 0.00001f) return;
            
            // Apply the delta to the pasted splats
            m_TargetRenderer.MoveSplatsInRange(m_LastPastedStartIndex, m_LastPastedCount, offsetDelta);
            
            // Update last applied values
            m_LastAppliedOffset = m_PasteOffset;
            m_LastAppliedDepthOffset = m_PasteDepthOffset;
        }
        
        /// <summary>
        /// Apply rotation and scale delta to pasted splats using undo-then-apply approach
        /// </summary>
        private void ApplyPastedSplatTransformDelta()
        {
            if (!HasAdjustablePastedSplats) return;
            if (!m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup) return;
            
            // Compute quaternions for last applied and new rotation
            Quaternion lastRot = Quaternion.Euler(m_LastAppliedRotation);
            Quaternion newRot = Quaternion.Euler(m_PasteRotationAdjust);
            
            // Compute the delta rotation: undo last, then apply new
            // deltaRot * lastRot = newRot  =>  deltaRot = newRot * Inverse(lastRot)
            Quaternion rotDelta = newRot * Quaternion.Inverse(lastRot);
            
            // Compute scale delta
            float scaleDelta = m_PasteScaleAdjust / Mathf.Max(0.001f, m_LastAppliedScale);
            
            bool hasRotation = Mathf.Abs(Quaternion.Dot(rotDelta, Quaternion.identity)) < 0.9999f;
            bool hasScale = Mathf.Abs(scaleDelta - 1f) > 0.001f;
            
            if (!hasRotation && !hasScale) return;
            
            m_TargetRenderer.TransformSplatsInRange(
                m_LastPastedStartIndex, 
                m_LastPastedCount, 
                m_PastedSplatsPivot,
                hasRotation ? rotDelta : Quaternion.identity,
                hasScale ? scaleDelta : 1f
            );
            
            m_LastAppliedRotation = m_PasteRotationAdjust;
            m_LastAppliedScale = m_PasteScaleAdjust;
        }
        
        /// <summary>
        /// Clear the tracking of pasted splats (call when done adjusting)
        /// </summary>
        public void ConfirmPastedSplats()
        {
            m_LastPastedStartIndex = -1;
            m_LastPastedCount = 0;
            m_LastAppliedOffset = Vector3.zero;
            m_LastAppliedDepthOffset = 0f;
            m_LastAppliedRotation = Vector3.zero;
            m_LastAppliedScale = 1f;
            m_PastedSplatsPivot = Vector3.zero;
        }
        
        /// <summary>
        /// Reset all paste adjustment values
        /// </summary>
        public void ResetPasteAdjustments()
        {
            m_PasteOffset = Vector3.zero;
            m_PasteDepthOffset = 0f;
            m_PasteRotationAdjust = Vector3.zero;
            m_PasteScaleAdjust = 1f;
        }
        
        public void DeleteSelection()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
            {
                Debug.LogWarning("BoxBrush: Invalid renderer state");
                return;
            }
            
            if (m_TargetRenderer.editSelectedSplats == 0)
            {
                Debug.LogWarning("BoxBrush: No splats selected to delete");
                return;
            }
            
            m_TargetRenderer.EditDeleteSelected();
            m_SelectedSplatIndices.Clear();
            
            Debug.Log("BoxBrush: Deleted selected splats");
        }
        
        public bool SupportsCloning => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                                       m_TargetRenderer.SupportsCloning;
        
        public bool CanPasteSelection => m_CopiedSelectionIndices.Count > 0 && m_TargetRenderer != null && 
                                         m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup &&
                                         m_TargetRenderer.SupportsCloning;
        
        public bool CanPaste => m_HasCopiedData && m_TargetRenderer != null && 
                                m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup &&
                                m_TargetRenderer.SupportsCloning;
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                               m_TargetRenderer.HasValidRenderSetup;

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (IsBrushModeActive || !UnityEditor.Selection.Contains(gameObject))
                return;
            
            DrawBoxGizmo();
        }
        
        private void OnDrawGizmosSelected()
        {
            DrawBoxGizmo();
        }
        
        private void DrawBoxGizmo()
        {
            Vector3 currentPos = m_BrushMode == BoxBrushMode.Planar ? PlanarBoxPosition : m_BoxPosition;
            Vector3 currentSize = m_BrushMode == BoxBrushMode.Planar ? PlanarBoxSize : m_BoxSize;
            
            // Current box/planar
            Gizmos.color = m_HasCopiedData ? new Color(0f, 0.8f, 1f, 0.3f) : new Color(0f, 1f, 0.5f, 0.3f);
            Gizmos.DrawCube(currentPos, currentSize);
            
            Gizmos.color = m_HasCopiedData ? new Color(0f, 0.8f, 1f, 0.9f) : new Color(0f, 1f, 0.5f, 0.9f);
            Gizmos.DrawWireCube(currentPos, currentSize);
            
            // Source box if copied
            if (m_HasCopiedData)
            {
                Gizmos.color = new Color(1f, 0.5f, 0f, 0.3f);
                Gizmos.DrawCube(m_CopiedSourcePosition, m_CopiedBoxSize);
                
                Gizmos.color = new Color(1f, 0.5f, 0f, 0.9f);
                Gizmos.DrawWireCube(m_CopiedSourcePosition, m_CopiedBoxSize);
                
                Gizmos.color = Color.yellow;
                Gizmos.DrawLine(m_CopiedSourcePosition, currentPos);
            }
        }
#endif
    }
}

