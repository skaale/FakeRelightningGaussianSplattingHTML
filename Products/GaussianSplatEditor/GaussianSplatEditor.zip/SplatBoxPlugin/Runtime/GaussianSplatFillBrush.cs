// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatFillBrush : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] [Range(0.01f, 2.0f)] private float m_SelectionDepth = 0.1f;
        [SerializeField] [Range(0.01f, 1.0f)] private float m_EdgeSampleWidth = 0.1f;
        [SerializeField] [Range(0.5f, 5.0f)] private float m_FillDensity = 1.0f;
        [SerializeField] [Range(0f, 0.5f)] private float m_PositionJitter = 0.001f;
        [SerializeField] private bool m_DeleteBeforeFill = false;
        
        [Header("Fill Color")]
        [SerializeField] private bool m_UseFillColor = false;
        [SerializeField] private Color m_FillColor = Color.white;
        [SerializeField] [Range(0f, 1f)] private float m_FillColorBlend = 1.0f;
        
        [Header("Color Adjustments")]
        [SerializeField] private ColorAdjustments m_ColorAdjustments = ColorAdjustments.Default;
        
        // Polygon vertices (original, before transform)
        private List<Vector3> m_Vertices = new List<Vector3>();
        private bool m_IsDrawing = false;
        private bool m_IsClosed = false;
        private Vector3 m_PolygonCenter;
        private Vector3 m_PolygonNormal = Vector3.up;
        
        // Transform controls for closed polygon
        private Vector3 m_TransformOffset = Vector3.zero;
        private Quaternion m_TransformRotation = Quaternion.identity;
        private Vector3 m_TransformScale = Vector3.one;
        
        public float SelectionDepth
        {
            get => m_SelectionDepth;
            set => m_SelectionDepth = Mathf.Clamp(value, 0.01f, 2.0f);
        }
        
        public float EdgeSampleWidth
        {
            get => m_EdgeSampleWidth;
            set => m_EdgeSampleWidth = Mathf.Clamp(value, 0.01f, 1.0f);
        }
        
        public float FillDensity
        {
            get => m_FillDensity;
            set => m_FillDensity = Mathf.Clamp(value, 0.5f, 5.0f);
        }
        
        public float PositionJitter
        {
            get => m_PositionJitter;
            set => m_PositionJitter = Mathf.Clamp(value, 0f, 0.5f);
        }
        
        public bool DeleteBeforeFill
        {
            get => m_DeleteBeforeFill;
            set => m_DeleteBeforeFill = value;
        }
        
        public ColorAdjustments ColorAdjust
        {
            get => m_ColorAdjustments;
            set => m_ColorAdjustments = value;
        }
        
        public bool UseFillColor
        {
            get => m_UseFillColor;
            set => m_UseFillColor = value;
        }
        
        public Color FillColor
        {
            get => m_FillColor;
            set => m_FillColor = value;
        }
        
        public float FillColorBlend
        {
            get => m_FillColorBlend;
            set => m_FillColorBlend = Mathf.Clamp01(value);
        }
        
        public List<Vector3> Vertices => m_Vertices;
        public bool IsDrawing => m_IsDrawing;
        public bool IsClosed => m_IsClosed;
        public Vector3 PolygonCenter => m_PolygonCenter;
        public Vector3 PolygonNormal => m_PolygonNormal;
        
        // Transform properties
        public Vector3 TransformOffset
        {
            get => m_TransformOffset;
            set => m_TransformOffset = value;
        }
        
        public Quaternion TransformRotation
        {
            get => m_TransformRotation;
            set => m_TransformRotation = value;
        }
        
        public Vector3 TransformScale
        {
            get => m_TransformScale;
            set
            {
                m_TransformScale = new Vector3(
                    Mathf.Max(0.01f, value.x),
                    Mathf.Max(0.01f, value.y),
                    Mathf.Max(0.01f, value.z));
            }
        }
        
        public float UniformScale
        {
            get => m_TransformScale.x;
            set => m_TransformScale = Vector3.one * Mathf.Max(0.01f, value);
        }
        
        public Vector3 TransformedCenter => m_PolygonCenter + m_TransformOffset;
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public bool HasValidPolygon => m_IsClosed && m_Vertices.Count >= 3;
        public bool CanFill => HasValidPolygon && m_TargetRenderer != null && 
                               m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup;
        
        public static bool IsBrushModeActive { get; set; } = false;
        public static Vector3 LastBrushPosition { get; set; }
        public static bool HasValidBrushPosition { get; set; } = false;
        
        /// <summary>
        /// Gets the polygon vertices with current transform applied
        /// </summary>
        public List<Vector3> GetTransformedVertices()
        {
            var result = new List<Vector3>(m_Vertices.Count);
            foreach (var v in m_Vertices)
            {
                // Transform relative to center: offset from center, scale, rotate, then add back center + offset
                Vector3 localPos = v - m_PolygonCenter;
                localPos = Vector3.Scale(localPos, m_TransformScale);
                localPos = m_TransformRotation * localPos;
                result.Add(localPos + m_PolygonCenter + m_TransformOffset);
            }
            return result;
        }
        
        /// <summary>
        /// Gets the transformed normal based on rotation
        /// </summary>
        public Vector3 GetTransformedNormal()
        {
            return m_TransformRotation * m_PolygonNormal;
        }
        
        /// <summary>
        /// Resets transform to identity
        /// </summary>
        public void ResetTransform()
        {
            m_TransformOffset = Vector3.zero;
            m_TransformRotation = Quaternion.identity;
            m_TransformScale = Vector3.one;
        }
        
        /// <summary>
        /// Applies current transform to vertices permanently (bakes the transform)
        /// </summary>
        public void BakeTransform()
        {
            if (!m_IsClosed || m_Vertices.Count == 0) return;
            
            var transformed = GetTransformedVertices();
            m_Vertices.Clear();
            m_Vertices.AddRange(transformed);
            
            m_PolygonCenter = m_PolygonCenter + m_TransformOffset;
            m_PolygonNormal = GetTransformedNormal();
            
            ResetTransform();
        }
        
        /// <summary>
        /// Moves a specific vertex (in transformed space) and updates the original vertex
        /// </summary>
        public void MoveTransformedVertex(int index, Vector3 newWorldPosition)
        {
            if (index < 0 || index >= m_Vertices.Count) return;
            
            // Convert world position back to original space
            // Reverse the transform: subtract center+offset, inverse rotate, inverse scale, add back center
            Vector3 localPos = newWorldPosition - (m_PolygonCenter + m_TransformOffset);
            localPos = Quaternion.Inverse(m_TransformRotation) * localPos;
            localPos = new Vector3(
                m_TransformScale.x > 0.001f ? localPos.x / m_TransformScale.x : localPos.x,
                m_TransformScale.y > 0.001f ? localPos.y / m_TransformScale.y : localPos.y,
                m_TransformScale.z > 0.001f ? localPos.z / m_TransformScale.z : localPos.z);
            localPos += m_PolygonCenter;
            
            m_Vertices[index] = localPos;
            UpdateCenter();
        }
        
        /// <summary>
        /// Gets the world position of a transformed vertex
        /// </summary>
        public Vector3 GetTransformedVertex(int index)
        {
            if (index < 0 || index >= m_Vertices.Count) return Vector3.zero;
            
            Vector3 v = m_Vertices[index];
            Vector3 localPos = v - m_PolygonCenter;
            localPos = Vector3.Scale(localPos, m_TransformScale);
            localPos = m_TransformRotation * localPos;
            return localPos + m_PolygonCenter + m_TransformOffset;
        }
        
        /// <summary>
        /// Number of vertices in the polygon
        /// </summary>
        public int VertexCount => m_Vertices.Count;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        public void StartDrawing(Vector3 firstVertex, Vector3 normal)
        {
            m_Vertices.Clear();
            m_Vertices.Add(firstVertex);
            m_IsDrawing = true;
            m_IsClosed = false;
            m_PolygonNormal = normal;
            UpdateCenter();
        }
        
        public void AddVertex(Vector3 worldPosition)
        {
            if (!m_IsDrawing)
            {
                StartDrawing(worldPosition, Vector3.up);
                return;
            }
            
            // Don't add if too close to existing vertex
            if (m_Vertices.Count > 0)
            {
                float minDist = 0.02f;
                foreach (var v in m_Vertices)
                {
                    if (Vector3.Distance(v, worldPosition) < minDist)
                        return;
                }
            }
            
            m_Vertices.Add(worldPosition);
            UpdateCenter();
        }
        
        public void ClosePolygon()
        {
            if (m_Vertices.Count >= 3)
            {
                m_IsClosed = true;
                m_IsDrawing = false;
                UpdateCenter();
                Debug.Log($"FILL: Polygon closed with {m_Vertices.Count} vertices");
            }
        }
        
        public void UndoLastVertex()
        {
            if (m_Vertices.Count > 0)
            {
                m_Vertices.RemoveAt(m_Vertices.Count - 1);
                UpdateCenter();
                
                if (m_Vertices.Count == 0)
                {
                    m_IsDrawing = false;
                    m_IsClosed = false;
                }
            }
        }
        
        public void Clear()
        {
            m_Vertices.Clear();
            m_IsDrawing = false;
            m_IsClosed = false;
            m_PolygonCenter = Vector3.zero;
            ResetTransform();
        }
        
        public void ResetColorAdjustments()
        {
            m_ColorAdjustments = ColorAdjustments.Default;
        }
        
        private void UpdateCenter()
        {
            if (m_Vertices.Count == 0)
            {
                m_PolygonCenter = Vector3.zero;
                return;
            }
            
            Vector3 sum = Vector3.zero;
            foreach (var v in m_Vertices)
                sum += v;
            m_PolygonCenter = sum / m_Vertices.Count;
            
            // Calculate normal from polygon vertices
            if (m_Vertices.Count >= 3)
            {
                Vector3 edge1 = m_Vertices[1] - m_Vertices[0];
                Vector3 edge2 = m_Vertices[2] - m_Vertices[0];
                m_PolygonNormal = Vector3.Cross(edge1, edge2).normalized;
                if (m_PolygonNormal.magnitude < 0.1f)
                    m_PolygonNormal = Vector3.up;
            }
        }
        
        public void ExecuteFill()
        {
            if (!CanFill)
            {
                Debug.LogWarning($"FillBrush: Cannot fill - HasValidPolygon={HasValidPolygon}, Renderer={m_TargetRenderer != null}, HasAsset={m_TargetRenderer?.HasValidAsset}, HasSetup={m_TargetRenderer?.HasValidRenderSetup}");
                return;
            }
            
            // Get transformed vertices
            var transformedVerts = GetTransformedVertices();
            Vector3 transformedCenter = TransformedCenter;
            
            // Delete existing splats in polygon if enabled
            if (m_DeleteBeforeFill)
            {
                m_TargetRenderer.DeleteSplatsInPolygon(transformedVerts, m_SelectionDepth);
            }
            
            // Fill polygon with sampled splats from edges
            m_TargetRenderer.FillPolygonWithSplats(
                transformedVerts, 
                transformedCenter,
                m_SelectionDepth, 
                m_EdgeSampleWidth,
                m_FillDensity,
                m_PositionJitter,
                m_ColorAdjustments,
                m_UseFillColor,
                m_FillColor,
                m_FillColorBlend);
            
            Debug.Log($"FILL: Filled polygon with {m_Vertices.Count} vertices");
        }
        
        public void DeletePolygonArea()
        {
            if (!HasValidPolygon || m_TargetRenderer == null)
                return;
            
            var transformedVerts = GetTransformedVertices();
            m_TargetRenderer.DeleteSplatsInPolygon(transformedVerts, m_SelectionDepth);
            Debug.Log("FILL: Deleted splats in polygon area");
        }
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                               m_TargetRenderer.HasValidRenderSetup;
        
        public bool HasAdjustments => m_ColorAdjustments.HasAdjustments;

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (IsBrushModeActive || !UnityEditor.Selection.Contains(gameObject))
                return;
            
            DrawPolygonGizmo();
        }
        
        private void OnDrawGizmosSelected()
        {
            DrawPolygonGizmo();
        }
        
        private void DrawPolygonGizmo()
        {
            if (m_Vertices.Count == 0) return;
            
            // Use transformed vertices when closed
            var displayVerts = m_IsClosed ? GetTransformedVertices() : m_Vertices;
            Vector3 displayCenter = m_IsClosed ? TransformedCenter : m_PolygonCenter;
            
            // Draw vertices
            Gizmos.color = m_IsClosed ? new Color(0.3f, 0.9f, 0.5f, 0.9f) : new Color(0.9f, 0.7f, 0.2f, 0.9f);
            foreach (var v in displayVerts)
                Gizmos.DrawSphere(v, 0.02f);
            
            // Draw edges
            for (int i = 0; i < displayVerts.Count - 1; i++)
                Gizmos.DrawLine(displayVerts[i], displayVerts[i + 1]);
            
            // Close polygon
            if (m_IsClosed && displayVerts.Count >= 3)
            {
                Gizmos.color = new Color(0.3f, 0.9f, 0.5f, 0.9f);
                Gizmos.DrawLine(displayVerts[displayVerts.Count - 1], displayVerts[0]);
            }
            
            // Draw center
            if (displayVerts.Count >= 3)
            {
                Gizmos.color = Color.yellow;
                Gizmos.DrawWireSphere(displayCenter, 0.05f);
            }
        }
#endif
    }
}

