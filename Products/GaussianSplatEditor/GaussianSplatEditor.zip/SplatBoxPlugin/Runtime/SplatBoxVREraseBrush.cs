// SPDX-License-Identifier: MIT

using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.XR;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// VR splat brush: tool palette at the hand circle (A to select), trigger to apply the active editor tool.
    /// Right hand: brush + radial HUD on the same hand. Trigger/A select menu wedges, grip restore,
    /// thumbstick Y = radius or property slider, stick-click back, B toggles tool HUD.
    /// </summary>
    [DisallowMultipleComponent]
    public class SplatBoxVREraseBrush : MonoBehaviour
    {
        [Header("Targets")]
        public SplatBoxRenderer m_TargetRenderer;
        public Camera m_XrCamera;

        [Header("XR Input — Right Hand (brush)")]
        public XRNode m_ControllerNode = XRNode.RightHand;
        [Tooltip("Right hand in the scene. Auto-finds 'Right Hand Model'. Uses world transform (no tracking offset).")]
        public Transform m_RightHandTransform;

        [Header("XR Input — Left Hand (optional)")]
        public Transform m_LeftHandTransform;
        [Tooltip("Brush origin offset in hand local space.")]
        public Vector3 m_BrushLocalOffset = Vector3.zero;
        [Tooltip("Aim direction in hand local space. Try (0,0,1), (0,1,0), or (1,0,0) if the circle aim feels wrong.")]
        public Vector3 m_AimLocalDirection = new Vector3(0f, 0f, 1f);
        [Tooltip("How far in front of the hand the red circle is drawn (meters).")]
        public float m_BrushVisualDistance = 0.1f;

        [Header("Interaction")]
        public float m_RayMaxDistance = 50f;
        [Tooltip("Default screen radius when none is saved yet (desktop erase uses the same value).")]
        public float m_DefaultScreenRadius = 3f;
        [Tooltip("Screen-radius change per second at full thumbstick deflection.")]
        public float m_RadiusAdjustSpeed = 8f;
        [Tooltip("Maximum brush screen radius (thumbstick). Delete radius = this × Delete Radius Multiplier.")]
        public float m_MaxScreenRadius = 50f;
        [Range(0.05f, 0.5f)] public float m_StickDeadZone = 0.15f;
        public float m_DeleteInterval = 0.008f;
        [Tooltip("Extra multiplier on delete radius (visual circle size is unchanged).")]
        public float m_DeleteRadiusMultiplier = 3f;
        [Tooltip("When false, deletes through depth along the aim ray instead of only the front screen layer.")]
        public bool m_BackfaceCulling = false;
        [Tooltip("World offset when cloning splats along the aim ray.")]
        public float m_CloneOffset = 0.15f;

        [Header("Tool Palette (auto-created at runtime)")]
        public SplatBoxVRBrushHud m_ToolHud;

        [Header("HUD Feedback (auto-created at runtime)")]
        [Tooltip("Seconds to show radius / splat info after thumbstick resize or B-button backface toggle.")]
        public float m_InfoDisplayDuration = 2.5f;
        [Tooltip("HUD offset from the controller in hand-local space (X = right, Y = up, Z = forward).")]
        public Vector3 m_HudLocalOffset = new Vector3(0.64f, 0.01f, 0f);
        public float m_HudCharacterSize = 0.00015f;
        public int m_HudFontSize = 8;

        [Header("Visual Feedback (auto-created at runtime)")]
        public Color m_RayColor = new Color(1f, 0.35f, 0.35f, 0.9f);
        public Color m_DiscFillColor = new Color(1f, 0.3f, 0.3f, 0.15f);
        public Color m_RingColor = new Color(1f, 0.3f, 0.3f, 0.9f);
        public Color m_RingColorActive = new Color(1f, 0.15f, 0.15f, 1f);
        [Range(8, 64)] public int m_RingSegments = 48;
        public float m_RingLineWidth = 0.012f;

        static readonly InputFeatureUsage<Vector3> s_PointerPositionUsage = new InputFeatureUsage<Vector3>("PointerPosition");
        static readonly InputFeatureUsage<Quaternion> s_PointerRotationUsage = new InputFeatureUsage<Quaternion>("PointerRotation");

        GaussianSplatBrush m_Brush;
        GaussianSplatPaintBrush m_PaintBrush;
        GaussianSplatColorizeBrush m_ColorizeBrush;
        GaussianSplatColorBrush m_ColorBrush;
        GaussianSplatAttractor m_VortexAttractor;
        LineRenderer m_RayLine;
        LineRenderer m_BrushRing;
        LineRenderer m_FalloffRing;
        MeshRenderer m_BrushDisc;
        Material m_DiscMaterial;
        Material m_LineMaterial;
        Mesh m_DiscMesh;
        TextMesh m_HudText;
        Material m_HudMaterial;
        float m_LastActionTime;
        float m_InfoHideTime;
        bool m_HasValidHit;
        bool m_RightHudSelectWasPressed;
        bool m_RightHudBackWasPressed;
        bool m_BButtonWasPressed;
        string m_ToolStatusMessage;

        public GaussianSplatBrush EraseBrush => m_Brush;
        public GaussianSplatPaintBrush PaintBrush => m_PaintBrush;
        public GaussianSplatColorizeBrush ColorizeBrush => m_ColorizeBrush;
        public GaussianSplatColorBrush ColorBrush => m_ColorBrush;
        public GaussianSplatAttractor VortexAttractor => m_VortexAttractor;
        public float CloneOffset
        {
            get => m_CloneOffset;
            set => m_CloneOffset = Mathf.Clamp(value, 0.02f, 1f);
        }
        public bool EraseBackfaceCulling
        {
            get => m_BackfaceCulling;
            set => m_BackfaceCulling = value;
        }

        void Reset()
        {
            EnsureBrush();
            EnsureVisuals();
        }

        void Awake()
        {
            EnsureBrush();
            EnsureVisuals();
        }

        void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
            if (m_XrCamera == null)
                m_XrCamera = Camera.main;
            ResolveHandTransforms();
            EnsureBrush();
            EnsureAuxBrushes();
            EnsureToolHud();
            if (m_ToolHud != null)
                m_ToolHud.ToolSelected += OnVrToolSelected;
            EnsureVisuals();
            if (m_Brush != null)
            {
                if (m_TargetRenderer != null)
                    m_Brush.TargetRenderer = m_TargetRenderer;
                if (m_Brush.ScreenRadius < 0.5f)
                    m_Brush.ScreenRadius = m_DefaultScreenRadius;
            }
        }

        void OnDisable()
        {
            if (m_ToolHud != null)
                m_ToolHud.ToolSelected -= OnVrToolSelected;
            SetVisualsEnabled(false);
            GaussianSplatBrush.IsDeleting = false;
            GaussianSplatBrush.IsRestoring = false;
            GaussianSplatBrush.HasValidBrushPosition = false;
            GaussianSplatPaintBrush.IsPainting = false;
            GaussianSplatColorizeBrush.IsColorizing = false;
        }

        void OnVrToolSelected(SplatBoxVRBrushTool tool)
        {
            m_ToolStatusMessage = $"Tool: {m_ToolHud.GetToolLabel(tool)}";
            ShowHud(m_InfoDisplayDuration);
        }

        void OnDestroy()
        {
            if (m_DiscMaterial != null) Destroy(m_DiscMaterial);
            if (m_LineMaterial != null) Destroy(m_LineMaterial);
            if (m_HudMaterial != null) Destroy(m_HudMaterial);
            if (m_DiscMesh != null) Destroy(m_DiscMesh);
        }

        void Update()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;
            if (m_XrCamera == null)
                m_XrCamera = Camera.main;
            if (m_XrCamera == null)
                return;

            EnsureBrush();
            EnsureAuxBrushes();
            EnsureToolHud();
            EnsureVisuals();
            m_Brush.TargetRenderer = m_TargetRenderer;
            SyncAuxBrushTargets();
            ResolveHandTransforms();

            if (!TryGetAimPose(out Vector3 handPos, out Quaternion handRot))
            {
                SetVisualsEnabled(false);
                return;
            }

            SetVisualsEnabled(true);

            Vector3 rayOrigin = handPos + handRot * m_BrushLocalOffset;
            Vector3 rayDir = (handRot * m_AimLocalDirection).normalized;
            if (rayDir.sqrMagnitude < 1e-6f)
                rayDir = handRot * Vector3.forward;

            Vector3 visualPos = rayOrigin + rayDir * Mathf.Max(0.02f, m_BrushVisualDistance);
            m_HasValidHit = true;
            var aimRay = new Ray(rayOrigin, rayDir);
            var camT = m_XrCamera.transform;

            HandleToolHudToggle();

            float screenRadius = m_Brush.ScreenRadius;
            float visualWorldRadius = CalculateWorldRadius(visualPos, m_XrCamera, screenRadius);
            float actionWorldRadius = visualWorldRadius * m_DeleteRadiusMultiplier;
            var activeTool = m_ToolHud != null ? m_ToolHud.ActiveTool : SplatBoxVRBrushTool.EraseBrush;
            bool gripHeld = IsGripPressed();
            var toolColor = gripHeld
                ? (m_ToolHud != null ? m_ToolHud.GetToolColor(SplatBoxVRBrushTool.RestoreBrush) : new Color(0.35f, 1f, 0.45f))
                : (m_ToolHud != null ? m_ToolHud.GetToolColor(activeTool) : m_RingColor);

            GaussianSplatBrush.LastBrushPosition = visualPos;
            GaussianSplatBrush.HasValidBrushPosition = true;
            GaussianSplatBrush.CurrentWorldRadius = actionWorldRadius;
            GaussianSplatBrush.CurrentViewDirection = rayDir;

            bool hudOpen = m_ToolHud != null && m_ToolHud.IsVisible;
            bool pointerOverHud = false;
            bool adjustingRadius = false;

            if (hudOpen)
            {
                m_ToolHud.BindHost(this);
                m_ToolHud.SetFollowRightHand(visualPos, handRot, camT.forward);
                m_ToolHud.UpdateHover(aimRay);
                pointerOverHud = m_ToolHud.IsRayOverHud(aimRay);

                bool hudSelect = IsHudSelectPressed();
                bool hudBack = IsHudBackPressed();
                if (m_ToolHud.TrySelectWithPrimaryButton(aimRay, hudSelect, m_RightHudSelectWasPressed))
                {
                    m_ToolStatusMessage = m_ToolHud.GetStatusMessage();
                    ShowHud(m_InfoDisplayDuration);
                }
                else if (m_ToolHud.TryGoBack(hudBack, m_RightHudBackWasPressed))
                {
                    m_ToolStatusMessage = "Tool HUD: back";
                    ShowHud(m_InfoDisplayDuration);
                }

                var device = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
                if (device.isValid && device.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 stick))
                {
                    bool propertyAdjust = m_ToolHud.IsInPropertyMenu && m_ToolHud.IsPointerOverMenu;
                    if (propertyAdjust && m_ToolHud.TryAdjustHoveredProperty(stick, Time.deltaTime))
                        adjustingRadius = false;
                    else
                        adjustingRadius = HandleThumbstickResize(stick);
                }

                m_ToolHud.RefreshPropertyValueLabels();
                m_RightHudSelectWasPressed = hudSelect;
                m_RightHudBackWasPressed = hudBack;
            }
            else
            {
                m_RightHudSelectWasPressed = IsHudSelectPressed();
                m_RightHudBackWasPressed = IsHudBackPressed();
                adjustingRadius = HandleThumbstickResize();
            }

            bool blockBrushTrigger = hudOpen && pointerOverHud && IsTriggerPressed();
            if (gripHeld)
                HandleGripRestore(visualPos, actionWorldRadius, rayDir);
            else if (!blockBrushTrigger)
                HandleTriggerTool(activeTool, aimRay, visualPos, actionWorldRadius, rayDir, screenRadius);

            UpdateVisuals(rayOrigin, visualPos, visualWorldRadius, camT.forward, toolColor, gripHeld);
            UpdateHud(handPos, handRot, screenRadius, adjustingRadius, activeTool, gripHeld);
        }

        void ResolveHandTransforms()
        {
            if (m_RightHandTransform == null)
            {
                var named = GameObject.Find("Right Hand Model");
                if (named != null)
                    m_RightHandTransform = named.transform;
                else
                {
                    foreach (var t in FindObjectsByType<Transform>())
                    {
                        if (t.name is "Right Hand" or "RightHand" or "Right Controller" or "RightHandController")
                        {
                            m_RightHandTransform = t;
                            break;
                        }
                    }
                }
            }

            if (m_LeftHandTransform == null)
            {
                var named = GameObject.Find("Left Hand Model");
                if (named != null)
                    m_LeftHandTransform = named.transform;
                else
                {
                    foreach (var t in FindObjectsByType<Transform>())
                    {
                        if (t.name is "Left Hand" or "LeftHand" or "Left Controller" or "LeftHandController")
                        {
                            m_LeftHandTransform = t;
                            break;
                        }
                    }
                }
            }
        }

        bool IsHudSelectPressed()
        {
            return IsButtonPressed(m_ControllerNode, CommonUsages.primaryButton) ||
                   IsButtonPressed(m_ControllerNode, CommonUsages.triggerButton);
        }

        static readonly InputFeatureUsage<bool> s_StickClickUsage = new InputFeatureUsage<bool>("Primary2DAxisClick");

        bool IsHudBackPressed()
        {
            var device = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
            if (!device.isValid)
                return false;
            if (device.TryGetFeatureValue(s_StickClickUsage, out bool clicked) && clicked)
                return true;
            return device.TryGetFeatureValue(CommonUsages.secondary2DAxisClick, out bool altClick) && altClick;
        }

        bool TryGetAimPose(out Vector3 position, out Quaternion rotation)
        {
            if (m_RightHandTransform != null)
            {
                position = m_RightHandTransform.position;
                rotation = m_RightHandTransform.rotation;
                return true;
            }

            return TryGetControllerPose(m_ControllerNode, out position, out rotation);
        }

        bool HandleThumbstickResize()
        {
            var device = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
            if (!device.isValid || !device.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 stick))
                return false;
            return HandleThumbstickResize(stick);
        }

        bool HandleThumbstickResize(Vector2 stick)
        {
            if (Mathf.Abs(stick.y) <= m_StickDeadZone)
                return false;

            float delta = stick.y * m_RadiusAdjustSpeed * Time.deltaTime;
            m_Brush.ScreenRadius = Mathf.Clamp(m_Brush.ScreenRadius + delta, 0.1f, m_MaxScreenRadius);
            ShowHud(m_InfoDisplayDuration);
            return true;
        }

        void HandleToolHudToggle()
        {
            bool bPressed = IsButtonPressed(CommonUsages.secondaryButton);
            if (bPressed && !m_BButtonWasPressed && m_ToolHud != null)
            {
                m_ToolHud.ToggleVisible();
                m_ToolStatusMessage = m_ToolHud.IsVisible ? "Tool HUD: shown" : "Tool HUD: hidden";
                ShowHud(m_InfoDisplayDuration);
            }

            m_BButtonWasPressed = bPressed;
        }

        bool IsButtonPressed(InputFeatureUsage<bool> usage) => IsButtonPressed(m_ControllerNode, usage);

        static bool IsButtonPressed(XRNode node, InputFeatureUsage<bool> usage)
        {
            var device = InputDevices.GetDeviceAtXRNode(node);
            return device.isValid && device.TryGetFeatureValue(usage, out bool pressed) && pressed;
        }

        bool IsGripPressed() => IsButtonPressed(CommonUsages.gripButton);

        void HandleGripRestore(Vector3 brushPos, float worldRadius, Vector3 viewDir)
        {
            bool gripHeld = IsGripPressed();
            GaussianSplatBrush.IsRestoring = gripHeld && m_HasValidHit;
            GaussianSplatBrush.IsDeleting = false;
            GaussianSplatPaintBrush.IsPainting = false;
            GaussianSplatColorizeBrush.IsColorizing = false;

            if (!gripHeld)
                return;
            if (Time.time - m_LastActionTime < m_DeleteInterval)
                return;

            m_LastActionTime = Time.time;
            m_Brush.RestoreAtPosition(brushPos, worldRadius, viewDir);
        }

        void HandleTriggerTool(SplatBoxVRBrushTool tool, Ray aimRay, Vector3 brushPos, float worldRadius,
            Vector3 viewDir, float screenRadius)
        {
            bool triggerPressed = IsTriggerPressed() && !IsGripPressed();
            GaussianSplatBrush.IsDeleting = triggerPressed && tool == SplatBoxVRBrushTool.EraseBrush && m_HasValidHit;
            GaussianSplatBrush.IsRestoring = false;
            GaussianSplatPaintBrush.IsPainting = triggerPressed && tool == SplatBoxVRBrushTool.PaintBrush && m_HasValidHit;
            GaussianSplatColorizeBrush.IsColorizing = triggerPressed && tool == SplatBoxVRBrushTool.ColorizeBrush && m_HasValidHit;

            if (!triggerPressed)
                return;
            if (Time.time - m_LastActionTime < m_DeleteInterval)
                return;

            if (m_ToolHud != null && !m_ToolHud.IsVrReady(tool))
            {
                m_ToolStatusMessage = $"{m_ToolHud.GetToolLabel(tool)}: use desktop editor";
                ShowHud(m_InfoDisplayDuration);
                return;
            }

            m_LastActionTime = Time.time;
            switch (tool)
            {
                case SplatBoxVRBrushTool.EraseBrush:
                    if (m_BackfaceCulling)
                        m_Brush.DeleteAtPosition(brushPos, worldRadius, viewDir, m_XrCamera);
                    else
                        m_Brush.DeleteAtPosition(brushPos, worldRadius, viewDir);
                    break;

                case SplatBoxVRBrushTool.PaintBrush:
                    EnsureAuxBrushes();
                    if (m_PaintBrush != null)
                    {
                        m_PaintBrush.ScreenRadius = Mathf.Clamp(screenRadius, 0.1f, 10f);
                        float depth = Vector3.Dot(brushPos - m_XrCamera.transform.position, m_XrCamera.transform.forward);
                        m_PaintBrush.PaintAtRay(aimRay, m_XrCamera, worldRadius, viewDir, Mathf.Max(0.1f, depth));
                    }
                    break;

                case SplatBoxVRBrushTool.ColorizeBrush:
                    EnsureAuxBrushes();
                    if (m_ColorizeBrush != null)
                    {
                        m_ColorizeBrush.ScreenRadius = Mathf.Clamp(screenRadius, 0.1f, 10f);
                        float colorRadius = CalculateWorldRadius(brushPos, m_XrCamera, m_ColorizeBrush.ScreenRadius);
                        m_ColorizeBrush.ColorizeAtPosition(brushPos, colorRadius);
                    }
                    break;

                case SplatBoxVRBrushTool.CloneBrush:
                    if (m_TargetRenderer != null)
                    {
                        Vector3 target = brushPos + viewDir * m_CloneOffset;
                        m_TargetRenderer.CloneSplatsInSphere(brushPos, target, worldRadius, 0f);
                    }
                    break;

                case SplatBoxVRBrushTool.BoxBrush:
                    if (m_TargetRenderer != null)
                    {
                        Vector3 size = Vector3.one * (worldRadius * 2f);
                        Quaternion rot = Quaternion.LookRotation(viewDir, m_XrCamera.transform.up);
                        m_TargetRenderer.DeleteSplatsInBox(brushPos, size, rot);
                    }
                    break;

                case SplatBoxVRBrushTool.CylinderBrush:
                    if (m_TargetRenderer != null)
                        m_TargetRenderer.DeleteSplatsInCylinderBounded(brushPos, worldRadius, worldRadius * 2f, viewDir);
                    break;

                case SplatBoxVRBrushTool.ColorBrush:
                    if (m_TargetRenderer != null)
                        m_TargetRenderer.ColorizeInSphere(brushPos, worldRadius, Color.white, 0.35f, 0.5f);
                    break;

                case SplatBoxVRBrushTool.VortexTool:
                    EnsureVortexAttractor(brushPos);
                    if (m_VortexAttractor != null && m_TargetRenderer != null)
                    {
                        m_TargetRenderer.enableWind = true;
                        m_VortexAttractor.Range = Mathf.Clamp(worldRadius, 0.1f, 20f);
                        m_VortexAttractor.AttractorEnabled = true;
                        m_VortexAttractor.EnsureRegistered();
                    }
                    break;

                default:
                    m_ToolStatusMessage = $"{m_ToolHud?.GetToolLabel(tool) ?? tool.ToString()}: use desktop editor";
                    ShowHud(m_InfoDisplayDuration);
                    break;
            }
        }

        bool IsTriggerPressed()
        {
            var device = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
            return device.isValid &&
                   device.TryGetFeatureValue(CommonUsages.triggerButton, out bool pressed) &&
                   pressed;
        }

        void EnsureBrush()
        {
            if (m_Brush != null)
                return;
            m_Brush = GetComponent<GaussianSplatBrush>();
            if (m_Brush == null)
                m_Brush = gameObject.AddComponent<GaussianSplatBrush>();
            if (m_TargetRenderer != null)
                m_Brush.TargetRenderer = m_TargetRenderer;
        }

        void EnsureAuxBrushes()
        {
            if (m_PaintBrush == null)
            {
                m_PaintBrush = GetComponent<GaussianSplatPaintBrush>();
                if (m_PaintBrush == null)
                    m_PaintBrush = gameObject.AddComponent<GaussianSplatPaintBrush>();
            }
            if (m_ColorizeBrush == null)
            {
                m_ColorizeBrush = GetComponent<GaussianSplatColorizeBrush>();
                if (m_ColorizeBrush == null)
                    m_ColorizeBrush = gameObject.AddComponent<GaussianSplatColorizeBrush>();
            }
            if (m_ColorBrush == null)
            {
                m_ColorBrush = GetComponent<GaussianSplatColorBrush>();
                if (m_ColorBrush == null)
                    m_ColorBrush = gameObject.AddComponent<GaussianSplatColorBrush>();
            }
            SyncAuxBrushTargets();
        }

        void SyncAuxBrushTargets()
        {
            if (m_TargetRenderer == null)
                return;
            if (m_PaintBrush != null) m_PaintBrush.TargetRenderer = m_TargetRenderer;
            if (m_ColorizeBrush != null) m_ColorizeBrush.TargetRenderer = m_TargetRenderer;
            if (m_ColorBrush != null) m_ColorBrush.TargetRenderer = m_TargetRenderer;
        }

        void EnsureToolHud()
        {
            if (m_ToolHud == null)
                m_ToolHud = GetComponent<SplatBoxVRBrushHud>();
            if (m_ToolHud == null)
                m_ToolHud = gameObject.AddComponent<SplatBoxVRBrushHud>();
            if (m_XrCamera != null)
                m_ToolHud.EnsureBuilt(m_XrCamera);
        }

        void EnsureVortexAttractor(Vector3 worldPos)
        {
            if (m_VortexAttractor == null)
                m_VortexAttractor = FindAnyObjectByType<GaussianSplatAttractor>();
            if (m_VortexAttractor == null)
            {
                var go = new GameObject("VR_VortexAttractor");
                go.transform.SetParent(transform, false);
                m_VortexAttractor = go.AddComponent<GaussianSplatAttractor>();
            }
            m_VortexAttractor.transform.position = worldPos;
        }

        void EnsureVisuals()
        {
            ResolveVisualReferences();

            if (m_LineMaterial == null)
                m_LineMaterial = CreateLineMaterial();
            if (m_DiscMaterial == null)
                m_DiscMaterial = CreateDiscMaterial();

            if (m_RayLine == null)
            {
                var go = CreateVisualChild("VRErase_Ray");
                m_RayLine = go.AddComponent<LineRenderer>();
                m_RayLine.positionCount = 2;
                m_RayLine.useWorldSpace = true;
                ConfigureLine(m_RayLine, 0.004f);
            }

            if (m_BrushRing == null)
            {
                var go = CreateVisualChild("VRErase_BrushRing");
                m_BrushRing = go.AddComponent<LineRenderer>();
                m_BrushRing.loop = true;
                m_BrushRing.useWorldSpace = true;
                ConfigureLine(m_BrushRing, m_RingLineWidth);
            }

            if (m_FalloffRing == null)
            {
                var go = CreateVisualChild("VRErase_FalloffRing");
                m_FalloffRing = go.AddComponent<LineRenderer>();
                m_FalloffRing.loop = true;
                m_FalloffRing.useWorldSpace = true;
                ConfigureLine(m_FalloffRing, m_RingLineWidth * 0.65f);
            }

            if (m_BrushDisc == null)
            {
                var go = CreateVisualChild("VRErase_BrushDisc");
                var meshFilter = go.AddComponent<MeshFilter>();
                m_BrushDisc = go.AddComponent<MeshRenderer>();
                m_DiscMesh ??= CreateDiscMesh(m_RingSegments);
                meshFilter.sharedMesh = m_DiscMesh;
                m_BrushDisc.shadowCastingMode = ShadowCastingMode.Off;
                m_BrushDisc.receiveShadows = false;
            }

            EnsureHud();
            ApplyVisualMaterials();
        }

        void EnsureHud()
        {
            if (m_HudText != null)
                return;

            var go = CreateVisualChild("VRErase_Hud");
            m_HudText = go.AddComponent<TextMesh>();
            m_HudText.anchor = TextAnchor.MiddleLeft;
            m_HudText.alignment = TextAlignment.Left;
            m_HudText.fontSize = m_HudFontSize;
            m_HudText.characterSize = m_HudCharacterSize;
            m_HudText.lineSpacing = 1.05f;
            m_HudText.color = Color.white;

            var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf")
                ?? Resources.GetBuiltinResource<Font>("Arial.ttf");
            if (font != null)
            {
                m_HudText.font = font;
                var mr = go.GetComponent<MeshRenderer>();
                if (mr != null && font.material != null)
                {
                    m_HudMaterial = new Material(font.material) { name = "VREraseBrush_Hud" };
                    ConfigureHudMaterial(m_HudMaterial);
                    mr.sharedMaterial = m_HudMaterial;
                }
            }

            go.SetActive(false);
        }

        void ShowHud(float duration)
        {
            m_InfoHideTime = Time.time + duration;
            if (m_HudText != null)
                m_HudText.gameObject.SetActive(true);
        }

        void UpdateHud(Vector3 handPos, Quaternion handRot, float screenRadius, bool adjustingRadius, SplatBoxVRBrushTool activeTool, bool gripHeld)
        {
            if (m_HudText == null)
                return;

            if (Time.time > m_InfoHideTime)
            {
                m_HudText.gameObject.SetActive(false);
                return;
            }

            if (!m_HudText.gameObject.activeSelf)
                return;

            var camT = m_XrCamera.transform;
            var hudT = m_HudText.transform;
            hudT.position = handPos + handRot * m_HudLocalOffset   ;
            hudT.rotation = Quaternion.LookRotation(camT.forward, camT.up);

            m_HudText.characterSize = m_HudCharacterSize;
            m_HudText.fontSize = m_HudFontSize;

            int totalSplats = m_TargetRenderer != null ? m_TargetRenderer.splatCount : 0;
            uint deletedSplats = m_TargetRenderer != null ? m_TargetRenderer.editDeletedSplats : 0u;
            int remainingSplats = Mathf.Max(0, totalSplats - (int)deletedSplats);
            string backfaceLabel = m_BackfaceCulling ? "ON (front layer)" : "OFF (through depth)";

            string toolLabel = m_ToolHud != null ? m_ToolHud.GetToolLabel(activeTool) : "Erase";
            m_HudText.text =
                (adjustingRadius ? "Brush Radius\n" : $"{toolLabel}\n") +
                $"Radius: {screenRadius:F1}\n" +
                $"Delete: {screenRadius * m_DeleteRadiusMultiplier:F1} ({m_DeleteRadiusMultiplier:F1}x)\n" +
                $"Splats: {remainingSplats:N0} / {totalSplats:N0}\n" +
                $"Deleted: {deletedSplats:N0}\n" +
                $"Backface: {backfaceLabel}\n" +
                $"Restore [Grip]: {(gripHeld ? "ON" : "hold")}\n" +
                $"Tool HUD [B]: {(m_ToolHud != null && m_ToolHud.IsVisible ? "shown" : "hidden")}\n" +
                $"Menu [Trigger/A]: {toolLabel}" +
                (string.IsNullOrEmpty(m_ToolStatusMessage) ? "" : $"\n{m_ToolStatusMessage}");
        }

        static void ConfigureHudMaterial(Material mat)
        {
            mat.SetInt("_ZWrite", 0);
            mat.SetInt("_ZTest", (int)CompareFunction.Always);
            if (mat.HasProperty("_Cull"))
                mat.SetInt("_Cull", (int)CullMode.Off);
            mat.renderQueue = (int)RenderQueue.Overlay;
        }

        void ResolveVisualReferences()
        {
            if (m_RayLine == null)
                m_RayLine = FindChildComponent<LineRenderer>("VRErase_Ray");
            if (m_BrushRing == null)
                m_BrushRing = FindChildComponent<LineRenderer>("VRErase_BrushRing");
            if (m_FalloffRing == null)
                m_FalloffRing = FindChildComponent<LineRenderer>("VRErase_FalloffRing");
            if (m_BrushDisc == null)
                m_BrushDisc = FindChildComponent<MeshRenderer>("VRErase_BrushDisc");
        }

        GameObject CreateVisualChild(string childName)
        {
            var existing = transform.Find(childName);
            if (existing != null)
                return existing.gameObject;
            var go = new GameObject(childName);
            go.transform.SetParent(transform, false);
            return go;
        }

        T FindChildComponent<T>(string childName) where T : Component
        {
            var child = transform.Find(childName);
            return child != null ? child.GetComponent<T>() : null;
        }

        void ApplyVisualMaterials()
        {
            if (m_LineMaterial == null || m_DiscMaterial == null)
                return;

            if (m_RayLine != null)
                m_RayLine.sharedMaterial = m_LineMaterial;
            if (m_BrushRing != null)
                m_BrushRing.sharedMaterial = m_LineMaterial;
            if (m_FalloffRing != null)
                m_FalloffRing.sharedMaterial = m_LineMaterial;
            if (m_BrushDisc != null)
                m_BrushDisc.sharedMaterial = m_DiscMaterial;
        }

        static void ConfigureLine(LineRenderer line, float width)
        {
            line.startWidth = width;
            line.endWidth = width;
            line.numCapVertices = 4;
            line.alignment = LineAlignment.View;
        }

        void SetVisualsEnabled(bool enabled)
        {
            if (m_RayLine != null) m_RayLine.enabled = enabled;
            if (m_BrushRing != null) m_BrushRing.enabled = enabled;
            if (m_FalloffRing != null) m_FalloffRing.enabled = enabled;
            if (m_BrushDisc != null) m_BrushDisc.enabled = enabled;
            if (m_HudText != null && !enabled)
                m_HudText.gameObject.SetActive(false);
        }

        void UpdateVisuals(Vector3 rayStart, Vector3 visualPos, float visualWorldRadius, Vector3 camForward, Color toolColor, bool gripHeld)
        {
            if (m_RayLine != null)
            {
                m_RayLine.SetPosition(0, rayStart);
                m_RayLine.SetPosition(1, visualPos);
                m_RayLine.startColor = toolColor;
                m_RayLine.endColor = toolColor;
            }

            Vector3 discNormal = -camForward.normalized;
            bool activeStroke = gripHeld || GaussianSplatBrush.IsDeleting || GaussianSplatPaintBrush.IsPainting || GaussianSplatColorizeBrush.IsColorizing;
            var ringColor = activeStroke ? Color.Lerp(toolColor * 0.6f, Color.black, 0.25f) : toolColor;
            int segments = Mathf.Max(8, m_RingSegments);
            UpdateRing(m_BrushRing, visualPos, discNormal, visualWorldRadius, ringColor, segments);

            float falloff = m_Brush != null ? Mathf.Clamp01(m_Brush.BrushFalloff) : 0f;
            if (m_FalloffRing != null)
            {
                bool showFalloff = falloff > 0.001f;
                m_FalloffRing.enabled = showFalloff;
                if (showFalloff)
                {
                    var falloffColor = new Color(ringColor.r, ringColor.g, ringColor.b, ringColor.a * 0.55f);
                    UpdateRing(m_FalloffRing, visualPos, discNormal, visualWorldRadius * falloff, falloffColor, segments);
                }
            }

            if (m_BrushDisc != null)
            {
                var t = m_BrushDisc.transform;
                t.position = visualPos;
                t.rotation = Quaternion.FromToRotation(Vector3.up, discNormal);
                t.localScale = Vector3.one * Mathf.Max(visualWorldRadius, 0.001f);
                if (m_DiscMaterial != null)
                {
                    var fill = new Color(toolColor.r, toolColor.g, toolColor.b, m_DiscFillColor.a);
                    if (activeStroke)
                        fill.a = Mathf.Min(1f, fill.a * 2.5f);
                    SetMaterialColor(m_DiscMaterial, fill);
                }
            }
        }

        static void UpdateRing(LineRenderer ring, Vector3 center, Vector3 discNormal, float radius, Color color, int segments)
        {
            if (ring == null) return;
            ring.positionCount = segments;
            Vector3 up = Mathf.Abs(Vector3.Dot(discNormal, Vector3.up)) > 0.95f ? Vector3.right : Vector3.up;
            Vector3 tangent = Vector3.Cross(discNormal, up).normalized;
            Vector3 bitangent = Vector3.Cross(discNormal, tangent).normalized;
            for (int i = 0; i < segments; i++)
            {
                float angle = (i / (float)segments) * Mathf.PI * 2f;
                Vector3 offset = (Mathf.Cos(angle) * tangent + Mathf.Sin(angle) * bitangent) * radius;
                ring.SetPosition(i, center + offset);
            }
            ring.startColor = color;
            ring.endColor = color;
        }

        static Mesh CreateDiscMesh(int segments)
        {
            segments = Mathf.Max(8, segments);
            var mesh = new Mesh { name = "VREraseBrushDisc" };
            var verts = new Vector3[segments + 1];
            var tris = new int[segments * 3];
            verts[0] = Vector3.zero;
            for (int i = 0; i < segments; i++)
            {
                float angle = (i / (float)segments) * Mathf.PI * 2f;
                verts[i + 1] = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
            }
            for (int i = 0; i < segments; i++)
            {
                int next = i + 2;
                if (next > segments) next = 1;
                tris[i * 3] = 0;
                tris[i * 3 + 1] = i + 1;
                tris[i * 3 + 2] = next;
            }
            mesh.vertices = verts;
            mesh.triangles = tris;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        static Shader FindLineShader()
        {
            return Shader.Find("Universal Render Pipeline/Particles/Unlit")
                ?? Shader.Find("Particles/Standard Unlit")
                ?? Shader.Find("Unlit/Color")
                ?? Shader.Find("Sprites/Default");
        }

        static Shader FindDiscShader()
        {
            return Shader.Find("Universal Render Pipeline/Unlit")
                ?? Shader.Find("Unlit/Color")
                ?? Shader.Find("Sprites/Default");
        }

        static Material CreateLineMaterial()
        {
            var shader = FindLineShader();
            var mat = new Material(shader) { name = "VREraseBrush_Line" };
            ConfigureLineMaterial(mat, Color.white);
            return mat;
        }

        static Material CreateDiscMaterial()
        {
            var shader = FindDiscShader();
            var mat = new Material(shader) { name = "VREraseBrush_Disc" };
            ConfigureTransparentUnlitMaterial(mat, new Color(1f, 0.3f, 0.3f, 0.15f));
            return mat;
        }

        static void ConfigureLineMaterial(Material mat, Color tint)
        {
            SetMaterialColor(mat, tint);
            mat.SetInt("_ZWrite", 0);
            mat.SetInt("_ZTest", (int)CompareFunction.Always);
            if (mat.HasProperty("_Cull"))
                mat.SetInt("_Cull", (int)CullMode.Off);
            mat.renderQueue = (int)RenderQueue.Overlay;
        }

        static void ConfigureTransparentUnlitMaterial(Material mat, Color color)
        {
            SetMaterialColor(mat, color);

            if (mat.shader.name.Contains("Universal Render Pipeline"))
            {
                if (mat.HasProperty("_Surface"))
                    mat.SetFloat("_Surface", 1f);
                if (mat.HasProperty("_Blend"))
                    mat.SetFloat("_Blend", 0f);
                mat.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
                mat.EnableKeyword("_ALPHAPREMULTIPLY_ON");
                mat.SetOverrideTag("RenderType", "Transparent");
            }

            mat.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            mat.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            mat.SetInt("_ZWrite", 0);
            mat.SetInt("_ZTest", (int)CompareFunction.Always);
            if (mat.HasProperty("_Cull"))
                mat.SetInt("_Cull", (int)CullMode.Off);
            mat.renderQueue = (int)RenderQueue.Transparent;
        }

        static void SetMaterialColor(Material mat, Color color)
        {
            if (mat.HasProperty("_BaseColor"))
                mat.SetColor("_BaseColor", color);
            if (mat.HasProperty("_Color"))
                mat.SetColor("_Color", color);
            mat.color = color;
        }

        static float CalculateWorldRadius(Vector3 worldPos, Camera cam, float screenRadius)
        {
            float distance = Vector3.Distance(cam.transform.position, worldPos);
            float fov = cam.fieldOfView * Mathf.Deg2Rad;
            float worldPerPixel = (2f * distance * Mathf.Tan(fov * 0.5f)) / Mathf.Max(1f, cam.pixelHeight);
            return screenRadius * worldPerPixel;
        }

        bool TryGetControllerPose(XRNode node, out Vector3 position, out Quaternion rotation)
        {
            position = Vector3.zero;
            rotation = Quaternion.identity;

            var device = InputDevices.GetDeviceAtXRNode(node);
            if (!device.isValid)
                return false;

            Vector3 localPos = Vector3.zero;
            Quaternion localRot = Quaternion.identity;
            bool hasPose =
                device.TryGetFeatureValue(s_PointerPositionUsage, out localPos) &&
                device.TryGetFeatureValue(s_PointerRotationUsage, out localRot);

            if (!hasPose)
            {
                hasPose =
                    device.TryGetFeatureValue(CommonUsages.devicePosition, out localPos) &&
                    device.TryGetFeatureValue(CommonUsages.deviceRotation, out localRot);
            }

            if (!hasPose)
                return false;

            if (TryGetTrackingToWorld(out Matrix4x4 trackingToWorld))
            {
                position = trackingToWorld.MultiplyPoint3x4(localPos);
                rotation = trackingToWorld.rotation * localRot;
            }
            else
            {
                position = localPos;
                rotation = localRot;
            }

            return true;
        }

        bool TryGetTrackingToWorld(out Matrix4x4 trackingToWorld)
        {
            trackingToWorld = Matrix4x4.identity;
            if (m_XrCamera == null)
                return false;

            var head = InputDevices.GetDeviceAtXRNode(XRNode.CenterEye);
            if (!head.isValid ||
                !head.TryGetFeatureValue(CommonUsages.devicePosition, out Vector3 headPos) ||
                !head.TryGetFeatureValue(CommonUsages.deviceRotation, out Quaternion headRot))
                return false;

            Matrix4x4 hmdTracking = Matrix4x4.TRS(headPos, headRot, Vector3.one);
            var camT = m_XrCamera.transform;
            trackingToWorld = Matrix4x4.TRS(camT.position, camT.rotation, Vector3.one) * hmdTracking.inverse;
            return true;
        }

#if UNITY_EDITOR
        [UnityEditor.MenuItem("SplatBox/VR/Add Erase Brush To Main Camera")]
        static void MenuAddToMainCamera()
        {
            var cam = Camera.main ?? UnityEngine.Object.FindAnyObjectByType<Camera>();
            if (cam == null)
            {
                Debug.LogWarning("[SplatBox] No camera found to attach VR splat brush.");
                return;
            }
            if (cam.GetComponent<SplatBoxVREraseBrush>() != null)
            {
                Debug.Log("[SplatBox] VR splat brush already on " + cam.name);
                return;
            }
            UnityEditor.Undo.AddComponent<SplatBoxVREraseBrush>(cam.gameObject);
            Debug.Log("[SplatBox] Added SplatBoxVREraseBrush (tool palette + erase/paint/colorize/...) to " + cam.name);
        }
#endif
    }
}
