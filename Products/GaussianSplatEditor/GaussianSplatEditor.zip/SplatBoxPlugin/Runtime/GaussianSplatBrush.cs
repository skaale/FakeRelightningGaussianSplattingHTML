// SPDX-License-Identifier: MIT

using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatBrush : MonoBehaviour
    {
        private const string PREFS_KEY_SCREEN_RADIUS = "GaussianSplatBrush.ScreenRadius";
        
        [SerializeField] [Range(0.1f, 50f)] private float m_ScreenRadius = 1f;
        [SerializeField] [Range(0.0f, 1.0f)] private float m_BrushFalloff = 0.0f;
        [SerializeField] [Range(0.0f, 1.0f)] private float m_NoiseStrength = 0.0f;
        [SerializeField] [Range(0.1f, 10.0f)] private float m_NoiseScale = 1.0f;
        [SerializeField] private bool m_BackfaceCulling = true;
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;

        [Header("Color Filter")]
        [SerializeField] private bool m_UseColorFilter = false;
        [SerializeField] private Color m_FilterColor = Color.white;
        [SerializeField] [Range(0.01f, 1.0f)] private float m_ColorThreshold = 0.1f;
        
        public float ScreenRadius
        {
            get => m_ScreenRadius;
            set
            {
                m_ScreenRadius = Mathf.Clamp(value, 0.1f, 50f);
                SaveScreenRadius();
            }
        }
        
        /// <summary>
        /// Reloads the ScreenRadius from saved preferences. Useful when component already exists.
        /// </summary>
        public void ReloadScreenRadius()
        {
            LoadScreenRadius();
        }
        
        public float BrushFalloff
        {
            get => m_BrushFalloff;
            set => m_BrushFalloff = Mathf.Clamp01(value);
        }
        
        public float NoiseStrength
        {
            get => m_NoiseStrength;
            set => m_NoiseStrength = Mathf.Clamp01(value);
        }
        
        public float NoiseScale
        {
            get => m_NoiseScale;
            set => m_NoiseScale = Mathf.Clamp(value, 0.1f, 10.0f);
        }
        
        public bool BackfaceCulling
        {
            get => m_BackfaceCulling;
            set => m_BackfaceCulling = value;
        }

        public bool UseColorFilter
        {
            get => m_UseColorFilter;
            set => m_UseColorFilter = value;
        }

        public Color FilterColor
        {
            get => m_FilterColor;
            set => m_FilterColor = value;
        }

        public float ColorThreshold
        {
            get => m_ColorThreshold;
            set => m_ColorThreshold = Mathf.Clamp(value, 0.01f, 1.0f);
        }
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public static bool IsBrushModeActive { get; set; } = false;
        public static Vector3 LastBrushPosition { get; set; }
        public static bool HasValidBrushPosition { get; set; } = false;
        public static bool IsDeleting { get; set; } = false;
        public static bool IsRestoring { get; set; } = false;
        public static float CurrentWorldRadius { get; set; } = 0.5f;
        public static Vector3 CurrentViewDirection { get; set; } = Vector3.forward;
        
        // Line mode (Shift+Click)
        public static bool IsLineMode { get; set; } = false;
        public static Vector3 LineStartPosition { get; set; }
        public static float LineStartRadius { get; set; }
        public static Vector3 LineStartViewDirection { get; set; }
        public static Vector2 LineStartScreenPosition { get; set; }
        public static float LineStartScreenRadius { get; set; }
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
            
            LoadScreenRadius();
        }
        
#if UNITY_EDITOR
        private void OnValidate()
        {
            // Save when value is changed in inspector
            SaveScreenRadius();
        }
#endif
        
        private void LoadScreenRadius()
        {
#if UNITY_EDITOR
            if (EditorPrefs.HasKey(PREFS_KEY_SCREEN_RADIUS))
            {
                float savedValue = EditorPrefs.GetFloat(PREFS_KEY_SCREEN_RADIUS, m_ScreenRadius);
                m_ScreenRadius = Mathf.Clamp(savedValue, 0.1f, 50f);
            }
#else
            if (PlayerPrefs.HasKey(PREFS_KEY_SCREEN_RADIUS))
            {
                float savedValue = PlayerPrefs.GetFloat(PREFS_KEY_SCREEN_RADIUS, m_ScreenRadius);
                m_ScreenRadius = Mathf.Clamp(savedValue, 0.1f, 50f);
            }
#endif
        }
        
        private void SaveScreenRadius()
        {
#if UNITY_EDITOR
            EditorPrefs.SetFloat(PREFS_KEY_SCREEN_RADIUS, m_ScreenRadius);
#else
            PlayerPrefs.SetFloat(PREFS_KEY_SCREEN_RADIUS, m_ScreenRadius);
            PlayerPrefs.Save();
#endif
        }
        
        public void DeleteAtPosition(Vector3 worldPosition, float worldRadius, Vector3 viewDirection)
        {
            DeleteAtPosition(worldPosition, worldRadius, viewDirection, null);
        }
        
        public void DeleteAtPosition(Vector3 worldPosition, float worldRadius, Vector3 viewDirection, Camera cam)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
                return;
            
            if (m_BackfaceCulling && cam != null)
                m_TargetRenderer.EditDeleteCylinderWithBackfaceCulling(worldPosition, worldRadius, viewDirection, cam, m_BrushFalloff, m_NoiseStrength, m_NoiseScale, m_UseColorFilter, m_FilterColor, m_ColorThreshold);
            else
                m_TargetRenderer.EditDeleteCylinder(worldPosition, worldRadius, viewDirection, m_BrushFalloff, m_NoiseStrength, m_NoiseScale, m_UseColorFilter, m_FilterColor, m_ColorThreshold);
        }
        
        /// <summary>
        /// Delete splats in screen-space with backface culling (only deletes visible front layer)
        /// </summary>
        /// <param name="screenPos">Screen position in GUI coordinates (from Event.mousePosition)</param>
        /// <param name="screenRadius">Brush radius in screen pixels</param>
        public void DeleteAtScreenPosition(Vector2 screenPos, float screenRadius, Camera cam)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
                return;
            
            m_TargetRenderer.EditDeleteSplatsInScreenCircle(screenPos, screenRadius, cam, m_BackfaceCulling, m_BrushFalloff, m_NoiseStrength, m_NoiseScale, m_UseColorFilter, m_FilterColor, m_ColorThreshold);
        }
        
        public void DeleteLine(Vector3 startPos, Vector3 endPos, float startRadius, float endRadius, Vector3 startViewDir, Vector3 endViewDir)
        {
            DeleteLine(startPos, endPos, startRadius, endRadius, startViewDir, endViewDir, null);
        }
        
        public void DeleteLine(Vector3 startPos, Vector3 endPos, float startRadius, float endRadius, Vector3 startViewDir, Vector3 endViewDir, Camera cam)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
                return;
            
            if (m_BackfaceCulling && cam != null)
            {
                // For line mode with backface culling, we use screen-space line deletion
                Vector3 startScreenPos3D = cam.WorldToScreenPoint(startPos);
                Vector3 endScreenPos3D = cam.WorldToScreenPoint(endPos);
                
                if (startScreenPos3D.z > 0 && endScreenPos3D.z > 0)
                {
                    Vector2 startScreenPos = new Vector2(startScreenPos3D.x, cam.pixelHeight - startScreenPos3D.y);
                    Vector2 endScreenPos = new Vector2(endScreenPos3D.x, cam.pixelHeight - endScreenPos3D.y);
                    
                    // Estimate screen radii
                    float startDist = startScreenPos3D.z;
                    float endDist = endScreenPos3D.z;
                    float screenHeight = cam.pixelHeight;
                    float fovFact = screenHeight * 0.5f / Mathf.Tan(cam.fieldOfView * 0.5f * Mathf.Deg2Rad);
                    float startRadiusPx = (startRadius / startDist) * fovFact;
                    float endRadiusPx = (endRadius / endDist) * fovFact;
                    
                    DeleteLineAtScreenPosition(startScreenPos, endScreenPos, startRadiusPx, endRadiusPx, cam);
                    return;
                }
            }
            
            float distance = Vector3.Distance(startPos, endPos);
            float avgRadius = (startRadius + endRadius) * 2.5f;
            int steps = Mathf.Max(1, Mathf.CeilToInt(distance / (avgRadius * 2.5f)));
            
            for (int i = 0; i <= steps; i++)
            {
                float t = (float)i / steps;
                Vector3 pos = Vector3.Lerp(startPos, endPos, t);
                float radius = Mathf.Lerp(startRadius, endRadius, t);
                Vector3 viewDir = Vector3.Slerp(startViewDir, endViewDir, t).normalized;
                
                m_TargetRenderer.EditDeleteCylinder(pos, radius, viewDir, m_BrushFalloff, m_NoiseStrength, m_NoiseScale, m_UseColorFilter, m_FilterColor, m_ColorThreshold);
            }
        }
        
        /// <summary>
        /// Delete splats along a line in screen-space with backface culling
        /// </summary>
        public void DeleteLineAtScreenPosition(Vector2 startScreenPos, Vector2 endScreenPos, float startRadius, float endRadius, Camera cam)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
                return;
            
            float distance = Vector2.Distance(startScreenPos, endScreenPos);
            float avgRadius = (startRadius + endRadius) * 0.5f;
            int steps = Mathf.Max(1, Mathf.CeilToInt(distance / (avgRadius * 0.5f)));
            
            for (int i = 0; i <= steps; i++)
            {
                float t = (float)i / steps;
                Vector2 pos = Vector2.Lerp(startScreenPos, endScreenPos, t);
                float radius = Mathf.Lerp(startRadius, endRadius, t);
                
                m_TargetRenderer.EditDeleteSplatsInScreenCircle(pos, radius, cam, m_BackfaceCulling, m_BrushFalloff, m_NoiseStrength, m_NoiseScale, m_UseColorFilter, m_FilterColor, m_ColorThreshold);
            }
        }
        
        public void RestoreAtPosition(Vector3 worldPosition, float worldRadius, Vector3 viewDirection)
        {
            if (m_TargetRenderer == null)
                return;
            
            m_TargetRenderer.EditRestoreCylinder(worldPosition, worldRadius, viewDirection);
        }
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup;
    }
}
