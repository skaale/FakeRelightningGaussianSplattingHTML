// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Records and plays back splat animation by capturing position keyframes
    /// </summary>
    [Serializable]
    public class SplatAnimationClip
    {
        public string clipName = "New Recording";
        public float duration;
        public float recordFPS = 30f;
        public int splatCount;
        public List<SplatKeyframe> keyframes = new List<SplatKeyframe>();
        
        [Serializable]
        public struct SplatKeyframe
        {
            public float time;
            public Vector3[] positions; // Positions for all splats at this time
        }
        
        public bool IsValid => keyframes.Count >= 2 && splatCount > 0;
    }
    
    /// <summary>
    /// Component that handles recording and playback of splat animations
    /// </summary>
    [ExecuteAlways] // Enables Update in edit mode
    public class GaussianSplatAnimationRecorder : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        
        [Header("Recording Settings")]
        [SerializeField] private float m_RecordFPS = 30f;
        [SerializeField] private float m_MaxRecordDuration = 30f;
        
        [Header("Playback Settings")]
        [SerializeField] private float m_PlaybackSpeed = 1f;
        [SerializeField] private bool m_Loop = true;
        [SerializeField] private bool m_PingPong = false;
        
        // Current clip
        private SplatAnimationClip m_CurrentClip;
        private Vector3[] m_OriginalPositions; // Store original positions before playback
        
        // Recording state
        private bool m_IsRecording;
        private float m_RecordStartTime;
        private float m_LastRecordTime;
        
        // Playback state
        private bool m_IsPlaying;
        private bool m_IsPaused;
        private float m_PlaybackTime;
        private bool m_PlayingReverse;
        
        // Editor timing (use realtimeSinceStartup for edit mode)
        private float m_LastUpdateTime;
        
        // Cached data for efficient readback
        private Vector3[] m_PositionReadbackBuffer;
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public float RecordFPS
        {
            get => m_RecordFPS;
            set => m_RecordFPS = Mathf.Clamp(value, 1f, 60f);
        }
        
        public float MaxRecordDuration
        {
            get => m_MaxRecordDuration;
            set => m_MaxRecordDuration = Mathf.Clamp(value, 1f, 300f);
        }
        
        public float PlaybackSpeed
        {
            get => m_PlaybackSpeed;
            set => m_PlaybackSpeed = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public bool Loop
        {
            get => m_Loop;
            set => m_Loop = value;
        }
        
        public bool PingPong
        {
            get => m_PingPong;
            set => m_PingPong = value;
        }
        
        public bool IsRecording => m_IsRecording;
        public bool IsPlaying => m_IsPlaying;
        public bool IsPaused => m_IsPaused;
        public float PlaybackTime => m_PlaybackTime;
        public float ClipDuration => m_CurrentClip?.duration ?? 0f;
        public int KeyframeCount => m_CurrentClip?.keyframes.Count ?? 0;
        public bool HasClip => m_CurrentClip != null && m_CurrentClip.IsValid;
        
        public float PlaybackProgress => m_CurrentClip != null && m_CurrentClip.duration > 0 
            ? m_PlaybackTime / m_CurrentClip.duration 
            : 0f;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = GetComponent<SplatBoxRenderer>();
            m_LastUpdateTime = Time.realtimeSinceStartup;
        }
        
        private void Update()
        {
            // Calculate delta time (works in both edit and play mode)
            float currentTime = Time.realtimeSinceStartup;
            float deltaTime = currentTime - m_LastUpdateTime;
            m_LastUpdateTime = currentTime;
            
            // Clamp delta to avoid jumps
            deltaTime = Mathf.Clamp(deltaTime, 0f, 0.1f);
            
            if (m_IsRecording)
                UpdateRecording();
            
            if (m_IsPlaying && !m_IsPaused)
                UpdatePlayback(deltaTime);
        }
        
        #region Recording
        
        /// <summary>
        /// Start recording splat positions
        /// </summary>
        public bool StartRecording()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                Debug.LogWarning("AnimationRecorder: No valid renderer to record");
                return false;
            }
            
            if (m_IsPlaying)
                StopPlayback();
            
            int splatCount = m_TargetRenderer.splatCount;
            if (splatCount <= 0)
            {
                Debug.LogWarning("AnimationRecorder: No splats to record");
                return false;
            }
            
            // Create new clip
            m_CurrentClip = new SplatAnimationClip
            {
                clipName = $"Recording_{DateTime.Now:HHmmss}",
                recordFPS = m_RecordFPS,
                splatCount = splatCount
            };
            
            // Initialize readback buffer
            m_PositionReadbackBuffer = new Vector3[splatCount];
            
            // Store original positions
            m_OriginalPositions = new Vector3[splatCount];
            ReadCurrentPositions(m_OriginalPositions);
            
            m_IsRecording = true;
            m_RecordStartTime = Time.realtimeSinceStartup;
            m_LastRecordTime = -1f;
            m_LastUpdateTime = Time.realtimeSinceStartup;
            
            // Record first keyframe immediately
            RecordKeyframe(0f);
            
            Debug.Log($"AnimationRecorder: Started recording ({splatCount} splats at {m_RecordFPS} FPS)");
            return true;
        }
        
        /// <summary>
        /// Stop recording and finalize the clip
        /// </summary>
        public SplatAnimationClip StopRecording()
        {
            if (!m_IsRecording)
                return m_CurrentClip;
            
            m_IsRecording = false;
            
            if (m_CurrentClip != null && m_CurrentClip.keyframes.Count > 0)
            {
                m_CurrentClip.duration = m_CurrentClip.keyframes[m_CurrentClip.keyframes.Count - 1].time;
                Debug.Log($"AnimationRecorder: Stopped recording. Duration: {m_CurrentClip.duration:F2}s, Keyframes: {m_CurrentClip.keyframes.Count}");
            }
            
            return m_CurrentClip;
        }
        
        private void UpdateRecording()
        {
            float elapsed = Time.realtimeSinceStartup - m_RecordStartTime;
            
            // Check max duration
            if (elapsed >= m_MaxRecordDuration)
            {
                StopRecording();
                return;
            }
            
            // Check if it's time for a new keyframe
            float frameInterval = 1f / m_RecordFPS;
            if (elapsed - m_LastRecordTime >= frameInterval)
            {
                RecordKeyframe(elapsed);
                m_LastRecordTime = elapsed;
            }
        }
        
        private void RecordKeyframe(float time)
        {
            if (m_CurrentClip == null || m_PositionReadbackBuffer == null)
                return;
            
            // Read current positions from GPU
            ReadCurrentPositions(m_PositionReadbackBuffer);
            
            // Create keyframe with a copy of the positions
            var keyframe = new SplatAnimationClip.SplatKeyframe
            {
                time = time,
                positions = new Vector3[m_PositionReadbackBuffer.Length]
            };
            Array.Copy(m_PositionReadbackBuffer, keyframe.positions, m_PositionReadbackBuffer.Length);
            
            m_CurrentClip.keyframes.Add(keyframe);
        }
        
        private void ReadCurrentPositions(Vector3[] buffer)
        {
            if (m_TargetRenderer == null || buffer == null)
                return;
            
            m_TargetRenderer.ReadSplatPositions(buffer);
        }
        
        #endregion
        
        #region Playback
        
        /// <summary>
        /// Start playback from the beginning
        /// </summary>
        public bool StartPlayback()
        {
            if (m_CurrentClip == null || !m_CurrentClip.IsValid)
            {
                Debug.LogWarning("AnimationRecorder: No valid clip to play");
                return false;
            }
            
            if (m_IsRecording)
                StopRecording();
            
            // Store current positions as original (for restoration later)
            if (m_OriginalPositions == null || m_OriginalPositions.Length != m_CurrentClip.splatCount)
            {
                m_OriginalPositions = new Vector3[m_CurrentClip.splatCount];
                ReadCurrentPositions(m_OriginalPositions);
            }
            
            m_IsPlaying = true;
            m_IsPaused = false;
            m_PlaybackTime = 0f;
            m_PlayingReverse = false;
            m_LastUpdateTime = Time.realtimeSinceStartup;
            
            // Apply first frame
            ApplyKeyframeAtTime(0f);
            
            Debug.Log($"AnimationRecorder: Started playback (Duration: {m_CurrentClip.duration:F2}s)");
            return true;
        }
        
        /// <summary>
        /// Pause/resume playback
        /// </summary>
        public void TogglePause()
        {
            if (!m_IsPlaying) return;
            m_IsPaused = !m_IsPaused;
        }
        
        public void Pause() => m_IsPaused = true;
        public void Resume() => m_IsPaused = false;
        
        /// <summary>
        /// Stop playback and optionally restore original positions
        /// </summary>
        public void StopPlayback(bool restoreOriginal = false)
        {
            m_IsPlaying = false;
            m_IsPaused = false;
            m_PlaybackTime = 0f;
            
            if (restoreOriginal && m_OriginalPositions != null && m_TargetRenderer != null)
            {
                m_TargetRenderer.WriteSplatPositions(m_OriginalPositions);
            }
        }
        
        /// <summary>
        /// Seek to a specific time in the clip
        /// </summary>
        public void SeekTo(float time)
        {
            if (m_CurrentClip == null || !m_CurrentClip.IsValid)
                return;
            
            m_PlaybackTime = Mathf.Clamp(time, 0f, m_CurrentClip.duration);
            ApplyKeyframeAtTime(m_PlaybackTime);
        }
        
        /// <summary>
        /// Seek to a normalized position (0-1)
        /// </summary>
        public void SeekToNormalized(float t)
        {
            if (m_CurrentClip == null) return;
            SeekTo(t * m_CurrentClip.duration);
        }
        
        /// <summary>
        /// Toggle reverse playback direction
        /// </summary>
        public void ToggleReverse()
        {
            m_PlayingReverse = !m_PlayingReverse;
        }
        
        /// <summary>
        /// Step forward/backward by one frame
        /// </summary>
        public void StepFrame(bool forward = true)
        {
            if (m_CurrentClip == null || !m_CurrentClip.IsValid)
                return;
            
            float frameTime = 1f / m_CurrentClip.recordFPS;
            float newTime = m_PlaybackTime + (forward ? frameTime : -frameTime);
            SeekTo(newTime);
        }
        
        private void UpdatePlayback(float deltaTime)
        {
            if (m_CurrentClip == null || !m_CurrentClip.IsValid)
                return;
            
            float delta = deltaTime * m_PlaybackSpeed;
            if (m_PlayingReverse)
                delta = -delta;
            
            m_PlaybackTime += delta;
            
            // Handle looping
            if (m_PlaybackTime >= m_CurrentClip.duration)
            {
                if (m_Loop)
                {
                    if (m_PingPong)
                    {
                        m_PlaybackTime = m_CurrentClip.duration;
                        m_PlayingReverse = true;
                    }
                    else
                    {
                        m_PlaybackTime = 0f;
                    }
                }
                else
                {
                    m_PlaybackTime = m_CurrentClip.duration;
                    m_IsPlaying = false;
                }
            }
            else if (m_PlaybackTime < 0f)
            {
                if (m_Loop)
                {
                    if (m_PingPong)
                    {
                        m_PlaybackTime = 0f;
                        m_PlayingReverse = false;
                    }
                    else
                    {
                        m_PlaybackTime = m_CurrentClip.duration;
                    }
                }
                else
                {
                    m_PlaybackTime = 0f;
                    m_IsPlaying = false;
                }
            }
            
            ApplyKeyframeAtTime(m_PlaybackTime);
        }
        
        private void ApplyKeyframeAtTime(float time)
        {
            if (m_CurrentClip == null || m_CurrentClip.keyframes.Count == 0)
                return;
            
            var keyframes = m_CurrentClip.keyframes;
            
            // Find surrounding keyframes
            int prevIdx = 0;
            int nextIdx = 0;
            
            for (int i = 0; i < keyframes.Count; i++)
            {
                if (keyframes[i].time <= time)
                    prevIdx = i;
                if (keyframes[i].time >= time)
                {
                    nextIdx = i;
                    break;
                }
                nextIdx = i;
            }
            
            // Interpolate between keyframes
            var prevFrame = keyframes[prevIdx];
            var nextFrame = keyframes[nextIdx];
            
            float t = 0f;
            if (nextIdx != prevIdx && nextFrame.time != prevFrame.time)
            {
                t = (time - prevFrame.time) / (nextFrame.time - prevFrame.time);
            }
            
            // Interpolate positions
            int count = Mathf.Min(prevFrame.positions.Length, nextFrame.positions.Length);
            Vector3[] interpolated = new Vector3[count];
            
            for (int i = 0; i < count; i++)
            {
                interpolated[i] = Vector3.Lerp(prevFrame.positions[i], nextFrame.positions[i], t);
            }
            
            // Apply to renderer
            if (m_TargetRenderer != null)
            {
                m_TargetRenderer.WriteSplatPositions(interpolated);
            }
        }
        
        #endregion
        
        #region Clip Management
        
        /// <summary>
        /// Set the current clip for playback
        /// </summary>
        public void SetClip(SplatAnimationClip clip)
        {
            if (m_IsRecording)
                StopRecording();
            if (m_IsPlaying)
                StopPlayback();
            
            m_CurrentClip = clip;
        }
        
        /// <summary>
        /// Get the current clip
        /// </summary>
        public SplatAnimationClip GetClip() => m_CurrentClip;
        
        /// <summary>
        /// Clear the current clip
        /// </summary>
        public void ClearClip()
        {
            if (m_IsRecording)
                StopRecording();
            if (m_IsPlaying)
                StopPlayback();
            
            m_CurrentClip = null;
        }
        
        /// <summary>
        /// Get memory usage estimate for current clip
        /// </summary>
        public long GetClipMemoryUsage()
        {
            if (m_CurrentClip == null)
                return 0;
            
            // Vector3 = 12 bytes, per splat per keyframe
            long positionBytes = (long)m_CurrentClip.splatCount * 12 * m_CurrentClip.keyframes.Count;
            return positionBytes;
        }
        
        public string GetClipMemoryUsageString()
        {
            long bytes = GetClipMemoryUsage();
            if (bytes < 1024)
                return $"{bytes} B";
            if (bytes < 1024 * 1024)
                return $"{bytes / 1024f:F1} KB";
            return $"{bytes / (1024f * 1024f):F1} MB";
        }
        
        #endregion
    }
}
