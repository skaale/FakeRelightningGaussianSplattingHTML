// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatPaintBrush : MonoBehaviour
    {
        public static bool IsBrushModeActive = false;
        public static bool HasValidBrushPosition = false;
        public static Vector3 LastBrushPosition;
        public static Vector3 CurrentViewDirection;
        public static float CurrentWorldRadius;
        public static bool IsPainting = false;
        public static bool IsSampling = false;
        
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] private float m_ScreenRadius = 1.5f;
        [SerializeField] private float m_PaintDensity = 1f;
        [SerializeField] private float m_SplatSizeMultiplier = 0.1f; // Multiplier of worldRadius
        [SerializeField] private int m_SplatsPerStroke = 5;
        [SerializeField] private int m_SamplePixelRadius = 25;
        
        [Header("Custom Color")]
        [SerializeField] private bool m_UseCustomColor = false;
        [SerializeField] private Color m_CustomColor = Color.white;
        [SerializeField] private float m_ColorVariation = 0f; // 0-1, adds random variation to custom color
        
        [Header("Performance")]
        [SerializeField] private bool m_FastPaintMode = true; // Skip surface detection during drag
        [SerializeField] private bool m_UseGPUPaint = true; // Use fully GPU-based painting (zero CPU allocation)
        [SerializeField] private int m_BatchSize = 100; // Pre-allocate batch buffer
        
        [Header("Layering")]
        [SerializeField] private float m_LayerSpacing = 0.002f; // Distance between stroke layers
        [SerializeField] private bool m_EnableLayering = true; // Stack strokes on top of each other
        
        [Header("Texture Paint")]
        [SerializeField] private bool m_UseTexturePaint = false;
        [SerializeField] private int m_ActiveTextureSlot = 0; // 0-2
        [SerializeField] private float m_TextureTileScale = 1f;
        [SerializeField] private float m_TextureRotation = 0f;
        
        // 3 texture slots for captured textures
        private Texture2D[] m_TextureSlots = new Texture2D[3];
        private Color[][] m_TextureColorCache = new Color[3][];
        
        private List<Color> m_SampledColors = new List<Color>();
        private Vector3 m_SamplePosition;
        private bool m_HasSampledColors = false;
        
        // Track buffer state to avoid constant reallocation
        private int m_AllocatedCapacity = 0;
        private int m_NextWriteIndex = 0;
        
        // Fast paint caching
        private Vector3 m_CachedSurfacePos;
        private float m_CachedSurfaceDepth;
        private bool m_HasCachedSurface = false;
        private float m_LastSurfaceUpdateTime;
        private const float SURFACE_UPDATE_INTERVAL = 0.2f; // Update surface every 200ms (less frequent = smoother)
        
        // Layering state
        private int m_CurrentStrokeLayer = 0;
        private Vector3 m_LastLayerViewDir;
        
        // Batch paint buffers (reused to avoid allocation)
        private Vector3[] m_BatchPositions;
        private Color[] m_BatchColors;
        private float[] m_BatchSizes;
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public float ScreenRadius
        {
            get => m_ScreenRadius;
            set => m_ScreenRadius = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public float PaintDensity
        {
            get => m_PaintDensity;
            set => m_PaintDensity = Mathf.Clamp(value, 0.1f, 2f);
        }
        
        public float SplatSizeMultiplier
        {
            get => m_SplatSizeMultiplier;
            set => m_SplatSizeMultiplier = Mathf.Clamp(value, 0.01f, 1f);
        }
        
        public int SplatsPerStroke
        {
            get => m_SplatsPerStroke;
            set => m_SplatsPerStroke = Mathf.Clamp(value, 1, 50);
        }
        
        public int SamplePixelRadius
        {
            get => m_SamplePixelRadius;
            set => m_SamplePixelRadius = Mathf.Clamp(value, 5, 100);
        }
        
        public bool UseCustomColor
        {
            get => m_UseCustomColor;
            set => m_UseCustomColor = value;
        }
        
        public Color CustomColor
        {
            get => m_CustomColor;
            set => m_CustomColor = value;
        }
        
        public float ColorVariation
        {
            get => m_ColorVariation;
            set => m_ColorVariation = Mathf.Clamp01(value);
        }
        
        public bool FastPaintMode
        {
            get => m_FastPaintMode;
            set => m_FastPaintMode = value;
        }
        
        public bool UseGPUPaint
        {
            get => m_UseGPUPaint;
            set => m_UseGPUPaint = value;
        }
        
        public int BatchSize
        {
            get => m_BatchSize;
            set => m_BatchSize = Mathf.Clamp(value, 10, 500);
        }
        
        public float LayerSpacing
        {
            get => m_LayerSpacing;
            set => m_LayerSpacing = Mathf.Clamp(value, 0.0001f, 0.1f);
        }
        
        public bool EnableLayering
        {
            get => m_EnableLayering;
            set => m_EnableLayering = value;
        }
        
        public int CurrentStrokeLayer => m_CurrentStrokeLayer;
        
        public bool UseTexturePaint
        {
            get => m_UseTexturePaint;
            set => m_UseTexturePaint = value;
        }
        
        public int ActiveTextureSlot
        {
            get => m_ActiveTextureSlot;
            set => m_ActiveTextureSlot = Mathf.Clamp(value, 0, 2);
        }
        
        public float TextureTileScale
        {
            get => m_TextureTileScale;
            set => m_TextureTileScale = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public float TextureRotation
        {
            get => m_TextureRotation;
            set => m_TextureRotation = value;
        }
        
        public Texture2D GetTextureSlot(int slot) => slot >= 0 && slot < 3 ? m_TextureSlots[slot] : null;
        public bool HasTextureInSlot(int slot) => slot >= 0 && slot < 3 && m_TextureSlots[slot] != null;
        public bool HasActiveTexture => m_UseTexturePaint && HasTextureInSlot(m_ActiveTextureSlot);
        
        public bool HasSampledColors => m_HasSampledColors && m_SampledColors.Count > 0;
        public int SampledColorCount => m_SampledColors.Count;
        public Vector3 SamplePosition => m_SamplePosition;
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset;
        
        /// <summary>
        /// Sample colors from splats directly under the cursor ray
        /// </summary>
        public void SampleColorsAtRay(Ray ray, Camera cam, float referenceDepth, float screenRadius = 300f)
        {
            if (!IsValid) return;
            
            m_SampledColors.Clear();
            
            var renderer = m_TargetRenderer;
            int splatCount = renderer.splatCount;
            if (splatCount <= 0) { Debug.LogWarning("No splats in renderer"); return; }
            
            var posBuffer = renderer.GpuPosData;
            if (posBuffer == null) { Debug.LogWarning("No position buffer"); return; }
            
            // Get cursor screen position using reference point along ray
            Vector3 refPoint = ray.origin + ray.direction * referenceDepth;
            Vector3 screenCenter3 = cam.WorldToScreenPoint(refPoint);
            if (screenCenter3.z <= 0) { Debug.LogWarning("Cursor behind camera"); return; }
            
            Vector2 screenCenter = new Vector2(screenCenter3.x, screenCenter3.y);
            float screenRadiusSq = screenRadius * screenRadius;
            
            // Read position data
            int maxSamples = Mathf.Min(splatCount, 100000);
            float[] posData = new float[maxSamples * 3];
            posBuffer.GetData(posData, 0, 0, maxSamples * 3);
            
            // Read color texture
            var (texWidth, texHeight) = GaussianSplatAsset.CalcTextureSize(splatCount);
            Texture colorTex = renderer.GpuColorData;
            Color[] colors = null;
            
            if (colorTex is Texture2D tex2D)
            {
                try { colors = tex2D.GetPixels(); }
                catch (System.Exception e) { Debug.LogWarning($"Cannot read Texture2D: {e.Message}"); return; }
            }
            else if (colorTex is RenderTexture rt)
            {
                var prevActive = RenderTexture.active;
                try
                {
                    RenderTexture.active = rt;
                    var tempTex = new Texture2D(texWidth, texHeight, TextureFormat.RGBAHalf, false);
                    tempTex.ReadPixels(new Rect(0, 0, texWidth, texHeight), 0, 0);
                    tempTex.Apply();
                    colors = tempTex.GetPixels();
                    DestroyImmediate(tempTex);
                }
                catch (System.Exception e)
                {
                    Debug.LogWarning($"Cannot read RenderTexture: {e.Message}");
                }
                finally
                {
                    RenderTexture.active = prevActive;
                }
            }
            
            if (colors == null || colors.Length == 0)
            {
                Debug.LogWarning($"Could not read color texture (type: {colorTex?.GetType().Name})");
                return;
            }
            
            Transform t = renderer.transform;
            int foundInRange = 0;
            
            // Find surface position first to store
            Vector3? surfacePos = FindSplatSurfaceFromRay(ray, cam, referenceDepth, screenRadius);
            if (surfacePos.HasValue)
                m_SamplePosition = surfacePos.Value;
            
            for (int i = 0; i < maxSamples; i++)
            {
                Vector3 localPos = new Vector3(posData[i * 3], posData[i * 3 + 1], posData[i * 3 + 2]);
                Vector3 wpos = t.TransformPoint(localPos);
                Vector3 sp = cam.WorldToScreenPoint(wpos);
                
                if (sp.z <= 0) continue;
                
                float dx = sp.x - screenCenter.x;
                float dy = sp.y - screenCenter.y;
                float distSq = dx * dx + dy * dy;
                
                if (distSq < screenRadiusSq)
                {
                    foundInRange++;
                    int texX = i % texWidth;
                    int texY = i / texWidth;
                    if (texY < texHeight && texX < texWidth)
                    {
                        int colorIdx = texY * texWidth + texX;
                        if (colorIdx < colors.Length)
                        {
                            Color col = colors[colorIdx];
                            m_SampledColors.Add(col);
                        }
                    }
                    
                    if (m_SampledColors.Count >= 500) break;
                }
            }
            
            m_HasSampledColors = m_SampledColors.Count > 0;
            
            if (m_HasSampledColors)
                Debug.Log($"✓ Sampled {m_SampledColors.Count} colors (avg RGB: {GetAverageColor().r:F2},{GetAverageColor().g:F2},{GetAverageColor().b:F2})");
            else
                Debug.LogWarning($"No splats found in range ({foundInRange} checked, {screenRadius:F0}px radius)");
        }
        
        /// <summary>
        /// Pre-allocate buffer space to prevent jiggling during paint
        /// </summary>
        public void EnsureCapacity(int neededSlots = 500)
        {
            if (!IsValid) return;
            
            int currentCapacity = m_TargetRenderer.splatCount;
            
            // Initialize tracking on first call
            if (m_AllocatedCapacity == 0 || m_NextWriteIndex == 0)
            {
                m_AllocatedCapacity = currentCapacity;
                m_NextWriteIndex = currentCapacity;
            }
            
            // Check if we have enough room
            int remaining = m_AllocatedCapacity - m_NextWriteIndex;
            if (remaining >= neededSlots) return;
            
            // Expand buffer (allocate large chunks for continuous painting)
            int newCapacity = m_AllocatedCapacity + Mathf.Max(neededSlots, 2000);
            newCapacity = ((newCapacity / 1000) + 1) * 1000; // Round up to 1000
            
            try
            {
                m_TargetRenderer.EditSetSplatCount(newCapacity);
                m_AllocatedCapacity = newCapacity;
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"Could not expand buffer: {e.Message}");
            }
        }
        
        /// <summary>
        /// Find the world position on splat surface directly under the cursor ray.
        /// During fast paint mode, uses cached depth to avoid GPU readbacks.
        /// </summary>
        public Vector3? FindSplatSurfaceFromRay(Ray ray, Camera cam, float referenceDepth, float screenSearchRadius = 300f)
        {
            var renderer = m_TargetRenderer;
            if (renderer == null || !renderer.HasValidAsset || !renderer.HasValidRenderSetup) 
                return null;
            
            // During painting with cached surface, skip expensive GPU readback
            if (m_FastPaintMode && IsPainting && m_HasCachedSurface)
            {
                Vector3 camForward = cam.transform.forward;
                Vector3 camPos = cam.transform.position;
                Plane depthPlane = new Plane(-camForward, camPos + camForward * m_CachedSurfaceDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                    return ray.GetPoint(hitDist);
                return m_CachedSurfacePos;
            }
            
            // Create a reference point along the ray at the given depth
            Vector3 refPoint = ray.origin + ray.direction * referenceDepth;
            
            // Use renderer's built-in method to find nearest splat in screen space
            Vector3 nearestSplat = renderer.FindNearestSplatInScreenSpace(refPoint, cam, screenSearchRadius);
            
            // If we found a different position, project ray to that depth
            if (nearestSplat != refPoint)
            {
                Vector3 camForward = cam.transform.forward;
                Vector3 camPos = cam.transform.position;
                float splatDepth = Vector3.Dot(nearestSplat - camPos, camForward);
                
                // Project ray to the splat's depth plane (keeps cursor alignment)
                Plane depthPlane = new Plane(-camForward, camPos + camForward * splatDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                {
                    return ray.GetPoint(hitDist);
                }
                return nearestSplat;
            }
            
            return null;
        }
        
        /// <summary>
        /// Paint splats directly on the splat surface under the cursor ray (OPTIMIZED)
        /// </summary>
        public void PaintAtRay(Ray ray, Camera cam, float worldRadius, Vector3 viewDir, float referenceDepth)
        {
            if (!IsValid) return;
            
            float currentTime = Time.realtimeSinceStartup;
            Vector3 paintWorldPos;
            
            // Fast paint mode: cache surface position, only update periodically
            if (m_FastPaintMode && m_HasCachedSurface && (currentTime - m_LastSurfaceUpdateTime) < SURFACE_UPDATE_INTERVAL)
            {
                // Use cached depth, but project ray to that depth for cursor tracking
                Vector3 camForward = cam.transform.forward;
                Vector3 camPos = cam.transform.position;
                Plane depthPlane = new Plane(-camForward, camPos + camForward * m_CachedSurfaceDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                    paintWorldPos = ray.GetPoint(hitDist);
                else
                    paintWorldPos = m_CachedSurfacePos;
            }
            else
            {
                // Full surface detection
                Vector3? surfacePos = FindSplatSurfaceFromRay(ray, cam, referenceDepth, 300f);
                if (surfacePos.HasValue)
                {
                    paintWorldPos = surfacePos.Value;
                    m_CachedSurfacePos = paintWorldPos;
                    m_CachedSurfaceDepth = Vector3.Dot(paintWorldPos - cam.transform.position, cam.transform.forward);
                    m_HasCachedSurface = true;
                }
                else
                {
                    paintWorldPos = ray.origin + ray.direction * referenceDepth;
                }
                m_LastSurfaceUpdateTime = currentTime;
            }
            
            // Ensure we have capacity (larger batch to reduce reallocation frequency)
            int neededCapacity = m_SplatsPerStroke + m_BatchSize;
            if (m_AllocatedCapacity - m_NextWriteIndex < neededCapacity)
            {
                EnsureCapacity(neededCapacity + 2000); // Add large headroom for continuous strokes
            }
            
            Transform t = m_TargetRenderer.transform;
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localScatterRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            float splatSize = localScatterRadius * m_SplatSizeMultiplier;
            
            // Apply layer offset - move toward camera for each layer
            if (m_EnableLayering && m_CurrentStrokeLayer > 0)
            {
                float layerOffset = m_CurrentStrokeLayer * m_LayerSpacing;
                paintWorldPos -= viewDir * layerOffset; // Move toward camera
            }
            m_LastLayerViewDir = viewDir;
            
            // Get basis vectors perpendicular to view for scattering
            Vector3 localViewDir = t.InverseTransformDirection(viewDir);
            Vector3 right = Vector3.Cross(Vector3.up, localViewDir);
            if (right.sqrMagnitude < 0.001f)
                right = Vector3.Cross(Vector3.forward, localViewDir);
            right.Normalize();
            Vector3 up = Vector3.Cross(localViewDir, right).normalized;
            
            Vector3 localCenter = t.InverseTransformPoint(paintWorldPos);
            
            // GPU paint path - zero CPU allocation during paint
            if (m_UseGPUPaint)
            {
                Color baseColor = GetBasePaintColor();
                float variation = m_UseCustomColor ? m_ColorVariation : 0f;
                
                m_TargetRenderer.PaintSplatsGPU(
                    m_NextWriteIndex,
                    localCenter,
                    localScatterRadius,
                    splatSize,
                    baseColor,
                    variation,
                    right,
                    up,
                    m_SplatsPerStroke,
                    m_PaintDensity
                );
                
                m_NextWriteIndex += m_SplatsPerStroke;
                return;
            }
            
            // CPU batch fallback path
            if (m_BatchPositions == null || m_BatchPositions.Length < m_SplatsPerStroke)
            {
                m_BatchPositions = new Vector3[Mathf.Max(m_SplatsPerStroke, 50)];
                m_BatchColors = new Color[Mathf.Max(m_SplatsPerStroke, 50)];
                m_BatchSizes = new float[Mathf.Max(m_SplatsPerStroke, 50)];
            }
            
            for (int i = 0; i < m_SplatsPerStroke; i++)
            {
                float angle = Random.Range(0f, Mathf.PI * 2f);
                float dist = Mathf.Sqrt(Random.Range(0f, 1f)) * localScatterRadius;
                m_BatchPositions[i] = localCenter + right * (Mathf.Cos(angle) * dist) + up * (Mathf.Sin(angle) * dist);
                m_BatchColors[i] = GetNextPaintColor();
                m_BatchSizes[i] = splatSize;
            }
            
            m_TargetRenderer.PaintSplatsBatch(
                m_NextWriteIndex,
                m_BatchPositions,
                m_BatchSizes,
                m_BatchColors,
                m_SplatsPerStroke,
                m_PaintDensity
            );
            
            m_NextWriteIndex += m_SplatsPerStroke;
        }
        
        /// <summary>
        /// Get base paint color for GPU path (no variation, that's done on GPU)
        /// </summary>
        private Color GetBasePaintColor()
        {
            if (m_UseCustomColor)
                return m_CustomColor;
            if (m_HasSampledColors && m_SampledColors.Count > 0)
                return GetAverageColor();
            return new Color(0.5f, 0.5f, 0.5f, 1f);
        }
        
        /// <summary>
        /// Get next paint color (fast path, pre-calculated variation)
        /// </summary>
        private Color GetNextPaintColor()
        {
            if (m_UseCustomColor)
            {
                if (m_ColorVariation <= 0)
                    return m_CustomColor;
                
                // Fast HSV variation
                float h, s, v;
                Color.RGBToHSV(m_CustomColor, out h, out s, out v);
                h = Mathf.Repeat(h + Random.Range(-m_ColorVariation, m_ColorVariation) * 0.1f, 1f);
                s = Mathf.Clamp01(s + Random.Range(-m_ColorVariation, m_ColorVariation) * 0.2f);
                v = Mathf.Clamp01(v + Random.Range(-m_ColorVariation, m_ColorVariation) * 0.15f);
                Color result = Color.HSVToRGB(h, s, v);
                result.a = m_CustomColor.a;
                return result;
            }
            
            if (m_HasSampledColors && m_SampledColors.Count > 0)
                return m_SampledColors[Random.Range(0, m_SampledColors.Count)];
            
            return new Color(0.5f, 0.5f, 0.5f, 1f);
        }
        
        /// <summary>
        /// Clear cached surface on paint start, increment layer for stacking
        /// </summary>
        public void BeginPaintStroke()
        {
            m_HasCachedSurface = false;
            m_LastSurfaceUpdateTime = 0;
            
            // Increment layer for each new stroke (strokes stack on top of each other)
            if (m_EnableLayering)
                m_CurrentStrokeLayer++;
        }
        
        /// <summary>
        /// Reset layer counter (call when switching tools or clearing)
        /// </summary>
        public void ResetLayers()
        {
            m_CurrentStrokeLayer = 0;
        }
        
        /// <summary>
        /// Get the surface position for brush preview display
        /// </summary>
        public Vector3? GetSurfacePositionForPreview(Ray ray, Camera cam, float referenceDepth)
        {
            return FindSplatSurfaceFromRay(ray, cam, referenceDepth, 300f);
        }
        
        public void ClearSampledColors()
        {
            m_SampledColors.Clear();
            m_HasSampledColors = false;
        }
        
        public void ResetBufferState()
        {
            m_AllocatedCapacity = 0;
            m_NextWriteIndex = 0;
            m_CurrentStrokeLayer = 0;
        }
        
        public Color GetAverageColor()
        {
            if (!m_HasSampledColors) return Color.gray;
            
            Vector4 sum = Vector4.zero;
            foreach (var c in m_SampledColors)
                sum += new Vector4(c.r, c.g, c.b, c.a);
            
            sum /= m_SampledColors.Count;
            return new Color(sum.x, sum.y, sum.z, sum.w);
        }
        
        public Color GetRandomSampledColor()
        {
            if (!m_HasSampledColors) return Color.gray;
            return m_SampledColors[Random.Range(0, m_SampledColors.Count)];
        }
        
        /// <summary>
        /// Set custom color from a sampled/picked color
        /// </summary>
        public void SetCustomColorFromSample(Color color)
        {
            m_CustomColor = color;
            m_UseCustomColor = true;
        }
        
        /// <summary>
        /// Add a sampled color to the palette (for eyedropper)
        /// </summary>
        public void AddSampledColor(Color color)
        {
            m_SampledColors.Add(color);
            m_HasSampledColors = true;
        }
        
        /// <summary>
        /// Get the current paint color (for preview)
        /// </summary>
        public Color GetCurrentPaintColor()
        {
            if (m_UseTexturePaint && HasTextureInSlot(m_ActiveTextureSlot))
                return GetTextureCenterColor(m_ActiveTextureSlot);
            if (m_UseCustomColor)
                return m_CustomColor;
            if (m_HasSampledColors && m_SampledColors.Count > 0)
                return GetAverageColor();
            return Color.gray;
        }
        
        /// <summary>
        /// Get center color from texture slot for preview
        /// </summary>
        private Color GetTextureCenterColor(int slot)
        {
            var tex = m_TextureSlots[slot];
            if (tex == null) return Color.gray;
            return tex.GetPixelBilinear(0.5f, 0.5f);
        }
        
        /// <summary>
        /// Capture screen rect to texture slot
        /// </summary>
        public void CaptureTextureFromScreen(Rect screenRect, int slot, Camera cam)
        {
            if (slot < 0 || slot > 2 || cam == null) return;
            
            int x = Mathf.Max(0, (int)screenRect.x);
            int y = Mathf.Max(0, (int)screenRect.y);
            int w = Mathf.Min((int)screenRect.width, Screen.width - x);
            int h = Mathf.Min((int)screenRect.height, Screen.height - y);
            
            if (w <= 0 || h <= 0) return;
            
            // Cleanup old texture
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.ReadPixels(new Rect(x, y, w, h), 0, 0);
            tex.Apply();
            
            m_TextureSlots[slot] = tex;
            m_TextureColorCache[slot] = tex.GetPixels();
            
            Debug.Log($"Captured {w}x{h} texture to slot {slot + 1}");
        }
        
        /// <summary>
        /// Capture from RenderTexture to slot
        /// </summary>
        public void CaptureTextureFromRT(RenderTexture rt, Rect captureRect, int slot)
        {
            if (slot < 0 || slot > 2 || rt == null) return;
            
            var prevActive = RenderTexture.active;
            RenderTexture.active = rt;
            
            int x = Mathf.Max(0, (int)captureRect.x);
            int y = Mathf.Max(0, (int)captureRect.y);
            int w = Mathf.Min((int)captureRect.width, rt.width - x);
            int h = Mathf.Min((int)captureRect.height, rt.height - y);
            
            if (w <= 0 || h <= 0)
            {
                RenderTexture.active = prevActive;
                return;
            }
            
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.ReadPixels(new Rect(x, y, w, h), 0, 0);
            tex.Apply();
            
            RenderTexture.active = prevActive;
            
            m_TextureSlots[slot] = tex;
            m_TextureColorCache[slot] = tex.GetPixels();
            
            Debug.Log($"Captured {w}x{h} texture to slot {slot + 1}");
        }
        
        /// <summary>
        /// Load texture from file to slot
        /// </summary>
        public void LoadTextureToSlot(Texture2D source, int slot)
        {
            if (slot < 0 || slot > 2 || source == null) return;
            
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            // Make readable copy
            var tex = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false);
            
            var prevRT = RenderTexture.active;
            var tmpRT = RenderTexture.GetTemporary(source.width, source.height, 0, RenderTextureFormat.ARGB32);
            Graphics.Blit(source, tmpRT);
            RenderTexture.active = tmpRT;
            tex.ReadPixels(new Rect(0, 0, source.width, source.height), 0, 0);
            tex.Apply();
            RenderTexture.active = prevRT;
            RenderTexture.ReleaseTemporary(tmpRT);
            
            m_TextureSlots[slot] = tex;
            m_TextureColorCache[slot] = tex.GetPixels();
            
            Debug.Log($"Loaded {tex.width}x{tex.height} texture to slot {slot + 1}");
        }
        
        /// <summary>
        /// Clear texture from slot
        /// </summary>
        public void ClearTextureSlot(int slot)
        {
            if (slot < 0 || slot > 2) return;
            
            if (m_TextureSlots[slot] != null)
                DestroyImmediate(m_TextureSlots[slot]);
            
            m_TextureSlots[slot] = null;
            m_TextureColorCache[slot] = null;
        }
        
        /// <summary>
        /// Save texture slot to PNG file
        /// </summary>
        public byte[] GetTextureSlotAsPNG(int slot)
        {
            if (slot < 0 || slot > 2 || m_TextureSlots[slot] == null) return null;
            return m_TextureSlots[slot].EncodeToPNG();
        }
        
        /// <summary>
        /// Get color from active texture at UV coordinate
        /// </summary>
        public Color SampleTextureColor(float u, float v)
        {
            if (!HasActiveTexture) return GetNextPaintColor();
            
            var tex = m_TextureSlots[m_ActiveTextureSlot];
            var cache = m_TextureColorCache[m_ActiveTextureSlot];
            if (tex == null || cache == null) return GetNextPaintColor();
            
            // Apply tiling and rotation
            float cu = u * m_TextureTileScale;
            float cv = v * m_TextureTileScale;
            
            if (m_TextureRotation != 0f)
            {
                float rad = m_TextureRotation * Mathf.Deg2Rad;
                float cos = Mathf.Cos(rad);
                float sin = Mathf.Sin(rad);
                float nu = (cu - 0.5f) * cos - (cv - 0.5f) * sin + 0.5f;
                float nv = (cu - 0.5f) * sin + (cv - 0.5f) * cos + 0.5f;
                cu = nu;
                cv = nv;
            }
            
            // Repeat wrap
            cu = cu - Mathf.Floor(cu);
            cv = cv - Mathf.Floor(cv);
            
            int x = Mathf.Clamp((int)(cu * tex.width), 0, tex.width - 1);
            int y = Mathf.Clamp((int)(cv * tex.height), 0, tex.height - 1);
            
            return cache[y * tex.width + x];
        }
        
        /// <summary>
        /// Get color from texture based on splat position within brush area
        /// </summary>
        public Color GetTextureColorForPosition(Vector3 localPos, Vector3 brushCenter, float brushRadius, Vector3 right, Vector3 up)
        {
            if (!HasActiveTexture) return GetNextPaintColor();
            
            Vector3 offset = localPos - brushCenter;
            float u = Vector3.Dot(offset, right) / (brushRadius * 2f) + 0.5f;
            float v = Vector3.Dot(offset, up) / (brushRadius * 2f) + 0.5f;
            
            return SampleTextureColor(u, v);
        }
        
        /// <summary>
        /// Paint using active texture - GPU path with texture
        /// </summary>
        public void PaintWithTextureAtRay(Ray ray, Camera cam, float worldRadius, Vector3 viewDir, float referenceDepth)
        {
            if (!IsValid || !HasActiveTexture) 
            {
                PaintAtRay(ray, cam, worldRadius, viewDir, referenceDepth);
                return;
            }
            
            float currentTime = Time.realtimeSinceStartup;
            Vector3 paintWorldPos;
            
            if (m_FastPaintMode && m_HasCachedSurface && (currentTime - m_LastSurfaceUpdateTime) < SURFACE_UPDATE_INTERVAL)
            {
                Vector3 camForward = cam.transform.forward;
                Vector3 camPos = cam.transform.position;
                Plane depthPlane = new Plane(-camForward, camPos + camForward * m_CachedSurfaceDepth);
                if (depthPlane.Raycast(ray, out float hitDist) && hitDist > 0)
                    paintWorldPos = ray.GetPoint(hitDist);
                else
                    paintWorldPos = m_CachedSurfacePos;
            }
            else
            {
                Vector3? surfacePos = FindSplatSurfaceFromRay(ray, cam, referenceDepth, 300f);
                if (surfacePos.HasValue)
                {
                    paintWorldPos = surfacePos.Value;
                    m_CachedSurfacePos = paintWorldPos;
                    m_CachedSurfaceDepth = Vector3.Dot(paintWorldPos - cam.transform.position, cam.transform.forward);
                    m_HasCachedSurface = true;
                }
                else
                {
                    paintWorldPos = ray.origin + ray.direction * referenceDepth;
                }
                m_LastSurfaceUpdateTime = currentTime;
            }
            
            int neededCapacity = m_SplatsPerStroke + m_BatchSize;
            if (m_AllocatedCapacity - m_NextWriteIndex < neededCapacity)
            {
                EnsureCapacity(neededCapacity + 2000);
            }
            
            Transform t = m_TargetRenderer.transform;
            float rendererScale = t.lossyScale.magnitude / 1.732f;
            float localScatterRadius = worldRadius / Mathf.Max(rendererScale, 0.001f);
            float splatSize = localScatterRadius * m_SplatSizeMultiplier;
            
            if (m_EnableLayering && m_CurrentStrokeLayer > 0)
            {
                float layerOffset = m_CurrentStrokeLayer * m_LayerSpacing;
                paintWorldPos -= viewDir * layerOffset;
            }
            m_LastLayerViewDir = viewDir;
            
            Vector3 localViewDir = t.InverseTransformDirection(viewDir);
            Vector3 right = Vector3.Cross(Vector3.up, localViewDir);
            if (right.sqrMagnitude < 0.001f)
                right = Vector3.Cross(Vector3.forward, localViewDir);
            right.Normalize();
            Vector3 up = Vector3.Cross(localViewDir, right).normalized;
            
            Vector3 localCenter = t.InverseTransformPoint(paintWorldPos);
            
            // For texture painting, use GPU with texture or CPU fallback
            var tex = m_TextureSlots[m_ActiveTextureSlot];
            if (m_UseGPUPaint && tex != null)
            {
                m_TargetRenderer.PaintSplatsFromTextureGPU(
                    m_NextWriteIndex,
                    localCenter,
                    localScatterRadius,
                    splatSize,
                    tex,
                    m_TextureTileScale,
                    m_TextureRotation,
                    m_ColorVariation,
                    right,
                    up,
                    m_SplatsPerStroke,
                    m_PaintDensity
                );
                
                m_NextWriteIndex += m_SplatsPerStroke;
                return;
            }
            
            // CPU batch fallback with texture sampling
            if (m_BatchPositions == null || m_BatchPositions.Length < m_SplatsPerStroke)
            {
                m_BatchPositions = new Vector3[Mathf.Max(m_SplatsPerStroke, 50)];
                m_BatchColors = new Color[Mathf.Max(m_SplatsPerStroke, 50)];
                m_BatchSizes = new float[Mathf.Max(m_SplatsPerStroke, 50)];
            }
            
            for (int i = 0; i < m_SplatsPerStroke; i++)
            {
                float angle = Random.Range(0f, Mathf.PI * 2f);
                float dist = Mathf.Sqrt(Random.Range(0f, 1f)) * localScatterRadius;
                Vector3 pos = localCenter + right * (Mathf.Cos(angle) * dist) + up * (Mathf.Sin(angle) * dist);
                m_BatchPositions[i] = pos;
                m_BatchColors[i] = GetTextureColorForPosition(pos, localCenter, localScatterRadius, right, up);
                m_BatchSizes[i] = splatSize;
            }
            
            m_TargetRenderer.PaintSplatsBatch(
                m_NextWriteIndex,
                m_BatchPositions,
                m_BatchSizes,
                m_BatchColors,
                m_SplatsPerStroke,
                m_PaintDensity
            );
            
            m_NextWriteIndex += m_SplatsPerStroke;
        }
        
        private void OnDestroy()
        {
            for (int i = 0; i < 3; i++)
            {
                if (m_TextureSlots[i] != null)
                    DestroyImmediate(m_TextureSlots[i]);
            }
        }
    }
}

