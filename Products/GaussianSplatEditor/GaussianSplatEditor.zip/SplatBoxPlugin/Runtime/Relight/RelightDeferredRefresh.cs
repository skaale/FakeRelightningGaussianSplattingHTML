using System.Collections;
using GaussianSplatting.Runtime;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Relight
{
    /// <summary>
    /// Deferred relight buffer refresh for player/XR builds (mirrors editor delayCall).
    /// </summary>
    static class RelightDeferredRefresh
    {
        static bool s_Scheduled;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void RefreshAfterSceneLoad()
        {
            Schedule();
        }

        internal static void Schedule()
        {
            if (s_Scheduled)
                return;
            s_Scheduled = true;
            var go = new GameObject("RelightDeferredRefresh")
            {
                hideFlags = HideFlags.HideAndDontSave
            };
            go.AddComponent<Runner>();
        }

        sealed class Runner : MonoBehaviour
        {
            IEnumerator Start()
            {
                // Wait a couple frames so SplatBoxRenderer + URP feature can initialize.
                yield return null;
                yield return null;

                CustomLightManager.RefreshAllInScene();
                SplatBoxPlayerBootstrap.BootstrapAllRenderers();

                if (GraphicsSettings.currentRenderPipeline != null && !GaussianSplatRenderSystem.URPFeatureExecuted)
                {
                    Debug.LogWarning(
                        "[SplatBox] Gaussian Splat URP Feature did not run. Splats will not render on device. " +
                        "In the Editor, use SplatBox > Setup URP Renderer Features and ensure your Android/XR URP Renderer includes the feature.");
                }

                s_Scheduled = false;
                Destroy(gameObject);
            }
        }
    }
}
