using UnityEngine;

namespace GaussianSplatting.Relight
{
    public class CustomLightFlicker : MonoBehaviour
    {
        [Header("Flicker Settings")]
        public float flickerSpeed = 5.0f;
        public float flickerIntensity = 0.3f;
        public float baseIntensity = 1.0f;

        [Header("Light Type")]
        public bool isSpotLight = false;
        public int lightIndex = 0;

        private CustomLightManager lightManager;
        private float originalIntensity;
        private float timeOffset;

        void Start()
        {
            lightManager = FindAnyObjectByType<CustomLightManager>();
            if (lightManager == null)
            {
                Debug.LogError("CustomLightFlicker: No CustomLightManager found in scene!");
                enabled = false;
                return;
            }
            if (isSpotLight && lightManager.spotLights.Count > lightIndex)
                originalIntensity = lightManager.spotLights[lightIndex].intensity;
            else if (!isSpotLight && lightManager.pointLights.Count > lightIndex)
                originalIntensity = lightManager.pointLights[lightIndex].intensity;
            baseIntensity = originalIntensity;
            timeOffset = Random.Range(0f, 100f);
        }

        void Update()
        {
            if (lightManager == null) return;
            float noise1 = Mathf.PerlinNoise(Time.time * flickerSpeed + timeOffset, 0.0f);
            float noise2 = Mathf.PerlinNoise(Time.time * flickerSpeed * 2.3f + timeOffset + 50f, 0.0f);
            float flicker = (noise1 * 0.7f + noise2 * 0.3f - 0.5f) * 2.0f;
            float newIntensity = Mathf.Max(0.0f, baseIntensity + flicker * flickerIntensity);
            if (isSpotLight && lightManager.spotLights.Count > lightIndex && lightManager.spotLights[lightIndex] != null)
                lightManager.spotLights[lightIndex].intensity = newIntensity;
            else if (!isSpotLight && lightManager.pointLights.Count > lightIndex && lightManager.pointLights[lightIndex] != null)
                lightManager.pointLights[lightIndex].intensity = newIntensity;
        }

        void OnDisable()
        {
            if (lightManager != null)
            {
                if (isSpotLight && lightManager.spotLights.Count > lightIndex && lightManager.spotLights[lightIndex] != null)
                    lightManager.spotLights[lightIndex].intensity = originalIntensity;
                else if (!isSpotLight && lightManager.pointLights.Count > lightIndex && lightManager.pointLights[lightIndex] != null)
                    lightManager.pointLights[lightIndex].intensity = originalIntensity;
            }
        }
    }
}
