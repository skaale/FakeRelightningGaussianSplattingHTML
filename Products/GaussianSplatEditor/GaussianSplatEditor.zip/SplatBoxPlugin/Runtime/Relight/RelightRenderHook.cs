using GaussianSplatting.Runtime;
using UnityEngine;
using UnityEngine.Rendering;

namespace GaussianSplatting.Relight
{
    /// <summary>
    /// Re-binds custom light GPU buffers whenever SplatBoxRenderer recreates relight materials (player builds).
    /// </summary>
    static class RelightRenderHook
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void Register()
        {
            GaussianSplatRenderSystem.OnRelightRendererReady -= CustomLightManager.RefreshAllInScene;
            GaussianSplatRenderSystem.OnRelightRendererReady += CustomLightManager.RefreshAllInScene;
            GaussianSplatRenderSystem.OnRelightRendererReady -= RelightDeferredRefresh.Schedule;
            GaussianSplatRenderSystem.OnRelightRendererReady += RelightDeferredRefresh.Schedule;
            GaussianSplatRenderSystem.OnBeforeDrawSplats -= CustomLightManager.BindAllToDrawContext;
            GaussianSplatRenderSystem.OnBeforeDrawSplats += CustomLightManager.BindAllToDrawContext;
        }
    }
}
