using UnityEngine;
using System.Collections.Generic;

namespace GaussianSplatting.Relight
{
    public enum RelightAttenuationMode { Default, Linear, InverseSquare }

    public class RelightPointLight : MonoBehaviour
    {
        [SerializeField] public Color color = Color.white;
        [SerializeField] public float intensity = 1f;
        [SerializeField] public float range = 1f;
        [SerializeField] public RelightAttenuationMode attenuationMode = RelightAttenuationMode.Default;
        [SerializeField] public bool isActive = true;
        [SerializeField] public bool showGizmo = true;
    }

    public class RelightSpotLight : MonoBehaviour
    {
        [SerializeField] public Color color = Color.white;
        [SerializeField] public float intensity = 1f;
        [SerializeField] public float range = 1f;
        [SerializeField] public float spotAngle = 30.0f;
        [SerializeField] public float innerConeAngle = 21.8f;
        [SerializeField] public RelightAttenuationMode attenuationMode = RelightAttenuationMode.Default;
        [SerializeField] public bool isActive = true;
        [SerializeField] public bool showGizmo = true;
        public Vector3 Direction => transform.forward;
    }

    public enum RelightDirectionalPreset { Custom, Top, TopFront, Front, BottomFront, Bottom, Left, Right, Back }

    public class RelightDirectionalLight : MonoBehaviour
    {
        [SerializeField] public RelightDirectionalPreset preset = RelightDirectionalPreset.TopFront;
        [SerializeField] public Color color = Color.white;
        [SerializeField] public float intensity = 100f;
        [SerializeField] public float effectRange = 25f;
        [SerializeField] public float rangeSoftness = 1f;
        [SerializeField] public float shadowStrength = 0.5f;
        [SerializeField] public bool useDistanceAttenuation = true;
        [SerializeField] public float distanceAttenuationFactor = 0.5f;
        [SerializeField] public bool useAngleAttenuation = true;
        [SerializeField] public float angleAttenuationBias = 0.5f;
        [SerializeField] public bool isActive = true;
        [SerializeField] public bool showGizmo = true;
        public Vector3 Direction => transform.forward;
        public Vector3 GetPresetDirection()
        {
            switch (preset)
            {
                case RelightDirectionalPreset.Top: return Vector3.up;
                case RelightDirectionalPreset.TopFront: return new Vector3(0, 0.7f, -0.7f).normalized;
                case RelightDirectionalPreset.Front: return Vector3.back;
                case RelightDirectionalPreset.BottomFront: return new Vector3(0, -0.7f, -0.7f).normalized;
                case RelightDirectionalPreset.Bottom: return Vector3.down;
                case RelightDirectionalPreset.Left: return Vector3.left;
                case RelightDirectionalPreset.Right: return Vector3.right;
                case RelightDirectionalPreset.Back: return Vector3.forward;
                default: return transform.forward;
            }
        }
    }

    public class RelightPlanarLight : MonoBehaviour
    {
        [SerializeField] public Vector2 size = new Vector2(5.0f, 5.0f);
        [SerializeField] public Color color = Color.white;
        [SerializeField] public float intensity = 1f;
        [SerializeField] public float range = 1f;
        [SerializeField] public bool twoSided = false;
        [SerializeField] public RelightAttenuationMode attenuationMode = RelightAttenuationMode.Default;
        [SerializeField] public bool isActive = true;
        [SerializeField] public bool showGizmo = true;
        public Vector3 Normal => transform.forward.sqrMagnitude > 0.0001f ? transform.forward.normalized : Vector3.forward;
    }
}
