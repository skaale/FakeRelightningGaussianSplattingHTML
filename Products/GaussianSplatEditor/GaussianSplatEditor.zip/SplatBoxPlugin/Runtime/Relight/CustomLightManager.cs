using UnityEngine;
using UnityEngine.Rendering;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace GaussianSplatting.Relight
{
    [ExecuteInEditMode]
    public class CustomLightManager : MonoBehaviour
    {
        [Header("Gizmos")]
        [SerializeField] private bool m_ShowGizmos = true;

        const string kPointRoot = "Point Lights";
        const string kSpotRoot = "Spot Lights";
        const string kDirectionalRoot = "Directional Lights";
        const string kPlanarRoot = "Planar Lights";

        Transform m_PointRoot;
        Transform m_SpotRoot;
        Transform m_DirectionalRoot;
        Transform m_PlanarRoot;

        List<RelightPointLight> m_PointLights = new List<RelightPointLight>();
        List<RelightSpotLight> m_SpotLights = new List<RelightSpotLight>();
        List<RelightDirectionalLight> m_DirectionalLights = new List<RelightDirectionalLight>();
        List<RelightPlanarLight> m_PlanarLights = new List<RelightPlanarLight>();

        public IReadOnlyList<RelightPointLight> pointLights => m_PointLights;
        public IReadOnlyList<RelightSpotLight> spotLights => m_SpotLights;
        public IReadOnlyList<RelightDirectionalLight> directionalLights => m_DirectionalLights;
        public IReadOnlyList<RelightPlanarLight> planarLights => m_PlanarLights;

        private ComputeBuffer pointLightBuffer;
        private ComputeBuffer spotLightBuffer;
        private ComputeBuffer directionalLightBuffer;
        private ComputeBuffer planarLightBuffer;
        private CustomPointLightData[] pointLightData;
        private CustomSpotLightData[] spotLightData;
        private CustomDirectionalLightData[] directionalLightData;
        private CustomPlanarLightData[] planarLightData;

        // Must match HLSL StructuredBuffer struct sizes in RenderGaussianSplats.shader exactly.
        const int kPointLightStride = 48;
        const int kSpotLightStride = 80;
        const int kDirectionalLightStride = 64;
        const int kPlanarLightStride = 80;

        static readonly int s_CustomPointLightsId = Shader.PropertyToID("_CustomPointLights");
        static readonly int s_CustomSpotLightsId = Shader.PropertyToID("_CustomSpotLights");
        static readonly int s_CustomDirectionalLightsId = Shader.PropertyToID("_CustomDirectionalLights");
        static readonly int s_CustomPlanarLightsId = Shader.PropertyToID("_CustomPlanarLights");
        static readonly int s_CustomPointLightCountId = Shader.PropertyToID("_CustomPointLightCount");
        static readonly int s_CustomSpotLightCountId = Shader.PropertyToID("_CustomSpotLightCount");
        static readonly int s_CustomDirectionalLightCountId = Shader.PropertyToID("_CustomDirectionalLightCount");
        static readonly int s_CustomPlanarLightCountId = Shader.PropertyToID("_CustomPlanarLightCount");
        static readonly int s_GaussianSSAOId = Shader.PropertyToID("_GaussianSSAO");
        static readonly int s_SSAOStrengthId = Shader.PropertyToID("_SSAOStrength");

        // HLSL StructuredBuffer elements are 16-byte aligned (float3 -> float4 stride).
        // Tight C# Vector3 packing breaks light colors on Android/Vulkan.
        [StructLayout(LayoutKind.Sequential)]
        struct CustomPointLightData
        {
            public Vector4 position;
            public Vector4 color;
            public float intensity;
            public float range;
            public float attenuationMode;
            public float _pad;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct CustomSpotLightData
        {
            public Vector4 position;
            public Vector4 direction;
            public Vector4 color;
            public float intensity;
            public float range;
            public float innerConeAngle;
            public float outerConeAngle;
            public float attenuationMode;
            public float _pad0;
            public float _pad1;
            public float _pad2;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct CustomDirectionalLightData
        {
            public Vector4 direction;
            public Vector4 color;
            public float intensity;
            public float effectRange;
            public float rangeSoftness;
            public float shadowStrength;
            public float useDistanceAttenuation;
            public float distanceAttenuationFactor;
            public float useAngleAttenuation;
            public float angleAttenuationBias;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct CustomPlanarLightData
        {
            public Vector4 position;
            public Vector4 normal;
            public Vector4 color;
            public float intensity;
            public float range;
            public float sizeX;
            public float sizeY;
            public float twoSided;
            public float attenuationMode;
            public float _pad0;
            public float _pad1;
        }

        static Vector4 PackPosition(Vector3 v) => new Vector4(v.x, v.y, v.z, 0f);
        static Vector4 PackDirection(Vector3 v) => new Vector4(v.x, v.y, v.z, 0f);
        static Vector4 PackLinearColor(Color c)
        {
            // Inspector colors are sRGB; convert once for linear lighting math.
            var linear = QualitySettings.activeColorSpace == ColorSpace.Linear ? c.linear : c;
            return new Vector4(linear.r, linear.g, linear.b, 1f);
        }

        static int LightStructStride<T>() where T : struct
        {
            if (typeof(T) == typeof(CustomPointLightData)) return kPointLightStride;
            if (typeof(T) == typeof(CustomSpotLightData)) return kSpotLightStride;
            if (typeof(T) == typeof(CustomDirectionalLightData)) return kDirectionalLightStride;
            if (typeof(T) == typeof(CustomPlanarLightData)) return kPlanarLightStride;
            return Marshal.SizeOf<T>();
        }

        void FindExistingRoots()
        {
            foreach (Transform child in transform)
            {
                if (child.name == kPointRoot) m_PointRoot = child;
                else if (child.name == kSpotRoot) m_SpotRoot = child;
                else if (child.name == kDirectionalRoot) m_DirectionalRoot = child;
                else if (child.name == kPlanarRoot) m_PlanarRoot = child;
            }
        }

        void EnsureRoot(ref Transform root, string name)
        {
            if (root != null) return;
            foreach (Transform child in transform)
            {
                if (child.name == name) { root = child; return; }
            }
            var go = new GameObject(name);
            go.transform.SetParent(transform, false);
            go.transform.localPosition = Vector3.zero;
            root = go.transform;
        }

        void GatherLights()
        {
            FindExistingRoots();
            m_PointLights.Clear();
            m_SpotLights.Clear();
            m_DirectionalLights.Clear();
            m_PlanarLights.Clear();

            if (m_PointRoot != null)
                for (int i = 0; i < m_PointRoot.childCount; i++)
                {
                    var c = m_PointRoot.GetChild(i).GetComponent<RelightPointLight>();
                    if (c != null) m_PointLights.Add(c);
                }
            if (m_SpotRoot != null)
                for (int i = 0; i < m_SpotRoot.childCount; i++)
                {
                    var c = m_SpotRoot.GetChild(i).GetComponent<RelightSpotLight>();
                    if (c != null) m_SpotLights.Add(c);
                }
            if (m_DirectionalRoot != null)
                for (int i = 0; i < m_DirectionalRoot.childCount; i++)
                {
                    var c = m_DirectionalRoot.GetChild(i).GetComponent<RelightDirectionalLight>();
                    if (c != null) m_DirectionalLights.Add(c);
                }
            if (m_PlanarRoot != null)
                for (int i = 0; i < m_PlanarRoot.childCount; i++)
                {
                    var c = m_PlanarRoot.GetChild(i).GetComponent<RelightPlanarLight>();
                    if (c != null) m_PlanarLights.Add(c);
                }

            // Fallback: find lights anywhere in children (handles lights not under root containers)
            if (m_PointLights.Count == 0)
                GetComponentsInChildren(m_PointLights);
            if (m_SpotLights.Count == 0)
                GetComponentsInChildren(m_SpotLights);
            if (m_DirectionalLights.Count == 0)
                GetComponentsInChildren(m_DirectionalLights);
            if (m_PlanarLights.Count == 0)
                GetComponentsInChildren(m_PlanarLights);
        }

        void OnEnable()
        {
            FindExistingRoots();
            RefreshLightBuffers();

#if UNITY_EDITOR
            // OnEnable can run before SplatBoxRenderer finishes creating its relight
            // materials. Defer one refresh so global light buffers bind after the full
            // scene init pass (fixes black splats after a Unity restart).
            UnityEditor.EditorApplication.delayCall += DeferredRefreshAfterLoad;
#else
            // Player/XR builds: mirror editor deferred refresh (Quest init order).
            RelightDeferredRefresh.Schedule();
#endif
        }

        bool HasAnyLights()
        {
            return m_PointLights.Count > 0 || m_SpotLights.Count > 0
                || m_DirectionalLights.Count > 0 || m_PlanarLights.Count > 0;
        }

        /// <summary>
        /// Re-gather lights and push buffer data to the relight shader.
        /// Safe to call after renderers/materials are recreated.
        /// </summary>
        public void RefreshLightBuffers()
        {
            GatherLights();
            ReleaseBuffer();
            if (!HasAnyLights())
            {
                ClearGlobalLightBindings();
                return;
            }
            CreateBuffer();
            UpdateBuffer();
        }

        /// <summary>
        /// Refresh every CustomLightManager in loaded scenes (e.g. after SplatBoxRenderer re-inits).
        /// </summary>
        public static void RefreshAllInScene()
        {
#if UNITY_2022_2_OR_NEWER
            var managers = Object.FindObjectsByType<CustomLightManager>(FindObjectsInactive.Include);
#else
            var managers = Object.FindObjectsOfType<CustomLightManager>(true);
#endif
            for (int i = 0; i < managers.Length; i++)
            {
                if (managers[i] != null)
                    managers[i].RefreshLightBuffers();
            }
        }

        /// <summary>
        /// Bind current light GPU buffers on the draw CommandBuffer and MPB (required for URP DrawProcedural).
        /// </summary>
        public static void BindAllToDrawContext(CommandBuffer cmd, MaterialPropertyBlock mpb)
        {
            ApplyRelightDrawDefaults(cmd, mpb);

#if UNITY_2022_2_OR_NEWER
            var managers = Object.FindObjectsByType<CustomLightManager>(FindObjectsInactive.Include);
#else
            var managers = Object.FindObjectsOfType<CustomLightManager>(true);
#endif
            if (managers == null || managers.Length == 0)
            {
                ClearDrawLightBindings(cmd, mpb);
                return;
            }

            for (int i = 0; i < managers.Length; i++)
            {
                if (managers[i] != null)
                    managers[i].BindToDrawContext(cmd, mpb);
            }
        }

        static void ApplyRelightDrawDefaults(CommandBuffer cmd, MaterialPropertyBlock mpb)
        {
            // Keep SSAO slot valid on every draw — unbound samplers return 0 on Vulkan/Quest.
            Shader.SetGlobalTexture(s_GaussianSSAOId, Texture2D.whiteTexture);
            if (cmd != null)
            {
                cmd.SetGlobalTexture(s_GaussianSSAOId, Texture2D.whiteTexture);
                cmd.SetGlobalFloat(s_SSAOStrengthId, 0f);
            }
            if (mpb != null)
            {
                mpb.SetTexture(s_GaussianSSAOId, Texture2D.whiteTexture);
                mpb.SetFloat(s_SSAOStrengthId, 0f);
            }
        }

        static void ClearDrawLightBindings(CommandBuffer cmd, MaterialPropertyBlock mpb)
        {
            ApplyLightBinding(cmd, mpb, s_CustomPointLightsId, s_CustomPointLightCountId, null, 0);
            ApplyLightBinding(cmd, mpb, s_CustomSpotLightsId, s_CustomSpotLightCountId, null, 0);
            ApplyLightBinding(cmd, mpb, s_CustomDirectionalLightsId, s_CustomDirectionalLightCountId, null, 0);
            ApplyLightBinding(cmd, mpb, s_CustomPlanarLightsId, s_CustomPlanarLightCountId, null, 0);
        }

        void BindToDrawContext(CommandBuffer cmd, MaterialPropertyBlock mpb)
        {
            GatherLights();
            UpdateBuffer();
            int pc = m_PointLights.Count, sc = m_SpotLights.Count, dc = m_DirectionalLights.Count, plc = m_PlanarLights.Count;

            ApplyLightBinding(cmd, mpb, s_CustomPointLightsId, s_CustomPointLightCountId, pointLightBuffer, pc);
            ApplyLightBinding(cmd, mpb, s_CustomSpotLightsId, s_CustomSpotLightCountId, spotLightBuffer, sc);
            ApplyLightBinding(cmd, mpb, s_CustomDirectionalLightsId, s_CustomDirectionalLightCountId, directionalLightBuffer, dc);
            ApplyLightBinding(cmd, mpb, s_CustomPlanarLightsId, s_CustomPlanarLightCountId, planarLightBuffer, plc);
        }

        // A StructuredBuffer left UNBOUND makes the Vulkan/Quest descriptor set incomplete and the
        // whole DrawProcedural is silently dropped (D3D11 tolerates unbound buffers, which is why it
        // "works in the editor" but renders nothing on device). We must always bind a valid buffer for
        // every light slot; the matching count==0 still stops the shader from ever reading it. 80 bytes
        // (>= the largest light struct stride) keeps even a defensive element-0 read in-bounds.
        static ComputeBuffer s_DummyLightBuffer;
        static bool s_DummyCleanupHooked;

        static ComputeBuffer DummyLightBuffer()
        {
            if (s_DummyLightBuffer == null)
            {
                s_DummyLightBuffer = new ComputeBuffer(1, 80, ComputeBufferType.Structured);
                if (!s_DummyCleanupHooked)
                {
                    s_DummyCleanupHooked = true;
                    Application.quitting += ReleaseDummyLightBuffer;
                }
            }
            return s_DummyLightBuffer;
        }

        static void ReleaseDummyLightBuffer()
        {
            if (s_DummyLightBuffer != null) { s_DummyLightBuffer.Release(); s_DummyLightBuffer = null; }
        }

        static void ApplyLightBinding(CommandBuffer cmd, MaterialPropertyBlock mpb, int bufferId, int countId, ComputeBuffer buffer, int count)
        {
            // Never leave the StructuredBuffer descriptor unbound (see DummyLightBuffer note).
            ComputeBuffer bound = (buffer != null && count > 0) ? buffer : DummyLightBuffer();
            if (cmd != null)
            {
                cmd.SetGlobalBuffer(bufferId, bound);
                cmd.SetGlobalInt(countId, count);
            }

            if (mpb != null)
            {
                mpb.SetBuffer(bufferId, bound);
                mpb.SetInt(countId, count);
            }
        }

        void ApplyGlobalLightBindings()
        {
            int pc = m_PointLights.Count, sc = m_SpotLights.Count, dc = m_DirectionalLights.Count, plc = m_PlanarLights.Count;

            // Always bind a valid buffer (real when present, dummy otherwise) so the Vulkan/Quest
            // descriptor set is never incomplete; the count==0 stops the shader from reading it.
            Shader.SetGlobalBuffer(s_CustomPointLightsId, (pc > 0 && pointLightBuffer != null) ? pointLightBuffer : DummyLightBuffer());
            Shader.SetGlobalInt(s_CustomPointLightCountId, (pc > 0 && pointLightBuffer != null) ? pc : 0);

            Shader.SetGlobalBuffer(s_CustomSpotLightsId, (sc > 0 && spotLightBuffer != null) ? spotLightBuffer : DummyLightBuffer());
            Shader.SetGlobalInt(s_CustomSpotLightCountId, (sc > 0 && spotLightBuffer != null) ? sc : 0);

            Shader.SetGlobalBuffer(s_CustomDirectionalLightsId, (dc > 0 && directionalLightBuffer != null) ? directionalLightBuffer : DummyLightBuffer());
            Shader.SetGlobalInt(s_CustomDirectionalLightCountId, (dc > 0 && directionalLightBuffer != null) ? dc : 0);

            Shader.SetGlobalBuffer(s_CustomPlanarLightsId, (plc > 0 && planarLightBuffer != null) ? planarLightBuffer : DummyLightBuffer());
            Shader.SetGlobalInt(s_CustomPlanarLightCountId, (plc > 0 && planarLightBuffer != null) ? plc : 0);
        }

#if UNITY_EDITOR
        void DeferredRefreshAfterLoad()
        {
            UnityEditor.EditorApplication.delayCall -= DeferredRefreshAfterLoad;
            if (this == null)
                return;
            RefreshLightBuffers();
        }
#endif

        public RelightPointLight AddPointLight(Vector3? position = null)
        {
            EnsureRoot(ref m_PointRoot, kPointRoot);
            var go = new GameObject("Point Light " + m_PointRoot.childCount);
            go.transform.SetParent(m_PointRoot, false);
            go.transform.localPosition = position ?? Vector3.zero;
            var light = go.AddComponent<RelightPointLight>();
            GatherLights();
            UpdateBuffer();
            return light;
        }

        public RelightSpotLight AddSpotLight(Vector3? position = null)
        {
            EnsureRoot(ref m_SpotRoot, kSpotRoot);
            var go = new GameObject("Spot Light " + m_SpotRoot.childCount);
            go.transform.SetParent(m_SpotRoot, false);
            go.transform.localPosition = position ?? Vector3.zero;
            var light = go.AddComponent<RelightSpotLight>();
            GatherLights();
            UpdateBuffer();
            return light;
        }

        public RelightDirectionalLight AddDirectionalLight()
        {
            EnsureRoot(ref m_DirectionalRoot, kDirectionalRoot);
            var go = new GameObject("Directional Light " + m_DirectionalRoot.childCount);
            go.transform.SetParent(m_DirectionalRoot, false);
            go.transform.rotation = Quaternion.Euler(50, -30, 0);
            var light = go.AddComponent<RelightDirectionalLight>();
            GatherLights();
            UpdateBuffer();
            return light;
        }

        public RelightPlanarLight AddPlanarLight(Vector3? position = null)
        {
            EnsureRoot(ref m_PlanarRoot, kPlanarRoot);
            var go = new GameObject("Planar Light " + m_PlanarRoot.childCount);
            go.transform.SetParent(m_PlanarRoot, false);
            go.transform.localPosition = position ?? Vector3.zero;
            var light = go.AddComponent<RelightPlanarLight>();
            GatherLights();
            UpdateBuffer();
            return light;
        }

        public void RemoveLight(RelightPointLight light)
        {
            if (light != null && light.transform.parent == m_PointRoot)
            {
#if UNITY_EDITOR
                if (!Application.isPlaying) DestroyImmediate(light.gameObject);
                else Destroy(light.gameObject);
#else
                Destroy(light.gameObject);
#endif
                GatherLights();
                UpdateBuffer();
            }
        }
        public void RemoveLight(RelightSpotLight light)
        {
            if (light != null && light.transform.parent == m_SpotRoot)
            {
#if UNITY_EDITOR
                if (!Application.isPlaying) DestroyImmediate(light.gameObject);
                else Destroy(light.gameObject);
#else
                Destroy(light.gameObject);
#endif
                GatherLights();
                UpdateBuffer();
            }
        }
        public void RemoveLight(RelightDirectionalLight light)
        {
            if (light != null && light.transform.parent == m_DirectionalRoot)
            {
#if UNITY_EDITOR
                if (!Application.isPlaying) DestroyImmediate(light.gameObject);
                else Destroy(light.gameObject);
#else
                Destroy(light.gameObject);
#endif
                GatherLights();
                UpdateBuffer();
            }
        }
        public void RemoveLight(RelightPlanarLight light)
        {
            if (light != null && light.transform.parent == m_PlanarRoot)
            {
#if UNITY_EDITOR
                if (!Application.isPlaying) DestroyImmediate(light.gameObject);
                else Destroy(light.gameObject);
#else
                Destroy(light.gameObject);
#endif
                GatherLights();
                UpdateBuffer();
            }
        }

        void OnDisable()
        {
            ReleaseBuffer();
            ClearGlobalLightBindings();
        }

        void ClearGlobalLightBindings()
        {
            Shader.SetGlobalInt(s_CustomPointLightCountId, 0);
            Shader.SetGlobalInt(s_CustomSpotLightCountId, 0);
            Shader.SetGlobalInt(s_CustomDirectionalLightCountId, 0);
            Shader.SetGlobalInt(s_CustomPlanarLightCountId, 0);
        }

        void CreateBuffer()
        {
            int pc = m_PointLights.Count, sc = m_SpotLights.Count, dc = m_DirectionalLights.Count, plc = m_PlanarLights.Count;
            if (pointLightBuffer != null && (pointLightBuffer.count != pc)) { pointLightBuffer.Release(); pointLightBuffer = null; }
            if (spotLightBuffer != null && (spotLightBuffer.count != sc)) { spotLightBuffer.Release(); spotLightBuffer = null; }
            if (directionalLightBuffer != null && (directionalLightBuffer.count != dc)) { directionalLightBuffer.Release(); directionalLightBuffer = null; }
            if (planarLightBuffer != null && (planarLightBuffer.count != plc)) { planarLightBuffer.Release(); planarLightBuffer = null; }
            if (pc > 0 && (pointLightData == null || pointLightData.Length != pc)) pointLightData = new CustomPointLightData[pc];
            if (sc > 0 && (spotLightData == null || spotLightData.Length != sc)) spotLightData = new CustomSpotLightData[sc];
            if (dc > 0 && (directionalLightData == null || directionalLightData.Length != dc)) directionalLightData = new CustomDirectionalLightData[dc];
            if (plc > 0 && (planarLightData == null || planarLightData.Length != plc)) planarLightData = new CustomPlanarLightData[plc];
            if (pc > 0 && pointLightBuffer == null) pointLightBuffer = new ComputeBuffer(pc, LightStructStride<CustomPointLightData>());
            if (sc > 0 && spotLightBuffer == null) spotLightBuffer = new ComputeBuffer(sc, LightStructStride<CustomSpotLightData>());
            if (dc > 0 && directionalLightBuffer == null) directionalLightBuffer = new ComputeBuffer(dc, LightStructStride<CustomDirectionalLightData>());
            if (plc > 0 && planarLightBuffer == null) planarLightBuffer = new ComputeBuffer(plc, LightStructStride<CustomPlanarLightData>());
            if (pc == 0) { pointLightData = null; if (pointLightBuffer != null) { pointLightBuffer.Release(); pointLightBuffer = null; } }
            if (sc == 0) { spotLightData = null; if (spotLightBuffer != null) { spotLightBuffer.Release(); spotLightBuffer = null; } }
            if (dc == 0) { directionalLightData = null; if (directionalLightBuffer != null) { directionalLightBuffer.Release(); directionalLightBuffer = null; } }
            if (plc == 0) { planarLightData = null; if (planarLightBuffer != null) { planarLightBuffer.Release(); planarLightBuffer = null; } }
        }

        static float AttenuationModeToFloat(RelightAttenuationMode m) { return (float)m; }

        void UpdateBuffer()
        {
            GatherLights();
            int pc = m_PointLights.Count, sc = m_SpotLights.Count, dc = m_DirectionalLights.Count, plc = m_PlanarLights.Count;
            if ((pc > 0 && (pointLightBuffer == null || pointLightData == null || pointLightData.Length != pc)) ||
                (sc > 0 && (spotLightBuffer == null || spotLightData == null || spotLightData.Length != sc)) ||
                (dc > 0 && (directionalLightBuffer == null || directionalLightData == null || directionalLightData.Length != dc)) ||
                (plc > 0 && (planarLightBuffer == null || planarLightData == null || planarLightData.Length != plc)) ||
                (pc == 0 && (pointLightBuffer != null || pointLightData != null)) ||
                (sc == 0 && (spotLightBuffer != null || spotLightData != null)) ||
                (dc == 0 && (directionalLightBuffer != null || directionalLightData != null)) ||
                (plc == 0 && (planarLightBuffer != null || planarLightData != null)))
            {
                CreateBuffer();
            }
            if (pc > 0 && pointLightBuffer != null && pointLightData != null)
            {
                for (int i = 0; i < pc; i++)
                {
                    var L = m_PointLights[i];
                    if (L != null && L.isActive)
                        pointLightData[i] = new CustomPointLightData { position = PackPosition(L.transform.position), color = PackLinearColor(L.color), intensity = L.intensity, range = L.range, attenuationMode = AttenuationModeToFloat(L.attenuationMode) };
                    else
                        pointLightData[i] = default;
                }
                pointLightBuffer.SetData(pointLightData);
            }
            if (sc > 0 && spotLightBuffer != null && spotLightData != null)
            {
                for (int i = 0; i < sc; i++)
                {
                    var L = m_SpotLights[i];
                    if (L != null && L.isActive)
                    {
                        float outerCos = Mathf.Cos(L.spotAngle * 0.5f * Mathf.Deg2Rad);
                        float innerCos = Mathf.Cos(L.innerConeAngle * 0.5f * Mathf.Deg2Rad);
                        spotLightData[i] = new CustomSpotLightData { position = PackPosition(L.transform.position), direction = PackDirection(L.Direction), color = PackLinearColor(L.color), intensity = L.intensity, range = L.range, innerConeAngle = innerCos, outerConeAngle = outerCos, attenuationMode = AttenuationModeToFloat(L.attenuationMode) };
                    }
                    else
                        spotLightData[i] = default;
                }
                spotLightBuffer.SetData(spotLightData);
            }
            if (dc > 0 && directionalLightBuffer != null && directionalLightData != null)
            {
                for (int i = 0; i < dc; i++)
                {
                    var L = m_DirectionalLights[i];
                    if (L != null && L.isActive)
                    {
                        Vector3 dir = L.Direction;
                        directionalLightData[i] = new CustomDirectionalLightData { direction = PackDirection(dir), color = PackLinearColor(L.color), intensity = L.intensity, effectRange = L.effectRange, rangeSoftness = Mathf.Max(0f, L.rangeSoftness), shadowStrength = L.shadowStrength, useDistanceAttenuation = L.useDistanceAttenuation ? 1.0f : 0.0f, distanceAttenuationFactor = L.distanceAttenuationFactor, useAngleAttenuation = L.useAngleAttenuation ? 1.0f : 0.0f, angleAttenuationBias = L.angleAttenuationBias };
                    }
                    else
                        directionalLightData[i] = default;
                }
                directionalLightBuffer.SetData(directionalLightData);
            }
            if (plc > 0 && planarLightBuffer != null && planarLightData != null)
            {
                for (int i = 0; i < plc; i++)
                {
                    var L = m_PlanarLights[i];
                    if (L != null && L.isActive)
                    {
                        Vector3 n = L.Normal;
                        planarLightData[i] = new CustomPlanarLightData { position = PackPosition(L.transform.position), normal = PackDirection(n), color = PackLinearColor(L.color), intensity = L.intensity, range = L.range, sizeX = L.size.x, sizeY = L.size.y, twoSided = L.twoSided ? 1.0f : 0.0f, attenuationMode = AttenuationModeToFloat(L.attenuationMode) };
                    }
                    else
                        planarLightData[i] = default;
                }
                planarLightBuffer.SetData(planarLightData);
            }

            ApplyGlobalLightBindings();
        }

        void ReleaseBuffer()
        {
            if (pointLightBuffer != null) { pointLightBuffer.Release(); pointLightBuffer = null; }
            if (spotLightBuffer != null) { spotLightBuffer.Release(); spotLightBuffer = null; }
            if (directionalLightBuffer != null) { directionalLightBuffer.Release(); directionalLightBuffer = null; }
            if (planarLightBuffer != null) { planarLightBuffer.Release(); planarLightBuffer = null; }
        }

#if UNITY_EDITOR
        int m_EditorRefreshFrame;
#endif

        void Update()
        {
            if (!Application.isPlaying)
            {
#if UNITY_EDITOR
                // Throttled edit-mode refresh keeps Scene view lit when lights move,
                // without pushing buffers on every repaint (which was freezing the editor).
                if (!HasAnyLights())
                    return;
                if (Time.frameCount - m_EditorRefreshFrame < 2)
                    return;
                m_EditorRefreshFrame = Time.frameCount;
                UpdateBuffer();
#endif
                return;
            }
            UpdateBuffer();
        }

#if UNITY_EDITOR
        void OnValidate()
        {
            if (HasAnyLights())
                RefreshLightBuffers();
        }

        void OnDrawGizmos()
        {
            if (!m_ShowGizmos) return;
            GatherLights();
            foreach (var L in m_PointLights)
                if (L != null && L.isActive && L.showGizmo) { Color c = L.color; c.a = 0.2f; Gizmos.color = c; Gizmos.DrawWireSphere(L.transform.position, L.range); Gizmos.DrawSphere(L.transform.position, 0.1f); }
            foreach (var L in m_SpotLights)
                if (L != null && L.isActive && L.showGizmo)
                {
                    Color c = L.color; c.a = 0.3f; Gizmos.color = c;
                    Vector3 p = L.transform.position, d = L.Direction;
                    float r = Mathf.Tan(L.spotAngle * 0.5f * Mathf.Deg2Rad) * L.range;
                    Gizmos.DrawLine(p, p + d * L.range);
                    Vector3 up = Vector3.Cross(d, Vector3.right).normalized; if (up.magnitude < 0.1f) up = Vector3.Cross(d, Vector3.up).normalized;
                    Vector3 right = Vector3.Cross(d, up).normalized;
                    for (int j = 0; j < 8; j++) { float a = j * Mathf.PI * 2f / 8f; Gizmos.DrawLine(p, p + d * L.range + (up * Mathf.Sin(a) + right * Mathf.Cos(a)) * r); }
                    Gizmos.DrawSphere(p, 0.1f);
                }
            foreach (var L in m_DirectionalLights)
                if (L != null && L.isActive && L.showGizmo) { Color c = L.color; c.a = 0.5f; Gizmos.color = c; Vector3 pos = L.transform.position; Vector3 d = L.Direction; Gizmos.DrawRay(pos, d * 2f); Gizmos.DrawSphere(pos + d * 2f, 0.1f); }
            foreach (var L in m_PlanarLights)
                if (L != null && L.isActive && L.showGizmo)
                {
                    Color c = L.color; c.a = 0.4f; Gizmos.color = c;
                    Vector3 p = L.transform.position, n = L.Normal, sz = L.size;
                    Vector3 right = Vector3.Cross(n, Vector3.forward).normalized; if (right.magnitude < 0.1f) right = Vector3.Cross(n, Vector3.right).normalized;
                    Vector3 up = Vector3.Cross(right, n).normalized;
                    Gizmos.DrawLine(p + right * sz.x * 0.5f + up * sz.y * 0.5f, p - right * sz.x * 0.5f + up * sz.y * 0.5f);
                    Gizmos.DrawLine(p - right * sz.x * 0.5f + up * sz.y * 0.5f, p - right * sz.x * 0.5f - up * sz.y * 0.5f);
                    Gizmos.DrawLine(p - right * sz.x * 0.5f - up * sz.y * 0.5f, p + right * sz.x * 0.5f - up * sz.y * 0.5f);
                    Gizmos.DrawLine(p + right * sz.x * 0.5f - up * sz.y * 0.5f, p + right * sz.x * 0.5f + up * sz.y * 0.5f);
                    Gizmos.DrawRay(p, n * 1f); Gizmos.DrawSphere(p + n * 1f, 0.1f);
                }
        }

        void OnDrawGizmosSelected()
        {
            if (!m_ShowGizmos) return;
            GatherLights();
            foreach (var L in m_PointLights)
                if (L != null && L.isActive && L.showGizmo) { Color c = L.color; c.a = 0.4f; Gizmos.color = c; Gizmos.DrawWireSphere(L.transform.position, L.range); }
            foreach (var L in m_SpotLights)
                if (L != null && L.isActive && L.showGizmo)
                {
                    Color c = L.color; c.a = 0.5f; Gizmos.color = c;
                    Vector3 p = L.transform.position, d = L.Direction;
                    float r = Mathf.Tan(L.spotAngle * 0.5f * Mathf.Deg2Rad) * L.range;
                    Vector3 up = Vector3.Cross(d, Vector3.right).normalized; if (up.magnitude < 0.1f) up = Vector3.Cross(d, Vector3.up).normalized;
                    Vector3 right = Vector3.Cross(d, up).normalized;
                    for (int j = 0; j < 16; j++) { float a = j * Mathf.PI * 2f / 16f; Gizmos.DrawLine(p, p + d * L.range + (up * Mathf.Sin(a) + right * Mathf.Cos(a)) * r); }
                }
            foreach (var L in m_DirectionalLights)
                if (L != null && L.isActive && L.showGizmo) { Color c = L.color; c.a = 0.8f; Gizmos.color = c; Vector3 pos = L.transform.position; Vector3 d = L.Direction; Gizmos.DrawRay(pos, d * 3f); Gizmos.DrawSphere(pos + d * 3f, 0.15f); }
            foreach (var L in m_PlanarLights)
                if (L != null && L.isActive && L.showGizmo)
                {
                    Color c = L.color; c.a = 0.7f; Gizmos.color = c;
                    Vector3 p = L.transform.position, n = L.Normal, sz = L.size;
                    Vector3 right = Vector3.Cross(n, Vector3.forward).normalized; if (right.magnitude < 0.1f) right = Vector3.Cross(n, Vector3.right).normalized;
                    Vector3 up = Vector3.Cross(right, n).normalized;
                    Gizmos.DrawLine(p + right * sz.x * 0.5f + up * sz.y * 0.5f, p - right * sz.x * 0.5f + up * sz.y * 0.5f);
                    Gizmos.DrawLine(p - right * sz.x * 0.5f + up * sz.y * 0.5f, p - right * sz.x * 0.5f - up * sz.y * 0.5f);
                    Gizmos.DrawLine(p - right * sz.x * 0.5f - up * sz.y * 0.5f, p + right * sz.x * 0.5f - up * sz.y * 0.5f);
                    Gizmos.DrawLine(p + right * sz.x * 0.5f - up * sz.y * 0.5f, p + right * sz.x * 0.5f + up * sz.y * 0.5f);
                    Gizmos.DrawRay(p, n * 2f); Gizmos.DrawSphere(p + n * 2f, 0.2f);
                }
        }
#endif
    }
}
