// SPDX-License-Identifier: MIT

using UnityEngine;
using System;
using System.Collections.Generic;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Simple attractor effect for Gaussian splats - creates vortex/attraction effects
    /// </summary>
    [ExecuteAlways]
    public class GaussianSplatAttractor : MonoBehaviour
    {
        public enum AttractorMode
        {
            Vortex,     // Spiral/swirl effect
            Attract,    // Pull toward center
            Repel,      // Push away from center
            Wave        // Sine wave distortion
        }

        [Header("Attractor")]
        [SerializeField] private bool m_AttractorEnabled = false;
        [SerializeField] private bool m_AttractorPaused = false;
        [SerializeField] private AttractorMode m_Mode = AttractorMode.Vortex;
        
        [Header("Effect Settings")]
        [Tooltip("How strong the effect is (0.01 = very slow, 0.1 = medium, 0.5 = fast)")]
        [SerializeField] [Range(0.001f, 0.5f)] private float m_Strength = 0.02f;
        
        [Tooltip("Radius of effect")]
        [SerializeField] [Range(0.1f, 20f)] private float m_Range = 2f;
        
        [Tooltip("Scale multiplier for effect range")]
        [SerializeField] [Range(0.1f, 10f)] private float m_Scale = 1f;
        
        [Tooltip("How quickly effect falls off with distance (higher = sharper edge)")]
        [SerializeField] [Range(0.1f, 3f)] private float m_Falloff = 1f;
        
        [Tooltip("Vortex height in Y axis (0 = flat, positive = upward spiral, negative = downward)")]
        [SerializeField] [Range(-5f, 5f)] private float m_VortexHeight = 0f;
        
        [Header("Wave Settings")]
        [Tooltip("Frequency of the wave (higher = more waves)")]
        [SerializeField] [Range(0.1f, 20f)] private float m_WaveFrequency = 2f;
        
        [Tooltip("Wave amplitude multiplier")]
        [SerializeField] [Range(0.1f, 5f)] private float m_WaveAmplitude = 1f;
        
        [Tooltip("Wave animation speed")]
        [SerializeField] [Range(0f, 10f)] private float m_WaveSpeed = 3f;
        
        [Tooltip("Wave direction axis (0=X, 1=Y, 2=Z)")]
        [SerializeField] [Range(0, 2)] private int m_WaveAxis = 1;
        
        [Tooltip("Curl/twist intensity - adds rotational motion to waves")]
        [SerializeField] [Range(0f, 2f)] private float m_CurlStrength = 0f;
        
        [Tooltip("Secondary wave frequency for complex patterns")]
        [SerializeField] [Range(0f, 10f)] private float m_SecondaryFrequency = 0f;

        [Header("Gizmos")]
        [SerializeField] private bool m_DrawGizmos = true;
        [SerializeField] private bool m_ShowVortexGizmo = true;
        [SerializeField] private Color m_GizmoColor = Color.cyan;

        private static readonly List<GaussianSplatAttractor> s_AllAttractors = new();
        public static IReadOnlyList<GaussianSplatAttractor> AllAttractors => s_AllAttractors;
        private static int s_LastUpdateFrame = -1;
        private static readonly List<global::GaussianSplatting.Runtime.AttractorData> s_ActiveAttractorData = new();

        // Compute shader data structure - must match BoxUtil.compute
        public struct AttractorData
        {
            public Vector3 position;
            public float strength;
            public float range;
            public float falloff;
            public int mode;        // 0=Vortex, 1=Attract, 2=Repel, 3=Wave
            public float enabled;
            public float vortexHeight;
            public float waveFrequency;
            public float waveAmplitude;
            public float waveSpeed;
            public int waveAxis;    // 0=X, 1=Y, 2=Z
            public float curlStrength;
            public float secondaryFrequency;
            public Quaternion rotation;
            public Vector3 scale;
            public float scalePadding;
        }

        public static void ClearAllAttractors() => s_AllAttractors.Clear();
        
        /// <summary>
        /// Update attractors for the given renderer - called by SplatBoxRenderer
        /// </summary>
        public static void UpdateRenderer(SplatBoxRenderer renderer)
        {
            // Attractors work when wind is enabled on the renderer
            // No action needed here - data is pulled by renderer
        }

        public bool AttractorEnabled
        {
            get => m_AttractorEnabled;
            set => m_AttractorEnabled = value;
        }
        
        public bool AttractorPaused
        {
            get => m_AttractorPaused;
            set => m_AttractorPaused = value;
        }

        public float Range
        {
            get => m_Range;
            set => m_Range = Mathf.Clamp(value, 0.1f, 20f);
        }

        public float Strength
        {
            get => m_Strength;
            set => m_Strength = Mathf.Clamp(value, 0.001f, 0.5f);
        }

        public float Falloff
        {
            get => m_Falloff;
            set => m_Falloff = Mathf.Clamp(value, 0.1f, 3f);
        }

        public float Scale
        {
            get => m_Scale;
            set => m_Scale = Mathf.Clamp(value, 0.1f, 10f);
        }

        public void EnsureRegistered()
        {
            if (!s_AllAttractors.Contains(this))
                s_AllAttractors.Add(this);
        }

        public void Unregister() => s_AllAttractors.Remove(this);

        public void ManualUpdate()
        {
            EnsureRegistered();
            UpdateAllRenderers(force: true);
        }

        void OnEnable()
        {
            if (!s_AllAttractors.Contains(this))
                s_AllAttractors.Add(this);
            UpdateAllRenderers(force: true);
        }

        void OnDisable()
        {
            s_AllAttractors.Remove(this);
            UpdateAllRenderers(force: true);
        }
        
        void OnDestroy()
        {
            s_AllAttractors.Remove(this);
            UpdateAllRenderers(force: true);
        }
        
        void Update()
        {
            UpdateAllRenderers();
        }

        public AttractorData GetAttractorData()
        {
            return new AttractorData
            {
                position = transform.position,
                strength = m_Strength,
                range = m_Range * m_Scale,
                falloff = m_Falloff,
                mode = (int)m_Mode,
                enabled = m_AttractorEnabled ? 1.0f : 0.0f,
                vortexHeight = m_VortexHeight,
                waveFrequency = m_WaveFrequency,
                waveAmplitude = m_WaveAmplitude * m_Scale,
                waveSpeed = m_WaveSpeed,
                waveAxis = m_WaveAxis,
                curlStrength = m_CurlStrength,
                secondaryFrequency = m_SecondaryFrequency,
                rotation = transform.rotation,
                scale = transform.lossyScale,
                scalePadding = 0f
            };
        }
        
        private static void UpdateAllRenderers(bool force = false)
        {
            int frame = Time.frameCount;
            if (!force && s_LastUpdateFrame == frame)
                return;
            
            s_LastUpdateFrame = frame;
            s_ActiveAttractorData.Clear();
            
            for (int i = 0; i < s_AllAttractors.Count; i++)
            {
                var attractor = s_AllAttractors[i];
                if (attractor == null || !attractor.isActiveAndEnabled || !attractor.m_AttractorEnabled)
                    continue;
                
                if (attractor.m_AttractorPaused)
                    continue;
                
                var src = attractor.GetAttractorData();
                s_ActiveAttractorData.Add(new global::GaussianSplatting.Runtime.AttractorData
                {
                    position = src.position,
                    strength = src.strength,
                    range = src.range,
                    falloff = src.falloff,
                    mode = src.mode,
                    enabled = src.enabled,
                    vortexHeight = src.vortexHeight,
                    waveFrequency = src.waveFrequency,
                    waveAmplitude = src.waveAmplitude,
                    waveSpeed = src.waveSpeed,
                    waveAxis = src.waveAxis,
                    curlStrength = src.curlStrength,
                    secondaryFrequency = src.secondaryFrequency,
                    rotation = src.rotation,
                    scale = src.scale,
                    scalePadding = 0f
                });
            }
            
            var data = s_ActiveAttractorData.Count == 0
                ? Array.Empty<global::GaussianSplatting.Runtime.AttractorData>()
                : s_ActiveAttractorData.ToArray();
            
            var renderers = FindObjectsByType<SplatBoxRenderer>();
            for (int i = 0; i < renderers.Length; i++)
            {
                var renderer = renderers[i];
                if (renderer != null)
                    renderer.SetAttractorData(data);
            }
        }

        void OnDrawGizmos()
        {
            if (!m_DrawGizmos) return;

            Vector3 pos = transform.position;
            float scaledRange = m_Range * m_Scale;
            
            // Draw range sphere
            Gizmos.color = m_GizmoColor * 0.5f;
            Gizmos.DrawWireSphere(pos, scaledRange);
            
            // Draw mode indicator
            Gizmos.color = m_Mode switch
            {
                AttractorMode.Vortex => Color.cyan,
                AttractorMode.Attract => Color.green,
                AttractorMode.Repel => Color.red,
                AttractorMode.Wave => Color.yellow,
                _ => Color.white
            };
            
            if (m_Mode == AttractorMode.Vortex)
            {
                // Draw spiral (if enabled)
                if (m_ShowVortexGizmo)
                {
                    for (int i = 0; i < 24; i++)
                    {
                        float t = i / 24f;
                        float angle = t * Mathf.PI * 4;
                        float radius = t * scaledRange * 0.5f;
                        float yOffset = t * m_VortexHeight;
                        Vector3 point = pos + new Vector3(Mathf.Cos(angle) * radius, yOffset, Mathf.Sin(angle) * radius);
                        
                        if (i > 0)
                        {
                            float pt = (i - 1) / 24f;
                            float pa = pt * Mathf.PI * 4;
                            float pr = pt * scaledRange * 0.5f;
                            float pyOffset = pt * m_VortexHeight;
                            Vector3 prev = pos + new Vector3(Mathf.Cos(pa) * pr, pyOffset, Mathf.Sin(pa) * pr);
                            Gizmos.DrawLine(prev, point);
                        }
                    }
                }
            }
            else if (m_Mode == AttractorMode.Wave)
            {
                // Draw sine wave with curl visualization
                Vector3 waveDir = m_WaveAxis == 0 ? Vector3.right : (m_WaveAxis == 1 ? Vector3.up : Vector3.forward);
                Vector3 perpDir = m_WaveAxis == 0 ? Vector3.forward : Vector3.right;
                Vector3 curlDir = m_WaveAxis == 1 ? Vector3.forward : Vector3.up;
                float scaledAmplitude = m_WaveAmplitude * m_Scale;
                
                // Primary wave
                for (int i = 0; i < 32; i++)
                {
                    float t = (i / 31f) * 2f - 1f;
                    float waveOffset = Mathf.Sin(t * m_WaveFrequency * Mathf.PI) * scaledRange * 0.3f * m_WaveAmplitude;
                    float curlOffset = m_CurlStrength > 0.01f ? Mathf.Cos(t * m_WaveFrequency * 0.5f * Mathf.PI) * scaledRange * 0.15f * m_CurlStrength : 0f;
                    Vector3 point = pos + perpDir * t * scaledRange + waveDir * waveOffset + curlDir * curlOffset;
                    
                    if (i > 0)
                    {
                        float pt = ((i - 1) / 31f) * 2f - 1f;
                        float pwo = Mathf.Sin(pt * m_WaveFrequency * Mathf.PI) * scaledRange * 0.3f * m_WaveAmplitude;
                        float pco = m_CurlStrength > 0.01f ? Mathf.Cos(pt * m_WaveFrequency * 0.5f * Mathf.PI) * scaledRange * 0.15f * m_CurlStrength : 0f;
                        Vector3 prev = pos + perpDir * pt * scaledRange + waveDir * pwo + curlDir * pco;
                        Gizmos.DrawLine(prev, point);
                    }
                }
                
                // Secondary wave visualization (if enabled)
                if (m_SecondaryFrequency > 0.01f)
                {
                    Gizmos.color = Color.yellow * 0.6f;
                    Vector3 secPerpDir = m_WaveAxis == 1 ? Vector3.forward : (m_WaveAxis == 0 ? Vector3.up : Vector3.up);
                    for (int i = 0; i < 24; i++)
                    {
                        float t = (i / 23f) * 2f - 1f;
                        float waveOffset = Mathf.Sin(t * m_SecondaryFrequency * Mathf.PI) * scaledRange * 0.15f * m_WaveAmplitude;
                        Vector3 point = pos + secPerpDir * t * scaledRange * 0.5f + waveDir * waveOffset;
                        
                        if (i > 0)
                        {
                            float pt = ((i - 1) / 23f) * 2f - 1f;
                            float pwo = Mathf.Sin(pt * m_SecondaryFrequency * Mathf.PI) * scaledRange * 0.15f * m_WaveAmplitude;
                            Vector3 prev = pos + secPerpDir * pt * scaledRange * 0.5f + waveDir * pwo;
                            Gizmos.DrawLine(prev, point);
                        }
                    }
                }
            }
            else
            {
                // Draw arrows
                for (int i = 0; i < 8; i++)
                {
                    float angle = i * 45 * Mathf.Deg2Rad;
                    Vector3 dir = new Vector3(Mathf.Cos(angle), 0, Mathf.Sin(angle));
                    
                    if (m_Mode == AttractorMode.Attract)
                    {
                        Gizmos.DrawLine(pos + dir * scaledRange * 0.8f, pos + dir * scaledRange * 0.4f);
                    }
                    else
                    {
                        Gizmos.DrawLine(pos + dir * scaledRange * 0.4f, pos + dir * scaledRange * 0.8f);
                    }
                }
            }
            
            Gizmos.DrawWireSphere(pos, 0.1f);
        }
    }
}
