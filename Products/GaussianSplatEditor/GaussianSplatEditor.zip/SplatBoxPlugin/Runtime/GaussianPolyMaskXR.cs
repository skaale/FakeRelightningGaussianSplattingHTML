// SPDX-License-Identifier: MIT
// Requires XR Interaction Toolkit package to be installed

#if UNITY_XR_INTERACTION_TOOLKIT
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;
using System.Collections.Generic;

namespace GaussianSplatting.Runtime
{
    [RequireComponent(typeof(GaussianPolyMask))]
    public class GaussianPolyMaskXR : MonoBehaviour
    {
        [Header("XR Controller")]
        public XRNode m_ControllerNode = XRNode.LeftHand;
        public XRController m_XRController;
        
        [Header("Input Actions")]
        public InputHelpers.Button m_TriggerButton = InputHelpers.Button.Trigger;
        public InputHelpers.Button m_GrabButton = InputHelpers.Button.Grip;
        
        [Header("Drawing Settings")]
        public float m_RayMaxDistance = 10f;
        public LayerMask m_DrawSurfaceLayer = ~0;
        public float m_MinVertexDistance = 0.1f;
        public float m_CloseDistanceThreshold = 0.3f;
        public float m_ShapeGenerationSize = 1.0f;
        
        [Header("Visual Feedback")]
        public GameObject m_RayVisualizerPrefab;
        public Color m_DrawRayColor = Color.cyan;
        public Color m_DeleteRayColor = Color.red;
        
        private GaussianPolyMask m_PolyMask;
        private bool m_TriggerPressed = false;
        private bool m_GrabPressed = false;
        private GameObject m_RayVisualizer;
        private LineRenderer m_RayLine;
        private Vector3 m_LastHitPoint;
        private bool m_HasValidHit;
        private float m_LastTriggerTime = 0f;

        private void Awake()
        {
            m_PolyMask = GetComponent<GaussianPolyMask>();
            
            if (m_RayVisualizerPrefab != null)
            {
                m_RayVisualizer = Instantiate(m_RayVisualizerPrefab);
                m_RayLine = m_RayVisualizer.GetComponent<LineRenderer>();
            }
            
            if (m_RayLine == null && m_RayVisualizer != null)
            {
                m_RayLine = m_RayVisualizer.AddComponent<LineRenderer>();
                m_RayLine.startWidth = 0.01f;
                m_RayLine.endWidth = 0.01f;
                m_RayLine.material = new Material(Shader.Find("Unlit/Color"));
            }
        }

        private void Update()
        {
            if (!TryGetControllerTransform(out Vector3 position, out Quaternion rotation))
                return;

            Ray ray = new Ray(position, rotation * Vector3.forward);
            m_HasValidHit = Physics.Raycast(ray, out RaycastHit hit, m_RayMaxDistance, m_DrawSurfaceLayer);
            
            if (m_HasValidHit)
            {
                m_LastHitPoint = hit.point;
                UpdateRayVisualizer(position, hit.point, false);
            }
            else
            {
                m_LastHitPoint = ray.GetPoint(m_RayMaxDistance);
                UpdateRayVisualizer(position, m_LastHitPoint, true);
            }

            HandleTriggerInput();
            HandleGrabInput();
        }

        private bool TryGetControllerTransform(out Vector3 position, out Quaternion rotation)
        {
            if (m_XRController != null)
            {
                position = m_XRController.transform.position;
                rotation = m_XRController.transform.rotation;
                return true;
            }

            InputDevice device = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
            if (device.isValid)
            {
                if (device.TryGetFeatureValue(CommonUsages.devicePosition, out position) &&
                    device.TryGetFeatureValue(CommonUsages.deviceRotation, out rotation))
                {
                    return true;
                }
            }

            position = Vector3.zero;
            rotation = Quaternion.identity;
            return false;
        }

        private void HandleTriggerInput()
        {
            bool triggerState = GetButtonState(m_TriggerButton);
            
            if (triggerState && !m_TriggerPressed && m_HasValidHit)
            {
                OnTriggerPressed();
            }
            
            m_TriggerPressed = triggerState;
        }

        private void HandleGrabInput()
        {
            bool grabState = GetButtonState(m_GrabButton);
            
            if (grabState && !m_GrabPressed)
            {
                OnGrabPressed();
            }
            
            m_GrabPressed = grabState;
        }

        private bool GetButtonState(InputHelpers.Button button)
        {
            if (m_XRController != null && m_XRController.inputDevice.isValid)
            {
                if (m_XRController.inputDevice.TryGetFeatureValue(new InputFeatureUsage<bool>(button.ToString()), out bool value))
                {
                    return value;
                }
            }

            InputDevice device = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
            if (device.isValid)
            {
                if (InputHelpers.IsPressed(device, button, out bool pressed))
                {
                    return pressed;
                }
            }

            return false;
        }

        private void OnTriggerPressed()
        {
            float currentTime = Time.time;
            bool isDoubleTrigger = (currentTime - m_LastTriggerTime) < 0.4f;
            m_LastTriggerTime = currentTime;
            
            if (!m_PolyMask.m_IsDrawing)
            {
                TryGetControllerTransform(out _, out Quaternion rotation);
                Vector3 planeNormal = rotation * Vector3.forward;
                
                // Generate predefined shape or start custom drawing
                if (m_PolyMask.m_ShapeType != GaussianPolyMask.ShapeType.Custom)
                {
                    m_PolyMask.GenerateShape(m_LastHitPoint, planeNormal, m_ShapeGenerationSize);
                }
                else
                {
                    m_PolyMask.StartDrawing(m_LastHitPoint, Vector3.up);
                }
                return;
            }

            // Double-trigger closes polygon
            if (isDoubleTrigger && m_PolyMask.m_Vertices.Count >= 3)
            {
                m_PolyMask.ClosePath();
                return;
            }

            // Check minimum distance from last vertex
            if (m_PolyMask.m_Vertices.Count > 0)
            {
                Vector3 lastPoint = m_PolyMask.transform.TransformPoint(
                    m_PolyMask.m_Vertices[m_PolyMask.m_Vertices.Count - 1]);
                if (Vector3.Distance(m_LastHitPoint, lastPoint) < m_MinVertexDistance)
                {
                    return;
                }
            }

            // Use 3D placement in world space
            m_PolyMask.AddVertex3D(m_LastHitPoint);
        }

        private void OnGrabPressed()
        {
            if (!m_PolyMask.IsClosed)
                return;

            // Delete the drawn area by applying it to the splat renderer
            SplatBoxRenderer[] renderers = FindObjectsOfType<SplatBoxRenderer>();
            foreach (var renderer in renderers)
            {
                if (renderer.m_Cutouts == null)
                {
                    renderer.m_Cutouts = new GaussianCutout[] { m_PolyMask };
                }
                else
                {
                    List<GaussianCutout> cutouts = new List<GaussianCutout>(renderer.m_Cutouts);
                    if (!cutouts.Contains(m_PolyMask))
                    {
                        cutouts.Add(m_PolyMask);
                        renderer.m_Cutouts = cutouts.ToArray();
                    }
                }
            }

            // Don't clear - the polygon needs to stay active for the cutout to work
            // The cutout is continuously evaluated every frame
        }

        private void UpdateRayVisualizer(Vector3 start, Vector3 end, bool invalid)
        {
            if (m_RayLine == null)
                return;

            m_RayLine.SetPosition(0, start);
            m_RayLine.SetPosition(1, end);
            
            Color rayColor = m_PolyMask.IsClosed ? m_DeleteRayColor : m_DrawRayColor;
            if (invalid)
                rayColor.a = 0.3f;
            
            m_RayLine.startColor = rayColor;
            m_RayLine.endColor = rayColor;
            m_RayVisualizer.SetActive(true);
        }

        private void OnDestroy()
        {
            if (m_RayVisualizer != null)
            {
                Destroy(m_RayVisualizer);
            }
        }

        private void OnDisable()
        {
            if (m_RayVisualizer != null)
            {
                m_RayVisualizer.SetActive(false);
            }
        }
    }
}
#endif