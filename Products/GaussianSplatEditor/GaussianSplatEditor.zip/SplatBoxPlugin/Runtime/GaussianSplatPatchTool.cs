// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Multi-patch repair tool for Gaussian splats.
    /// Allows defining source patches (good areas) and filling target regions with copies.
    /// </summary>
    public class GaussianSplatPatchTool : MonoBehaviour
    {
        [Serializable]
        public class PatchData
        {
            public string name = "Patch";
            public Vector3 position;
            public Vector3 size = Vector3.one;
            public Color gizmoColor = Color.green;
            
            public PatchData() { }
            public PatchData(Vector3 pos, Vector3 sz, string n = "Patch")
            {
                position = pos;
                size = sz;
                name = n;
                gizmoColor = new Color(UnityEngine.Random.value, UnityEngine.Random.value, UnityEngine.Random.value, 0.5f);
            }
        }
        
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] private List<PatchData> m_SourcePatches = new List<PatchData>();
        [SerializeField] private PatchData m_TargetRegion = new PatchData { name = "Target", gizmoColor = new Color(1f, 0.3f, 0.3f, 0.5f) };
        
        [Header("Grid Fill Settings")]
        [SerializeField] private Vector3 m_GridCellSize = Vector3.one;
        [SerializeField] private Vector3 m_GridOffset = Vector3.zero;
        [SerializeField] private bool m_RandomizePatchSelection = true;
        [SerializeField] private bool m_RandomizeRotation = false;
        [SerializeField] [Range(0f, 0.5f)] private float m_PositionJitter = 0.1f;
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public List<PatchData> SourcePatches => m_SourcePatches;
        public PatchData TargetRegion => m_TargetRegion;
        public Vector3 GridCellSize { get => m_GridCellSize; set => m_GridCellSize = value; }
        public Vector3 GridOffset { get => m_GridOffset; set => m_GridOffset = value; }
        public bool RandomizePatchSelection { get => m_RandomizePatchSelection; set => m_RandomizePatchSelection = value; }
        public bool RandomizeRotation { get => m_RandomizeRotation; set => m_RandomizeRotation = value; }
        public float PositionJitter { get => m_PositionJitter; set => m_PositionJitter = value; }
        
        public static bool IsBrushModeActive { get; set; } = false;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        public int AddSourcePatch(Vector3 position, Vector3 size)
        {
            var patch = new PatchData(position, size, $"Patch {m_SourcePatches.Count + 1}");
            m_SourcePatches.Add(patch);
            return m_SourcePatches.Count - 1;
        }
        
        public void RemoveSourcePatch(int index)
        {
            if (index >= 0 && index < m_SourcePatches.Count)
                m_SourcePatches.RemoveAt(index);
        }
        
        public void ClearSourcePatches()
        {
            m_SourcePatches.Clear();
        }
        
        public void SetTargetRegion(Vector3 position, Vector3 size)
        {
            m_TargetRegion.position = position;
            m_TargetRegion.size = size;
        }
        
        public void DeleteTargetRegion()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                Debug.LogWarning("PatchTool: No valid renderer");
                return;
            }
            
            m_TargetRenderer.DeleteSplatsInBox(m_TargetRegion.position, m_TargetRegion.size);
        }
        
        public void PastePatchAt(int patchIndex, Vector3 targetPosition)
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                Debug.LogWarning("PatchTool: No valid renderer");
                return;
            }
            
            if (patchIndex < 0 || patchIndex >= m_SourcePatches.Count)
            {
                Debug.LogWarning($"PatchTool: Invalid patch index {patchIndex}");
                return;
            }
            
            var patch = m_SourcePatches[patchIndex];
            m_TargetRenderer.CloneSplatsInBox(patch.position, targetPosition, patch.size);
        }
        
        public void PasteRandomPatchAt(Vector3 targetPosition)
        {
            if (m_SourcePatches.Count == 0)
            {
                Debug.LogWarning("PatchTool: No source patches defined");
                return;
            }
            
            int idx = UnityEngine.Random.Range(0, m_SourcePatches.Count);
            PastePatchAt(idx, targetPosition);
        }
        
        public void GridFillTargetRegion()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
            {
                Debug.LogWarning("PatchTool: No valid renderer");
                return;
            }
            
            if (m_SourcePatches.Count == 0)
            {
                Debug.LogWarning("PatchTool: No source patches defined");
                return;
            }
            
            // Calculate grid dimensions
            Vector3 targetMin = m_TargetRegion.position - m_TargetRegion.size * 0.5f;
            Vector3 targetMax = m_TargetRegion.position + m_TargetRegion.size * 0.5f;
            
            Vector3 cellSize = m_GridCellSize;
            if (cellSize.x <= 0) cellSize.x = 1f;
            if (cellSize.y <= 0) cellSize.y = 1f;
            if (cellSize.z <= 0) cellSize.z = 1f;
            
            int gridX = Mathf.CeilToInt(m_TargetRegion.size.x / cellSize.x);
            int gridY = Mathf.CeilToInt(m_TargetRegion.size.y / cellSize.y);
            int gridZ = Mathf.CeilToInt(m_TargetRegion.size.z / cellSize.z);
            
            Debug.Log($"PatchTool: Grid fill {gridX}x{gridY}x{gridZ} = {gridX * gridY * gridZ} cells");
            
            int patchIdx = 0;
            int placedCount = 0;
            
            for (int x = 0; x < gridX; x++)
            {
                for (int y = 0; y < gridY; y++)
                {
                    for (int z = 0; z < gridZ; z++)
                    {
                        // Calculate cell center
                        Vector3 cellCenter = targetMin + m_GridOffset + new Vector3(
                            (x + 0.5f) * cellSize.x,
                            (y + 0.5f) * cellSize.y,
                            (z + 0.5f) * cellSize.z);
                        
                        // Add jitter
                        if (m_PositionJitter > 0)
                        {
                            cellCenter += new Vector3(
                                UnityEngine.Random.Range(-m_PositionJitter, m_PositionJitter) * cellSize.x,
                                UnityEngine.Random.Range(-m_PositionJitter, m_PositionJitter) * cellSize.y,
                                UnityEngine.Random.Range(-m_PositionJitter, m_PositionJitter) * cellSize.z);
                        }
                        
                        // Skip if outside target region
                        if (cellCenter.x < targetMin.x || cellCenter.x > targetMax.x ||
                            cellCenter.y < targetMin.y || cellCenter.y > targetMax.y ||
                            cellCenter.z < targetMin.z || cellCenter.z > targetMax.z)
                            continue;
                        
                        // Select patch
                        if (m_RandomizePatchSelection)
                            patchIdx = UnityEngine.Random.Range(0, m_SourcePatches.Count);
                        else
                            patchIdx = (patchIdx + 1) % m_SourcePatches.Count;
                        
                        PastePatchAt(patchIdx, cellCenter);
                        placedCount++;
                    }
                }
            }
            
            Debug.Log($"PatchTool: Placed {placedCount} patches");
        }
        
        public void DeleteAndFill()
        {
            DeleteTargetRegion();
            GridFillTargetRegion();
        }
        
        public List<Vector3> GetGridPreviewPositions()
        {
            var positions = new List<Vector3>();
            
            Vector3 targetMin = m_TargetRegion.position - m_TargetRegion.size * 0.5f;
            Vector3 targetMax = m_TargetRegion.position + m_TargetRegion.size * 0.5f;
            
            Vector3 cellSize = m_GridCellSize;
            if (cellSize.x <= 0) cellSize.x = 1f;
            if (cellSize.y <= 0) cellSize.y = 1f;
            if (cellSize.z <= 0) cellSize.z = 1f;
            
            int gridX = Mathf.CeilToInt(m_TargetRegion.size.x / cellSize.x);
            int gridY = Mathf.CeilToInt(m_TargetRegion.size.y / cellSize.y);
            int gridZ = Mathf.CeilToInt(m_TargetRegion.size.z / cellSize.z);
            
            for (int x = 0; x < gridX; x++)
            {
                for (int y = 0; y < gridY; y++)
                {
                    for (int z = 0; z < gridZ; z++)
                    {
                        Vector3 cellCenter = targetMin + m_GridOffset + new Vector3(
                            (x + 0.5f) * cellSize.x,
                            (y + 0.5f) * cellSize.y,
                            (z + 0.5f) * cellSize.z);
                        
                        if (cellCenter.x >= targetMin.x && cellCenter.x <= targetMax.x &&
                            cellCenter.y >= targetMin.y && cellCenter.y <= targetMax.y &&
                            cellCenter.z >= targetMin.z && cellCenter.z <= targetMax.z)
                        {
                            positions.Add(cellCenter);
                        }
                    }
                }
            }
            
            return positions;
        }

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (IsBrushModeActive) return;
            
            // Draw source patches
            foreach (var patch in m_SourcePatches)
            {
                Gizmos.color = new Color(patch.gizmoColor.r, patch.gizmoColor.g, patch.gizmoColor.b, 0.3f);
                Gizmos.DrawCube(patch.position, patch.size);
                Gizmos.color = new Color(patch.gizmoColor.r, patch.gizmoColor.g, patch.gizmoColor.b, 0.9f);
                Gizmos.DrawWireCube(patch.position, patch.size);
            }
            
            // Draw target region
            Gizmos.color = new Color(m_TargetRegion.gizmoColor.r, m_TargetRegion.gizmoColor.g, m_TargetRegion.gizmoColor.b, 0.2f);
            Gizmos.DrawCube(m_TargetRegion.position, m_TargetRegion.size);
            Gizmos.color = new Color(1f, 0.3f, 0.3f, 0.9f);
            Gizmos.DrawWireCube(m_TargetRegion.position, m_TargetRegion.size);
        }
#endif
    }
}

