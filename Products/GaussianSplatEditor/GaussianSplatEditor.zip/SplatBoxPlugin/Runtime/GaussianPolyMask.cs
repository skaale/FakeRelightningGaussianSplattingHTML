// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianPolyMask : GaussianCutout
    {
        public enum ShapeType
        {
            Custom,
            Box,
            Circle,
            Hexagon,
            Star
        }

        public ShapeType m_ShapeType = ShapeType.Custom;
        public bool m_IsDrawing = false;
        public List<Vector3> m_Vertices = new List<Vector3>();
        
        // Store visual vertices (without expansion) for gizmo drawing
        private List<Vector3> m_VisualVertices = new List<Vector3>();
        
        [SerializeField] private bool m_IsClosed = false;
        private uint m_DetectedExtrusionAxis = 0;  // Cached detected axis: 0=Z, 1=X, 2=Y
        [System.NonSerialized] private Plane m_DrawPlane;
        [SerializeField] private Vector3 m_PlaneNormal = Vector3.up;
        // m_ExtrusionDepth removed - reserved field was never used
        [SerializeField] private float m_ShapeSize = 1.0f;
        [SerializeField] private int m_CircleSegments = 16;
        [SerializeField] private int m_StarPoints = 5;
        [SerializeField] private float m_StarInnerRadius = 0.5f;
        
        public enum ExtrusionAxis { Auto, X, Y, Z }
        
        [Header("Cutout Area Expansion")]
        [SerializeField] [Range(-3.0f, 3.0f)] private float m_ExpansionX = 2.0f;
        [SerializeField] [Range(-3.0f, 3.0f)] private float m_ExpansionY = 1.9f;
        [Tooltip("Expand cutout area beyond visual bounds. Increase if edges don't delete enough splats.")]
        
        [Header("Cutout Area Offset")]
        [SerializeField] [Range(-2.0f, 2.0f)] private float m_OffsetX = 0.0f;
        [SerializeField] [Range(-2.0f, 2.0f)] private float m_OffsetY = 0.0f;
        [Tooltip("Shift cutout area position in local space. Use to fine-tune coverage without redrawing.")]
        
        [Header("Extrusion Settings")]
        [SerializeField] private ExtrusionAxis m_ExtrusionAxis = ExtrusionAxis.Auto;
        [SerializeField] [Range(0.1f, 100.0f)] private float m_CutDepth = 100.0f;
        [Tooltip("Auto = detect from polygon orientation | X/Y/Z = force specific extrusion axis")]

        public bool IsClosed => m_IsClosed && m_Vertices.Count >= 3;
        
        /// <summary>Effective extrusion axis (for Editor gizmo: 0=Z, 1=X, 2=Y).</summary>
        public uint EffectiveExtrusionAxis => m_ExtrusionAxis == ExtrusionAxis.Auto ? m_DetectedExtrusionAxis : (uint)m_ExtrusionAxis;
        
        /// <summary>Cut depth for extrusion (for Editor gizmo).</summary>
        public float CutDepth => m_CutDepth;
        
        // Get vertices for visual display (uses visual vertices if available, otherwise regular vertices)
        public List<Vector3> GetDisplayVertices() => m_VisualVertices.Count > 0 ? m_VisualVertices : m_Vertices;
        
        // Bounds properties for editor display
        public Vector3 BoundsCenter => transform.position;
        public Vector3 BoundsSize => transform.localScale * 2f;

        public void StartDrawing(Vector3 startPoint, Vector3 planeNormal)
        {
            m_IsDrawing = true;
            m_IsClosed = false;
            m_Vertices.Clear();
            m_PlaneNormal = planeNormal.normalized;
            m_DrawPlane = new Plane(m_PlaneNormal, startPoint);
            AddVertex3D(startPoint);
        }

        public void AddVertex(Vector3 worldPos)
        {
            if (!m_IsDrawing) return;
            
            Vector3 projectedPos = m_DrawPlane.ClosestPointOnPlane(worldPos);
            Vector3 localPos = transform.InverseTransformPoint(projectedPos);
            m_Vertices.Add(localPos);
        }

        public void AddVertex3D(Vector3 worldPos)
        {
            if (!m_IsDrawing) return;
            
            Vector3 localPos = transform.InverseTransformPoint(worldPos);
            m_Vertices.Add(localPos);
        }

        public void ClosePath()
        {
            if (m_Vertices.Count >= 3)
            {
                m_IsClosed = true;
                m_IsDrawing = false;
                
                // Auto-scale to fit bounds
                NormalizeToBounds();
            }
        }
        
        private void NormalizeToBounds()
        {
            if (m_Vertices.Count < 3)
            {
                Debug.LogWarning("NormalizeToBounds: Not enough vertices");
                return;
            }
            
            // Check for parent scale issues
            if (transform.parent != null && transform.parent.lossyScale != Vector3.one)
            {
                Debug.LogWarning($"⚠️ Parent has non-uniform scale: {transform.parent.lossyScale} - may affect cutout accuracy!");
            }
            
            // Calculate bounds in WORLD space using original transform
            List<Vector3> worldVertices = new List<Vector3>();
            Vector3 worldMin = transform.TransformPoint(m_Vertices[0]);
            Vector3 worldMax = worldMin;
            
            foreach (var v in m_Vertices)
            {
                Vector3 worldV = transform.TransformPoint(v);
                worldVertices.Add(worldV);
                worldMin = Vector3.Min(worldMin, worldV);
                worldMax = Vector3.Max(worldMax, worldV);
            }
            
            Vector3 worldCenter = (worldMin + worldMax) * 0.5f;
            Vector3 worldSize = worldMax - worldMin;
            
            // Update transform to center and scale
            transform.position = worldCenter;
            
            Vector3 targetScale = new Vector3(
                worldSize.x > 0.001f ? worldSize.x * 0.5f : 1f,
                worldSize.y > 0.001f ? worldSize.y * 0.5f : 1f,
                worldSize.z > 0.001f ? worldSize.z * 0.5f : 1f
            );
            
            transform.localScale = targetScale;
            
            // Convert world vertices back to new local space
            Vector3 localMin = Vector3.one * float.MaxValue;
            Vector3 localMax = Vector3.one * float.MinValue;
            
            for (int i = 0; i < m_Vertices.Count; i++)
            {
                m_Vertices[i] = transform.InverseTransformPoint(worldVertices[i]);
                localMin = Vector3.Min(localMin, m_Vertices[i]);
                localMax = Vector3.Max(localMax, m_Vertices[i]);
            }
            
            // Explicitly normalize to [-1, 1] range
            Vector3 localSize = localMax - localMin;
            Vector3 localCenter = (localMin + localMax) * 0.5f;
            
            // Normalize to [-1, 1] range (expansion is now handled in shader, not here)
            for (int i = 0; i < m_Vertices.Count; i++)
            {
                Vector3 centered = m_Vertices[i] - localCenter;
                Vector3 normalized = new Vector3(
                    localSize.x > 0.001f ? centered.x / (localSize.x * 0.5f) : 0,
                    localSize.y > 0.001f ? centered.y / (localSize.y * 0.5f) : 0,
                    localSize.z > 0.001f ? centered.z / (localSize.z * 0.5f) : 0
                );
                m_Vertices[i] = normalized;
            }
            
            // Store copy for visual display (same as vertices since expansion is in shader)
            m_VisualVertices = new List<Vector3>(m_Vertices);
            
            
            // Calculate 2D area and detect extrusion axis based on the two largest dimensions
            Vector3 scale2x = transform.localScale * 2f;
            float area1, area2;
            string axisNames;
            
            if (worldSize.z < worldSize.x && worldSize.z < worldSize.y)
            {
                // XY plane (vertical polygon) - extrude through Z
                area1 = scale2x.x; area2 = scale2x.y; axisNames = "XY";
                m_DetectedExtrusionAxis = 0;  // or 3
            }
            else if (worldSize.y < worldSize.x && worldSize.y < worldSize.z)
            {
                // XZ plane (horizontal polygon) - extrude through Y
                area1 = scale2x.x; area2 = scale2x.z; axisNames = "XZ";
                m_DetectedExtrusionAxis = 2;
            }
            else
            {
                // YZ plane - extrude through X
                area1 = scale2x.y; area2 = scale2x.z; axisNames = "YZ";
                m_DetectedExtrusionAxis = 1;
            }
            
            // Log summary
            if (area1 < 0.1f || area2 < 0.1f)
            {
                Debug.LogWarning($"⚠️ Cutout area: {area1:F2}m x {area2:F2}m - very small!");
            }
            else
            {
                Debug.Log($"✓ Polygon cutout: {axisNames} {area1:F1}m x {area2:F1}m x {m_CutDepth:F0}m depth");
            }
        }

        public void Clear()
        {
            m_Vertices.Clear();
            m_VisualVertices.Clear();
            m_IsClosed = false;
            m_IsDrawing = false;
        }
        

        public void GenerateShape(Vector3 center, Vector3 planeNormal, float size)
        {
            Clear();
            m_PlaneNormal = planeNormal.normalized;
            m_DrawPlane = new Plane(m_PlaneNormal, center);
            m_ShapeSize = size;

            Vector3 right = Vector3.Cross(m_PlaneNormal, Vector3.up);
            if (right.sqrMagnitude < 0.001f)
                right = Vector3.Cross(m_PlaneNormal, Vector3.forward);
            right.Normalize();
            
            Vector3 up = Vector3.Cross(right, m_PlaneNormal).normalized;

            switch (m_ShapeType)
            {
                case ShapeType.Box:
                    GenerateBox(center, right, up, size);
                    break;
                case ShapeType.Circle:
                    GenerateCircle(center, right, up, size);
                    break;
                case ShapeType.Hexagon:
                    GenerateHexagon(center, right, up, size);
                    break;
                case ShapeType.Star:
                    GenerateStar(center, right, up, size);
                    break;
            }

            if (m_Vertices.Count >= 3)
            {
                m_IsClosed = true;
                
                // Auto-scale for predefined shapes too
                NormalizeToBounds();
            }
        }

        private void GenerateBox(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float halfSize = size * 0.5f;
            Vector3[] corners = new Vector3[]
            {
                center + right * halfSize + up * halfSize,
                center - right * halfSize + up * halfSize,
                center - right * halfSize - up * halfSize,
                center + right * halfSize - up * halfSize
            };

            foreach (var corner in corners)
            {
                Vector3 localPos = transform.InverseTransformPoint(corner);
                m_Vertices.Add(localPos);
            }
        }

        private void GenerateCircle(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float radius = size * 0.5f;
            for (int i = 0; i < m_CircleSegments; i++)
            {
                float angle = (i / (float)m_CircleSegments) * Mathf.PI * 2f;
                Vector3 point = center + (Mathf.Cos(angle) * right + Mathf.Sin(angle) * up) * radius;
                Vector3 localPos = transform.InverseTransformPoint(point);
                m_Vertices.Add(localPos);
            }
        }

        private void GenerateHexagon(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float radius = size * 0.5f;
            for (int i = 0; i < 6; i++)
            {
                float angle = (i / 6f) * Mathf.PI * 2f;
                Vector3 point = center + (Mathf.Cos(angle) * right + Mathf.Sin(angle) * up) * radius;
                Vector3 localPos = transform.InverseTransformPoint(point);
                m_Vertices.Add(localPos);
            }
        }

        private void GenerateStar(Vector3 center, Vector3 right, Vector3 up, float size)
        {
            float outerRadius = size * 0.5f;
            float innerRadius = outerRadius * m_StarInnerRadius;
            
            for (int i = 0; i < m_StarPoints * 2; i++)
            {
                float angle = (i / (float)(m_StarPoints * 2)) * Mathf.PI * 2f;
                float radius = (i % 2 == 0) ? outerRadius : innerRadius;
                Vector3 point = center + (Mathf.Cos(angle) * right + Mathf.Sin(angle) * up) * radius;
                Vector3 localPos = transform.InverseTransformPoint(point);
                m_Vertices.Add(localPos);
            }
        }

        public bool IsPointInside(Vector3 worldPoint)
        {
            if (!IsClosed) return false;

            Vector3 localPoint = transform.InverseTransformPoint(worldPoint);
            Vector3 projectedPoint = ProjectToDrawPlane(localPoint);

            return IsPointInPolygon2D(projectedPoint);
        }

        private Vector3 ProjectToDrawPlane(Vector3 localPoint)
        {
            Vector3 worldPoint = transform.TransformPoint(localPoint);
            Vector3 projected = m_DrawPlane.ClosestPointOnPlane(worldPoint);
            return transform.InverseTransformPoint(projected);
        }

        private bool IsPointInPolygon2D(Vector3 point)
        {
            if (m_Vertices.Count < 3) return false;

            Vector3 right = Vector3.Cross(m_PlaneNormal, Vector3.up);
            if (right.sqrMagnitude < 0.001f)
                right = Vector3.Cross(m_PlaneNormal, Vector3.forward);
            right.Normalize();
            
            Vector3 up = Vector3.Cross(right, m_PlaneNormal).normalized;

            bool inside = false;
            int j = m_Vertices.Count - 1;
            
            for (int i = 0; i < m_Vertices.Count; i++)
            {
                Vector2 vi = new Vector2(Vector3.Dot(m_Vertices[i], right), Vector3.Dot(m_Vertices[i], up));
                Vector2 vj = new Vector2(Vector3.Dot(m_Vertices[j], right), Vector3.Dot(m_Vertices[j], up));
                Vector2 p = new Vector2(Vector3.Dot(point, right), Vector3.Dot(point, up));

                if ((vi.y > p.y) != (vj.y > p.y) &&
                    (p.x < (vj.x - vi.x) * (p.y - vi.y) / (vj.y - vi.y) + vi.x))
                {
                    inside = !inside;
                }
                j = i;
            }

            return inside;
        }

        public static ShaderData GetShaderData(GaussianPolyMask self, Matrix4x4 rendererMatrix)
        {
            ShaderData sd = default;
            if (self && self.isActiveAndEnabled && self.IsClosed)
            {
                var tr = self.transform;
                
                // Use worldToLocalMatrix WITH rendererMatrix (standard cutout behavior)
                sd.matrix = tr.worldToLocalMatrix * rendererMatrix;
                
                sd.typeAndFlags = 2u | (self.m_Invert ? 0x100u : 0u);
                
                // Pass expansion, offset, and depth values to shader (real-time control)
                sd.expansionX = self.m_ExpansionX;
                sd.expansionY = self.m_ExpansionY;
                sd.cutDepth = self.m_CutDepth;
                sd.offsetX = self.m_OffsetX;
                sd.offsetY = self.m_OffsetY;
                
                // Determine extrusion axis
                if (self.m_ExtrusionAxis == ExtrusionAxis.Auto)
                    sd.extrusionAxis = self.m_DetectedExtrusionAxis;  // Use auto-detected
                else
                    sd.extrusionAxis = (uint)self.m_ExtrusionAxis;  // Use manual override
            }
            else
            {
                sd.typeAndFlags = ~0u;
                sd.expansionX = 1.0f;
                sd.expansionY = 1.0f;
                sd.cutDepth = 100.0f;
                sd.extrusionAxis = 0;
                sd.offsetX = 0.0f;
                sd.offsetY = 0.0f;
                //Debug.LogWarning($"Polygon NOT active: enabled={self?.isActiveAndEnabled}, closed={self?.IsClosed}");
            }
            return sd;
        }

    }
}

