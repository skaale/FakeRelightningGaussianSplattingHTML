// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public class GaussianSplatCloneBrush : MonoBehaviour
    {
        [SerializeField] [Range(0.01f, 2.0f)] private float m_SelectionDepth = 0.2f;
        [SerializeField] [Range(-2.0f, 2.0f)] private float m_DepthOffset = 0f;
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        
        // Polygon vertices for source selection
        private List<Vector3> m_SourceVertices = new List<Vector3>();
        private bool m_IsDrawingSource = true; // true = drawing source, false = placing target
        private Vector3 m_SourceCenter;
        private Vector3 m_TargetPosition;
        private bool m_HasTarget = false;
        
        public float SelectionDepth
        {
            get => m_SelectionDepth;
            set => m_SelectionDepth = Mathf.Clamp(value, 0.01f, 2.0f);
        }
        
        public float DepthOffset
        {
            get => m_DepthOffset;
            set => m_DepthOffset = Mathf.Clamp(value, -2.0f, 2.0f);
        }
        
        public List<Vector3> SourceVertices => m_SourceVertices;
        public bool IsDrawingSource => m_IsDrawingSource;
        public Vector3 SourceCenter => m_SourceCenter;
        public Vector3 TargetPosition => m_TargetPosition;
        public bool HasTarget => m_HasTarget;
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public bool HasSourcePolygon => m_SourceVertices.Count >= 3;
        public bool HasTargetPosition => m_HasTarget;
        
        public static bool IsBrushModeActive { get; set; } = false;
        public static Vector3 LastBrushPosition { get; set; }
        public static bool HasValidBrushPosition { get; set; } = false;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        /// <summary>
        /// Add a vertex to source polygon or set target position
        /// </summary>
        public void AddVertex(Vector3 worldPosition)
        {
            if (m_IsDrawingSource)
            {
                m_SourceVertices.Add(worldPosition);
                UpdateSourceCenter();
            }
            else
            {
                // Single click sets target position
                SetTargetPosition(worldPosition);
            }
        }
        
        /// <summary>
        /// Set the target position directly
        /// </summary>
        public void SetTargetPosition(Vector3 worldPosition)
        {
            m_TargetPosition = worldPosition;
            m_HasTarget = true;
        }
        
        /// <summary>
        /// Remove the last vertex from source polygon or clear target
        /// </summary>
        public void UndoLastVertex()
        {
            if (m_IsDrawingSource && m_SourceVertices.Count > 0)
            {
                m_SourceVertices.RemoveAt(m_SourceVertices.Count - 1);
                UpdateSourceCenter();
            }
            else if (!m_IsDrawingSource)
            {
                m_HasTarget = false;
            }
        }
        
        /// <summary>
        /// Finish drawing source polygon and switch to target mode
        /// </summary>
        public void FinishSourcePolygon()
        {
            if (m_SourceVertices.Count >= 3)
            {
                m_IsDrawingSource = false;
                Debug.Log($"CLONE: Source polygon complete with {m_SourceVertices.Count} vertices");
            }
        }
        
        /// <summary>
        /// Clear source polygon and start fresh
        /// </summary>
        public void ClearSource()
        {
            m_SourceVertices.Clear();
            m_IsDrawingSource = true;
        }
        
        /// <summary>
        /// Clear target position
        /// </summary>
        public void ClearTarget()
        {
            m_HasTarget = false;
        }
        
        /// <summary>
        /// Clear everything and start fresh
        /// </summary>
        public void ClearAll()
        {
            m_SourceVertices.Clear();
            m_HasTarget = false;
            m_IsDrawingSource = true;
        }
        
        private void UpdateSourceCenter()
        {
            if (m_SourceVertices.Count == 0)
            {
                m_SourceCenter = Vector3.zero;
                return;
            }
            
            Vector3 sum = Vector3.zero;
            foreach (var v in m_SourceVertices)
                sum += v;
            m_SourceCenter = sum / m_SourceVertices.Count;
        }
        
        /// <summary>
        /// Perform clone using polygon selection to target position
        /// </summary>
        public void PerformClone()
        {
            if (m_TargetRenderer == null || !HasSourcePolygon || !m_HasTarget)
                return;
            
            if (!m_TargetRenderer.HasValidAsset || !m_TargetRenderer.HasValidRenderSetup)
                return;
            
            m_TargetRenderer.CloneSplatsInPolygon(m_SourceVertices, m_SourceCenter, m_TargetPosition, m_SelectionDepth, m_DepthOffset);
            
            // Clear after clone
            ClearAll();
        }
        
        public bool CanClone => HasSourcePolygon && m_HasTarget && m_TargetRenderer != null && 
                                m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup;
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && m_TargetRenderer.HasValidRenderSetup;

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (IsBrushModeActive || !UnityEditor.Selection.Contains(gameObject))
                return;
            
            // Draw source polygon (green)
            if (m_SourceVertices.Count > 0)
            {
                Gizmos.color = new Color(0f, 1f, 0.5f, 0.7f);
                for (int i = 0; i < m_SourceVertices.Count; i++)
                {
                    Gizmos.DrawSphere(m_SourceVertices[i], 0.02f);
                    if (i > 0)
                        Gizmos.DrawLine(m_SourceVertices[i - 1], m_SourceVertices[i]);
                }
                if (m_SourceVertices.Count >= 3)
                    Gizmos.DrawLine(m_SourceVertices[m_SourceVertices.Count - 1], m_SourceVertices[0]);
            }
            
            // Draw target position (orange)
            if (m_HasTarget)
            {
                Gizmos.color = new Color(1f, 0.5f, 0f, 0.7f);
                Gizmos.DrawSphere(m_TargetPosition, 0.05f);
                Gizmos.DrawWireCube(m_TargetPosition, Vector3.one * 0.1f);
            }
            
            // Draw line from source center to target
            if (HasSourcePolygon && m_HasTarget)
            {
                Gizmos.color = Color.yellow;
                Gizmos.DrawLine(m_SourceCenter, m_TargetPosition);
            }
        }
#endif
    }
}

