// SPDX-License-Identifier: MIT
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
using UnityEngine.Rendering.RenderGraphModule.Util;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// URP Renderer Feature for Tilt-Shift miniature effect on Gaussian Splats.
    /// Add this to your URP Renderer to enable tilt-shift in game view.
    /// Settings can be overridden by adding a GaussianSplatTiltShiftEffect component to the camera.
    /// </summary>
    public class GaussianTiltShiftRendererFeature : ScriptableRendererFeature
    {
        public enum BlurMode
        {
            TiltShift = 0,
            DepthOfField = 1,
            Combined = 2
        }

        [System.Serializable]
        public class TiltShiftSettings
        {
            [Header("Blur Mode")]
            [Tooltip("TiltShift = horizontal band blur, DepthOfField = distance-based blur (requires Depth Texture), Combined = both")]
            public BlurMode blurMode = BlurMode.TiltShift;
            
            [Header("Tilt-Shift Focus")]
            [Range(0f, 1f)] public float focusPosition = 0.58f;
            [Range(0.001f, 0.8f)] public float focusWidth = 0.05f;
            [Range(-45f, 45f)] public float tiltAngle = 0f;
            
            [Header("Depth of Field (requires Depth Texture in URP Asset)")]
            [Tooltip("Distance from camera to focus point")]
            public float focusDistance = 10f;
            [Range(0.1f, 50f)] 
            [Tooltip("Range around focus distance that stays sharp")]
            public float focusRange = 5f;
            [Range(0f, 1f)] 
            [Tooltip("Blur intensity for objects closer than focus")]
            public float nearBlurStrength = 0.5f;
            [Range(0f, 1f)] 
            [Tooltip("Blur intensity for objects farther than focus")]
            public float farBlurStrength = 0.8f;
            
            [Header("Blur")]
            [Range(0f, 25f)] public float blurStrength = 10f;
            [Range(0f, 2f)] public float topBlurStrength = 1f;
            [Range(0f, 2f)] public float bottomBlurStrength = 1f;
            [Range(-0.5f, 0.5f)]
            [Tooltip("Moves the top blur edge up (+) or down (-) to align the focus band in VR.")]
            public float topBlurOffset = 0f;
            [Range(-0.5f, 0.5f)]
            [Tooltip("Moves the bottom blur edge down (+) or up (-) to align the focus band in VR.")]
            public float bottomBlurOffset = 0f;
            [Range(3, 16)] public int blurSamples = 8;
            [Range(0f, 1f)] public float bokehShape = 0.5f;
            
            [Header("Color Enhancement")]
            [Range(0.5f, 2f)] public float saturationBoost = 1f;
            [Range(0.5f, 2f)] public float contrastBoost = 1f;
            [Range(0f, 1f)] public float vignetteStrength = 0.58f;
            
            [Header("Rendering")]
            public RenderPassEvent renderPassEvent = RenderPassEvent.BeforeRenderingPostProcessing;
            public bool highQualityBlur = true;
            public bool enabled = true;
            
            [Header("Override")]
            [Tooltip("If true, settings from GaussianSplatTiltShiftEffect on camera will override these")]
            public bool allowCameraOverride = true;
            
            /// <summary>
            /// Copy settings from a GaussianSplatTiltShiftEffect component
            /// </summary>
            public void CopyFrom(GaussianSplatTiltShiftEffect effect)
            {
                if (effect == null) return;
                
                blurMode = (BlurMode)effect.blurMode;
                focusPosition = effect.focusPosition;
                focusWidth = effect.focusWidth;
                tiltAngle = effect.tiltAngle;
                focusDistance = effect.focusDistance;
                focusRange = effect.focusRange;
                nearBlurStrength = effect.nearBlurStrength;
                farBlurStrength = effect.farBlurStrength;
                blurStrength = effect.blurStrength;
                topBlurStrength = effect.topBlurStrength;
                bottomBlurStrength = effect.bottomBlurStrength;
                topBlurOffset = effect.topBlurOffset;
                bottomBlurOffset = effect.bottomBlurOffset;
                blurSamples = effect.blurSamples;
                bokehShape = effect.bokehShape;
                saturationBoost = effect.saturationBoost;
                contrastBoost = effect.contrastBoost;
                vignetteStrength = effect.vignetteStrength;
                highQualityBlur = effect.highQualityBlur;
                enabled = effect.effectEnabled;
            }
            
            /// <summary>
            /// Copy settings from global static settings (set by Editor Window)
            /// </summary>
            public void CopyFromGlobal()
            {
                blurMode = (BlurMode)GaussianTiltShiftGlobalSettings.BlurMode;
                focusPosition = GaussianTiltShiftGlobalSettings.FocusPosition;
                focusWidth = GaussianTiltShiftGlobalSettings.FocusWidth;
                tiltAngle = GaussianTiltShiftGlobalSettings.TiltAngle;
                focusDistance = GaussianTiltShiftGlobalSettings.FocusDistance;
                focusRange = GaussianTiltShiftGlobalSettings.FocusRange;
                nearBlurStrength = GaussianTiltShiftGlobalSettings.NearBlurStrength;
                farBlurStrength = GaussianTiltShiftGlobalSettings.FarBlurStrength;
                blurStrength = GaussianTiltShiftGlobalSettings.BlurStrength;
                topBlurStrength = GaussianTiltShiftGlobalSettings.TopBlurStrength;
                bottomBlurStrength = GaussianTiltShiftGlobalSettings.BottomBlurStrength;
                topBlurOffset = GaussianTiltShiftGlobalSettings.TopBlurOffset;
                bottomBlurOffset = GaussianTiltShiftGlobalSettings.BottomBlurOffset;
                blurSamples = GaussianTiltShiftGlobalSettings.BlurSamples;
                bokehShape = GaussianTiltShiftGlobalSettings.BokehShape;
                saturationBoost = GaussianTiltShiftGlobalSettings.SaturationBoost;
                contrastBoost = GaussianTiltShiftGlobalSettings.ContrastBoost;
                vignetteStrength = GaussianTiltShiftGlobalSettings.VignetteStrength;
                highQualityBlur = GaussianTiltShiftGlobalSettings.HighQualityBlur;
                enabled = GaussianTiltShiftGlobalSettings.Enabled;
            }
        }

        public TiltShiftSettings settings = new TiltShiftSettings();
        private TiltShiftRenderPass m_RenderPass;
        [SerializeField, HideInInspector] internal Shader m_Shader;
        private TiltShiftSettings m_RuntimeSettings;

#if UNITY_EDITOR
        private static Shader FindTiltShiftShaderEditor()
        {
            var shader = Shader.Find("Hidden/Gaussian Splatting/TiltShift");
            if (shader != null)
                return shader;

            var guids = UnityEditor.AssetDatabase.FindAssets("GaussianTiltShift t:Shader");
            foreach (var guid in guids)
            {
                var path = UnityEditor.AssetDatabase.GUIDToAssetPath(guid);
                shader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>(path);
                if (shader != null && shader.name == "Hidden/Gaussian Splatting/TiltShift")
                    return shader;
            }

            return null;
        }

        internal void EnsureShaderReferenceEditor()
        {
            if (m_Shader != null)
                return;

            m_Shader = FindTiltShiftShaderEditor();
            if (m_Shader != null)
                UnityEditor.EditorUtility.SetDirty(this);
        }

        /// <summary>
        /// Auto-find and serialize the shader reference so it is available in builds.
        /// Called when the feature is created, modified, or scripts reload.
        /// </summary>
        private void OnValidate()
        {
            EnsureShaderReferenceEditor();
        }

        private void Reset()
        {
            EnsureShaderReferenceEditor();
        }
#endif

        public override void Create()
        {
#if UNITY_EDITOR
            EnsureShaderReferenceEditor();
#endif
            // Use the serialized reference first; fall back to Shader.Find for editor/first-run
            if (m_Shader == null)
                m_Shader = Shader.Find("Hidden/Gaussian Splatting/TiltShift");
            if (m_Shader == null)
            {
                Debug.LogWarning("GaussianTiltShiftRendererFeature: Shader not found! Make sure 'Hidden/Gaussian Splatting/TiltShift' is included in the build.");
                return;
            }
            
            m_RuntimeSettings = new TiltShiftSettings();
            m_RenderPass = new TiltShiftRenderPass(settings, m_Shader);
            m_RenderPass.renderPassEvent = settings.renderPassEvent;
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (m_RenderPass == null)
                return;
            
            // Don't apply to preview cameras
            if (renderingData.cameraData.cameraType == CameraType.Preview)
                return;
            
            // The serialized feature `settings` are the SINGLE source of truth — they're authored in the URP
            // renderer-feature inspector and ship in the player/Android build. A GaussianSplatTiltShiftEffect
            // component on the camera is the ONLY runtime override (this is how the VR menu pushes live
            // changes). We deliberately no longer let GaussianTiltShiftGlobalSettings shadow the serialized
            // settings: that static flag stayed "Active" for the whole editor session and silently swallowed
            // every edit to the feature inspector, and reset to disabled in builds (so nothing rendered).
            var effectSettings = settings;
            var camera = renderingData.cameraData.camera;

            // Camera-component override (opt-in). Used by the VR settings menu (GaussianTiltShiftGlobalSettings
            // .SyncToCamera) so slider changes apply live in a build without touching the serialized asset.
            if (settings.allowCameraOverride && camera != null)
            {
                var cameraEffect = camera.GetComponent<GaussianSplatTiltShiftEffect>();
                if (cameraEffect != null)
                {
                    m_RuntimeSettings.CopyFrom(cameraEffect);
                    effectSettings = m_RuntimeSettings;
                }
            }

            // Check if effect should be disabled
            if (!effectSettings.enabled || effectSettings.blurStrength < 0.01f)
                return;
            
            // DoF mode requires depth texture
            if (effectSettings.blurMode != BlurMode.TiltShift)
            {
                if (!renderingData.cameraData.requiresDepthTexture)
                    renderingData.cameraData.requiresDepthTexture = true;
            }
                
            m_RenderPass.Setup(effectSettings);
            renderer.EnqueuePass(m_RenderPass);
        }

        protected override void Dispose(bool disposing)
        {
            m_RenderPass?.Cleanup();
        }
    }

    /// <summary>
    /// Editor-only bridge so the (URP-free) Editor Window can bake the live tilt-shift settings into the
    /// serialized feature settings without referencing URP types itself. This class deliberately does NOT
    /// derive from any URP type, so the Editor assembly can call it even though it doesn't reference URP.
    /// </summary>
    public static class GaussianTiltShiftBuildSync
    {
        public static void EnsureShaderReferencesOnRenderers()
        {
#if UNITY_EDITOR
            var pipelineGuids = UnityEditor.AssetDatabase.FindAssets("t:UniversalRenderPipelineAsset");
            var visited = new System.Collections.Generic.HashSet<ScriptableRendererData>();
            bool anyChanged = false;

            foreach (var pg in pipelineGuids)
            {
                var path = UnityEditor.AssetDatabase.GUIDToAssetPath(pg);
                var pipeline = UnityEditor.AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);
                if (pipeline == null)
                    continue;

                var pipelineSO = new UnityEditor.SerializedObject(pipeline);
                var rendererDataList = pipelineSO.FindProperty("m_RendererDataList");
                if (rendererDataList == null || !rendererDataList.isArray)
                    continue;

                for (int i = 0; i < rendererDataList.arraySize; i++)
                {
                    var rd = rendererDataList.GetArrayElementAtIndex(i).objectReferenceValue as ScriptableRendererData;
                    if (rd == null || !visited.Add(rd))
                        continue;

                    foreach (var f in rd.rendererFeatures)
                    {
                        var ts = f as GaussianTiltShiftRendererFeature;
                        if (ts == null)
                            continue;

                        var before = ts.m_Shader;
                        ts.EnsureShaderReferenceEditor();
                        if (before != ts.m_Shader)
                            anyChanged = true;
                    }
                }
            }

            if (anyChanged)
                UnityEditor.AssetDatabase.SaveAssets();
#endif
        }

        /// <summary>
        /// Copies the current GaussianTiltShiftGlobalSettings into the serialized settings of every
        /// GaussianTiltShiftRendererFeature on every URP renderer asset, then saves — so the values ship in
        /// player/Android builds (where the runtime globals reset to disabled defaults).
        /// </summary>
        public static void PersistGlobalsToRenderers()
        {
#if UNITY_EDITOR
            var pipelineGuids = UnityEditor.AssetDatabase.FindAssets("t:UniversalRenderPipelineAsset");
            var visited = new System.Collections.Generic.HashSet<ScriptableRendererData>();
            bool anyChanged = false;

            foreach (var pg in pipelineGuids)
            {
                var path = UnityEditor.AssetDatabase.GUIDToAssetPath(pg);
                var pipeline = UnityEditor.AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);
                if (pipeline == null)
                    continue;

                var pipelineSO = new UnityEditor.SerializedObject(pipeline);
                var rendererDataList = pipelineSO.FindProperty("m_RendererDataList");
                if (rendererDataList == null || !rendererDataList.isArray)
                    continue;

                for (int i = 0; i < rendererDataList.arraySize; i++)
                {
                    var rd = rendererDataList.GetArrayElementAtIndex(i).objectReferenceValue as ScriptableRendererData;
                    if (rd == null || !visited.Add(rd))
                        continue;

                    foreach (var f in rd.rendererFeatures)
                    {
                        var ts = f as GaussianTiltShiftRendererFeature;
                        if (ts == null || ts.settings == null)
                            continue;

                        ts.EnsureShaderReferenceEditor();
                        ts.settings.CopyFromGlobal();
                        UnityEditor.EditorUtility.SetDirty(ts);
                        anyChanged = true;
                    }
                }
            }

            if (anyChanged)
                UnityEditor.AssetDatabase.SaveAssets();
#endif
        }
    }

#if UNITY_EDITOR
    /// <summary>
    /// Hidden shaders are stripped from Android players unless a serialized asset reference keeps them alive.
    /// This hook does NOT touch values; it only makes sure the tilt-shift shader is referenced before builds.
    /// </summary>
    class GaussianTiltShiftBuildPreprocessor : UnityEditor.Build.IPreprocessBuildWithReport
    {
        public int callbackOrder => 0;

        public void OnPreprocessBuild(UnityEditor.Build.Reporting.BuildReport report)
        {
            GaussianTiltShiftBuildSync.EnsureShaderReferencesOnRenderers();
        }
    }
#endif

    public class TiltShiftRenderPass : ScriptableRenderPass
    {
        private GaussianTiltShiftRendererFeature.TiltShiftSettings m_Settings;
        private Material m_Material;
        
        private static readonly int PropFocusPosition = Shader.PropertyToID("_FocusPosition");
        private static readonly int PropFocusWidth = Shader.PropertyToID("_FocusWidth");
        private static readonly int PropBlurStrength = Shader.PropertyToID("_BlurStrength");
        private static readonly int PropTopBlurStrength = Shader.PropertyToID("_TopBlurStrength");
        private static readonly int PropBottomBlurStrength = Shader.PropertyToID("_BottomBlurStrength");
        private static readonly int PropTopBlurOffset = Shader.PropertyToID("_TopBlurOffset");
        private static readonly int PropBottomBlurOffset = Shader.PropertyToID("_BottomBlurOffset");
        private static readonly int PropBlurSamples = Shader.PropertyToID("_BlurSamples");
        private static readonly int PropTiltAngle = Shader.PropertyToID("_TiltAngle");
        private static readonly int PropSaturationBoost = Shader.PropertyToID("_SaturationBoost");
        private static readonly int PropContrastBoost = Shader.PropertyToID("_ContrastBoost");
        private static readonly int PropVignetteStrength = Shader.PropertyToID("_VignetteStrength");
        private static readonly int PropBokehShape = Shader.PropertyToID("_BokehShape");
        private static readonly int PropBlurMode = Shader.PropertyToID("_BlurMode");
        private static readonly int PropFocusDistance = Shader.PropertyToID("_FocusDistance");
        private static readonly int PropFocusRange = Shader.PropertyToID("_FocusRange");
        private static readonly int PropNearBlurStrength = Shader.PropertyToID("_NearBlurStrength");
        private static readonly int PropFarBlurStrength = Shader.PropertyToID("_FarBlurStrength");

        public TiltShiftRenderPass(GaussianTiltShiftRendererFeature.TiltShiftSettings settings, Shader shader)
        {
            m_Settings = settings;
            
            if (shader != null)
                m_Material = CoreUtils.CreateEngineMaterial(shader);
        }

        public void Setup(GaussianTiltShiftRendererFeature.TiltShiftSettings settings)
        {
            m_Settings = settings;
            renderPassEvent = settings.renderPassEvent;

            // A fullscreen effect must never sample the XR backbuffer directly. This makes URP allocate
            // a sampleable camera color texture on Quest as well as in the Editor.
            requiresIntermediateTexture = true;

            // Only DoF/Combined need a depth copy. Camera color is represented by the intermediate
            // requirement above; requesting Color here would create an unnecessary opaque-texture copy.
            if (settings.blurMode != GaussianTiltShiftRendererFeature.BlurMode.TiltShift)
                ConfigureInput(ScriptableRenderPassInput.Depth);
            else
                ConfigureInput(ScriptableRenderPassInput.None);
        }

        private void UpdateMaterialProperties()
        {
            if (m_Material == null) return;
            
            m_Material.SetFloat(PropBlurMode, (float)m_Settings.blurMode);
            m_Material.SetFloat(PropFocusPosition, m_Settings.focusPosition);
            m_Material.SetFloat(PropFocusWidth, m_Settings.focusWidth);
            m_Material.SetFloat(PropTiltAngle, m_Settings.tiltAngle);
            m_Material.SetFloat(PropFocusDistance, m_Settings.focusDistance);
            m_Material.SetFloat(PropFocusRange, m_Settings.focusRange);
            m_Material.SetFloat(PropNearBlurStrength, m_Settings.nearBlurStrength);
            m_Material.SetFloat(PropFarBlurStrength, m_Settings.farBlurStrength);
            m_Material.SetFloat(PropBlurStrength, m_Settings.blurStrength);
            m_Material.SetFloat(PropTopBlurStrength, m_Settings.topBlurStrength);
            m_Material.SetFloat(PropBottomBlurStrength, m_Settings.bottomBlurStrength);
            m_Material.SetFloat(PropTopBlurOffset, m_Settings.topBlurOffset);
            m_Material.SetFloat(PropBottomBlurOffset, m_Settings.bottomBlurOffset);
            m_Material.SetFloat(PropBlurSamples, m_Settings.blurSamples);
            m_Material.SetFloat(PropBokehShape, m_Settings.bokehShape);
            m_Material.SetFloat(PropSaturationBoost, m_Settings.saturationBoost);
            m_Material.SetFloat(PropContrastBoost, m_Settings.contrastBoost);
            m_Material.SetFloat(PropVignetteStrength, m_Settings.vignetteStrength);
        }

        private static TextureHandle CreateFullscreenTexture(
            RenderGraph renderGraph,
            TextureDesc sourceDesc,
            string name)
        {
            sourceDesc.name = name;
            sourceDesc.clearBuffer = false;
            sourceDesc.msaaSamples = MSAASamples.None;
            sourceDesc.depthBufferBits = DepthBits.None;
            return renderGraph.CreateTexture(sourceDesc);
        }

        private static void AddFullscreenBlit(
            RenderGraph renderGraph,
            TextureHandle source,
            TextureHandle destination,
            Material material,
            int shaderPass,
            string passName)
        {
            var parameters = new RenderGraphUtils.BlitMaterialParameters(
                source, destination, material, shaderPass);

            // AddBlitPass handles XR texture slices (including Single Pass Instanced) correctly.
            // Fullscreen image processing must not inherit Quest's non-uniform foveated rasterization.
            using var builder = renderGraph.AddBlitPass(parameters, passName, true);
            builder.EnableFoveatedRasterization(false);
        }

        // URP 17.3+ removed OnCameraSetup/Execute. RecordRenderGraph is the only path.
        public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
        {
            if (m_Material == null)
                return;

            var resourceData = frameData.Get<UniversalResourceData>();

            // Setup requires an intermediate texture. If URP still exposes the backbuffer, sampling it is
            // unsupported; skipping is safer than an undefined read/write feedback loop.
            if (resourceData.isActiveTargetBackBuffer || !resourceData.activeColorTexture.IsValid())
                return;

            UpdateMaterialProperties();

            TextureHandle source = resourceData.activeColorTexture;
            TextureDesc desc = renderGraph.GetTextureDesc(source);

            TextureHandle output;
            if (m_Settings.highQualityBlur)
            {
                TextureHandle tempH = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftHorizontal");
                TextureHandle tempV = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftVertical");
                output = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftOutput");

                AddFullscreenBlit(renderGraph, source, tempH, m_Material, 0, "TiltShift Horizontal");
                AddFullscreenBlit(renderGraph, tempH, tempV, m_Material, 1, "TiltShift Vertical");
                AddFullscreenBlit(renderGraph, tempV, output, m_Material, 2, "TiltShift Enhance");
            }
            else
            {
                output = CreateFullscreenTexture(renderGraph, desc, "_TiltShiftOutput");
                AddFullscreenBlit(renderGraph, source, output, m_Material, 3, "TiltShift Combined");
            }

            // Make every later URP pass (post-processing/final XR blit) consume the processed texture.
            // Swapping the graph resource is XR-safe and avoids writing back into the sampled camera color.
            resourceData.cameraColor = output;
        }

        public void Cleanup()
        {
            if (m_Material != null)
            {
                CoreUtils.Destroy(m_Material);
                m_Material = null;
            }
        }
    }
}
