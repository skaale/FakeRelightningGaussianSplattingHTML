// SPDX-License-Identifier: MIT

using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    public enum ColorizeBlendMode
    {
        Normal = 0,     // Simple lerp toward target color
        Multiply = 1,   // Darken by multiplying
        Screen = 2,     // Lighten (inverse multiply)
        Overlay = 3,    // Combines multiply and screen
        Darken = 4,     // Keep darker of two colors
        Lighten = 5,    // Keep lighter of two colors
        SoftLight = 6,  // Gentle overlay effect
        HardLight = 7,  // Intense overlay effect
        ColorDodge = 8, // Brighten and increase contrast
        ColorBurn = 9   // Darken and increase contrast
    }
    
    public class GaussianSplatColorizeBrush : MonoBehaviour
    {
        [SerializeField] private SplatBoxRenderer m_TargetRenderer;
        [SerializeField] [Range(0.1f, 10f)] private float m_ScreenRadius = 1.5f;
        [SerializeField] [Range(0.01f, 1f)] private float m_BlendStrength = 0.3f;
        [SerializeField] [Range(0f, 1f)] private float m_Falloff = 0.5f;
        [SerializeField] private Color m_TargetColor = Color.red;
        [SerializeField] private ColorizeBlendMode m_BlendMode = ColorizeBlendMode.Normal;
        [SerializeField] [Range(0f, 1f)] private float m_BlendModeIntensity = 1f;
        [SerializeField] private bool m_UseNoise = false;
        [SerializeField] [Range(0f, 1f)] private float m_NoiseStrength = 0.5f;
        [SerializeField] [Range(0.1f, 10f)] private float m_NoiseScale = 1f;
        [SerializeField] [Range(5, 50)] private int m_MaxUndoSteps = 20;
        
        public static bool IsBrushModeActive = false;
        public static bool HasValidBrushPosition = false;
        public static Vector3 LastBrushPosition;
        public static Vector3 CurrentViewDirection;
        public static float CurrentWorldRadius;
        public static bool IsColorizing = false;
        public static bool IsSampling = false;
        
        // Undo/Redo history
        private List<RenderTexture> m_UndoStack = new List<RenderTexture>();
        private List<RenderTexture> m_RedoStack = new List<RenderTexture>();
        
        public SplatBoxRenderer TargetRenderer
        {
            get => m_TargetRenderer;
            set => m_TargetRenderer = value;
        }
        
        public float ScreenRadius
        {
            get => m_ScreenRadius;
            set => m_ScreenRadius = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public float BlendStrength
        {
            get => m_BlendStrength;
            set => m_BlendStrength = Mathf.Clamp(value, 0.01f, 1f);
        }
        
        public float Falloff
        {
            get => m_Falloff;
            set => m_Falloff = Mathf.Clamp01(value);
        }
        
        public Color TargetColor
        {
            get => m_TargetColor;
            set => m_TargetColor = value;
        }
        
        public ColorizeBlendMode BlendMode
        {
            get => m_BlendMode;
            set => m_BlendMode = value;
        }
        
        public float BlendModeIntensity
        {
            get => m_BlendModeIntensity;
            set => m_BlendModeIntensity = Mathf.Clamp01(value);
        }
        
        public bool UseNoise
        {
            get => m_UseNoise;
            set => m_UseNoise = value;
        }
        
        public float NoiseStrength
        {
            get => m_NoiseStrength;
            set => m_NoiseStrength = Mathf.Clamp01(value);
        }
        
        public float NoiseScale
        {
            get => m_NoiseScale;
            set => m_NoiseScale = Mathf.Clamp(value, 0.1f, 10f);
        }
        
        public int MaxUndoSteps
        {
            get => m_MaxUndoSteps;
            set => m_MaxUndoSteps = Mathf.Clamp(value, 5, 50);
        }
        
        public int UndoCount => m_UndoStack.Count;
        public int RedoCount => m_RedoStack.Count;
        public bool CanUndo => m_UndoStack.Count > 0;
        public bool CanRedo => m_RedoStack.Count > 0;
        
        public bool IsValid => m_TargetRenderer != null && m_TargetRenderer.HasValidAsset && 
                               m_TargetRenderer.HasValidRenderSetup;
        
        private void OnEnable()
        {
            if (m_TargetRenderer == null)
                m_TargetRenderer = FindAnyObjectByType<SplatBoxRenderer>();
        }
        
        private void OnDestroy()
        {
            ClearUndoHistory();
        }
        
        /// <summary>
        /// Push current state to undo stack before making changes
        /// </summary>
        public void PushUndoState()
        {
            if (!IsValid) return;
            
            RenderTexture snapshot = m_TargetRenderer.CreateColorSnapshot();
            if (snapshot == null) return;
            
            m_UndoStack.Add(snapshot);
            
            // Clear redo stack when new action is performed
            ClearRedoStack();
            
            // Limit undo stack size
            while (m_UndoStack.Count > m_MaxUndoSteps)
            {
                if (m_UndoStack[0] != null)
                    DestroyImmediate(m_UndoStack[0]);
                m_UndoStack.RemoveAt(0);
            }
        }
        
        /// <summary>
        /// Undo last colorize stroke
        /// </summary>
        public bool Undo()
        {
            if (!CanUndo || !IsValid) return false;
            
            // Save current state for redo
            RenderTexture currentState = m_TargetRenderer.CreateColorSnapshot();
            if (currentState != null)
                m_RedoStack.Add(currentState);
            
            // Restore previous state
            int lastIdx = m_UndoStack.Count - 1;
            RenderTexture undoState = m_UndoStack[lastIdx];
            m_UndoStack.RemoveAt(lastIdx);
            
            m_TargetRenderer.RestoreColorSnapshot(undoState);
            
            if (undoState != null)
                DestroyImmediate(undoState);
            
            return true;
        }
        
        /// <summary>
        /// Redo previously undone stroke
        /// </summary>
        public bool Redo()
        {
            if (!CanRedo || !IsValid) return false;
            
            // Save current state for undo
            RenderTexture currentState = m_TargetRenderer.CreateColorSnapshot();
            if (currentState != null)
                m_UndoStack.Add(currentState);
            
            // Restore redo state
            int lastIdx = m_RedoStack.Count - 1;
            RenderTexture redoState = m_RedoStack[lastIdx];
            m_RedoStack.RemoveAt(lastIdx);
            
            m_TargetRenderer.RestoreColorSnapshot(redoState);
            
            if (redoState != null)
                DestroyImmediate(redoState);
            
            return true;
        }
        
        /// <summary>
        /// Clear all undo/redo history
        /// </summary>
        public void ClearUndoHistory()
        {
            ClearUndoStack();
            ClearRedoStack();
        }
        
        private void ClearUndoStack()
        {
            foreach (var rt in m_UndoStack)
            {
                if (rt != null) DestroyImmediate(rt);
            }
            m_UndoStack.Clear();
        }
        
        private void ClearRedoStack()
        {
            foreach (var rt in m_RedoStack)
            {
                if (rt != null) DestroyImmediate(rt);
            }
            m_RedoStack.Clear();
        }
        
        /// <summary>
        /// Colorize splats at the given world position
        /// </summary>
        public void ColorizeAtPosition(Vector3 worldPosition, float worldRadius)
        {
            if (!IsValid) return;
            float noiseStr = m_UseNoise ? m_NoiseStrength : 0f;
            m_TargetRenderer.ColorizeInSphere(worldPosition, worldRadius, m_TargetColor, m_BlendStrength, m_Falloff, (int)m_BlendMode, m_BlendModeIntensity, noiseStr, m_NoiseScale);
        }
        
        /// <summary>
        /// Sample color from splats at the given position
        /// </summary>
        public Color SampleColorAtPosition(Vector3 worldPosition, float worldRadius, Camera cam)
        {
            if (!IsValid) return Color.gray;
            return m_TargetRenderer.SampleSplatColorAtPosition(worldPosition, worldRadius, cam);
        }
        
        /// <summary>
        /// Set target color from sampled color
        /// </summary>
        public void SetTargetColorFromSample(Color sampledColor)
        {
            m_TargetColor = sampledColor;
        }

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!IsBrushModeActive || !HasValidBrushPosition) return;
            
            Gizmos.color = new Color(m_TargetColor.r, m_TargetColor.g, m_TargetColor.b, 0.3f);
            Gizmos.DrawSphere(LastBrushPosition, CurrentWorldRadius);
            
            Gizmos.color = m_TargetColor;
            Gizmos.DrawWireSphere(LastBrushPosition, CurrentWorldRadius);
        }
#endif
    }
}
