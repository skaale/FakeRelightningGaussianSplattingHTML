// SPDX-License-Identifier: MIT

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Simple trigger that activates a GaussianSplatAttractor when any object enters
    /// </summary>
    [RequireComponent(typeof(Collider))]
    public class GaussianSplatAttractorTrigger : MonoBehaviour
    {
        [System.Serializable]
        public class ObjectToEnable
        {
            [Tooltip("GameObject to enable")]
            public GameObject gameObject;
            [Tooltip("Delay in seconds before enabling")]
            public float delay = 0f;
        }

        [System.Serializable]
        public class AnimationToPlay
        {
            [Tooltip("Animator component to enable")]
            public Animator animator;
            [Tooltip("Delay in seconds before enabling")]
            public float delay = 0f;
        }

        [Header("Attractor Reference")]
        [Tooltip("The attractor to activate when any object enters trigger")]
        [SerializeField] private GaussianSplatAttractor m_Attractor;
        
        [Header("Trigger Settings")]
        [Tooltip("Deactivate attractor when object exits trigger")]
        [SerializeField] private bool m_DeactivateOnExit = false;

        [Header("Objects to Enable")]
        [Tooltip("Objects to enable when attractor activates (with optional delays)")]
        [SerializeField] private List<ObjectToEnable> m_ObjectsToEnable = new List<ObjectToEnable>();

        [Header("Animations to Play")]
        [Tooltip("Animations to play when attractor activates (with optional delays)")]
        [SerializeField] private List<AnimationToPlay> m_AnimationsToPlay = new List<AnimationToPlay>();

        void Start()
        {
            // Ensure the collider is set to trigger
            Collider col = GetComponent<Collider>();
            if (col != null && !col.isTrigger)
            {
                col.isTrigger = true;
                Debug.LogWarning($"Collider on {gameObject.name} was not set as trigger. Setting it automatically.");
            }
            
            // Warn if no attractor is assigned
            if (m_Attractor == null)
            {
                Debug.LogWarning($"No GaussianSplatAttractor assigned to {gameObject.name}");
            }
            else
            {
                // Disable the attractor at start - only activate when trigger is entered
                m_Attractor.enabled = false;
            }

            // Disable all objects in the list at start
            foreach (var obj in m_ObjectsToEnable)
            {
                if (obj.gameObject != null)
                {
                    obj.gameObject.SetActive(false);
                }
            }

            // Disable all animations at start - only play when triggered
            foreach (var anim in m_AnimationsToPlay)
            {
                if (anim.animator != null)
                {
                    anim.animator.enabled = false;
                }
            }
        }

        void OnTriggerEnter(Collider other)
        {
            // Activate attractor when any object enters
            ActivateAttractor();
        }

        void OnTriggerExit(Collider other)
        {
            // Optionally deactivate when object leaves
            if (m_DeactivateOnExit)
            {
                DeactivateAttractor();
            }
        }

        private void ActivateAttractor()
        {
            if (m_Attractor != null)
            {
                m_Attractor.enabled = true;
                Debug.Log($"Attractor '{m_Attractor.name}' activated by trigger '{gameObject.name}'");
            }

            // Enable all objects with their delays
            foreach (var obj in m_ObjectsToEnable)
            {
                if (obj.gameObject != null)
                {
                    StartCoroutine(EnableObjectWithDelay(obj));
                }
            }

            // Play all animations with their delays
            foreach (var anim in m_AnimationsToPlay)
            {
                if (anim.animator != null)
                {
                    StartCoroutine(PlayAnimationWithDelay(anim));
                }
            }
        }

        private IEnumerator EnableObjectWithDelay(ObjectToEnable obj)
        {
            if (obj.delay > 0)
            {
                yield return new WaitForSeconds(obj.delay);
            }

            obj.gameObject.SetActive(true);
            Debug.Log($"Object '{obj.gameObject.name}' enabled after {obj.delay} seconds");
        }

        private IEnumerator PlayAnimationWithDelay(AnimationToPlay anim)
        {
            if (anim.delay > 0)
            {
                yield return new WaitForSeconds(anim.delay);
            }

            if (anim.animator != null)
            {
                anim.animator.enabled = true;
                Debug.Log($"Animator on '{anim.animator.name}' enabled after {anim.delay} seconds");
            }
        }

        private void DeactivateAttractor()
        {
            if (m_Attractor != null)
            {
                m_Attractor.enabled = false;
                Debug.Log($"Attractor '{m_Attractor.name}' deactivated by trigger '{gameObject.name}'");
            }

            // Stop all ongoing enable coroutines
            StopAllCoroutines();

            // Disable all objects in the list
            foreach (var obj in m_ObjectsToEnable)
            {
                if (obj.gameObject != null)
                {
                    obj.gameObject.SetActive(false);
                }
            }

            // Stop all animations
            foreach (var anim in m_AnimationsToPlay)
            {
                if (anim.animator != null)
                {
                    anim.animator.enabled = false;
                }
            }
        }

        void OnDrawGizmos()
        {
            // Draw the trigger bounds in the editor
            Collider col = GetComponent<Collider>();
            if (col != null)
            {
                Gizmos.color = new Color(0, 1, 0, 0.3f);
                Gizmos.matrix = transform.localToWorldMatrix;
                
                if (col is BoxCollider box)
                {
                    Gizmos.DrawCube(box.center, box.size);
                }
                else if (col is SphereCollider sphere)
                {
                    Gizmos.DrawSphere(sphere.center, sphere.radius);
                }
                else if (col is CapsuleCollider capsule)
                {
                    Gizmos.DrawSphere(capsule.center, capsule.radius);
                }
                
                Gizmos.matrix = Matrix4x4.identity;
            }
        }
    }
}

