// SPDX-License-Identifier: MIT
// RENDERING PATH: Render Graph only (URP 17.3+ / Unity 6.3+). Compatibility Mode
// OnCameraSetup/Execute APIs were removed from ScriptableRenderPass — RecordRenderGraph
// is the only supported path. Keep URP "Compatibility Mode (Render Graph Disabled)" OFF:
// Project Settings > Graphics > Render Graph.
#if GS_ENABLE_URP

using UnityEngine;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.Rendering.RenderGraphModule;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace GaussianSplatting.Runtime
{
    // ReSharper disable once InconsistentNaming
    class GaussianSplatURPFeature : ScriptableRendererFeature
    {
        class GSRenderPass : ScriptableRenderPass
        {
            const string k_ProfilerTag = "GaussianSplatRender";
            static readonly int s_GaussianSplatRTId = Shader.PropertyToID("_GaussianSplatRT");
            static readonly int s_CameraDepthTextureId = Shader.PropertyToID("_CameraDepthTexture");
            static readonly int s_SplatRenderTargetSizeId = Shader.PropertyToID("_SplatRenderTargetSize");
            static readonly int s_SceneDepthTextureValidId = Shader.PropertyToID("_SceneDepthTextureValid");

            // URP 17.3+ removed OnCameraSetup/Execute. Only RecordRenderGraph runs.
            // Mirrors aras-p/UnityGaussianSplatting + Enndee/Splatviewer_VR_Android (Quest).
            class PassData
            {
                internal Camera camera;
                internal UniversalCameraData cameraData;
                internal TextureHandle source;
                internal TextureHandle splatRT;
                // Camera depth texture for scene-depth occlusion (SplatBoxRenderer.m_OccludeBySceneDepth).
                internal TextureHandle cameraDepth;
                internal bool hasCameraDepth;
                internal Vector4 splatRenderTargetSize;
            }

            public override void RecordRenderGraph(RenderGraph renderGraph, ContextContainer frameData)
            {
                var cameraData = frameData.Get<UniversalCameraData>();
                var resourceData = frameData.Get<UniversalResourceData>();

                RenderTextureDescriptor rtDesc = cameraData.cameraTargetDescriptor;
                rtDesc.depthBufferBits = 0;
                rtDesc.msaaSamples = 1;
                rtDesc.graphicsFormat = GraphicsFormat.R16G16B16A16_SFloat;
                // Optional resolution downscale for the splat pass (big perf win on Quest ~4K/eye).
                // The composite samples bilinearly so a low-res splat RT is smoothly upscaled.
                GaussianSplatRenderSystem.ApplySplatRenderScale(ref rtDesc);
                // Keep the descriptor dimension as-is: Tex2DArray for Single Pass Instanced,
                // Tex2D for Multi Pass / mono. Render Graph + Blitter then handle XR for us.
                TextureHandle splatRT = UniversalRenderer.CreateRenderGraphTexture(
                    renderGraph, rtDesc, "_GaussianSplatRT", true, FilterMode.Bilinear, TextureWrapMode.Clamp);

                using var builder = renderGraph.AddUnsafePass<PassData>(k_ProfilerTag, out PassData passData);

                passData.camera = cameraData.camera;
                passData.cameraData = cameraData;
                passData.source = resourceData.activeColorTexture;
                passData.splatRT = splatRT;
                passData.splatRenderTargetSize = new Vector4(
                    rtDesc.width, rtDesc.height,
                    1f / Mathf.Max(1, rtDesc.width), 1f / Mathf.Max(1, rtDesc.height));

                // The splat RT has no depth attachment (see below), so splats hide behind opaque geometry by
                // sampling URP's single-sample camera depth copy in the fragment shader. Never fall back to
                // cameraDepth/activeDepthTexture: those can be MSAA attachments, and sampling them as a
                // regular Texture2D produced distance-dependent clipping in Scene view.
                TextureHandle cameraDepth = resourceData.cameraDepthTexture;
                passData.hasCameraDepth = GaussianSplatRenderSystem.instance.SceneDepthOcclusionRequested &&
                                          cameraDepth.IsValid();
                passData.cameraDepth = cameraDepth;

                builder.UseTexture(resourceData.activeColorTexture, AccessFlags.ReadWrite);
                builder.UseTexture(splatRT, AccessFlags.Write);
                if (passData.hasCameraDepth)
                    builder.UseTexture(cameraDepth, AccessFlags.Read);
                builder.AllowPassCulling(false);
                builder.SetRenderFunc(static (PassData data, UnsafeGraphContext ctx) =>
                {
                    var cmd = CommandBufferHelpers.GetNativeCommandBuffer(ctx.cmd);
                    cmd.SetGlobalTexture(s_GaussianSplatRTId, data.splatRT);
                    cmd.SetGlobalVector(s_SplatRenderTargetSizeId, data.splatRenderTargetSize);
                    cmd.SetGlobalInt(s_SceneDepthTextureValidId, data.hasCameraDepth ? 1 : 0);
                    if (data.hasCameraDepth)
                        cmd.SetGlobalTexture(s_CameraDepthTextureId, data.cameraDepth);

                    // XR: per-eye view/proj live on UniversalCameraData, not on Camera (which stays mono).
                    // Using the mono Camera matrices makes splats skew and "swim" with head rotation.
                    // Call GetViewMatrix/GetProjectionMatrix at execute time so Multi-Pass gets the
                    // current eye.
                    var cam = data.camera;
                    var cd = data.cameraData;
                    bool xr = cd.xrRendering;
                    GaussianSplatRenderSystem.SetOverrideRenderTargetSize(
                        Mathf.RoundToInt(data.splatRenderTargetSize.x),
                        Mathf.RoundToInt(data.splatRenderTargetSize.y));

                    try
                    {
                        if (xr)
                        {
                            Matrix4x4 eyeView = cd.GetViewMatrix();
                            Matrix4x4 eyeProj = cd.GetProjectionMatrix();
                            GaussianSplatRenderSystem.SetOverrideMatrices(eyeView, eyeProj);
                            cmd.SetViewProjectionMatrices(eyeView, eyeProj);
                        }

                        GaussianSplatRenderSystem.MarkURPExecPath("RenderGraph");

                        // Color-only target (no depth). The camera depth on Quest is usually 4x MSAA
                        // while this splat RT is single-sample; binding them together makes the
                        // framebuffer sample-count mismatched and INVALID on Vulkan (clear + draw both
                        // drop). ForwardLit is ZTest Always + ZWrite Off, so no depth attachment is required.
                        CoreUtils.SetRenderTarget(cmd, data.splatRT, ClearFlag.Color, Color.clear);

                        Material matComposite = null;
                        try
                        {
                            matComposite = GaussianSplatRenderSystem.instance.SortAndRenderSplats(cam, cmd);
                            GaussianSplatRenderSystem.LastRenderError = "none";
                        }
                        catch (System.Exception e)
                        {
                            GaussianSplatRenderSystem.LastRenderError = e.GetType().Name + ": " + e.Message;
                        }

                        if (matComposite != null)
                        {
                            cmd.BeginSample(GaussianSplatRenderSystem.s_ProfCompose);
                            Blitter.BlitCameraTexture(cmd, data.splatRT, data.source, matComposite, 1); // Pass 1 = BlitToScreen
                            cmd.EndSample(GaussianSplatRenderSystem.s_ProfCompose);
                        }
                    }
                    finally
                    {
                        GaussianSplatRenderSystem.ClearOverrideRenderTargetSize();
                        if (xr)
                            GaussianSplatRenderSystem.ClearOverrideMatrices();
                    }
                });
            }
        }

        GSRenderPass m_Pass;
        bool m_HasCamera;
        bool m_LoggedNoValidSplats;

        public override void Create()
        {
            m_Pass = new GSRenderPass
            {
                renderPassEvent = RenderPassEvent.BeforeRenderingTransparents
            };
        }

        public override void OnCameraPreCull(ScriptableRenderer renderer, in CameraData cameraData)
        {
            m_HasCamera = false;
            var system = GaussianSplatRenderSystem.instance;
            if (!system.GatherSplatsForCamera(cameraData.camera))
            {
#if !UNITY_EDITOR
                if (!m_LoggedNoValidSplats)
                {
                    m_LoggedNoValidSplats = true;
                    Debug.LogWarning("[SplatBox] GaussianSplatURPFeature: no valid splats for camera (check SplatBoxRenderer asset + Resources shaders).");
                }
#endif
                return;
            }
            m_LoggedNoValidSplats = false;

            // Ensure the shared command buffer exists / is cleared for any non-RG consumers.
            system.InitialClearCmdBuffer(cameraData.camera);
            m_HasCamera = true;
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (!m_HasCamera)
                return;
            // Ask URP for the camera depth texture only when a gathered splat wants scene-depth occlusion;
            // on Quest the depth copy is not free, so renderers that don't need it keep the cheaper path.
            m_Pass.ConfigureInput(GaussianSplatRenderSystem.instance.SceneDepthOcclusionRequested
                ? ScriptableRenderPassInput.Depth
                : ScriptableRenderPassInput.None);
            renderer.EnqueuePass(m_Pass);
        }

        protected override void Dispose(bool disposing)
        {
            m_Pass = null;
        }

#if UNITY_EDITOR
        [MenuItem("SplatBox/Setup URP Renderer Features")]
        static void MenuAddFeatures()
        {
            bool added = EnsureFeatureOnAllRenderers();
            if (!added)
                Debug.Log("[SplatBox] Gaussian Splat URP Feature is already present on all URP renderers.");
        }

        // The splat pass only renders on Quest/Android via the Render Graph path. If URP is in
        // "Compatibility Mode (Render Graph Disabled)" the on-device HUD shows "Path: Compatibility"
        // and splats stay invisible. This flips the global setting so RecordRenderGraph runs.
        // Done via reflection so the package still compiles on URP versions without this API.
        [MenuItem("SplatBox/Use Render Graph (disable Compatibility Mode)")]
        static void DisableUrpCompatibilityMode()
        {
            const string manual = "Disable it manually: Project Settings > Graphics > Render Graph > uncheck \"Compatibility Mode (Render Graph Disabled)\".";

            // Find the RenderGraphSettings type without hard-coding its assembly (varies by Unity 6.x).
            System.Type rgType = FindTypeByName("RenderGraphSettings");
            if (rgType == null)
            {
                Debug.LogWarning("[SplatBox] RenderGraphSettings type not found in any loaded assembly (needs Unity 6+). " + manual);
                return;
            }

            System.Reflection.MethodInfo getSettings = null;
            foreach (var m in typeof(GraphicsSettings).GetMethods())
            {
                if (m.Name == "GetRenderPipelineSettings" && m.IsGenericMethodDefinition && m.GetParameters().Length == 0)
                {
                    getSettings = m.MakeGenericMethod(rgType);
                    break;
                }
            }
            if (getSettings == null)
            {
                Debug.LogWarning("[SplatBox] GraphicsSettings.GetRenderPipelineSettings<>() not found. " + manual);
                return;
            }

            object settings;
            try { settings = getSettings.Invoke(null, null); }
            catch (System.Exception e) { Debug.LogWarning($"[SplatBox] Could not read RenderGraphSettings ({e.Message}). " + manual); return; }

            if (settings == null)
            {
                Debug.LogWarning("[SplatBox] RenderGraphSettings instance is null. Open Project Settings > Graphics once, then retry. " + manual);
                return;
            }

            // The flag may be exposed as a property or a serialized field.
            const string memberName = "enableRenderCompatibilityMode";
            var prop = rgType.GetProperty(memberName, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var field = rgType.GetField(memberName, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            bool current;
            if (prop != null && prop.CanRead) current = (bool)prop.GetValue(settings);
            else if (field != null) current = (bool)field.GetValue(settings);
            else { Debug.LogWarning("[SplatBox] '" + memberName + "' not found on RenderGraphSettings. " + manual); return; }

            if (!current)
            {
                Debug.Log("[SplatBox] Compatibility Mode is already OFF — Render Graph is active. Just rebuild the APK.");
                return;
            }

            try
            {
                if (prop != null && prop.CanWrite) prop.SetValue(settings, false);
                else if (field != null) field.SetValue(settings, false);
                else { Debug.LogWarning("[SplatBox] '" + memberName + "' is read-only via reflection. " + manual); return; }
            }
            catch (System.Exception e) { Debug.LogWarning($"[SplatBox] Failed to set {memberName} ({e.Message}). " + manual); return; }

            var gfx = GraphicsSettings.GetGraphicsSettings();
            if (gfx != null)
                EditorUtility.SetDirty(gfx);
            AssetDatabase.SaveAssets();
            Debug.Log("[SplatBox] Disabled URP Compatibility Mode — Render Graph is now active. Rebuild the APK; the HUD should read \"Path: RenderGraph\".");
        }

        static System.Type FindTypeByName(string typeName)
        {
            foreach (var asm in System.AppDomain.CurrentDomain.GetAssemblies())
            {
                System.Type[] types;
                try { types = asm.GetTypes(); }
                catch (System.Reflection.ReflectionTypeLoadException e) { types = e.Types; }
                catch { continue; }

                if (types == null)
                    continue;
                foreach (var t in types)
                {
                    if (t != null && t.Name == typeName)
                        return t;
                }
            }
            return null;
        }

        [InitializeOnLoadMethod]
        static void AutoInstall()
        {
            EditorApplication.delayCall += () => EnsureFeatureOnAllRenderers();
        }

        static bool EnsureFeatureOnAllRenderers()
        {
            // Walk EVERY URP asset in the project (not just the currently-active one) so the feature
            // is attached to Mobile / PC / XR quality tiers. This avoids "splats render on Standalone
            // but disappear when playing on Android" because the Android quality tier uses a different
            // RendererData that was missing the feature.
            bool anyAdded = false;
            var pipelineGuids = AssetDatabase.FindAssets("t:UniversalRenderPipelineAsset");
            var visited = new System.Collections.Generic.HashSet<ScriptableRendererData>();

            foreach (var pg in pipelineGuids)
            {
                var path = AssetDatabase.GUIDToAssetPath(pg);
                var pipeline = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(path);
                if (pipeline == null)
                    continue;

                var pipelineSO = new SerializedObject(pipeline);
                var rendererDataList = pipelineSO.FindProperty("m_RendererDataList");
                if (rendererDataList == null || !rendererDataList.isArray)
                    continue;

                for (int i = 0; i < rendererDataList.arraySize; i++)
                {
                    var rendererData = rendererDataList.GetArrayElementAtIndex(i).objectReferenceValue as ScriptableRendererData;
                    if (rendererData == null || !visited.Add(rendererData))
                        continue;

                    if (AddFeatureIfMissing(rendererData))
                        anyAdded = true;
                }
            }

            return anyAdded;
        }

        static bool AddFeatureIfMissing(ScriptableRendererData rendererData)
        {
            foreach (var f in rendererData.rendererFeatures)
            {
                if (f != null && f.GetType() == typeof(GaussianSplatURPFeature))
                    return false;
            }

            var feature = CreateInstance<GaussianSplatURPFeature>();
            feature.name = "Gaussian Splat URP Feature";
            AssetDatabase.AddObjectToAsset(feature, rendererData);

            var rendererSO = new SerializedObject(rendererData);
            var featuresProp = rendererSO.FindProperty("m_RendererFeatures");
            featuresProp.arraySize++;
            featuresProp.GetArrayElementAtIndex(featuresProp.arraySize - 1).objectReferenceValue = feature;

            var guids = rendererSO.FindProperty("m_RendererFeatureMap");
            if (guids != null && guids.isArray)
            {
                guids.arraySize = featuresProp.arraySize;
                long guid = (long)EntityId.ToULong(feature.GetEntityId());
                guids.GetArrayElementAtIndex(guids.arraySize - 1).longValue = guid;
            }

            rendererSO.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(rendererData);
            AssetDatabase.SaveAssetIfDirty(rendererData);

            Debug.Log($"[SplatBox] Auto-added Gaussian Splat URP Feature to renderer '{rendererData.name}'.");
            return true;
        }
#endif
    }
}

#endif // #if GS_ENABLE_URP
