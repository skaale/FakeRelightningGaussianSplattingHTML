// SPDX-License-Identifier: MIT
// Lightweight XR version without XR Interaction Toolkit dependency

using UnityEngine;
using UnityEngine.XR;

namespace GaussianSplatting.Runtime
{
    [RequireComponent(typeof(GaussianPolyMask))]
    public class GaussianPolyMaskXRSimple : MonoBehaviour
    {
        [Header("XR Settings")]
        public XRNode m_ControllerNode = XRNode.LeftHand;
        
        [Header("Drawing Settings")]
        public float m_RayMaxDistance = 10f;
        public LayerMask m_DrawSurfaceLayer = ~0;
        public float m_MinVertexDistance = 0.1f;
        public float m_CloseDistanceThreshold = 0.3f;
        public float m_ShapeGenerationSize = 1.0f;
        
        [Header("Visual")]
        public LineRenderer m_RayLine;
        public Color m_DrawRayColor = Color.cyan;
        public Color m_DeleteRayColor = Color.red;
        
        private GaussianPolyMask m_PolyMask;
        private bool m_TriggerPressed = false;
        private bool m_GrabPressed = false;
        private Vector3 m_LastHitPoint;
        private bool m_HasValidHit;
        private InputDevice m_Controller;
        private float m_LastTriggerTime = 0f;

        private void Awake()
        {
            m_PolyMask = GetComponent<GaussianPolyMask>();
            
            if (m_RayLine == null)
            {
                GameObject rayObj = new GameObject("XR_Ray");
                rayObj.transform.SetParent(transform);
                m_RayLine = rayObj.AddComponent<LineRenderer>();
                m_RayLine.startWidth = 0.01f;
                m_RayLine.endWidth = 0.01f;
                m_RayLine.positionCount = 2;
                m_RayLine.material = new Material(Shader.Find("Sprites/Default"));
            }
        }

        private void Update()
        {
            if (!m_Controller.isValid)
            {
                m_Controller = InputDevices.GetDeviceAtXRNode(m_ControllerNode);
                if (!m_Controller.isValid)
                    return;
            }

            if (!m_Controller.TryGetFeatureValue(CommonUsages.devicePosition, out Vector3 position))
                return;
            if (!m_Controller.TryGetFeatureValue(CommonUsages.deviceRotation, out Quaternion rotation))
                return;

            Ray ray = new Ray(position, rotation * Vector3.forward);
            m_HasValidHit = Physics.Raycast(ray, out RaycastHit hit, m_RayMaxDistance, m_DrawSurfaceLayer);
            
            if (m_HasValidHit)
            {
                m_LastHitPoint = hit.point;
                UpdateRayVisual(position, hit.point, false);
            }
            else
            {
                m_LastHitPoint = ray.GetPoint(m_RayMaxDistance);
                UpdateRayVisual(position, m_LastHitPoint, true);
            }

            HandleInput();
        }

        private void HandleInput()
        {
            m_Controller.TryGetFeatureValue(CommonUsages.triggerButton, out bool trigger);
            m_Controller.TryGetFeatureValue(CommonUsages.gripButton, out bool grip);
            
            if (trigger && !m_TriggerPressed && m_HasValidHit)
            {
                OnTriggerPressed();
            }
            
            if (grip && !m_GrabPressed && m_PolyMask.IsClosed)
            {
                OnGrabPressed();
            }
            
            m_TriggerPressed = trigger;
            m_GrabPressed = grip;
        }

        private void OnTriggerPressed()
        {
            float currentTime = Time.time;
            bool isDoubleTrigger = (currentTime - m_LastTriggerTime) < 0.4f;
            m_LastTriggerTime = currentTime;
            
            if (!m_PolyMask.m_IsDrawing)
            {
                m_Controller.TryGetFeatureValue(CommonUsages.deviceRotation, out Quaternion rotation);
                Vector3 planeNormal = rotation * Vector3.forward;
                
                // Generate predefined shape or start custom drawing
                if (m_PolyMask.m_ShapeType != GaussianPolyMask.ShapeType.Custom)
                {
                    m_PolyMask.GenerateShape(m_LastHitPoint, planeNormal, m_ShapeGenerationSize);
                }
                else
                {
                    m_PolyMask.StartDrawing(m_LastHitPoint, Vector3.up);
                }
                return;
            }

            // Double-trigger closes polygon
            if (isDoubleTrigger && m_PolyMask.m_Vertices.Count >= 3)
            {
                m_PolyMask.ClosePath();
                return;
            }

            if (m_PolyMask.m_Vertices.Count > 0)
            {
                Vector3 lastPoint = m_PolyMask.transform.TransformPoint(
                    m_PolyMask.m_Vertices[m_PolyMask.m_Vertices.Count - 1]);
                if (Vector3.Distance(m_LastHitPoint, lastPoint) < m_MinVertexDistance)
                    return;
            }

            // Use 3D placement in world space
            m_PolyMask.AddVertex3D(m_LastHitPoint);
        }

        private void OnGrabPressed()
        {
            SplatBoxRenderer[] renderers = FindObjectsByType<SplatBoxRenderer>();
            foreach (var renderer in renderers)
            {
                if (renderer.m_Cutouts == null)
                {
                    renderer.m_Cutouts = new GaussianCutout[] { m_PolyMask };
                }
                else
                {
                    bool hasIt = false;
                    foreach (var cutout in renderer.m_Cutouts)
                    {
                        if (cutout == m_PolyMask)
                        {
                            hasIt = true;
                            break;
                        }
                    }
                    
                    if (!hasIt)
                    {
                        GaussianCutout[] newCutouts = new GaussianCutout[renderer.m_Cutouts.Length + 1];
                        for (int i = 0; i < renderer.m_Cutouts.Length; i++)
                        {
                            newCutouts[i] = renderer.m_Cutouts[i];
                        }
                        newCutouts[renderer.m_Cutouts.Length] = m_PolyMask;
                        renderer.m_Cutouts = newCutouts;
                    }
                }
            }

            // Don't clear - the polygon needs to stay active for the cutout to work
        }

        private void UpdateRayVisual(Vector3 start, Vector3 end, bool invalid)
        {
            if (m_RayLine == null)
                return;

            m_RayLine.SetPosition(0, start);
            m_RayLine.SetPosition(1, end);
            
            Color rayColor = m_PolyMask.IsClosed ? m_DeleteRayColor : m_DrawRayColor;
            if (invalid)
                rayColor.a = 0.3f;
            
            m_RayLine.startColor = rayColor;
            m_RayLine.endColor = rayColor;
        }

        private void OnDisable()
        {
            if (m_RayLine != null)
                m_RayLine.enabled = false;
        }

        private void OnEnable()
        {
            if (m_RayLine != null)
                m_RayLine.enabled = true;
        }
    }
}

