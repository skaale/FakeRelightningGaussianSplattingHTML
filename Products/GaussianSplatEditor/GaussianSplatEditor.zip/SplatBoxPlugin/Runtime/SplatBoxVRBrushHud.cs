// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEngine;

namespace GaussianSplatting.Runtime
{
    /// <summary>
    /// Matches <see cref="GaussianSplatting.Editor.GaussianSplatEditorWindow.BrushTool"/>.
    /// Restore is bound to hold grip on the VR brush controller (not a toolbar button).
    /// </summary>
    public enum SplatBoxVRBrushTool
    {
        EraseBrush = 1,
        RestoreBrush = 100,
        BoxBrush = 2,
        CloneBrush = 3,
        FloorFill = 4,
        PatchTool = 5,
        PolyMask = 6,
        ColorBrush = 7,
        VortexTool = 8,
        FillBrush = 9,
        PaintBrush = 10,
        CylinderBrush = 11,
        TextureStamp = 12,
        SculptBrush = 13,
        ColorizeBrush = 14
    }

    /// <summary>
    /// Radial VR tool HUD mirroring the desktop splat editor: categories, tools, then per-tool property wedges.
    /// Right hand: ray at menu on the brush hand, trigger/A select, stick-click back, thumbstick Y adjusts properties.
    /// </summary>
    [DisallowMultipleComponent]
    public class SplatBoxVRBrushHud : MonoBehaviour
    {
        public struct ToolDef
        {
            public SplatBoxVRBrushTool tool;
            public string icon;
            public string label;
            public Color color;
            public bool vrReady;
        }

        struct CategoryDef
        {
            public string id;
            public string label;
            public string icon;
            public Color accent;
            public ToolDef[] tools;
        }

        struct SegmentVisualRefs
        {
            public MeshRenderer iconDisc;
            public TextMesh icon;
            public TextMesh label;
            public TextMesh value;
            public GameObject submenuBadge;
        }

        enum SegmentKind
        {
            Category,
            Tool,
            Property,
            Back
        }

        enum MenuLevel
        {
            Main,
            CategoryTools,
            ToolProperties
        }

        struct SegmentBinding
        {
            public SegmentKind kind;
            public string categoryId;
            public SplatBoxVRBrushTool tool;
            public ToolDef def;
            public CategoryDef category;
            public SplatBoxVRBrushToolSettings.PropertyDef property;
            public MeshRenderer fillRenderer;
            public MeshRenderer outlineRenderer;
            public MeshRenderer glowRenderer;
            public MeshCollider collider;
            public MeshRenderer iconDisc;
            public TextMesh icon;
            public TextMesh label;
            public TextMesh value;
            public GameObject submenuBadge;
        }

        const float kReferenceDiameterMeters = 0.1f;
        const float kLayoutOuterRadius = 68f;
        const float kLayoutInnerRadius = 24f;
        const float kOutlineThickness = 3f;
        const float kGlowThickness = 5f;

        [Header("Radial Layout")]
        [Tooltip("World-space menu diameter in meters. 0.18 = 18 cm hand menu.")]
        [Range(0.08f, 0.35f)]
        public float m_MenuDiameterMeters = 0.18f;
        [Tooltip("Scales icon/label text independently from the ring size.")]
        [Range(0.2f, 1f)]
        public float m_TextSizeMultiplier = 0.38f;
        [Tooltip("Offset from the right brush hand in hand-local space (X = right, Y = up, Z = forward).")]
        public Vector3 m_HandLocalOffset = new Vector3(0f, -0.04f, 0.03f);
        [Tooltip("Thumbstick Y adjusts the hovered property when a tool settings ring is open.")]
        public float m_PropertyAdjustSpeed = 1.8f;
        [Range(0.05f, 0.5f)] public float m_StickDeadZone = 0.2f;
        public Vector3 m_PanelRotationEuler = Vector3.zero;
        public Vector2 m_ShadowOffset = new Vector2(3f, -4f);
        [Range(0f, 1f)] public float m_ShadowAlpha = 0.45f;
        public float m_RayMaxDistance = 1.1f;
        public bool m_StartVisible = false;

        [Header("Colors")]
        public Color m_RingOutlineColor = new Color(0.2f, 0.85f, 0.82f, 0.95f);
        public Color m_SegmentIdleColor = new Color(0.1f, 0.12f, 0.16f, 0.82f);
        public Color m_SegmentHoverColor = new Color(0.15f, 0.55f, 0.52f, 0.95f);
        public Color m_SegmentActiveColor = new Color(0.2f, 0.75f, 0.72f, 1f);
        public Color m_GlowHoverColor = new Color(0.35f, 1f, 0.95f, 0.55f);
        public Color m_CategoryAccent = new Color(0.25f, 0.9f, 0.85f, 1f);

        public event Action<SplatBoxVRBrushTool> ToolSelected;

        public SplatBoxVRBrushTool ActiveTool { get; private set; } = SplatBoxVRBrushTool.EraseBrush;

        static readonly ToolDef[] s_AllTools =
        {
            new() { tool = SplatBoxVRBrushTool.EraseBrush, icon = "🔴", label = "Erase", color = new Color(1f, 0.35f, 0.35f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.PaintBrush, icon = "✏️", label = "Paint", color = new Color(0.4f, 0.65f, 1f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.ColorizeBrush, icon = "🖌️", label = "Colorize", color = new Color(0.85f, 0.45f, 1f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.CloneBrush, icon = "🔄", label = "Clone", color = new Color(1f, 0.75f, 0.3f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.BoxBrush, icon = "📦", label = "Box", color = new Color(0.45f, 0.85f, 1f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.CylinderBrush, icon = "🔷", label = "Cylinder", color = new Color(0.6f, 0.8f, 1f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.FillBrush, icon = "🖌", label = "Fill", color = new Color(0.55f, 0.9f, 0.85f), vrReady = false },
            new() { tool = SplatBoxVRBrushTool.FloorFill, icon = "▬", label = "Floor", color = new Color(0.7f, 0.55f, 0.35f), vrReady = false },
            new() { tool = SplatBoxVRBrushTool.ColorBrush, icon = "🎨", label = "Color", color = new Color(1f, 0.55f, 0.2f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.VortexTool, icon = "🌀", label = "Vortex", color = new Color(0.55f, 0.4f, 1f), vrReady = true },
            new() { tool = SplatBoxVRBrushTool.PatchTool, icon = "🔧", label = "Patch", color = new Color(1f, 0.55f, 0.7f), vrReady = false },
            new() { tool = SplatBoxVRBrushTool.PolyMask, icon = "✂️", label = "Mask", color = new Color(0.75f, 0.75f, 0.35f), vrReady = false },
            new() { tool = SplatBoxVRBrushTool.TextureStamp, icon = "🖼️", label = "Stamp", color = new Color(0.85f, 0.7f, 0.45f), vrReady = false },
            new() { tool = SplatBoxVRBrushTool.SculptBrush, icon = "🖐️", label = "Sculpt", color = new Color(0.65f, 0.5f, 0.35f), vrReady = false },
        };

        static readonly CategoryDef[] s_Categories =
        {
            new()
            {
                id = "brush",
                label = "Brush",
                icon = "🖌",
                accent = new Color(1f, 0.4f, 0.38f),
                tools = new[]
                {
                    ToolOf(SplatBoxVRBrushTool.EraseBrush),
                    ToolOf(SplatBoxVRBrushTool.PaintBrush),
                    ToolOf(SplatBoxVRBrushTool.ColorizeBrush),
                    ToolOf(SplatBoxVRBrushTool.CloneBrush),
                }
            },
            new()
            {
                id = "shape",
                label = "Shape",
                icon = "📐",
                accent = new Color(0.4f, 0.75f, 1f),
                tools = new[]
                {
                    ToolOf(SplatBoxVRBrushTool.BoxBrush),
                    ToolOf(SplatBoxVRBrushTool.CylinderBrush),
                    ToolOf(SplatBoxVRBrushTool.FillBrush),
                    ToolOf(SplatBoxVRBrushTool.FloorFill),
                }
            },
            new()
            {
                id = "fx",
                label = "FX",
                icon = "✨",
                accent = new Color(0.75f, 0.45f, 1f),
                tools = new[]
                {
                    ToolOf(SplatBoxVRBrushTool.ColorBrush),
                    ToolOf(SplatBoxVRBrushTool.VortexTool),
                    ToolOf(SplatBoxVRBrushTool.PatchTool),
                    ToolOf(SplatBoxVRBrushTool.PolyMask),
                    ToolOf(SplatBoxVRBrushTool.TextureStamp),
                    ToolOf(SplatBoxVRBrushTool.SculptBrush),
                }
            },
        };

        Transform m_HudRoot;
        Transform m_VisualRoot;
        Transform m_RadialRoot;
        Transform m_ShadowRoot;
        TextMesh m_TitleText;
        readonly List<SegmentBinding> m_Segments = new List<SegmentBinding>();
        readonly List<Material> m_OwnedMaterials = new List<Material>();

        Material m_FillMat;
        Material m_OutlineMat;
        Material m_GlowMat;
        Material m_ShadowMat;
        Material m_RingMat;

        int m_HoveredSegment = -1;
        string m_OpenCategoryId;
        SplatBoxVRBrushTool m_PropertyTool;
        MenuLevel m_MenuLevel = MenuLevel.Main;
        SplatBoxVREraseBrush m_BrushHost;
        Camera m_WorldCamera;
        bool m_Built;
        bool m_HudVisible;

        public bool IsVisible => m_HudVisible;

        static Font s_UiFont;

        static ToolDef ToolOf(SplatBoxVRBrushTool tool)
        {
            for (int i = 0; i < s_AllTools.Length; i++)
            {
                if (s_AllTools[i].tool == tool)
                    return s_AllTools[i];
            }
            return new ToolDef { tool = tool, icon = "?", label = tool.ToString(), color = Color.white, vrReady = false };
        }

        static Font GetUiFont()
        {
            if (s_UiFont != null)
                return s_UiFont;
            s_UiFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf")
                ?? Resources.GetBuiltinResource<Font>("Arial.ttf")
                ?? Font.CreateDynamicFontFromOSFont("Arial", 16);
            return s_UiFont;
        }

        public bool IsVrReady(SplatBoxVRBrushTool tool)
        {
            for (int i = 0; i < s_AllTools.Length; i++)
            {
                if (s_AllTools[i].tool == tool)
                    return s_AllTools[i].vrReady;
            }
            return false;
        }

        public string GetToolLabel(SplatBoxVRBrushTool tool)
        {
            for (int i = 0; i < s_AllTools.Length; i++)
            {
                if (s_AllTools[i].tool == tool)
                    return s_AllTools[i].label;
            }
            return tool.ToString();
        }

        public Color GetToolColor(SplatBoxVRBrushTool tool)
        {
            for (int i = 0; i < s_AllTools.Length; i++)
            {
                if (s_AllTools[i].tool == tool)
                    return s_AllTools[i].color;
            }
            return Color.white;
        }

        public void EnsureBuilt(Camera worldCamera)
        {
            m_WorldCamera = worldCamera;
            ResolveHudRoot();
            ApplyLegacySizeMigration();
            if (m_Built && m_HudRoot != null && m_VisualRoot != null && m_RadialRoot != null)
                return;

            m_Built = false;
            BuildUi();
            m_Built = true;
            ShowMainMenu();
            SetActiveTool(ActiveTool, false);
            SetVisible(m_StartVisible);
        }

        public void SetVisible(bool visible)
        {
            m_HudVisible = visible;
            if (m_HudRoot != null && !m_HudRoot.gameObject.activeSelf)
                m_HudRoot.gameObject.SetActive(true);
            if (m_VisualRoot != null)
                m_VisualRoot.gameObject.SetActive(visible);
            if (visible)
                ShowMainMenu();
        }

        public void ToggleVisible() => SetVisible(!m_HudVisible);

        public void BindHost(SplatBoxVREraseBrush host) => m_BrushHost = host;

        public bool IsInPropertyMenu => m_MenuLevel == MenuLevel.ToolProperties;
        public bool IsPointerOverMenu => m_HudVisible && m_HoveredSegment >= 0;

        public void SetFollowRightHand(Vector3 anchorWorldPos, Quaternion handRotation, Vector3 cameraForward)
        {
            if (m_HudRoot == null || !m_HudVisible)
                return;

            Vector3 handUp = handRotation * Vector3.up;
            m_HudRoot.position = anchorWorldPos + handRotation * m_HandLocalOffset;
            m_HudRoot.rotation = Quaternion.LookRotation(cameraForward, handUp) * Quaternion.Euler(m_PanelRotationEuler);
            ApplyMenuWorldScale();
            UpdateBillboards();
        }

        void UpdateBillboards()
        {
            if (m_WorldCamera == null || m_HudRoot == null)
                return;

            Vector3 camPos = m_WorldCamera.transform.position;
            Vector3 up = m_WorldCamera.transform.up;
            if (m_TitleText != null)
                BillboardTransform(m_TitleText.transform, camPos, up);

            for (int i = 0; i < m_Segments.Count; i++)
            {
                var seg = m_Segments[i];
                if (seg.iconDisc != null)
                    BillboardTransform(seg.iconDisc.transform, camPos, up);
                if (seg.icon != null)
                    BillboardTransform(seg.icon.transform, camPos, up);
                if (seg.label != null)
                    BillboardTransform(seg.label.transform, camPos, up);
                if (seg.value != null)
                    BillboardTransform(seg.value.transform, camPos, up);
                if (seg.submenuBadge != null)
                    BillboardTransform(seg.submenuBadge.transform, camPos, up);
            }
        }

        static void BillboardTransform(Transform t, Vector3 camPos, Vector3 up)
        {
            if (t == null)
                return;
            Vector3 toCam = camPos - t.position;
            if (toCam.sqrMagnitude < 1e-8f)
                toCam = Vector3.forward;
            t.rotation = Quaternion.LookRotation(toCam.normalized, up);
        }

        public bool TryGoBack(bool backPressed, bool backWasPressed)
        {
            if (!m_HudVisible || !backPressed || backWasPressed)
                return false;
            NavigateBack();
            return true;
        }

        public bool TryAdjustHoveredProperty(Vector2 stick, float deltaTime)
        {
            if (!m_HudVisible || m_MenuLevel != MenuLevel.ToolProperties || m_BrushHost == null)
                return false;
            if (Mathf.Abs(stick.y) <= m_StickDeadZone)
                return false;
            if (m_HoveredSegment < 0 || m_HoveredSegment >= m_Segments.Count)
                return false;

            var seg = m_Segments[m_HoveredSegment];
            if (seg.kind != SegmentKind.Property || seg.property == null)
                return false;

            seg.property.Adjust(m_BrushHost, stick.y * m_PropertyAdjustSpeed * deltaTime);
            UpdatePropertyLabel(seg);
            return true;
        }

        public void RefreshPropertyValueLabels()
        {
            if (m_MenuLevel != MenuLevel.ToolProperties || m_BrushHost == null)
                return;
            for (int i = 0; i < m_Segments.Count; i++)
            {
                if (m_Segments[i].kind == SegmentKind.Property)
                    UpdatePropertyLabel(m_Segments[i]);
            }
        }

        public string GetStatusMessage()
        {
            if (m_MenuLevel == MenuLevel.ToolProperties)
                return $"{GetToolLabel(m_PropertyTool)} settings";
            return $"Tool: {GetToolLabel(ActiveTool)}";
        }

        float RefOuterRadiusMeters() => kReferenceDiameterMeters * 0.5f;

        float LayoutUnitsToMeters(float layoutUnits) => layoutUnits / kLayoutOuterRadius * RefOuterRadiusMeters();

        float GetVisualRootScale() => m_MenuDiameterMeters / kReferenceDiameterMeters;

        float TextCharSize(float layoutUnits) => LayoutUnitsToMeters(layoutUnits) * m_TextSizeMultiplier;

        void ApplyMenuWorldScale()
        {
            if (m_VisualRoot == null)
                return;
            m_VisualRoot.localScale = Vector3.one * GetVisualRootScale();
        }

        public bool IsRayOverHud(Ray ray)
        {
            if (!m_HudVisible)
                return false;
            return TryRaycastHud(ray, out _);
        }

        public bool TrySelectWithPrimaryButton(Ray ray, bool primaryPressed, bool primaryWasPressed)
        {
            if (!m_HudVisible || !primaryPressed || primaryWasPressed)
                return false;
            if (!TryRaycastHud(ray, out int segmentIndex))
                return false;

            ActivateSegment(segmentIndex);
            return true;
        }

        public void UpdateHover(Ray ray)
        {
            if (!m_HudVisible)
                return;

            int hovered = -1;
            if (TryRaycastHud(ray, out int index))
                hovered = index;

            if (m_HoveredSegment == hovered)
                return;

            m_HoveredSegment = hovered;
            RefreshAllSegmentVisuals();
            UpdateBillboards();
        }

        void ActivateSegment(int index)
        {
            if (index < 0 || index >= m_Segments.Count)
                return;

            var seg = m_Segments[index];
            switch (seg.kind)
            {
                case SegmentKind.Category:
                    ShowSubMenu(seg.categoryId);
                    break;
                case SegmentKind.Back:
                    NavigateBack();
                    break;
                case SegmentKind.Tool:
                    SetActiveTool(seg.tool, true);
                    if (SplatBoxVRBrushToolSettings.HasProperties(seg.tool))
                        ShowToolProperties(seg.tool);
                    break;
                case SegmentKind.Property:
                    if (seg.property != null && m_BrushHost != null &&
                        seg.property.kind == SplatBoxVRBrushToolSettings.PropertyKind.Bool)
                    {
                        bool next = !seg.property.getBool(m_BrushHost);
                        seg.property.setBool(m_BrushHost, next);
                    }
                    UpdatePropertyLabel(seg);
                    break;
            }
        }

        void NavigateBack()
        {
            switch (m_MenuLevel)
            {
                case MenuLevel.ToolProperties:
                    if (!string.IsNullOrEmpty(m_OpenCategoryId))
                        ShowSubMenu(m_OpenCategoryId);
                    else
                        ShowMainMenu();
                    break;
                case MenuLevel.CategoryTools:
                    ShowMainMenu();
                    break;
                default:
                    ShowMainMenu();
                    break;
            }
        }

        void SetActiveTool(SplatBoxVRBrushTool tool, bool notify)
        {
            ActiveTool = tool;
            RefreshAllSegmentVisuals();
            if (notify)
                ToolSelected?.Invoke(tool);
        }

        void ShowMainMenu()
        {
            m_MenuLevel = MenuLevel.Main;
            m_OpenCategoryId = null;
            m_PropertyTool = default;
            RebuildRadialMenu();
            if (m_TitleText != null)
                m_TitleText.text = "Splat Tools";
        }

        void ShowSubMenu(string categoryId)
        {
            m_MenuLevel = MenuLevel.CategoryTools;
            m_OpenCategoryId = categoryId;
            m_PropertyTool = default;
            RebuildRadialMenu();
            if (m_TitleText != null)
            {
                for (int i = 0; i < s_Categories.Length; i++)
                {
                    if (s_Categories[i].id == categoryId)
                    {
                        m_TitleText.text = s_Categories[i].label;
                        break;
                    }
                }
            }
        }

        void ShowToolProperties(SplatBoxVRBrushTool tool)
        {
            m_MenuLevel = MenuLevel.ToolProperties;
            m_PropertyTool = tool;
            if (string.IsNullOrEmpty(m_OpenCategoryId))
                m_OpenCategoryId = FindCategoryIdForTool(tool);
            RebuildRadialMenu();
            if (m_TitleText != null)
                m_TitleText.text = GetToolLabel(tool);
        }

        static string FindCategoryIdForTool(SplatBoxVRBrushTool tool)
        {
            for (int i = 0; i < s_Categories.Length; i++)
            {
                var tools = s_Categories[i].tools;
                for (int t = 0; t < tools.Length; t++)
                {
                    if (tools[t].tool == tool)
                        return s_Categories[i].id;
                }
            }
            return null;
        }

        void RefreshAllSegmentVisuals()
        {
            for (int i = 0; i < m_Segments.Count; i++)
                ApplySegmentVisual(m_Segments[i], i == m_HoveredSegment);
        }

        void ApplySegmentVisual(SegmentBinding seg, bool hovered)
        {
            bool active = seg.kind == SegmentKind.Tool && seg.tool == ActiveTool;
            Color fill = m_SegmentIdleColor;
            Color outline = m_RingOutlineColor;
            Color glow = new Color(m_GlowHoverColor.r, m_GlowHoverColor.g, m_GlowHoverColor.b, 0f);

            if (seg.kind == SegmentKind.Category)
            {
                if (hovered) fill = Color.Lerp(m_SegmentIdleColor, seg.category.accent, 0.55f);
                else fill = Color.Lerp(m_SegmentIdleColor, seg.category.accent, 0.2f);
            }
            else if (seg.kind == SegmentKind.Back)
            {
                fill = hovered ? m_SegmentHoverColor : new Color(0.08f, 0.1f, 0.12f, 0.9f);
            }
            else if (seg.kind == SegmentKind.Property)
            {
                var toolColor = GetToolColor(m_PropertyTool);
                if (hovered) fill = Color.Lerp(toolColor, m_SegmentHoverColor, 0.55f);
                else fill = Color.Lerp(m_SegmentIdleColor, toolColor, 0.28f);
            }
            else
            {
                if (active) fill = Color.Lerp(seg.def.color, m_SegmentActiveColor, 0.45f);
                else if (hovered) fill = Color.Lerp(seg.def.color, m_SegmentHoverColor, 0.5f);
                else fill = Color.Lerp(m_SegmentIdleColor, seg.def.color, 0.22f);
            }

            if (hovered)
            {
                outline = Color.Lerp(m_RingOutlineColor, Color.white, 0.45f);
                glow = m_GlowHoverColor;
            }
            else if (active)
            {
                outline = Color.white;
                glow = new Color(m_GlowHoverColor.r, m_GlowHoverColor.g, m_GlowHoverColor.b, 0.25f);
            }

            SetRendererColor(seg.fillRenderer, fill);
            SetRendererColor(seg.outlineRenderer, outline);
            SetRendererColor(seg.glowRenderer, glow);

            if (seg.label != null)
                seg.label.color = hovered || active ? Color.white : new Color(0.85f, 0.9f, 0.95f);
            if (seg.value != null)
                seg.value.color = hovered ? m_RingOutlineColor : new Color(0.65f, 0.75f, 0.85f);
            if (seg.icon != null)
                seg.icon.color = hovered || active ? Color.white : new Color(0.92f, 0.95f, 1f);
            if (seg.iconDisc != null)
            {
                Color disc = seg.kind == SegmentKind.Category ? seg.category.accent
                    : seg.kind == SegmentKind.Tool ? seg.def.color
                    : seg.kind == SegmentKind.Property ? GetToolColor(m_PropertyTool)
                    : m_SegmentIdleColor;
                if (hovered) disc = Color.Lerp(disc, Color.white, 0.35f);
                SetRendererColor(seg.iconDisc, new Color(disc.r, disc.g, disc.b, 0.92f));
            }
            if (seg.submenuBadge != null)
                seg.submenuBadge.SetActive(seg.kind == SegmentKind.Category ||
                    (seg.kind == SegmentKind.Tool && SplatBoxVRBrushToolSettings.HasProperties(seg.tool)));
        }

        static void SetRendererColor(MeshRenderer renderer, Color color)
        {
            if (renderer == null)
                return;
            SplatBoxVRBrushHudRadialMesh.ApplyHudColor(renderer.material, color);
        }

        bool TryRaycastHud(Ray ray, out int segmentIndex)
        {
            segmentIndex = -1;
            if (m_VisualRoot == null)
                return false;

            var hits = Physics.RaycastAll(ray, m_RayMaxDistance, ~0, QueryTriggerInteraction.Collide);
            float bestDist = float.MaxValue;
            for (int h = 0; h < hits.Length; h++)
            {
                for (int i = 0; i < m_Segments.Count; i++)
                {
                    if (m_Segments[i].collider == null || hits[h].collider != m_Segments[i].collider)
                        continue;
                    if (hits[h].distance < bestDist)
                    {
                        bestDist = hits[h].distance;
                        segmentIndex = i;
                    }
                }
            }

            return segmentIndex >= 0;
        }

        void BuildUi()
        {
            ResolveHudRoot();
            EnsureMaterials();

            if (m_VisualRoot != null && m_RadialRoot != null)
            {
                ApplyMenuWorldScale();
                RefreshAllSegmentVisuals();
                return;
            }

            if (m_VisualRoot != null)
                Destroy(m_VisualRoot.gameObject);

            m_Segments.Clear();

            m_VisualRoot = new GameObject("VisualRoot").transform;
            m_VisualRoot.SetParent(m_HudRoot, false);
            m_VisualRoot.localPosition = Vector3.zero;
            m_VisualRoot.localRotation = Quaternion.identity;
            ApplyMenuWorldScale();

            m_ShadowRoot = new GameObject("RadialShadow").transform;
            m_ShadowRoot.SetParent(m_VisualRoot, false);
            m_ShadowRoot.localPosition = new Vector3(
                LayoutUnitsToMeters(m_ShadowOffset.x),
                LayoutUnitsToMeters(m_ShadowOffset.y),
                0f);

            m_RadialRoot = new GameObject("RadialMenu").transform;
            m_RadialRoot.SetParent(m_VisualRoot, false);
            m_RadialRoot.localPosition = Vector3.zero;

            CreateCenterTitle(m_RadialRoot);
            CreateOuterRing(m_RadialRoot);
            ShowMainMenu();
        }

        void CreateCenterTitle(Transform parent)
        {
            m_TitleText = CreateSegmentTextMesh(parent, "Title", "Splat Tools", TextCharSize(5f), Vector3.zero, FontStyle.Bold);
            m_TitleText.color = m_RingOutlineColor;
        }

        void CreateOuterRing(Transform parent)
        {
            float outer = RefOuterRadiusMeters();
            float ringWidth = LayoutUnitsToMeters(2f);
            CreateWedgeObject(parent, "OuterRing",
                SplatBoxVRBrushHudRadialMesh.CreateRing(outer, outer + ringWidth, 64),
                m_RingMat, 2);
        }

        void RebuildRadialMenu()
        {
            ClearSegmentObjects();
            m_HoveredSegment = -1;

            if (m_MenuLevel == MenuLevel.ToolProperties)
                BuildPropertyMenu(m_PropertyTool);
            else if (string.IsNullOrEmpty(m_OpenCategoryId))
                BuildCategoryMenu();
            else
                BuildToolSubMenu(m_OpenCategoryId);

            RefreshAllSegmentVisuals();
        }

        void BuildPropertyMenu(SplatBoxVRBrushTool tool)
        {
            var props = SplatBoxVRBrushToolSettings.GetProperties(tool);
            int count = props.Count + 1;
            float step = 360f / Mathf.Max(1, count);
            float start = 90f;
            CreateBackSegment(start, start - step);
            for (int i = 0; i < props.Count; i++)
            {
                float segStart = start - (i + 1) * step;
                float segEnd = segStart - step;
                CreatePropertySegment(props[i], segStart, segEnd);
            }
        }

        void BuildCategoryMenu()
        {
            int count = s_Categories.Length;
            float step = 360f / count;
            float start = 90f;
            for (int i = 0; i < s_Categories.Length; i++)
            {
                float segStart = start - i * step;
                float segEnd = segStart - step;
                CreateCategorySegment(s_Categories[i], segStart, segEnd);
            }
        }

        void BuildToolSubMenu(string categoryId)
        {
            CategoryDef cat = default;
            bool found = false;
            for (int i = 0; i < s_Categories.Length; i++)
            {
                if (s_Categories[i].id == categoryId)
                {
                    cat = s_Categories[i];
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                ShowMainMenu();
                return;
            }

            int count = cat.tools.Length + 1;
            float step = 360f / count;
            float start = 90f;
            CreateBackSegment(start, start - step);
            for (int i = 0; i < cat.tools.Length; i++)
            {
                float segStart = start - (i + 1) * step;
                float segEnd = segStart - step;
                CreateToolSegment(cat.tools[i], segStart, segEnd);
            }
        }

        struct WedgeSlotLayout
        {
            public Vector3 iconDiscPos;
            public Vector3 iconPos;
            public Vector3 labelPos;
            public Vector3 valuePos;
            public Vector3 badgePos;
        }

        WedgeSlotLayout GetWedgeSlotLayout(float startDeg, float endDeg, bool includeValueSlot)
        {
            float midDeg = (startDeg + endDeg) * 0.5f;
            float midRad = midDeg * Mathf.Deg2Rad;
            Vector3 outward = new Vector3(Mathf.Cos(midRad), Mathf.Sin(midRad), 0f);
            Vector3 tangent = new Vector3(-outward.y, outward.x, 0f);
            float depth = -LayoutUnitsToMeters(3.5f);
            return new WedgeSlotLayout
            {
                iconDiscPos = outward * LayoutUnitsToMeters(56f) + Vector3.forward * (depth - LayoutUnitsToMeters(0.4f)),
                iconPos = outward * LayoutUnitsToMeters(56f) + Vector3.forward * depth,
                labelPos = outward * LayoutUnitsToMeters(44f) + Vector3.forward * (depth + LayoutUnitsToMeters(0.2f)),
                valuePos = outward * LayoutUnitsToMeters(34f) + Vector3.forward * (depth + LayoutUnitsToMeters(0.35f)),
                badgePos = outward * LayoutUnitsToMeters(58f) + tangent * LayoutUnitsToMeters(7f) + Vector3.forward * depth
            };
        }

        SegmentVisualRefs CreateSegmentVisuals(Transform root, WedgeSlotLayout layout, string iconGlyph, string labelText,
            Color iconColor, string valueText = null, bool showBadge = false)
        {
            var iconDisc = CreateIconDisc(root, layout.iconDiscPos, iconColor, LayoutUnitsToMeters(9f));
            var icon = CreateSegmentTextMesh(root, "Icon", iconGlyph, TextCharSize(5.5f), layout.iconPos, FontStyle.Bold);
            var label = CreateSegmentTextMesh(root, "Label", labelText, TextCharSize(2.7f), layout.labelPos, FontStyle.Normal);
            TextMesh value = null;
            if (!string.IsNullOrEmpty(valueText))
                value = CreateSegmentTextMesh(root, "Value", valueText, TextCharSize(2.2f), layout.valuePos, FontStyle.Normal);
            GameObject badge = showBadge ? CreateSubmenuBadge(root, layout.badgePos) : null;
            return new SegmentVisualRefs { iconDisc = iconDisc, icon = icon, label = label, value = value, submenuBadge = badge };
        }

        MeshRenderer CreateIconDisc(Transform parent, Vector3 localPos, Color color, float radiusMeters)
        {
            var mat = SplatBoxVRBrushHudRadialMesh.CreateHudMaterial("VRRadial_IconDisc", color);
            m_OwnedMaterials.Add(mat);
            var mr = CreateWedgeObject(parent, "IconDisc",
                SplatBoxVRBrushHudRadialMesh.CreateDisc(radiusMeters, 24),
                mat, -1);
            mr.transform.localPosition = localPos;
            return mr;
        }

        void CreateCategorySegment(CategoryDef cat, float startDeg, float endDeg)
        {
            var segGo = CreateSegmentWedgeSet(m_RadialRoot, $"{cat.label}_Category", startDeg, endDeg, true);
            var layout = GetWedgeSlotLayout(startDeg, endDeg, false);
            var visuals = CreateSegmentVisuals(segGo.root, layout, cat.icon, cat.label, cat.accent, showBadge: true);

            m_Segments.Add(new SegmentBinding
            {
                kind = SegmentKind.Category,
                categoryId = cat.id,
                category = cat,
                fillRenderer = segGo.fill,
                outlineRenderer = segGo.outline,
                glowRenderer = segGo.glow,
                collider = segGo.collider,
                iconDisc = visuals.iconDisc,
                icon = visuals.icon,
                label = visuals.label,
                submenuBadge = visuals.submenuBadge
            });
        }

        void CreateToolSegment(ToolDef def, float startDeg, float endDeg)
        {
            var segGo = CreateSegmentWedgeSet(m_RadialRoot, $"{def.label}_Tool", startDeg, endDeg, true);
            var layout = GetWedgeSlotLayout(startDeg, endDeg, false);
            var visuals = CreateSegmentVisuals(segGo.root, layout, def.icon, def.label, def.color,
                showBadge: SplatBoxVRBrushToolSettings.HasProperties(def.tool));

            m_Segments.Add(new SegmentBinding
            {
                kind = SegmentKind.Tool,
                tool = def.tool,
                def = def,
                fillRenderer = segGo.fill,
                outlineRenderer = segGo.outline,
                glowRenderer = segGo.glow,
                collider = segGo.collider,
                iconDisc = visuals.iconDisc,
                icon = visuals.icon,
                label = visuals.label,
                submenuBadge = visuals.submenuBadge
            });
        }

        void CreatePropertySegment(SplatBoxVRBrushToolSettings.PropertyDef prop, float startDeg, float endDeg)
        {
            var segGo = CreateSegmentWedgeSet(m_RadialRoot, $"{prop.label}_Property", startDeg, endDeg, true);
            var layout = GetWedgeSlotLayout(startDeg, endDeg, true);
            string value = prop.Format(m_BrushHost);
            var visuals = CreateSegmentVisuals(segGo.root, layout, prop.shortLabel, prop.label,
                GetToolColor(m_PropertyTool), value);

            m_Segments.Add(new SegmentBinding
            {
                kind = SegmentKind.Property,
                property = prop,
                fillRenderer = segGo.fill,
                outlineRenderer = segGo.outline,
                glowRenderer = segGo.glow,
                collider = segGo.collider,
                iconDisc = visuals.iconDisc,
                icon = visuals.icon,
                label = visuals.label,
                value = visuals.value
            });
        }

        void UpdatePropertyLabel(SegmentBinding seg)
        {
            if (seg.value == null || seg.property == null || m_BrushHost == null)
                return;
            seg.value.text = seg.property.Format(m_BrushHost);
        }

        void CreateBackSegment(float startDeg, float endDeg)
        {
            var segGo = CreateSegmentWedgeSet(m_RadialRoot, "Back", startDeg, endDeg, true);
            var layout = GetWedgeSlotLayout(startDeg, endDeg, false);
            var visuals = CreateSegmentVisuals(segGo.root, layout, "←", "Back", m_SegmentHoverColor);

            m_Segments.Add(new SegmentBinding
            {
                kind = SegmentKind.Back,
                fillRenderer = segGo.fill,
                outlineRenderer = segGo.outline,
                glowRenderer = segGo.glow,
                collider = segGo.collider,
                iconDisc = visuals.iconDisc,
                icon = visuals.icon,
                label = visuals.label
            });
        }

        struct WedgeSet
        {
            public Transform root;
            public MeshRenderer fill;
            public MeshRenderer outline;
            public MeshRenderer glow;
            public MeshCollider collider;
        }

        WedgeSet CreateSegmentWedgeSet(Transform parent, string name, float startDeg, float endDeg, bool withShadow)
        {
            var root = new GameObject(name).transform;
            root.SetParent(parent, false);
            root.localPosition = Vector3.zero;

            float inner = LayoutUnitsToMeters(kLayoutInnerRadius);
            float outer = RefOuterRadiusMeters();
            float outline = LayoutUnitsToMeters(kOutlineThickness);
            float glow = LayoutUnitsToMeters(kGlowThickness);

            if (withShadow)
            {
                CreateWedgeObject(m_ShadowRoot, name + "_Shadow",
                    SplatBoxVRBrushHudRadialMesh.CreateWedge(inner, outer, startDeg, endDeg),
                    m_ShadowMat, 0);
            }

            var glowRenderer = CreateWedgeObject(root, "Glow",
                SplatBoxVRBrushHudRadialMesh.CreateWedge(inner - glow, outer + glow, startDeg, endDeg),
                m_GlowMat, 0);

            var outlineRenderer = CreateWedgeObject(root, "Outline",
                SplatBoxVRBrushHudRadialMesh.CreateWedge(inner - outline, outer + outline, startDeg, endDeg),
                m_OutlineMat, 1);

            var fill = CreateWedgeObject(root, "Fill",
                SplatBoxVRBrushHudRadialMesh.CreateWedge(inner, outer, startDeg, endDeg),
                m_FillMat, 2);

            var collider = fill.gameObject.AddComponent<MeshCollider>();
            collider.sharedMesh = fill.GetComponent<MeshFilter>().sharedMesh;
            collider.convex = false;

            return new WedgeSet { root = root, fill = fill, outline = outlineRenderer, glow = glowRenderer, collider = collider };
        }

        MeshRenderer CreateWedgeObject(Transform parent, string name, Mesh mesh, Material mat, int zOrder)
        {
            var go = new GameObject(name, typeof(MeshFilter), typeof(MeshRenderer));
            go.transform.SetParent(parent, false);
            float z = zOrder < 0 ? LayoutUnitsToMeters(0.8f) : -LayoutUnitsToMeters(0.5f) * zOrder;
            go.transform.localPosition = new Vector3(0f, 0f, z);
            var mf = go.GetComponent<MeshFilter>();
            mf.sharedMesh = mesh;
            var mr = go.GetComponent<MeshRenderer>();
            var instance = new Material(mat);
            m_OwnedMaterials.Add(instance);
            mr.material = instance;
            mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            mr.receiveShadows = false;
            return mr;
        }

        TextMesh CreateSegmentTextMesh(Transform parent, string name, string content, float charSize, Vector3 localPos, FontStyle style)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            var text = go.AddComponent<TextMesh>();
            text.text = content;
            text.font = GetUiFont();
            text.characterSize = charSize;
            text.fontSize = 64;
            text.fontStyle = style;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.color = Color.white;
            ConfigureTextMeshRenderer(text);
            return text;
        }

        void ConfigureTextMeshRenderer(TextMesh text)
        {
            var renderer = text.GetComponent<MeshRenderer>();
            if (renderer == null)
                return;
            var mat = new Material(renderer.sharedMaterial) { name = "VRRadialHud_Text" };
            mat.SetInt("_ZWrite", 0);
            mat.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Always);
            renderer.material = mat;
            m_OwnedMaterials.Add(mat);
        }

        GameObject CreateSubmenuBadge(Transform parent, Vector3 localPos)
        {
            var go = new GameObject("SubmenuBadge");
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            var text = go.AddComponent<TextMesh>();
            text.text = "▶";
            text.font = GetUiFont();
            text.characterSize = TextCharSize(3f);
            text.fontSize = 64;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.color = Color.white;
            ConfigureTextMeshRenderer(text);
            var renderer = text.GetComponent<MeshRenderer>();
            if (renderer != null)
                SplatBoxVRBrushHudRadialMesh.ApplyHudColor(renderer.material, m_CategoryAccent);
            return go;
        }

        void ClearSegmentObjects()
        {
            m_Segments.Clear();
            if (m_RadialRoot != null)
            {
                for (int i = m_RadialRoot.childCount - 1; i >= 0; i--)
                {
                    var child = m_RadialRoot.GetChild(i);
                    if (child.name == "Title" || child.name == "OuterRing")
                        continue;
                    Destroy(child.gameObject);
                }
            }
            if (m_ShadowRoot != null)
            {
                for (int i = m_ShadowRoot.childCount - 1; i >= 0; i--)
                    Destroy(m_ShadowRoot.GetChild(i).gameObject);
            }
        }

        void EnsureMaterials()
        {
            if (m_FillMat != null)
                return;

            m_FillMat = SplatBoxVRBrushHudRadialMesh.CreateHudMaterial("VRRadial_Fill", m_SegmentIdleColor);
            m_OutlineMat = SplatBoxVRBrushHudRadialMesh.CreateHudMaterial("VRRadial_Outline", m_RingOutlineColor);
            m_GlowMat = SplatBoxVRBrushHudRadialMesh.CreateHudMaterial("VRRadial_Glow", m_GlowHoverColor, additive: true);
            m_ShadowMat = SplatBoxVRBrushHudRadialMesh.CreateHudMaterial("VRRadial_Shadow", new Color(0f, 0f, 0f, m_ShadowAlpha));
            m_RingMat = SplatBoxVRBrushHudRadialMesh.CreateHudMaterial("VRRadial_Ring", m_RingOutlineColor);

            m_OwnedMaterials.Add(m_FillMat);
            m_OwnedMaterials.Add(m_OutlineMat);
            m_OwnedMaterials.Add(m_GlowMat);
            m_OwnedMaterials.Add(m_ShadowMat);
            m_OwnedMaterials.Add(m_RingMat);
        }

        void ApplyLegacySizeMigration()
        {
            if (m_MenuDiameterMeters <= 0f)
                m_MenuDiameterMeters = 0.18f;

            if (m_HudRoot == null)
                return;

            // Rebuild canvas-based HUDs or menus whose mesh radius is still in layout units (~68m).
            bool hasLegacyCanvas = m_HudRoot.GetComponentInChildren<Canvas>(true) != null;
            bool hasOversizedMesh = false;
            if (m_RadialRoot != null)
            {
                var ring = m_RadialRoot.Find("OuterRing");
                if (ring != null)
                {
                    var mf = ring.GetComponent<MeshFilter>();
                    if (mf != null && mf.sharedMesh != null)
                        hasOversizedMesh = mf.sharedMesh.bounds.extents.magnitude > 0.25f;
                }
            }

            if (!hasLegacyCanvas && !hasOversizedMesh)
            {
                ApplyMenuWorldScale();
                return;
            }

            ForceHudRebuild();
        }

        void ForceHudRebuild()
        {
            if (m_HudRoot != null)
                Destroy(m_HudRoot.gameObject);
            m_HudRoot = null;
            m_VisualRoot = null;
            m_RadialRoot = null;
            m_ShadowRoot = null;
            m_TitleText = null;
            m_Segments.Clear();
            ResetHudMaterials();
            m_Built = false;
        }

        void ResetHudMaterials()
        {
            for (int i = 0; i < m_OwnedMaterials.Count; i++)
            {
                if (m_OwnedMaterials[i] != null)
                    Destroy(m_OwnedMaterials[i]);
            }

            m_OwnedMaterials.Clear();
            m_FillMat = null;
            m_OutlineMat = null;
            m_GlowMat = null;
            m_ShadowMat = null;
            m_RingMat = null;
        }

        void OnValidate()
        {
            m_MenuDiameterMeters = Mathf.Clamp(m_MenuDiameterMeters, 0.08f, 0.35f);
            m_TextSizeMultiplier = Mathf.Clamp(m_TextSizeMultiplier, 0.2f, 1f);
            ApplyMenuWorldScale();
        }

        void ResolveHudRoot()
        {
            if (m_HudRoot != null)
                return;

            var existing = transform.Find("VRErase_ToolHud");
            if (existing != null)
            {
                m_HudRoot = existing;
                m_VisualRoot = m_HudRoot.Find("VisualRoot");
                if (m_VisualRoot != null)
                {
                    m_RadialRoot = m_VisualRoot.Find("RadialMenu");
                    m_ShadowRoot = m_VisualRoot.Find("RadialShadow");
                    var title = m_RadialRoot != null ? m_RadialRoot.Find("Title") : null;
                    if (title != null)
                        m_TitleText = title.GetComponent<TextMesh>();
                }
                return;
            }

            var root = new GameObject("VRErase_ToolHud");
            m_HudRoot = root.transform;
            m_HudRoot.SetParent(transform, false);
        }

        void OnDestroy()
        {
            if (m_HudRoot != null)
                Destroy(m_HudRoot.gameObject);
            ResetHudMaterials();
        }
    }
}
