// SPDX-License-Identifier: MIT
using System;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        const int MaxPagedCloneSplats = 300_000;
        string m_PagedCloneStatus;

        void ExecuteCloneInEditor(Camera camera)
        {
            if (m_CloneBrush == null || !m_CloneBrush.CanClone) return;
            var source = m_CloneBrush.TargetRenderer;
            if (!source.UsesPagedLod) { m_CloneBrush.PerformClone(); return; }
            m_PagedCloneStatus = null;
            if (camera == null) { m_PagedCloneStatus = "Open a Scene view to clone paged splats."; return; }
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            { m_PagedCloneStatus = "Paged Clone is available in Edit mode. Stop Play mode and try again."; return; }
            if (EditorUtility.IsPersistent(source) || !source.gameObject.scene.IsValid() || PrefabStageUtility.GetCurrentPrefabStage() != null)
            { m_PagedCloneStatus = "Paged Clone requires a scene object outside Prefab Mode."; return; }
            if (source.activeSplatCount <= 0)
            { m_PagedCloneStatus = "The paged scene is still loading. Wait for its splats to appear, then try again."; return; }
            if (m_CloneBrush.SourceVertices.Count > 128)
            { m_PagedCloneStatus = "Use at most 128 vertices for a paged Clone polygon."; return; }

            Matrix4x4 actual = source.transform.localToWorldMatrix;
            Matrix4x4 trs = Matrix4x4.TRS(source.transform.position, source.transform.rotation, source.transform.lossyScale);
            for (int i = 0; i < 16; i++)
                if (Mathf.Abs(actual[i] - trs[i]) > 0.001f)
                { m_PagedCloneStatus = "The source has a sheared transform. Remove non-uniformly scaled parents before cloning."; return; }

            var polygon = new Vector2[m_CloneBrush.SourceVertices.Count];
            for (int i = 0; i < polygon.Length; i++)
            {
                var point = camera.WorldToViewportPoint(m_CloneBrush.SourceVertices[i]);
                if (point.z <= camera.nearClipPlane)
                { m_PagedCloneStatus = "The source polygon must be in front of the Scene camera."; return; }
                polygon[i] = new Vector2(point.x, point.y);
            }
            Vector3 sourceScreen = camera.WorldToScreenPoint(m_CloneBrush.SourceCenter);
            Vector3 targetScreen = camera.WorldToScreenPoint(m_CloneBrush.TargetPosition);
            if (sourceScreen.z <= 0 || targetScreen.z <= 0)
            { m_PagedCloneStatus = "The source and target must be in front of the Scene camera."; return; }

            string folder = null;
            GameObject root = null;
            try
            {
                int stride = UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>();
                using var gpuData = new GraphicsBuffer(GraphicsBuffer.Target.Structured, Mathf.Min(MaxPagedCloneSplats, source.activeSplatCount), stride);
                if (!source.ExportPagedClone(polygon, camera, m_CloneBrush.SelectionDepth, gpuData, out int count))
                { m_PagedCloneStatus = "Could not read the displayed paged splats. Check the Console and try again."; return; }
                if (count == 0)
                { m_PagedCloneStatus = "No visible splats were found in the polygon. Check the source area and Selection Depth."; return; }
                if (count > MaxPagedCloneSplats)
                { m_PagedCloneStatus = $"The polygon contains {count:N0} splats; select a smaller area (maximum {MaxPagedCloneSplats:N0})."; return; }

                var splats = new GaussianSplatAssetCreator.InputSplatData[count];
                gpuData.GetData(splats, 0, 0, count);
                Vector2 screenOffset = new Vector2(targetScreen.x - sourceScreen.x, targetScreen.y - sourceScreen.y);
                Matrix4x4 worldToSource = actual.inverse;
                for (int i = 0; i < splats.Length; i++)
                {
                    Vector3 world = actual.MultiplyPoint3x4(splats[i].pos);
                    Vector3 screen = camera.WorldToScreenPoint(world);
                    screen.x += screenOffset.x; screen.y += screenOffset.y;
                    Vector3 destination = camera.ScreenToWorldPoint(screen) + camera.transform.forward * m_CloneBrush.DepthOffset;
                    splats[i].pos = worldToSource.MultiplyPoint3x4(destination);
                }

                const string parent = "Assets/SplatBoxClones";
                if (!AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder("Assets", "SplatBoxClones");
                string uniqueName = "Clone_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder(parent, uniqueName);
                folder = parent + "/" + uniqueName;
                using var input = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(splats, Allocator.TempJob);
                string path = GaussianSplatAssetCreator.CreateAssetFromSplats(input, folder, uniqueName, GaussianSplatAssetCreator.DataQuality.VeryHigh);
                var asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
                if (asset == null) throw new InvalidOperationException("Could not create the clone asset.");

                root = new GameObject(source.name + " Clone"); root.SetActive(false);
                SceneManager.MoveGameObjectToScene(root, source.gameObject.scene);
                var child = new GameObject("Cloned splats"); child.transform.SetParent(root.transform, false);
                child.transform.position = source.transform.position;
                child.transform.rotation = source.transform.rotation;
                child.transform.localScale = source.transform.lossyScale;
                var renderer = child.AddComponent<SplatBoxRenderer>();
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(source), renderer);
                using (var serialized = new SerializedObject(renderer))
                {
                    serialized.FindProperty("m_Asset").objectReferenceValue = asset;
                    serialized.FindProperty("m_PagedScene").objectReferenceValue = null;
                    serialized.FindProperty("m_LodStreamer").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedEraseScene").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedEraseStrokes").ClearArray();
                    serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedXcopySource").objectReferenceValue = source;
                    serialized.FindProperty("m_PagedXcopyRoot").objectReferenceValue = root;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                renderer.m_RenderOrder = source.m_RenderOrder < int.MaxValue ? source.m_RenderOrder + 1 : int.MaxValue;
                Undo.RegisterCreatedObjectUndo(root, "Clone paged splats");
                root.SetActive(true);
                EditorSceneManager.MarkSceneDirty(root.scene);
                m_PagedCloneStatus = $"Cloned {count:N0} displayed splats. Save the scene to keep the clone.";
                m_CloneBrush.ClearAll();
                SceneView.RepaintAll();
            }
            catch (Exception exception)
            {
                if (root != null) Object.DestroyImmediate(root);
                if (!string.IsNullOrEmpty(folder)) AssetDatabase.DeleteAsset(folder);
                m_PagedCloneStatus = "Clone failed: " + exception.Message;
                Debug.LogException(exception);
            }
            finally { EditorUtility.ClearProgressBar(); Repaint(); }
        }
    }
}
