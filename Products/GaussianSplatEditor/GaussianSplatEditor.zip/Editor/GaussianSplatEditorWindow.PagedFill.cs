// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using FillSplat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        const int MaxPagedFillSplats = 300_000;
        const int MaxPagedFillSamples = 65_536;
        const long MaxPagedFillGridCandidates = 1_000_000;
        string m_PagedFillStatus;

        void ExecuteFillInEditor(Camera camera, bool deleteOnly = false)
        {
            m_PagedFillStatus = null;
            var brush = m_FillBrush;
            var source = brush != null ? brush.TargetRenderer : null;
            if (brush == null || source == null || !brush.HasValidPolygon) return;
            if (!source.UsesPagedLod)
            {
                if (deleteOnly) brush.DeletePolygonArea(); else brush.ExecuteFill();
                return;
            }
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            { m_PagedFillStatus = "Paged Fill is available in Edit mode. Stop Play mode and try again."; return; }
            if (EditorUtility.IsPersistent(source) || !source.gameObject.scene.IsValid() || PrefabStageUtility.GetCurrentPrefabStage() != null)
            { m_PagedFillStatus = "Paged Fill requires a scene object outside Prefab Mode."; return; }
            var polygon = brush.GetTransformedVertices().ToArray();
            if (polygon.Length > 128)
            { m_PagedFillStatus = "Use at most 128 vertices for a paged Fill polygon."; return; }
            Vector3 normal = brush.GetTransformedNormal();
            Matrix4x4 actual = source.transform.localToWorldMatrix;
            Matrix4x4 trs = Matrix4x4.TRS(source.transform.position, source.transform.rotation, source.transform.lossyScale);
            for (int i = 0; i < 16; ++i)
                if (!FillFinite(actual[i]) || Mathf.Abs(actual[i] - trs[i]) > 0.001f)
                { m_PagedFillStatus = "The source has a sheared or invalid transform. Remove non-uniformly scaled parents before filling."; return; }
            if (Mathf.Abs(actual.determinant) < 1e-12f)
            { m_PagedFillStatus = "The source transform has a zero scale."; return; }

            string folder = null;
            GameObject root = null;
            int undoGroup = -1;
            bool committed = false;
            try
            {
                if (deleteOnly)
                {
                    Undo.IncrementCurrentGroup(); undoGroup = Undo.GetCurrentGroup();
                    Undo.SetCurrentGroupName("Delete Paged Fill Area");
                    Undo.RegisterCompleteObjectUndo(source, "Delete Paged Fill Area");
                    if (!source.DeletePagedSplatsInPolygon(polygon, normal, brush.SelectionDepth))
                        throw new InvalidOperationException("The polygon could not be deleted. Check the polygon outline and that the paged scene is ready.");
                    Undo.FlushUndoRecordObjects(); Undo.CollapseUndoOperations(undoGroup);
                    committed = true;
                    m_PagedFillStatus = "Deleted the polygon area. Save the scene to retain the edit.";
                    EditorSceneManager.MarkSceneDirty(source.gameObject.scene);
                    return;
                }

                var samples = Array.Empty<FillSplat>();
                if (source.activeSplatCount > 0 && source.HasValidRenderSetup)
                {
                    using var gpu = new GraphicsBuffer(GraphicsBuffer.Target.Structured,
                        Mathf.Min(MaxPagedFillSamples, source.activeSplatCount), UnsafeUtility.SizeOf<FillSplat>());
                    if (!source.ExportPagedPolygonSamples(polygon, normal, brush.SelectionDepth, brush.EdgeSampleWidth, gpu, out int count))
                        throw new InvalidOperationException("Could not sample the polygon edges. Check the polygon outline and that the paged scene is ready.");
                    if (count > MaxPagedFillSamples)
                        throw new InvalidOperationException("Too many edge samples. Reduce Edge Sample Width or select a smaller polygon.");
                    samples = new FillSplat[count];
                    if (count > 0) gpu.GetData(samples, 0, 0, count);
                }
                bool solidFallback = samples.Length == 0;
                var splats = BuildPagedFillSplats(samples, polygon, normal, actual, brush);

                const string parent = "Assets/SplatBoxFills";
                if (!AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder("Assets", "SplatBoxFills");
                string uniqueName = "Fill_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder(parent, uniqueName); folder = parent + "/" + uniqueName;
                using var input = new NativeArray<FillSplat>(splats, Allocator.TempJob);
                string path = GaussianSplatAssetCreator.CreateAssetFromSplats(input, folder, uniqueName, GaussianSplatAssetCreator.DataQuality.VeryHigh);
                var asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
                if (asset == null) throw new InvalidOperationException("Could not create the fill asset.");

                root = new GameObject(source.name + " Fill"); root.SetActive(false);
                SceneManager.MoveGameObjectToScene(root, source.gameObject.scene);
                var child = new GameObject("Filled splats"); child.transform.SetParent(root.transform, false);
                child.transform.SetPositionAndRotation(source.transform.position, source.transform.rotation);
                child.transform.localScale = source.transform.lossyScale;
                var renderer = child.AddComponent<SplatBoxRenderer>();
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(source), renderer);
                using (var serialized = new SerializedObject(renderer))
                {
                    serialized.FindProperty("m_Asset").objectReferenceValue = asset;
                    ClearPagedEditHistoryForGeneratedOutput(serialized);
                    serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedXcopySource").objectReferenceValue = source;
                    serialized.FindProperty("m_PagedXcopyRoot").objectReferenceValue = root;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                renderer.m_RenderOrder = source.m_RenderOrder < int.MaxValue ? source.m_RenderOrder + 1 : int.MaxValue;
                root.SetActive(true);
                if (!renderer.HasValidRenderSetup || renderer.activeSplatCount != splats.Length)
                    throw new InvalidOperationException("The fill renderer did not initialize. The source has not been deleted.");

                // Only commit a destructive replacement once its complete output is ready.
                Undo.IncrementCurrentGroup(); undoGroup = Undo.GetCurrentGroup();
                Undo.SetCurrentGroupName("Fill Paged Polygon");
                Undo.RegisterCreatedObjectUndo(root, "Fill Paged Polygon");
                if (brush.DeleteBeforeFill)
                {
                    Undo.RegisterCompleteObjectUndo(source, "Replace Paged Polygon");
                    if (!source.DeletePagedSplatsInPolygon(polygon, normal, brush.SelectionDepth))
                        throw new InvalidOperationException("Could not delete the original polygon area.");
                }
                Undo.FlushUndoRecordObjects(); Undo.CollapseUndoOperations(undoGroup);
                EditorSceneManager.MarkSceneDirty(root.scene);
                committed = true;
                m_PagedFillStatus = $"Filled {splats.Length:N0} splats. " +
                    (solidFallback ? "No edge samples: used solid color with 5 cm base spacing. " : "") +
                    "Save the scene to keep the fill.";
            }
            catch (Exception exception)
            {
                if (undoGroup >= 0 && !committed)
                {
                    Undo.FlushUndoRecordObjects();
                    Undo.RevertAllDownToGroup(undoGroup);
                }
                if (root != null && !committed) Object.DestroyImmediate(root);
                if (!string.IsNullOrEmpty(folder) && !committed) AssetDatabase.DeleteAsset(folder);
                m_PagedFillStatus = "Fill failed: " + exception.Message;
                // Expected validation failures belong in the tool panel, without a misleading success log.
                if (!(exception is InvalidOperationException)) Debug.LogException(exception);
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                EditorApplication.QueuePlayerLoopUpdate(); SceneView.RepaintAll(); Repaint();
            }
        }

        static bool FillFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        static bool FillFinite(Vector3 value) => FillFinite(value.x) && FillFinite(value.y) && FillFinite(value.z);

        static FillSplat[] BuildPagedFillSplats(FillSplat[] samples, Vector3[] polygon, Vector3 normal,
            Matrix4x4 sourceToWorld, GaussianSplatFillBrush brush)
        {
            if (!SplatBoxRenderer.TryBuildPagedPolygonFrame(polygon, normal, out var worldToPlane, out var outline))
                throw new InvalidOperationException("Draw a valid polygon with at least three vertices.");
            // Use the same plane as the persistent deletion, including its centroid. Surface
            // picks may be slightly nonplanar; both operations use the same projected outline.
            Matrix4x4 planeToWorld = worldToPlane.inverse;
            Vector3 origin = planeToWorld.MultiplyPoint3x4(Vector3.zero);
            Vector3 tangent = planeToWorld.MultiplyVector(Vector3.right).normalized;
            Vector3 bitangent = planeToWorld.MultiplyVector(Vector3.up).normalized;
            normal = planeToWorld.MultiplyVector(Vector3.forward).normalized;
            Vector2 min = Vector2.one * float.MaxValue, max = Vector2.one * float.MinValue;
            foreach (var vertex in outline) { min = Vector2.Min(min, vertex); max = Vector2.Max(max, vertex); }

            bool fallback = samples == null || samples.Length == 0;
            if (fallback && (!brush.UseFillColor || brush.FillColorBlend < 0.999f))
                throw new InvalidOperationException("No visible edge splats were found. Increase Edge Sample Width/Selection Depth, or use Fill Color with Color Blend 1 for a solid fill.");
            if (fallback)
            {
                Vector3 axisScale = new Vector3(sourceToWorld.MultiplyVector(Vector3.right).magnitude,
                    sourceToWorld.MultiplyVector(Vector3.up).magnitude, sourceToWorld.MultiplyVector(Vector3.forward).magnitude);
                samples = new[] { new FillSplat { pos = sourceToWorld.inverse.MultiplyPoint3x4(origin),
                    dc0 = Vector3.zero, opacity = FillLogit(1), rot = new Quaternion(1,0,0,0),
                    scale = new Vector3(Mathf.Log(0.025f / axisScale.x), Mathf.Log(0.025f / axisScale.y), Mathf.Log(0.025f / axisScale.z)) } };
            }
            else
            {
                // GPU append order is not stable. Sort spatially before constructing the lookup.
                samples = (FillSplat[])samples.Clone();
                Array.Sort(samples, (a,b) => { int value = a.pos.x.CompareTo(b.pos.x); if (value != 0) return value;
                    value = a.pos.y.CompareTo(b.pos.y); return value != 0 ? value : a.pos.z.CompareTo(b.pos.z); });
            }
            var projected = new Vector2[samples.Length];
            double sigmaSum = 0;
            for (int i = 0; i < samples.Length; ++i)
            {
                var sample = samples[i];
                Vector3 p = sourceToWorld.MultiplyPoint3x4(sample.pos) - origin;
                projected[i] = new Vector2(Vector3.Dot(p,tangent), Vector3.Dot(p,bitangent));
                // Export uses PLY rotation (w,x,y,z) and logarithmic scale.
                var q = new Quaternion(sample.rot.y, sample.rot.z, sample.rot.w, sample.rot.x).normalized;
                Vector3 scale = new Vector3(Mathf.Exp(sample.scale.x), Mathf.Exp(sample.scale.y), Mathf.Exp(sample.scale.z));
                if (!FillFinite(scale) || scale.x <= 0 || scale.y <= 0 || scale.z <= 0)
                    throw new InvalidOperationException("An edge sample has an invalid scale.");
                Vector3 x = sourceToWorld.MultiplyVector(q * Vector3.right * scale.x);
                Vector3 y = sourceToWorld.MultiplyVector(q * Vector3.up * scale.y);
                Vector3 z = sourceToWorld.MultiplyVector(q * Vector3.forward * scale.z);
                float u = Mathf.Sqrt(Mathf.Pow(Vector3.Dot(x,tangent),2) + Mathf.Pow(Vector3.Dot(y,tangent),2) + Mathf.Pow(Vector3.Dot(z,tangent),2));
                float v = Mathf.Sqrt(Mathf.Pow(Vector3.Dot(x,bitangent),2) + Mathf.Pow(Vector3.Dot(y,bitangent),2) + Mathf.Pow(Vector3.Dot(z,bitangent),2));
                sigmaSum += (u + v) * 0.5f;
            }
            float sigma = fallback ? 0.025f : (float)(sigmaSum / samples.Length);
            float spacing = Mathf.Max(0.001f, sigma * 2f / brush.FillDensity);
            if (!FillFinite(spacing)) throw new InvalidOperationException("The edge samples could not provide a fill spacing.");
            Vector2 size = max - min;
            double columns = Math.Max(1, Math.Ceiling(size.x / spacing));
            double rows = Math.Max(1, Math.Ceiling(size.y / spacing));
            double layers = Math.Max(1, Math.Ceiling(brush.SelectionDepth / spacing));
            if (columns * rows * layers > MaxPagedFillGridCandidates)
                throw new InvalidOperationException("The fill grid is too large. Reduce Fill Density/Selection Depth or draw a smaller polygon.");
            int nx = (int)columns, ny = (int)rows, nz = (int)layers;
            var tree = new FillSampleTree(projected);
            var output = new List<FillSplat>();
            var random = new System.Random(173);
            Matrix4x4 inverse = sourceToWorld.inverse;
            float jitter = brush.PositionJitter * spacing;
            float scaleAdjustment = Mathf.Log(1.5f / brush.FillDensity + 0.5f);
            for (int z = 0; z < nz; ++z)
                for (int y = 0; y < ny; ++y)
                    for (int x = 0; x < nx; ++x)
                    {
                        Vector2 point = new Vector2(Mathf.Lerp(min.x,max.x,(x + 0.5f)/nx), Mathf.Lerp(min.y,max.y,(y + 0.5f)/ny));
                        if (!FillContains(outline, point)) continue;
                        Vector2 displaced = point + new Vector2((float)random.NextDouble()*2-1, (float)random.NextDouble()*2-1) * jitter;
                        if (FillContains(outline, displaced)) point = displaced;
                        float depth = Mathf.Lerp(-brush.SelectionDepth*0.5f,brush.SelectionDepth*0.5f,(z+0.5f)/nz);
                        depth = Mathf.Clamp(depth + ((float)random.NextDouble()*2-1)*jitter, -brush.SelectionDepth*0.5f,brush.SelectionDepth*0.5f);
                        var splat = samples[tree.Nearest(point)];
                        splat.pos = inverse.MultiplyPoint3x4(origin + tangent*point.x + bitangent*point.y + normal*depth);
                        splat.scale += Vector3.one * scaleAdjustment;
                        float blend = brush.UseFillColor ? brush.FillColorBlend : 0;
                        var rgb = GaussianUtils.SH0ToColor(splat.dc0);
                        Color color = new Color(rgb.x,rgb.y,rgb.z,GaussianUtils.Sigmoid(splat.opacity));
                        color = Color.Lerp(color, brush.FillColor, blend);
                        color = AdjustPagedFillColor(color, brush.ColorAdjust);
                        splat.dc0 = (new Vector3(color.r,color.g,color.b)-Vector3.one*0.5f)/0.2820948f;
                        splat.opacity = FillLogit(color.a);
                        ScaleFillSH(ref splat, 1-blend);
                        if (output.Count >= MaxPagedFillSplats)
                            throw new InvalidOperationException($"The polygon exceeds {MaxPagedFillSplats:N0} fill splats. Reduce Fill Density/Selection Depth or use a smaller polygon.");
                        output.Add(splat);
                    }
            if (output.Count == 0) throw new InvalidOperationException("No fill points fit inside this polygon. Increase Fill Density or redraw the area.");
            return output.ToArray();
        }

        static float FillLogit(float alpha) { alpha = Mathf.Clamp(alpha,0.00001f,0.99999f); return Mathf.Log(alpha/(1-alpha)); }
        static bool FillContains(Vector2[] polygon, Vector2 point)
        {
            bool inside = false;
            Vector2 previous = polygon[polygon.Length-1];
            foreach (var current in polygon)
            {
                if ((current.y > point.y) != (previous.y > point.y) &&
                    point.x < (previous.x-current.x)*(point.y-current.y)/(previous.y-current.y)+current.x) inside = !inside;
                previous = current;
            }
            return inside;
        }
        static Color AdjustPagedFillColor(Color c, ColorAdjustments adjustment)
        {
            float exposure = Mathf.Pow(2,adjustment.exposure);
            c.r = Mathf.Max(0,((c.r*exposure-0.5f)*adjustment.contrast+0.5f)*adjustment.colorTint.r);
            c.g = Mathf.Max(0,((c.g*exposure-0.5f)*adjustment.contrast+0.5f)*adjustment.colorTint.g);
            c.b = Mathf.Max(0,((c.b*exposure-0.5f)*adjustment.contrast+0.5f)*adjustment.colorTint.b);
            if (Mathf.Abs(adjustment.hueShift)>0.1f || Mathf.Abs(adjustment.saturation-1)>0.001f)
            {
                float maximum = Mathf.Max(1,Mathf.Max(c.r,Mathf.Max(c.g,c.b)));
                Color.RGBToHSV(new Color(c.r/maximum,c.g/maximum,c.b/maximum),out float h,out float s,out float v);
                Color shifted = Color.HSVToRGB(Mathf.Repeat(h+adjustment.hueShift/360,1),Mathf.Clamp01(s*adjustment.saturation),v);
                c.r=shifted.r*maximum; c.g=shifted.g*maximum; c.b=shifted.b*maximum;
            }
            return c;
        }
        static void ScaleFillSH(ref FillSplat splat, float factor)
        {
            splat.sh1*=factor; splat.sh2*=factor; splat.sh3*=factor; splat.sh4*=factor; splat.sh5*=factor;
            splat.sh6*=factor; splat.sh7*=factor; splat.sh8*=factor; splat.sh9*=factor; splat.shA*=factor;
            splat.shB*=factor; splat.shC*=factor; splat.shD*=factor; splat.shE*=factor; splat.shF*=factor;
        }

        // Balanced 2D tree avoids testing every edge sample for every generated splat.
        sealed class FillSampleTree
        {
            readonly Vector2[] points;
            readonly int[] indices;
            public FillSampleTree(Vector2[] source)
            {
                points=source; indices=new int[source.Length];
                for(int i=0;i<indices.Length;++i) indices[i]=i;
                Build(0,indices.Length,0);
            }
            void Build(int start,int count,int axis)
            {
                if(count<=1) return;
                Array.Sort(indices,start,count,Comparer<int>.Create((a,b)=> {
                    int value=points[a][axis].CompareTo(points[b][axis]); return value!=0?value:a.CompareTo(b); }));
                int middle=start+count/2;
                Build(start,middle-start,1-axis); Build(middle+1,start+count-middle-1,1-axis);
            }
            public int Nearest(Vector2 point)
            {
                int best=0; float distance=float.MaxValue;
                Search(point,0,indices.Length,0,ref best,ref distance); return best;
            }
            void Search(Vector2 point,int start,int count,int axis,ref int best,ref float distance)
            {
                if(count==0) return;
                int middle=start+count/2, index=indices[middle];
                float candidate=(point-points[index]).sqrMagnitude;
                if(candidate<distance) { distance=candidate; best=index; }
                float delta=point[axis]-points[index][axis];
                int left=middle-start, right=start+count-middle-1;
                if(delta<0)
                {
                    Search(point,start,left,1-axis,ref best,ref distance);
                    if(delta*delta<=distance) Search(point,middle+1,right,1-axis,ref best,ref distance);
                }
                else
                {
                    Search(point,middle+1,right,1-axis,ref best,ref distance);
                    if(delta*delta<=distance) Search(point,start,left,1-axis,ref best,ref distance);
                }
            }
        }
    }
}
