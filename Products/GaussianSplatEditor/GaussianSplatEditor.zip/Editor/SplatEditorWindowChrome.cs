// SPDX-License-Identifier: MIT

using UnityEditor;
#if UNITY_EDITOR_WIN
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using UnityEngine;
#endif

namespace GaussianSplatting.Editor
{
    /// <summary>Styles floating Splat windows' native Windows captions.</summary>
    internal static class SplatEditorWindowChrome
    {
        public static void Request(EditorWindow window)
        {
#if UNITY_EDITOR_WIN
            if (!IsFloatingSplatEditor(window) || s_NativeUnavailable || !s_Pending.Add(window))
                return;

            // Wait until Unity has created/updated the native caption. Requests from Show,
            // OnEnable and OnFocus coalesce; no editor-update or repaint polling is needed.
            EditorApplication.delayCall += () =>
            {
                s_Pending.Remove(window);
                if (IsFloatingSplatEditor(window) && !s_NativeUnavailable)
                    Apply(window.titleContent?.text);
            };
#endif
        }

#if UNITY_EDITOR_WIN
        const uint kUseImmersiveDarkMode = 20;
        const uint kCaptionColor = 35;
        const uint kTextColor = 36;
        static readonly HashSet<EditorWindow> s_Pending = new HashSet<EditorWindow>();
        static bool s_NativeUnavailable;

        static bool IsFloatingSplatEditor(EditorWindow window) =>
            window != null && (window is GaussianSplatEditorWindow || window is GaussianPlyImporterWindow) && !window.docked;

        static void Apply(string expectedTitle)
        {
            if (string.IsNullOrEmpty(expectedTitle))
                return;

            try
            {
                uint processId = GetCurrentProcessId();
                var windows = new List<IntPtr>();
                // Keep interop calls outside the unmanaged callback so any unavailable entry
                // point is handled normally below, without an exception crossing the callback.
                if (!EnumWindows((handle, state) => { windows.Add(handle); return true; }, IntPtr.Zero))
                    return;

                IntPtr target = IntPtr.Zero;
                var title = new StringBuilder(expectedTitle.Length + 2);
                foreach (IntPtr handle in windows)
                {
                    if (GetWindowThreadProcessId(handle, out uint ownerProcessId) == 0 ||
                        ownerProcessId != processId || GetWindowTextLengthW(handle) != expectedTitle.Length)
                        continue;
                    title.Clear();
                    if (GetWindowTextW(handle, title, title.Capacity) == 0 ||
                        !string.Equals(title.ToString(), expectedTitle, StringComparison.Ordinal))
                        continue;

                    // Without a public Unity HWND API, an ambiguous title is safer to leave alone.
                    if (target != IntPtr.Zero)
                        return;
                    target = handle;
                }
                if (target == IntPtr.Zero)
                    return;

                int dark = 1;
                int caption = ToColorRef(SplatEditorTheme.Surface);
                int text = ToColorRef(SplatEditorTheme.Text);
                // Documented DWMWINDOWATTRIBUTE values. Older Windows versions reject unsupported
                // attributes with an HRESULT; leave their native caption unchanged in that case.
                // https://learn.microsoft.com/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute
                DwmSetWindowAttribute(target, kUseImmersiveDarkMode, ref dark, sizeof(int));
                DwmSetWindowAttribute(target, kCaptionColor, ref caption, sizeof(int));
                DwmSetWindowAttribute(target, kTextColor, ref text, sizeof(int));
            }
            catch (DllNotFoundException) { s_NativeUnavailable = true; }
            catch (EntryPointNotFoundException) { s_NativeUnavailable = true; }
        }

        static int ToColorRef(Color color)
        {
            Color32 rgb = color;
            return rgb.r | (rgb.g << 8) | (rgb.b << 16);
        }

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.Bool)]
        delegate bool EnumWindowsCallback(IntPtr handle, IntPtr state);

        [DllImport("user32.dll", ExactSpelling = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool EnumWindows(EnumWindowsCallback callback, IntPtr state);

        [DllImport("user32.dll", ExactSpelling = true)]
        static extern uint GetWindowThreadProcessId(IntPtr handle, out uint processId);

        [DllImport("user32.dll", ExactSpelling = true)]
        static extern int GetWindowTextLengthW(IntPtr handle);

        [DllImport("user32.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
        static extern int GetWindowTextW(IntPtr handle, StringBuilder text, int maxCount);

        [DllImport("kernel32.dll", ExactSpelling = true)]
        static extern uint GetCurrentProcessId();

        [DllImport("dwmapi.dll", ExactSpelling = true)]
        static extern int DwmSetWindowAttribute(IntPtr handle, uint attribute, ref int value, uint size);
#endif
    }
}
