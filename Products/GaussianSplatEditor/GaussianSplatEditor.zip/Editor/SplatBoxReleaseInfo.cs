// SPDX-License-Identifier: MIT

using System;
using System.Globalization;
using System.IO;
using UnityEditor.PackageManager;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    /// <summary>Release metadata from the owning package, cached for this editor domain.</summary>
    internal static class SplatBoxReleaseInfo
    {
        [Serializable]
        sealed class Manifest
        {
            public string version;
            public string releaseDate;
        }

        static bool s_Loaded;
        static string s_Version;
        static string s_ReleaseDate;
        static GUIContent s_VersionBadge;
        static GUIContent s_ReleaseLabel;

        public static string Version { get { EnsureLoaded(); return s_Version; } }
        public static string ReleaseDate { get { EnsureLoaded(); return s_ReleaseDate; } }
        public static GUIContent VersionBadge { get { EnsureLoaded(); return s_VersionBadge; } }
        public static GUIContent ReleaseLabel { get { EnsureLoaded(); return s_ReleaseLabel; } }

        static void EnsureLoaded()
        {
            if (s_Loaded)
                return;
            s_Loaded = true;
            s_Version = string.Empty;
            s_ReleaseDate = string.Empty;
            PackageInfo package = PackageInfo.FindForAssembly(typeof(GaussianSplatEditorWindow).Assembly);
            if (package != null)
            {
                s_Version = package.version;
                try
                {
                    // A precompiled/combined distribution owns its own manifest at the same
                    // resolved package root. No source checkout or hard-coded folder is required.
                    string manifestPath = Path.Combine(package.resolvedPath, "package.json");
                    var manifest = JsonUtility.FromJson<Manifest>(File.ReadAllText(manifestPath));
                    if (manifest != null)
                    {
                        if (!string.IsNullOrWhiteSpace(manifest.version))
                            s_Version = manifest.version;
                        s_ReleaseDate = manifest.releaseDate ?? string.Empty;
                    }
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
                catch (ArgumentException) { }
            }

            string versionLabel = string.IsNullOrWhiteSpace(s_Version) ? "Version unknown" : "v" + s_Version;
            if (System.Version.TryParse(s_Version, out var version) && version.Build == 0)
                versionLabel = "v" + version.Major + "." + version.Minor;
            s_VersionBadge = new GUIContent(versionLabel, "SplatBox package version " + s_Version);

            bool validDate = DateTimeOffset.TryParse(s_ReleaseDate, CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out var releaseDate);
            s_ReleaseLabel = new GUIContent(validDate
                ? "Released " + releaseDate.ToString("dd MMM yyyy \u00b7 HH:mm 'UTC'", CultureInfo.InvariantCulture)
                : "Release date unavailable", "Package release timestamp: " + s_ReleaseDate);
        }

        public static void RequireMetadataForExport()
        {
            EnsureLoaded();
            if (string.IsNullOrWhiteSpace(s_Version) ||
                !DateTimeOffset.TryParse(s_ReleaseDate, CultureInfo.InvariantCulture,
                    DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out _))
                throw new InvalidOperationException("SplatBox package.json must contain its version and UTC releaseDate before exporting a plugin package.");
        }
    }
}
