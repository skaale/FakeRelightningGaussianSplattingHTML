// SPDX-License-Identifier: MIT
using System;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Editor
{
    [InitializeOnLoad]
    static class MonolithicXcopy
    {
        const int MaxSplats = 300_000;
        static MonolithicXcopy() => GaussianSplatBoxBrush.PasteInEditor = Paste;

        static void Paste(GaussianSplatBoxBrush brush)
        {
            var source = brush.TargetRenderer;
            if (EditorUtility.IsPersistent(source) || !source.gameObject.scene.IsValid() || PrefabStageUtility.GetCurrentPrefabStage() != null)
            {
                Debug.LogWarning("Xcopy requires a scene object outside Prefab Mode.");
                return;
            }
            var actual = source.transform.localToWorldMatrix;
            var trs = Matrix4x4.TRS(source.transform.position, source.transform.rotation, source.transform.lossyScale);
            for (int i = 0; i < 16; ++i)
                if (Mathf.Abs(actual[i] - trs[i]) > 0.001f)
                {
                    Debug.LogWarning("Xcopy cannot copy a sheared source transform. Remove non-uniformly scaled parents first.");
                    return;
                }

            string folder = null;
            GameObject root = null;
            try
            {
                int capacity = Mathf.Min(MaxSplats, source.splatCount);
                using var gpu = new GraphicsBuffer(GraphicsBuffer.Target.Structured, capacity, UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>());
                if (!source.ExportBoxXcopy(brush.CopiedSourcePosition, brush.CopiedBoxSize, brush.CopiedBoxRotation, gpu, out int count))
                    throw new InvalidOperationException("Could not read the copied splats.");
                if (count == 0) { Debug.LogWarning("Xcopy: no visible splats found in the source box."); return; }
                if (count > capacity) { Debug.LogWarning($"Xcopy: select a smaller area (maximum {MaxSplats:N0} splats)."); return; }
                var splats = new GaussianSplatAssetCreator.InputSplatData[count];
                gpu.GetData(splats, 0, 0, count);
                if (brush.ApplyColorAdjustments && brush.ColorAdjust.HasAdjustments)
                    for (int i = 0; i < splats.Length; ++i) splats[i].dc0 = AdjustColor(splats[i].dc0, brush.ColorAdjust);

                const string parent = "Assets/SplatBoxXcopy";
                if (!AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder("Assets", "SplatBoxXcopy");
                string name = "Xcopy_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder(parent, name);
                folder = parent + "/" + name;
                using var input = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(splats, Allocator.TempJob);
                string path = GaussianSplatAssetCreator.CreateAssetFromSplats(input, folder, name, GaussianSplatAssetCreator.DataQuality.VeryHigh);
                var asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
                if (asset == null) throw new InvalidOperationException("Could not create the Xcopy asset.");

                root = new GameObject(source.name + " Xcopy");
                root.SetActive(false);
                SceneManager.MoveGameObjectToScene(root, source.gameObject.scene);
                root.transform.position = brush.CopiedSourcePosition;
                var child = new GameObject("Copied splats");
                child.transform.SetParent(root.transform, false);
                child.transform.position = source.transform.position;
                child.transform.rotation = source.transform.rotation;
                child.transform.localScale = source.transform.lossyScale;
                var renderer = child.AddComponent<SplatBoxRenderer>();
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(source), renderer);
                using (var serialized = new SerializedObject(renderer))
                {
                    serialized.FindProperty("m_Asset").objectReferenceValue = asset;
                    serialized.FindProperty("m_PagedScene").objectReferenceValue = null;
                    serialized.FindProperty("m_LodStreamer").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedEraseScene").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedEraseStrokes").ClearArray();
                    serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedXcopySource").objectReferenceValue = source;
                    serialized.FindProperty("m_PagedXcopyRoot").objectReferenceValue = root;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                renderer.m_Cutouts = Array.Empty<GaussianCutout>();
                Quaternion currentRotation = brush.BrushMode == BoxBrushMode.Planar ? Quaternion.identity : brush.BoxRotationQuat;
                Quaternion delta = currentRotation * Quaternion.Inverse(brush.CopiedBoxRotation);
                root.transform.rotation = delta * (brush.ApplyPasteTransform ? brush.PasteTransformSettings.GetRotation() : Quaternion.identity);
                root.transform.localScale = brush.ApplyPasteTransform ? brush.PasteTransformSettings.GetCombinedScale() : Vector3.one;
                root.transform.position = brush.BrushMode == BoxBrushMode.Planar ? brush.PlanarBoxPosition : brush.BoxPosition;
                Undo.RegisterCreatedObjectUndo(root, "Paste splat object");
                root.SetActive(true);
                EditorSceneManager.MarkSceneDirty(root.scene);
                Selection.activeGameObject = root;
                SceneView.RepaintAll();
            }
            catch (Exception e)
            {
                if (root != null) Object.DestroyImmediate(root);
                if (!string.IsNullOrEmpty(folder)) AssetDatabase.DeleteAsset(folder);
                Debug.LogException(e);
            }
            finally { EditorUtility.ClearProgressBar(); }
        }

        static Vector3 AdjustColor(Vector3 dc, ColorAdjustments adj)
        {
            const float sh = 0.2820948f;
            Color c = new Color(dc.x * sh + 0.5f, dc.y * sh + 0.5f, dc.z * sh + 0.5f);
            float exposure = Mathf.Pow(2f, adj.exposure);
            c.r = ((c.r * exposure - 0.5f) * adj.contrast + 0.5f) * adj.colorTint.r;
            c.g = ((c.g * exposure - 0.5f) * adj.contrast + 0.5f) * adj.colorTint.g;
            c.b = ((c.b * exposure - 0.5f) * adj.contrast + 0.5f) * adj.colorTint.b;
            if (Mathf.Abs(adj.hueShift) > 0.1f || Mathf.Abs(adj.saturation - 1f) > 0.001f)
            {
                float scale = Mathf.Max(1f, c.r, c.g, c.b);
                Color.RGBToHSV(new Color(c.r / scale, c.g / scale, c.b / scale), out float h, out float s, out float v);
                h = Mathf.Repeat(h + adj.hueShift / 360f, 1f);
                c = Color.HSVToRGB(h, Mathf.Clamp01(s * adj.saturation), v) * scale;
            }
            return new Vector3((Mathf.Max(0, c.r) - 0.5f) / sh, (Mathf.Max(0, c.g) - 0.5f) / sh, (Mathf.Max(0, c.b) - 0.5f) / sh);
        }
    }
}
