// SPDX-License-Identifier: MIT
using System;
using GaussianSplatting.Runtime;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;
using PaintSplat = GaussianSplatting.Editor.GaussianSplatAssetCreator.InputSplatData;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        const int MaxPaintStrokeSplats = 300_000;
        SplatBoxRenderer m_PaintOutputSource;
        SplatBoxRenderer m_PaintOutput;
        GaussianSplatAsset m_PaintSavedAsset;
        GameObject m_PaintOutputRoot;
        string m_PaintOutputFolder;
        string m_PaintOutputStatus;
        bool m_FinishingPaintOutput;
        int m_PaintOutputEndIndex;
        string m_PaintOutputOperation = "Paint";

        void HookPaintPersistence()
        {
            EditorSceneManager.sceneSaving += OnPaintSceneSaving;
            AssemblyReloadEvents.beforeAssemblyReload += FinishPaintOutputStroke;
        }

        void UnhookPaintPersistence()
        {
            EditorSceneManager.sceneSaving -= OnPaintSceneSaving;
            AssemblyReloadEvents.beforeAssemblyReload -= FinishPaintOutputStroke;
        }

        void OnPaintSceneSaving(Scene scene, string path)
        {
            if (m_PaintOutputRoot != null && m_PaintOutputRoot.scene == scene) FinishPaintOutputStroke();
        }

        void UpdatePaintPersistence()
        {
            if (m_PaintOutputRoot != null &&
                (m_TargetRenderer != m_PaintOutputSource || m_CurrentTool != BrushTool.PaintBrush ||
                 m_PaintBrushMode != 0 || m_ShowLightingWorkspace))
                FinishPaintOutputStroke();
        }

        static void ClearPagedEditHistoryForGeneratedOutput(SerializedObject renderer)
        {
            // Generated Float32 assets already contain their new geometry and colors. Source page
            // journals do not apply to the new indices, and retaining them duplicates potentially
            // large sculpt/Relax histories in every Paint, Stamp, or Fill output.
            foreach (string field in new[] { "m_PagedScene", "m_LodStreamer", "m_PagedEraseScene",
                "m_PagedColorizeScene", "m_PagedSmudgeScene" })
                renderer.FindProperty(field).objectReferenceValue = null;
            foreach (string field in new[] { "m_PagedEraseStrokes", "m_PagedColorizeStrokes",
                "m_PagedSmudgeDabs", "m_PagedEditSculptHistory" })
                renderer.FindProperty(field).ClearArray();
            foreach (string field in new[] { "m_PagedEraseRevision", "m_PagedColorizeCursor", "m_PagedColorizeUndoFloor",
                "m_PagedColorizeRevision", "m_PagedSmudgeRevision" })
                renderer.FindProperty(field).intValue = 0;
        }

        bool BeginPaintOutputStroke()
        {
            FinishPaintOutputStroke();
            if (m_PaintOutputRoot != null) return false;
            var source = m_TargetRenderer;
            if (source == null || m_PaintBrush == null || !source.HasValidAsset || !source.HasValidRenderSetup) return false;
            m_PaintBrush.TargetRenderer = source;
            m_PaintOutputStatus = null;
            if (source.SupportsInPlacePaint) return true;
            if (EditorApplication.isPlayingOrWillChangePlaymode)
            { m_PaintOutputStatus = "Painting paged or compressed sources is available in Edit mode. Stop Play mode to paint."; return false; }
            if (EditorUtility.IsPersistent(source) || !source.gameObject.scene.IsValid() || PrefabStageUtility.GetCurrentPrefabStage() != null)
            { m_PaintOutputStatus = "Paint requires a scene renderer outside Prefab Mode."; return false; }
            var actual = source.transform.localToWorldMatrix;
            var trs = Matrix4x4.TRS(source.transform.position, source.transform.rotation, source.transform.lossyScale);
            for (int i = 0; i < 16; ++i)
                if (!FillFinite(actual[i]) || Mathf.Abs(actual[i] - trs[i]) > 0.001f)
                { m_PaintOutputStatus = "Remove the source's sheared transform before painting."; return false; }
            if (Mathf.Abs(actual.determinant) < 1e-12f)
            { m_PaintOutputStatus = "The source transform has a zero scale."; return false; }
            try
            {
                const string parent = "Assets/SplatBoxPaint";
                if (!AssetDatabase.IsValidFolder(parent)) AssetDatabase.CreateFolder("Assets", "SplatBoxPaint");
                string name = "Stroke_" + Guid.NewGuid().ToString("N");
                AssetDatabase.CreateFolder(parent, name); m_PaintOutputFolder = parent + "/" + name;
                // A transparent seed provides editable Float32 buffers for live feedback.
                // Only subsequently painted indices are exported into the final asset.
                using var seed = new NativeArray<PaintSplat>(new[] {
                    new PaintSplat { opacity = -30, scale = Vector3.one * Mathf.Log(0.0001f), rot = new Quaternion(1,0,0,0) }
                }, Allocator.TempJob);
                string path = GaussianSplatAssetCreator.CreateAssetFromSplats(seed, m_PaintOutputFolder, "Preview", GaussianSplatAssetCreator.DataQuality.VeryHigh);
                var asset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
                if (asset == null) throw new InvalidOperationException("Could not create the paint preview asset.");
                using (var seedData = new SerializedObject(asset))
                {
                    // GetWorldBounds includes the sculpt displacement envelope. Bring the complete
                    // world AABB back to source space conservatively, including rotated/mirrored
                    // transforms, so preview stamps beyond the original page bounds remain visible.
                    Bounds worldBounds = source.GetWorldBounds();
                    Matrix4x4 worldToLocal = source.transform.worldToLocalMatrix;
                    Vector3 center = worldToLocal.MultiplyPoint3x4(worldBounds.center);
                    Vector3 e = worldBounds.extents;
                    Vector3 extents = new Vector3(
                        Mathf.Abs(worldToLocal.m00) * e.x + Mathf.Abs(worldToLocal.m01) * e.y + Mathf.Abs(worldToLocal.m02) * e.z,
                        Mathf.Abs(worldToLocal.m10) * e.x + Mathf.Abs(worldToLocal.m11) * e.y + Mathf.Abs(worldToLocal.m12) * e.z,
                        Mathf.Abs(worldToLocal.m20) * e.x + Mathf.Abs(worldToLocal.m21) * e.y + Mathf.Abs(worldToLocal.m22) * e.z);
                    seedData.FindProperty("m_BoundsMin").vector3Value = center - extents - Vector3.one * 10f;
                    seedData.FindProperty("m_BoundsMax").vector3Value = center + extents + Vector3.one * 10f;
                    seedData.ApplyModifiedPropertiesWithoutUndo();
                }
                m_PaintOutputRoot = new GameObject(GameObjectUtility.GetUniqueNameForSibling(null, source.name + " Paint")); m_PaintOutputRoot.SetActive(false);
                SceneManager.MoveGameObjectToScene(m_PaintOutputRoot, source.gameObject.scene);
                var child = new GameObject("Painted splats"); child.transform.SetParent(m_PaintOutputRoot.transform, false);
                child.transform.SetPositionAndRotation(source.transform.position, source.transform.rotation);
                child.transform.localScale = source.transform.lossyScale;
                m_PaintOutput = child.AddComponent<SplatBoxRenderer>();
                EditorJsonUtility.FromJsonOverwrite(EditorJsonUtility.ToJson(source), m_PaintOutput);
                using (var serialized = new SerializedObject(m_PaintOutput))
                {
                    serialized.FindProperty("m_Asset").objectReferenceValue = asset;
                    ClearPagedEditHistoryForGeneratedOutput(serialized);
                    serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = null;
                    serialized.FindProperty("m_PagedXcopySource").objectReferenceValue = source;
                    serialized.FindProperty("m_PagedXcopyRoot").objectReferenceValue = m_PaintOutputRoot;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                m_PaintOutput.m_Cutouts = Array.Empty<GaussianCutout>();
                m_PaintOutput.m_RenderOrder = source.m_RenderOrder < int.MaxValue ? source.m_RenderOrder + 1 : int.MaxValue;
                m_PaintOutputRoot.SetActive(true);
                if (!m_PaintOutput.HasValidRenderSetup || !m_PaintOutput.SupportsInPlacePaint)
                    throw new InvalidOperationException("The paint preview renderer did not initialize.");
                m_PaintOutputSource = source;
                m_PaintOutputEndIndex = 1;
                m_PaintBrush.PaintOutputRenderer = m_PaintOutput;
                return true;
            }
            catch (Exception exception)
            {
                DiscardEmptyPaintOutput();
                m_PaintOutputStatus = "Paint could not start: " + exception.Message;
                if (!(exception is InvalidOperationException)) Debug.LogException(exception);
                return false;
            }
            finally { EditorUtility.ClearProgressBar(); Repaint(); }
        }

        bool CanAppendPaintOutput()
        {
            if (m_PaintOutput == null) return true;
            if (m_PaintBrush != null && m_PaintBrush.PaintedSplatEndIndex + m_PaintBrush.SplatsPerStroke <= MaxPaintStrokeSplats + 1) return true;
            FinishPaintOutputStroke();
            m_PaintOutputStatus = "Stroke reached 300,000 splats and was saved. Release the mouse, then start another stroke.";
            return false;
        }

        void RecordPaintOutputProgress()
        {
            if (m_PaintOutput != null && m_PaintBrush != null && m_PaintBrush.PaintOutputRenderer == m_PaintOutput)
                m_PaintOutputEndIndex = Mathf.Max(m_PaintOutputEndIndex, m_PaintBrush.PaintedSplatEndIndex);
        }

        void FinishPaintOutputStroke()
        {
            if (m_FinishingPaintOutput) return;
            GaussianSplatPaintBrush.IsPainting = false;
            m_IsPaintStrokeActive = false;
            if (m_PaintOutputRoot == null)
            {
                if (m_PaintBrush != null) m_PaintBrush.PaintOutputRenderer = null;
                return;
            }
            m_FinishingPaintOutput = true;
            try
            {
                RecordPaintOutputProgress();
                int count = m_PaintOutputEndIndex - 1;
                if (count <= 0) { DiscardEmptyPaintOutput(); return; }
                if (m_PaintOutput == null) throw new InvalidOperationException("The paint preview renderer is missing.");
                if (m_PaintSavedAsset == null)
                {
                    using var gpu = new GraphicsBuffer(GraphicsBuffer.Target.Structured, count, UnsafeUtility.SizeOf<PaintSplat>());
                    if (!m_PaintOutput.ExportPaintSplats(gpu, 1, count)) throw new InvalidOperationException("Could not read the painted splats.");
                    var data = new PaintSplat[count]; gpu.GetData(data);
                    using var input = new NativeArray<PaintSplat>(data, Allocator.TempJob);
                    string path = GaussianSplatAssetCreator.CreateAssetFromSplats(input, m_PaintOutputFolder, "Paint", GaussianSplatAssetCreator.DataQuality.VeryHigh);
                    var saved = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(path);
                    if (saved == null || saved.splatCount != count) throw new InvalidOperationException("Could not save the painted splats.");
                    m_PaintSavedAsset = saved;
                }
                // After assignment the final asset has no seed. A retry must reuse its
                // saved data, never export the old seed-relative range a second time.
                var asset = m_PaintSavedAsset;
                count = asset.splatCount;
                m_PaintOutput.enabled = false;
                using (var serialized = new SerializedObject(m_PaintOutput))
                {
                    serialized.FindProperty("m_Asset").objectReferenceValue = asset;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                m_PaintOutput.enabled = true;
                if (!m_PaintOutput.HasValidRenderSetup || m_PaintOutput.activeSplatCount != count)
                    throw new InvalidOperationException("The saved paint renderer did not initialize.");
                Undo.IncrementCurrentGroup();
                int group = Undo.GetCurrentGroup();
                Undo.SetCurrentGroupName(m_PaintOutputOperation + " Splat Stroke");
                Undo.RegisterCreatedObjectUndo(m_PaintOutputRoot, m_PaintOutputOperation + " Splat Stroke");
                Undo.FlushUndoRecordObjects(); Undo.CollapseUndoOperations(group);
                EditorUtility.SetDirty(m_PaintOutput);
                EditorSceneManager.MarkSceneDirty(m_PaintOutputRoot.scene);
                m_PaintOutputStatus = $"Saved {count:N0} {m_PaintOutputOperation.ToLowerInvariant()} splats. Save the scene to retain this stroke.";
                // The seed is no longer referenced by the scene or its creation Undo.
                AssetDatabase.DeleteAsset(m_PaintOutputFolder + "/Preview.asset");
                foreach (string suffix in new[] { "_pos.bytes", "_oth.bytes", "_col.bytes", "_shs.bytes", "_chk.bytes" })
                    AssetDatabase.DeleteAsset(m_PaintOutputFolder + "/Preview" + suffix);
                ClearPaintOutputReferences();
            }
            catch (Exception exception)
            {
                m_PaintOutputStatus = "Paint could not be saved: " + exception.Message + " Keep this window open and retry saving the scene.";
                Debug.LogError(m_PaintOutputStatus);
            }
            finally
            {
                m_FinishingPaintOutput = false;
                EditorUtility.ClearProgressBar();
                EditorApplication.QueuePlayerLoopUpdate(); SceneView.RepaintAll(); Repaint();
            }
        }

        void ClearPaintOutputReferences()
        {
            if (m_PaintBrush != null) m_PaintBrush.PaintOutputRenderer = null;
            m_PaintOutput = null; m_PaintSavedAsset = null; m_PaintOutputRoot = null; m_PaintOutputSource = null; m_PaintOutputFolder = null;
            m_PaintOutputEndIndex = 0;
            m_PaintOutputOperation = "Paint";
        }

        void DiscardEmptyPaintOutput()
        {
            if (m_PaintOutputRoot != null) Object.DestroyImmediate(m_PaintOutputRoot);
            if (!string.IsNullOrEmpty(m_PaintOutputFolder)) AssetDatabase.DeleteAsset(m_PaintOutputFolder);
            ClearPaintOutputReferences();
        }
    }
}
