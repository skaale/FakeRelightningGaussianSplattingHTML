// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        // Relight is optional in exported packages. Keep its types behind the existing assembly boundary.
        static readonly Type s_LightManagerType = Type.GetType(
            "GaussianSplatting.Relight.CustomLightManager, GaussianSplatting.SplatBox.Relight");
        static readonly string[] s_LightNames = { "Point", "Spot", "Directional", "Planar" };
        static readonly string[] s_LightRoots = { "Point Lights", "Spot Lights", "Directional Lights", "Planar Lights" };
        static readonly Type[] s_LightTypes = Array.ConvertAll(s_LightNames, name => Type.GetType(
            "GaussianSplatting.Relight.Relight" + name + "Light, GaussianSplatting.SplatBox.Relight"));
        static readonly MethodInfo[] s_AddLightMethods = Array.ConvertAll(s_LightNames,
            name => s_LightManagerType?.GetMethod("Add" + name + "Light"));
        static readonly MethodInfo s_RefreshManager = s_LightManagerType?.GetMethod("RefreshLightBuffers");
        static readonly SplatEditorTheme.Icon[] s_LightIcons =
        {
            SplatEditorTheme.Icon.PointLight, SplatEditorTheme.Icon.SpotLight,
            SplatEditorTheme.Icon.DirectionalLight, SplatEditorTheme.Icon.PlanarLight
        };

        [SerializeField] Component m_LightingManager;
        [SerializeField] Component m_SelectedRelightLight;
        [SerializeField] bool m_ShowAdvancedLighting;
        readonly List<Component> m_RelightLights = new List<Component>();
        Vector2 m_LightListScroll;
        SerializedObject m_LightSettings;
        SerializedObject m_LightManagerSettings;
        SerializedObject m_LightRendererSettings;
        GUIStyle[] m_LightAddButtonStyles;
        GUISkin m_LightButtonSkin;
        double m_NextLightingScan;
        int m_LightingManagerCount;
        string m_LightingMessage;

        /// <summary>Open the integrated lighting workspace, reusing the main Splat Editor window.</summary>
        public static void ShowLightingWindow()
        {
            ShowWindow();
            s_Window.OpenLightingWorkspace();
        }

        public static void ShowLightingWindow(Component manager)
        {
            ShowWindow();
            if (s_Window.IsWorkspaceManager(manager)) s_Window.m_LightingManager = manager;
            s_Window.OpenLightingWorkspace();
        }

        void OpenLightingWorkspace()
        {
            DeactivateCurrentTool();
            m_ShowLightingWorkspace = true;
            m_ToolScroll = Vector2.zero;
            RefreshLightingWorkspace(true);
            if (Event.current != null) GUI.FocusControl(null);
            Repaint();
        }

        void OnLightingHierarchyChanged()
        {
            m_NextLightingScan = 0;
            if (m_ShowLightingWorkspace)
                Repaint();
        }

        void OnLightingUndoRedo()
        {
            OnLightingHierarchyChanged();
            if (IsWorkspaceManager(m_LightingManager)) RefreshWorkspaceLightBuffers();
        }

        bool HasLightingRenderer => m_TargetRenderer != null &&
            StageUtility.GetStageHandle(m_TargetRenderer.gameObject).Equals(StageUtility.GetCurrentStageHandle());

        Scene LightingScene => HasLightingRenderer && m_TargetRenderer.gameObject.scene.IsValid()
            ? m_TargetRenderer.gameObject.scene
            : PrefabStageUtility.GetCurrentPrefabStage()?.scene ?? SceneManager.GetActiveScene();

        static SerializedObject LightingSettings(ref SerializedObject settings, Object target)
        {
            if (target == null || settings == null || settings.targetObject != target)
            {
                settings?.Dispose();
                settings = target != null ? new SerializedObject(target) : null;
            }
            return settings;
        }

        void DisposeLightingSettings()
        {
            m_LightSettings?.Dispose();
            m_LightManagerSettings?.Dispose();
            m_LightRendererSettings?.Dispose();
            m_LightSettings = m_LightManagerSettings = m_LightRendererSettings = null;
        }

        bool IsWorkspaceManager(Component manager)
        {
            if (manager == null || s_LightManagerType == null || !s_LightManagerType.IsInstanceOfType(manager) ||
                EditorUtility.IsPersistent(manager) || !manager.gameObject.scene.IsValid())
                return false;
            return StageUtility.GetStageHandle(manager.gameObject).Equals(StageUtility.GetCurrentStageHandle());
        }

        void RefreshLightingWorkspace(bool force = false)
        {
            if (s_LightManagerType == null || (!force && EditorApplication.timeSinceStartup < m_NextLightingScan))
                return;
            m_NextLightingScan = EditorApplication.timeSinceStartup + 1;
            if (!IsWorkspaceManager(m_LightingManager))
                m_LightingManager = null;
            Component first = null, sameScene = null;
            m_LightingManagerCount = 0;
            foreach (var candidate in Object.FindObjectsOfType(s_LightManagerType, true))
            {
                var manager = candidate as Component;
                if (!IsWorkspaceManager(manager)) continue;
                m_LightingManagerCount++;
                if (first == null) first = manager;
                if (sameScene == null && manager.gameObject.scene == LightingScene) sameScene = manager;
            }
            // Reuse a loaded manager instead of silently adding another global light-buffer owner.
            if (m_LightingManager == null) m_LightingManager = sameScene != null ? sameScene : first;
            m_RelightLights.Clear();
            if (m_LightingManager != null)
            {
                foreach (var component in m_LightingManager.GetComponentsInChildren<Component>(true))
                    if (RelightTypeIndex(component) >= 0) m_RelightLights.Add(component);
            }
            if (m_SelectedRelightLight != null && !m_RelightLights.Contains(m_SelectedRelightLight))
                m_SelectedRelightLight = null;
            if (m_SelectedRelightLight == null && m_RelightLights.Count > 0)
                m_SelectedRelightLight = m_RelightLights[0];
            if (m_LightManagerSettings != null && m_LightManagerSettings.targetObject != m_LightingManager)
                LightingSettings(ref m_LightManagerSettings, null);
            if (m_LightSettings != null && m_LightSettings.targetObject != m_SelectedRelightLight)
                LightingSettings(ref m_LightSettings, null);
        }

        static int RelightTypeIndex(Component component)
        {
            if (component != null)
                for (int i = 0; i < s_LightTypes.Length; i++)
                    if (s_LightTypes[i] != null && s_LightTypes[i].IsInstanceOfType(component)) return i;
            return -1;
        }

        bool HasLiveRelightPreview()
        {
            if (!HasLightingRenderer || !m_TargetRenderer.usesRelightShader) return false;
            if (!m_TargetRenderer.UsesPagedLod || Application.isPlaying) return true;
            LightingSettings(ref m_LightRendererSettings, m_TargetRenderer);
            m_LightRendererSettings.Update();
            return !(m_LightRendererSettings.FindProperty("m_LodFastEditorPreview")?.boolValue ?? false);
        }

        void EnableWorkspaceRelightPreview()
        {
            if (HasLightingRenderer && !HasLiveRelightPreview())
                ApplyRelightShaderToRenderer(m_TargetRenderer);
            EditorApplication.QueuePlayerLoopUpdate();
            SceneView.RepaintAll();
        }

        void DrawRelightWorkspace()
        {
            if (s_LightManagerType == null)
            {
                GUILayout.Label("Install the SplatBox Relight add-on to create custom lights.", SplatEditorTheme.WrappedLabel);
                return;
            }
            if (Event.current.type == EventType.Layout) RefreshLightingWorkspace();
            bool livePreview = HasLiveRelightPreview();
            GUILayout.BeginHorizontal();
            GUILayout.Label(SplatEditorTheme.Content(livePreview ? "Relight preview is on" : "Relight preview is off",
                livePreview ? SplatEditorTheme.Icon.Check : SplatEditorTheme.Icon.Relight), SplatEditorTheme.BoldLabel);
            GUILayout.EndHorizontal();
            GUILayout.Label("Light your splats, then adjust each light here or move it in the Scene view.", SplatEditorTheme.WrappedMiniLabel);
            if (!livePreview)
            {
                using (new EditorGUI.DisabledScope(!HasLightingRenderer))
                    if (GUILayout.Button(SplatEditorTheme.Content("Enable Relight preview", SplatEditorTheme.Icon.Relight),
                        SplatEditorTheme.PrimaryButton, GUILayout.Height(28)))
                        m_AfterGuiAction = EnableWorkspaceRelightPreview;
                if (!HasLightingRenderer)
                    GUILayout.Label("Choose a splat renderer from the current scene or Prefab Mode to preview lighting.", SplatEditorTheme.WrappedMiniLabel);
            }
            GUILayout.Space(12);
            GUILayout.Label("LIGHT MANAGER", SplatEditorTheme.Subtitle);
            GUILayout.BeginHorizontal();
            EditorGUI.BeginChangeCheck();
            var manager = EditorGUILayout.ObjectField(m_LightingManager, s_LightManagerType, true) as Component;
            if (EditorGUI.EndChangeCheck())
                m_AfterGuiAction = () =>
                {
                    if (manager == null || IsWorkspaceManager(manager))
                    {
                        m_LightingManager = manager;
                        m_SelectedRelightLight = null;
                        RefreshLightingWorkspace(true);
                    }
                };
            if (GUILayout.Button(SplatEditorTheme.Content("", SplatEditorTheme.Icon.Search, "Find scene light managers"),
                SplatEditorTheme.Button, GUILayout.Width(30), GUILayout.Height(28)))
                m_AfterGuiAction = () => RefreshLightingWorkspace(true);
            GUILayout.EndHorizontal();
            if (m_LightingManager == null)
                GUILayout.Label("Your first light creates a manager automatically.", SplatEditorTheme.WrappedMiniLabel);
            else
            {
                GUILayout.Label(m_LightingManager.gameObject.scene.name + "  /  " + m_RelightLights.Count + " lights", SplatEditorTheme.MutedLabel);
                LightingSettings(ref m_LightManagerSettings, m_LightingManager);
                m_LightManagerSettings.Update();
                EditorGUI.BeginChangeCheck();
                DrawLightingProperty(m_LightManagerSettings, "m_ShowGizmos", "Scene gizmos");
                if (EditorGUI.EndChangeCheck()) QueueLightingProperties(m_LightManagerSettings);
            }
            if (m_LightingManagerCount > 1)
                GUILayout.Label("Multiple managers share the scene lighting. Use one manager for consistent results.", SplatEditorTheme.HelpBox);
            if (!string.IsNullOrEmpty(m_LightingMessage))
                GUILayout.Label(m_LightingMessage, SplatEditorTheme.HelpBox);

            GUILayout.Space(12);
            GUILayout.Label("ADD LIGHTS", SplatEditorTheme.Subtitle);
            GUILayout.Space(5);
            for (int row = 0; row < 2; row++)
            {
                GUILayout.BeginHorizontal();
                for (int column = 0; column < 2; column++)
                {
                    int index = row * 2 + column;
                    if (GUILayout.Button(SplatEditorTheme.Content(s_LightNames[index], s_LightIcons[index],
                        "Add a " + s_LightNames[index].ToLowerInvariant() + " light and enable Relight preview"),
                        LightAddButtonStyle(index), GUILayout.Height(42), GUILayout.MinWidth(0), GUILayout.ExpandWidth(true)))
                        m_AfterGuiAction = () => AddWorkspaceRelight(index);
                }
                GUILayout.EndHorizontal();
                if (row == 0) GUILayout.Space(6);
            }

            GUILayout.Space(14);
            GUILayout.Label("LIGHTS", SplatEditorTheme.Subtitle);
            if (m_RelightLights.Count == 0)
            {
                GUILayout.Label("Add a light above to get started.", SplatEditorTheme.WrappedMiniLabel);
                return;
            }
            m_LightListScroll = GUILayout.BeginScrollView(m_LightListScroll, false, false,
                GUILayout.Height(Mathf.Min(132, m_RelightLights.Count * 32 + 4)));
            for (int i = 0; i < m_RelightLights.Count; i++)
            {
                var light = m_RelightLights[i];
                int type = RelightTypeIndex(light);
                if (type < 0) continue;
                if (GUILayout.Button(SplatEditorTheme.Content(light.name, s_LightIcons[type]),
                    light == m_SelectedRelightLight ? SplatEditorTheme.ActiveTab : SplatEditorTheme.Tab, GUILayout.Height(30)))
                    m_AfterGuiAction = () => SelectWorkspaceLight(light);
                GUILayout.Space(2);
            }
            GUILayout.EndScrollView();
            DrawSelectedWorkspaceLight();
        }

        GUIStyle LightAddButtonStyle(int type)
        {
            // Toolbar tiles are 60px with image-above text. Light actions use their own 42px
            // horizontal style so the painted rectangle agrees with GUILayout's allocation.
            if (m_LightAddButtonStyles == null || m_LightButtonSkin != SplatEditorTheme.Skin)
            {
                m_LightButtonSkin = SplatEditorTheme.Skin;
                m_LightAddButtonStyles = new GUIStyle[s_LightIcons.Length];
            }
            return m_LightAddButtonStyles[type] ??= new GUIStyle(SplatEditorTheme.GetToolButtonStyle(s_LightIcons[type], false))
            {
                fixedHeight = 42,
                imagePosition = ImagePosition.ImageLeft,
                alignment = TextAnchor.MiddleLeft,
                fontSize = 11,
                fontStyle = FontStyle.Bold,
                padding = new RectOffset(12, 12, 6, 6),
                margin = new RectOffset(2, 2, 0, 0),
                stretchWidth = true
            };
        }

        void DrawSelectedWorkspaceLight()
        {
            int type = RelightTypeIndex(m_SelectedRelightLight);
            if (type < 0) return;
            var light = m_SelectedRelightLight;
            LightingSettings(ref m_LightSettings, light);
            m_LightSettings.Update();
            GUILayout.Space(12);
            GUILayout.Label(SplatEditorTheme.Content(s_LightNames[type] + " light", s_LightIcons[type]), SplatEditorTheme.BoldLabel);
            EditorGUI.BeginChangeCheck();
            DrawLightingProperty(m_LightSettings, "isActive", "Enabled");
            DrawLightingProperty(m_LightSettings, "color", "Color");
            DrawLightingProperty(m_LightSettings, "intensity", "Intensity", true);
            DrawLightingProperty(m_LightSettings, type == 2 ? "effectRange" : "range",
                type == 2 ? "Reach from origin (m)" : "Range (m)", true);
            if (type == 1)
            {
                DrawLightingProperty(m_LightSettings, "spotAngle", "Outer cone (deg)", true);
                DrawLightingProperty(m_LightSettings, "innerConeAngle", "Inner cone (deg)", true);
            }
            if (type == 3)
            {
                DrawLightingProperty(m_LightSettings, "size", "Size (m)");
                DrawLightingProperty(m_LightSettings, "twoSided", "Two sided");
            }
            bool propertiesChanged = EditorGUI.EndChangeCheck();
            GUILayout.Space(6);
            m_ShowAdvancedLighting = EditorGUILayout.Foldout(m_ShowAdvancedLighting, "Advanced lighting", true, SplatEditorTheme.Foldout);
            if (m_ShowAdvancedLighting)
            {
                EditorGUI.BeginChangeCheck();
                DrawLightingProperty(m_LightSettings, "attenuationMode", "Falloff");
                DrawLightingProperty(m_LightSettings, "rangeSoftness", "Edge softness (m)", true);
                DrawLightingProperty(m_LightSettings, "shadowStrength", "Shadow strength", true);
                DrawLightingProperty(m_LightSettings, "useDistanceAttenuation", "Distance falloff");
                DrawLightingProperty(m_LightSettings, "distanceAttenuationFactor", "Distance factor", true);
                DrawLightingProperty(m_LightSettings, "useAngleAttenuation", "Angle falloff");
                DrawLightingProperty(m_LightSettings, "angleAttenuationBias", "Angle bias", true);
                DrawLightingProperty(m_LightSettings, "showGizmo", "Show light gizmo");
                propertiesChanged |= EditorGUI.EndChangeCheck();
            }
            if (propertiesChanged) QueueLightingProperties(m_LightSettings);

            GUILayout.Space(10);
            EditorGUI.BeginChangeCheck();
            Vector3 position = light.transform.position;
            if (type != 2) position = EditorGUILayout.Vector3Field("Position", position);
            Vector3 rotation = light.transform.eulerAngles;
            if (type != 0) rotation = EditorGUILayout.Vector3Field("Rotation", rotation);
            if (EditorGUI.EndChangeCheck())
                m_AfterGuiAction = () =>
                {
                    if (light == null) return;
                    Undo.RecordObject(light.transform, "Move Relight light");
                    light.transform.SetPositionAndRotation(position, Quaternion.Euler(rotation));
                    PrefabUtility.RecordPrefabInstancePropertyModifications(light.transform);
                    RefreshWorkspaceLightBuffers();
                    MarkLightingSceneDirty(light);
                };
            GUILayout.Space(6);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(SplatEditorTheme.Content("Select in Scene", SplatEditorTheme.Icon.Search), SplatEditorTheme.Button, GUILayout.Height(28)))
                m_AfterGuiAction = () => SelectWorkspaceLight(light);
            if (GUILayout.Button(SplatEditorTheme.Content("Remove", SplatEditorTheme.Icon.Erase), SplatEditorTheme.Button, GUILayout.Height(28)))
                m_AfterGuiAction = () =>
                {
                    if (light == null) return;
                    var scene = light.gameObject.scene;
                    Undo.DestroyObjectImmediate(light.gameObject);
                    RefreshLightingWorkspace(true);
                    RefreshWorkspaceLightBuffers();
                    if (scene.IsValid()) EditorSceneManager.MarkSceneDirty(scene);
                };
            GUILayout.EndHorizontal();
        }

        static void DrawLightingProperty(SerializedObject settings, string propertyName, string label, bool nonnegative = false)
        {
            var property = settings.FindProperty(propertyName);
            if (property == null) return;
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, SplatEditorTheme.Label, GUILayout.Width(EditorGUIUtility.labelWidth));
            EditorGUI.BeginChangeCheck();
            if (property.propertyType == SerializedPropertyType.Boolean)
                property.boolValue = EditorGUILayout.Toggle(GUIContent.none, property.boolValue);
            else
                EditorGUILayout.PropertyField(property, GUIContent.none, true);
            if (EditorGUI.EndChangeCheck())
            {
                if (nonnegative && property.propertyType == SerializedPropertyType.Float)
                    property.floatValue = Mathf.Max(0, property.floatValue);
                if (propertyName == "spotAngle")
                {
                    property.floatValue = Mathf.Clamp(property.floatValue, 1, 179);
                    var innerCone = settings.FindProperty("innerConeAngle");
                    if (innerCone != null) innerCone.floatValue = Mathf.Clamp(innerCone.floatValue, 0, property.floatValue);
                }
                if (propertyName == "innerConeAngle")
                    property.floatValue = Mathf.Clamp(property.floatValue, 0, settings.FindProperty("spotAngle").floatValue);
                if (propertyName == "distanceAttenuationFactor") property.floatValue = Mathf.Clamp01(property.floatValue);
                if (propertyName == "shadowStrength") property.floatValue = Mathf.Clamp01(property.floatValue);
                if (propertyName == "size") property.vector2Value = Vector2.Max(Vector2.zero, property.vector2Value);
            }
            GUILayout.EndHorizontal();
        }

        void QueueLightingProperties(SerializedObject settings)
        {
            m_AfterGuiAction = () =>
            {
                if (settings.targetObject == null) return;
                Undo.SetCurrentGroupName("Edit Relight light");
                settings.ApplyModifiedProperties();
                if (settings.targetObject != m_LightingManager) RefreshWorkspaceLightBuffers();
                MarkLightingSceneDirty(settings.targetObject as Component);
            };
        }

        void SelectWorkspaceLight(Component light)
        {
            m_SelectedRelightLight = light;
            if (light != null)
            {
                Selection.activeGameObject = light.gameObject;
                EditorGUIUtility.PingObject(light.gameObject);
                Tools.current = RelightTypeIndex(light) == 2 ? Tool.Rotate : Tool.Move;
            }
            Repaint();
        }

        void AddWorkspaceRelight(int type)
        {
            if (type < 0 || type >= s_LightTypes.Length || s_LightTypes[type] == null || s_AddLightMethods[type] == null)
                return;
            RefreshLightingWorkspace(true);
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            string undoName = "Add Relight " + s_LightNames[type] + " light";
            Undo.SetCurrentGroupName(undoName);
            try
            {
                bool createdManager = m_LightingManager == null;
                if (createdManager)
                {
                    var go = new GameObject("Relight Lights");
                    StageUtility.PlaceGameObjectInCurrentStage(go);
                    // Prefab Mode already parents the object beneath its contents root. Only
                    // unparented main-stage objects need moving to another loaded scene.
                    if (go.transform.parent == null && go.scene != LightingScene &&
                        LightingScene.IsValid() && LightingScene.isLoaded)
                        SceneManager.MoveGameObjectToScene(go, LightingScene);
                    m_LightingManager = go.AddComponent(s_LightManagerType);
                    Undo.RegisterCreatedObjectUndo(go, undoName);
                }
                Transform oldRoot = m_LightingManager.transform.Find(s_LightRoots[type]);
                var light = s_AddLightMethods[type].Invoke(m_LightingManager, type == 2 ? null : new object[] { null }) as Component;
                if (light == null) throw new InvalidOperationException("The light could not be created.");
                // Register a new container hierarchy once; it includes the new child light.
                // A new manager's creation record already owns its entire new hierarchy.
                if (oldRoot == null && !createdManager)
                    Undo.RegisterCreatedObjectUndo(light.transform.parent.gameObject, undoName);
                else if (!createdManager)
                    Undo.RegisterCreatedObjectUndo(light.gameObject, undoName);
                var sceneView = SceneView.lastActiveSceneView;
                if (type != 2)
                {
                    Vector3 forward = sceneView != null && sceneView.camera != null ? sceneView.camera.transform.forward : Vector3.forward;
                    Vector3 pivot = sceneView != null ? sceneView.pivot : HasLightingRenderer ? m_TargetRenderer.transform.position : Vector3.zero;
                    light.transform.position = pivot - forward * 0.5f;
                    if (type != 0) light.transform.rotation = Quaternion.LookRotation(forward);
                }
                EnableWorkspaceRelightPreview();
                m_LightingMessage = null;
                SelectWorkspaceLight(light);
                RefreshLightingWorkspace(true);
                RefreshWorkspaceLightBuffers();
                MarkLightingSceneDirty(m_LightingManager);
            }
            catch (Exception exception)
            {
                m_LightingMessage = "Could not add the light: " + (exception.InnerException?.Message ?? exception.Message);
                Debug.LogException(exception);
            }
            finally { Undo.CollapseUndoOperations(undoGroup); }
        }

        void RefreshWorkspaceLightBuffers()
        {
            if (m_LightingManager != null) s_RefreshManager?.Invoke(m_LightingManager, null);
            EditorApplication.QueuePlayerLoopUpdate();
            SceneView.RepaintAll();
        }

        static void MarkLightingSceneDirty(Component component)
        {
            if (component != null)
            {
                EditorUtility.SetDirty(component);
                if (component.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(component.gameObject.scene);
            }
            EditorApplication.QueuePlayerLoopUpdate();
            SceneView.RepaintAll();
        }
    }
}
