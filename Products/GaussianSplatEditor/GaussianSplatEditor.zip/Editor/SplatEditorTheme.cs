// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    /// <summary>Window-local styling and code-drawn icons; never changes Unity's shared editor styles.</summary>
    [InitializeOnLoad]
    internal static class SplatEditorTheme
    {
        public enum Icon
        {
            Splat, Erase, Geometry, Copy, Clone, Fill, Mask, Color, Vortex, Paint,
            Stamp, Sculpt, Relight, Camera, Export, Help, Search, Add, Play, Stop,
            ChevronDown, ChevronRight, Settings, Reset, Check,
            PointLight, SpotLight, DirectionalLight, PlanarLight
        }

        public static readonly Color Background = Hex(0x10151D);
        public static readonly Color Surface = Hex(0x181F29);
        public static readonly Color SurfaceRaised = Hex(0x232D39);
        public static readonly Color Border = Hex(0x344151);
        public static readonly Color Text = Hex(0xE6EDF5);
        public static readonly Color Muted = Hex(0x99A9BB);
        public static readonly Color Accent = Hex(0x91DADB);
        public static readonly Color Mint = Hex(0xA8DCC6);
        public static readonly Color Peach = Hex(0xE8C2A6);
        public static readonly Color Lavender = Hex(0xC9BDEC);
        public static readonly Color Rose = Hex(0xE8B3C0);
        public static readonly Color Sky = Hex(0xACD0EC);
        public static readonly Color Success = Mint;
        public static readonly Color Warning = Peach;
        public static readonly Color Danger = Rose;

        public static GUISkin Skin { get; private set; }
        public static GUIStyle Panel { get; private set; }
        public static GUIStyle Header { get; private set; }
        public static GUIStyle Title { get; private set; }
        public static GUIStyle Subtitle { get; private set; }
        public static GUIStyle Button { get; private set; }
        public static GUIStyle PrimaryButton { get; private set; }
        public static GUIStyle ToolButton { get; private set; }
        public static GUIStyle ActiveToolButton { get; private set; }
        public static GUIStyle Tab { get; private set; }
        public static GUIStyle ActiveTab { get; private set; }
        public static GUIStyle MutedLabel { get; private set; }
        public static GUIStyle Badge { get; private set; }
        public static GUIStyle Label { get; private set; }
        public static GUIStyle BoldLabel { get; private set; }
        public static GUIStyle MiniLabel { get; private set; }
        public static GUIStyle MiniBoldLabel { get; private set; }
        public static GUIStyle WrappedLabel { get; private set; }
        public static GUIStyle WrappedMiniLabel { get; private set; }
        public static GUIStyle HelpBox { get; private set; }
        public static GUIStyle Popup { get; private set; }
        public static GUIStyle Foldout { get; private set; }

        static readonly List<Texture2D> s_Textures = new List<Texture2D>();
        static readonly Dictionary<Icon, Texture2D> s_Icons = new Dictionary<Icon, Texture2D>();
        static readonly Dictionary<ContentKey, GUIContent> s_Content = new Dictionary<ContentKey, GUIContent>();
        static readonly Dictionary<int, GUIStyle> s_ToolStyles = new Dictionary<int, GUIStyle>();

        static SplatEditorTheme()
        {
            AssemblyReloadEvents.beforeAssemblyReload += Dispose;
            EditorApplication.quitting += Dispose;
        }

        public static void EnsureInitialized()
        {
            if (Skin != null)
                return;

            // The scene skin supplies dark native widgets even when the host editor uses its light theme.
            Skin = UnityEngine.Object.Instantiate(EditorGUIUtility.GetBuiltinSkin(EditorSkin.Scene));
            Skin.name = "Splat Editor Dark Skin";
            Skin.hideFlags = HideFlags.HideAndDontSave;
            Skin.settings.cursorColor = Text;
            Skin.settings.selectionColor = new Color(Accent.r, Accent.g, Accent.b, 0.35f);

            Texture2D panel = MakeSurface(Surface, Border);
            Texture2D normal = MakeSurface(SurfaceRaised, Border);
            Texture2D hover = MakeSurface(Hex(0x303D4D), Hex(0x60738A));
            Texture2D pressed = MakeSurface(Hex(0x151E29), Accent);
            Texture2D selected = MakeSurface(Hex(0x193C45), Hex(0x418994));
            Texture2D selectedHover = MakeSurface(Hex(0x224F5A), Accent);
            Texture2D primary = MakeSurface(Hex(0x2B5059), Hex(0x5A8B94));
            Texture2D primaryHover = MakeSurface(Hex(0x35636D), Accent);

            Panel = new GUIStyle(Skin.box)
            {
                border = new RectOffset(6, 6, 6, 6),
                padding = new RectOffset(14, 14, 12, 12),
                margin = new RectOffset(0, 0, 0, 0),
                stretchWidth = true
            };
            SetStates(Panel, panel, panel, panel, Text);
            Header = MakeLabel(11, FontStyle.Bold, Text);
            Header.padding = new RectOffset(0, 0, 2, 6);
            Title = MakeLabel(20, FontStyle.Bold, Text);
            Subtitle = MakeLabel(11, FontStyle.Normal, Muted);
            Subtitle.wordWrap = true;
            MutedLabel = MakeLabel(11, FontStyle.Normal, Muted);
            Label = MakeLabel(11, FontStyle.Normal, Text);
            BoldLabel = MakeLabel(11, FontStyle.Bold, Text);
            MiniLabel = MakeLabel(10, FontStyle.Normal, Muted);
            MiniBoldLabel = MakeLabel(10, FontStyle.Bold, Text);
            WrappedLabel = new GUIStyle(Label) { wordWrap = true };
            WrappedMiniLabel = new GUIStyle(MiniLabel) { wordWrap = true };
            HelpBox = new GUIStyle(Panel)
            {
                fontSize = 11,
                alignment = TextAnchor.MiddleLeft,
                wordWrap = true,
                padding = new RectOffset(10, 10, 8, 8),
                margin = new RectOffset(0, 0, 4, 4)
            };
            Foldout = new GUIStyle(EditorStyles.foldout);
            SetTextColors(Foldout, Text);
            Popup = new GUIStyle(EditorStyles.popup)
            {
                border = new RectOffset(6, 12, 5, 5),
                padding = new RectOffset(6, 22, 2, 2),
                fixedHeight = 22
            };
            SetStates(Popup, MakeSurface(Hex(0x111821), Border, 3f, true),
                MakeSurface(Hex(0x1C2733), Hex(0x60738A), 3f, true),
                MakeSurface(Hex(0x111821), Accent, 3f, true), Text);

            Button = new GUIStyle(Skin.button)
            {
                fontSize = 11,
                fontStyle = FontStyle.Normal,
                alignment = TextAnchor.MiddleCenter,
                imagePosition = ImagePosition.ImageLeft,
                fixedHeight = 28,
                border = new RectOffset(6, 6, 6, 6),
                padding = new RectOffset(10, 10, 4, 4),
                margin = new RectOffset(2, 2, 2, 2)
            };
            SetStates(Button, normal, hover, pressed, Text);
            PrimaryButton = new GUIStyle(Button) { fontStyle = FontStyle.Bold };
            SetStates(PrimaryButton, primary, primaryHover, pressed, Text);
            ToolButton = new GUIStyle(Button)
            {
                fixedHeight = 60,
                fontSize = 10,
                imagePosition = ImagePosition.ImageAbove,
                padding = new RectOffset(5, 5, 8, 5),
                margin = new RectOffset(3, 3, 0, 0)
            };
            ActiveToolButton = new GUIStyle(ToolButton) { fontStyle = FontStyle.Bold };
            SetStates(ActiveToolButton, selected, selectedHover, pressed, Accent);
            Tab = new GUIStyle(Button)
            {
                fixedHeight = 30,
                margin = new RectOffset(2, 2, 0, 0),
                padding = new RectOffset(10, 10, 4, 4)
            };
            ActiveTab = new GUIStyle(Tab) { fontStyle = FontStyle.Bold };
            SetStates(ActiveTab, selected, selectedHover, pressed, Accent);
            Badge = new GUIStyle(Button)
            {
                fixedHeight = 23,
                fontSize = 10,
                fontStyle = FontStyle.Bold,
                padding = new RectOffset(9, 9, 3, 3),
                margin = new RectOffset(0, 0, 0, 0)
            };
            SetStates(Badge, selected, selected, selected, Success);

            Skin.box = new GUIStyle(Panel);
            Skin.button = new GUIStyle(Button);
            Skin.label = MakeLabel(11, FontStyle.Normal, Text);
            Skin.label.wordWrap = false;
            Skin.toggle = new GUIStyle(Skin.toggle);
            SetTextColors(Skin.toggle, Text);
            Texture2D input = MakeSurface(Hex(0x111821), Border, 3f);
            Texture2D inputFocused = MakeSurface(Hex(0x111821), Hex(0x43858E), 3f);
            Skin.textField = new GUIStyle(Skin.textField)
            {
                border = new RectOffset(5, 5, 5, 5),
                padding = new RectOffset(6, 6, 3, 3)
            };
            SetStates(Skin.textField, input, input, inputFocused, Text);
            Skin.textField.focused.background = inputFocused;
            Skin.textArea = new GUIStyle(Skin.textField) { wordWrap = true };
            ConfigureScrollbars();

            // Clone custom styles as well: an IMGUI skin change must never recolor another editor window.
            GUIStyle[] originals = Skin.customStyles ?? Array.Empty<GUIStyle>();
            var localStyles = new GUIStyle[originals.Length];
            for (int i = 0; i < originals.Length; i++)
            {
                localStyles[i] = new GUIStyle(originals[i]);
                SetTextColors(localStyles[i], Text);
            }
            Skin.customStyles = localStyles;
        }

        static void ConfigureScrollbars()
        {
            // Keep a ten-pixel drag target while the inset textures show an eight-pixel track
            // and a six-pixel thumb. The controls reserve the same space in either orientation.
            Color trackColor = Hex(0x111720);
            Color thumbColor = Hex(0x455363);
            Color thumbHover = Hex(0x6E8093);
            Color thumbActive = Hex(0x8DA4BA);
            Skin.horizontalScrollbar = ScrollbarStyle(false, false, trackColor, trackColor, trackColor);
            Skin.verticalScrollbar = ScrollbarStyle(true, false, trackColor, trackColor, trackColor);
            Skin.horizontalScrollbarThumb = ScrollbarStyle(false, true, thumbColor, thumbHover, thumbActive);
            Skin.verticalScrollbarThumb = ScrollbarStyle(true, true, thumbColor, thumbHover, thumbActive);

            // Arrow buttons would consume most of a thin scrollbar; the track still supports
            // page clicks and the thumb supports dragging in addition to wheel/trackpad scrolling.
            Skin.horizontalScrollbarLeftButton = EmptyScrollbarButton();
            Skin.horizontalScrollbarRightButton = EmptyScrollbarButton();
            Skin.verticalScrollbarUpButton = EmptyScrollbarButton();
            Skin.verticalScrollbarDownButton = EmptyScrollbarButton();
        }

        static GUIStyle EmptyScrollbarButton() => new GUIStyle
        {
            fixedWidth = 0,
            fixedHeight = 0,
            margin = new RectOffset(),
            padding = new RectOffset(),
            border = new RectOffset(),
            stretchWidth = false,
            stretchHeight = false
        };

        static GUIStyle ScrollbarStyle(bool vertical, bool thumb, Color normal, Color hover, Color active)
        {
            var style = new GUIStyle
            {
                name = "Splat " + (vertical ? "Vertical" : "Horizontal") + (thumb ? " Thumb" : " Scrollbar"),
                fixedWidth = vertical ? 10 : 0,
                fixedHeight = vertical ? 0 : 10,
                border = new RectOffset(4, 4, 4, 4),
                margin = new RectOffset(),
                padding = thumb ? (vertical ? new RectOffset(0, 0, 8, 8) : new RectOffset(8, 8, 0, 0))
                    : new RectOffset(),
                stretchWidth = !vertical,
                stretchHeight = vertical
            };
            Texture2D normalTexture = MakeScrollbarTexture(normal, vertical, thumb);
            Texture2D hoverTexture = hover == normal ? normalTexture : MakeScrollbarTexture(hover, vertical, thumb);
            Texture2D activeTexture = active == normal ? normalTexture : MakeScrollbarTexture(active, vertical, thumb);
            SetStates(style, normalTexture, hoverTexture, activeTexture, Text);
            return style;
        }

        static Texture2D MakeScrollbarTexture(Color color, bool vertical, bool thumb)
        {
            const int size = 20;
            float thicknessInset = thumb ? 2f : 1f;
            float insetX = vertical ? thicknessInset : 1f;
            float insetY = vertical ? 1f : thicknessInset;
            const float radius = 3f;
            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float qx = Mathf.Abs(x + 0.5f - size * 0.5f) - (size * 0.5f - insetX - radius);
                float qy = Mathf.Abs(y + 0.5f - size * 0.5f) - (size * 0.5f - insetY - radius);
                float dx = Mathf.Max(qx, 0f), dy = Mathf.Max(qy, 0f);
                float distance = Mathf.Sqrt(dx * dx + dy * dy) + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
                pixels[y * size + x] = new Color(color.r, color.g, color.b, Mathf.Clamp01(0.5f - distance));
            }
            return MakeTexture(size, pixels, "Splat Editor " + (thumb ? "Scroll Thumb" : "Scroll Track"));
        }

        public static Color GetIconColor(Icon icon)
        {
            switch (icon)
            {
                case Icon.Erase:
                case Icon.Mask:
                case Icon.Stop:
                    return Rose;
                case Icon.Geometry:
                case Icon.Copy:
                case Icon.Search:
                case Icon.Settings:
                case Icon.SpotLight:
                    return Sky;
                case Icon.Clone:
                case Icon.Fill:
                case Icon.Export:
                case Icon.Add:
                case Icon.Play:
                case Icon.Check:
                case Icon.DirectionalLight:
                    return Mint;
                case Icon.Paint:
                case Icon.Sculpt:
                case Icon.Relight:
                case Icon.Reset:
                case Icon.PointLight:
                    return Peach;
                case Icon.Color:
                case Icon.Vortex:
                case Icon.Camera:
                case Icon.Help:
                case Icon.PlanarLight:
                    return Lavender;
                case Icon.Splat:
                case Icon.Stamp:
                    return Accent;
                default:
                    return Muted;
            }
        }

        public static GUIStyle GetToolButtonStyle(Icon icon, bool selected)
        {
            EnsureInitialized();
            int key = ((int)icon << 1) | (selected ? 1 : 0);
            if (s_ToolStyles.TryGetValue(key, out GUIStyle style))
                return style;
            Color color = GetIconColor(icon);
            Color fill = Color.Lerp(SurfaceRaised, color, selected ? 0.16f : 0.045f);
            Color outline = Color.Lerp(Border, color, selected ? 0.78f : 0.18f);
            Color hoverFill = Color.Lerp(SurfaceRaised, color, selected ? 0.23f : 0.10f);
            Color hoverOutline = Color.Lerp(Border, color, selected ? 1f : 0.43f);
            style = new GUIStyle(ToolButton) { fontStyle = selected ? FontStyle.Bold : FontStyle.Normal };
            SetStates(style, MakeSurface(fill, outline), MakeSurface(hoverFill, hoverOutline),
                MakeSurface(Color.Lerp(Surface, color, 0.14f), color), selected ? color : Text);
            s_ToolStyles.Add(key, style);
            return style;
        }

        static GUIStyle MakeLabel(int size, FontStyle weight, Color color)
        {
            var style = new GUIStyle(EditorStyles.label)
            {
                fontSize = size,
                fontStyle = weight,
                alignment = TextAnchor.MiddleLeft,
                margin = new RectOffset(0, 0, 0, 0),
                padding = new RectOffset(0, 0, 0, 0)
            };
            SetTextColors(style, color);
            return style;
        }

        static void SetStates(GUIStyle style, Texture2D normal, Texture2D hover, Texture2D active, Color color)
        {
            style.normal.background = normal;
            style.hover.background = hover;
            style.active.background = active;
            style.focused.background = hover;
            style.onNormal.background = active;
            style.onHover.background = hover;
            style.onActive.background = active;
            style.onFocused.background = hover;
            SetTextColors(style, color);
        }

        static void SetTextColors(GUIStyle style, Color color)
        {
            style.normal.textColor = color;
            style.hover.textColor = color;
            style.active.textColor = color;
            style.focused.textColor = color;
            style.onNormal.textColor = color;
            style.onHover.textColor = color;
            style.onActive.textColor = color;
            style.onFocused.textColor = color;
        }

        static Color Hex(uint value) => new Color(
            ((value >> 16) & 255) / 255f, ((value >> 8) & 255) / 255f, (value & 255) / 255f);

        static Texture2D MakeSurface(Color fill, Color outline, float radius = 5f, bool dropdown = false)
        {
            const int size = 20;
            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float qx = Mathf.Abs(x + 0.5f - size * 0.5f) - (size * 0.5f - radius - 0.5f);
                float qy = Mathf.Abs(y + 0.5f - size * 0.5f) - (size * 0.5f - radius - 0.5f);
                float distance = Mathf.Sqrt(Mathf.Max(qx, 0f) * Mathf.Max(qx, 0f) +
                    Mathf.Max(qy, 0f) * Mathf.Max(qy, 0f)) + Mathf.Min(Mathf.Max(qx, qy), 0f) - radius;
                Color pixel = Color.Lerp(outline, fill, Mathf.Clamp01(-distance - 0.5f));
                if (dropdown)
                {
                    var p = new Vector2(x + 0.5f, size - y - 0.5f);
                    float arrowDistance = Mathf.Min(
                        SegmentDistance(p, new Vector2(12, 8.5f), new Vector2(15, 11.5f)),
                        SegmentDistance(p, new Vector2(15, 11.5f), new Vector2(18, 8.5f)));
                    pixel = Color.Lerp(pixel, Muted, Mathf.Clamp01(1.2f - arrowDistance));
                }
                pixel.a = Mathf.Clamp01(0.5f - distance);
                pixels[y * size + x] = pixel;
            }
            return MakeTexture(size, pixels, "Splat Editor Surface");
        }

        static float SegmentDistance(Vector2 p, Vector2 a, Vector2 b)
        {
            Vector2 line = b - a;
            float t = Mathf.Clamp01(Vector2.Dot(p - a, line) / line.sqrMagnitude);
            return (p - a - t * line).magnitude;
        }

        static Texture2D MakeTexture(int size, Color[] pixels, string name)
        {
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false)
            {
                name = name,
                hideFlags = HideFlags.HideAndDontSave,
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear
            };
            texture.SetPixels(pixels);
            texture.Apply(false, true);
            s_Textures.Add(texture);
            return texture;
        }

        public static GUIContent Content(string label, Icon icon, string tooltip = null)
        {
            var key = new ContentKey(label, icon, tooltip);
            if (!s_Content.TryGetValue(key, out GUIContent content))
            {
                content = new GUIContent(label, GetIcon(icon), tooltip ?? string.Empty);
                s_Content.Add(key, content);
            }
            return content;
        }

        public static Texture2D GetIcon(Icon icon)
        {
            if (s_Icons.TryGetValue(icon, out Texture2D texture) && texture != null)
                return texture;
            var c = new IconCanvas();
            switch (icon)
            {
                case Icon.Splat:
                    c.Circle(12, 12, 3, true); c.Circle(6, 6, 1.6f, true);
                    c.Circle(18, 6, 1.6f, true); c.Circle(6, 18, 1.6f, true); c.Circle(18, 18, 1.6f, true);
                    c.Line(8, 8, 10, 10); c.Line(14, 10, 16, 8); c.Line(8, 16, 10, 14); c.Line(14, 14, 16, 16);
                    break;
                case Icon.Erase:
                    c.Path(3, 14, 13, 4, 21, 12, 12, 21, 9, 21, 3, 15, 3, 14);
                    c.Line(8, 9, 16, 17); c.Line(12, 21, 21, 21);
                    break;
                case Icon.Geometry:
                    c.Path(12, 3, 21, 8, 21, 17, 12, 22, 3, 17, 3, 8, 12, 3);
                    c.Path(3, 8, 12, 13, 21, 8); c.Line(12, 13, 12, 22);
                    break;
                case Icon.Copy:
                    c.Path(8, 4, 4, 4, 4, 17); c.Rect(8, 8, 13, 13);
                    break;
                case Icon.Clone:
                    c.Rect(3, 3, 12, 12); c.Rect(10, 10, 11, 11); c.Path(15, 5, 20, 5, 20, 8);
                    break;
                case Icon.Fill:
                    c.Path(4, 13, 12, 5, 20, 13, 12, 21, 4, 13);
                    c.Line(7, 13, 17, 13); c.Line(8, 3, 14, 9); c.Circle(21, 20, 1.5f, true);
                    break;
                case Icon.Mask:
                    c.Path(4, 5, 18, 3, 21, 15, 11, 21, 3, 15, 4, 5);
                    c.Circle(4, 5, 1.3f, true); c.Circle(18, 3, 1.3f, true);
                    c.Circle(21, 15, 1.3f, true); c.Circle(11, 21, 1.3f, true);
                    c.Line(7, 10, 16, 8); c.Line(7, 14, 17, 12);
                    break;
                case Icon.Color:
                    c.Arc(12, 12, 9, 35, 320); c.Path(19, 18, 14, 17, 14, 21);
                    c.Circle(7, 9, 1.1f, true); c.Circle(11, 6, 1.1f, true);
                    c.Circle(16, 7, 1.1f, true); c.Circle(18, 11, 1.1f, true);
                    break;
                case Icon.Vortex:
                    for (int i = 0; i < 72; i++)
                    {
                        float a = i * Mathf.PI / 12f;
                        float b = (i + 1) * Mathf.PI / 12f;
                        float r0 = 1 + i / 9f, r1 = 1 + (i + 1) / 9f;
                        c.Line(12 + Mathf.Cos(a) * r0, 12 + Mathf.Sin(a) * r0,
                            12 + Mathf.Cos(b) * r1, 12 + Mathf.Sin(b) * r1);
                    }
                    break;
                case Icon.Paint:
                    c.Path(9, 14, 17, 3, 21, 7, 10, 15); c.Path(9, 14, 5, 14, 4, 19, 2, 21, 8, 21, 11, 18, 9, 14);
                    break;
                case Icon.Stamp:
                    c.Path(7, 4, 17, 4, 17, 9, 15, 13, 21, 17, 21, 20, 3, 20, 3, 17, 9, 13, 7, 9, 7, 4);
                    c.Line(3, 17, 21, 17);
                    break;
                case Icon.Sculpt:
                    c.Path(3, 18, 7, 8, 12, 4, 17, 9, 21, 18, 3, 18);
                    c.Path(7, 8, 12, 14, 17, 9); c.Path(3, 18, 12, 14, 21, 18); c.Line(12, 4, 12, 14);
                    break;
                case Icon.Relight:
                    c.Circle(12, 12, 4);
                    for (int i = 0; i < 8; i++)
                    {
                        float a = i * Mathf.PI / 4;
                        c.Line(12 + Mathf.Cos(a) * 7, 12 + Mathf.Sin(a) * 7,
                            12 + Mathf.Cos(a) * 10, 12 + Mathf.Sin(a) * 10);
                    }
                    break;
                case Icon.PointLight:
                    c.Circle(12, 12, 4);
                    c.Line(12, 2, 12, 5); c.Line(12, 19, 12, 22);
                    c.Line(2, 12, 5, 12); c.Line(19, 12, 22, 12);
                    c.Line(4, 4, 6, 6); c.Line(18, 18, 20, 20);
                    c.Line(4, 20, 6, 18); c.Line(18, 6, 20, 4);
                    break;
                case Icon.SpotLight:
                    c.Path(8, 3, 16, 3, 16, 7, 8, 7, 8, 3);
                    c.Path(9, 9, 3, 21, 21, 21, 15, 9); c.Line(12, 10, 12, 17);
                    break;
                case Icon.DirectionalLight:
                    c.Circle(6, 6, 3);
                    c.Path(10, 10, 20, 20, 20, 15); c.Line(20, 20, 15, 20);
                    c.Path(14, 5, 21, 12, 21, 8); c.Path(5, 14, 12, 21, 8, 21);
                    break;
                case Icon.PlanarLight:
                    c.Path(3, 5, 18, 5, 21, 10, 6, 10, 3, 5);
                    c.Path(7, 13, 7, 21, 4, 18); c.Line(7, 21, 10, 18);
                    c.Path(17, 13, 17, 21, 14, 18); c.Line(17, 21, 20, 18);
                    break;
                case Icon.Camera:
                    c.Path(3, 7, 8, 7, 10, 4, 15, 4, 17, 7, 21, 7, 21, 20, 3, 20, 3, 7);
                    c.Circle(12, 13, 4);
                    break;
                case Icon.Export:
                    c.Path(4, 14, 4, 21, 20, 21, 20, 14); c.Line(12, 3, 12, 16);
                    c.Path(7, 8, 12, 3, 17, 8);
                    break;
                case Icon.Help:
                    c.Circle(12, 12, 9); c.Arc(12, 9, 3, 180, 390);
                    c.Path(14.6f, 10.5f, 12, 13, 12, 14); c.Circle(12, 18, 0.9f, true);
                    break;
                case Icon.Search:
                    c.Circle(10, 10, 6); c.Line(14.5f, 14.5f, 21, 21);
                    break;
                case Icon.Add:
                    c.Line(12, 5, 12, 19); c.Line(5, 12, 19, 12);
                    break;
                case Icon.Play:
                    c.Path(7, 3, 21, 12, 7, 21, 7, 3);
                    break;
                case Icon.Stop:
                    c.Rect(5, 5, 14, 14);
                    break;
                case Icon.ChevronDown:
                    c.Path(6, 9, 12, 15, 18, 9);
                    break;
                case Icon.ChevronRight:
                    c.Path(9, 6, 15, 12, 9, 18);
                    break;
                case Icon.Settings:
                    c.Line(4, 6, 20, 6); c.Line(4, 12, 20, 12); c.Line(4, 18, 20, 18);
                    c.Circle(9, 6, 2.3f, true); c.Circle(16, 12, 2.3f, true); c.Circle(7, 18, 2.3f, true);
                    break;
                case Icon.Reset:
                    c.Arc(12, 12, 8, -90, 215); c.Path(3, 4, 3, 10, 9, 10);
                    break;
                case Icon.Check:
                    c.Path(4, 12, 10, 18, 21, 6);
                    break;
            }
            texture = MakeTexture(24, c.Pixels(GetIconColor(icon)), "Splat Editor " + icon);
            s_Icons[icon] = texture;
            return texture;
        }

        public static void Dispose()
        {
            s_Content.Clear();
            s_Icons.Clear();
            s_ToolStyles.Clear();
            foreach (Texture2D texture in s_Textures)
                if (texture != null) UnityEngine.Object.DestroyImmediate(texture);
            s_Textures.Clear();
            if (Skin != null) UnityEngine.Object.DestroyImmediate(Skin);
            Skin = null;
        }

        readonly struct ContentKey : IEquatable<ContentKey>
        {
            readonly string m_Label, m_Tooltip;
            readonly Icon m_Icon;

            public ContentKey(string label, Icon icon, string tooltip)
            {
                m_Label = label ?? string.Empty;
                m_Tooltip = tooltip ?? string.Empty;
                m_Icon = icon;
            }

            public bool Equals(ContentKey other) => m_Icon == other.m_Icon &&
                m_Label == other.m_Label && m_Tooltip == other.m_Tooltip;
            public override bool Equals(object obj) => obj is ContentKey other && Equals(other);
            public override int GetHashCode()
            {
                unchecked { return ((m_Label.GetHashCode() * 397) ^ m_Tooltip.GetHashCode()) * 397 ^ (int)m_Icon; }
            }
        }

        // Four-times supersampling keeps diagonal strokes and circles clean at ordinary editor scale.
        sealed class IconCanvas
        {
            const int Scale = 4;
            const int Size = 24 * Scale;
            readonly float[] m_Coverage = new float[Size * Size];

            public void Line(float ax, float ay, float bx, float by, float width = 1.55f)
            {
                float dx = bx - ax, dy = by - ay;
                float lengthSquared = dx * dx + dy * dy;
                for (int y = 0; y < Size; y++)
                for (int x = 0; x < Size; x++)
                {
                    float px = (x + 0.5f) / Scale, py = (y + 0.5f) / Scale;
                    float t = lengthSquared > 0f ? Mathf.Clamp01(((px - ax) * dx + (py - ay) * dy) / lengthSquared) : 0f;
                    float ex = px - ax - t * dx, ey = py - ay - t * dy;
                    Blend(x, y, Mathf.Sqrt(ex * ex + ey * ey) - width * 0.5f);
                }
            }

            public void Path(params float[] coordinates)
            {
                for (int i = 2; i + 1 < coordinates.Length; i += 2)
                    Line(coordinates[i - 2], coordinates[i - 1], coordinates[i], coordinates[i + 1]);
            }

            public void Rect(float x, float y, float width, float height) =>
                Path(x, y, x + width, y, x + width, y + height, x, y + height, x, y);

            public void Circle(float cx, float cy, float radius, bool fill = false)
            {
                for (int y = 0; y < Size; y++)
                for (int x = 0; x < Size; x++)
                {
                    float dx = (x + 0.5f) / Scale - cx, dy = (y + 0.5f) / Scale - cy;
                    float d = Mathf.Sqrt(dx * dx + dy * dy) - radius;
                    Blend(x, y, fill ? d : Mathf.Abs(d) - 0.775f);
                }
            }

            public void Arc(float cx, float cy, float radius, float startDegrees, float endDegrees)
            {
                int steps = Mathf.CeilToInt(Mathf.Abs(endDegrees - startDegrees) / 10f);
                for (int i = 0; i < steps; i++)
                {
                    float a = Mathf.Lerp(startDegrees, endDegrees, i / (float)steps) * Mathf.Deg2Rad;
                    float b = Mathf.Lerp(startDegrees, endDegrees, (i + 1) / (float)steps) * Mathf.Deg2Rad;
                    Line(cx + Mathf.Cos(a) * radius, cy + Mathf.Sin(a) * radius,
                        cx + Mathf.Cos(b) * radius, cy + Mathf.Sin(b) * radius);
                }
            }

            void Blend(int x, int y, float distance)
            {
                int i = y * Size + x;
                m_Coverage[i] = Mathf.Max(m_Coverage[i], Mathf.Clamp01(0.5f - distance * Scale));
            }

            public Color[] Pixels(Color tint)
            {
                var pixels = new Color[24 * 24];
                for (int y = 0; y < 24; y++)
                for (int x = 0; x < 24; x++)
                {
                    float alpha = 0f;
                    for (int sy = 0; sy < Scale; sy++)
                    for (int sx = 0; sx < Scale; sx++)
                        alpha += m_Coverage[(y * Scale + sy) * Size + x * Scale + sx];
                    // The drawing coordinates use a top-left origin, unlike Texture2D pixel rows.
                    pixels[(23 - y) * 24 + x] = new Color(tint.r, tint.g, tint.b, tint.a * alpha / (Scale * Scale));
                }
                return pixels;
            }
        }
    }
}
