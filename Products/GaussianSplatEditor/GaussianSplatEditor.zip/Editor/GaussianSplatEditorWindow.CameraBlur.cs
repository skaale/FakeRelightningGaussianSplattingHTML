// SPDX-License-Identifier: MIT
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        Camera m_ObservedBlurCamera;
        GaussianSplatTiltShiftEffect m_ObservedBlurEffect;
        bool m_HasObservedBlurCamera;

        [MenuItem("SplatToolbox/Editor/Camera Effects", false, 101)]
        public static void ShowCameraEffects()
        {
            ShowWindow();
            s_Window.m_WorkspacePanel = WorkspacePanel.Camera;
            s_Window.m_ShowTiltShift = true;
            s_Window.RefreshCameraBlurSettings(true);
            s_Window.Repaint();
        }

        Camera ResolveCameraBlurTarget() => Camera.main;

        void DrawCameraBlurTarget()
        {
            RefreshCameraBlurSettings();
            var camera = ResolveCameraBlurTarget();
            GUILayout.Label(camera != null ? "Main Camera: " + camera.name + ". Settings save with the scene." :
                "No active Main Camera found. Tag your scene camera MainCamera to save these effects.",
                SplatEditorTheme.WrappedMiniLabel);
        }

        void OnCameraBlurUndoRedo()
        {
            RefreshCameraBlurSettings(true);
            Repaint();
        }

        void RefreshCameraBlurSettings(bool force = false)
        {
            var camera = ResolveCameraBlurTarget();
            var effect = camera != null ? camera.GetComponent<GaussianSplatTiltShiftEffect>() : null;
            if (!force && m_HasObservedBlurCamera && camera == m_ObservedBlurCamera && effect == m_ObservedBlurEffect)
                return;
            m_HasObservedBlurCamera = true;
            m_ObservedBlurCamera = camera;
            m_ObservedBlurEffect = effect;
            if (effect != null)
                ReadCameraBlurSettings(effect);
            else if (camera != null)
                m_TiltShiftEnabled = false;
            PreviewCameraBlurSettings();
        }

        void ReadCameraBlurSettings(GaussianSplatTiltShiftEffect effect)
        {
            m_BlurMode = (int)effect.blurMode;
            m_TiltShiftEnabled = effect.effectEnabled;
            m_TiltShiftFocusPosition = effect.focusPosition;
            m_TiltShiftFocusWidth = effect.focusWidth;
            m_TiltShiftTopBlurOffset = effect.topBlurOffset;
            m_TiltShiftBottomBlurOffset = effect.bottomBlurOffset;
            m_TiltShiftTopBlurStrength = effect.topBlurStrength;
            m_TiltShiftBottomBlurStrength = effect.bottomBlurStrength;
            m_TiltShiftAngle = effect.tiltAngle;
            m_DoFFocusDistance = effect.focusDistance;
            m_DoFFocusRange = effect.focusRange;
            m_DoFNearBlur = effect.nearBlurStrength;
            m_DoFFarBlur = effect.farBlurStrength;
            m_TiltShiftBlurStrength = effect.blurStrength;
            m_TiltShiftBlurSamples = effect.blurSamples;
            m_TiltShiftBokehShape = effect.bokehShape;
            m_TiltShiftSaturation = effect.saturationBoost;
            m_TiltShiftContrast = effect.contrastBoost;
            m_TiltShiftVignette = effect.vignetteStrength;
            m_TiltShiftHighQuality = effect.highQualityBlur;
        }

        void WriteCameraBlurSettings(GaussianSplatTiltShiftEffect effect)
        {
            effect.blurMode = (GaussianSplatTiltShiftEffect.BlurMode)m_BlurMode;
            effect.effectEnabled = m_TiltShiftEnabled;
            effect.focusPosition = m_TiltShiftFocusPosition;
            effect.focusWidth = m_TiltShiftFocusWidth;
            effect.topBlurOffset = m_TiltShiftTopBlurOffset;
            effect.bottomBlurOffset = m_TiltShiftBottomBlurOffset;
            effect.topBlurStrength = m_TiltShiftTopBlurStrength;
            effect.bottomBlurStrength = m_TiltShiftBottomBlurStrength;
            effect.tiltAngle = m_TiltShiftAngle;
            effect.focusDistance = m_DoFFocusDistance;
            effect.focusRange = m_DoFFocusRange;
            effect.nearBlurStrength = m_DoFNearBlur;
            effect.farBlurStrength = m_DoFFarBlur;
            effect.blurStrength = m_TiltShiftBlurStrength;
            effect.blurSamples = m_TiltShiftBlurSamples;
            effect.bokehShape = m_TiltShiftBokehShape;
            effect.saturationBoost = m_TiltShiftSaturation;
            effect.contrastBoost = m_TiltShiftContrast;
            effect.vignetteStrength = m_TiltShiftVignette;
            effect.highQualityBlur = m_TiltShiftHighQuality;
        }

        void SaveCameraBlurSettings(Camera camera)
        {
            if (camera == null) return;
            var effect = camera.GetComponent<GaussianSplatTiltShiftEffect>();
            if (effect == null)
                effect = Undo.AddComponent<GaussianSplatTiltShiftEffect>(camera.gameObject);
            Undo.RecordObject(effect, "Change SplatBox Camera Blur");
            WriteCameraBlurSettings(effect);
            effect.authoredInSplatBoxEditor = true;
            // A runtime applier may have created a transient preview. Promote it to scene data.
            effect.hideFlags &= ~HideFlags.HideAndDontSave;
            EditorUtility.SetDirty(effect);
            PrefabUtility.RecordPrefabInstancePropertyModifications(effect);
            if (!Application.isPlaying && camera.gameObject.scene.IsValid())
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(camera.gameObject.scene);
            m_ObservedBlurCamera = camera;
            m_ObservedBlurEffect = effect;
            m_HasObservedBlurCamera = true;
        }

        void PreviewCameraBlurSettings()
        {
            foreach (SceneView view in SceneView.sceneViews)
            {
                if (view.camera == null) continue;
                var effect = view.camera.GetComponent<GaussianSplatTiltShiftEffect>();
                if (effect == null)
                {
                    if (!m_TiltShiftEnabled) continue;
                    effect = view.camera.gameObject.AddComponent<GaussianSplatTiltShiftEffect>();
                    effect.hideFlags = HideFlags.HideAndDontSave;
                }
                WriteCameraBlurSettings(effect);
                effect.authoredInSplatBoxEditor = true;
                view.Repaint();
            }
        }
    }
}
