// SPDX-License-Identifier: MIT

using System;
using System.Collections.Generic;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEngine;
using Change = GaussianSplatting.Runtime.SplatBoxRenderer.EditorSettingsChange;

namespace GaussianSplatting.Editor
{
    /// <summary>Keep the thumb local during a drag; publish costly settings after a short pause or release.</summary>
    sealed class SplatBoxSettingsSliderGUI : IDisposable
    {
        internal const double SettleSeconds = 0.15;

        internal sealed class PendingValue
        {
            public float value, applied;
            public double changedAt;
            public bool pending;

            public void Observe(float current)
            {
                // An external edit or Undo wins over a stale drag preview.
                if (!pending || current != applied)
                {
                    value = applied = current;
                    pending = false;
                }
            }

            public void Set(float next, double now)
            {
                if (next == value) return;
                value = next;
                changedAt = now;
                pending = value != applied;
            }

            public bool Ready(double now, bool dragging) => pending &&
                (!dragging || now - changedAt >= SettleSeconds);

            public void Commit() { applied = value; pending = false; }
        }

        sealed class Slider
        {
            public readonly PendingValue preview = new();
            public Change change;
        }

        readonly Dictionary<string, Slider> m_Sliders = new();
        readonly Action<SerializedObject> m_BeforeApply;
        SplatBoxRenderer m_Target;

        public SplatBoxSettingsSliderGUI(Action<SerializedObject> beforeApply = null)
        {
            m_BeforeApply = beforeApply;
            Undo.undoRedoPerformed += Discard;
        }

        public float Draw(SerializedProperty property, float min, float max, GUIContent label, Change change)
        {
            if (property.serializedObject.targetObjects.Length != 1)
            {
                if (property.propertyType == SerializedPropertyType.Integer)
                {
                    EditorGUILayout.IntSlider(property, (int)min, (int)max, label);
                    return property.intValue;
                }
                EditorGUILayout.Slider(property, min, max, label);
                return property.floatValue;
            }
            var renderer = property.serializedObject.targetObject as SplatBoxRenderer;
            if (m_Target != renderer)
            {
                Flush();
                m_Sliders.Clear();
                m_Target = renderer;
            }
            if (!m_Sliders.TryGetValue(property.propertyPath, out var slider))
                m_Sliders.Add(property.propertyPath, slider = new Slider());
            slider.change = change;
            var preview = slider.preview;
            bool integer = property.propertyType == SerializedPropertyType.Integer;
            preview.Observe(integer ? property.intValue : property.floatValue);
            double now = EditorApplication.timeSinceStartup;
            bool released = Event.current.rawType == EventType.MouseUp;
            var rect = EditorGUILayout.GetControlRect();
            EditorGUI.BeginProperty(rect, label, property);
            float next = integer
                ? EditorGUI.IntSlider(rect, label, (int)preview.value, (int)min, (int)max)
                : EditorGUI.Slider(rect, label, preview.value, min, max);
            EditorGUI.EndProperty();
            preview.Set(next, now);
            if (preview.Ready(now, !released && GUIUtility.hotControl != 0))
            {
                if (integer) property.intValue = (int)preview.value;
                else property.floatValue = preview.value;
                preview.Commit();
            }
            return preview.value;
        }

        public static bool Apply(SerializedObject serialized, Change change)
        {
            if (!serialized.hasModifiedProperties) return false;
            bool applied;
            if (serialized.targetObjects.Length == 1 && serialized.targetObject is SplatBoxRenderer renderer)
            {
                using (renderer.BeginEditorSettingsChange(change))
                    applied = serialized.ApplyModifiedProperties();
            }
            else applied = serialized.ApplyModifiedProperties();
            if (applied) SceneView.RepaintAll();
            return applied;
        }

        public void ApplyChanges(SerializedObject serialized, Change change)
        {
            if (serialized.hasModifiedProperties)
                m_BeforeApply?.Invoke(serialized);
            Apply(serialized, change);
        }

        // Focus loss, target changes and window closure must not lose the final value.
        public void Flush()
        {
            if (m_Target == null) return;
            using var serialized = new SerializedObject(m_Target);
            Change change = Change.Full;
            foreach (var pair in m_Sliders)
            {
                var preview = pair.Value.preview;
                if (!preview.pending) continue;
                var property = serialized.FindProperty(pair.Key);
                if (property == null) continue;
                bool integer = property.propertyType == SerializedPropertyType.Integer;
                preview.Observe(integer ? property.intValue : property.floatValue);
                if (!preview.pending) continue;
                if (integer) property.intValue = (int)preview.value;
                else property.floatValue = preview.value;
                preview.Commit();
                change |= pair.Value.change;
            }
            ApplyChanges(serialized, change);
        }

        void Discard() => m_Sliders.Clear();

        public void Dispose()
        {
            Flush();
            Undo.undoRedoPerformed -= Discard;
            m_Sliders.Clear();
        }
    }
}
