// SPDX-License-Identifier: MIT

using GaussianSplatting.Runtime;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        sealed class GeometryRotationState
        {
            public Quaternion start = Quaternion.identity;
            public Quaternion handle = Quaternion.identity;
        }

        // Each Scene view owns its drag basis: a repaint in another view must not reset it.
        readonly Dictionary<EntityId, GeometryRotationState> m_GeometryRotations = new Dictionary<EntityId, GeometryRotationState>();

        static bool IsGeometryTransformTool(Tool tool) => tool == Tool.Move || tool == Tool.Rotate ||
            tool == Tool.Scale || tool == Tool.Transform;

        static string GeometryToolName => Tools.current == Tool.Move ? "MOVE" :
            Tools.current == Tool.Rotate ? "ROTATE" : Tools.current == Tool.Scale ? "SCALE" :
            Tools.current == Tool.Transform ? "TRANSFORM" : "NAVIGATE";

        void DrawGeometryToolSelector()
        {
            GUILayout.Label("Transform gizmo", SplatEditorTheme.BoldLabel);
            GUILayout.BeginHorizontal();
            DrawGeometryToolButton("Move", Tool.Move);
            DrawGeometryToolButton("Rotate", Tool.Rotate);
            DrawGeometryToolButton(m_CylinderBrush.PrimitiveType == PrimitiveBrushType.Sphere ? "Radius" : "Scale", Tool.Scale);
            GUILayout.EndHorizontal();
            GUILayout.Space(8);
        }

        void DrawGeometryToolButton(string label, Tool tool)
        {
            if (GUILayout.Button(label, Tools.current == tool ? SplatEditorTheme.ActiveTab : SplatEditorTheme.Tab,
                GUILayout.Height(30), GUILayout.MinWidth(0), GUILayout.ExpandWidth(true)))
                m_AfterGuiAction = () => SelectGeometryTransformTool(tool);
        }

        void SelectGeometryTransformTool(Tool tool)
        {
            Tools.current = tool;
            if (!m_IsToolActive) ActivateCurrentTool();
            Repaint();
            SceneView.RepaintAll();
        }

        bool HandleGeometryToolShortcut(Event e)
        {
            if (e.type != EventType.KeyDown || e.alt || e.control || e.command || e.shift ||
                EditorGUIUtility.editingTextField)
                return false;
            Tool tool;
            switch (e.keyCode)
            {
                case KeyCode.Alpha1: tool = Tool.Move; break;
                case KeyCode.Alpha2: tool = Tool.Rotate; break;
                case KeyCode.Alpha3: tool = Tool.Scale; break;
                default: return false;
            }
            SelectGeometryTransformTool(tool);
            e.Use();
            return true;
        }

        // Cylinders retain one radial dimension; spheres retain one radius. Use the axis
        // actually dragged rather than averaging it with unchanged axes and damping the drag.
        static float RadiusFromGeometryScale(Vector3 before, Vector3 after, bool sphere)
        {
            int axis = 0;
            if (sphere && Mathf.Abs(after.y - before.y) > Mathf.Abs(after.x - before.x)) axis = 1;
            if (Mathf.Abs(after.z - before.z) > Mathf.Abs(after[axis] - before[axis])) axis = 2;
            return Mathf.Max(0.01f, after[axis] * 0.5f);
        }

        Quaternion DrawGeometryRotationHandle(Quaternion rotation, Vector3 position, SceneView sceneView)
        {
            if (Tools.pivotRotation == PivotRotation.Local)
                return Handles.RotationHandle(rotation, position);

            // Global axes start at identity. Retain the complete drag delta and apply it to
            // the original primitive rotation once, rather than compounding it each event.
            EntityId viewId = sceneView != null ? sceneView.GetEntityId() : EntityId.None;
            if (!m_GeometryRotations.TryGetValue(viewId, out var state))
                m_GeometryRotations.Add(viewId, state = new GeometryRotationState());
            if (GUIUtility.hotControl == 0)
            {
                state.start = rotation;
                state.handle = Quaternion.identity;
            }
            state.handle = Handles.RotationHandle(state.handle, position);
            return state.handle * state.start;
        }

        void DrawGeometryPrimitiveHandles(SceneView sceneView)
        {
            if (m_CylinderBrush == null || !IsGeometryTransformTool(Tools.current)) return;
            var brush = m_CylinderBrush;
            Vector3 position = brush.Position;
            Quaternion rotation = brush.Rotation;
            bool sphere = brush.PrimitiveType == PrimitiveBrushType.Sphere;
            bool box = brush.PrimitiveType == PrimitiveBrushType.Box;
            Vector3 dimensions = box ? brush.BoxSize : sphere ? Vector3.one * (brush.SphereRadius * 2f) :
                new Vector3(brush.Radius * 2f, brush.Height, brush.Radius * 2f);
            Vector3 scaled = dimensions;
            var oldColor = Handles.color;
            var oldDepth = Handles.zTest;
            var oldMatrix = Handles.matrix;
            try
            {
                Handles.matrix = Matrix4x4.identity;
                Handles.zTest = UnityEngine.Rendering.CompareFunction.Always;
                EditorGUI.BeginChangeCheck();
                switch (Tools.current)
                {
                    case Tool.Move:
                        position = Handles.PositionHandle(position,
                            Tools.pivotRotation == PivotRotation.Local ? rotation : Quaternion.identity);
                        break;
                    case Tool.Rotate:
                        rotation = DrawGeometryRotationHandle(rotation, position, sceneView);
                        break;
                    case Tool.Scale:
                        // Shape dimensions remain in primitive axes; global nonuniform scaling
                        // of rotated boxes/cylinders would require shear or an elliptical volume.
                        scaled = Handles.ScaleHandle(dimensions, position, rotation, HandleUtility.GetHandleSize(position));
                        break;
                    case Tool.Transform:
                        Handles.TransformHandle(ref position, ref rotation, ref scaled);
                        break;
                }
                if (!EditorGUI.EndChangeCheck()) return;

                Undo.RecordObject(brush, "Transform Geometry " + brush.PrimitiveType);
                brush.Position = position;
                brush.Rotation = rotation;
                if (box) brush.BoxSize = scaled;
                else if (sphere) brush.SphereRadius = RadiusFromGeometryScale(dimensions, scaled, true);
                else
                {
                    brush.Radius = RadiusFromGeometryScale(dimensions, scaled, false);
                    brush.Height = scaled.y;
                }
                PrefabUtility.RecordPrefabInstancePropertyModifications(brush);
                EditorUtility.SetDirty(brush);
                if (brush.gameObject.scene.IsValid() && brush.gameObject.scene.isLoaded)
                    EditorSceneManager.MarkSceneDirty(brush.gameObject.scene);
                Repaint();
                SceneView.RepaintAll();
            }
            finally
            {
                Handles.color = oldColor;
                Handles.zTest = oldDepth;
                Handles.matrix = oldMatrix;
            }
        }
    }
}
