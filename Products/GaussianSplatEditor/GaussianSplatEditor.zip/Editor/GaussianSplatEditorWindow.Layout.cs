// SPDX-License-Identifier: MIT

using UnityEditor;
using UnityEngine;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        enum WorkspacePanel { Output, Camera, Guide }

        [SerializeField] WorkspacePanel m_WorkspacePanel;
        [SerializeField] Vector2 m_RendererScroll;
        [SerializeField] Vector2 m_ToolScroll;
        [SerializeField] Vector2 m_UtilityScroll;
        [SerializeField] bool m_ShowLightingWorkspace;
        [SerializeField] bool m_ShowAndroidSettings;
        [SerializeField] bool m_ShowColorSettings;
        [SerializeField] bool m_ShowOtherRendererSettings;
        UnityEditor.Editor m_RendererSettingsEditor;
        SplatBoxSettingsSliderGUI m_LodSettingsSliders;
        SerializedObject m_LodSettingsSerialized;
        Vector2 m_WorkspaceScroll;
        Vector2 m_ToolbarScroll;
        System.Action m_AfterGuiAction;
        static GUIStyle s_TileLabelStyle;
        static GUIStyle s_EmptyTitleStyle;
        static GUIStyle s_EmptyTextStyle;
        int m_WorkspaceLayoutState;
        bool m_HasWorkspaceLayoutState;
        const float kWorkspaceMinWidth = 1100f;
        static readonly string[] s_HelpTopicNames =
        {
            "Erase", "Xcopy", "Clone", "Floor fill", "Patch", "Polygon mask", "Color",
            "Vortex", "Fill", "Paint", "Texture stamp", "Sculpt", "Geometry", "Colorize", "Animation", "Camera effects"
        };

        void DrawHorizontalWorkspace()
        {
            if (Event.current.type == EventType.Layout && m_CurrentTool == BrushTool.FillBrush &&
                m_ShowToolSettings && m_FillBrush == null)
                CreateToolGameObject(BrushTool.FillBrush);
            if (Event.current.type == EventType.Layout && m_CurrentTool == BrushTool.PaintBrush &&
                m_ShowToolSettings && m_PaintBrush == null)
                CreateToolGameObject(BrushTool.PaintBrush);
            if (Event.current.type == EventType.Layout && m_ShowToolSettings && m_ColorizeBrush == null &&
                (m_CurrentTool == BrushTool.ColorizeBrush || m_CurrentTool == BrushTool.PaintBrush && m_PaintBrushMode == 1))
                CreateToolGameObject(BrushTool.ColorizeBrush);
            // Scene-view shortcuts can switch tools between the Layout and Repaint events.
            // Abort a stale event before opening any GUILayout groups and request a fresh layout.
            int layoutState = (int)m_CurrentTool * 397 + (m_ShowLightingWorkspace ? 1 : 0);
            layoutState = layoutState * 397 + (int)m_WorkspacePanel;
            layoutState = layoutState * 397 + (m_ShowToolSettings ? 1 : 0);
            layoutState = layoutState * 397 + (m_TargetRenderer != null && m_TargetRenderer.UsesPagedLod ? 1 : 0);
            if (m_CurrentTool == BrushTool.CloneBrush) layoutState = layoutState * 397 + (m_CloneBrush != null ? 1 : 0);
            if (m_CurrentTool == BrushTool.PolyMask) layoutState = layoutState * 397 + (m_PolyMask != null ? (int)m_PolyMask.m_ShapeType + 1 : 0);
            if (m_CurrentTool == BrushTool.FillBrush)
            {
                layoutState = layoutState * 397 + (m_FillBrush != null ? 1 : 0);
                layoutState = layoutState * 397 + (m_FillBrush != null && m_FillBrush.IsClosed ? 1 : 0);
                layoutState = layoutState * 397 + (m_FillBrush != null && m_FillBrush.IsDrawing ? 1 : 0);
                layoutState = layoutState * 397 + (m_PagedFillStatus?.GetHashCode() ?? 0);
            }
            if (m_CurrentTool == BrushTool.PaintBrush)
            {
                layoutState = layoutState * 397 + m_PaintBrushMode;
                layoutState = layoutState * 397 + (m_PaintBrush != null ? 1 : 0);
                layoutState = layoutState * 397 + (m_PaintOutputStatus?.GetHashCode() ?? 0);
                layoutState = layoutState * 397 + (m_TargetRenderer != null && m_TargetRenderer.SupportsInPlacePaint ? 1 : 0);
                if (m_PaintBrush != null)
                {
                    layoutState = layoutState * 397 + (m_PaintBrush.UseGPUPaint ? 1 : 0);
                    layoutState = layoutState * 397 + (m_PaintBrush.FastPaintMode ? 1 : 0);
                    layoutState = layoutState * 397 + (m_PaintBrush.EnableLayering ? 1 : 0);
                    layoutState = layoutState * 397 + (m_PaintBrush.UseCustomColor ? 1 : 0);
                    layoutState = layoutState * 397 + (m_PaintBrush.HasSampledColors ? 1 : 0);
                    layoutState = layoutState * 397 + (m_PaintBrush.UseTexturePaint ? 1 : 0);
                    layoutState = layoutState * 397 + m_PaintBrush.ActiveTextureSlot;
                    layoutState = layoutState * 397 + (m_PaintBrush.GetTextureSlot(m_PaintBrush.ActiveTextureSlot) != null ? 1 : 0);
                    layoutState = layoutState * 397 + (m_IsCapturingRect ? 1 : 0);
                }
            }
            if (m_CurrentTool == BrushTool.ColorizeBrush || m_CurrentTool == BrushTool.PaintBrush && m_PaintBrushMode == 1)
            {
                layoutState = layoutState * 397 + (m_ColorizeBrush != null ? 1 : 0);
                layoutState = layoutState * 397 + (m_ColorizeBrush != null && m_ColorizeBrush.UseNoise ? 1 : 0);
            }
            if (Event.current.type == EventType.Layout)
            {
                m_WorkspaceLayoutState = layoutState;
                m_HasWorkspaceLayoutState = true;
            }
            else if (m_HasWorkspaceLayoutState && layoutState != m_WorkspaceLayoutState)
            {
                Repaint();
                GUIUtility.ExitGUI();
            }
            var previousSkin = GUI.skin;
            var previousColor = GUI.color;
            var previousBackground = GUI.backgroundColor;
            var previousContent = GUI.contentColor;
            var previousIconSize = EditorGUIUtility.GetIconSize();
            float previousLabelWidth = EditorGUIUtility.labelWidth;
            float previousFieldWidth = EditorGUIUtility.fieldWidth;
            bool previousWideMode = EditorGUIUtility.wideMode;
            bool previousEnabled = GUI.enabled;
            int previousIndent = EditorGUI.indentLevel;
            try
            {
                InitStyles();
                var tabIcon = SplatEditorTheme.GetIcon(SplatEditorTheme.Icon.Splat);
                if (titleContent.image != tabIcon)
                    titleContent = new GUIContent("Splat Editor", tabIcon);
                GUI.skin = SplatEditorTheme.Skin;
                GUI.color = GUI.backgroundColor = GUI.contentColor = Color.white;
                EditorGUIUtility.SetIconSize(new Vector2(18, 18));
                EditorGUIUtility.wideMode = true;
                EditorGUIUtility.fieldWidth = 52f;
                EditorGUI.indentLevel = 0;

                EditorGUI.DrawRect(new Rect(0, 0, position.width, position.height), SplatEditorTheme.Background);
                DrawWorkspaceHeader();
                DrawWorkspaceToolStrip();

                var viewport = new Rect(0, 150, position.width, Mathf.Max(100, position.height - 180));
                float width = Mathf.Max(kWorkspaceMinWidth, viewport.width);
                float height = viewport.height - (width > viewport.width ? 18 : 0);
                m_WorkspaceScroll = GUI.BeginScrollView(viewport, m_WorkspaceScroll,
                    new Rect(0, 0, width, height), false, false);
                const float leftWidth = 300f;
                const float rightWidth = 334f;
                const float gap = 12f;
                float centerWidth = width - leftWidth - rightWidth - gap * 4;
                DrawRendererPanel(new Rect(gap, 8, leftWidth, height - 16));
                DrawEditingPanel(new Rect(leftWidth + gap * 2, 8, centerWidth, height - 16));
                DrawUtilityPanel(new Rect(width - rightWidth - gap, 8, rightWidth, height - 16));
                GUI.EndScrollView();
                DrawWorkspaceStatusBar(new Rect(0, position.height - 30, position.width, 30));
                // Switch panel contents only after all layout/scroll groups have closed.
                if (m_AfterGuiAction != null)
                {
                    var action = m_AfterGuiAction;
                    m_AfterGuiAction = null;
                    action();
                    Repaint();
                    GUIUtility.ExitGUI();
                }
                HandleKeyboardShortcuts();
            }
            finally
            {
                GUI.skin = previousSkin;
                GUI.color = previousColor;
                GUI.backgroundColor = previousBackground;
                GUI.contentColor = previousContent;
                GUI.enabled = previousEnabled;
                EditorGUIUtility.SetIconSize(previousIconSize);
                EditorGUIUtility.labelWidth = previousLabelWidth;
                EditorGUIUtility.fieldWidth = previousFieldWidth;
                EditorGUIUtility.wideMode = previousWideMode;
                EditorGUI.indentLevel = previousIndent;
            }
        }

        void DrawWorkspaceHeader()
        {
            EditorGUI.DrawRect(new Rect(0, 0, position.width, 64), SplatEditorTheme.Surface);
            EditorGUI.DrawRect(new Rect(0, 63, position.width, 1), SplatEditorTheme.Border);
            GUI.DrawTexture(new Rect(18, 18, 28, 28), SplatEditorTheme.GetIcon(SplatEditorTheme.Icon.Splat));
            GUI.Label(new Rect(54, 8, 132, 29), "SPLATBOX", SplatEditorTheme.Title);
            GUI.Label(new Rect(190, 12, 56, 23), SplatBoxReleaseInfo.VersionBadge, SplatEditorTheme.Badge);
            GUI.Label(new Rect(56, 35, 342, 20), SplatBoxReleaseInfo.ReleaseLabel, SplatEditorTheme.Subtitle);

            float x = position.width - 16;
            if (HeaderAction(ref x, 114, m_IsToolActive ? "Stop tool" : "Start tool",
                m_IsToolActive ? SplatEditorTheme.Icon.Stop : SplatEditorTheme.Icon.Play,
                "Start or stop the selected editing tool. Escape stops an active tool.",
                m_CurrentTool != BrushTool.None && !m_ShowLightingWorkspace, true))
            {
                if (m_IsToolActive) DeactivateCurrentTool();
                else ActivateCurrentTool();
            }
            if (HeaderAction(ref x, 98, "Import", SplatEditorTheme.Icon.Add,
                "Open the PLY / SPZ importer"))
                m_AfterGuiAction = GaussianPlyImporterWindow.ShowImporter;
            if (IsRelightPluginInstalled())
            {
                if (HeaderAction(ref x, 96, "Lighting", SplatEditorTheme.Icon.Relight,
                    "Add and edit Relight lights in this window", true, m_ShowLightingWorkspace))
                    m_AfterGuiAction = OpenLightingWorkspace;
                bool relight = GetSelectedRelightMode();
                if (HeaderAction(ref x, 112, relight ? "Relight on" : "Relight off", SplatEditorTheme.Icon.Relight,
                    "Switch between the Relight and standard splat shaders", true, relight))
                {
                    m_AfterGuiAction = () =>
                    {
                        EditorPrefs.SetBool("SplatBox.Relight.UseRelight", !relight);
                        if (m_TargetRenderer != null)
                        {
                            if (relight) ApplyDefaultShaderToRenderer(m_TargetRenderer);
                            else ApplyRelightShaderToRenderer(m_TargetRenderer);
                        }
                    };
                }
            }
        }

        bool HeaderAction(ref float right, float width, string label, SplatEditorTheme.Icon icon,
            string tooltip, bool enabled = true, bool primary = false)
        {
            right -= width;
            bool clicked;
            using (new EditorGUI.DisabledScope(!enabled))
                clicked = GUI.Button(new Rect(right, 17, width, 32), SplatEditorTheme.Content(label, icon, tooltip),
                    primary ? SplatEditorTheme.PrimaryButton : SplatEditorTheme.Button);
            right -= 8;
            return clicked;
        }

        void DrawWorkspaceToolStrip()
        {
            float contentWidth = 11 * 78 + 2 * 12 + 24;
            var viewport = new Rect(0, 64, position.width, 86);
            m_ToolbarScroll = GUI.BeginScrollView(viewport, m_ToolbarScroll,
                new Rect(0, 0, Mathf.Max(viewport.width, contentWidth), viewport.width < contentWidth ? 68 : 86), false, false);
            float x = 12;
            DrawToolTile(ref x, "Erase", BrushTool.EraseBrush, SplatEditorTheme.Icon.Erase, "Delete or restore splats with a spherical brush", "1");
            DrawToolTile(ref x, "Geometry", BrushTool.CylinderBrush, SplatEditorTheme.Icon.Geometry, "Erase with cylinder or box primitives", "G");
            DrawToolTile(ref x, "Xcopy", BrushTool.BoxBrush, SplatEditorTheme.Icon.Copy, "Copy, paste and delete splat selections", "2");
            DrawToolTile(ref x, "Clone", BrushTool.CloneBrush, SplatEditorTheme.Icon.Clone, "Clone splats from a polygon source", "3");
            DrawToolTile(ref x, "Mask", BrushTool.PolyMask, SplatEditorTheme.Icon.Mask, "Cut out splats with a polygon mask", "5");
            DrawToolDivider(ref x);
            DrawToolTile(ref x, "Fill", BrushTool.FillBrush, SplatEditorTheme.Icon.Fill, "Draw a polygon and fill it with splats", "8");
            DrawToolTile(ref x, "Paint", BrushTool.PaintBrush, SplatEditorTheme.Icon.Paint, "Paint splats, colorize or paint animation", "9");
            DrawToolTile(ref x, "Color", BrushTool.ColorBrush, SplatEditorTheme.Icon.Color, "Adjust splat colors in a selected region", "6");
            DrawToolTile(ref x, "Stamp", BrushTool.TextureStamp, SplatEditorTheme.Icon.Stamp, "Stamp a texture onto splats", "0");
            DrawToolDivider(ref x);
            DrawToolTile(ref x, "Sculpt", BrushTool.SculptBrush, SplatEditorTheme.Icon.Sculpt, "Smudge, pinch, move, flatten and relax splats", "S");
            DrawToolTile(ref x, "Vortex", BrushTool.VortexTool, SplatEditorTheme.Icon.Vortex, "Apply an animated attractor effect", "7");
            GUI.EndScrollView();
        }

        void DrawToolDivider(ref float x)
        {
            EditorGUI.DrawRect(new Rect(x + 4, 18, 1, 36), SplatEditorTheme.Border);
            x += 12;
        }

        void DrawToolTile(ref float x, string label, BrushTool tool, SplatEditorTheme.Icon icon, string tooltip, string shortcut = "")
        {
            var rect = new Rect(x, 8, 74, 60);
            bool selected = !m_ShowLightingWorkspace && m_CurrentTool == tool;
            if (!string.IsNullOrEmpty(shortcut))
                tooltip += "\nShortcut: " + shortcut + " (Editor or Scene View). Press again to start/stop.";
            if (GUI.Button(rect, new GUIContent("", tooltip), SplatEditorTheme.GetToolButtonStyle(icon, selected)))
            {
                m_AfterGuiAction = () =>
                {
                    DeactivateCurrentTool();
                    m_ShowLightingWorkspace = false;
                    if (selected) m_CurrentTool = BrushTool.None;
                    else
                    {
                        m_CurrentTool = tool;
                        m_ShowToolSettings = true;
                        m_ToolScroll = Vector2.zero;
                        if (tool == BrushTool.BoxBrush && m_BoxBrush != null) m_BoxBrush.ResetAll();
                        if (tool == BrushTool.ColorBrush && m_ColorBrush != null)
                        {
                            m_ColorBrush.BoxSize = Vector3.one;
                            m_ColorBrush.BoxPosition = Vector3.zero;
                            m_ColorBrush.ResetColorAdjustments();
                        }
                    }
                    GUI.FocusControl(null);
                };
            }
            GUI.DrawTexture(new Rect(rect.center.x - 11, rect.y + 8, 22, 22), SplatEditorTheme.GetIcon(icon));
            GUI.Label(new Rect(rect.x, rect.y + 33, rect.width, 20), label, s_TileLabelStyle);
            if (selected)
                EditorGUI.DrawRect(new Rect(rect.x + 10, rect.yMax - 3, rect.width - 20, 2), SplatEditorTheme.GetIconColor(icon));
            if (!string.IsNullOrEmpty(shortcut))
                GUI.Label(new Rect(rect.xMax - 13, rect.y + 3, 11, 13), shortcut, SplatEditorTheme.Subtitle);
            x += 78;
        }

        void BeginWorkspacePanel(Rect rect, string heading, string subtitle, SplatEditorTheme.Icon icon)
        {
            GUILayout.BeginArea(rect, SplatEditorTheme.Panel);
            EditorGUIUtility.labelWidth = Mathf.Clamp((rect.width - 36) * 0.45f, 105, 165);
            GUILayout.Label(SplatEditorTheme.Content(heading, icon), SplatEditorTheme.Header, GUILayout.Height(26));
            GUILayout.Label(subtitle, SplatEditorTheme.Subtitle);
            GUILayout.Space(10);
        }

        void DrawRendererPanel(Rect rect)
        {
            BeginWorkspacePanel(rect, "Scene", "SOURCE / QUALITY / STREAMING", SplatEditorTheme.Icon.Splat);
            m_RendererScroll = GUILayout.BeginScrollView(m_RendererScroll, false, false);
            DrawRendererSection();
            GUILayout.Space(12);
            DrawQuickActions();
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        void DrawRendererSettingsSections(SplatBoxRenderer renderer)
        {
            UnityEditor.Editor.CreateCachedEditor(renderer, typeof(GaussianSplatRendererEditor),
                ref m_RendererSettingsEditor);
            var settings = m_RendererSettingsEditor as GaussianSplatRendererEditor;
            if (settings == null) return;

            GUILayout.Space(8);
            m_ShowColorSettings = EditorGUILayout.Foldout(m_ShowColorSettings, "Color Adjustments", true);
            if (m_ShowColorSettings)
                settings.DrawColorSettings();

            m_ShowAndroidSettings = EditorGUILayout.Foldout(m_ShowAndroidSettings, "Android Advanced", true);
            if (m_ShowAndroidSettings)
                settings.DrawAndroidSettings();

            m_ShowOtherRendererSettings = EditorGUILayout.Foldout(m_ShowOtherRendererSettings,
                "Other Renderer Settings", true);
            if (m_ShowOtherRendererSettings)
                settings.DrawSettingsGUI();
        }

        void DrawEditingPanel(Rect rect)
        {
            BeginWorkspacePanel(rect, m_ShowLightingWorkspace ? "Lighting" : "Tool settings",
                m_ShowLightingWorkspace ? "RELIGHT / LIGHTS / PREVIEW" : m_CurrentTool == BrushTool.None
                    ? "SELECT A TOOL TO BEGIN" : ToolDisplayName(m_CurrentTool).ToUpperInvariant(),
                m_ShowLightingWorkspace ? SplatEditorTheme.Icon.Relight : SplatEditorTheme.Icon.Settings);
            if (IsRelightPluginInstalled())
            {
                GUILayout.BeginHorizontal();
                if (GUILayout.Button(SplatEditorTheme.Content("Tools", SplatEditorTheme.Icon.Settings),
                    m_ShowLightingWorkspace ? SplatEditorTheme.Tab : SplatEditorTheme.ActiveTab, GUILayout.Height(30)))
                    m_AfterGuiAction = () => { m_ShowLightingWorkspace = false; m_ToolScroll = Vector2.zero; };
                if (GUILayout.Button(SplatEditorTheme.Content("Lighting", SplatEditorTheme.Icon.Relight),
                    m_ShowLightingWorkspace ? SplatEditorTheme.ActiveTab : SplatEditorTheme.Tab, GUILayout.Height(30)))
                    m_AfterGuiAction = OpenLightingWorkspace;
                GUILayout.EndHorizontal();
                GUILayout.Space(10);
            }
            m_ToolScroll = GUILayout.BeginScrollView(m_ToolScroll, false, false);
            if (m_ShowLightingWorkspace)
                DrawRelightWorkspace();
            else if (m_CurrentTool == BrushTool.None)
                DrawToolEmptyState();
            else
                DrawToolSettings();
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        void DrawToolEmptyState()
        {
            GUILayout.Space(32);
            var iconRect = GUILayoutUtility.GetRect(52, 52, GUILayout.ExpandWidth(true));
            GUI.DrawTexture(new Rect(iconRect.center.x - 24, iconRect.y, 48, 48), SplatEditorTheme.GetIcon(SplatEditorTheme.Icon.Sculpt));
            GUILayout.Space(16);
            GUILayout.Label("Choose a tool to get started", s_EmptyTitleStyle);
            GUILayout.Space(8);
            GUILayout.Label("Choose a tool from the strip above to edit, paint or sculpt your splats.\n\nYour brush settings and scene controls stay side by side.", s_EmptyTextStyle);
            GUILayout.Space(24);
            if (GUILayout.Button(SplatEditorTheme.Content("Start with Erase", SplatEditorTheme.Icon.Erase,
                "Select the Erase brush. Start tool enables editing in the Scene view."), SplatEditorTheme.Button, GUILayout.Height(34)))
            {
                m_AfterGuiAction = () =>
                {
                    m_CurrentTool = BrushTool.EraseBrush;
                    m_ShowToolSettings = true;
                };
            }
        }

        void DrawUtilityPanel(Rect rect)
        {
            BeginWorkspacePanel(rect, "Workspace", "OUTPUT / CAMERA / REFERENCE", SplatEditorTheme.Icon.Export);
            GUILayout.BeginHorizontal();
            DrawWorkspaceTab("Output", WorkspacePanel.Output, SplatEditorTheme.Icon.Export);
            DrawWorkspaceTab("Camera", WorkspacePanel.Camera, SplatEditorTheme.Icon.Camera);
            DrawWorkspaceTab("Guide", WorkspacePanel.Guide, SplatEditorTheme.Icon.Help);
            GUILayout.EndHorizontal();
            GUILayout.Space(10);
            m_UtilityScroll = GUILayout.BeginScrollView(m_UtilityScroll, false, false);
            switch (m_WorkspacePanel)
            {
                case WorkspacePanel.Output: DrawExportSection(); break;
                case WorkspacePanel.Camera: DrawTiltShiftSection(); break;
                case WorkspacePanel.Guide: DrawHelpSection(); break;
            }
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }

        void DrawWorkspaceTab(string label, WorkspacePanel panel, SplatEditorTheme.Icon icon)
        {
            if (GUILayout.Button(SplatEditorTheme.Content(label, icon), m_WorkspacePanel == panel
                    ? SplatEditorTheme.ActiveTab : SplatEditorTheme.Tab, GUILayout.Height(30)))
            {
                m_AfterGuiAction = () =>
                {
                    m_WorkspacePanel = panel;
                    m_UtilityScroll = Vector2.zero;
                    if (panel == WorkspacePanel.Camera) m_ShowTiltShift = true;
                    GUI.FocusControl(null);
                };
            }
        }

        void DrawWorkspaceStatusBar(Rect rect)
        {
            EditorGUI.DrawRect(rect, SplatEditorTheme.Surface);
            EditorGUI.DrawRect(new Rect(rect.x, rect.y, rect.width, 1), SplatEditorTheme.Border);
            string status = "Ready to edit";
            Color color = SplatEditorTheme.Success;
            if (m_ShowLightingWorkspace)
                status = m_SelectedRelightLight != null ? m_SelectedRelightLight.name + " selected" : "Lighting / add a light to begin";
            else if (m_TargetRenderer == null) { status = "Select a renderer to begin"; color = SplatEditorTheme.Warning; }
            else if (!m_TargetRenderer.HasValidAsset) { status = "Renderer needs a splat asset"; color = SplatEditorTheme.Warning; }
            else if (m_IsToolActive) { status = ToolDisplayName(m_CurrentTool) + " active  /  Esc to stop"; color = SplatEditorTheme.Accent; }
            else if (m_CurrentTool != BrushTool.None) status = ToolDisplayName(m_CurrentTool) + " selected  /  Start tool to edit";
            EditorGUI.DrawRect(new Rect(16, rect.y + 12, 6, 6), color);
            GUI.Label(new Rect(30, rect.y + 5, rect.width - 320, 20), status, SplatEditorTheme.MutedLabel);
            var shortcutStyle = SplatEditorTheme.Subtitle;
            GUI.Label(new Rect(rect.width - 270, rect.y + 5, 260, 20), m_ShowLightingWorkspace
                ? "Move / rotate lights in the Scene view" : "1–0 / G / S  Tools     /     Esc  Stop", shortcutStyle);
        }

        static void DrawWorkspaceLodStats(SplatBoxRenderer renderer)
        {
            GUILayout.Space(6);
            DrawLodMetric("Source splats", renderer.pagedSceneLeafCount.ToString("N0"));
            DrawLodMetric("All LoD nodes", renderer.pagedSceneSplatCount.ToString("N0"));
            DrawLodMetric("Active splats", renderer.activeSplatCount.ToString("N0"));
            DrawLodMetric("Splat budget", renderer.EffectiveLodBudget.ToString("N0"));
            var meter = GUILayoutUtility.GetRect(0, 4, GUILayout.ExpandWidth(true));
            EditorGUI.DrawRect(meter, SplatEditorTheme.SurfaceRaised);
            float used = Mathf.Clamp01((float)renderer.activeSplatCount / Mathf.Max(1, renderer.EffectiveLodBudget));
            EditorGUI.DrawRect(new Rect(meter.x, meter.y, meter.width * used, meter.height),
                used > 0.98f ? SplatEditorTheme.Warning : SplatEditorTheme.Accent);
            GUILayout.Space(6);
            int loaded = renderer.lodStreamer != null ? renderer.lodStreamer.loadedPages.Count : 0;
            int total = renderer.pagedScene != null ? renderer.pagedScene.pageCount : 0;
            DrawLodMetric("Resident pages", $"{loaded} / {total}");
            DrawLodMetric("Full-detail pages", renderer.detailPageCount.ToString());
            DrawLodMetric("Detail cutoff", $"{renderer.currentLodPixelScaleLimit:0.0} px");
            GUILayout.Space(8);
            GUILayout.Label("SELECTION", SplatEditorTheme.Subtitle);
            DrawLodMetric("Leaves", renderer.lastLodLeafCount.ToString("N0"));
            DrawLodMetric("Merged", renderer.lastLodMergedCount.ToString("N0"));
            DrawLodMetric("Dropped", renderer.lastLodMergedDropCount.ToString("N0"));
            GUILayout.Space(8);
            GUILayout.Label(renderer.usesBurstLodTraversal ? "CPU TIMING / BURST" : "CPU TIMING / MANAGED", SplatEditorTheme.Subtitle);
            DrawLodMetric("Main thread", $"{renderer.lastLodSelectMs:0.0} ms");
            DrawLodMetric("Worker", $"{renderer.lastLodWorkerMs:0.0} ms");
            DrawLodMetric("Atlas update", $"{renderer.lastLodAtlasMs:0.0} ms");
            GUILayout.Space(8);
        }

        SerializedObject GetLodSettingsSerialized(SplatBoxRenderer renderer)
        {
            if (m_LodSettingsSerialized == null || m_LodSettingsSerialized.targetObject != renderer)
            {
                m_LodSettingsSliders?.Flush();
                m_LodSettingsSerialized?.Dispose();
                m_LodSettingsSerialized = new SerializedObject(renderer);
            }
            m_LodSettingsSerialized.UpdateIfRequiredOrScript();
            return m_LodSettingsSerialized;
        }

        void DrawWorkspaceLodQuality(SplatBoxRenderer renderer)
        {
            var serialized = GetLodSettingsSerialized(renderer);
            var quality = serialized.FindProperty(SplatBoxRenderer.kPropLodQuality);
            var distance = serialized.FindProperty(SplatBoxRenderer.kPropLodDetailDistance);
            if (quality == null) return;
            float oldDistance = distance?.floatValue ?? 0f;
            GUILayout.Label(SplatBoxLodQualityGUI.qualitySliderLabel, SplatEditorTheme.Label);
            m_LodSettingsSliders ??= new SplatBoxSettingsSliderGUI();
            const SplatBoxRenderer.EditorSettingsChange selection = SplatBoxRenderer.EditorSettingsChange.LodSelection;
            var qualityPreview = m_LodSettingsSliders.Draw(quality, 0f, 1f, GUIContent.none, selection);
            GUILayout.Label(SplatBoxLodQualityGUI.QualitySummary(qualityPreview), SplatEditorTheme.WrappedMiniLabel);
            if (distance != null)
            {
                GUILayout.Label(new GUIContent("Detail distance (m)",
                    "Distance from the camera that receives additional detail."), SplatEditorTheme.Label);
                m_LodSettingsSliders.Draw(distance, 2f, 32f, GUIContent.none,
                    selection | SplatBoxRenderer.EditorSettingsChange.Atlas | SplatBoxRenderer.EditorSettingsChange.View);
            }
            var changes = selection;
            if (distance != null && distance.floatValue != oldDistance)
                changes |= SplatBoxRenderer.EditorSettingsChange.Atlas | SplatBoxRenderer.EditorSettingsChange.View;
            SplatBoxSettingsSliderGUI.Apply(serialized, changes);
        }

        static void DrawLodMetric(string label, string value)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, SplatEditorTheme.MutedLabel);
            GUILayout.FlexibleSpace();
            GUILayout.Label(value, SplatEditorTheme.Label);
            GUILayout.EndHorizontal();
        }

        static string ToolDisplayName(BrushTool tool)
        {
            switch (tool)
            {
                case BrushTool.EraseBrush: return "Erase";
                case BrushTool.BoxBrush: return "Xcopy";
                case BrushTool.CloneBrush: return "Clone";
                case BrushTool.FloorFill: return "Floor fill";
                case BrushTool.PatchTool: return "Patch";
                case BrushTool.PolyMask: return "Polygon mask";
                case BrushTool.ColorBrush: return "Color";
                case BrushTool.VortexTool: return "Vortex";
                case BrushTool.FillBrush: return "Fill";
                case BrushTool.PaintBrush: return "Paint";
                case BrushTool.CylinderBrush: return "Geometry";
                case BrushTool.TextureStamp: return "Texture stamp";
                case BrushTool.SculptBrush: return "Sculpt";
                case BrushTool.ColorizeBrush: return "Colorize";
                default: return "No tool selected";
            }
        }
    }
}
