// SPDX-License-Identifier: MIT

using UnityEditor;
using UnityEngine;

namespace GaussianSplatting.Relight.Editor
{
    // Keep the optional add-on's entry point and saved layouts compatible with previous versions.
    public class RelightEditorWindow : EditorWindow
    {
        [MenuItem("SplatToolbox/Relight/Relight Editor", false, 120)]
        public static void ShowWindow() => GaussianSplatting.Editor.GaussianSplatEditorWindow.ShowLightingWindow();

        void OnGUI()
        {
            GUILayout.Space(12);
            GUILayout.Label("Lighting is now in Splat Editor", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Add Point, Spot, Directional and Planar lights, and edit their settings together in the Lighting panel.", MessageType.Info);
            if (GUILayout.Button("Open Splat Editor lighting", GUILayout.Height(34)))
            {
                ShowWindow();
                Close();
                GUIUtility.ExitGUI();
            }
        }
    }
}
