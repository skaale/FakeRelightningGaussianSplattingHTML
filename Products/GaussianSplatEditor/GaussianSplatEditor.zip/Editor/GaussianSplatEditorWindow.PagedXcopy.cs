// SPDX-License-Identifier: MIT
using System;
using System.Collections.Generic;
using GaussianSplatting.Runtime;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace GaussianSplatting.Editor
{
    public partial class GaussianSplatEditorWindow
    {
        SplatBoxRenderer m_PagedCopySource;
        Vector3 m_PagedCopyCenter, m_PagedCopySize;
        Quaternion m_PagedCopyRotation;
        GaussianSplatPageEntry[] m_PagedCopyPages;
        GaussianSplatPagedScene m_PagedCopyManifest;
        Matrix4x4 m_PagedCopySourceMatrix;
        string m_PagedCopyRendererJson;
        string m_PagedCopyMessage;
        [SerializeField] bool m_EraseIncludePagedCopies = true;

        bool CanPastePagedXcopy => m_PagedCopySource != null && m_PagedCopySource == m_TargetRenderer &&
            m_PagedCopySource.UsesPagedLod && m_PagedCopySource.pagedScene == m_PagedCopyManifest &&
            m_PagedCopyPages != null && m_PagedCopyPages.Length > 0;

        void DrawPagedXcopySettings()
        {
            if (m_BoxBrush.BrushMode != BoxBrushMode.Box3D)
                m_BoxBrush.BrushMode = BoxBrushMode.Box3D;
            GUILayout.Label("PAGED LOD / BOX XCOPY", SplatEditorTheme.Subtitle);
            EditorGUILayout.HelpBox("Copy the box, move it to the destination, then paste. This creates a separate LoD object and an asset in Assets/SplatBoxXcopy. Copies use additional GPU memory. Coarse detail near the box edge is approximate.", MessageType.Info);
            EditorGUI.BeginChangeCheck();
            Vector3 position = EditorGUILayout.Vector3Field("Box Position", m_BoxBrush.BoxPosition);
            Vector3 size = EditorGUILayout.Vector3Field("Box Size", m_BoxBrush.BoxSize);
            Vector3 rotation = EditorGUILayout.Vector3Field("Box Rotation", m_BoxBrush.BoxRotation);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(m_BoxBrush, "Edit Xcopy box");
                m_BoxBrush.BoxPosition = position;
                m_BoxBrush.BoxSize = size;
                m_BoxBrush.BoxRotation = rotation;
                EditorUtility.SetDirty(m_BoxBrush);
            }
            m_BoxBrush.BoxColor = EditorGUILayout.ColorField("Box Color", m_BoxBrush.BoxColor);
            m_BoxBrush.BoxAlpha = EditorGUILayout.Slider("Transparency", m_BoxBrush.BoxAlpha, 0.05f, 0.5f);
            if (!string.IsNullOrEmpty(m_PagedCopyMessage)) EditorGUILayout.HelpBox(m_PagedCopyMessage, MessageType.Info);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Copy pages", GUILayout.Height(28))) m_AfterGuiAction = CopyPagedXcopy;
            using (new EditorGUI.DisabledScope(!CanPastePagedXcopy))
                if (GUILayout.Button("Paste LoD object", GUILayout.Height(28))) m_AfterGuiAction = PastePagedXcopy;
            if (GUILayout.Button("Delete in box", GUILayout.Height(28))) m_AfterGuiAction = m_BoxBrush.DeleteSplatsInBox;
            GUILayout.EndHorizontal();
            if (GUILayout.Button("Clear copied area", GUILayout.Height(28))) m_AfterGuiAction = ClearPagedXcopy;
            DrawToolControls("C = Copy pages | V = Paste LoD object | Del = Delete | 1/2/3 = Transform box");
        }

        void ClearPagedXcopy()
        {
            m_PagedCopySource = null;
            m_PagedCopyPages = null;
            m_PagedCopyManifest = null;
            m_PagedCopyRendererJson = null;
            m_PagedCopyMessage = null;
        }

        void CopyPagedXcopy()
        {
            ClearPagedXcopy();
            var source = m_TargetRenderer;
            if (source == null || !source.UsesPagedLod || m_BoxBrush == null) return;
            if (source.m_Cutouts != null && Array.Exists(source.m_Cutouts, cutout => cutout != null && cutout.isActiveAndEnabled))
            {
                m_PagedCopyMessage = "Paged Xcopy cannot yet copy a renderer with active cutouts.";
                return;
            }
            var worldToBox = Matrix4x4.TRS(m_BoxBrush.BoxPosition, m_BoxBrush.BoxRotationQuat, Vector3.one).inverse;
            var localToBox = worldToBox * source.transform.localToWorldMatrix;
            var extents = m_BoxBrush.BoxSize * 0.5f;
            var pages = new List<GaussianSplatPageEntry>();
            foreach (var page in source.pagedScene.pages)
            {
                if (page.pageAsset == null || !page.pageAsset.IsValid)
                {
                    m_PagedCopyMessage = "The source has missing or invalid pages. Repair the paged scene before copying.";
                    return;
                }
                var bounds = page.pageAsset.bounds;
                Vector3 c = localToBox.MultiplyPoint3x4(bounds.center), e = bounds.extents;
                Vector3 r = new Vector3(
                    Mathf.Abs(localToBox.m00) * e.x + Mathf.Abs(localToBox.m01) * e.y + Mathf.Abs(localToBox.m02) * e.z,
                    Mathf.Abs(localToBox.m10) * e.x + Mathf.Abs(localToBox.m11) * e.y + Mathf.Abs(localToBox.m12) * e.z,
                    Mathf.Abs(localToBox.m20) * e.x + Mathf.Abs(localToBox.m21) * e.y + Mathf.Abs(localToBox.m22) * e.z);
                if (Mathf.Abs(c.x) <= extents.x + r.x && Mathf.Abs(c.y) <= extents.y + r.y && Mathf.Abs(c.z) <= extents.z + r.z)
                    pages.Add(page);
            }
            if (pages.Count == 0) { m_PagedCopyMessage = "No pages intersect the box."; return; }
            m_PagedCopySource = source;
            m_PagedCopyCenter = m_BoxBrush.BoxPosition;
            m_PagedCopySize = m_BoxBrush.BoxSize;
            m_PagedCopyRotation = m_BoxBrush.BoxRotationQuat;
            m_PagedCopyPages = pages.ToArray();
            m_PagedCopyManifest = source.pagedScene;
            m_PagedCopySourceMatrix = source.transform.localToWorldMatrix;
            m_PagedCopyRendererJson = EditorJsonUtility.ToJson(source);
            m_PagedCopyMessage = $"Copied area intersects {pages.Count} pages. Move the box and paste.";
        }

        void PastePagedXcopy()
        {
            if (!CanPastePagedXcopy) { m_PagedCopyMessage = "Copy a paged LoD box first."; return; }
            var source = m_PagedCopySource;
            if (source.m_Cutouts != null && Array.Exists(source.m_Cutouts, c => c != null && c.isActiveAndEnabled))
            { m_PagedCopyMessage = "Remove active cutouts before pasting this area."; return; }
            if (EditorUtility.IsPersistent(source) || !source.gameObject.scene.IsValid() || PrefabStageUtility.GetCurrentPrefabStage() != null)
            { m_PagedCopyMessage = "Paged Xcopy currently requires a regular scene object outside Prefab Mode."; return; }
            foreach (var page in m_PagedCopyPages)
            {
                var asset = page.pageAsset;
                var data = asset != null ? asset.splatData : null;
                if (asset == null || !asset.IsValid || data == null || !AssetDatabase.Contains(asset) ||
                    !AssetDatabase.Contains(data) || !AssetDatabase.Contains(asset.lodTreeData) ||
                    !AssetDatabase.Contains(data.posData) || !AssetDatabase.Contains(data.otherData) ||
                    !AssetDatabase.Contains(data.colorData) || !AssetDatabase.Contains(data.shData) ||
                    (data.chunkData != null && !AssetDatabase.Contains(data.chunkData)))
                { m_PagedCopyMessage = "The selected page assets must be saved in the project before pasting."; return; }
            }
            // Unity transforms cannot represent a sheared parent hierarchy as an independent object.
            Matrix4x4 actual = source.transform.localToWorldMatrix;
            for (int i = 0; i < 16; ++i)
                if (Mathf.Abs(actual[i] - m_PagedCopySourceMatrix[i]) > 0.0001f)
                { m_PagedCopyMessage = "The source moved since copying. Copy the area again."; return; }
            Matrix4x4 trs = Matrix4x4.TRS(source.transform.position, source.transform.rotation, source.transform.lossyScale);
            for (int i = 0; i < 16; ++i)
                if (Mathf.Abs(actual[i] - trs[i]) > 0.001f)
                { m_PagedCopyMessage = "The source has a sheared transform. Remove non-uniformly scaled parents before copying."; return; }

            const string folder = "Assets/SplatBoxXcopy";
            if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder("Assets", "SplatBoxXcopy");
            var manifest = Object.Instantiate(source.pagedScene);
            manifest.name = source.pagedScene.name + " Xcopy";
            string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/Paged Xcopy.asset");
            GameObject root = null;
            try
            {
                using (var serialized = new SerializedObject(manifest))
                {
                    var array = serialized.FindProperty("m_Pages");
                    array.ClearArray();
                    foreach (var entry in m_PagedCopyPages)
                    {
                        int i = array.arraySize;
                        array.InsertArrayElementAtIndex(i);
                        var element = array.GetArrayElementAtIndex(i);
                        element.FindPropertyRelative("pageId").intValue = entry.pageId;
                        element.FindPropertyRelative("gridCoord").vector3IntValue = entry.gridCoord;
                        element.FindPropertyRelative("boundsMin").vector3Value = entry.boundsMin;
                        element.FindPropertyRelative("boundsMax").vector3Value = entry.boundsMax;
                        element.FindPropertyRelative("pageAsset").objectReferenceValue = entry.pageAsset;
                        element.FindPropertyRelative("splatCount").intValue = entry.splatCount;
                        element.FindPropertyRelative("lodNodeCount").intValue = entry.lodNodeCount;
                    }
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                AssetDatabase.CreateAsset(manifest, path);
                AssetDatabase.SaveAssetIfDirty(manifest);
                root = new GameObject(source.name + " Xcopy");
                root.SetActive(false);
                SceneManager.MoveGameObjectToScene(root, source.gameObject.scene);
                root.transform.position = m_PagedCopyCenter;
                var child = new GameObject("Paged splats");
                child.transform.SetParent(root.transform, false);
                child.transform.position = source.transform.position;
                child.transform.rotation = source.transform.rotation;
                child.transform.localScale = source.transform.lossyScale;
                var renderer = child.AddComponent<SplatBoxRenderer>();
                EditorJsonUtility.FromJsonOverwrite(m_PagedCopyRendererJson, renderer);
                using (var serialized = new SerializedObject(renderer))
                {
                    serialized.FindProperty("m_PagedScene").objectReferenceValue = manifest;
                    serialized.FindProperty("m_LodStreamer").objectReferenceValue = null;
                    var eraseScene = serialized.FindProperty("m_PagedEraseScene");
                    if (eraseScene.objectReferenceValue == source.pagedScene) eraseScene.objectReferenceValue = manifest;
                    var colorScene = serialized.FindProperty("m_PagedColorizeScene");
                    if (colorScene.objectReferenceValue == source.pagedScene) colorScene.objectReferenceValue = manifest;
                    var sculptScene = serialized.FindProperty("m_PagedSmudgeScene");
                    if (sculptScene.objectReferenceValue == source.pagedScene) sculptScene.objectReferenceValue = manifest;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                var clipObject = new GameObject("Xcopy boundary");
                clipObject.transform.SetParent(root.transform, false);
                clipObject.transform.position = m_PagedCopyCenter;
                clipObject.transform.rotation = m_PagedCopyRotation;
                clipObject.transform.localScale = m_PagedCopySize * 0.5f;
                var clip = clipObject.AddComponent<GaussianCutout>();
                clip.m_Type = GaussianCutout.Type.Box;
                clip.m_Invert = true;
                renderer.m_Cutouts = new[] { clip };
                using (var serialized = new SerializedObject(renderer))
                {
                    serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue = clip;
                    serialized.FindProperty("m_PagedXcopySource").objectReferenceValue = source;
                    serialized.FindProperty("m_PagedXcopyRoot").objectReferenceValue = root;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
                root.transform.rotation = m_BoxBrush.BoxRotationQuat * Quaternion.Inverse(m_PagedCopyRotation);
                root.transform.position = m_BoxBrush.BoxPosition;
                Undo.RegisterCreatedObjectUndo(root, "Paste paged LoD object");
                root.SetActive(true);
                EditorSceneManager.MarkSceneDirty(root.scene);
                Selection.activeGameObject = root;
                m_PagedCopyMessage = "Pasted a separate LoD object. Select it in the Hierarchy to adjust its transform.";
                SceneView.RepaintAll();
            }
            catch (Exception exception)
            {
                if (root != null) Object.DestroyImmediate(root);
                AssetDatabase.DeleteAsset(path);
                m_PagedCopyMessage = "Paged paste failed: " + exception.Message;
                Debug.LogException(exception);
            }
        }

        // Earlier copies have no source reference. Only match their original hierarchy and a
        // manifest made entirely from this source's page assets; ambiguous sources are skipped.
        static GaussianCutout FindCopyBoundary(SplatBoxRenderer copy)
        {
            if (copy == null || copy.m_Cutouts == null || copy.transform.parent == null) return null;
            using var serialized = new SerializedObject(copy);
            var stored = serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue;
            foreach (var cutout in copy.m_Cutouts)
                if (cutout != null && cutout.GetType() == typeof(GaussianCutout) && cutout.m_Invert &&
                    cutout.m_Type == GaussianCutout.Type.Box && cutout.transform.IsChildOf(copy.transform.parent) &&
                    (stored != null ? stored == cutout : cutout.name == "Xcopy boundary"))
                    return cutout;
            return null;
        }

        static bool IsLegacyPagedCopyOf(SplatBoxRenderer copy, SplatBoxRenderer source)
        {
            if (copy == null || source == null || copy == source || !copy.UsesPagedLod || !source.UsesPagedLod ||
                copy.gameObject.scene != source.gameObject.scene || copy.pagedScene == source.pagedScene ||
                copy.transform.parent == null || copy.transform.parent.name != source.name + " Xcopy" ||
                copy.m_Cutouts == null)
                return false;
            var clip = FindCopyBoundary(copy);
            if (clip == null || !clip.m_Invert || clip.m_Type != GaussianCutout.Type.Box ||
                !clip.transform.IsChildOf(copy.transform.parent)) return false;
            using var serialized = new SerializedObject(copy);
            if (serialized.FindProperty("m_PagedXcopySource").objectReferenceValue != null) return false;
            var boundary = serialized.FindProperty("m_PagedXcopyBoundary").objectReferenceValue;
            if (boundary != clip && (boundary != null || clip.name != "Xcopy boundary")) return false;
            if (source.pagedScene.pages == null) return false;
            var sourcePages = new HashSet<GaussianSplatPageAsset>();
            foreach (var page in source.pagedScene.pages)
                if (page.pageAsset != null) sourcePages.Add(page.pageAsset);
            if (copy.pagedScene.pages == null || copy.pagedScene.pages.Length == 0) return false;
            foreach (var page in copy.pagedScene.pages)
                if (page.pageAsset == null || !sourcePages.Contains(page.pageAsset)) return false;
            return true;
        }

        static bool CopyBoundaryIntersectsScreenBrush(SplatBoxRenderer copy, Camera cam, Vector2 start,
            Vector2 end, float startRadius, float endRadius)
        {
            var clip = FindCopyBoundary(copy);
            if (clip == null || cam == null)
                return true; // Unknown bounds: don't accidentally miss an edit.
            var boundary = clip.transform;
            Vector2 min = new Vector2(float.MaxValue, float.MaxValue), max = new Vector2(float.MinValue, float.MinValue);
            for (int i = 0; i < 8; i++)
            {
                var corner = boundary.TransformPoint(new Vector3((i & 1) == 0 ? -1 : 1,
                    (i & 2) == 0 ? -1 : 1, (i & 4) == 0 ? -1 : 1));
                Vector3 screen = cam.WorldToScreenPoint(corner);
                // Projection across the near plane is not bounded by its projected corners.
                if (screen.z <= cam.nearClipPlane || float.IsNaN(screen.x) || float.IsNaN(screen.y) ||
                    float.IsInfinity(screen.x) || float.IsInfinity(screen.y)) return true;
                var point = new Vector2(screen.x, cam.pixelHeight - screen.y);
                min = Vector2.Min(min, point); max = Vector2.Max(max, point);
            }
            float radius = Mathf.Max(startRadius, endRadius);
            Vector2 brushMin = Vector2.Min(start, end) - Vector2.one * radius;
            Vector2 brushMax = Vector2.Max(start, end) + Vector2.one * radius;
            return min.x <= brushMax.x && max.x >= brushMin.x && min.y <= brushMax.y && max.y >= brushMin.y;
        }

        void ApplyEditorErase(Vector2 start, Vector2 end, float startRadius, float endRadius,
            Camera cam, bool restore, bool line)
        {
            var source = m_TargetRenderer;
            if (source == null || m_EraseBrush == null || cam == null) return;
            var targets = new List<SplatBoxRenderer> { source };
            if (m_EraseIncludePagedCopies && source.gameObject.scene.IsValid())
            {
                var sceneRenderers = new List<SplatBoxRenderer>();
                foreach (var root in source.gameObject.scene.GetRootGameObjects())
                    sceneRenderers.AddRange(root.GetComponentsInChildren<SplatBoxRenderer>(true));
                var owned = new HashSet<SplatBoxRenderer> { source };
                bool discovered;
                do
                {
                    discovered = false;
                    foreach (var copy in sceneRenderers)
                    {
                        if (copy == null || owned.Contains(copy)) continue;
                        using var serialized = new SerializedObject(copy);
                        var owner = serialized.FindProperty("m_PagedXcopySource").objectReferenceValue as SplatBoxRenderer;
                        if (owner != null && owned.Contains(owner))
                        {
                            owned.Add(copy);
                            discovered = true;
                        }
                    }
                } while (discovered);
                foreach (var copy in sceneRenderers)
                {
                    if (copy == null || copy == source || !copy.isActiveAndEnabled ||
                        !CopyBoundaryIntersectsScreenBrush(copy, cam, start, end, startRadius, endRadius)) continue;
                    using var serialized = new SerializedObject(copy);
                    var owner = serialized.FindProperty("m_PagedXcopySource").objectReferenceValue as SplatBoxRenderer;
                    if (owned.Contains(copy)) targets.Add(copy);
                    else if (source.UsesPagedLod && copy.UsesPagedLod && owner == null && IsLegacyPagedCopyOf(copy, source))
                    {
                        bool ambiguous = false;
                        foreach (var other in sceneRenderers)
                            if (other != source && IsLegacyPagedCopyOf(copy, other)) { ambiguous = true; break; }
                        if (!ambiguous) targets.Add(copy);
                    }
                }
            }
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(restore ? "Restore Splat Area" : "Erase Splat Area");
            try
            {
                foreach (var target in targets)
                {
                    m_EraseBrush.TargetRenderer = target;
                    if (restore) m_EraseBrush.RestoreAtScreenPosition(end, endRadius, cam);
                    else if (line) m_EraseBrush.DeleteLineAtScreenPosition(start, end, startRadius, endRadius, cam);
                    else m_EraseBrush.DeleteAtScreenPosition(end, endRadius, cam);
                }
            }
            finally
            {
                m_EraseBrush.TargetRenderer = source;
                Undo.CollapseUndoOperations(group);
            }
        }

        static bool IsUnmodifiedPagedCopyHierarchy(GameObject root, SplatBoxRenderer copy)
        {
            // Do not silently delete other objects or components that a user added under a copy.
            if (root != null && copy != null && !copy.UsesPagedLod && copy.transform.parent == root.transform &&
                root.transform.childCount == 1 && root.GetComponents<Component>().Length == 1 &&
                copy.transform.childCount == 0)
            {
                foreach (var component in copy.GetComponents<Component>())
                    if (!(component is Transform) && !(component is SplatBoxRenderer)) return false;
                return true;
            }
            if (root == null || copy == null || copy.transform.parent != root.transform ||
                root.transform.childCount != 2 || root.GetComponents<Component>().Length != 1 ||
                copy.transform.childCount != 0)
                return false;
            var boundary = FindCopyBoundary(copy);
            if (boundary == null || boundary.transform.parent != root.transform || boundary.transform.childCount != 0)
                return false;
            foreach (var component in copy.GetComponents<Component>())
                if (!(component is Transform) && !(component is SplatBoxRenderer) && !(component is SplatBoxLodStreamer)) return false;
            foreach (var component in boundary.GetComponents<Component>())
                if (!(component is Transform) && !(component is GaussianCutout)) return false;
            return true;
        }

        static void CollectPolygonMasks(SplatBoxRenderer renderer, HashSet<GaussianPolyMask> masks)
        {
            if (renderer.m_Cutouts == null) return;
            foreach (var cutout in renderer.m_Cutouts)
                if (cutout is GaussianPolyMask polygon && polygon != null) masks.Add(polygon);
        }

        static int RemovePagedXcopies(SplatBoxRenderer source, HashSet<GaussianPolyMask> masks, out int ambiguous)
        {
            ambiguous = 0;
            if (source == null || !source.gameObject.scene.IsValid()) return 0;
            var renderers = new List<SplatBoxRenderer>();
            foreach (var root in source.gameObject.scene.GetRootGameObjects())
                renderers.AddRange(root.GetComponentsInChildren<SplatBoxRenderer>(true));
            var roots = new HashSet<GameObject>();
            var owned = new HashSet<SplatBoxRenderer> { source };
            // Include copies made from other copies, even if scene traversal visits children first.
            bool discovered;
            do
            {
                discovered = false;
                foreach (var copy in renderers)
                {
                    if (copy == null || owned.Contains(copy)) continue;
                    using var serialized = new SerializedObject(copy);
                    var owner = serialized.FindProperty("m_PagedXcopySource").objectReferenceValue as SplatBoxRenderer;
                    if (owner != null && owned.Contains(owner))
                    {
                        owned.Add(copy);
                        discovered = true;
                    }
                }
            } while (discovered);
            foreach (var copy in renderers)
            {
                if (copy == null || copy == source) continue;
                using var serialized = new SerializedObject(copy);
                var owner = serialized.FindProperty("m_PagedXcopySource").objectReferenceValue as SplatBoxRenderer;
                var root = serialized.FindProperty("m_PagedXcopyRoot").objectReferenceValue as GameObject;
                if (owner != null && owned.Contains(copy))
                {
                    if (root != null && root.scene == source.gameObject.scene &&
                        !source.transform.IsChildOf(root.transform) && IsUnmodifiedPagedCopyHierarchy(root, copy))
                    {
                        roots.Add(root);
                        CollectPolygonMasks(copy, masks);
                    }
                    else
                        ambiguous++;
                    continue;
                }
                if (owner != null || !IsLegacyPagedCopyOf(copy, source)) continue;
                bool multipleSources = false;
                foreach (var other in renderers)
                    if (other != source && IsLegacyPagedCopyOf(copy, other)) { multipleSources = true; break; }
                if (multipleSources || !IsUnmodifiedPagedCopyHierarchy(copy.transform.parent.gameObject, copy)) ambiguous++;
                else
                {
                    roots.Add(copy.transform.parent.gameObject);
                    CollectPolygonMasks(copy, masks);
                }
            }
            foreach (var root in roots) Undo.DestroyObjectImmediate(root);
            return roots.Count;
        }

        void ResetAllSplatEdits()
        {
            FinishPagedSmudgeStroke();
            FinishPaintOutputStroke();
            FinishColorizeStroke();
            var renderer = m_TargetRenderer;
            if (renderer == null) return;
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Reset Splat Edits");
            Undo.RegisterCompleteObjectUndo(renderer, "Reset Splat Edits");
            var masks = new HashSet<GaussianPolyMask>();
            CollectPolygonMasks(renderer, masks);
            int removed = RemovePagedXcopies(renderer, masks, out int ambiguous);
            if (renderer.m_Cutouts != null)
            {
                // Preserve non-polygon cutouts, especially an Xcopy's keep-inside boundary.
                var retained = new List<GaussianCutout>();
                foreach (var cutout in renderer.m_Cutouts)
                    if (!(cutout is GaussianPolyMask)) retained.Add(cutout);
                renderer.m_Cutouts = retained.ToArray();
            }
            if (m_PolyMask != null) masks.Add(m_PolyMask);
            var remaining = Object.FindObjectsByType<SplatBoxRenderer>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            foreach (var mask in masks)
            {
                if (mask == null) continue;
                bool shared = false;
                foreach (var other in remaining)
                {
                    if (other.m_Cutouts == null) continue;
                    foreach (var cutout in other.m_Cutouts)
                        if (cutout == mask) { shared = true; break; }
                    if (shared) break;
                }
                // A mask can be shared with another model. Detach it locally without changing
                // that model's visibility; clear unused tool geometry so it cannot reapply later.
                if (!shared)
                {
                    Undo.RecordObject(mask, "Reset Polygon Mask");
                    mask.Clear();
                    EditorUtility.SetDirty(mask);
                }
            }
            if (renderer.UsesPagedLod)
            {
                renderer.ResetDeletedSplats();
                renderer.ResetPagedColorize();
                renderer.ResetPagedSculpt();
                renderer.ResetPagedAttractors();
            }
            if (renderer.enabled)
            {
                // Reload transient edits from the original asset/atlas. Monolithic Clone
                // appends GPU data; paged Erase additionally needs its saved journal cleared.
                renderer.enabled = false;
                renderer.enabled = true;
            }
            EditorUtility.SetDirty(renderer);
            if (renderer.gameObject.scene.IsValid()) EditorSceneManager.MarkSceneDirty(renderer.gameObject.scene);
            ClearPagedXcopy();
            if (m_BoxBrush != null) m_BoxBrush.ClearCopiedData();
            if (m_CloneBrush != null) m_CloneBrush.ClearAll();
            m_PagedCloneStatus = null;
            if (m_FillBrush != null) m_FillBrush.Clear();
            m_PagedFillStatus = null;
            if (m_PaintBrush != null) m_PaintBrush.ResetBufferState();
            m_PaintOutputStatus = null;
            if (m_ColorizeBrush != null && m_ColorizeBrush.TargetRenderer == renderer)
                m_ColorizeBrush.ClearUndoHistory();
            Undo.FlushUndoRecordObjects();
            Undo.CollapseUndoOperations(group);
            EditorApplication.QueuePlayerLoopUpdate();
            SceneView.RepaintAll();
            if (ambiguous > 0)
                Debug.LogWarning($"Reset splat edits and polygon masks, and removed {removed} Clone/Xcopy/Fill/Paint objects. {ambiguous} copies were left because their source was ambiguous or their hierarchy contains additional objects or components.");
            else
                Debug.Log($"Reset splat edits and polygon masks, and removed {removed} Clone/Xcopy/Fill/Paint objects.");
        }
    }
}
