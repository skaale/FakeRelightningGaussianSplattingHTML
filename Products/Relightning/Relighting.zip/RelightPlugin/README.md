# SplatBox Relight Plugin

Separate add-on for SplatBox: custom lighting and the Relight shader for Gaussian splats.

**Requires:** SplatBox plugin must be installed first.

## Installation

1. Install SplatBox plugin (main package).
2. In Package Manager: Add package from disk → select this folder's `package.json`.
3. Or copy this folder into `Packages/` and ensure the main SplatBox plugin is present.

## Contents

- **Plugins/** – Relight runtime and editor DLLs (CustomLightManager, point/spot/directional/planar light components, custom editors, Relight Editor window).
- **Shaders/** – `RenderGaussianSplats.shader` (Gaussian Splatting/Render Splats Relight) and `SplatBox.hlsl` (included so the shader compiles in the package).

## Usage

- Menu: **SplatToolbox → Relight → Relight Editor**.
- In Splat Editor, use the Relight toggle and "Use Relight shader" so the renderer uses the Relight shader.
- Add **Custom Light Manager** to the scene, then add **Point**, **Spot**, **Directional**, or **Planar** lights as child objects. Move and rotate them in the Scene; edit properties (intensity, range, attenuation, etc.) in each light's inspector. Each light has a **Show gizmo** option; CustomLightManager has a global **Show Gizmos** checkbox.
- Directional: effect range (1–50 m) and shadow softness; direction from transform (preset can apply rotation). Point/spot/planar: range sliders, no negative values, reset-to-default button.
