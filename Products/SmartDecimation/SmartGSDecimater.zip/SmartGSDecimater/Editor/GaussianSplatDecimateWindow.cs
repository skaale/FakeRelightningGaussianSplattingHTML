// SPDX-License-Identifier: MIT
// Smart Decimate add-on for SplatBox: Android VR / memory reduction.

using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using UnityEditor;
using UnityEngine;
using GaussianSplatting.Editor;
using GaussianSplatting.Runtime;

namespace GaussianSplatting.Decimate.Editor
{
    public class GaussianSplatDecimateWindow : EditorWindow
    {
        const int kMenuPriority = 130;
        const string kPrefRemoval = "SplatBox.Decimate.Removal";
        const string kPrefCompression = "SplatBox.Decimate.Compression";
        const string kPrefSaveAsset = "SplatBox.Decimate.SaveAsset";
        const string kPrefOutputFolder = "SplatBox.Decimate.OutputFolder";
        const string kPrefAssetSuffix = "SplatBox.Decimate.AssetSuffix";
        const string kPrefFilterSpikes = "SplatBox.Decimate.FilterSpikes";
        const string kPrefSpikeFraction = "SplatBox.Decimate.SpikeFraction";

        static readonly Color kPreviewColor = new Color(0.9f, 0.75f, 0.35f);
        static readonly Color kApplyColor = new Color(0.35f, 0.75f, 0.45f);

        SplatBoxRenderer m_TargetRenderer;
        float m_DecimateRemoval = 0.5f;
        float m_DecimateCompression = 1f;
        bool m_DecimateSaveAsset = true;
        string m_DecimateOutputFolder = "Assets/GaussianAssets/Decimated";
        string m_DecimateAssetSuffix = "_vr";
        bool m_FilterSpikes = true;
        float m_SpikeScaleFraction = 0.25f;
        Vector2 m_Scroll;

        [MenuItem("SplatToolbox/Decimate/Smart Decimate", false, kMenuPriority)]
        public static void ShowWindow()
        {
            var w = GetWindow<GaussianSplatDecimateWindow>(false, "Smart Decimate", true);
            w.minSize = new Vector2(360, 420);
            w.Show();
        }

        void OnEnable()
        {
            m_DecimateRemoval = EditorPrefs.GetFloat(kPrefRemoval, 0.5f);
            m_DecimateCompression = EditorPrefs.GetFloat(kPrefCompression, 1f);
            m_DecimateSaveAsset = EditorPrefs.GetBool(kPrefSaveAsset, true);
            m_DecimateOutputFolder = EditorPrefs.GetString(kPrefOutputFolder, "Assets/GaussianAssets/Decimated");
            m_DecimateAssetSuffix = EditorPrefs.GetString(kPrefAssetSuffix, "_vr");
            m_FilterSpikes = EditorPrefs.GetBool(kPrefFilterSpikes, true);
            m_SpikeScaleFraction = EditorPrefs.GetFloat(kPrefSpikeFraction, 0.25f);
            TryBindSelectedRenderer();
        }

        void OnDisable()
        {
            EditorPrefs.SetFloat(kPrefRemoval, m_DecimateRemoval);
            EditorPrefs.SetFloat(kPrefCompression, m_DecimateCompression);
            EditorPrefs.SetBool(kPrefSaveAsset, m_DecimateSaveAsset);
            EditorPrefs.SetString(kPrefOutputFolder, m_DecimateOutputFolder);
            EditorPrefs.SetString(kPrefAssetSuffix, m_DecimateAssetSuffix);
            EditorPrefs.SetBool(kPrefFilterSpikes, m_FilterSpikes);
            EditorPrefs.SetFloat(kPrefSpikeFraction, m_SpikeScaleFraction);
        }

        void OnSelectionChange()
        {
            TryBindSelectedRenderer();
            Repaint();
        }

        void TryBindSelectedRenderer()
        {
            if (m_TargetRenderer != null && m_TargetRenderer.HasValidAsset)
                return;

            var go = Selection.activeGameObject;
            if (go == null)
                return;
            var renderer = go.GetComponent<SplatBoxRenderer>();
            if (renderer != null && renderer.HasValidAsset)
                m_TargetRenderer = renderer;
        }

        void OnGUI()
        {
            m_Scroll = EditorGUILayout.BeginScrollView(m_Scroll);

            EditorGUILayout.Space(8);
            var titleStyle = new GUIStyle(EditorStyles.boldLabel) { fontSize = 14, alignment = TextAnchor.MiddleCenter };
            EditorGUILayout.LabelField("Smart Decimate (Android VR)", titleStyle);

            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(0.2f, 0.55f, 0.35f);
            EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
            GUILayout.FlexibleSpace();
            GUILayout.Label(" Plugin installed & active ", EditorStyles.centeredGreyMiniLabel);
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            GUI.backgroundColor = prevBg;

            EditorGUILayout.Space(8);
            DrawTargetSection();
            EditorGUILayout.Space(8);
            DrawDecimateSection();

            EditorGUILayout.EndScrollView();
        }

        void DrawTargetSection()
        {
            EditorGUILayout.LabelField("Target", EditorStyles.boldLabel);
            m_TargetRenderer = (SplatBoxRenderer)EditorGUILayout.ObjectField(
                "Renderer", m_TargetRenderer, typeof(SplatBoxRenderer), true);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Use Selection", EditorStyles.miniButton))
            {
                var go = Selection.activeGameObject;
                var renderer = go != null ? go.GetComponent<SplatBoxRenderer>() : null;
                if (renderer != null)
                    m_TargetRenderer = renderer;
                else
                    EditorUtility.DisplayDialog("Smart Decimate", "Select a GameObject with a SplatBoxRenderer.", "OK");
            }
            if (GUILayout.Button("Open Splat Editor", EditorStyles.miniButton))
                GaussianSplatEditorWindow.ShowWindow();
            EditorGUILayout.EndHorizontal();
        }

        void DrawDecimateSection()
        {
            EditorGUILayout.LabelField("Reduction", EditorStyles.boldLabel);

            bool hasTarget = m_TargetRenderer != null && m_TargetRenderer.HasValidAsset;
            int currentCount = hasTarget ? m_TargetRenderer.splatCount : 0;
            int deletedCount = hasTarget ? (int)m_TargetRenderer.editDeletedSplats : 0;
            int aliveCount = currentCount - deletedCount;
            int estimatedAfter = hasTarget
                ? Mathf.Max(1, Mathf.RoundToInt(aliveCount * (1f - m_DecimateRemoval)))
                : 0;

            EditorGUILayout.LabelField("Current Splats", hasTarget ? $"{currentCount:N0} ({aliveCount:N0} visible)" : "—");
            EditorGUILayout.LabelField("After Decimate (est.)", hasTarget ? $"~{estimatedAfter:N0}" : "—");

            m_DecimateRemoval = EditorGUILayout.Slider(
                new GUIContent("Remove", "Fraction of visible splats to remove. Keeps high-opacity, larger, round splats; removes faint, tiny, and needle-like ones first."),
                m_DecimateRemoval, 0.05f, 0.9f);

            m_DecimateSaveAsset = EditorGUILayout.Toggle(
                new GUIContent("Save Compressed Asset", "Write a new compressed asset instead of only hiding splats in the scene."),
                m_DecimateSaveAsset);

            if (m_DecimateSaveAsset)
            {
                EditorGUI.indentLevel++;
                m_DecimateAssetSuffix = EditorGUILayout.TextField("Asset Suffix", m_DecimateAssetSuffix);
                m_DecimateOutputFolder = EditorGUILayout.TextField("Output Folder", m_DecimateOutputFolder);
                m_DecimateCompression = EditorGUILayout.Slider(
                    new GUIContent("Compression", GetCompressionLabel(m_DecimateCompression)),
                    m_DecimateCompression, 0f, 4f);
                EditorGUILayout.LabelField("Quality", GetCompressionLabel(m_DecimateCompression), EditorStyles.miniLabel);
                m_FilterSpikes = EditorGUILayout.Toggle(
                    new GUIContent("Filter Spikes", "Skip oversized floater gaussians when writing the new asset."),
                    m_FilterSpikes);
                if (m_FilterSpikes)
                    m_SpikeScaleFraction = EditorGUILayout.Slider("Max Size", m_SpikeScaleFraction, 0.05f, 1f);
                EditorGUI.indentLevel--;
            }

            GUI.enabled = hasTarget && aliveCount > 1;
            EditorGUILayout.BeginHorizontal();
            GUI.backgroundColor = kPreviewColor;
            if (GUILayout.Button("Preview Decimate", GUILayout.Height(28)))
                PreviewSmartDecimate();
            GUI.backgroundColor = kApplyColor;
            if (GUILayout.Button(m_DecimateSaveAsset ? "Apply & Save Asset" : "Apply Decimate", GUILayout.Height(28)))
            {
                if (m_DecimateSaveAsset)
                    ApplyDecimateAndSaveAsset();
                else
                    PreviewSmartDecimate();
            }
            GUI.backgroundColor = Color.white;
            EditorGUILayout.EndHorizontal();

            GUI.enabled = hasTarget && deletedCount > 0;
            if (GUILayout.Button("Reset Deletions (Undo Preview)"))
                ResetDecimatePreview();
            GUI.enabled = true;

            if (!hasTarget)
                EditorGUILayout.HelpBox("Select a renderer with a valid splat asset.", MessageType.Info);
            else
                EditorGUILayout.HelpBox(
                    "Scores each splat by opacity, geometric size, and shape (penalizes needles/floaters). " +
                    "Removes the least important splats first — ideal for Quest / Android VR. " +
                    "Use Preview to check the result, then Apply & Save to create a smaller compressed asset.",
                    MessageType.Info);
        }

        static DecimationSettings BuildDecimationSettings(float removalRatio)
        {
            return new DecimationSettings
            {
                removalRatio = removalRatio,
                opacityWeight = 1f,
                sizeWeight = 0.6f,
                anisotropyPenalty = 0.5f,
                maxScale = 0f
            };
        }

        void PreviewSmartDecimate()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;

            const string kProgressTitle = "Smart Decimate";
            try
            {
                EditorUtility.DisplayProgressBar(kProgressTitle, "Scoring splats...", 0.2f);
                m_TargetRenderer.ResetDeletedSplats();
                int removed = m_TargetRenderer.SmartDecimate(BuildDecimationSettings(m_DecimateRemoval));
                EditorUtility.DisplayProgressBar(kProgressTitle, "Updating...", 1f);
                SceneView.RepaintAll();
                Debug.Log($"Smart decimate preview: removed {removed:N0} splats (~{(m_DecimateRemoval * 100f):F0}% of visible)");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        void ResetDecimatePreview()
        {
            if (m_TargetRenderer == null)
                return;
            m_TargetRenderer.ResetDeletedSplats();
            SceneView.RepaintAll();
        }

        void ApplyDecimateAndSaveAsset()
        {
            if (m_TargetRenderer == null || !m_TargetRenderer.HasValidAsset)
                return;

            if (string.IsNullOrWhiteSpace(m_DecimateOutputFolder) || !m_DecimateOutputFolder.StartsWith("Assets/"))
            {
                EditorUtility.DisplayDialog("Decimate Failed", "Output folder must be inside the project (Assets/...).", "OK");
                return;
            }

            const string kProgressTitle = "Smart Decimate";
            try
            {
                EditorUtility.DisplayProgressBar(kProgressTitle, "Scoring and removing splats...", 0.15f);
                m_TargetRenderer.ResetDeletedSplats();
                int removed = m_TargetRenderer.SmartDecimate(BuildDecimationSettings(m_DecimateRemoval));
                if (removed <= 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate", "Nothing to remove at this setting.", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, "Exporting surviving splats...", 0.45f);

                var mergedSplats = new List<GaussianSplatAssetCreator.InputSplatData>();
                if (!CollectAliveSplatsFromRenderer(m_TargetRenderer, mergedSplats, false, ComputeExportMaxScale()))
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate Failed", "Could not export splat data.", "OK");
                    return;
                }

                if (mergedSplats.Count == 0)
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate Failed", "No splats left after decimation.", "OK");
                    return;
                }

                string baseName = m_TargetRenderer.asset.name + m_DecimateAssetSuffix;
                var quality = GetCompressionQuality(m_DecimateCompression);

                EditorUtility.DisplayProgressBar(kProgressTitle,
                    $"Creating {quality} asset ({mergedSplats.Count:N0} splats)...", 0.7f);

                using var nativeSplats = new NativeArray<GaussianSplatAssetCreator.InputSplatData>(
                    mergedSplats.ToArray(), Allocator.TempJob);

                string assetPath = GaussianSplatAssetCreator.CreateAssetFromSplats(
                    nativeSplats, m_DecimateOutputFolder.Trim(), baseName, quality);

                if (string.IsNullOrEmpty(assetPath))
                {
                    EditorUtility.ClearProgressBar();
                    EditorUtility.DisplayDialog("Decimate Failed", "Asset creation failed. Check the Console.", "OK");
                    return;
                }

                EditorUtility.DisplayProgressBar(kProgressTitle, "Assigning asset...", 0.95f);

                var savedAsset = AssetDatabase.LoadAssetAtPath<GaussianSplatAsset>(assetPath);
                Undo.RecordObject(m_TargetRenderer, "Smart Decimate");
                m_TargetRenderer.m_Asset = savedAsset;
                m_TargetRenderer.ResetDeletedSplats();
                EditorUtility.SetDirty(m_TargetRenderer);
                m_TargetRenderer.gameObject.SetActive(false);
                m_TargetRenderer.gameObject.SetActive(true);
                SceneView.RepaintAll();

                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Decimate Complete",
                    $"Removed {removed:N0} splats.\n\n" +
                    $"Remaining: {mergedSplats.Count:N0}\n" +
                    $"Quality: {GetCompressionLabel(m_DecimateCompression)}\n" +
                    $"Asset: {assetPath}",
                    "OK");

                Debug.Log($"✓ Smart decimate saved {assetPath} ({mergedSplats.Count:N0} splats, removed {removed:N0})");
            }
            catch (Exception ex)
            {
                Debug.LogError($"Smart decimate failed: {ex.Message}\n{ex.StackTrace}");
                EditorUtility.ClearProgressBar();
                EditorUtility.DisplayDialog("Decimate Failed", ex.Message, "OK");
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        float ComputeExportMaxScale()
        {
            if (!m_FilterSpikes || m_TargetRenderer == null || m_TargetRenderer.asset == null)
                return 0f;

            var asset = m_TargetRenderer.asset;
            float diagonal = (asset.boundsMax - asset.boundsMin).magnitude;
            if (diagonal <= 0f || float.IsNaN(diagonal) || float.IsInfinity(diagonal))
                return 0f;

            return diagonal * m_SpikeScaleFraction;
        }

        static bool CollectAliveSplatsFromRenderer(
            SplatBoxRenderer renderer,
            List<GaussianSplatAssetCreator.InputSplatData> output,
            bool bakeTransform,
            float maxExportScale)
        {
            if (renderer == null || !renderer.HasValidAsset || renderer.splatCount <= 0)
                return false;

            int kSplatSize = UnsafeUtility.SizeOf<GaussianSplatAssetCreator.InputSplatData>();
            using var gpuData = new GraphicsBuffer(GraphicsBuffer.Target.Structured, renderer.splatCount, kSplatSize);
            if (!renderer.EditExportData(gpuData, bakeTransform, maxExportScale))
                return false;

            var data = new GaussianSplatAssetCreator.InputSplatData[gpuData.count];
            gpuData.GetData(data);

            var gpuDeleted = renderer.GpuEditDeleted;
            if (gpuDeleted == null)
            {
                for (int i = 0; i < data.Length; i++)
                {
                    if (data[i].nor.sqrMagnitude <= 0)
                        output.Add(data[i]);
                }
                return true;
            }

            uint[] deleted = new uint[gpuDeleted.count];
            gpuDeleted.GetData(deleted);

            for (int i = 0; i < data.Length; i++)
            {
                int wordIdx = i >> 5;
                int bitIdx = i & 31;
                bool isDeleted = (deleted[wordIdx] & (1u << bitIdx)) != 0;
                bool isCutout = data[i].nor.sqrMagnitude > 0;
                if (!isDeleted && !isCutout)
                    output.Add(data[i]);
            }

            return true;
        }

        static string GetCompressionLabel(float value)
        {
            return GetCompressionQuality(value) switch
            {
                GaussianSplatAssetCreator.DataQuality.VeryLow => "Very Low (~19× smaller, most compression)",
                GaussianSplatAssetCreator.DataQuality.Low => "Low (~14× smaller)",
                GaussianSplatAssetCreator.DataQuality.Medium => "Medium (~5× smaller, balanced)",
                GaussianSplatAssetCreator.DataQuality.High => "High (~3× smaller)",
                GaussianSplatAssetCreator.DataQuality.VeryHigh => "Very High (minimal compression, best quality)",
                _ => "Medium"
            };
        }

        static GaussianSplatAssetCreator.DataQuality GetCompressionQuality(float value)
        {
            int level = Mathf.Clamp(Mathf.RoundToInt(value), 0, 4);
            return (GaussianSplatAssetCreator.DataQuality)(4 - level);
        }
    }
}
