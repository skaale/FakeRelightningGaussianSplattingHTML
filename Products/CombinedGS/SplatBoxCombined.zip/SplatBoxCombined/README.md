# SplatBox Combined Plugin (Render + Relight)

All-in-one precompiled package: SplatBox Gaussian Splat editing tools **and** the Relight lighting add-on.

**Build Info:**
- Unity Version: 6000.3.4f1
- URP Support: NO - GaussianSplatURPFeature NOT included (rebuild with URP for full support)
- Build Date: 2026-04-14 15:51

## Installation

### Option 1: Unity Package Manager
1. Open Unity Package Manager (Window > Package Manager)
2. Click '+' and select 'Add package from disk...'
3. Navigate to this folder and select `package.json`

### Option 2: Manual
1. Copy this folder into your project's `Packages/` directory.
2. Rename to `com.gaussiansplatting.splatbox.combined`.

## Requirements

- **Unity 6** (6000.0+) — compiled with Unity 6000.3.4f1
- Universal Render Pipeline (URP) for splat rendering
- Auto-installed dependencies: Mathematics, Collections, Burst

**IMPORTANT:** Use with the same major Unity version it was built with.

## URP Setup

1. Select your URP Renderer Asset (usually in Settings folder)
2. Click 'Add Renderer Feature'
3. Add **Gaussian Splat URP Feature** for splat rendering
4. (Optional) Add **Gaussian Tilt Shift Renderer Feature** for tilt-shift effects

## Contents

- **Plugins/** — Precompiled DLLs
  - `GaussianSplatting.SplatBox.Core.dll` — Core rendering and data structures
  - `GaussianSplatting.SplatBox.Runtime.dll` — Runtime components, brushes, URP features
  - `GaussianSplatting.SplatBox.Relight.dll` — Relight runtime (custom lights)
  - **Editor/**
    - `GaussianSplatting.SplatBox.Editor.dll` — Editor tools and inspectors
    - `GaussianSplatting.SplatBox.Relight.Editor.dll` — Relight editor (Relight window, custom inspectors)
- **Editor/Icons/** — Editor icon assets
- **Shaders/** — All shader and compute files (SplatBox + Relight)
- **Resources/** — Runtime-loadable assets

## Relight Usage

- Menu: **SplatToolbox > Relight > Relight Editor**
- In Splat Editor, enable the Relight toggle and 'Use Relight shader'.
- Add **Custom Light Manager** to the scene, then add Point, Spot, Directional, or Planar lights as children.
- Adjust intensity, range, attenuation, etc. in each light's inspector.
