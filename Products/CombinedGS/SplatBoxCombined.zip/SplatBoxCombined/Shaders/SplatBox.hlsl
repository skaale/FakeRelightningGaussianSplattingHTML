// SPDX-License-Identifier: MIT
 
// For compute shader code, see BoxUtil.compute
#ifndef SPLATBOX_HLSL
#define SPLATBOX_HLSL

// View data structure for rendering splats
struct SplatViewData
{
    float4 pos;
    float2 axis1, axis2;
    uint2 color; // 4xFP16
};

#endif // SPLATBOX_HLSL
