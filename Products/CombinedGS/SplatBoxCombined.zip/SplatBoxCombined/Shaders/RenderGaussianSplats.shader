 
Shader "Gaussian Splatting/Render Splats Relight"
{
    Properties
    {
        _DirectionalIntensity ("Directional Light Intensity", Range(0, 2)) = 1
        _AmbientIntensity ("Ambient Light Intensity", Range(0, 2)) = 1
        _ShadowStrength ("Shadow Strength", Range(0, 1)) = 0.5
        _SSAOStrength ("SSAO Strength", Range(0, 1)) = 1.0
        _SharpenStrength ("Sharpen Strength", Range(0, 2)) = 0.0
       // _AudioColorTint ("Audio Color Tint", Color) = (1,1,1,1)
    }

    SubShader
    {
        Tags { 
            "RenderType" = "Transparent" 
            "Queue" = "Transparent"
            "RenderPipeline" = "UniversalPipeline"
        }

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }
            
            ZWrite Off
           // ZTest LEqual
            Blend OneMinusDstAlpha One
            Cull Off
            
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma require compute
            #pragma use_dxc
            #pragma multi_compile_local __ DEBUG_SPLAT_RENDER
            #pragma multi_compile_local __ DEBUG_BINDINGS
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS_CASCADE
            #pragma multi_compile _ _ADDITIONAL_LIGHTS
            #pragma multi_compile _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile _ _SHADOWS_SOFT
            #pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX
            #pragma multi_compile_fog
            // Use Multi-Pass VR rendering instead of Single Pass Instanced (known issue)
            #pragma multi_compile _ STEREO_MULTIVIEW_ON

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
            #include "Packages/com.unity.render-pipelines.core/ShaderLibrary/UnityInstancing.hlsl"
            #include "SplatBox.hlsl"

            StructuredBuffer<uint> _OrderBuffer;

            CBUFFER_START(UnityPerMaterial)
                float _DirectionalIntensity;
                float _AmbientIntensity;
                float _ShadowStrength;
                float _SSAOStrength;
                float _SharpenStrength;
                float4 _AudioColorTint;
                float _DepthOffset;
                uint _CustomPointLightCount;
                uint _CustomSpotLightCount;
                
                // Color adjustments
                float _ColorExposure;
                float _ColorContrast;
                float4 _ColorFilter;
                float _ColorHueShift;
                float _ColorSaturation;
                
                // Selection colors
                float4 _SelectionColor;
                float4 _TargetSelectionColor;
                
                // Decal properties
                int _DecalEnabled;
                float4x4 _DecalWorldToProjector;
                float4x4 _DecalProjectorToWorld;
                float3 _DecalBoxSize;
                int _DecalProjectionMode;
                int _DecalBlendMode;
                float _DecalOpacity;
                float4 _DecalTintColor;
                float _DecalFrustumFOV;
                float _DecalFrustumNear;
                float _DecalFrustumFar;
                int _DecalUseNormalFiltering;
                float _DecalNormalThreshold;
                int _DecalUseDepthFade;
                float _DecalDepthFadeStart;
                float _DecalDepthFadeEnd;
                int _DecalUseCircleMask;
                float2 _DecalMaskCenter;
                float _DecalMaskRadius;
                float _DecalMaskSoftness;
                int _DecalInvertMask;
            CBUFFER_END

            TEXTURE2D(_DecalTexture);
            SAMPLER(sampler_DecalTexture);

            struct v2f
            {
                half4 col : COLOR0;
                float2 pos : TEXCOORD0;
                float4 vertex : SV_POSITION;
                float3 normalWS : TEXCOORD1;
                float3 positionWS : TEXCOORD2;
                float4 shadowCoord : TEXCOORD3;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            StructuredBuffer<SplatViewData> _SplatViewData;
            ByteAddressBuffer _SplatSelectedBits;
            ByteAddressBuffer _SplatTargetSelectedBits;
            uint _SplatBitsValid;

            struct CustomPointLight {
                float3 position;
                float3 color;
                float intensity;
                float range;
                float attenuationMode;
            };

            struct CustomSpotLight {
                float3 position;
                float3 direction;
                float3 color;
                float intensity;
                float range;
                float innerConeAngle;  // cosine of inner cone half-angle
                float outerConeAngle;  // cosine of outer cone half-angle
                float attenuationMode;
            };

            struct CustomDirectionalLight {
                float3 direction;
                float3 color;
                float intensity;
                float effectRange;
                float rangeSoftness;
                float shadowStrength;
                float useDistanceAttenuation;
                float distanceAttenuationFactor;
                float useAngleAttenuation;
                float angleAttenuationBias;
            };

            struct CustomPlanarLight {
                float3 position;
                float3 normal;
                float3 color;
                float intensity;
                float range;
                float sizeX;
                float sizeY;
                float twoSided;
                float attenuationMode;
            };

            StructuredBuffer<CustomPointLight> _CustomPointLights;
            StructuredBuffer<CustomSpotLight> _CustomSpotLights;
            StructuredBuffer<CustomDirectionalLight> _CustomDirectionalLights;
            StructuredBuffer<CustomPlanarLight> _CustomPlanarLights;
            uint _CustomDirectionalLightCount;
            uint _CustomPlanarLightCount;
            TEXTURE2D(_GaussianSSAO);
            SAMPLER(sampler_GaussianSSAO);

            // Convert RGB to HSV
            float3 RGBToHSV(float3 c)
            {
                float4 K = float4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
                float4 p = lerp(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
                float4 q = lerp(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));
                
                float d = q.x - min(q.w, q.y);
                float e = 1.0e-10;
                return float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
            }
            
            // Convert HSV to RGB
            float3 HSVToRGB(float3 c)
            {
                float4 K = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
                float3 p = abs(frac(c.xxx + K.xyz) * 6.0 - K.www);
                return c.z * lerp(K.xxx, saturate(p - K.xxx), c.y);
            }
            
            // Apply color adjustments to a color
            float3 ApplyColorAdjustments(float3 color)
            {
                // Apply exposure (brightness)
                color *= exp2(_ColorExposure);
                
                // Apply contrast
                color = lerp(0.5, color, _ColorContrast);
                
                // Convert to HSV for hue shift and saturation
                float3 hsv = RGBToHSV(color);
                
                // Apply hue shift (in degrees, convert to 0-1 range)
                hsv.x = frac(hsv.x + _ColorHueShift / 360.0);
                
                // Apply saturation
                hsv.y *= _ColorSaturation;
                
                // Convert back to RGB
                color = HSVToRGB(hsv);
                
                // Apply color filter (multiply)
                color *= _ColorFilter.rgb;
                
                return color;
            }
            
            float4 ApplyDecal(float3 positionWS, float3 normalWS, float4 baseColor)
            {
                if (_DecalEnabled == 0) return baseColor;
                
                // Transform world position to projector local space
                float3 projectorLocalPos = mul(_DecalWorldToProjector, float4(positionWS, 1.0)).xyz;
                
                // Check if position is within projection volume
                bool inVolume = false;
                float2 uv = float2(0, 0);
                
                if (_DecalProjectionMode == 0) // Box
                {
                    float3 absPos = abs(projectorLocalPos);
                    half3 boxHalfSize = _DecalBoxSize * 0.5;
                    inVolume = all(absPos <= boxHalfSize);
                    if (inVolume)
                    {
                        // Map to UV (0-1)
                        uv = (projectorLocalPos.xy / _DecalBoxSize.xy) + 0.5;
                    }
                }
                else // Frustum (1)
                {
                    // For frustum projection, use perspective division
                    float depth = -projectorLocalPos.z;
                    if (depth > _DecalFrustumNear && depth < _DecalFrustumFar)
                    {
                        // Calculate frustum size at this depth
                        float fovRad = _DecalFrustumFOV * 0.5 * 0.01745329; // deg to rad
                        float halfHeight = tan(fovRad) * depth;
                        float halfWidth = halfHeight;
                        
                        if (abs(projectorLocalPos.x) < halfWidth && abs(projectorLocalPos.y) < halfHeight)
                        {
                            inVolume = true;
                            uv = float2(projectorLocalPos.x / (halfWidth * 2.0) + 0.5,
                                       projectorLocalPos.y / (halfHeight * 2.0) + 0.5);
                        }
                    }
                }
                
                if (!inVolume) return baseColor;
                
                float finalOpacity = _DecalOpacity;
                
                // Apply circle mask
                if (_DecalUseCircleMask == 1)
                {
                    float2 maskUV = uv - _DecalMaskCenter;
                    float dist = length(maskUV);
                    float mask = smoothstep(_DecalMaskRadius + _DecalMaskSoftness, 
                                           _DecalMaskRadius - _DecalMaskSoftness, dist);
                    if (_DecalInvertMask == 1) mask = 1.0 - mask;
                    if (mask < 0.01) return baseColor;
                    finalOpacity *= mask;
                }
                
                // Depth fade
                if (_DecalUseDepthFade == 1)
                {
                    float depth = abs(projectorLocalPos.z) / _DecalBoxSize.z;
                    float fade = smoothstep(_DecalDepthFadeStart, _DecalDepthFadeEnd, depth);
                    finalOpacity *= (1.0 - fade);
                }
                
                // Sample decal texture
                float4 decalColor = SAMPLE_TEXTURE2D(_DecalTexture, sampler_DecalTexture, uv);
                decalColor *= _DecalTintColor;
                
                // Apply blend mode
                float4 result = baseColor;
                if (_DecalBlendMode == 0) // Replace
                {
                    result.rgb = lerp(baseColor.rgb, decalColor.rgb, decalColor.a * finalOpacity);
                }
                else if (_DecalBlendMode == 1) // Multiply
                {
                    result.rgb = lerp(baseColor.rgb, baseColor.rgb * decalColor.rgb, decalColor.a * finalOpacity);
                }
                else if (_DecalBlendMode == 2) // Additive
                {
                    result.rgb = baseColor.rgb + decalColor.rgb * decalColor.a * finalOpacity;
                }
                else if (_DecalBlendMode == 3) // Overlay
                {
                    float3 overlay;
                    overlay.r = baseColor.r < 0.5 ? (2.0 * baseColor.r * decalColor.r) : (1.0 - 2.0 * (1.0 - baseColor.r) * (1.0 - decalColor.r));
                    overlay.g = baseColor.g < 0.5 ? (2.0 * baseColor.g * decalColor.g) : (1.0 - 2.0 * (1.0 - baseColor.g) * (1.0 - decalColor.g));
                    overlay.b = baseColor.b < 0.5 ? (2.0 * baseColor.b * decalColor.b) : (1.0 - 2.0 * (1.0 - baseColor.b) * (1.0 - decalColor.b));
                    result.rgb = lerp(baseColor.rgb, overlay, decalColor.a * finalOpacity);
                }
                else // AlphaBlend (4)
                {
                    result.rgb = lerp(baseColor.rgb, decalColor.rgb, decalColor.a * finalOpacity);
                }
                
                return result;
            }

			float CalculateAttenuation(float distance, float range, float mode)
            {
                float normalizedDistance = distance / range;
                
                // Mode 0: Default (Quadratic)
                if (mode < 0.5)
                {
                    float attenuation = saturate(1.0 - normalizedDistance * normalizedDistance);
                    return attenuation * attenuation;
                }
                // Mode 1: Linear
                else if (mode < 1.5)
                {
                    return saturate(1.0 - normalizedDistance);
                }
                // Mode 2: Inverse Square
                else
                {
                    return 1.0 / (1.0 + normalizedDistance * normalizedDistance);
                }
            }

            half3 CalculateGSLighting(float3 normalWS, float3 positionWS, float4 shadowCoord)
            {
             
                half3 totalLighting = half3(0, 0, 0);
                
                half3 ambient = SampleSH(normalWS);
                totalLighting += ambient * _AmbientIntensity;
               
                Light mainLight = GetMainLight(shadowCoord);
                float NdotL = saturate(dot(normalWS, mainLight.direction));
               
                float shadowAttenuation = mainLight.shadowAttenuation;
                
                float depth = length(positionWS);
                float distanceAtten = 1.0 / (1.0 + depth * 0.5);  
                
                // Calculate angle-based attenuation
                float upDot = dot(mainLight.direction, float3(0, 1, 0));
                float angleAttenuation = saturate(upDot + 0.5);
                
                // Combine all attenuation factors
                float finalAttenuation = shadowAttenuation * distanceAtten * angleAttenuation;
                
              
                half3 directionalLight = mainLight.color * NdotL * _DirectionalIntensity;
                directionalLight *= (1 - (_ShadowStrength * (1 - finalAttenuation)));
                
                totalLighting += directionalLight;
                
                // Custom point lights
                for (uint i = 0; i < _CustomPointLightCount; i++)
                {
                    CustomPointLight light = _CustomPointLights[i];
                    
                    float3 lightVector = light.position - positionWS;
                    float distance = length(lightVector);
                    float3 lightDir = lightVector / distance;
                    
                    float attenuation = CalculateAttenuation(distance, light.range, light.attenuationMode);
                    
                    float pointNdotL = saturate(dot(normalWS, lightDir));
                    half3 pointContribution = light.color * light.intensity * attenuation * pointNdotL;
                    
                    totalLighting += pointContribution;
                }
                
                // Custom spot lights
                for (uint j = 0; j < _CustomSpotLightCount; j++)
                {
                    CustomSpotLight spotLight = _CustomSpotLights[j];
                    
                    float3 lightVector = spotLight.position - positionWS;
                    float distance = length(lightVector);
                    float3 lightDir = lightVector / distance;
                    
                    // Distance attenuation
                    float distanceAttenuation = CalculateAttenuation(distance, spotLight.range, spotLight.attenuationMode);
                    
                    // Angular attenuation for spotlight cone (lightDir = splat->light, so -lightDir = light->splat)
                    float3 spotDirection = normalize(spotLight.direction);
                    float cosAngle = dot(-lightDir, spotDirection);
                    float coneSpan = spotLight.innerConeAngle - spotLight.outerConeAngle;
                    // Avoid division by zero; inner should be > outer (inner = tighter cone = larger cos)
                    float angularAttenuation = (coneSpan > 1e-5) ? saturate((cosAngle - spotLight.outerConeAngle) / coneSpan) : saturate(sign(cosAngle - spotLight.outerConeAngle));
                    
                    // Overall attenuation
                    float totalAttenuation = distanceAttenuation * angularAttenuation;
                    
                    float spotNdotL = saturate(dot(normalWS, lightDir));
                    half3 spotContribution = spotLight.color * spotLight.intensity * totalAttenuation * spotNdotL;
                    
                    totalLighting += spotContribution;
                }
                
                // Custom directional lights
                for (uint k = 0; k < _CustomDirectionalLightCount; k++)
                {
                    CustomDirectionalLight dirLight = _CustomDirectionalLights[k];
                    
                    // Skip inactive lights
                    if (dirLight.intensity <= 0.0)
                        continue;
                    
                    float3 lightDir = normalize(dirLight.direction);
                    float dirNdotL = saturate(dot(normalWS, lightDir));
                    
                    // Effect range in meters: dark outside. rangeSoftness = width (m) of soft falloff at the edge.
                    float distanceFromOrigin = length(positionWS);
                    float rangeStart = max(0.0, dirLight.effectRange - max(0.0, dirLight.rangeSoftness));
                    float rangeAtten = 1.0 - smoothstep(rangeStart, dirLight.effectRange, distanceFromOrigin);
                    
                    // When shadowStrength is 0, ignore normal direction (no shadows from normals)
                    // When shadowStrength is 1, fully respect normal direction. Saturate to avoid artifacts from values > 1.
                    float normalInfluence = lerp(1.0, dirNdotL, saturate(dirLight.shadowStrength));
                    
                    float finalDirAttenuation = rangeAtten;
                    
                    // Distance attenuation (optional)
                    if (dirLight.useDistanceAttenuation > 0.5)
                    {
                        float distance = length(positionWS);
                        float distFactor = saturate(dirLight.distanceAttenuationFactor);
                        float dirDistAtten = 1.0 / (1.0 + distance * distFactor);
                        finalDirAttenuation *= dirDistAtten;
                    }
                    
                    // Angle-based attenuation (optional). Use min 0.2 so downward/bottom presets still cast light.
                    if (dirLight.useAngleAttenuation > 0.5)
                    {
                        float upDot = dot(lightDir, float3(0, 1, 0));
                        float angleAtten = saturate(upDot + dirLight.angleAttenuationBias);
                        finalDirAttenuation *= max(0.2, angleAtten);
                    }
                    
                    // Apply normal influence and other attenuations
                    half3 dirContribution = dirLight.color * dirLight.intensity * normalInfluence;
                    dirContribution *= finalDirAttenuation;
                    
                    totalLighting += dirContribution;
                }
                
                // Custom planar lights
                for (uint p = 0; p < _CustomPlanarLightCount; p++)
                {
                    CustomPlanarLight planar = _CustomPlanarLights[p];
                    
                    // Skip inactive lights
                    if (planar.intensity <= 0.0)
                        continue;
                    
                    float3 toSplat = positionWS - planar.position;
                    float distance = length(toSplat);
                    float3 lightDir = normalize(toSplat);
                    
                    // Calculate if splat is within the planar light's rectangular area projection
                    float3 planeNormal = normalize(planar.normal);
                    
                    // Project splat position onto plane
                    float dotNormal = dot(toSplat, planeNormal);
                    
                    // Check if on correct side of plane (or two-sided)
                    bool correctSide = (dotNormal > 0.0) || (planar.twoSided > 0.5);
                    if (!correctSide)
                        continue;
                    
                    // Project position onto plane
                    float3 projectedPos = positionWS - planeNormal * dotNormal;
                    float3 localPos = projectedPos - planar.position;
                    
                    // Calculate plane local axes
                    float3 planeRight = normalize(cross(planeNormal, float3(0, 1, 0)));
                    if (length(planeRight) < 0.1)
                        planeRight = normalize(cross(planeNormal, float3(1, 0, 0)));
                    float3 planeUp = normalize(cross(planeNormal, planeRight));
                    
                    // Project to plane local coordinates
                    float localX = dot(localPos, planeRight);
                    float localY = dot(localPos, planeUp);
                    
                    // Check if within rectangular bounds
                    float halfSizeX = planar.sizeX * 0.5;
                    float halfSizeY = planar.sizeY * 0.5;
                    
                    bool withinBounds = (abs(localX) <= halfSizeX) && (abs(localY) <= halfSizeY);
                    
                    if (!withinBounds)
                        continue;
                    
                    // Distance attenuation
                    float distanceAtten = CalculateAttenuation(distance, planar.range, planar.attenuationMode);
                    
                    // Calculate lighting based on angle (Lambert for normal, or uniform)
                    float planarNdotL = saturate(dot(normalWS, -lightDir));
                    
                    // Soft edge falloff within plane bounds
                    float edgeFalloffX = 1.0 - smoothstep(halfSizeX * 0.7, halfSizeX, abs(localX));
                    float edgeFalloffY = 1.0 - smoothstep(halfSizeY * 0.7, halfSizeY, abs(localY));
                    float edgeFalloff = edgeFalloffX * edgeFalloffY;
                    
                    half3 planarContribution = planar.color * planar.intensity * distanceAtten * planarNdotL * edgeFalloff;
                    
                    totalLighting += planarContribution;
                }
                
                return totalLighting;
            }

            struct appdata
            {
                uint vtxID : SV_VertexID;
                uint instID : SV_InstanceID;
            };

            v2f vert(appdata input)
            {
                v2f o = (v2f)0;
                
                // Multi-Pass VR support (no instance ID conflicts)
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                
                uint vtxID = input.vtxID;
                uint instID = input.instID;
                instID = _OrderBuffer[instID];
                SplatViewData view = _SplatViewData[instID];
                float4 centerClipPos = view.pos;
                bool behindCam = centerClipPos.w <= 0;
                if (behindCam)
                {
                    o.vertex = asfloat(0x7fc00000); // NaN discards the primitive
                }
                else
                {
                    o.col.r = f16tof32(view.color.x >> 16);
                    o.col.g = f16tof32(view.color.x);
                    o.col.b = f16tof32(view.color.y >> 16);
                    o.col.a = f16tof32(view.color.y);

                    uint idx = vtxID;
                    float2 quadPos = float2(idx&1, (idx>>1)&1) * 2.0 - 1.0;
                    quadPos *= 2;
                    o.pos = quadPos;

                    // Calculate vertex position in clip space
                    float2 deltaScreenPos = (quadPos.x * view.axis1 + quadPos.y * view.axis2) * 2 / _ScreenParams.xy;
                    o.vertex = centerClipPos;
                    o.vertex.xy += deltaScreenPos * centerClipPos.w;

                    // Transform to world space for lighting calculations
                    // Use stereo-aware inverse view-projection matrix
                    o.positionWS = mul(UNITY_MATRIX_I_VP, o.vertex).xyz;
                    
                    // Calculate normal based on view direction
                    float3 viewDir = normalize(_WorldSpaceCameraPos - o.positionWS);
                    o.normalWS = viewDir;  // Use view direction as normal for lighting
                    
                    o.shadowCoord = TransformWorldToShadowCoord(o.positionWS);

                    if (_SplatBitsValid)
                    {
                        uint wordIdx = instID / 32;
                        uint bitIdx = instID & 31;
                        uint selVal = _SplatSelectedBits.Load(wordIdx * 4);
                        uint targetSelVal = _SplatTargetSelectedBits.Load(wordIdx * 4);
                        bool isSourceSelected = (selVal & (1 << bitIdx)) != 0;
                        bool isTargetSelected = (targetSelVal & (1 << bitIdx)) != 0;
                        
                        // Encode selection state in alpha:
                        // -1 = source selected only
                        // -2 = target selected only
                        // -3 = both selected
                        if (isSourceSelected && isTargetSelected)
                            o.col.a = -3;
                        else if (isTargetSelected)
                            o.col.a = -2;
                        else if (isSourceSelected)
                            o.col.a = -1;
                    }
                }
                return o;
            }

            half4 frag(v2f i) : SV_Target
            {
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
                
                #if defined(DEBUG_BINDINGS)
                return half4(1,0,0,1);
                #endif

                float power = -dot(i.pos, i.pos);
                half alpha = exp(power);
                
                // Apply sharpening after exp for more visible effect
                if (_SharpenStrength > 0.01)
                {
                    // Sharpen by raising alpha to higher power (makes edges crisper)
                    // Higher power = steeper falloff at edges
                    float sharpenPower = 1.0 + (_SharpenStrength * 3.0);
                    alpha = pow(alpha, sharpenPower);
                }
                
                // Debug: Tint splats red when sharpen is active
                if (_SharpenStrength > 0.5)
                {
                    i.col.rgb = lerp(i.col.rgb, half3(1,0,0), 0.3);
                }
                
                if (i.col.a >= 0)
                {
                    alpha = saturate(alpha * i.col.a);
                }
                else
                {
                    // Selection state encoded in negative alpha:
                    // -1 = source selected, -2 = target selected, -3 = both
                    half3 selColor = _SelectionColor.rgb;
                    if (i.col.a < -2.5) // Both selected (-3)
                    {
                        // Mix both colors
                        selColor = lerp(_SelectionColor.rgb, _TargetSelectionColor.rgb, 0.5);
                    }
                    else if (i.col.a < -1.5) // Target selected (-2)
                    {
                        selColor = _TargetSelectionColor.rgb;
                    }
                    // else: Source selected (-1), use default _SelectionColor
                    
                    if (alpha > 7.0/255.0)
                    {
                        if (alpha < 10.0/255.0)
                        {
                            alpha = 1;
                            i.col.rgb = selColor;
                        }
                        alpha = saturate(alpha + 0.3);
                    }
                    i.col.rgb = lerp(i.col.rgb, selColor, 0.5);
                }
                
                if (alpha < 1.0/255.0)
                    discard;

                // Sample SSAO
                float2 screenUV = i.vertex.xy / _ScreenParams.xy;
                half ssao = SAMPLE_TEXTURE2D(_GaussianSSAO, sampler_GaussianSSAO, screenUV).r;
                ssao = lerp(1.0, ssao, _SSAOStrength);
               
                half3 lighting = CalculateGSLighting(normalize(i.normalWS), i.positionWS, i.shadowCoord);
                lighting *= ssao; // Apply SSAO occlusion
                half4 res = half4(i.col.rgb * lighting * alpha, alpha);
               // half3 finalColor = i.col.rgb * lighting * alpha;
               // finalColor *= _AudioColorTint.rgb; // Apply audio color tint
               // half4 res = half4(finalColor, alpha);
               
                // Apply decal projection
                res = ApplyDecal(i.positionWS, i.normalWS, res);
               
                // Apply color adjustments to final color
                res.rgb = ApplyColorAdjustments(res.rgb);
               
                return res;
            }
            ENDHLSL
        }

        Pass
        {
            Name "BlitToScreen"
            Tags { "LightMode" = "Always" }
            ZWrite Off
            ZTest Always
            Cull Off
            Blend SrcAlpha OneMinusSrcAlpha

            CGPROGRAM
            #pragma vertex vertComposite
            #pragma fragment fragComposite
            #pragma require compute
            #pragma use_dxc
            #include "UnityCG.cginc"

            struct v2fComposite
            {
                float4 vertex : SV_POSITION;
            };

            v2fComposite vertComposite(uint vtxID : SV_VertexID)
            {
                v2fComposite o;
                float2 quadPos = float2(vtxID & 1, (vtxID >> 1) & 1) * 4.0 - 1.0;
                o.vertex = float4(quadPos, 1, 1);
                return o;
            }

            Texture2D _GaussianSplatRT;

            half4 fragComposite(v2fComposite i) : SV_Target
            {
                return _GaussianSplatRT.Load(int3(i.vertex.xy, 0));
            }
            ENDCG
        }
    }
}
